/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;

/**
 * �������� ��й�ȣ ���� 
 * @author ���ѳ�
 *
 */
public class AdminMemberUnLockDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ȸ�� ID **/
	private String ID;
	/** �α��� ID **/
	private String sLoginId;
	/** �̸� **/
	private String sName;
	/** �������� ��ȣ ���� Ƚ�� **/
	private String nPasswordFailureCount;
	/** ��ȣ �÷��� (0:����, 1:���, 2:�������) **/
	private String sPassFlag;
	/** ��ȣ���� ���� **/
	private String sPassFailDate;
	/** ��ȣ��� �������� **/
	private String sFailClearDate;
	/** ��ȣ��� ������ **/
	private String sFailClearID;
	/** �������� **/
	private String sCreDate;
	/** �����ð� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	/** ������ ������ **/
	@XmlTransient
	private String startDate;
	/** ������ ������ **/
	@XmlTransient
	private String endDate;
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the sLoginId
	 */
	public String getsLoginId() {
		return sLoginId;
	}
	/**
	 * @param sLoginId the sLoginId to set
	 */
	public void setsLoginId(String sLoginId) {
		this.sLoginId = sLoginId;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the nPasswordFailureCount
	 */
	public String getnPasswordFailureCount() {
		return nPasswordFailureCount;
	}
	/**
	 * @param nPasswordFailureCount the nPasswordFailureCount to set
	 */
	public void setnPasswordFailureCount(String nPasswordFailureCount) {
		this.nPasswordFailureCount = nPasswordFailureCount;
	}
	/**
	 * @return the sPassFlag
	 */
	public String getsPassFlag() {
		return sPassFlag;
	}
	/**
	 * @param sPassFlag the sPassFlag to set
	 */
	public void setsPassFlag(String sPassFlag) {
		this.sPassFlag = sPassFlag;
	}
	/**
	 * @return the sPassFailDate
	 */
	public String getsPassFailDate() {
		return sPassFailDate;
	}
	/**
	 * @param sPassFailDate the sPassFailDate to set
	 */
	public void setsPassFailDate(String sPassFailDate) {
		this.sPassFailDate = sPassFailDate;
	}
	/**
	 * @return the sFailClearDate
	 */
	public String getsFailClearDate() {
		return sFailClearDate;
	}
	/**
	 * @param sFailClearDate the sFailClearDate to set
	 */
	public void setsFailClearDate(String sFailClearDate) {
		this.sFailClearDate = sFailClearDate;
	}
	/**
	 * @return the sFailClearID
	 */
	public String getsFailClearID() {
		return sFailClearID;
	}
	/**
	 * @param sFailClearID the sFailClearID to set
	 */
	public void setsFailClearID(String sFailClearID) {
		this.sFailClearID = sFailClearID;
	}
	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}
	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(String sCreDate) {
		this.sCreDate = sCreDate;
	}
	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}
	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}
	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}
	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(String sModiDate) {
		this.sModiDate = sModiDate;
	}
	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}
	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(String sModiTime) {
		this.sModiTime = sModiTime;
	}
	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
}
