/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.commonMng;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/** 
 * ü��ó ���� DTO
 * @author ������
 * @since 1.1.0
 */
public class PartnershipDTO extends PageDTO {

	/** default **/
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ **/
	private Long nSeq;
	/** ����ó�ڵ� **/
	private String sAffiliatedConcern;
	/** ����ó�� **/
	private String sAffiliatedConcernName;
	/**	**/
	private String sContactPath;
	/** ����� **/
	private String sStaffName;
	/** �Խ��� **/
	private String sOpenDate;
	/** ������(���ᰡ �Ǿ ����ó������ ������ ���������� ����) **/
	private String sEndDate;
	/** ������ **/
	private String sJobKind;
	/** ���λ����� **/
	private String sWidth;
	/** �ڵ�������-ǥ�ø� **/
	private String sCarText;
	/** �ڵ�������-������갡�� **/
	private String sCarCalc;
	/** �ڵ�������-����û **/
	private String sCarCounsel;
	/** �Ϲݺ���-ǥ�ø� **/
	private String sGeneralText;
	/** �Ϲݺ���-������갡�� **/
	private String sGeneralCalc;
	/** �Ϲݺ���-����û **/
	private String sGeneralCounsel;
	/** ��⺸��-����û **/
	private String sLongCounsel;
	/** ��⺸�� ��ǰ�ڵ� **/
	private String sLongProductCode;
	/** ȸ��ΰ�-�̹����̸� **/
	private String sLogoImageName;
	/** ȸ��ΰ�-�̹���URL **/
	private String sLogoImageURL;
	/** ����ʼ���-�̹����̸� **/
	private String sMembershipImageName;
	/** ����ʼ���-�̹���URL **/
	private String sMembershipImageURL;
	/** ����ʼ���-Forward URL **/
	private String sMembershipForwardURL;
	/** ���������-�̹����̸� **/
	private String sSavingImageName;
	/** ���������-�̹���URL **/
	private String sSavingImageURL;
	/** ���������-Forward URL **/
	private String sSavingForwardURL;
	/** ��õ��ǰ-�̹����̸� **/
	private String sBestImageName;
	/** ��õ��ǰ-�̹���URL **/
	private String sBestImageURL;
	/** ��õ��ǰ-Forward URL **/
	private String sBestForwardURL;
	/** ����ϼ���-�̹����̸� **/
	private String sMobileImageName;
	/** ����ϼ���-�̹���URL **/
	private String sMobileImageURL;
	/** ����ϼ���-Forward URL **/
	private String sMobileForwardURL;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	/** �������(���, ����, ����) **/
	private String status;

	/** �ΰ� �̹��� **/
	private MultipartFile logoImageFile;
	/** ����� ���� �̹��� **/
	private MultipartFile memberShipImageFile;
	/** ����� ���� �̹��� **/
	private MultipartFile savingImageFile;
	/** ��õ��ǰ �̹��� **/
	private MultipartFile bestImageFile;
	/** ����� ���� �̹��� **/
	private MultipartFile mobileImageFile;
	/** ���� ���� �̹��� **/
	private MultipartFile mainImageFile;
	/** �����2 ���� �̹��� **/
	private MultipartFile memberShip2ImageFile;

	/** ����ó���� **/
	private String sHashkey;
	/** �̺�Ʈ�ڵ� **/
	private String sEventDiv;
	/** �����ID **/
	private String sUserID;
	/** ������� **/  
	private String sHomepageJehuYn;
	
	/** �������ȣ **/  
	private String sCounselNo;
	
	/** ����ʼ���2-�̹����̸� **/
	private String sMembership2ImageName;
	/** ����ʼ���2-�̹���URL **/
	private String sMembership2ImageURL;
	/** ����ʼ���2-Forward URL **/
	private String sMembership2ForwardURL;
	/** ����-�̹����̸� **/
	private String sMainImageName;
	/** ����-�̹���URL **/
	private String sMainImageURL;
	/** ����-Forward URL **/
	private String sMainForwardURL;
	
	// �˻��� ���
	/** �˻� ���� **/
	private String searchType;
	/** �˻��� **/
	private String searchValue;
	/** �˻���_�޺� **/
	private String searchValue2;
	
	//���޻���� ���
	private String sAdminID;
	private String sPassword;
	private String sAdminName;
	private String sEmpNo;
	private String sDept;
	private String sPosition;
	private String sLevel;
	private String sTel;
	private String sCelluar;
	private String sEmail;
	private String sJehuID;
	private String sTime;
	private String sDate;
	private String sIsrt;
	
	//���ް����ڰ��� ���
	private String sSSN;
	private String sIPAddress;
	private String sIPAddress_new;
	private String sCompany;
	private String sEmpName;
	//private String sTel;
	private String sAdminId;
	private String sJehuInfo1;
	private String sJehuInfo2;
	private String sJehuInfo3;
	
	public String getsContactPath() {
		return sContactPath;
	}

	public void setsContactPath(String sContactPath) {
		this.sContactPath = sContactPath;
	}

	public String getsIPAddress_new() {
		return sIPAddress_new;
	}

	public void setsIPAddress_new(String sIPAddress_new) {
		this.sIPAddress_new = sIPAddress_new;
	}
	public String getsAdminID() {
		return sAdminID;
	}

	public void setsAdminID(String sAdminID) {
		this.sAdminID = sAdminID;
	}

	public String getsPassword() {
		return sPassword;
	}

	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}

	public String getsAdminName() {
		return sAdminName;
	}

	public void setsAdminName(String sAdminName) {
		this.sAdminName = sAdminName;
	}

	public String getsEmpNo() {
		return sEmpNo;
	}

	public void setsEmpNo(String sEmpNo) {
		this.sEmpNo = sEmpNo;
	}

	public String getsDept() {
		return sDept;
	}

	public void setsDept(String sDept) {
		this.sDept = sDept;
	}

	public String getsPosition() {
		return sPosition;
	}

	public void setsPosition(String sPosition) {
		this.sPosition = sPosition;
	}

	public String getsLevel() {
		return sLevel;
	}

	public void setsLevel(String sLevel) {
		this.sLevel = sLevel;
	}

	public String getsTel() {
		return sTel;
	}

	public void setsTel(String sTel) {
		this.sTel = sTel;
	}

	public String getsCelluar() {
		return sCelluar;
	}

	public void setsCelluar(String sCelluar) {
		this.sCelluar = sCelluar;
	}

	public String getsEmail() {
		return sEmail;
	}

	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

	public String getsJehuID() {
		return sJehuID;
	}

	public void setsJehuID(String sJehuID) {
		this.sJehuID = sJehuID;
	}

	public String getsTime() {
		return sTime;
	}

	public void setsTime(String sTime) {
		this.sTime = sTime;
	}

	public String getsDate() {
		return sDate;
	}

	public void setsDate(String sDate) {
		this.sDate = sDate;
	}

	/**
	 * @return
	 */
	public String getSearchValue2() {
		return searchValue2;
	}

	/**
	 * @param searchValue2
	 */
	public void setSearchValue2(String searchValue2) {
		this.searchValue2 = searchValue2;
	}

	/**
	 * @return
	 */
	public String getSearchType() {
		return searchType;
	}

	/**
	 * @param searchType
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	/**
	 * @return
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	
	/**
	 * @return the nSeq
	 */
	public Long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the sAffiliatedConcernName
	 */
	public String getsAffiliatedConcernName() {
		return sAffiliatedConcernName;
	}

	/**
	 * @param sAffiliatedConcernName the sAffiliatedConcernName to set
	 */
	public void setsAffiliatedConcernName(final String sAffiliatedConcernName) {
		this.sAffiliatedConcernName = sAffiliatedConcernName;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}

	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(final String sEndDate) {
		this.sEndDate = sEndDate;
	}

	/**
	 * @return the sJobKind
	 */
	public String getsJobKind() {
		return sJobKind;
	}

	/**
	 * @param sJobKind the sJobKind to set
	 */
	public void setsJobKind(final String sJobKind) {
		this.sJobKind = sJobKind;
	}

	/**
	 * @return the sWidth
	 */
	public String getsWidth() {
		return sWidth;
	}

	/**
	 * @param sWidth the sWidth to set
	 */
	public void setsWidth(final String sWidth) {
		this.sWidth = sWidth;
	}

	/**
	 * @return the sCarText
	 */
	public String getsCarText() {
		return sCarText;
	}

	/**
	 * @param sCarText the sCarText to set
	 */
	public void setsCarText(final String sCarText) {
		this.sCarText = sCarText;
	}

	/**
	 * @return the sCarCalc
	 */
	public String getsCarCalc() {
		return sCarCalc;
	}

	/**
	 * @param sCarCalc the sCarCalc to set
	 */
	public void setsCarCalc(final String sCarCalc) {
		this.sCarCalc = sCarCalc;
	}

	/**
	 * @return the sCarCounsel
	 */
	public String getsCarCounsel() {
		return sCarCounsel;
	}

	/**
	 * @param sCarCounsel the sCarCounsel to set
	 */
	public void setsCarCounsel(final String sCarCounsel) {
		this.sCarCounsel = sCarCounsel;
	}

	/**
	 * @return the sGeneralText
	 */
	public String getsGeneralText() {
		return sGeneralText;
	}

	/**
	 * @param sGeneralText the sGeneralText to set
	 */
	public void setsGeneralText(final String sGeneralText) {
		this.sGeneralText = sGeneralText;
	}

	/**
	 * @return the sGeneralCalc
	 */
	public String getsGeneralCalc() {
		return sGeneralCalc;
	}

	/**
	 * @param sGeneralCalc the sGeneralCalc to set
	 */
	public void setsGeneralCalc(final String sGeneralCalc) {
		this.sGeneralCalc = sGeneralCalc;
	}

	/**
	 * @return the sGeneralCounsel
	 */
	public String getsGeneralCounsel() {
		return sGeneralCounsel;
	}

	/**
	 * @param sGeneralCounsel the sGeneralCounsel to set
	 */
	public void setsGeneralCounsel(final String sGeneralCounsel) {
		this.sGeneralCounsel = sGeneralCounsel;
	}

	/**
	 * @return the sLongCounsel
	 */
	public String getsLongCounsel() {
		return sLongCounsel;
	}

	/**
	 * @param sLongCounsel the sLongCounsel to set
	 */
	public void setsLongCounsel(final String sLongCounsel) {
		this.sLongCounsel = sLongCounsel;
	}

	/**
	 * @return the sLongProductCode
	 */
	public String getsLongProductCode() {
		return sLongProductCode;
	}

	/**
	 * @param sLongProductCode the sLongProductCode to set
	 */
	public void setsLongProductCode(final String sLongProductCode) {
		this.sLongProductCode = sLongProductCode;
	}

	/**
	 * @return the sLogoImageName
	 */
	public String getsLogoImageName() {
		return sLogoImageName;
	}

	/**
	 * @param sLogoImageName the sLogoImageName to set
	 */
	public void setsLogoImageName(final String sLogoImageName) {
		this.sLogoImageName = sLogoImageName;
	}

	/**
	 * @return the sLogoImageURL
	 */
	public String getsLogoImageURL() {
		return sLogoImageURL;
	}

	/**
	 * @param sLogoImageURL the sLogoImageURL to set
	 */
	public void setsLogoImageURL(final String sLogoImageURL) {
		this.sLogoImageURL = sLogoImageURL;
	}

	/**
	 * @return the sMembershipImageName
	 */
	public String getsMembershipImageName() {
		return sMembershipImageName;
	}

	/**
	 * @param sMembershipImageName the sMembershipImageName to set
	 */
	public void setsMembershipImageName(final String sMembershipImageName) {
		this.sMembershipImageName = sMembershipImageName;
	}

	/**
	 * @return the sMembershipImageURL
	 */
	public String getsMembershipImageURL() {
		return sMembershipImageURL;
	}

	/**
	 * @param sMembershipImageURL the sMembershipImageURL to set
	 */
	public void setsMembershipImageURL(final String sMembershipImageURL) {
		this.sMembershipImageURL = sMembershipImageURL;
	}

	/**
	 * @return the sMembershipForwardURL
	 */
	public String getsMembershipForwardURL() {
		return sMembershipForwardURL;
	}

	/**
	 * @param sMembershipForwardURL the sMembershipForwardURL to set
	 */
	public void setsMembershipForwardURL(final String sMembershipForwardURL) {
		this.sMembershipForwardURL = sMembershipForwardURL;
	}

	/**
	 * @return the sSavingImageName
	 */
	public String getsSavingImageName() {
		return sSavingImageName;
	}

	/**
	 * @param sSavingImageName the sSavingImageName to set
	 */
	public void setsSavingImageName(final String sSavingImageName) {
		this.sSavingImageName = sSavingImageName;
	}

	/**
	 * @return the sSavingImageURL
	 */
	public String getsSavingImageURL() {
		return sSavingImageURL;
	}

	/**
	 * @param sSavingImageURL the sSavingImageURL to set
	 */
	public void setsSavingImageURL(final String sSavingImageURL) {
		this.sSavingImageURL = sSavingImageURL;
	}

	/**
	 * @return the sSavingForwardURL
	 */
	public String getsSavingForwardURL() {
		return sSavingForwardURL;
	}

	/**
	 * @param sSavingForwardURL the sSavingForwardURL to set
	 */
	public void setsSavingForwardURL(final String sSavingForwardURL) {
		this.sSavingForwardURL = sSavingForwardURL;
	}

	/**
	 * @return the sBestImageName
	 */
	public String getsBestImageName() {
		return sBestImageName;
	}

	/**
	 * @param sBestImageName the sBestImageName to set
	 */
	public void setsBestImageName(final String sBestImageName) {
		this.sBestImageName = sBestImageName;
	}

	/**
	 * @return the sBestImageURL
	 */
	public String getsBestImageURL() {
		return sBestImageURL;
	}

	/**
	 * @param sBestImageURL the sBestImageURL to set
	 */
	public void setsBestImageURL(final String sBestImageURL) {
		this.sBestImageURL = sBestImageURL;
	}

	/**
	 * @return the sBestForwardURL
	 */
	public String getsBestForwardURL() {
		return sBestForwardURL;
	}

	/**
	 * @param sBestForwardURL the sBestForwardURL to set
	 */
	public void setsBestForwardURL(final String sBestForwardURL) {
		this.sBestForwardURL = sBestForwardURL;
	}

	/**
	 * @return the sMobileImageName
	 */
	public String getsMobileImageName() {
		return sMobileImageName;
	}

	/**
	 * @param sMobileImageName the sMobileImageName to set
	 */
	public void setsMobileImageName(final String sMobileImageName) {
		this.sMobileImageName = sMobileImageName;
	}

	/**
	 * @return the sMobileImageURL
	 */
	public String getsMobileImageURL() {
		return sMobileImageURL;
	}

	/**
	 * @param sMobileImageURL the sMobileImageURL to set
	 */
	public void setsMobileImageURL(final String sMobileImageURL) {
		this.sMobileImageURL = sMobileImageURL;
	}

	/**
	 * @return the sMobileForwardURL
	 */
	public String getsMobileForwardURL() {
		return sMobileForwardURL;
	}

	/**
	 * @param sMobileForwardURL the sMobileForwardURL to set
	 */
	public void setsMobileForwardURL(final String sMobileForwardURL) {
		this.sMobileForwardURL = sMobileForwardURL;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(final String status) {
		this.status = status;
	}

	/**
	 * @return the logoImageFile
	 */
	public MultipartFile getLogoImageFile() {
		return logoImageFile;
	}

	/**
	 * @param logoImageFile the logoImageFile to set
	 */
	public void setLogoImageFile(final MultipartFile logoImageFile) {
		this.logoImageFile = logoImageFile;
	}

	/**
	 * @return the memberShipImageFile
	 */
	public MultipartFile getMemberShipImageFile() {
		return memberShipImageFile;
	}

	/**
	 * @param memberShipImageFile the memberShipImageFile to set
	 */
	public void setMemberShipImageFile(final MultipartFile memberShipImageFile) {
		this.memberShipImageFile = memberShipImageFile;
	}

	/**
	 * @return the savingImageFile
	 */
	public MultipartFile getSavingImageFile() {
		return savingImageFile;
	}

	/**
	 * @param savingImageFile the savingImageFile to set
	 */
	public void setSavingImageFile(final MultipartFile savingImageFile) {
		this.savingImageFile = savingImageFile;
	}

	/**
	 * @return the bestImageFile
	 */
	public MultipartFile getBestImageFile() {
		return bestImageFile;
	}

	/**
	 * @param bestImageFile the bestImageFile to set
	 */
	public void setBestImageFile(final MultipartFile bestImageFile) {
		this.bestImageFile = bestImageFile;
	}

	/**
	 * @return the mobileImageFile
	 */
	public MultipartFile getMobileImageFile() {
		return mobileImageFile;
	}

	/**
	 * @param mobileImageFile the mobileImageFile to set
	 */
	public void setMobileImageFile(final MultipartFile mobileImageFile) {
		this.mobileImageFile = mobileImageFile;
	}
	
	/**
	 * @return
	 */
	public String getsHashkey() {
		return sHashkey;
	}

	/**
	 * @param hashkey
	 */
	public void setsHashkey(String sHashkey) {
		this.sHashkey = sHashkey;
	}

	/**
	 * @return
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}

	/**
	 * @param sEventDiv
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	/**
	 * @return
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return
	 */
	public String getsHomepageJehuYn() {
		return sHomepageJehuYn;
	}

	/**
	 * @param homepageJehuYn
	 */
	public void setsHomepageJehuYn(String sHomepageJehuYn) {
		this.sHomepageJehuYn = sHomepageJehuYn;
	}

	/**
	 * @return
	 */
	public String getsIsrt() {
		return sIsrt;
	}

	/**
	 * @param sIsrt
	 */
	public void setsIsrt(String sIsrt) {
		this.sIsrt = sIsrt;
	}

	/**
	 * @return
	 */
	public String getsSSN() {
		return sSSN;
	}

	/**
	 * @param sSSN
	 */
	public void setsSSN(String sSSN) {
		this.sSSN = sSSN;
	}

	/**
	 * @return
	 */
	public String getsIPAddress() {
		return sIPAddress;
	}

	/**
	 * @param sIPAddress
	 */
	public void setsIPAddress(String sIPAddress) {
		this.sIPAddress = sIPAddress;
	}

	/**
	 * @return
	 */
	public String getsCompany() {
		return sCompany;
	}

	/**
	 * @param sCompany
	 */
	public void setsCompany(String sCompany) {
		this.sCompany = sCompany;
	}

	/**
	 * @return
	 */
	public String getsEmpName() {
		return sEmpName;
	}

	/**
	 * @param sEmpName
	 */
	public void setsEmpName(String sEmpName) {
		this.sEmpName = sEmpName;
	}

	/**
	 * @return
	 */
	public String getsAdminId() {
		return sAdminId;
	}

	/**
	 * @param sAdminId
	 */
	public void setsAdminId(String sAdminId) {
		this.sAdminId = sAdminId;
	}

	/**
	 * @return
	 */
	public String getsJehuInfo1() {
		return sJehuInfo1;
	}

	/**
	 * @param sJehuInfo1
	 */
	public void setsJehuInfo1(String sJehuInfo1) {
		this.sJehuInfo1 = sJehuInfo1;
	}

	/**
	 * @return
	 */
	public String getsJehuInfo2() {
		return sJehuInfo2;
	}

	/**
	 * @param sJehuInfo2
	 */
	public void setsJehuInfo2(String sJehuInfo2) {
		this.sJehuInfo2 = sJehuInfo2;
	}

	/**
	 * @return
	 */
	public String getsJehuInfo3() {
		return sJehuInfo3;
	}

	/**
	 * @param sJehuInfo3
	 */
	public void setsJehuInfo3(String sJehuInfo3) {
		this.sJehuInfo3 = sJehuInfo3;
	}

	/**
	 * @return the sCounselNo
	 */
	public String getsCounselNo() {
		return sCounselNo;
	}

	/**
	 * @param sCounselNo the sCounselNo to set
	 */
	public void setsCounselNo(String sCounselNo) {
		this.sCounselNo = sCounselNo;
	}

	/**
	 * @return the sMembership2ImageName
	 */
	public String getsMembership2ImageName() {
		return sMembership2ImageName;
	}

	/**
	 * @param sMembership2ImageName the sMembership2ImageName to set
	 */
	public void setsMembership2ImageName(String sMembership2ImageName) {
		this.sMembership2ImageName = sMembership2ImageName;
	}

	/**
	 * @return the sMembership2ImageURL
	 */
	public String getsMembership2ImageURL() {
		return sMembership2ImageURL;
	}

	/**
	 * @param sMembership2ImageURL the sMembership2ImageURL to set
	 */
	public void setsMembership2ImageURL(String sMembership2ImageURL) {
		this.sMembership2ImageURL = sMembership2ImageURL;
	}

	/**
	 * @return the sMembership2ForwardURL
	 */
	public String getsMembership2ForwardURL() {
		return sMembership2ForwardURL;
	}

	/**
	 * @param sMembership2ForwardURL the sMembership2ForwardURL to set
	 */
	public void setsMembership2ForwardURL(String sMembership2ForwardURL) {
		this.sMembership2ForwardURL = sMembership2ForwardURL;
	}

	/**
	 * @return the sMainImageName
	 */
	public String getsMainImageName() {
		return sMainImageName;
	}

	/**
	 * @param sMainImageName the sMainImageName to set
	 */
	public void setsMainImageName(String sMainImageName) {
		this.sMainImageName = sMainImageName;
	}

	/**
	 * @return the sMainImageURL
	 */
	public String getsMainImageURL() {
		return sMainImageURL;
	}

	/**
	 * @param sMainImageURL the sMainImageURL to set
	 */
	public void setsMainImageURL(String sMainImageURL) {
		this.sMainImageURL = sMainImageURL;
	}

	/**
	 * @return the sMainForwardURL
	 */
	public String getsMainForwardURL() {
		return sMainForwardURL;
	}

	/**
	 * @param sMainForwardURL the sMainForwardURL to set
	 */
	public void setsMainForwardURL(String sMainForwardURL) {
		this.sMainForwardURL = sMainForwardURL;
	}

	/**
	 * @return the mainImageFile
	 */
	public MultipartFile getMainImageFile() {
		return mainImageFile;
	}

	/**
	 * @param mainImageFile the mainImageFile to set
	 */
	public void setMainImageFile(MultipartFile mainImageFile) {
		this.mainImageFile = mainImageFile;
	}

	/**
	 * @return the memberShip2ImageFile
	 */
	public MultipartFile getMemberShip2ImageFile() {
		return memberShip2ImageFile;
	}

	/**
	 * @param memberShip2ImageFile the memberShip2ImageFile to set
	 */
	public void setMemberShip2ImageFile(MultipartFile memberShip2ImageFile) {
		this.memberShip2ImageFile = memberShip2ImageFile;
	}
}
