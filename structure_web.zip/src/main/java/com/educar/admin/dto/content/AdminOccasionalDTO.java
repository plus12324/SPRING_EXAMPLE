/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * ������ - �濵���� - ���ð濵���� 
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "occasionalDTO")
public class AdminOccasionalDTO extends PageDTO{
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** ���� **/
	private String seq;
	/** ���� **/
	private String title;
	/** �������� **/
	private String view_yn;
	/** ����� **/
	private String cre_id;
	/** ������ **/
	private String upd_id;
	/** ����� **/
	private String cre_dt;
	/** ������ **/
	private String upd_dt;
	
	private String registdate;
	private String updatedate;
	/** ��Ͻð� **/
	private String cre_time;
	/** �����ð� **/
	private String upd_time;
	/** �����̸� **/
	private String file_nm;
	/** ���ϰ�� **/
	private String file_path;
	/** �������ϰ�� **/
	private String file_real_path;
	
	private String file_str_nm;
	
	/** ����ڸ� **/
	private String cre_nm;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	/**
	 * @return the seq
	 */
	public String getSeq() {
		return seq;
	}
	/**
	 * @param seq the seq to set
	 */
	public void setSeq(String seq) {
		this.seq = seq;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the view_yn
	 */
	public String getView_yn() {
		return view_yn;
	}
	/**
	 * @param view_yn the view_yn to set
	 */
	public void setView_yn(String view_yn) {
		this.view_yn = view_yn;
	}
	/**
	 * @return the cre_id
	 */
	public String getCre_id() {
		return cre_id;
	}
	/**
	 * @param cre_id the cre_id to set
	 */
	public void setCre_id(String cre_id) {
		this.cre_id = cre_id;
	}
	/**
	 * @return the upd_id
	 */
	public String getUpd_id() {
		return upd_id;
	}
	/**
	 * @param upd_id the upd_id to set
	 */
	public void setUpd_id(String upd_id) {
		this.upd_id = upd_id;
	}
	/**
	 * @return the cre_dt
	 */
	public String getCre_dt() {
		return cre_dt;
	}
	/**
	 * @param cre_dt the cre_dt to set
	 */
	public void setCre_dt(String cre_dt) {
		this.cre_dt = cre_dt;
	}
	
	/**
	 * @return the upd_dt
	 */
	public String getUpd_dt() {
		return upd_dt;
	}
	/**
	 * @param upd_dt the upd_dt to set
	 */
	public void setUpd_dt(String upd_dt) {
		this.upd_dt = upd_dt;
	}
	/**
	 * @return the registdate
	 */
	public String getRegistdate() {
		return registdate;
	}
	/**
	 * @param registdate the registdate to set
	 */
	public void setRegistdate(String registdate) {
		this.registdate = registdate;
	}
	/**
	 * @return the updatedate
	 */
	public String getUpdatedate() {
		return updatedate;
	}
	/**
	 * @param updatedate the updatedate to set
	 */
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}
	/**
	 * @return the cre_time
	 */
	public String getCre_time() {
		return cre_time;
	}
	/**
	 * @param cre_time the cre_time to set
	 */
	public void setCre_time(String cre_time) {
		this.cre_time = cre_time;
	}
	/**
	 * @return the upd_time
	 */
	public String getUpd_time() {
		return upd_time;
	}
	/**
	 * @param upd_time the upd_time to set
	 */
	public void setUpd_time(String upd_time) {
		this.upd_time = upd_time;
	}
	/**
	 * @return the file_nm
	 */
	public String getFile_nm() {
		return file_nm;
	}
	/**
	 * @param file_nm the file_nm to set
	 */
	public void setFile_nm(String file_nm) {
		this.file_nm = file_nm;
	}
	/**
	 * @return the file_path
	 */
	public String getFile_path() {
		return file_path;
	}
	/**
	 * @param file_path the file_path to set
	 */
	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}
	/**
	 * @return the file_real_path
	 */
	public String getFile_real_path() {
		return file_real_path;
	}
	/**
	 * @param file_real_path the file_real_path to set
	 */
	public void setFile_real_path(String file_real_path) {
		this.file_real_path = file_real_path;
	}
	/**
	 * @return the file_str_nm
	 */
	public String getFile_str_nm() {
		return file_str_nm;
	}
	/**
	 * @param file_str_nm the file_str_nm to set
	 */
	public void setFile_str_nm(String file_str_nm) {
		this.file_str_nm = file_str_nm;
	}
	/**
	 * @return the cre_nm
	 */
	public String getCre_nm() {
		return cre_nm;
	}
	/**
	 * @param cre_nm the cre_nm to set
	 */
	public void setCre_nm(String cre_nm) {
		this.cre_nm = cre_nm;
	}
	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}
	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}
	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	/**
	 * @return the editDiv
	 */
	public String getEditDiv() {
		return editDiv;
	}
	/**
	 * @param editDiv the editDiv to set
	 */
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}
	/**
	 * @return the mFile
	 */
	public MultipartFile getmFile() {
		return mFile;
	}
	/**
	 * @param mFile the mFile to set
	 */
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
	
	
}
