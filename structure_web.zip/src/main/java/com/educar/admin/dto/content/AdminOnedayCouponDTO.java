/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
 
/**
 * <pre>
 * ������ ���� ���� DTO
 * <pre>
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "adminOnedayCouponDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AdminOnedayCouponDTO {

	/**	�̺�Ʈ�ڵ�	**/ 
	private String sEventDiv;
	/**	�����ڵ�	**/ 
	private String sAffiliatedConcern;
	/**	������������	**/ 
	private String sCreateNum;
	/**	�����߻���¥	**/ 
	private String sCouponGiveDate;
	/** �����ڵ� 8�ڸ� **/
	private String sCouponCode;
	/** ����� �ڵ�**/
	private String sAgencyCode;
	/** ���� ���**/
	private String sContactPath;
	/** ��ȿ���� **/
	private String sCouponEndMm;
	/** ��������(���μ��� ��¥üũ�� ���) **/
	private String sCouponStartDate;
	/** ��� ��¥ **/
	private String sCreateDate;
	/** ��� �ð� **/
	private String sCreateTime;
	
	public String getsCouponCode() {
		return sCouponCode;
	}
	public void setsCouponCode(String sCouponCode) {
		this.sCouponCode = sCouponCode;
	}
	public String getsAgencyCode() {
		return sAgencyCode;
	}
	public void setsAgencyCode(String sAgencyCode) {
		this.sAgencyCode = sAgencyCode;
	}
	public String getsContactPath() {
		return sContactPath;
	}
	public void setsContactPath(String sContactPath) {
		this.sContactPath = sContactPath;
	}
	public String getsCouponEndMm() {
		return sCouponEndMm;
	}
	public void setsCouponEndMm(String sCouponEndMm) {
		this.sCouponEndMm = sCouponEndMm;
	}
	public String getsCouponStartDate() {
		return sCouponStartDate;
	}
	public void setsCouponStartDate(String sCouponStartDate) {
		this.sCouponStartDate = sCouponStartDate;
	}
	public String getsCreateDate() {
		return sCreateDate;
	}
	public void setsCreateDate(String sCreateDate) {
		this.sCreateDate = sCreateDate;
	}
	public String getsCreateTime() {
		return sCreateTime;
	}
	public void setsCreateTime(String sCreateTime) {
		this.sCreateTime = sCreateTime;
	}
	public String getsEventDiv() {
		return sEventDiv;
	}
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}
	public void setsAffiliatedConcern(String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}
	public String getsCreateNum() {
		return sCreateNum;
	}
	public void setsCreateNum(String sCreateNum) {
		this.sCreateNum = sCreateNum;
	}
	public String getsCouponGiveDate() {
		return sCouponGiveDate;
	}
	public void setsCouponGiveDate(String sCouponGiveDate) {
		this.sCouponGiveDate = sCouponGiveDate;
	}
	
	
	
}
