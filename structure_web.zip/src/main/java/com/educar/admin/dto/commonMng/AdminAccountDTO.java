/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.commonMng;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.common.dto.PageDTO;

/**
 * ������ �������� DTO
 * @author ������
 *
 */
public class AdminAccountDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ **/
	private String nSeq;
	/** �̸� **/
	private String sName;
	/** �ֹε�Ϲ�ȣ **/
	private String sSSN;
	/** ��� **/
	private String sEmployeeNumber;
	/** IP�ּ� **/
	private String sIPAddress;
	/** �μ� **/
	private String sDepartmentName;
	/** ��ȭ��ȣ1 **/
	private String sTel1;
	/** ��ȭ��ȣ2 **/
	private String sTel2;
	/** ���� **/
	private String sPosition;
	/** �̸��� **/
	private String sEmail;
	/** �޴����� �޴��ڵ�� adminMenuCode.properties���� **/
	private String sPermission;
	/** ������ **/
	private String sCreName;
	/** ������ **/
	private String sModiName;

	// �˻��� ���
	/** �˻� ���� **/
	private String kind;
	/** �˻��� **/
	private String searchValue;

	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final String nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sSSN
	 */
	public String getsSSN() {
		return sSSN;
	}

	/**
	 * @param sSSN the sSSN to set
	 */
	public void setsSSN(final String sSSN) {
		this.sSSN = sSSN;
	}

	/**
	 * @return the sEmployeeNumber
	 */
	public String getsEmployeeNumber() {
		return sEmployeeNumber;
	}

	/**
	 * @param sEmployeeNumber the sEmployeeNumber to set
	 */
	public void setsEmployeeNumber(final String sEmployeeNumber) {
		this.sEmployeeNumber = sEmployeeNumber;
	}

	/**
	 * @return the sIPAddress
	 */
	public String getsIPAddress() {
		return sIPAddress;
	}

	/**
	 * @param sIPAddress the sIPAddress to set
	 */
	public void setsIPAddress(final String sIPAddress) {
		this.sIPAddress = sIPAddress;
	}

	/**
	 * @return the sDepartmentName
	 */
	public String getsDepartmentName() {
		return sDepartmentName;
	}

	/**
	 * @param sDepartmentName the sDepartmentName to set
	 */
	public void setsDepartmentName(final String sDepartmentName) {
		this.sDepartmentName = sDepartmentName;
	}

	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}

	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(final String sTel1) {
		this.sTel1 = sTel1;
	}

	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}

	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(final String sTel2) {
		this.sTel2 = sTel2;
	}

	/**
	 * @return the sPosition
	 */
	public String getsPosition() {
		return sPosition;
	}

	/**
	 * @param sPosition the sPosition to set
	 */
	public void setsPosition(final String sPosition) {
		this.sPosition = sPosition;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sPermission
	 */
	public String getsPermission() {
		return sPermission;
	}

	/**
	 * @param sPermission the sPermission to set
	 */
	public void setsPermission(final String sPermission) {
		this.sPermission = sPermission;
	}

	/**
	 * @return the sCreName
	 */
	public String getsCreName() {
		return sCreName;
	}

	/**
	 * @param sCreName the sCreName to set
	 */
	public void setsCreName(final String sCreName) {
		this.sCreName = sCreName;
	}

	/**
	 * @return the sModiName
	 */
	public String getsModiName() {
		return sModiName;
	}

	/**
	 * @param sModiName the sModiName to set
	 */
	public void setsModiName(final String sModiName) {
		this.sModiName = sModiName;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(final String kind) {
		this.kind = kind;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(final String searchValue) {
		this.searchValue = searchValue;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
