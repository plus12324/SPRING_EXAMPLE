/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.common.dto.PageDTO;

/**
 * ȸ������ list DTO
 * @author ���ѳ�
 *
 */
public class AdminMemberInfoListDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ȸ�� ID **/
	private String ID;
	/** �α��� ID **/
	private String sLoginId;
	/** ������ȣ **/
	private String sCustNo;
	/** �̸� **/
	private String sName;
	/** �̸��� **/
	private String sEmail;
	/** �޴���1 **/
	private String sCellPhone1;
	/** �޴���2 **/
	private String sCellPhone2;
	/** �޴���3 **/
	private String sCellPhone3;
	/** �������� **/
	private String sCreDate;
	/** ���Խð� **/
	private String sCreTime;
	//�߰� 
	/** �������� **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	/** �������� ��ȸ�� ������ **/
	private String startDate;
	/** �������� ��ȸ�� ������ **/
	private String endDate;
	/** ������ȣ 1 **/
	private String sZip1;
	/** ������ȣ 2**/
	private String sZip2;
	/** �ּ�1 **/
	private String sADrs1;
	/** �ּ�2 **/
    private String sADrs2;
    /** �ּ�3 **/
    private String sADrs3;
    /** ������ �ּ� 1**/
    private String sAdrsAdd;
    /** ������ �ּ� 2**/
    private String sAdrsAdd2;
    /** ��ǰ�Ұ� �����̿� ����**/
    private String s04CallReject;
    private String s04DMReject;
    private String s04FaxReject;
    private String s04EmailReject;
    private String s04SMSReject;
    /** ��ǰ�Ұ� �������� **/
    private String s41CallReject;
    private String s41DMReject;
    private String s41FaxReject;
    private String s41EmailReject;
    private String s41SMSReject;
    /** ��ȸ���� (���������������� ��� **/
    private String sTabNo;
	
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}


	/**
	 * @param iD the iD to set
	 */
	public void setID(final String iD) {
		ID = iD;
	}


	/**
	 * @return the sLoginId
	 */
	public String getsLoginId() {
		return sLoginId;
	}


	/**
	 * @param sLoginId the sLoginId to set
	 */
	public void setsLoginId(final String sLoginId) {
		this.sLoginId = sLoginId;
	}


	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}


	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}


	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}


	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}


	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}


	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}


	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}


	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}


	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}


	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}


	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}


	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}


	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}


	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}


	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}


	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}

	
	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}


	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(String sModiDate) {
		this.sModiDate = sModiDate;
	}


	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}


	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(String sModiTime) {
		this.sModiTime = sModiTime;
	}


	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}


	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(final String startDate) {
		this.startDate = startDate;
	}


	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}


	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(final String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}


	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}


	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}


	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}


	/**
	 * @return the sADrs1
	 */
	public String getsADrs1() {
		return sADrs1;
	}


	/**
	 * @param sADrs1 the sADrs1 to set
	 */
	public void setsADrs1(String sADrs1) {
		this.sADrs1 = sADrs1;
	}


	/**
	 * @return the sADrs2
	 */
	public String getsADrs2() {
		return sADrs2;
	}


	/**
	 * @param sADrs2 the sADrs2 to set
	 */
	public void setsADrs2(String sADrs2) {
		this.sADrs2 = sADrs2;
	}


	/**
	 * @return the sADrs3
	 */
	public String getsADrs3() {
		return sADrs3;
	}


	/**
	 * @param sADrs3 the sADrs3 to set
	 */
	public void setsADrs3(String sADrs3) {
		this.sADrs3 = sADrs3;
	}


	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}


	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}


	/**
	 * @return the sAdrsAdd2
	 */
	public String getsAdrsAdd2() {
		return sAdrsAdd2;
	}


	/**
	 * @param sAdrsAdd2 the sAdrsAdd2 to set
	 */
	public void setsAdrsAdd2(String sAdrsAdd2) {
		this.sAdrsAdd2 = sAdrsAdd2;
	}

	
	/**
	 * @return the s04CallReject
	 */
	public String getS04CallReject() {
		return s04CallReject;
	}


	/**
	 * @param s04CallReject the s04CallReject to set
	 */
	public void setS04CallReject(String s04CallReject) {
		this.s04CallReject = s04CallReject;
	}


	/**
	 * @return the s04DMReject
	 */
	public String getS04DMReject() {
		return s04DMReject;
	}


	/**
	 * @param s04dmReject the s04DMReject to set
	 */
	public void setS04DMReject(String s04dmReject) {
		s04DMReject = s04dmReject;
	}


	/**
	 * @return the s04FaxReject
	 */
	public String getS04FaxReject() {
		return s04FaxReject;
	}


	/**
	 * @param s04FaxReject the s04FaxReject to set
	 */
	public void setS04FaxReject(String s04FaxReject) {
		this.s04FaxReject = s04FaxReject;
	}


	/**
	 * @return the s04EmailReject
	 */
	public String getS04EmailReject() {
		return s04EmailReject;
	}


	/**
	 * @param s04EmailReject the s04EmailReject to set
	 */
	public void setS04EmailReject(String s04EmailReject) {
		this.s04EmailReject = s04EmailReject;
	}


	/**
	 * @return the s04SMSReject
	 */
	public String getS04SMSReject() {
		return s04SMSReject;
	}


	/**
	 * @param s04smsReject the s04SMSReject to set
	 */
	public void setS04SMSReject(String s04smsReject) {
		s04SMSReject = s04smsReject;
	}


	/**
	 * @return the s41CallReject
	 */
	public String getS41CallReject() {
		return s41CallReject;
	}


	/**
	 * @param s41CallReject the s41CallReject to set
	 */
	public void setS41CallReject(String s41CallReject) {
		this.s41CallReject = s41CallReject;
	}


	/**
	 * @return the s41DMReject
	 */
	public String getS41DMReject() {
		return s41DMReject;
	}


	/**
	 * @param s41dmReject the s41DMReject to set
	 */
	public void setS41DMReject(String s41dmReject) {
		s41DMReject = s41dmReject;
	}


	/**
	 * @return the s41FaxReject
	 */
	public String getS41FaxReject() {
		return s41FaxReject;
	}


	/**
	 * @param s41FaxReject the s41FaxReject to set
	 */
	public void setS41FaxReject(String s41FaxReject) {
		this.s41FaxReject = s41FaxReject;
	}


	/**
	 * @return the s41EmailReject
	 */
	public String getS41EmailReject() {
		return s41EmailReject;
	}


	/**
	 * @param s41EmailReject the s41EmailReject to set
	 */
	public void setS41EmailReject(String s41EmailReject) {
		this.s41EmailReject = s41EmailReject;
	}


	/**
	 * @return the s41SMSReject
	 */
	public String getS41SMSReject() {
		return s41SMSReject;
	}


	/**
	 * @param s41smsReject the s41SMSReject to set
	 */
	public void setS41SMSReject(String s41smsReject) {
		s41SMSReject = s41smsReject;
	}

	
	/**
	 * @return the sTabNo
	 */
	public String getsTabNo() {
		return sTabNo;
	}


	/**
	 * @param sTabNo the sTabNo to set
	 */
	public void setsTabNo(String sTabNo) {
		this.sTabNo = sTabNo;
	}


	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
