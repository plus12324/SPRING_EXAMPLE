/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ������ - �������� - �ٿ�ε弾�� DTO
 * ���� DB : WEBFF08
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "downloadCenterDTO")
public class AdminDownloadCenterDTO extends PageDTO {
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Խñ� ��ȣ  */
	private Integer nSeq;
	/** ���ҽ�Ű **/
	private String sResourceKey;
	/** ĳ�Ͱ��� ���� */
	private String sType;
	/** ���� */
	private String sTitle;
	/** ÷������ ����*/
	private String sFileType;
	/** ���� ���� URI**/
	private String sFileTypeURI;
	/** ���� �̸� **/
	private String sFileName;
	/** ����� **/
	private String sCreDate;
	/** ��Ͻð� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	/** �������� **/
	private String sPubYN;
	/** ����� **/
	private String sUser;
	/** ����� �� (�����ڿ��� ���)**/
	private String sUserNm;
	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/

	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Integer nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sResourceKey
	 */
	public String getsResourceKey() {
		return sResourceKey;
	}

	/**
	 * @param sResourceKey the sResourceKey to set
	 */
	public void setsResourceKey(final String sResourceKey) {
		this.sResourceKey = sResourceKey;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sAttachFile
	 */
	public String getsFileType() {
		return sFileType;
	}

	/**
	 * @param sAttachFile the sAttachFile to set
	 */
	public void setsFileType(final String sAttachFile) {
		this.sFileType = sAttachFile;
	}

	/**
	 * @return the sFileTypeURI
	 */
	public String getsFileTypeURI() {
		return sFileTypeURI;
	}

	/**
	 * @param sFileTypeURI the sFileTypeURI to set
	 */
	public void setsFileTypeURI(final String sFileTypeURI) {
		this.sFileTypeURI = sFileTypeURI;
	}

	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}

	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(final String sFileName) {
		this.sFileName = sFileName;
	}

	/**
	 * @return the sType
	 */
	public String getsType() {
		return sType;
	}

	/**
	 * @param sType the sType to set
	 */
	public void setsType(final String sType) {
		this.sType = sType;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the sPubYN
	 */
	public String getsPubYN() {
		return sPubYN;
	}

	/**
	 * @param sPubYN the sPubYN to set
	 */
	public void setsPubYN(String sPubYN) {
		this.sPubYN = sPubYN;
	}

	/**
	 * @return the sUser
	 */
	public String getsUser() {
		return sUser;
	}

	/**
	 * @param sUser the sUser to set
	 */
	public void setsUser(String sUser) {
		this.sUser = sUser;
	}
	
	/**
	 * @return the sUser
	 */
	public String getsUserNm() {
		return sUserNm;
	}

	/**
	 * @param sUser the sUser to set
	 */
	public void setsUserNm(String sUserNm) {
		this.sUserNm = sUserNm;
	}
	
	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}

	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}

	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}

	/**
	 * @return the editDiv
	 */
	public String getEditDiv() {
		return editDiv;
	}

	/**
	 * @param editDiv the editDiv to set
	 */
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}

	/**
	 * @return the mFile
	 */
	public MultipartFile getmFile() {
		return mFile;
	}

	/**
	 * @param mFile the mFile to set
	 */
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
	
}
