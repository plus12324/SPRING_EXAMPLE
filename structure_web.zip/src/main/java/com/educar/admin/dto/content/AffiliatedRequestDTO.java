/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;

/**
 * ���޹��� ���忡 ���Ǵ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement(name = "adminAffiliatedRequestDTO")
public class AffiliatedRequestDTO extends PageDTO implements Serializable {
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	
	/** �Ϸù�ȣ */
	private int nSeq;
	/** ���� **/
	private String sTitle;
	/** ���� **/
	private String sDivision1;
	/** �������� **/
	private String sDivision2;
	/** ������¥ �����(YYYYMMDD)**/
	private String sRegDate;
	/** �����ð� ��Ͻð� (HHMMSS) **/
	private String sRegTime;
	/** �߼۳�¥ **/
	private String sSendDate;
	/** �߼۽ð� **/
	private String sSendTime;
	/** �̸� **/
	private String sName;
	/** ���� ������ **/
	private String sReceiveMail;
	/** ���� **/
	private String sContent;
	/** �ڵ��� 1 **/
	private String sTel1;
	/** �ڵ��� 2 **/
	private String sTel2;
	/** �ڵ��� 3 **/
	private String sTel3;
	/** ����(�ſ�)���� ó�� ���� **/
	private String sAgreeYN;
	
	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/
	@XmlTransient
	private String kind;
	/** �Ϸù�ȣ  **/
	@XmlTransient
	private String sSeq;
	/** �˻��� **/
	@XmlTransient
	private String searchValue;
	/** ������ ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** ������ ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	
	/**
	 * @return the nSeq
	 */
	public int getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final int nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sDivision1
	 */
	public String getsDivision1() {
		return sDivision1;
	}

	/**
	 * @param sDivision1 the sDivision1 to set
	 */
	public void setsDivision1(final String sDivision1) {
		this.sDivision1 = sDivision1;
	}

	/**
	 * @return the sDivision2
	 */
	public String getsDivision2() {
		return sDivision2;
	}

	/**
	 * @param sDivision2 the sDivision2 to set
	 */
	public void setsDivision2(final String sDivision2) {
		this.sDivision2 = sDivision2;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sSendDate
	 */
	public String getsSendDate() {
		return sSendDate;
	}

	/**
	 * @param sSendDate the sSendDate to set
	 */
	public void setsSendDate(final String sSendDate) {
		this.sSendDate = sSendDate;
	}

	/**
	 * @return the sSendTime
	 */
	public String getsSendTime() {
		return sSendTime;
	}

	/**
	 * @param sSendTime the sSendTime to set
	 */
	public void setsSendTime(final String sSendTime) {
		this.sSendTime = sSendTime;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sReceiveMail
	 */
	public String getsReceiveMail() {
		return sReceiveMail;
	}

	/**
	 * @param sReceiveMail the sReceiveMail to set
	 */
	public void setsReceiveMail(final String sReceiveMail) {
		this.sReceiveMail = sReceiveMail;
	}

	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}

	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(final String sContent) {
		this.sContent = sContent;
	}

	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}

	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(final String sTel1) {
		this.sTel1 = sTel1;
	}

	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}

	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(final String sTel2) {
		this.sTel2 = sTel2;
	}

	/**
	 * @return the sTel3
	 */
	public String getsTel3() {
		return sTel3;
	}

	/**
	 * @param sTel3 the sTel3 to set
	 */
	public void setsTel3(final String sTel3) {
		this.sTel3 = sTel3;
	}

	/**
	 * @return the sAgreeYN
	 */
	public String getsAgreeYN() {
		return sAgreeYN;
	}

	/**
	 * @param sAgreeYN the sAgreeYN to set
	 */
	public void setsAgreeYN(String sAgreeYN) {
		this.sAgreeYN = sAgreeYN;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}

	/**
	 * @return the sSeq
	 */
	public String getsSeq() {
		return sSeq;
	}

	/**
	 * @param sSeq the sSeq to set
	 */
	public void setsSeq(String sSeq) {
		this.sSeq = sSeq;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}

	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}

	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	
	
}
