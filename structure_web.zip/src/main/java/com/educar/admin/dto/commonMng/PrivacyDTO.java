/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.commonMng;

import com.educar.common.dto.PageDTO;


/**
 * ��� DTO
 * @author ������
 * @since 1.1.0
 */
public class PrivacyDTO  extends PageDTO {
	/** default */
	private static final long serialVersionUID = 1L;
	
	/** �Ϸù�ȣ **/
	private Long nSeq;
	/** ��� Ÿ��Ʋ **/
	private String sTitle;
	/** ������� **/
	private String sContents;
	/** �ʼ����� **/
	private String sAgreeAt;
	/** ����� **/
	private String sRegiDate;
	/** ������ **/
	private String sModiName;
	/** �������� **/
	private String sModiReason;
	/** ������ **/
	private String sModiDate;
	/** ��ȸ ���� 1: �����, 2:����� **/
	private String searchType;
	/** �˻��� **/
	private String searchValue;

	/**
	 * @return the nSeq
	 */
	public Long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContents
	 */
	public String getsContents() {
		return sContents;
	}

	/**
	 * @param sContents the sContents to set
	 */
	public void setsContents(final String sContents) {
		this.sContents = sContents;
	}
	/**
	 * @return the sAgreeAt
	 */
	public String getsAgreeAt() {
		return sAgreeAt;
	}
	/**
	 * @param sAgreeAt the sAgreeAt to set
	 */
	public void setsAgreeAt(String sAgreeAt) {
		this.sAgreeAt = sAgreeAt;
	}

	/**
	 * @return the sRegiDate
	 */
	public String getsRegiDate() {
		return sRegiDate;
	}

	/**
	 * @param sRegiDate the sRegiDate to set
	 */
	public void setsRegiDate(final String sRegiDate) {
		this.sRegiDate = sRegiDate;
	}

	/**
	 * @return the sModiName
	 */
	public String getsModiName() {
		return sModiName;
	}

	/**
	 * @param sModiName the sModiName to set
	 */
	public void setsModiName(final String sModiName) {
		this.sModiName = sModiName;
	}

	/**
	 * @return the sModiReason
	 */
	public String getsModiReason() {
		return sModiReason;
	}

	/**
	 * @param sModiReason the sModiReason to set
	 */
	public void setsModiReason(final String sModiReason) {
		this.sModiReason = sModiReason;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the searchType
	 */
	public String getSearchType() {
		return searchType;
	}

	/**
	 * @param searchType the searchType to set
	 */
	public void setSearchType(final String searchType) {
		this.searchType = searchType;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(final String searchValue) {
		this.searchValue = searchValue;
	}

}
