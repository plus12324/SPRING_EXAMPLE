/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ȫ���� - �μⱤ�� DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "adminPrintAdDTO")
public class PrintAdDTO extends PageDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ */
	private int nSeq;
	/** ���� */
	private String sTitle;
	/** ���� */
	private String sContent;
	/** �������� */
	private String sViewYn;
	/** ������¥ */
	private String sOpenDate;
	/** ������ */
	private String sRegId;
	/** ������¥ */
	private String sRegDate;
	/** �����ð� */
	private String sRegTime;
	/** ������ */
	private String sUpId;
	/** ������¥ */
	private String sUpDate;
	/** �����ð� */
	private String sUpTime;
	/** ���� ���� �̸� */
	private String sFileNm;
	/** ���� ��� */
	private String sFilePath;
	/** ���� ������ �̸� */
	private String sFileStrNm;
	/** ���� ���� ���*/
	private String sFileRealPath;
	
	/** �Ϸù�ȣ */
	@XmlTransient
	private String sSeq;
	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/
	@XmlTransient
	private String kind;
	/** �˻��� **/
	@XmlTransient
	private String searchValue;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	
	/**
	 * @return the nSeq
	 */
	public int getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final int nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}

	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(final String sContent) {
		this.sContent = sContent;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}

	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(final String sUpDate) {
		this.sUpDate = sUpDate;
	}

	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}

	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(final String sUpTime) {
		this.sUpTime = sUpTime;
	}

	/**
	 * @return the sFileNm
	 */
	public String getsFileNm() {
		return sFileNm;
	}

	/**
	 * @param sFileNm the sFileNm to set
	 */
	public void setsFileNm(final String sFileNm) {
		this.sFileNm = sFileNm;
	}

	/**
	 * @return the sFilePath
	 */
	public String getsFilePath() {
		return sFilePath;
	}

	/**
	 * @param sFilePath the sFilePath to set
	 */
	public void setsFilePath(final String sFilePath) {
		this.sFilePath = sFilePath;
	}

	/**
	 * @return the sFileStrNm
	 */
	public String getsFileStrNm() {
		return sFileStrNm;
	}

	/**
	 * @param sFileStrNm the sFileStrNm to set
	 */
	public void setsFileStrNm(final String sFileStrNm) {
		this.sFileStrNm = sFileStrNm;
	}

	/**
	 * @return the sFileRealPath
	 */
	public String getsFileRealPath() {
		return sFileRealPath;
	}

	/**
	 * @param sFileRealPath the sFileRealPath to set
	 */
	public void setsFileRealPath(final String sFileRealPath) {
		this.sFileRealPath = sFileRealPath;
	}

	/**
	 * @return the sSeq
	 */
	public String getsSeq() {
		return sSeq;
	}

	/**
	 * @param sSeq the sSeq to set
	 */
	public void setsSeq(String sSeq) {
		this.sSeq = sSeq;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}

	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}

	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}

	/**
	 * @return the editDiv
	 */
	public String getEditDiv() {
		return editDiv;
	}

	/**
	 * @param editDiv the editDiv to set
	 */
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}

	/**
	 * @return the mFile
	 */
	public MultipartFile getmFile() {
		return mFile;
	}

	/**
	 * @param mFile the mFile to set
	 */
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
}
