/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * SMS �뷮�߼� - ��� ����
 * @author ���ѳ�
 *
 */
public class AdminSmsSpendFileDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ���� **/
	private String nSeq;
	/** ���� **/
	private String sTitle;
	/** ����� **/
	private String sDate;
	/** ��Ͻð� **/
	private String sTime;
	/** ���Ϲ�ȣ **/
	private String nFileNum;
	/** ���ϸ� **/
	private String sFileName;
	/** ����ũ�� **/
	private String nFileSize;
	/** ���� **/
	private byte[] sContent;
	/** ������ ���� ���� **/
	private int[] nSeqs;
	/** ������ID **/
	private String sAdminID;
	/** ���, ���� ���� **/
	private String sEditDiv;
	/** **/
	private String sTableName;
	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}
	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the sTime
	 */
	public String getsTime() {
		return sTime;
	}
	/**
	 * @param sTime the sTime to set
	 */
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	/**
	 * @return the nFileNum
	 */
	public String getnFileNum() {
		return nFileNum;
	}
	/**
	 * @param nFileNum the nFileNum to set
	 */
	public void setnFileNum(String nFileNum) {
		this.nFileNum = nFileNum;
	}
	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}
	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(String sFileName) {
		this.sFileName = sFileName;
	}
	/**
	 * @return the nFileSize
	 */
	public String getnFileSize() {
		return nFileSize;
	}
	/**
	 * @param nFileSize the nFileSize to set
	 */
	public void setnFileSize(String nFileSize) {
		this.nFileSize = nFileSize;
	}
	/**
	 * @return the sContent
	 */
	public byte[] getsContent() {
		return sContent;
	}
	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(byte[] sContent) {
		this.sContent = sContent;
	}
	/**
	 * @return the nSeqs
	 */
	public int[] getnSeqs() {
		return nSeqs;
	}
	/**
	 * @param nSeqs the nSeqs to set
	 */
	public void setnSeqs(int[] nSeqs) {
		this.nSeqs = nSeqs;
	}
	/**
	 * @return the sAdminID
	 */
	public String getsAdminID() {
		return sAdminID;
	}
	/**
	 * @param sAdminID the sAdminID to set
	 */
	public void setsAdminID(String sAdminID) {
		this.sAdminID = sAdminID;
	}
	/**
	 * @return the sEditDiv
	 */
	public String getsEditDiv() {
		return sEditDiv;
	}
	/**
	 * @param sEditDiv the sEditDiv to set
	 */
	public void setsEditDiv(String sEditDiv) {
		this.sEditDiv = sEditDiv;
	}
	/**
	 * @return the sTableName
	 */
	public String getsTableName() {
		return sTableName;
	}
	/**
	 * @param sTableName the sTableName to set
	 */
	public void setsTableName(String sTableName) {
		this.sTableName = sTableName;
	}

	
}
