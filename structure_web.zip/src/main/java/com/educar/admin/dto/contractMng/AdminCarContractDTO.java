/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.contractMng;

import com.educar.common.dto.PageDTO;


/**
 * �ڵ������� ���α�
 * @author ���ѳ�
 * @since 1.1.0
 */
public class AdminCarContractDTO extends PageDTO{
	/** default **/
	private static final long serialVersionUID = 1L;
	/** 	����	 **/ 
	private String 	nSeqNo;
	/** 	ID	 **/ 
	private String 	ID;
	/** 	��౸��	 **/ 
	private String 	sPolicyType;
	/** 	�����	 **/ 
	private String 	sPolicyYM;
	/** 	����ȣ	 **/ 
	private String 	sPolicySer;
	/** 	�Ѻ����	 **/ 
	private String 	nTotPrem;
	/** 	����	 **/ 
	private String 	sStatus;
	/** 	��೯¥	 **/ 
	private String 	sDate;
	/** 	���ð�	 **/ 
	private String 	sTime;
	/** 	��õ���̸�	 **/ 
	private String 	sIntroName;
	/** 	��õ�μҼ�	 **/ 
	private String 	sIntroPost;
	/** 	����ä��	 **/ 
	private String 	sChannel;
	/** 	�ű�/��������	 **/ 
	private String 	sGb;
	/** 	�����ڵ�	 **/ 
	private String 	sInsType;
	/** 	��������	 **/ 
	private String 	sPayType;
	/** 	������ȣ	 **/ 
	private String 	sPlateNo;
	/** 	����	 **/ 
	private String 	sName;
	/** 	������ȣ	 **/ 
	private String 	sCustNo;
	
	/** �˻����� **/
	/** ����� �˻� �������� **/
	private String sFromDate;
	/** ����� �˻�  �������� **/
	private String sToDate;
	
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}
	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}
	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}
	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}
	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}
	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}
	/**
	 * @return the nTotPrem
	 */
	public String getnTotPrem() {
		return nTotPrem;
	}
	/**
	 * @param nTotPrem the nTotPrem to set
	 */
	public void setnTotPrem(String nTotPrem) {
		this.nTotPrem = nTotPrem;
	}
	/**
	 * @return the sStatus
	 */
	public String getsStatus() {
		return sStatus;
	}
	/**
	 * @param sStatus the sStatus to set
	 */
	public void setsStatus(String sStatus) {
		this.sStatus = sStatus;
	}
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the sTime
	 */
	public String getsTime() {
		return sTime;
	}
	/**
	 * @param sTime the sTime to set
	 */
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	/**
	 * @return the sIntroName
	 */
	public String getsIntroName() {
		return sIntroName;
	}
	/**
	 * @param sIntroName the sIntroName to set
	 */
	public void setsIntroName(String sIntroName) {
		this.sIntroName = sIntroName;
	}
	/**
	 * @return the sIntroPost
	 */
	public String getsIntroPost() {
		return sIntroPost;
	}
	/**
	 * @param sIntroPost the sIntroPost to set
	 */
	public void setsIntroPost(String sIntroPost) {
		this.sIntroPost = sIntroPost;
	}
	/**
	 * @return the sChannel
	 */
	public String getsChannel() {
		return sChannel;
	}
	/**
	 * @param sChannel the sChannel to set
	 */
	public void setsChannel(String sChannel) {
		this.sChannel = sChannel;
	}
	/**
	 * @return the sGb
	 */
	public String getsGb() {
		return sGb;
	}
	/**
	 * @param sGb the sGb to set
	 */
	public void setsGb(String sGb) {
		this.sGb = sGb;
	}
	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}
	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(String sInsType) {
		this.sInsType = sInsType;
	}
	/**
	 * @return the sPayType
	 */
	public String getsPayType() {
		return sPayType;
	}
	/**
	 * @param sPayType the sPayType to set
	 */
	public void setsPayType(String sPayType) {
		this.sPayType = sPayType;
	}
	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}
	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sFromDate
	 */
	public String getsFromDate() {
		return sFromDate;
	}
	/**
	 * @param sFromDate the sFromDate to set
	 */
	public void setsFromDate(String sFromDate) {
		this.sFromDate = sFromDate;
	}
	/**
	 * @return the sToDate
	 */
	public String getsToDate() {
		return sToDate;
	}
	/**
	 * @param sToDate the sToDate to set
	 */
	public void setsToDate(String sToDate) {
		this.sToDate = sToDate;
	}
	
	
	
}
