/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * SMS �뷮�߼� - SMS �뷮 �߼�
 * @author ���ѳ�
 *
 */
public class AdminSmsSendDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ���� **/	
	private String nSeq;
	/** ������ID**/	
	private String sAdminID;
	/** TRAN_CODE**/	
	private String nTranCode;
	/** �ֹε�Ϲ�ȣ**/	
	private String sCustNo;
	/** ��������ȭ��ȣ**/	
	private String sReceiverTel;
	/** �۽�����ȭ��ȣ**/	
	private String sSenderTel;
	/** �޽�������**/	
	private String sMessage;
	/** ������Ϲ�ȣ**/	
	private String nFileNum;
	/** ������**/	
	private String sReserveDate;
	/** ����ð�**/	
	private String sReserveTime;
	/** �ۼ���**/	
	private String sDate;
	/** �ۼ��ð�**/	
	private String sTime;
	/** ����Flag **/
	private String SEND_FLAG;
	/** url **/
	private String url;
	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sAdminID
	 */
	public String getsAdminID() {
		return sAdminID;
	}
	/**
	 * @param sAdminID the sAdminID to set
	 */
	public void setsAdminID(String sAdminID) {
		this.sAdminID = sAdminID;
	}
	/**
	 * @return the nTranCode
	 */
	public String getnTranCode() {
		return nTranCode;
	}
	/**
	 * @param nTranCode the nTranCode to set
	 */
	public void setnTranCode(String nTranCode) {
		this.nTranCode = nTranCode;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sReceiverTel
	 */
	public String getsReceiverTel() {
		return sReceiverTel;
	}
	/**
	 * @param sReceiverTel the sReceiverTel to set
	 */
	public void setsReceiverTel(String sReceiverTel) {
		this.sReceiverTel = sReceiverTel;
	}
	/**
	 * @return the sSenderTel
	 */
	public String getsSenderTel() {
		return sSenderTel;
	}
	/**
	 * @param sSenderTel the sSenderTel to set
	 */
	public void setsSenderTel(String sSenderTel) {
		this.sSenderTel = sSenderTel;
	}
	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}
	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(String sMessage) {
		this.sMessage = sMessage;
	}
	/**
	 * @return the nFileNum
	 */
	public String getnFileNum() {
		return nFileNum;
	}
	/**
	 * @param nFileNum the nFileNum to set
	 */
	public void setnFileNum(String nFileNum) {
		this.nFileNum = nFileNum;
	}
	/**
	 * @return the sReserveDate
	 */
	public String getsReserveDate() {
		return sReserveDate;
	}
	/**
	 * @param sReserveDate the sReserveDate to set
	 */
	public void setsReserveDate(String sReserveDate) {
		this.sReserveDate = sReserveDate;
	}
	/**
	 * @return the sReserveTime
	 */
	public String getsReserveTime() {
		return sReserveTime;
	}
	/**
	 * @param sReserveTime the sReserveTime to set
	 */
	public void setsReserveTime(String sReserveTime) {
		this.sReserveTime = sReserveTime;
	}
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the sTime
	 */
	public String getsTime() {
		return sTime;
	}
	/**
	 * @param sTime the sTime to set
	 */
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	/**
	 * @return the sEND_FLAG
	 */
	public String getSEND_FLAG() {
		return SEND_FLAG;
	}
	/**
	 * @param sEND_FLAG the sEND_FLAG to set
	 */
	public void setSEND_FLAG(String sEND_FLAG) {
		SEND_FLAG = sEND_FLAG;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	
	
	
}
