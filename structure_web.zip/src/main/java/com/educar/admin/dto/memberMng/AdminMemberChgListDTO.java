/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * �����ŷ�ȸ�� - �ּ�, ��ȭ��ȣ, �̸��� ���� ����
 * @author ���ѳ�
 *
 */
public class AdminMemberChgListDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ȸ�� ID **/
	private String ID;
	/** �α��� ID **/
	private String sLoginId;
	/** ������ȣ **/
	private String sCustNo;
	/** �̸� **/
	private String sName;
	/** �̸��� **/
	private String sEmail;
	/** �޴���1 **/
	private String sCellPhone1;
	/** �޴���2 **/
	private String sCellPhone2;
	/** �޴���3 **/
	private String sCellPhone3;
	/** �������� **/
	private String sCreDate;
	/** ���Խð� **/
	private String sCreTime;
	/** �������� ��ȸ�� ������ **/
	private String startDate;
	/** �������� ��ȸ�� ������ **/
	private String endDate;
	/** ������ȣ 1 **/
	private String sZip1;
	/** ������ȣ 2**/
	private String sZip2;
	/** �ּ�1 **/
	private String sADrs1;
	/** �ּ�2 **/
    private String sADrs2;
    /** �ּ�3 **/
    private String sADrs3;
    /** ������ �ּ� 1**/
    private String sAdrsAdd;
    /** ������ �ּ� 2**/
    private String sAdrsAdd2;
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the sLoginId
	 */
	public String getsLoginId() {
		return sLoginId;
	}
	/**
	 * @param sLoginId the sLoginId to set
	 */
	public void setsLoginId(String sLoginId) {
		this.sLoginId = sLoginId;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}
	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}
	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(String sCreDate) {
		this.sCreDate = sCreDate;
	}
	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}
	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}
	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}
	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}
	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}
	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}
	/**
	 * @return the sADrs1
	 */
	public String getsADrs1() {
		return sADrs1;
	}
	/**
	 * @param sADrs1 the sADrs1 to set
	 */
	public void setsADrs1(String sADrs1) {
		this.sADrs1 = sADrs1;
	}
	/**
	 * @return the sADrs2
	 */
	public String getsADrs2() {
		return sADrs2;
	}
	/**
	 * @param sADrs2 the sADrs2 to set
	 */
	public void setsADrs2(String sADrs2) {
		this.sADrs2 = sADrs2;
	}
	/**
	 * @return the sADrs3
	 */
	public String getsADrs3() {
		return sADrs3;
	}
	/**
	 * @param sADrs3 the sADrs3 to set
	 */
	public void setsADrs3(String sADrs3) {
		this.sADrs3 = sADrs3;
	}
	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}
	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}
	/**
	 * @return the sAdrsAdd2
	 */
	public String getsAdrsAdd2() {
		return sAdrsAdd2;
	}
	/**
	 * @param sAdrsAdd2 the sAdrsAdd2 to set
	 */
	public void setsAdrsAdd2(String sAdrsAdd2) {
		this.sAdrsAdd2 = sAdrsAdd2;
	}

	
}
