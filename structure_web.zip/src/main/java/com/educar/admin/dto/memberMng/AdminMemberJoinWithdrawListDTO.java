/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * ���ں� ȸ������/Ż����Ȳ
 * @author ���ѳ�
 *
 */
public class AdminMemberJoinWithdrawListDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ��¥ **/
	private String sDate;
	/** �����ڼ� **/
	private String joinCnt;
	/** Ż��ȸ���� **/
	private String secedeCnt;
	/** ��ü **/
	private String totalCnt;
	/** �˻�����(c1 �Ϻ�, c2 ����) **/
	private String sDiv;
	/** �˻� ������ **/
	private String sStartDate;
	/** �˻� ������ **/
	private String sEndDate;
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the joinCnt
	 */
	public String getJoinCnt() {
		return joinCnt;
	}
	/**
	 * @param joinCnt the joinCnt to set
	 */
	public void setJoinCnt(String joinCnt) {
		this.joinCnt = joinCnt;
	}
	/**
	 * @return the secedeCnt
	 */
	public String getSecedeCnt() {
		return secedeCnt;
	}
	/**
	 * @param secedeCnt the secedeCnt to set
	 */
	public void setSecedeCnt(String secedeCnt) {
		this.secedeCnt = secedeCnt;
	}
	/**
	 * @return the totalCnt
	 */
	public String getTotalCnt() {
		return totalCnt;
	}
	/**
	 * @param totalCnt the totalCnt to set
	 */
	public void setTotalCnt(String totalCnt) {
		this.totalCnt = totalCnt;
	}
	/**
	 * @return the sDiv
	 */
	public String getsDiv() {
		return sDiv;
	}
	/**
	 * @param sDiv the sDiv to set
	 */
	public void setsDiv(String sDiv) {
		this.sDiv = sDiv;
	}
	/**
	 * @return the sStartDate
	 */
	public String getsStartDate() {
		return sStartDate;
	}
	/**
	 * @param sStartDate the sStartDate to set
	 */
	public void setsStartDate(String sStartDate) {
		this.sStartDate = sStartDate;
	}
	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}
	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(String sEndDate) {
		this.sEndDate = sEndDate;
	}
	
	
}
