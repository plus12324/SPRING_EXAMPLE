/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.springframework.web.multipart.MultipartFile;

import com.educar.common.annotation.BeanUtil;
import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ȫ���� - TV���� DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "adminTvAdDTO")
public class AdminEventDTO extends PageDTO{
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	
	/**	sEventDiv	**/ 
	private String sEventDiv;
	/**	sPreEventDiv	**/ 
	private String sPreEventDiv;
	/**	sInputDateFrom	**/ 
	private String sInputDateFrom;
	/**	sInputDateTo	**/ 
	private String sInputDateTo;
	/**	nCnt	**/ 
	private String nCnt;
	/**	sEventName	**/ 
	private String sEventName;	
	/**	�̺�Ʈ��÷Ÿ��Ʋ�̹���1 **/ 
	private MultipartFile sTitleImg1;	
	/**	�̺�Ʈ��÷Ÿ��Ʋ�̹���2 **/
	private MultipartFile sTitleImg2;
	/**	sEventID **/ 
	private String sEventID;	
	/**	nGrade	**/ 
	private int[] nGrade;
	/**	nGrade2	**/ 
	private int[] nGrade2;
	/**	nGradeTotal	**/ 
	private int[] nGradeTotal;
	/**	sGradeTitleImg	**/
	private MultipartFile[] sGradeTitleImg;
	
	//�̺�Ʈ��÷���� ����Ʈ
	private String sLongName;
	
	//�̺�Ʈ ��÷�� ����Ʈ
	private String rtnUri;
	private String nGradeDisplays;
	private String sEventLotteryDiv;
	private String sFmdt;
	private String sTodt;
	private String nGradeValue;
	private String nGradeInputValue;
	private String nGradeTotalValue;
	private String nGradeDisplayValue;
	private String sTitleImg2Value;
	
	//�̺�Ʈ �Խ�
	private MultipartFile sBannerImg;
	private MultipartFile sHTML;
	private String sEventTitle;
	private String sPresent;
	private String sTargetPeople;
	
	//�� ��÷�� ��ǥ ���
	private String sEventComment;
	private String sDateComment;
	private String sPresentComment;
	
	//���������̷½��ι�ȣ
	private String sAprvCd;
	
	/** ��÷ ��ǰ1(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE01;
	/** ��÷ ��ǰ2(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE02;
	/** ��÷ ��ǰ3(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE03;
	/** ��÷ ��ǰ4(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE04;
	/** ��÷ ��ǰ5(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE05;
	
	public String getPRIZE01() {
		return PRIZE01;
	}
	public void setPRIZE01(String pRIZE01) {
		PRIZE01 = pRIZE01;
	}
	public String getPRIZE02() {
		return PRIZE02;
	}
	public void setPRIZE02(String pRIZE02) {
		PRIZE02 = pRIZE02;
	}
	public String getPRIZE03() {
		return PRIZE03;
	}
	public void setPRIZE03(String pRIZE03) {
		PRIZE03 = pRIZE03;
	}
	public String getPRIZE04() {
		return PRIZE04;
	}
	public void setPRIZE04(String pRIZE04) {
		PRIZE04 = pRIZE04;
	}
	public String getPRIZE05() {
		return PRIZE05;
	}
	public void setPRIZE05(String pRIZE05) {
		PRIZE05 = pRIZE05;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getsAprvCd() {
		return sAprvCd;
	}
	public void setsAprvCd(String sAprvCd) {
		this.sAprvCd = sAprvCd;
	}
	public String getsEventComment() {
		return sEventComment;
	}
	public void setsEventComment(String sEventComment) {
		this.sEventComment = sEventComment;
	}
	public String getsDateComment() {
		return sDateComment;
	}
	public void setsDateComment(String sDateComment) {
		this.sDateComment = sDateComment;
	}
	public String getsPresentComment() {
		return sPresentComment;
	}
	public void setsPresentComment(String sPresentComment) {
		this.sPresentComment = sPresentComment;
	}
	public MultipartFile getsBannerImg() {
		return sBannerImg;
	}
	public void setsBannerImg(MultipartFile sBannerImg) {
		this.sBannerImg = sBannerImg;
	}
	public MultipartFile getsHTML() {
		return sHTML;
	}
	public void setsHTML(MultipartFile sHTML) {
		this.sHTML = sHTML;
	}
	public String getsEventTitle() {
		return sEventTitle;
	}
	public void setsEventTitle(String sEventTitle) {
		this.sEventTitle = sEventTitle;
	}
	public String getsPresent() {
		return sPresent;
	}
	public void setsPresent(String sPresent) {
		this.sPresent = sPresent;
	}
	public String getsTargetPeople() {
		return sTargetPeople;
	}
	public void setsTargetPeople(String sTargetPeople) {
		this.sTargetPeople = sTargetPeople;
	}
	public String getsTitleImg2Value() {
		return sTitleImg2Value;
	}
	public void setsTitleImg2Value(String sTitleImg2Value) {
		this.sTitleImg2Value = sTitleImg2Value;
	}
	public String getnGradeInputValue() {
		return nGradeInputValue;
	}
	public void setnGradeInputValue(String nGradeInputValue) {
		this.nGradeInputValue = nGradeInputValue;
	}
	public String getnGradeTotalValue() {
		return nGradeTotalValue;
	}
	public void setnGradeTotalValue(String nGradeTotalValue) {
		this.nGradeTotalValue = nGradeTotalValue;
	}
	public String getnGradeDisplayValue() {
		return nGradeDisplayValue;
	}
	public void setnGradeDisplayValue(String nGradeDisplayValue) {
		this.nGradeDisplayValue = nGradeDisplayValue;
	}
	public String getnGradeValue() {
		return nGradeValue;
	}
	public void setnGradeValue(String nGradeValue) {
		this.nGradeValue = nGradeValue;
	}
	public String getRtnUri() {
		return rtnUri;
	}
	public void setRtnUri(String rtnUri) {
		this.rtnUri = rtnUri;
	}
	public String getnGradeDisplays() {
		return nGradeDisplays;
	}
	public void setnGradeDisplays(String nGradeDisplays) {
		this.nGradeDisplays = nGradeDisplays;
	}
	public String getsEventLotteryDiv() {
		return sEventLotteryDiv;
	}
	public void setsEventLotteryDiv(String sEventLotteryDiv) {
		this.sEventLotteryDiv = sEventLotteryDiv;
	}
	public String getsFmdt() {
		return sFmdt;
	}
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	public String getsTodt() {
		return sTodt;
	}
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	public String getsLongName() {
		return sLongName;
	}
	public void setsLongName(String sLongName) {
		this.sLongName = sLongName;
	}
	public MultipartFile[] getsGradeTitleImg() {
		return sGradeTitleImg;
	}
	public void setsGradeTitleImg(MultipartFile[] sGradeTitleImg) {
		this.sGradeTitleImg = sGradeTitleImg;
	}
	public int[] getnGrade2() {
		return nGrade2;
	}
	public void setnGrade2(int[] nGrade2) {
		this.nGrade2 = nGrade2;
	}
	public int[] getnGradeTotal() {
		return nGradeTotal;
	}
	public void setnGradeTotal(int[] nGradeTotal) {
		this.nGradeTotal = nGradeTotal;
	}
	public MultipartFile getsTitleImg1() {
		return sTitleImg1;
	}
	public void setsTitleImg1(MultipartFile sTitleImg1) {
		this.sTitleImg1 = sTitleImg1;
	}
	public MultipartFile getsTitleImg2() {
		return sTitleImg2;
	}
	public void setsTitleImg2(MultipartFile sTitleImg2) {
		this.sTitleImg2 = sTitleImg2;
	}
	public String getsEventID() {
		return sEventID;
	}
	public void setsEventID(String sEventID) {
		this.sEventID = sEventID;
	}
	public String getsEventName() {
		return sEventName;
	}
	public void setsEventName(String sEventName) {
		this.sEventName = sEventName;
	}
	public String getsEventDiv() {
		return sEventDiv;
	}
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	public String getsPreEventDiv() {
		return sPreEventDiv;
	}
	public void setsPreEventDiv(String sPreEventDiv) {
		this.sPreEventDiv = sPreEventDiv;
	}
	public String getsInputDateFrom() {
		return sInputDateFrom;
	}
	public void setsInputDateFrom(String sInputDateFrom) {
		this.sInputDateFrom = sInputDateFrom;
	}
	public String getsInputDateTo() {
		return sInputDateTo;
	}
	public void setsInputDateTo(String sInputDateTo) {
		this.sInputDateTo = sInputDateTo;
	}
	public String getnCnt() {
		return nCnt;
	}
	public void setnCnt(String nCnt) {
		this.nCnt = nCnt;
	}
	public int[] getnGrade() {
		return nGrade;
	}
	public void setnGrade(int[] nGrade) {
		this.nGrade = nGrade;
	}	
}
