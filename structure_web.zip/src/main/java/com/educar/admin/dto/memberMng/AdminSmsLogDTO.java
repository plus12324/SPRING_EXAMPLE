/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;

/**
 * SMS �뷮�߼� - �߼۷α�
 * @author ���ѳ�
 *
 */
public class AdminSmsLogDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** ������ID **/
	private String sAdminID;
	/** ������ȣ **/
	private String sCustNo;
	/** ��ȭ��ȣ **/
	private String sReceiverTel;
	/** ���� **/
	private String sTitle;
	/** ���� **/
	private String sMessage;
	/** ����� **/
	private String sDate;
	/** ��Ͻð� **/
	private String sTime;
	/** ���� **/
	private String nSeq;
	/** ��ȸ���� **/
	private String gubun;
	/** �˻��� **/
	private String keyword;
	
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	
	/**
	 * @return the sAdminID
	 */
	public String getsAdminID() {
		return sAdminID;
	}

	/**
	 * @param sAdminID the sAdminID to set
	 */
	public void setsAdminID(String sAdminID) {
		this.sAdminID = sAdminID;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sReceiverTel
	 */
	public String getsReceiverTel() {
		return sReceiverTel;
	}

	/**
	 * @param sReceiverTel the sReceiverTel to set
	 */
	public void setsReceiverTel(String sReceiverTel) {
		this.sReceiverTel = sReceiverTel;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}

	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(String sMessage) {
		this.sMessage = sMessage;
	}

	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}

	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}

	/**
	 * @return the sTime
	 */
	public String getsTime() {
		return sTime;
	}

	/**
	 * @param sTime the sTime to set
	 */
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	
	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the gubun
	 */
	public String getGubun() {
		return gubun;
	}

	/**
	 * @param gubun the gubun to set
	 */
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}

	/**
	 * @return the keyword
	 */
	public String getKeyword() {
		return keyword;
	}

	/**
	 * @param keyword the keyword to set
	 */
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	
	
}
