/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * ������ - �濵���� - ��������ǥ
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "adminBalancesheetDTO")
public class AdminBalancesheetDTO extends PageDTO{
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** 	��ϼ���	 **/ 
	private String 	nSeq;
	/** 	�⵵	 **/ 
	private String 	sYear;
	/** 	����	 **/ 
	private String 	sTitle;
	/** 	��������	 **/ 
	private String 	sViewYn;
	/** 	����ξ��̵�	 **/ 
	private String 	sCreateId;
	/**		����ڸ� 	**/
	private String sCreateNm;
	/** 	�����ξ��̵�	 **/ 
	private String 	sUpdateId;
	/** 	�������	 **/ 
	private String 	sCreateDate;
	/** 	��Ͻð�	 **/ 
	private String 	sCreateTime;
	/** 	��������	 **/ 
	private String 	sUpdateDate;
	/** 	�����ð�	 **/ 
	private String 	sUpdateTime;
	/** 	���ϸ�	 **/ 
	private String 	sFileNm;
	/** 	���ϰ��	 **/ 
	private String 	sFilePath;
	/** 	��ȯ���ϸ�	 **/ 
	private String 	sFileStrNm;
	/** 	�������ϰ��	 **/ 
	private String 	sFileRealPath;
	
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	
	public String getnSeq() {
		return nSeq;
	}
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	public String getsYear() {
		return sYear;
	}
	public void setsYear(String sYear) {
		this.sYear = sYear;
	}
	public String getsTitle() {
		return sTitle;
	}
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	public String getsViewYn() {
		return sViewYn;
	}
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}
	public String getsCreateId() {
		return sCreateId;
	}
	public void setsCreateId(String sCreateId) {
		this.sCreateId = sCreateId;
	}
	public String getsCreateNm() {
		return sCreateNm;
	}
	public void setsCreateNm(String sCreateNm) {
		this.sCreateNm = sCreateNm;
	}
	public String getsUpdateId() {
		return sUpdateId;
	}
	public void setsUpdateId(String sUpdateId) {
		this.sUpdateId = sUpdateId;
	}
	public String getsCreateDate() {
		return sCreateDate;
	}
	public void setsCreateDate(String sCreateDate) {
		this.sCreateDate = sCreateDate;
	}
	public String getsCreateTime() {
		return sCreateTime;
	}
	public void setsCreateTime(String sCreateTime) {
		this.sCreateTime = sCreateTime;
	}
	public String getsUpdateDate() {
		return sUpdateDate;
	}
	public void setsUpdateDate(String sUpdateDate) {
		this.sUpdateDate = sUpdateDate;
	}
	public String getsUpdateTime() {
		return sUpdateTime;
	}
	public void setsUpdateTime(String sUpdateTime) {
		this.sUpdateTime = sUpdateTime;
	}
	public String getsFileNm() {
		return sFileNm;
	}
	public void setsFileNm(String sFileNm) {
		this.sFileNm = sFileNm;
	}
	public String getsFilePath() {
		return sFilePath;
	}
	public void setsFilePath(String sFilePath) {
		this.sFilePath = sFilePath;
	}
	public String getsFileStrNm() {
		return sFileStrNm;
	}
	public void setsFileStrNm(String sFileStrNm) {
		this.sFileStrNm = sFileStrNm;
	}
	public String getsFileRealPath() {
		return sFileRealPath;
	}
	public void setsFileRealPath(String sFileRealPath) {
		this.sFileRealPath = sFileRealPath;
	}
	public String getStartOpenDate() {
		return startOpenDate;
	}
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	public String getEndOpenDate() {
		return endOpenDate;
	}
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	public String getEditDiv() {
		return editDiv;
	}
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}
	public MultipartFile getmFile() {
		return mFile;
	}
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
	
	
}
