/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * ���� ���Ϲ߼� Ȯ�� 
 * @author ���ѳ�
 *
 */
public class NVSendMailHistoryDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** 	����	 **/ 
	private String 	SERIAL;
	/** 	����	 **/ 
	private String 	SUBJECT;
	/** 	�޴� ��� �̺���	 **/ 
	private String 	TO_EMAIL;
	/** 	���� ��¥	 **/ 
	private String 	INPT_DATE;
	/** 	���� �ð�	 **/ 
	private String 	INPT_TIME;
	/** 	����	 **/ 
	private String 	TO_NAME;
	/** 	����	 **/ 
	private String 	BODY_HTML;
	
	/** ��ȸ����(�����ڿ��� ���) **/
	/**		������ **/
	private String startDate;
	/**		������ **/
	private String endDate;
	/**		��ȸ���� **/
	private String gubun;
	/**		�˻��� **/
	private String keyword;
	/** 	������ȣ **/
	private String sCustNo;
	/**
	 * @return the sERIAL
	 */
	public String getSERIAL() {
		return SERIAL;
	}
	/**
	 * @param sERIAL the sERIAL to set
	 */
	public void setSERIAL(String sERIAL) {
		SERIAL = sERIAL;
	}
	/**
	 * @return the sUBJECT
	 */
	public String getSUBJECT() {
		return SUBJECT;
	}
	/**
	 * @param sUBJECT the sUBJECT to set
	 */
	public void setSUBJECT(String sUBJECT) {
		SUBJECT = sUBJECT;
	}
	/**
	 * @return the tO_EMAIL
	 */
	public String getTO_EMAIL() {
		return TO_EMAIL;
	}
	/**
	 * @param tO_EMAIL the tO_EMAIL to set
	 */
	public void setTO_EMAIL(String tO_EMAIL) {
		TO_EMAIL = tO_EMAIL;
	}
	/**
	 * @return the iNPT_DATE
	 */
	public String getINPT_DATE() {
		return INPT_DATE;
	}
	/**
	 * @param iNPT_DATE the iNPT_DATE to set
	 */
	public void setINPT_DATE(String iNPT_DATE) {
		INPT_DATE = iNPT_DATE;
	}
	/**
	 * @return the iNPT_TIME
	 */
	public String getINPT_TIME() {
		return INPT_TIME;
	}
	/**
	 * @param iNPT_TIME the iNPT_TIME to set
	 */
	public void setINPT_TIME(String iNPT_TIME) {
		INPT_TIME = iNPT_TIME;
	}
	/**
	 * @return the tO_NAME
	 */
	public String getTO_NAME() {
		return TO_NAME;
	}
	/**
	 * @param tO_NAME the tO_NAME to set
	 */
	public void setTO_NAME(String tO_NAME) {
		TO_NAME = tO_NAME;
	}
	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the gubun
	 */
	public String getGubun() {
		return gubun;
	}
	/**
	 * @param gubun the gubun to set
	 */
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	/**
	 * @return the keyword
	 */
	public String getKeyword() {
		return keyword;
	}
	/**
	 * @param keyword the keyword to set
	 */
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the bODY_HTML
	 */
	public String getBODY_HTML() {
		return BODY_HTML;
	}
	/**
	 * @param bODY_HTML the bODY_HTML to set
	 */
	public void setBODY_HTML(String bODY_HTML) {
		BODY_HTML = bODY_HTML;
	}
	
}
