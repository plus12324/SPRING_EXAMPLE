/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.memberMng;

import com.educar.common.dto.PageDTO;

/**
 * �� ȸ�� Ż��α� 
 * @author ���ѳ�
 *
 */
public class EWEBLR002DTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;
	/** 	����	 **/ 
	private String 	ID;
	/** 	�ֹι�ȣ	 **/ 
	private String 	sCustNo;
	/** 	Ż������	 **/ 
	private String 	sDate;
	/** 	Ż��ð�	 **/ 
	private String 	sTime;
	/** 	Ż�����	 **/ 
	private String 	sReason;
	/** 	����	 **/ 
	private String 	sName;
	
	/** ��ȸ����(�����ڿ��� ���) **/
	/**		������ **/
	private String startDate;
	/**		������ **/
	private String endDate;
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the sTime
	 */
	public String getsTime() {
		return sTime;
	}
	/**
	 * @param sTime the sTime to set
	 */
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	/**
	 * @return the sReason
	 */
	public String getsReason() {
		return sReason;
	}
	/**
	 * @param sReason the sReason to set
	 */
	public void setsReason(String sReason) {
		this.sReason = sReason;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	
}
