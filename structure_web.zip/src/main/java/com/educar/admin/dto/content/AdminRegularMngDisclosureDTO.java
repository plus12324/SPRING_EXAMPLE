/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

import kr.co.conch.validator.annotation.bytes.CharacterSet;
import kr.co.conch.validator.annotation.bytes.ValidateByte;

/**
 * ������ - �濵���� - ����濵���� 
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "managementDisclosureDTO")
public class AdminRegularMngDisclosureDTO extends PageDTO{
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** ���� **/
	private String nSeq;
	/** �⵵ **/
	@ValidateByte(max = 4, charset = CharacterSet.EUCKR)
	private String sYear;
	/** �б� **/
	@ValidateByte(max = 4, charset = CharacterSet.EUCKR)
	private String sQuarter;
	/** ���� **/
	@ValidateByte(max = 100, charset = CharacterSet.EUCKR)
	private String sTitle;
	/** �����̸� **/
	@ValidateByte(max = 200, charset = CharacterSet.EUCKR)
	private String sFileName;
	/** ���ϰ�� **/
	@ValidateByte(max = 10, charset = CharacterSet.EUCKR)
	private String sFileTypeURI;
	/** �������� **/
	private String sViewYn;
	/** ����� **/
	private String sCreId;
	/** ����ڸ� **/
	private String sUserNm;
	/** �������**/
	private String sCreDt;
	
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	
	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the sQuarter
	 */
	public String getsQuarter() {
		return sQuarter;
	}

	/**
	 * @param sQuarter the sQuarter to set
	 */
	public void setsQuarter(String sQuarter) {
		this.sQuarter = sQuarter;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}

	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(String sFileName) {
		this.sFileName = sFileName;
	}

	/**
	 * @return the sFileTypeURI
	 */
	public String getsFileTypeURI() {
		return sFileTypeURI;
	}

	/**
	 * @param sFileTypeURI the sFileTypeURI to set
	 */
	public void setsFileTypeURI(String sFileTypeURI) {
		this.sFileTypeURI = sFileTypeURI;
	}

	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sCreId
	 */
	public String getsCreId() {
		return sCreId;
	}

	/**
	 * @param sCreId the sCreId to set
	 */
	public void setsCreId(String sCreId) {
		this.sCreId = sCreId;
	}
	
	/**
	 * @return the sUserNm
	 */
	public String getsUserNm() {
		return sUserNm;
	}

	/**
	 * @param sUserNm the sUserNm to set
	 */
	public void setsUserNm(String sUserNm) {
		this.sUserNm = sUserNm;
	}

	/**
	 * @return the sCreDt
	 */
	public String getsCreDt() {
		return sCreDt;
	}

	/**
	 * @param sCreDt the sCreDt to set
	 */
	public void setsCreDt(String sCreDt) {
		this.sCreDt = sCreDt;
	}

	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}

	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}

	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}

	/**
	 * @return the editDiv
	 */
	public String getEditDiv() {
		return editDiv;
	}

	/**
	 * @param editDiv the editDiv to set
	 */
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}

	/**
	 * @return the mFile
	 */
	public MultipartFile getmFile() {
		return mFile;
	}

	/**
	 * @param mFile the mFile to set
	 */
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
	
}
