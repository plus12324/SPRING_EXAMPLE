package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ģ����õ�̺�Ʈ ��� DTO
 * <pre>
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "recommendFriendResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class RecommendFriendResultDTO {
	
	/** ����Ű**/
	private String sRecommendUrl;
	/** ��õ��	**/
	private String sRecommenderName;
	/**	��õ����ȭ��ȣ1 **/
	private String sRecommenderPhone;
	/** ����õ��	**/
	private String sJoinerName;
	/** ����õ����ȭ��ȣ1	**/
	private String sJoinerPhone;
	/** ��õ����	**/
	private String sCreDate;
	/** ��õ�ð�	**/
	private String sCreTime;
	
	public String getsRecommenderPhone() {
		return sRecommenderPhone;
	}
	public void setsRecommenderPhone(String sRecommenderPhone) {
		this.sRecommenderPhone = sRecommenderPhone;
	}
	public String getsJoinerPhone() {
		return sJoinerPhone;
	}
	public void setsJoinerPhone(String sJoinerPhone) {
		this.sJoinerPhone = sJoinerPhone;
	}
	public String getsRecommendUrl() {
		return sRecommendUrl;
	}
	public void setsRecommendUrl(String sRecommendUrl) {
		this.sRecommendUrl = sRecommendUrl;
	}
	public String getsRecommenderName() {
		return sRecommenderName;
	}
	public void setsRecommenderName(String sRecommenderName) {
		this.sRecommenderName = sRecommenderName;
	}
	public String getsJoinerName() {
		return sJoinerName;
	}
	public void setsJoinerName(String sJoinerName) {
		this.sJoinerName = sJoinerName;
	}
	public String getsCreDate() {
		return sCreDate;
	}
	public void setsCreDate(String sCreDate) {
		this.sCreDate = sCreDate;
	}
	public String getsCreTime() {
		return sCreTime;
	}
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}

}
