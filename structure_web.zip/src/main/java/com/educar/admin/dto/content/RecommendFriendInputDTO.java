package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ģ����õ�̺�Ʈ Input DTO
 * <pre>
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "recommendFriendInputDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class RecommendFriendInputDTO {
	
	/** �̺�Ʈ�Ⱓ(FROM)**/
	private String sFromDate;
	/** �̺�Ʈ�Ⱓ(TO)	**/
	private String sToDate;
	
	public String getsFromDate() {
		return sFromDate;
	}
	public void setsFromDate(String sFromDate) {
		this.sFromDate = sFromDate;
	}
	public String getsToDate() {
		return sToDate;
	}
	public void setsToDate(String sToDate) {
		this.sToDate = sToDate;
	}
}
