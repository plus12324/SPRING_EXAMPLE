/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.content;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * ������ - ��������
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "AdminBiddingDTO")
public class AdminBiddingDTO extends PageDTO{
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/**	�Ϸù�ȣ	**/ 
	private String 	nSeq;
	/**	����	**/ 
	private String 	sTitle;
	/**	����	**/ 
	private String 	sContent;
	/**	��������	**/ 
	private String 	sViewYn;
	/**	������¥	**/ 
	private String 	sOpenDate;
	/**	��ȸ��	**/ 
	private String 	nVisitCnt;
	/**	������	**/ 
	private String 	sRegId;
	private String  sRegNm;
	/**	������¥	**/ 
	private String 	sRegDate;
	/**	�����ð�	**/ 
	private String 	sRegTime;
	/**	������	**/ 
	private String 	sUpId;
	/**	������¥	**/ 
	private String 	sUpDate;
	/**	�����ð�	**/ 
	private String 	sUpTime;
	/**	���� ���� �̸�	**/ 
	private String 	sFileNm;
	/**	���� ���	**/ 
	private String 	sFilePath;
	/**	���� ������ �̸�	**/ 
	private String 	sFileStrNm;
	
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** Edit ���� **/
	@XmlTransient
	private String editDiv;
	/** ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile mFile;
	
	public String getnSeq() {
		return nSeq;
	}
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	public String getsTitle() {
		return sTitle;
	}
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	public String getsContent() {
		return sContent;
	}
	public void setsContent(String sContent) {
		this.sContent = sContent;
	}
	public String getsViewYn() {
		return sViewYn;
	}
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}
	public String getsOpenDate() {
		return sOpenDate;
	}
	public void setsOpenDate(String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}
	public String getnVisitCnt() {
		return nVisitCnt;
	}
	public void setnVisitCnt(String nVisitCnt) {
		this.nVisitCnt = nVisitCnt;
	}
	public String getsRegId() {
		return sRegId;
	}
	public void setsRegId(String sRegId) {
		this.sRegId = sRegId;
	}
	public String getsRegNm() {
		return sRegNm;
	}
	public void setsRegNm(String sRegNm) {
		this.sRegNm = sRegNm;
	}
	public String getsRegDate() {
		return sRegDate;
	}
	public void setsRegDate(String sRegDate) {
		this.sRegDate = sRegDate;
	}
	public String getsRegTime() {
		return sRegTime;
	}
	public void setsRegTime(String sRegTime) {
		this.sRegTime = sRegTime;
	}
	public String getsUpId() {
		return sUpId;
	}
	public void setsUpId(String sUpId) {
		this.sUpId = sUpId;
	}
	public String getsUpDate() {
		return sUpDate;
	}
	public void setsUpDate(String sUpDate) {
		this.sUpDate = sUpDate;
	}
	public String getsUpTime() {
		return sUpTime;
	}
	public void setsUpTime(String sUpTime) {
		this.sUpTime = sUpTime;
	}
	public String getsFileNm() {
		return sFileNm;
	}
	public void setsFileNm(String sFileNm) {
		this.sFileNm = sFileNm;
	}
	public String getsFilePath() {
		return sFilePath;
	}
	public void setsFilePath(String sFilePath) {
		this.sFilePath = sFilePath;
	}
	public String getsFileStrNm() {
		return sFileStrNm;
	}
	public void setsFileStrNm(String sFileStrNm) {
		this.sFileStrNm = sFileStrNm;
	}
	public String getStartOpenDate() {
		return startOpenDate;
	}
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	public String getEndOpenDate() {
		return endOpenDate;
	}
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	public String getEditDiv() {
		return editDiv;
	}
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}
	public MultipartFile getmFile() {
		return mFile;
	}
	public void setmFile(MultipartFile mFile) {
		this.mFile = mFile;
	}
	
}
