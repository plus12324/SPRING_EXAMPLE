/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.statsMng;

import com.educar.common.dto.PageDTO;


/**
 * ���ȭ�� �ٿ�ε� ��Ȳ
 * @author ���ѳ�
 * @since 1.1.0
 */
public class AdminBackImgHitDTO extends PageDTO{
	/** default **/
	private static final long serialVersionUID = 1L;
	/** 	��¥	**/ 
	private String 	sDate;
	/** 	������	**/ 
	private String 	nSeqNo;
	/** 	�����ڵ�	**/ 
	private String 	sCode;
	/** 	���ϸ�	**/ 
	private String 	sFileName;
	/** 	���ϰ��	**/ 
	private String 	sPath;
	/** 	��ȸ��	**/ 
	private String 	nHit;
	
	/** 	�˻����� : �⵵	**/ 
	private String 	sYearMonth;
	
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the sCode
	 */
	public String getsCode() {
		return sCode;
	}
	/**
	 * @param sCode the sCode to set
	 */
	public void setsCode(String sCode) {
		this.sCode = sCode;
	}
	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}
	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(String sFileName) {
		this.sFileName = sFileName;
	}
	/**
	 * @return the sPath
	 */
	public String getsPath() {
		return sPath;
	}
	/**
	 * @param sPath the sPath to set
	 */
	public void setsPath(String sPath) {
		this.sPath = sPath;
	}
	/**
	 * @return the nHit
	 */
	public String getnHit() {
		return nHit;
	}
	/**
	 * @param nHit the nHit to set
	 */
	public void setnHit(String nHit) {
		this.nHit = nHit;
	}
	/**
	 * @return the sYearMonth
	 */
	public String getsYearMonth() {
		return sYearMonth;
	}
	/**
	 * @param sYearMonth the sYearMonth to set
	 */
	public void setsYearMonth(String sYearMonth) {
		this.sYearMonth = sYearMonth;
	}
}
