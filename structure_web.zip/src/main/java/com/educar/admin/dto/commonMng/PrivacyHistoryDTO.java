/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.commonMng;

import com.educar.common.dto.PageDTO;

/**
 * ��� �̷� DTO
 * @author ������
 * @since 1.0.0
 */
public class PrivacyHistoryDTO extends PageDTO {
	/** default */
	private static final long serialVersionUID = 1L;

	/** �Ϸù�ȣ **/
	private Long nSeq;
	/** ���ID **/
	private Long nPolicyID;
	/** ��� Ÿ��Ʋ **/
	private String sTitle;
	/** ������� **/
	private String sContents;
	/** �Խ��� **/
	private String sOpenDate;
	/** ������ **/
	private String sModiName;
	/** �������� **/
	private String sModiReason;
	/** ������ **/
	private String sModiDate;

	/**
	 * @return the nSeq
	 */
	public Long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the nPolicyID
	 */
	public Long getnPolicyID() {
		return nPolicyID;
	}

	/**
	 * @param nPolicyID the nPolicyID to set
	 */
	public void setnPolicyID(final Long nPolicyID) {
		this.nPolicyID = nPolicyID;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContents
	 */
	public String getsContents() {
		return sContents;
	}

	/**
	 * @param sContents the sContents to set
	 */
	public void setsContents(final String sContents) {
		this.sContents = sContents;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sModiName
	 */
	public String getsModiName() {
		return sModiName;
	}

	/**
	 * @param sModiName the sModiName to set
	 */
	public void setsModiName(final String sModiName) {
		this.sModiName = sModiName;
	}

	/**
	 * @return the sModiReason
	 */
	public String getsModiReason() {
		return sModiReason;
	}

	/**
	 * @param sModiReason the sModiReason to set
	 */
	public void setsModiReason(final String sModiReason) {
		this.sModiReason = sModiReason;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

}
