/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dto.statsMng;

import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;


/**
 * ���ȭ�� �ٿ�ε� ��Ȳ
 * @author ���ѳ�
 * @since 1.1.0
 */
public class AdminSearchAdDTO extends PageDTO{
	/** default **/
	private static final long serialVersionUID = 1L;
	/**��¥ **/
	private String sDate;
	/**�����߾� **/
	private String nOvertureCPC;
	/**���̹�CPC **/
	private String nNaverCPC;
	/**���̹�CPT **/
	private String nNaverCPT;
	/**����CPC **/
	private String nDaumCPC;
	/**����ƮCPM **/
	private String nNateCPM;
	/**����CPC **/
	private String nGoogleCPC;
	/**���̹������ **/
	private String nNaverMobile;
	/**���۸���� **/
	private String nGoogleMobile;
	/**��������� **/
	private String nDaumMobile;
	/**���̹��귣�� **/
	private String nNaverBrand;
	/**�����귣�� **/
	private String nDaumBrand;
	/**�׿�Ŭ�� **/
	private String nNeoClick;
	/**��GDN **/
	private String nGDN;
	/**�ֵ�� **/
	private String nAdMob;
	/**�θ�� **/
	private String nInMobi;		
	/**�Ϻ��հ� **/
	private String nDaySum;	
	/** �˻����� **/
	@XmlTransient
	private String kind;
	/** �Ϻ��˻� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Ϻ��˻� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** �����˻� ���ۿ� (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenMonth;
	/** �����˻� ����� (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenMonth;
	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}
	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	/**
	 * @return the nOvertureCPC
	 */
	public String getnOvertureCPC() {
		return nOvertureCPC;
	}
	/**
	 * @param nOvertureCPC the nOvertureCPC to set
	 */
	public void setnOvertureCPC(String nOvertureCPC) {
		this.nOvertureCPC = nOvertureCPC;
	}
	/**
	 * @return the nNaverCPC
	 */
	public String getnNaverCPC() {
		return nNaverCPC;
	}
	/**
	 * @param nNaverCPC the nNaverCPC to set
	 */
	public void setnNaverCPC(String nNaverCPC) {
		this.nNaverCPC = nNaverCPC;
	}
	/**
	 * @return the nNaverCPT
	 */
	public String getnNaverCPT() {
		return nNaverCPT;
	}
	/**
	 * @param nNaverCPT the nNaverCPT to set
	 */
	public void setnNaverCPT(String nNaverCPT) {
		this.nNaverCPT = nNaverCPT;
	}
	/**
	 * @return the nDaumCPC
	 */
	public String getnDaumCPC() {
		return nDaumCPC;
	}
	/**
	 * @param nDaumCPC the nDaumCPC to set
	 */
	public void setnDaumCPC(String nDaumCPC) {
		this.nDaumCPC = nDaumCPC;
	}
	/**
	 * @return the nNateCPM
	 */
	public String getnNateCPM() {
		return nNateCPM;
	}
	/**
	 * @param nNateCPM the nNateCPM to set
	 */
	public void setnNateCPM(String nNateCPM) {
		this.nNateCPM = nNateCPM;
	}
	/**
	 * @return the nGoogleCPC
	 */
	public String getnGoogleCPC() {
		return nGoogleCPC;
	}
	/**
	 * @param nGoogleCPC the nGoogleCPC to set
	 */
	public void setnGoogleCPC(String nGoogleCPC) {
		this.nGoogleCPC = nGoogleCPC;
	}
	/**
	 * @return the nNaverMobile
	 */
	public String getnNaverMobile() {
		return nNaverMobile;
	}
	/**
	 * @param nNaverMobile the nNaverMobile to set
	 */
	public void setnNaverMobile(String nNaverMobile) {
		this.nNaverMobile = nNaverMobile;
	}
	/**
	 * @return the nGoogleMobile
	 */
	public String getnGoogleMobile() {
		return nGoogleMobile;
	}
	/**
	 * @param nGoogleMobile the nGoogleMobile to set
	 */
	public void setnGoogleMobile(String nGoogleMobile) {
		this.nGoogleMobile = nGoogleMobile;
	}
	/**
	 * @return the nDaumMobile
	 */
	public String getnDaumMobile() {
		return nDaumMobile;
	}
	/**
	 * @param nDaumMobile the nDaumMobile to set
	 */
	public void setnDaumMobile(String nDaumMobile) {
		this.nDaumMobile = nDaumMobile;
	}
	/**
	 * @return the nNaverBrand
	 */
	public String getnNaverBrand() {
		return nNaverBrand;
	}
	/**
	 * @param nNaverBrand the nNaverBrand to set
	 */
	public void setnNaverBrand(String nNaverBrand) {
		this.nNaverBrand = nNaverBrand;
	}
	/**
	 * @return the nDaumBrand
	 */
	public String getnDaumBrand() {
		return nDaumBrand;
	}
	/**
	 * @param nDaumBrand the nDaumBrand to set
	 */
	public void setnDaumBrand(String nDaumBrand) {
		this.nDaumBrand = nDaumBrand;
	}
	/**
	 * @return the nNeoClick
	 */
	public String getnNeoClick() {
		return nNeoClick;
	}
	/**
	 * @param nNeoClick the nNeoClick to set
	 */
	public void setnNeoClick(String nNeoClick) {
		this.nNeoClick = nNeoClick;
	}
	/**
	 * @return the nGDN
	 */
	public String getnGDN() {
		return nGDN;
	}
	/**
	 * @param nGDN the nGDN to set
	 */
	public void setnGDN(String nGDN) {
		this.nGDN = nGDN;
	}
	/**
	 * @return the nAdMob
	 */
	public String getnAdMob() {
		return nAdMob;
	}
	/**
	 * @param nAdMob the nAdMob to set
	 */
	public void setnAdMob(String nAdMob) {
		this.nAdMob = nAdMob;
	}
	/**
	 * @return the nInMobi
	 */
	public String getnInMobi() {
		return nInMobi;
	}
	/**
	 * @param nInMobi the nInMobi to set
	 */
	public void setnInMobi(String nInMobi) {
		this.nInMobi = nInMobi;
	}
	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}
	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}
	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	/**
	 * @return the startOpenMonth
	 */
	public String getStartOpenMonth() {
		return startOpenMonth;
	}
	/**
	 * @param startOpenMonth the startOpenMonth to set
	 */
	public void setStartOpenMonth(String startOpenMonth) {
		this.startOpenMonth = startOpenMonth;
	}
	/**
	 * @return the endOpenMonth
	 */
	public String getEndOpenMonth() {
		return endOpenMonth;
	}
	/**
	 * @param endOpenMonth the endOpenMonth to set
	 */
	public void setEndOpenMonth(String endOpenMonth) {
		this.endOpenMonth = endOpenMonth;
	}
	/**
	 * @return the nDaySum
	 */
	public String getnDaySum() {
		return nDaySum;
	}
	/**
	 * @param nDaySum the nDaySum to set
	 */
	public void setnDaySum(String nDaySum) {
		this.nDaySum = nDaySum;
	}
	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}
	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}
}
