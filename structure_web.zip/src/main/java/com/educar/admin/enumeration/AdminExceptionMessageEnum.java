/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.enumeration;

/**
 * @author ������
 *
 */
public enum AdminExceptionMessageEnum {
	/** �˼� ���� ���� **/
	LOGIN_UNKONWN_USER("admin.login.unknownUser"),
	/**  **/
	LOGIN_INVAILD_IP("admin.login.invaildIP");

	/**
	 * ���� exceptions.properties key ��
	 */
	private String message;

	/**
	 * private constructor to inject message
	 * @param message
	 */
	private AdminExceptionMessageEnum(final String message) {
		this.message = message;
	}

	/**
	 * Enum�� String message�� ��ȯ
	 * @return
	 */
	public String getMessage() {
		return this.message;
	}
}
