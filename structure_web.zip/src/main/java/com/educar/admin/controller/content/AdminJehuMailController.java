/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminJehuMailDAO;
import com.educar.common.dto.PageDTO;
import com.educar.admin.dto.content.AffiliatedRequestDTO;

/**
 * ������� ������ ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller(value = "/admin/jehuMail")
public class AdminJehuMailController {
	@Autowired
	private AdminJehuMailDAO adminJehuMailDAO;

	/**
	 * ����/�����ڷ� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/jehuMail/selectJehuMailList")
	public ModelAndView selectJehuMailList(final AffiliatedRequestDTO dto) {
		final Integer totalCount = adminJehuMailDAO.selectJehuMailListCount(dto);
		List<AffiliatedRequestDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminJehuMailDAO.selectJehuMailList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/maillist");
		return mv;
	}
	/**
	 * ����/�����ڷ� ���,����  ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/jehuMail/selectJehuMailInfo")
	public ModelAndView selectJehuMailInfo(final HttpSession session, final AffiliatedRequestDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AffiliatedRequestDTO result = adminJehuMailDAO.selectJehuMailInfo(dto);
		mv.addObject("result", result);
		mv.setViewName("contentMng/maillist_register");
		return mv;
	}
	
}
