/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminEventDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.dto.content.AdminEventDTO;
import com.educar.admin.dto.content.AdminOnedayCouponDTO;
import com.educar.admin.dto.content.AdminRegularMngDisclosureDTO;
import com.educar.admin.dto.content.RecommendFriendInputDTO;
import com.educar.admin.dto.content.RecommendFriendResultDTO;
import com.educar.admin.dto.memberMng.AdminMemberJoinWithdrawListDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.admin.service.content.AdminEventService;
import com.educar.common.dto.PageDTO;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.dao.EventDAO;


/**
 * �̺�Ʈ ��÷�� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/event")
public class AdminEventController {
	@Autowired
	private AdminEventDAO adminEventDAO;
	@Autowired
	private AdminEventService adminEventService;
	@Autowired
	private AdminCommonService adminCommonService;
	@Autowired
	private EventDAO eventDAO;
	private Logger logger = Logger.getLogger(getClass());
	@Autowired
	private FTPService ftpService;
	/** property service **/
	@Autowired
	private PropertyService propertyService;
	
	/**
	 * �̺�Ʈ������ ���� 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/inputLotteryCustomer")
	public ModelAndView inputLotteryCustomer(final AdminEventDTO dto) {
		logger.info("�̺�Ʈ����jsp�������̵�");
		final ModelAndView mv = new ModelAndView();
		List<AdminEventDTO> resultList = null;
		resultList = adminEventDAO.selectCODAA01(dto);
		
		mv.setViewName("newEvent/inputLotteryCustomer");
		mv.addObject("eventCboList", resultList);
		return mv;
	}
	
	/**
	 * �̺�Ʈ�Խ� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/eventAddWeb")
	public ModelAndView eventAddWeb(final AdminEventDTO dto) {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("newEvent/eventAddWeb");
		return mv;
	}
	
	/**
	 * URL ��ҿ� ���� ���ε�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/downsizeUrl")
	public ModelAndView downsizeUrl() {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("newEvent/downsizeUrl");
		return mv;
	}
	
	/**
	 * ���������� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/onedayCouponWeb")
	public ModelAndView onedayCouponWeb() {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("newEvent/onedayCouponWeb");
		return mv;
	}
	
	/**
	 * ģ����õ�̺�Ʈ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/recommendFriend")
	public ModelAndView recommendFriend() {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("newEvent/recommendFriend");
		return mv;
	}
	
	/**
	 * sns������ ��ȸ
	 * @param dto
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "/event/selectSNSsupporterList")
	public void selectWEBBB37Count(HttpServletResponse res, final AdminEventDTO dto) throws IOException {
		final String cnt = adminEventDAO.selectWEBBB37Count(dto);
		printReturnMsg(res, cnt);
	}
	
	/**
	 * �̺�Ʈ�ڵ� ��ȸ
	 * @param res
	 * @param sAdminID
	 * @throws IOException
	 */
	@RequestMapping(value = "/event/selectEventCD")
	public void selectEventCD(HttpServletResponse res, final String sEventDiv) throws IOException{
		final String cnt = adminEventDAO.selectEventName(sEventDiv);
		printReturnMsg(res, cnt);
	}
	
	/**
	 * sns������ ����
	 * @param dto
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "/event/selectSNSsupporterSave")
	public void selectSNSsupporterSave(HttpServletResponse res, final AdminEventDTO dto) throws IOException {
		String rtn = Integer.toString(adminEventDAO.insertCUSAA10(dto));
		rtn = rtn + "�� ������ ����Ϸ�.";
		printReturnMsg(res, rtn);
	}
	
	/**
	 * sns������ ����
	 * @param dto
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "/event/selectSNSdeleteCUSAA10")
	public void selectSNSdeleteCUSAA10(HttpServletResponse res, final AdminEventDTO dto) throws IOException {
		String rtn = Integer.toString(adminEventDAO.deleteCUSAA10(dto));
		rtn = rtn + "�� ������ �����Ϸ�.";
		printReturnMsg(res, rtn);
	}
	
	/**
	 * sns�̺�Ʈ ��÷����� ����
	 * @param dto
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/event/selectSNSsupporterInsert")
	public void selectSNSsupporterInsert(HttpServletResponse res, final AdminEventDTO dto) throws IOException {		
		HashMap hMap = new HashMap();
		
		hMap.put("nGrade", dto.getnGrade()[0]);
		hMap.put("sEventDiv", dto.getsEventDiv());
		hMap.put("sInputDateFrom", dto.getsInputDateFrom());
		hMap.put("sInputDateTo", dto.getsInputDateTo());
		
		String rtn = "�̹� ����� �����Դϴ�.";
		
		if(adminEventDAO.countWEBBB21(dto.getsEventDiv()) <= 0){
			rtn = Integer.toString(adminEventDAO.insertWEBBB21(hMap));
			rtn = rtn + "�� ������ ����Ϸ�.";
		}
		printReturnMsg(res, rtn);
	}
	
	/**
	 * sns�̺�Ʈ ��÷����� ����
	 * @param dto
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/event/selectSNSsupporterDelete")
	public void selectSNSsupporterDelete(HttpServletResponse res, final AdminEventDTO dto) throws IOException {
		String rtn = Integer.toString(adminEventDAO.deleteWEBBB21(dto));
		rtn = rtn + "�� ������ �����Ϸ�.";
		printReturnMsg(res, rtn);
	}
	
	/**
	 * �������� �̺�Ʈ �Խÿ�
	 * @param dto
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/event/insertEventAddWeb")
	public void insertEventAddWeb(HttpServletResponse res, final AdminEventDTO dto) throws IOException {
		String rtn = Integer.toString(adminEventDAO.deleteWEBBB21(dto));
		rtn = rtn + "�� ������ �����Ϸ�.";
		printReturnMsg(res, rtn);
	}

	/**
	 * ajax �ݹ� �� msg
	 * @param res
	 * @param cnt
	 * @throws IOException
	 */
	public void printReturnMsg(HttpServletResponse res,String cnt) throws IOException{
		res.setContentType("text/html; charset=utf-8");
		res.setHeader("pragma", "no-cache");
		res.setHeader("cache-control", "no-cache");
		res.setHeader("expires", "0");
		PrintWriter out = res.getWriter();
		out.println(cnt);
		out.flush();
		out.close();
	}

	
	/**
	 * �̺�Ʈ ��÷ ���α׷� ���
	 * @param res
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/event/lotteryCreateProc")
	public String lotteryCreateProc(final HttpSession session,final HttpServletResponse res, final AdminEventDTO dto) throws Exception
	{
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		HashMap dbparam 				= new HashMap();
		ModelAndView mav 				= new ModelAndView();
												
		String subFolderNm				= DateTime.now().toString("yyyyMMdd");
		String subHHMMSS				= DateTime.now().toString("HHmmss");
		String sTitleImg1				= subFolderNm + "/" + dto.getsTitleImg1().getOriginalFilename();	
		String sTitleImg2				= subFolderNm + "/" + dto.getsTitleImg2().getOriginalFilename();	
		int[] nGradeArrayParam			= dto.getnGrade();			// ���		
		int[] nGrade2ArrayParam			= dto.getnGrade2();			// ��÷���
		int[] nGradeTotalArrayParam		= dto.getnGradeTotal();		// �� ��÷��
		
		//Ÿ��Ʋ�̹��� ��� ����
		adminCommonService.fileUpload(dto.getsTitleImg1(), "/fupload/admin/" + subFolderNm, "E");
		adminCommonService.fileUpload(dto.getsTitleImg2(), "/fupload/admin/" + subFolderNm, "E");
		
		// �̺�Ʈ ��÷ ���� �Է� ����		
		dbparam.put("sEventDiv"	, 	dto.getsEventDiv());					// �̺�Ʈ�ڵ�
		dbparam.put("sEventID"	, 	dto.getsEventDiv());					// ��÷ �̺�Ʈ�ڵ�
		dbparam.put("sTitleImg1", 	sTitleImg1);							// Ÿ��Ʋ �̹���1
		dbparam.put("sTitleImg2", 	sTitleImg2);							// Ÿ��Ʋ �̹���2
		dbparam.put("sInputDate", 	subFolderNm);							//�Է���
		dbparam.put("sInputTime", 	subHHMMSS);		//�Է½ð�
		dbparam.put("sUserID"	, 	loginInfo.getsName());					// ���� �α��ε� ������ id
		
		int insertRtn = adminEventDAO.insertWEBBB19(dbparam);
		if (insertRtn != 1){
			throw new RuntimeException("adminEventDAO.insertWEBBB19 �۾� ����");
		}
		// �̺�Ʈ ��÷ �Է� ��
		
		
		for ( int i=0 ; i<nGradeArrayParam.length ; i++ ) {
			adminCommonService.fileUpload(dto.getsGradeTitleImg()[i], "/fupload/admin/" + subFolderNm, "E");
			dbparam = new HashMap();
			dbparam.put("sEventDiv", 	dto.getsEventDiv());
			dbparam.put("nGrade", 		nGradeArrayParam[i] );
			dbparam.put("sTitleImg", 	subFolderNm + "/" + dto.getsGradeTitleImg()[i].getOriginalFilename());
			dbparam.put("nGradeTotal", 	nGradeTotalArrayParam[i]);
			dbparam.put("nGrade2", 		nGrade2ArrayParam[i]);
			dbparam.put("sInputDate", 	subFolderNm);
			dbparam.put("sInputTime", 	subHHMMSS);
			dbparam.put("sUserID", 		loginInfo.getsName());
			
			int insertRtn20 = adminEventDAO.insertWEBBB20(dbparam);
			if (insertRtn20 != 1){
				throw new RuntimeException("adminEventDAO.insertWEBBB20 �۾� ����");
			}
		}
		
		return "forward:/admin/event/lotteryList";	
	}
	
	/**
	 * �������� ���� ȭ�� �̵�
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/event/lotteryList")
	public ModelAndView lotteryList(final AdminEventDTO dto) {
		final Integer totalCount = adminEventDAO.selectWEBBB19Count(dto);
		List<Map> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminEventDAO.selectWEBBB19(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		//mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("newEvent/lotteryList");
		return mv;
	}
	
	/**
	 * ��÷ ���� ȭ��
	 * @param request
	 * @param sCustNo
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/event/lotteryStart")
	public ModelAndView lotteryStart ( final AdminEventDTO dto) throws Exception 
	{
		ModelAndView mav = new ModelAndView();

		mav.setViewName("newEvent/common/lotteryStart"); 	// jsp page ���
		
		if(dto.getsEventDiv().equals(""))
			return mav;
		
		// �ش� ��� ���� ���� ����
		HashMap dbparam = new HashMap();
		dbparam.put("sEventDiv", dto.getsEventDiv()); 
		
		HashMap web_WEBBB19_select1HashMap = (HashMap) adminEventDAO.web_WEBBB19_select1(dto.getsEventDiv());
		List web_WEBBB20_select1List       = adminEventDAO.web_WEBBB20_select1(dto.getsEventDiv());
		
		dbparam.put("sInputDate", DateTime.now().toString("yyyyMMdd"));
		dbparam.put("sInputTime", DateTime.now().toString("HHmmss"));
 
		mav.addObject("web_WEBBB19_select1HashMap", web_WEBBB19_select1HashMap);
		mav.addObject("web_WEBBB20_select1List", 	web_WEBBB20_select1List); 
		mav.addObject("dbparam", 					dbparam);
		return mav;
	}
	
	
	/**
	 * �̺�Ʈ ��÷ 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/event/eventLottery")
	public ModelAndView eventLottery (final AdminEventDTO dto, final HttpSession session) throws Exception
	{ 
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		ModelAndView mav = new ModelAndView();
		mav.setViewName(dto.getRtnUri());   // ���� ���
		
		String sEventDivsParam 				= dto.getsEventDiv();								// �̺�Ʈ�ڵ�
		String sEventDivLotteryParam 		= dto.getsEventLotteryDiv();						// ��÷ �̺�Ʈ�ڵ�
		int nGradeParam						= Integer.parseInt(dto.getnGradeValue());			// web_WEBBB21 ��� ���
		int nGradeTotalParam				= Integer.parseInt(dto.getnGradeTotalValue());		// ��÷ �� (��¼�)
		int nGradeInputParam				= Integer.parseInt(dto.getnGradeInputValue());		// WEBBB07 �Է�  ���
		int nGradeDisplayParam				= Integer.parseInt(dto.getnGradeDisplayValue());	// ��÷ �����¿�

		// �ش� ��� ��÷ �� ��� ����
		HashMap dbparam = new HashMap();
		dbparam.put("sEventID", 	sEventDivLotteryParam);
		dbparam.put("nGrade", 		nGradeInputParam);
		//HashMap eventHashMapDb = (HashMap) adminEventDAO.web_WEBBB07_select2(dbparam);
		//nGradeTotalParam = nGradeTotalParam - Integer.parseInt(eventHashMapDb.get("WEBBB07_Count").toString());
		nGradeTotalParam = nGradeTotalParam - adminEventDAO.web_WEBBB07_select2(dbparam);
		// �ش� ��� ��÷ �� ��� ��
 
		
		// �ش� ��� ��÷ ����
		dbparam = new HashMap();
		// ��÷�� ���� ����
		dbparam.put("sEventDiv", 	sEventDivsParam);
		dbparam.put("nGrade", 		nGradeParam);
		List resultList 		= adminEventDAO.web_WEBBB21_select1(dbparam );
		List tmpCustInfo		= null;
		HashMap resultHashMap	= null;
		// ��÷�� ���� ��
		
		
		// �� ������ ��ȣ ����
		List lotteryNumberList = new ArrayList();
		for ( int i=0 ; i<resultList.size() ; i++ ){
			lotteryNumberList.add(i+"");
		}
		
		// �� ��÷�ο� > ������
		nGradeTotalParam = nGradeTotalParam>resultList.size() ? resultList.size() : nGradeTotalParam;

		for ( int i=0 ; i<nGradeTotalParam ; i++ ){
			
			// ���� ��ȣ �̱� ����
	    	int random = (int)(Math.random() * lotteryNumberList.size());
			int lotteryNumber = Integer.parseInt(lotteryNumberList.get(random).toString());
			// ���� ��ȣ �̱� ��			
			
			resultHashMap = (HashMap)resultList.get(lotteryNumber);			
			
			// ��÷�� ���� �������� ����
			dbparam = new HashMap();
			dbparam.put("sEventDiv", 	resultHashMap.get("sEventDiv").toString().trim());
			dbparam.put("sCustNo", 		resultHashMap.get("sCustNo").toString().trim());
			HashMap eventHashMapDb = (HashMap) adminEventDAO.customer_CUSAA10_select2(dbparam);
			// ��÷�� ���� �������� ��
			
			if (eventHashMapDb == null ) {
				
				nGradeTotalParam = nGradeTotalParam>resultList.size() ? resultList.size() : ++nGradeTotalParam;
				lotteryNumberList.remove(random);
				
				// ��÷ ����� ������ ����				
				if ( lotteryNumberList.size() == 0 )
					break;
				else
					continue;
			}
			
			// �̹� ��÷ �Ǿ��� Ȯ�� ����
			dbparam.put("sEventID", 	sEventDivLotteryParam);
			dbparam.put("sCustNo", 		eventHashMapDb.get("sCustNo").toString().trim());
			//HashMap eventHashMapDb2 = (HashMap) adminEventDAO.web_WEBBB07_select4(dbparam);
			
			if ( !"0".equals(Integer.toString(adminEventDAO.web_WEBBB07_select4(dbparam))) ) {
				// ��÷�� ��÷ ���� ���� ����(tempdb)
				this.setLotteryYnUpdate(resultHashMap.get("sEventDiv").toString().trim(), eventHashMapDb.get("sCustNo").toString().trim());
				// ��÷�� ��÷ ���� ���� ��(tempdb)
				lotteryNumberList.remove(random);
				
				// ��÷ ����� ������ ����
				if ( lotteryNumberList.size() == 0 )
					break;
				else
					continue;
			}
			// �̹� ��÷ �Ǿ��� Ȯ�� ��
			 
			
			// ��÷�� ��� ����
			dbparam = new HashMap();
			dbparam.put("sEventID", 		sEventDivLotteryParam);
			dbparam.put("nSeqNo", 			1);
			dbparam.put("sCustNo", 			eventHashMapDb.get("sCustNo").toString().trim());
			dbparam.put("nCustSeqNo", 		1);
			dbparam.put("sLast", 			"Y");
			dbparam.put("sCustName", 		(eventHashMapDb.get("sName")==null)?"":eventHashMapDb.get("sName").toString().trim() );
			dbparam.put("sEventType", 		"A");
			dbparam.put("nGrade", 			nGradeInputParam);
			dbparam.put("sHomeTel1", 		(eventHashMapDb.get("sHomeTel1")==null)?"":eventHashMapDb.get("sHomeTel1").toString().trim() );
			dbparam.put("sHomeTel2", 		(eventHashMapDb.get("sHomeTel2")==null)?"":eventHashMapDb.get("sHomeTel2").toString().trim() );
			dbparam.put("sHomeTel3", 		(eventHashMapDb.get("sHomeTel3")==null)?"":eventHashMapDb.get("sHomeTel3").toString().trim() );
			dbparam.put("sOfficeTel1", 		(eventHashMapDb.get("sOfficeTel1")==null)?"":eventHashMapDb.get("sOfficeTel1").toString().trim() );
			dbparam.put("sOfficeTel2", 		(eventHashMapDb.get("sOfficeTel2")==null)?"":eventHashMapDb.get("sOfficeTel2").toString().trim() );
			dbparam.put("sOfficeTel3", 		(eventHashMapDb.get("sOfficeTel3")==null)?"":eventHashMapDb.get("sOfficeTel3").toString().trim() );
			dbparam.put("sCellPhone1", 		(eventHashMapDb.get("sCellPhone1")==null)?"":eventHashMapDb.get("sCellPhone1").toString().trim() );
			dbparam.put("sCellPhone2", 		(eventHashMapDb.get("sCellPhone2")==null)?"":eventHashMapDb.get("sCellPhone2").toString().trim() );
			dbparam.put("sCellPhone3", 		(eventHashMapDb.get("sCellPhone3")==null)?"":eventHashMapDb.get("sCellPhone3").toString().trim() );
			dbparam.put("sEmail", 			(eventHashMapDb.get("sEmail")==null)?"":eventHashMapDb.get("sEmail").toString().trim() );
			dbparam.put("sZip1", 			(eventHashMapDb.get("sZip1")==null)?"":eventHashMapDb.get("sZip1").toString().trim() );
			dbparam.put("sZip2", 			(eventHashMapDb.get("sZip2")==null)?"":eventHashMapDb.get("sZip2").toString().trim() );
			dbparam.put("sAdrs1", 			(eventHashMapDb.get("sAdrs1")==null)?"":eventHashMapDb.get("sAdrs1").toString().trim() );
			dbparam.put("sAdrs2", 			(eventHashMapDb.get("sAdrs2")==null)?"":eventHashMapDb.get("sAdrs2").toString().trim() );
			dbparam.put("sAdrs3", 			(eventHashMapDb.get("sAdrs3")==null)?"":eventHashMapDb.get("sAdrs3").toString().trim() );
			dbparam.put("sAdrsAdd", 		(eventHashMapDb.get("sAdrsAdd")==null)?"":eventHashMapDb.get("sAdrsAdd").toString().trim() );
			dbparam.put("sInputDate", 		DateTime.now().toString("yyyyMMdd"));
			dbparam.put("sInputTime", 		DateTime.now().toString("HHmmss"));
			
			System.out.println("[��SBM"+ DateTime.now().toString("yyyyMMdd") +"] : getsAprvCd : " + dto.getsAprvCd());
			System.out.println("[��SBM"+ DateTime.now().toString("yyyyMMdd") +"] : sCustNo : " + eventHashMapDb.get("sCustNo").toString().trim());
			System.out.println("[��SBM"+ DateTime.now().toString("yyyyMMdd") +"] : getsEmployeeNumber : " + loginInfo.getsEmployeeNumber());
			
			adminEventDAO.web_WEBBB07_insert1(dbparam);			
			adminEventService.savePrintHistory(dto.getsAprvCd(), eventHashMapDb.get("sCustNo").toString().trim(), loginInfo.getsEmployeeNumber());
			// ��÷�� ��� ��
//			if (!adminEventService.savePrintHistory(dto.getsAprvCd(), eventHashMapDb.get("sCustNo").toString().trim(), loginInfo.getsEmployeeNumber())){
//				throw new RuntimeException("adminEventService.savePrintHistory ���������̷����� �۾� ����!");
//			}

			// ��÷�� ��÷ ���� ���� ����(tempdb)
			this.setLotteryYnUpdate(resultHashMap.get("sEventDiv").toString().trim(), eventHashMapDb.get("sCustNo").toString().trim());
			// ��÷�� ��÷ ���� ���� ��(tempdb)
			
			lotteryNumberList.remove(random);
		}
		// �ش� ��� ��÷ ��
		
		//������������̷� ����
		
		// �ش� ��� ���� ����
		dto.setnGradeValue(Integer.toString(nGradeDisplayParam));
		dbparam = new HashMap();
		dbparam.put("nGradeValue", Integer.parseInt(dto.getnGradeValue()));
		dbparam.put("sEventLotteryDiv", dto.getsEventLotteryDiv());
		dbparam.put("sFmdt", 	dto.getsFmdt());
		dbparam.put("sTodt", 	dto.getsTodt());		
		mav.addObject("resultList", 	adminEventDAO.web_WEBBB07_select3(dbparam));
		mav.addObject("nGradeDisplay", 	nGradeDisplayParam);
		return mav;
	}
	
	/**
	 * web_WEBBB21 table Y �� ���� 
	 * @param request
	 * @param sCustNo
	 * @return
	 * @throws Exception
	 */	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void setLotteryYnUpdate(String sEventDiv, String sCustNo ) {
		
		// ��÷�� ��÷ ���� ���� ����(tempdb)
		HashMap dbparam = new HashMap();
		dbparam.put("sEventDiv", 		sEventDiv);
		dbparam.put("sCustNo", 			sCustNo);
		dbparam.put("sInputDate", 		DateTime.now().toString("yyyyMMdd"));
		dbparam.put("sInputTime", 		DateTime.now().toString("HHmmss"));
		adminEventDAO.web_WEBBB21_update1(dbparam);
		// ��÷�� ��÷ ���� ���� ��(tempdb)
	}
	
	
//	/**
//	 * �̺�Ʈ ��÷�� ����Ʈ
//	 * @param request
//	 * @param response
//	 * @return
//	 * @throws Exception
//	 */
//	@RequestMapping(value = "/event/eventLotteryInfo")
//	public ModelAndView eventLotteryInfo (final HttpServletResponse response, final AdminEventDTO dto) throws Exception 
//	{
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName(dto.getRtnUri());
//		
//		String nGradeDisplaysParam = dto.getnGradeDisplays();		// ��÷ �����¿�
//		String[] nGradeDisplays = nGradeDisplaysParam.equals("")? null : nGradeDisplaysParam.split(",");
//		
//		if ( nGradeDisplays == null )	return mav;
//		
//		Vector resultVector = new Vector();
//		
//		for ( int i=0 ; i<nGradeDisplays.length ; i++ ) {
//			int nGradeDisplay = Integer.parseInt(nGradeDisplays[i]);
//			dto.setnGradeValue(Integer.toString(nGradeDisplay));
//			
//			HashMap dbparam = new HashMap();
//			dbparam.put("nGradeValue", 	nGradeDisplay);
//			dbparam.put("sEventLotteryDiv", dto.getsEventLotteryDiv());
//			dbparam.put("sFmdt", 	dto.getsFmdt());
//			dbparam.put("sTodt", 	dto.getsTodt());
//			
//			resultVector.add(adminEventDAO.web_WEBBB07_select3(dbparam));
//		}
//		
//		mav.addObject("resultVector", resultVector);
//		return mav;
//	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/event/eventLotteryInfo")
	public ModelAndView eventLotteryInfo (final HttpServletResponse response, final AdminEventDTO dto) throws Exception 
	{
		ModelAndView mav = new ModelAndView();
		mav.setViewName(dto.getRtnUri());
		
		String nGradeDisplaysParam = dto.getnGradeDisplays();		// ��÷ �����¿�
		String[] nGradeDisplays = nGradeDisplaysParam.equals("")? null : nGradeDisplaysParam.split(",");
		
		if ( nGradeDisplays == null )	return mav;
		
		Vector resultVector = new Vector();
		
		for ( int i=0 ; i<nGradeDisplays.length ; i++ ) {
			int nGradeDisplay = Integer.parseInt(nGradeDisplays[i]);
			dto.setnGradeValue(Integer.toString(nGradeDisplay));
			
			HashMap dbparam = new HashMap();
			dbparam.put("nGradeValue", 	nGradeDisplay);
			dbparam.put("sEventLotteryDiv", dto.getsEventLotteryDiv());
			dbparam.put("sFmdt", 	dto.getsFmdt());
			dbparam.put("sTodt", 	dto.getsTodt());
			
			resultVector.add(adminEventDAO.web_WEBBB07_select3(dbparam));
		}
		
		response.setHeader("Content-Disposition", "attachment; filename=\"List.xls\"");
		mav.addObject("resultVector", resultVector);
		mav.setViewName("/newEvent/common/lotteryWinnerExcel");
		return mav;
	}
	
	/**
	 * �̺�Ʈ�Խõ��
	 * @param response
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/event/publishingEvent")
	public ModelAndView publishingEvent (final HttpSession session, final AdminEventDTO dto) throws Exception 
	{
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		String YYYY 		= DateTime.now().toString("yyyy");
		String sEventPath 	= "/home/tmax/newweb/webtob/docs/download/membership/event/";
		String sShortPath	= "/download/membership/event/";
		String sBannerImg	= dto.getsBannerImg().getOriginalFilename();
		String sHTML		= dto.getsHTML().getOriginalFilename();
		
		//Ÿ��Ʋ�̹��� ��� ����
		adminCommonService.fileUpload(dto.getsBannerImg(), sShortPath + YYYY, "");
		adminCommonService.fileUpload(dto.getsHTML(), sShortPath , "");
		
		//�̺�Ʈ�Ⱓ ��ȸ
		HashMap eventStartEnd = (HashMap)adminEventDAO.selectEventDate(dto.getsEventDiv());
		eventStartEnd.put("sEventDiv",dto.getsEventDiv());
		eventStartEnd.put("sEventTitle",dto.getsEventTitle());
		eventStartEnd.put("sPresent",dto.getsPresent());
		eventStartEnd.put("sTargetPeople",dto.getsTargetPeople());
		eventStartEnd.put("sBannerImg",sBannerImg);
		eventStartEnd.put("sBannerImgPath",sShortPath + YYYY + "/");
		eventStartEnd.put("sHTML",sShortPath + sHTML);
		eventStartEnd.put("sEmpNo",loginInfo.getsEmployeeNumber());
		eventStartEnd.put("sInputTime",DateTime.now().toString("yyyy-MM-dd HH:mm:ss"));
		
		final int eventSeq = (Integer) adminEventDAO.selectEventEnroll(dto.getsEventDiv());
		
		logger.info("eventSeq>>>>"+eventSeq);
		if(eventSeq >= 1){
			//������Ʈ
			adminEventDAO.updateEWEBE001(eventStartEnd);
		}else {
			//���
			adminEventDAO.insertEWEBE001(eventStartEnd);
		}
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "eventAddWeb.do");
		mav.setViewName("common/message");
		return mav;
	}
	
	/**
	 * �� ��÷�� �Խ�
	 * @param response
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/event/noticeResult")
	public ModelAndView noticeResult (final HttpSession session, final AdminEventDTO dto) throws Exception 
	{
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnURL", "eventAddWeb.do");
		mav.setViewName("common/message");
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		
		HashMap tmpInfo = new HashMap();
		tmpInfo.put("sEventID", dto.getsEventDiv());
		tmpInfo.put("nGrade", 1);
		tmpInfo.put("sEventDiv", dto.getsEventDiv());
		tmpInfo.put("sEventComment", dto.getsEventComment());
		tmpInfo.put("sDateComment", dto.getsDateComment());
		tmpInfo.put("PRIZE01", dto.getPRIZE01());
		tmpInfo.put("PRIZE02", dto.getPRIZE02());
		tmpInfo.put("PRIZE03", dto.getPRIZE03());
		tmpInfo.put("PRIZE04", dto.getPRIZE04());
		tmpInfo.put("PRIZE05", dto.getPRIZE05());
		tmpInfo.put("sInputDate", DateTime.now().toString("yyyyMMdd"));
		tmpInfo.put("sInputTime", DateTime.now().toString("yyyy-MM-dd HH:mm:ss")+".000");
		tmpInfo.put("sEmpNo", loginInfo.getsEmployeeNumber());
		
		final int eventSeq = (Integer) adminEventDAO.selectEWEBE003(dto.getsEventDiv());
		if(eventSeq >= 1){ 
			mav.addObject("returnMSG", "������ ��ϵ� ��÷�ڹ�ǥ�� �ֽ��ϴ�. ������ �ٽ� ������ּ���.");
		}else {
			//��÷�� �Խ� insert
			adminEventDAO.insertEWEBE002003(tmpInfo);
		}
		return mav;
	}
	
	/**
	 * �� ��÷�� ����
	 * @param response
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/event/noticeRejectResult")
	public ModelAndView noticeRejectResult (final HttpSession session, final AdminEventDTO dto) throws Exception 
	{
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnURL", "eventAddWeb.do");
		mav.setViewName("common/message");
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		
		HashMap tmpInfo = new HashMap();
		tmpInfo.put("sEventDiv", dto.getsEventDiv());
		
		//��÷�� �Խ� ����
		adminEventDAO.deleteEWEBE003(tmpInfo);
		return mav;
	}
	
	/**
	 * ���������� ����
	 * @param response
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/event/createOnedayCoupon")
	public ModelAndView createOnedayCoupon(final HttpSession session, final AdminOnedayCouponDTO dto) throws Exception 
	{
		//�������� ����
		final int countNum = Integer.parseInt(dto.getsCreateNum());
		
		dto.setsContactPath("8"); //���԰��
		dto.setsCouponStartDate(DateTime.now().toString("yyyyMMdd")); //��������
		dto.setsCreateDate(DateTime.now().toString("yyyyMMdd"));	//��ϳ�¥
		dto.setsCreateTime(DateTime.now().toString("HHmmss"));		//��Ͻð�
		
		for (int i = 0; i < countNum ; i++ ){

			String sCouponCode;
			StringBuffer sb = new StringBuffer();
				
			for ( int j = 0; j<6; j++ ){					//���� 6�� �߻� 
				sb.append((char)((Math.random()*10)+48));
			}
		
			sb.insert(((int)(Math.random()*6) +1 ), ((char)((Math.random()*7)+65)));
			sb.insert(((int)(Math.random()*6) +1 ), ((char)((Math.random()*7)+65)));
			
			sCouponCode = sb.toString();
					
			dto.setsCouponCode(sCouponCode);	//�����ڵ� 8�ڸ�
			
			//�ߺ������ڵ� �ִ��� üũ
			int couponCount = adminEventDAO.web_WEBBB35_select(sCouponCode);
			
			if (couponCount == 0 ) {
				adminEventDAO.web_WEBBB35_insert(dto);
			}else {
				 i--;
			}

		}
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnMSG", "�����Ǿ����ϴ�."); 
		mav.addObject("returnURL", "onedayCouponWeb.do");
		mav.setViewName("common/message");
		return mav;
	}
	
	/**
	 * ������ ������ȣ ���(����)
	 * @return
	 */
	@RequestMapping(value = "/event/selectOnedayCoupon")
	public ModelAndView selectOnedayCoupon(final HttpServletResponse response, final AdminOnedayCouponDTO dto) {

		final List<AdminOnedayCouponDTO> resultList = adminEventDAO.onedayCounponSelect(dto);

		final String fileName = "coupon.xls";

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mav = new ModelAndView();
		mav.addObject("resultList", resultList);
		mav.setViewName("newEvent/onedayCouponExcel");
		return mav;
	}
	
	/**
	 * ������ ������ȣ ����
	 * @return
	 */
	@RequestMapping(value = "/event/deleteOnedayCoupon")
	public ModelAndView deleteOnedayCoupon(final HttpServletResponse response, final AdminOnedayCouponDTO dto) {

		adminEventDAO.web_WEBBB35_delete(dto);
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnMSG", "�����Ǿ����ϴ�."); 
		mav.addObject("returnURL", "onedayCouponWeb.do");
		mav.setViewName("common/message");
		return mav;
	}
	
	/**
	 * ģ����õ�̺�Ʈ ����� ��ȸ(ī��Ʈ)
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "/event/selectRecommendFriendCnt")
	public void selectRecommendFriendCnt(HttpServletResponse res, final RecommendFriendInputDTO dto) throws IOException {
		final String recommendCnt = Integer.toString(adminEventDAO.recommendFriendCnt(dto));
		final String recommenderCnt = Integer.toString(adminEventDAO.recommenderFriendCnt(dto));
		printReturnMsg(res, recommendCnt+"/"+ recommenderCnt);
	}
	
	/**
	 * ģ����õ�̺�Ʈ ����� ��ȸ(����)
	 * @return
	 */
	@RequestMapping(value = "/event/selectRecommendFriend")
	public ModelAndView selectRecommendFriend(final HttpServletResponse response, final RecommendFriendInputDTO dto) {

		final List<RecommendFriendResultDTO> resultList = adminEventDAO.recommendFriendSelect(dto);
		final String fileName = "recommendFriend.xls";
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		final ModelAndView mav = new ModelAndView();
		mav.addObject("resultList", resultList);
		mav.setViewName("newEvent/recommendFriendExcel");
		return mav;
	}
	
	/**
	 * url ��ҿ� ��������
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/event/downsizeUrlRegister")
	public ModelAndView downsizeUrl(final AdminRegularMngDisclosureDTO dto) {
		
		if(dto.getmFile() != null){
			final String subPath = "/st";
	    	final MultipartFile file = dto.getmFile();
	    	
	    	// ���� �̸�
			final String fileName;
				fileName = file.getOriginalFilename(); 
			// ���� ������
			byte[] bytes = null;
			try {
				bytes = file.getBytes();
			} catch (final IOException e) {
				throw new RuntimeException(e);
			}
			
			// FTP ���ε� ���� ���
			final String fileBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey())+subPath;

			// ������ ����� ��ġ
			final StringBuilder remoteFilePath = new StringBuilder();
			remoteFilePath.append(fileBasePath);

			//��ũ URL
			final StringBuilder fileURL = new StringBuilder();
			fileURL.append(subPath);

			remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
			fileURL.append(FTPService.FILE_SEPARATOR).append(fileName);
			// FTP�� WEBTOB�� ����
			for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
				// ���丮�� ������� ����
				ftpService.makeDirectory(webtobConnection, fileBasePath);
				ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
			}
		}
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "downsizeUrl.do");
		mav.setViewName("common/message");
		
		return mav;
	}
	
	
	/**
	 * �̷� �׽�Ʈ
	 * @param request
	 * @param sCustNo
	 * @return
	 * @throws Exception
	 */	
//	@RequestMapping(value = "/event/tttt")
//	private void tttt() {
//		adminEventService.savePrintHistory("14060016", "8201122A00076", "2130032");
//		adminEventService.savePrintHistory("14060018", "8201122A00076", "2130032");
//		adminEventService.savePrintHistory("14060017", "8201122A00076", "2130032");
//	}
}
