/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import java.util.List;

import jeus.util.StringUtil;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.statsMng.AdminStatsMngDAO;
import com.educar.admin.dto.statsMng.AdminBackImgHitDTO;
import com.educar.admin.dto.statsMng.AdminSearchAdDTO;
import com.educar.common.dto.PageDTO;
import com.educar.dto.web.LGUDataSatisticDTO;
import com.educar.service.backbone.AdminStatsBackBoneService;

/**
 * ������ ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller(value = "/admin/stats")
public class AdminStatsMngController {
	@Autowired
	private AdminStatsMngDAO adminStatsMngDAO;
	
	@Autowired
	private AdminStatsBackBoneService adminStatsBackBoneService;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	/**
	 * ���ȭ�� �ٿ�ε� ��Ȳ - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/stats/selectBackImgDownList")
	public ModelAndView selectBackImgDownList(final AdminBackImgHitDTO dto) {

		final Integer totalCount = adminStatsMngDAO.selectBackImgDownCount(dto);
		List<AdminBackImgHitDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminStatsMngDAO.selectBackImgDownList(dto);
		}
		final Integer totalSum = adminStatsMngDAO.selectBackImgHitTotal(dto.getsYearMonth());
		
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("totalSum", totalSum);
		mv.setViewName("/statsMng/bgDownload_list");
		return mv;
	}
	/**
	 * ���ȭ�� �ٿ�ε� ������ 
	 * @return
	 */
	@RequestMapping(value = "/stats/selectBackImgDownInfo")
	public ModelAndView selectBackHitInfo(final String sDate) {
		final List<AdminBackImgHitDTO> result = adminStatsMngDAO.selectBackImgDownInfo(sDate);
		final Integer totalSum = adminStatsMngDAO.selectBackImgHitTotal2(sDate);
		final ModelAndView mv = new ModelAndView();
		
		mv.addObject("resultList", result);
		mv.addObject("totalSum", totalSum);
		mv.addObject("sDate", sDate);
		mv.setViewName("/statsMng/bgDownload_view_popup");
		return mv;
	}
	/**
	 * �˻����� ��Ȳ - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/stats/selectSearchAdList")
	public ModelAndView selectSearchAdList(final AdminSearchAdDTO dto) {

		final Integer totalCount = adminStatsMngDAO.selectSearchAdCount(dto);
		List<AdminSearchAdDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminStatsMngDAO.selectSearchAdList(dto);
		}
		final AdminSearchAdDTO sumResult = adminStatsMngDAO.selectSearchAdSum(dto);
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("sumResult", sumResult);
		mv.setViewName("/statsMng/searchAds");
		return mv;
	}
	/**
	 * ��ʱ��� ��Ȳ - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/stats/selectBannerAdList")
	public ModelAndView selectBannerAdList(final AdminSearchAdDTO dto) {

		final Integer totalCount = adminStatsMngDAO.selectSearchAdCount(dto);
		List<AdminSearchAdDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminStatsMngDAO.selectBannerAdList(dto);
		}
		final AdminSearchAdDTO sumResult = adminStatsMngDAO.selectBannerAdSum(dto);
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("sumResult", sumResult);
		mv.setViewName("/statsMng/bannerAds");
		return mv;
	}
	/**
	 * LG U+������Ȳ
	 * @return
	 */
	@RequestMapping(value = "/stats/selectLGUDataList")
	public ModelAndView selectLGUDataList(final LGUDataSatisticDTO dto) {
		final DateTime dt = new DateTime();
		if(StringUtil.isNullOrEmpty(dto.getsFmdt())){
			dto.setsFmdt(dt.plusMonths(-1).toString("yyyyMMdd"));
		}
		if(StringUtil.isNullOrEmpty(dto.getsTodt())){
			dto.setsTodt(dt.toString("yyyyMMdd"));
		}
		final List<LGUDataSatisticDTO> result = adminStatsBackBoneService.selectAdminLGUDataStatisticList(dto);
		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", result);
		mv.addObject("condition", dto);
		mv.setViewName("/statsMng/lguDataStats");
		return mv;
	}
}
