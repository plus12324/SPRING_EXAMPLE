/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminTvAdDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.admin.dto.content.PrintAdDTO;
import com.educar.admin.dto.content.TvAdDTO;

/**
 * ����/�����ڷ� ���� ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller(value = "/admin/tvAd")
public class AdminTvAdController {
	@Autowired
	private AdminTvAdDAO adminTvAdDAO;
	@Autowired
	private AdminCommonService adminCommonService;
	
	/** ����/�����ڷ� ���ε� ���� �н� **/
	private static final String TVAD_FILE_PATH = "/download/company/publicity/";

	/**
	 * ����/�����ڷ� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/tvAd/selectTvAdList")
	public ModelAndView selectTvAdList(final TvAdDTO dto) {
		final Integer totalCount = adminTvAdDAO.selectTvAdListCount(dto);
		List<TvAdDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminTvAdDAO.selectTvAdList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/tvadvertise");
		return mv;
	}
	/**
	 * ����/�����ڷ� ���,����  ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/tvAd/tvAdModifyInit")
	public ModelAndView tvAdModifyIni(final HttpSession session, final TvAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		mv.addObject("editDiv", "r");
		mv.addObject("sFileUrl", TVAD_FILE_PATH);
		if(dto.getEditDiv().equals("m")){
			final TvAdDTO result = adminTvAdDAO.selectTvAdInfo(dto);
			mv.addObject("editDiv", "m");
			mv.addObject("result", result);
			mv.addObject("sFileUrl", TVAD_FILE_PATH );
		}
		mv.addObject("sUpdNm", loginInfo.getsName());
		mv.setViewName("contentMng/tvadvertise_register");
		return mv;
	}
	/**
	 * ����/�����ڷ� ���
	 * @return
	 */
	@RequestMapping(value = "/tvAd/tvAdInfoInsert")
	public ModelAndView tvAdInfoInsert(final HttpSession session, final TvAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("common/message");
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsEmployeeNumber());
		if(dto.getmFile() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");

	    	dto.setsImgPath(TVAD_FILE_PATH+ '/' + dto.getmFile().getOriginalFilename());
	    	dto.setsImgNm(dto.getmFile().getOriginalFilename());
		}
		if(dto.getmFile2() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile2(), fileUrl, "N");

	    	dto.setsVodPath(TVAD_FILE_PATH+ '/' + dto.getmFile2().getOriginalFilename());
	    	dto.setsVodNm(dto.getmFile2().getOriginalFilename());
		}
		adminTvAdDAO.insertTvAdInfo(dto);
		
		mv.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mv.addObject("returnURL", "selectPrintAdList.do");
		
		return mv;
	}
	/**
	 * ����/�����ڷ� ���� 
	 * @return
	 */
	@RequestMapping(value = "/tvAd/tvAdInfoUpdate")
	public ModelAndView tvAdInfoUpdate(final HttpSession session, final TvAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("common/message");
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsEmployeeNumber());
		if(dto.getmFile() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");

	    	dto.setsImgPath(TVAD_FILE_PATH+ '/' + dto.getmFile().getOriginalFilename());
	    	dto.setsImgNm(dto.getmFile().getOriginalFilename());
		}
		if(dto.getmFile2() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile2(), fileUrl, "N");

	    	dto.setsVodPath(TVAD_FILE_PATH+ '/' + dto.getmFile2().getOriginalFilename());
	    	dto.setsVodNm(dto.getmFile2().getOriginalFilename());
		}
		adminTvAdDAO.updateTvAdInfo(dto);
		
		mv.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mv.addObject("returnURL", "selectTvAdList.do");
		
		return mv;
	}
	/**
	 * ����/�����ڷ�  ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/tvAd/tvAdInfoDelete")
	public ModelAndView tvAdInfoDelete(final TvAdDTO dto) {
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		adminTvAdDAO.deleteTvAdInfo(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mav.addObject("returnURL", "selectTvAdList.do");
		
		return mav;
	}
	/**
	 * �μⱤ�� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/tvAd/selectPrintAdList")
	public ModelAndView selectPrintAdList(final PrintAdDTO dto) {
		final Integer totalCount = adminTvAdDAO.selectPrintAdListCount(dto);
		List<PrintAdDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminTvAdDAO.selectPrintAdList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/printadvertise");
		return mv;
	}
	/**
	 * �μⱤ�� ���,����  ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/tvAd/printAdModifyInit")
	public ModelAndView printAdModifyIni(final HttpSession session, final PrintAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		mv.addObject("editDiv", "r");
		mv.addObject("sFileUrl", TVAD_FILE_PATH);
		if(dto.getEditDiv().equals("m")){
			final PrintAdDTO result = adminTvAdDAO.selectPrintAdInfo(dto);
			mv.addObject("editDiv", "m");
			mv.addObject("result", result);
			mv.addObject("sFileUrl", TVAD_FILE_PATH );
		}
		mv.addObject("sUpdNm", loginInfo.getsName());
		mv.setViewName("contentMng/printadvertise_register");
		return mv;
	}
	/**
	 * �μⱤ�� ���
	 * @return
	 */
	@RequestMapping(value = "/tvAd/printAdInfoInsert")
	public ModelAndView printAdInfoInsert(final HttpSession session, final PrintAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("common/message");
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsEmployeeNumber());
		if(dto.getmFile() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");

	    	dto.setsFileRealPath(TVAD_FILE_PATH+ dto.getmFile().getOriginalFilename());
	    	dto.setsFileNm(dto.getmFile().getOriginalFilename());
	    	dto.setsFilePath(TVAD_FILE_PATH);
	    	dto.setsFileStrNm(dto.getmFile().getOriginalFilename());
		}
		adminTvAdDAO.insertPrintAdInfo(dto);
		
		mv.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mv.addObject("returnURL", "selectPrintAdList.do");
		
		return mv;
	}
	/**
	 * �μⱤ�� ���� 
	 * @return
	 */
	@RequestMapping(value = "/tvAd/printAdInfoUpdate")
	public ModelAndView printAdInfoUpdate(final HttpSession session, final PrintAdDTO dto) {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("common/message");
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsEmployeeNumber());
		if(dto.getmFile() != null){
			final String fileUrl = TVAD_FILE_PATH;
			adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");

			dto.setsFileRealPath(TVAD_FILE_PATH+ dto.getmFile().getOriginalFilename());
	    	dto.setsFileNm(dto.getmFile().getOriginalFilename());
	    	dto.setsFilePath(TVAD_FILE_PATH);
	    	dto.setsFileStrNm(dto.getmFile().getOriginalFilename());
		}
		adminTvAdDAO.updatePrintAdInfo(dto);
		
		mv.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mv.addObject("returnURL", "selectPrintAdList.do");
		
		return mv;
	}
	/**
	 * �μⱤ��  ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/tvAd/printAdInfoDelete")
	public ModelAndView printAdInfoDelete(final PrintAdDTO dto) {
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		adminTvAdDAO.deletePrintAdInfo(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mav.addObject("returnURL", "selectPrintAdList.do");
		
		return mav;
	}
}
