/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.dao.MainDAO;
import com.educar.dto.web.main.MenuDTO;
import com.educar.enumeration.admin.MainMenuEnum;

/**
 * ������ ���������� ����ü�� �������� ��Ʈ�ѷ�
 * @author �ּ�ȯ(David SW Choi) 
 * @since 1.0.0
 */
@Controller(value = "/admin/main")
public class AdminMainController {

	@Autowired
	private MainDAO mainDAO;

	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());

	@RequestMapping(value = "/list")
	public ModelAndView mainMenu() {
		final List<MenuDTO> result = mainDAO.getCenterMenuList(MainMenuEnum.CENTER_MENU.getCode());
		logger.debug(result);
		final ModelAndView mv = new ModelAndView();
		mv.addObject(MainMenuEnum.CENTER_MENU.toString(), result);
		mv.setViewName("board");
		return mv;
	}
}
