/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.commonMng;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.commonMng.SystemManagementDAO;
import com.educar.admin.dao.content.AdminNoticeDAO;
import com.educar.admin.dto.content.AdminRegularMngDisclosureDTO;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.dto.web.LoginUrlDTO;

/**
 * �ý��� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/systemManagement")
public class SystemManagementController {

	@Autowired
	private AdminCommonService adminCommonService;

	/** property service **/
	@Autowired
	private PropertyService propertyService;
	
	@Autowired
	private SystemManagementDAO systemManagementDAO;
	
	
	@Autowired
	private FTPService ftpService;
	
	/**
	 * �ý��� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/systemManagementInit")
	public ModelAndView systemManagementInit() {
		return new ModelAndView("commanagement/system_management");
	}
	
	/**
	 * css�������� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/cssFileSubmitInit")
	public ModelAndView cssFileSubmitInit() {
		return new ModelAndView("commanagement/cssFileRegister");
	}

	/**
	 * ����ĳ�� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/initQueryCache")
	public ModelAndView initQueryCache() {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("commanagement/system_management");

		// ���� ĳ�� ����
		adminCommonService.clearQueryCache();

		mv.addObject("initQueryCacheResult", "�Ϸ�");
		return mv;
	}
	
	/**
	 * css��������
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/cssFileSubmit")
	public ModelAndView cssFileSubmit(final AdminRegularMngDisclosureDTO dto) {
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("/contractMng/message");
		
		if(dto.getmFile() != null){
			final String subPath = "/static/web/common/css";
	    	
	    	final MultipartFile file = dto.getmFile();
	    	
	    	
	    	// ���� �̸�
			final String fileName;
				fileName = file.getOriginalFilename(); 
				
			// ���� ������
			byte[] bytes = null;
			try {
				bytes = file.getBytes();
			} catch (final IOException e) {
				throw new RuntimeException(e);
			}
			
			// FTP ���ε� ���� ���
			final String fileBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey())+subPath;

			// ������ ����� ��ġ
			final StringBuilder remoteFilePath = new StringBuilder();
			remoteFilePath.append(fileBasePath);

			//��ũ URL
			final StringBuilder fileURL = new StringBuilder();
			fileURL.append(subPath);

			remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
			fileURL.append(FTPService.FILE_SEPARATOR).append(fileName);
			// FTP�� WEBTOB�� ����
			for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
				// ���丮�� ������� ����
				ftpService.makeDirectory(webtobConnection, fileBasePath);
				ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
			}
			mav.addObject("returnMSG", "��Ͽ� �����߽��ϴ�.");
		}
		
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "cssFileSubmitInit.do");
		
		return mav;
	}
	
	/**
	 * css��������
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/cssFileSubmitM")
	public ModelAndView cssFileSubmitM(final AdminRegularMngDisclosureDTO dto) {
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("/contractMng/message");
		
		if(dto.getmFile() != null){
			final String subPath = "/static/mobile/common/css";
	    	
	    	final MultipartFile file = dto.getmFile();
	    	
	    	
	    	// ���� �̸�
			final String fileName;
				fileName = file.getOriginalFilename(); 
				
			// ���� ������
			byte[] bytes = null;
			try {
				bytes = file.getBytes();
			} catch (final IOException e) {
				throw new RuntimeException(e);
			}
			
			// FTP ���ε� ���� ���
			final String fileBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey())+subPath;

			// ������ ����� ��ġ
			final StringBuilder remoteFilePath = new StringBuilder();
			remoteFilePath.append(fileBasePath);

			//��ũ URL
			final StringBuilder fileURL = new StringBuilder();
			fileURL.append(subPath);

			remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
			fileURL.append(FTPService.FILE_SEPARATOR).append(fileName);
			// FTP�� WEBTOB�� ����
			for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
				// ���丮�� ������� ����
				ftpService.makeDirectory(webtobConnection, fileBasePath);
				ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
			}
			mav.addObject("returnMSG", "��Ͽ� �����߽��ϴ�.");
		}
		
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "cssFileSubmitInit.do");
		
		return mav;
	}
	
	/**
	 * �α��ΰ��� url ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/loginManagement")
	public ModelAndView loginManagement() {
		return new ModelAndView("commanagement/loginManagement");
	}
	
	/**
	 * �α��ΰ��� url ���
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/loginUrlInsert")
	public ModelAndView loginUrlInsert(final LoginUrlDTO dto) {
		
		systemManagementDAO.insertLoginUrl(dto);
		
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("/contractMng/message");
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "loginManagement.do");
		return mav;
	}
	
	/**
	 * �α��ΰ��� url ����
	 * @return
	 */
	@RequestMapping(value = "/systemManagement/loginUrlDelete")
	public ModelAndView loginUrlDelete(final LoginUrlDTO dto) {
		
		systemManagementDAO.deleteLoginUrl(dto);
		
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("/contractMng/message");
		
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mav.addObject("returnURL", "loginManagement.do");
		return mav;
	}
	
}
