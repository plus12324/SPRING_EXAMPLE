/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminDownCenterDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.dto.content.AdminDownloadCenterDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.common.service.PropertyService;
import com.jcraft.jsch.Logger;

/**
 * �ٿ�ε� ����
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller
public class AdminDownCenterController {
	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;
	@Autowired
	private AdminDownCenterDAO downCenterDAO;
	@Autowired
	private AdminCommonService adminCommonService;

	/**
	 * �ٿ�ε� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/downCenter/selectDownLoadList")
	public ModelAndView selectDownLoadList(final AdminDownloadCenterDTO dto) {
		final Integer totalCount = downCenterDAO.selectDownLoadListCount(dto);
		List<AdminDownloadCenterDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = downCenterDAO.selectDownLoadList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/downloadlist");
		return mv;
	}
	/**
	 * �ٿ�ε� ���� ���/���� ȭ��  �̵�
	 * @return
	 */
	@RequestMapping(value = "/downCenter/downLoadInsertInit")
	public ModelAndView downLoadInsertInit(final HttpSession session) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("sRegiName", loginInfo.getsName());
		mv.addObject("editDiv", "r");
		mv.setViewName("contentMng/download_register");
		return mv;
	}
	/**
	 * �ٿ�ε� ���� /���� ȭ��  �̵�
	 * @return
	 */
	@RequestMapping(value = "/downCenter/downLoadModifyInit")
	public ModelAndView downLoadModifyInit(final HttpSession session, final AdminDownloadCenterDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		
		AdminDownloadCenterDTO downLoadInfo = downCenterDAO.selectDownLoadInfo(dto);

		mv.addObject("sRegiName", loginInfo.getsName());
		mv.addObject("editDiv", "m");
		mv.addObject("result", downLoadInfo);
		mv.setViewName("contentMng/download_register");
		return mv;
	}
	/**
	 * �ٿ�ε� ���� - ���
	 * @return
	 */
	@RequestMapping(value = "/downCenter/downLoadEditRegister")
	public ModelAndView downLoadEditRegister(final HttpSession session, final AdminDownloadCenterDTO dto) {

		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUser(loginInfo.getsEmployeeNumber());
		final int chkResourceKey = downCenterDAO.selectResourceKey(dto);
		if(chkResourceKey > 0){
			mav.addObject("returnMSG", "�̹� ��ϵ� ���ҽ� Ű �Դϴ�.");
			mav.addObject("returnURL", "downLoadInsertInit.do");
		}else{
			if(dto.getmFile() != null){
				final String fileUrl = propertyService.getProperty(AdminSystemPropertyEnum.DOWNCENTER_FILE_PATH.getKey()); 
						
	    		adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");
	    		
	    		dto.setsFileTypeURI(fileUrl);
	    		dto.setsFileName(dto.getmFile().getOriginalFilename());
	    		String[] strFile = dto.getmFile().getOriginalFilename().split("\\.");
	    		//���� Ÿ��
	    		dto.setsFileType(strFile[1].toUpperCase()); 
			}
			downCenterDAO.insertDownLoadInfo(dto);
			// ����ĳ�� �ʱ�ȭ
			adminCommonService.clearQueryCache();
			mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
			mav.addObject("returnURL", "selectDownLoadList.do");
		}
		
		return mav;
	}
	/**
	 * �ٿ�ε� ���� - ����
	 * @return
	 */
	@RequestMapping(value = "/downCenter/downLoadEditModify")
	public ModelAndView downLoadEditModify(final HttpSession session, final AdminDownloadCenterDTO dto) {
		
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUser(loginInfo.getsEmployeeNumber());
		if(dto.getmFile() != null && !"".equals(dto.getmFile().getOriginalFilename())){
			final String fileUrl = propertyService.getProperty(AdminSystemPropertyEnum.DOWNCENTER_FILE_PATH.getKey()); 
    		adminCommonService.fileUpload(dto.getmFile(), fileUrl, "N");
    		
    		if(dto.getmFile().getOriginalFilename() != null){
    			dto.setsFileTypeURI(fileUrl);
        		dto.setsFileName(dto.getmFile().getOriginalFilename());
        		String[] strFile = dto.getmFile().getOriginalFilename().split("\\.");
        		//���� Ÿ��
        	    dto.setsFileType(strFile[1].toUpperCase()); 
    		}
    		
		}
		downCenterDAO.updateDownLoadInfo(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		mav.addObject("returnMSG", "��ϵǾ����ϴ�.");
		mav.addObject("returnURL", "selectDownLoadList.do");
		return mav;
	}
	/**
	 * �ٿ�ε� ���� - ����
	 * @return
	 */
	@RequestMapping(value = "/downCenter/downLoadEditDelete")
	public ModelAndView downLoadEditDelete(final HttpSession session, final AdminDownloadCenterDTO dto) {

		downCenterDAO.deleteDownLoadInfo(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mav.addObject("returnURL", "selectDownLoadList.do");
		return mav;
	}
}
