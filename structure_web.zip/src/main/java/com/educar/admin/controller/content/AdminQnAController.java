/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminQnADAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.dto.web.FaqCategoryDTO;
import com.educar.dto.web.FaqDTO;

/**
 * ���ֹ������� ���� ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller(value = "/admin/qna")
public class AdminQnAController {
	@Autowired
	private AdminQnADAO qnaDAO;
	@Autowired
	private AdminCommonService adminCommonService;

	/**
	 * ���ֹ������� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/qna/selectQnAList")
	public ModelAndView selectNoticeList(final FaqDTO dto) {
		List<FaqCategoryDTO> catList = qnaDAO.selectCatList(dto.getsCatCd());
		List<FaqCategoryDTO> catList2 = qnaDAO.selectCatList(dto.getsCatCd());
		final Integer totalCount = qnaDAO.selectQnaListCount(dto);
		
		List<FaqDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = qnaDAO.selectQnaList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("catList", catList);  //ī�װ��� ��ȸ
		mv.addObject("catList2", catList2);  //ī�װ��� depth2 ��ȸ
		mv.addObject("resultList", resultList);  //���ֹ��� ���� ��ȸ
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/qnalist");
		return mv;
	}
	/**
	 * ���ֹ������� ���� ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/qna/qnaRegisterInit")
	public ModelAndView qnaRegisterInit(final HttpSession session, final FaqDTO dto) {
		List<FaqCategoryDTO> catList = qnaDAO.selectCatList(dto.getsCatCd());
		
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("sRegiName", loginInfo.getsName());
		mv.addObject("catList", catList); 
		mv.setViewName("contentMng/qnalist_register");
		return mv;
	}
	/**
	 * ���ֹ������� ���� ���
	 * @return
	 */
	@RequestMapping(value = "/qna/qnaRegister")
	public String qnaRegister(final HttpSession session, final FaqDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsName());
		dto.setsUpId(loginInfo.getsName());
		// �Խù� ��� ������ ����
		dto.setsTopYn(this.getsTopYn(dto.getsTopYn()));
		qnaDAO.insertQna(dto);
		
		
		// ����ĳ�� �ʱ�ȭ
		//adminCommonService.clearQueryCache();

		return "forward:/admin/qna/selectQnAList";
	}
	/**
	 * <pre>
	 * �Խù� ��� ������ ��ȯ�Ѵ�.
	 * �����ϰ�� N�� ��ȯ
	 * </pre>
	 * @param sTopYn
	 * @return
	 */
	private String getsTopYn(final String sTopYn) {
		String returnValue = sTopYn;
		if (StringUtils.isBlank(sTopYn)) {
			returnValue = "N";
		}
		return returnValue;
	}
	/**
	 * ���ֹ������� ����ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/qna/qnaModifyInit")
	public ModelAndView qnaModifyInit(final HttpSession session, final FaqDTO dto) {
		List<FaqCategoryDTO> catList = qnaDAO.selectCatList(dto.getsCatCd());
		final ModelAndView mv = new ModelAndView();
		final FaqDTO result = qnaDAO.selectQnaInfo(dto.getnSeq());

		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("result", result);
		mv.addObject("catList", catList); 
		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/qnalist_modify");
		return mv;
	}

	/**
	 * ���ֹ������� ����
	 * @return
	 */
	@RequestMapping(value = "/qna/qnaModify")
	public String qnaModify(final HttpSession session, final FaqDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		dto.setsTopYn(this.getsTopYn(dto.getsTopYn()));
		qnaDAO.updateQna(dto);
		
		// ����ĳ�� �ʱ�ȭ
		//adminCommonService.clearQueryCache();
		
		return "forward:/admin/qna/selectQnAList";
	}

	/**
	 * ���ֹ������� ����
	 * @return
	 */
	@RequestMapping(value = "/qna/qnaDelete")
	public String qnaDelete(final FaqDTO dto) {
		// ����
		qnaDAO.deleteQna(dto.getnSeq());

		// ����ĳ�� �ʱ�ȭ
		//adminCommonService.clearQueryCache();
		return "forward:/admin/qna/selectQnAList";
	}
	/**
	 * ���ֹ������� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/qna/selectQnaMenuList")
	public ModelAndView selectQnaMenuList(final FaqDTO dto) {
		final ModelAndView mv = new ModelAndView();
		List<FaqCategoryDTO> catList = qnaDAO.selectCatMenuList();
		mv.addObject("menuList", catList); 
		mv.setViewName("contentMng/qnamenulist");
		return mv;
	}
	/**
	 * ���ֹ������� - �޴����� - �޴���������
	 * @return
	 */
	@RequestMapping(value = "/qna/menuConfirm")
	public String selectQnaMenuConfirm(final FaqDTO dto) {
		//��������
		qnaDAO.updateQnaMenuOrder(dto.getMenuList());
		
		// ����ĳ�� �ʱ�ȭ
		//adminCommonService.clearQueryCache();
		
		String forwardUrl = "forward:/admin/qna/selectQnaMenuList";
		
		return forwardUrl;
	}
}
