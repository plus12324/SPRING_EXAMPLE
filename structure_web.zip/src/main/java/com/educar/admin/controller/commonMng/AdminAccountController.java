/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.commonMng;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.common.dto.PageDTO;
import com.educar.service.backbone.AdminUserBackBoneService;

/**
 * ������ ��������
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/account")
public class AdminAccountController {
	/** ������ ���� �Ⱓ�� ���� **/
	@Autowired
	private AdminUserBackBoneService adminUserBackBoneService;

	/** logger **/
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ������ ���� ��ȸ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/account/selectAdminAccountList")
	public ModelAndView selectAdminAccountList(final AdminAccountDTO dto) {
		
		final Integer totalCount = adminUserBackBoneService.selectAdminAccountListCount(dto);
		List<AdminAccountDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminUserBackBoneService.selectAdminAccountList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/controlledaccount");
		return mv;
	}

	/**
	 * ������ ���� ��� �ʱ�ȭ���̵�
	 * @return
	 */
	@RequestMapping(value = "/account/controlledAccountRegisterInit")
	public ModelAndView controlledAccountRegisterInit(final HttpSession session) {
		return new ModelAndView("commanagement/controlledaccount_register");
	}

	/**
	 * ������ ���� ���
	 * @return
	 */
	@RequestMapping(value = "/account/controlledAccountRegister")
	public String controlledAccountRegister(final HttpSession session, final AdminAccountDTO dto) {
		logger.debug(dto.toString());
		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsCreName(loginInfo.getsName());
		adminUserBackBoneService.insertAdminAccount(dto);
		return "forward:/admin/account/selectAdminAccountList";
	}

	/**
	 * ������ ���� �������� �̵�
	 * @param nSeq
	 * @return
	 */
	@RequestMapping(value = "/account/controlledaccountView")
	public ModelAndView controlledaccountView(final long nSeq) {
		final AdminAccountDTO result = adminUserBackBoneService.selectAdminAccountInfo(nSeq);
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.setViewName("commanagement/controlledaccount_view");
		return mv;
	}

	/**
	 * ������ ���� ���� �������� �̵�
	 * @param nSeq
	 * @return
	 */
	@RequestMapping(value = "/account/controlledaccountModifyInit")
	public ModelAndView controlledaccountModifyInit(final long nSeq) {
		final AdminAccountDTO result = adminUserBackBoneService.selectAdminAccountInfo(nSeq);
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.setViewName("commanagement/controlledaccount_modify");
		return mv;
	}

	/**
	 * ������ ���� ����
	 * @param nSeq
	 * @return
	 */
	@RequestMapping(value = "/account/controlledaccountModify")
	public String controlledaccountModify(final HttpSession session, final AdminAccountDTO dto) {
		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsModiName(loginInfo.getsName());
		adminUserBackBoneService.modifyAdminAccount(dto);
		return "forward:/admin/account/selectAdminAccountList";
	}

	/**
	 * ������ ���� ����
	 * @param nSeq
	 * @return
	 */
	@RequestMapping(value = "/account/controlledaccountDelete")
	public String controlledaccountDelete(final long nSeq) {
		// ����
		adminUserBackBoneService.deleteAdminAccount(nSeq);
		return "forward:/admin/account/selectAdminAccountList";
	}
}
