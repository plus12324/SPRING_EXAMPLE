/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminGreenMotherDAO;
import com.educar.admin.dto.AdminGreenMotherDTO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.dto.web.GreenMotherCommentDTO;
import com.educar.dto.web.products.SchoolSearchResultDTO;
import com.educar.service.backbone.AdresssSearchBackBoneService;

/**
 * �����Ӵ� �Խ��� ���� ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller(value = "/admin/greenMother")
public class AdminGreenMotherController {
	@Autowired
	private AdminGreenMotherDAO adminGreenMotherDAO;
	@Autowired
	private AdminCommonService adminCommonService;
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	
	/** property ���� **/
	@Autowired
	private PropertyService propertyService;
	/** �����Ӵ� �̹��� ���� **/
	private static final String GREENMOTHER_IMAGE_FOLDER_NAME = "GreenMother";
	
	/**
	 * �����Ӵ� �Խ��� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/greenMother/selectGreenMotherList")
	public ModelAndView selectNoticeList(final AdminGreenMotherDTO dto) {
		
		final DateTime dt = new DateTime();
		
		if(StringUtils.isBlank(dto.getStartOpenDate())){
			dto.setStartOpenDate(dt.plusMonths(-1).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getEndOpenDate())){
			dto.setEndOpenDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminGreenMotherDAO.selectGreenMotherListCount(dto);
		List<AdminGreenMotherDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminGreenMotherDAO.selectGreenMotherList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/greenMother_list");
		return mv;
	}
	/**
	 * �����Ӵ� - ��÷�� ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherWinRegisterInit")
	public ModelAndView greenMotherWinRegisterInit(final HttpSession session, final AdminGreenMotherDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/greenWinner_register");
		return mv;
	}
	/**
	 * �����Ӵ� - ��÷�� ���
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherWinRegister")
	public String greenMotherWinRegister(final HttpSession session, final AdminGreenMotherDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsName());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.insertGreenMotherWinner(dto);
		// ����ĳ�� �ʱ�ȭ
		//adminCommonService.clearQueryCache();

		return "forward:/admin/greenMother/selectGreenMotherList";
	}
	/**
	 * �����Ӵ� - ��÷�� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherWinModifyInit")
	public ModelAndView greenMotherWinModifyInit(final HttpSession session, final AdminGreenMotherDTO dto) {
		final ModelAndView mv = new ModelAndView();
		
		final AdminGreenMotherDTO result = adminGreenMotherDAO.selectGreenMotherWinner(dto.getnSeq());

		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("result", result);
		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/greenWinner_modify");
		return mv;
	}
	/**
	 * �����Ӵ� - ��÷�� ����
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherWinModify")
	public String greenMotherWinModify(final HttpSession session, final AdminGreenMotherDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsName());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.updateGreenMotherWinner(dto);
		return "forward:/admin/greenMother/selectGreenMotherList";
	}
	/**
	 * �����Ӵ� - �Խù� ����
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherDelete")
	public String greenMotherDelete(final HttpSession session, final AdminGreenMotherDTO dto) {
		
		adminGreenMotherDAO.deleteGreenMother(dto.getnSeq());
		return "forward:/admin/greenMother/selectGreenMotherList";
	}
	/**
	 * �����Ӵ� - �Խñ� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/greenMother/greenMotherModifyInit")
	public ModelAndView greenMotherModifyInit(final HttpSession session, final AdminGreenMotherDTO dto) {
		final ModelAndView mv = new ModelAndView();
		
		final AdminGreenMotherDTO resultInfo = adminGreenMotherDAO.selectGreenMotherNoticeInfo(dto.getnSeq());
		final List<GreenMotherCommentDTO> cmtList= adminGreenMotherDAO.selectGreenMotherCmtList(dto.getnSeq());

		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("resultInfo", resultInfo);
		mv.addObject("cmtList", cmtList);
		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/greenMother_modify");
		return mv;
	}
	
	/**
	 * �����Ӵ� - �б� ã�� �˾� �̵�
	 * @return
	 */
	@RequestMapping(value = "/greenMother/schoolPopup")
	public ModelAndView schoolPopup(final HttpSession session) {
		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultCnt", "0");
		mv.setViewName("contentMng/greenMother_schoolPop");
		return mv;
	}
	/**
	 * �����Ӵ� - �б� ã��
	 * @return
	 */
	@RequestMapping(value = "/greenMother/searchSchool")
	public ModelAndView searchSchool(final HttpSession session, final String sSchoolName) {
		final List<SchoolSearchResultDTO> resultList = adresssSearchBackBoneService.selectSchoolByNameForWeb(sSchoolName);
		
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", resultList);
		mv.addObject("resultCnt", resultList.size());
		mv.setViewName("contentMng/greenMother_schoolPop");
		return mv;
	}
	/**
	 * �����Ӵ� - �Խñ� ��й�ȣ �ʱ�ȭ
	 * @return
	 */
	@RequestMapping(value = "/greenMother/passwordNoticeReset")
	public String updateNoticePasswordReSet(final HttpSession session, final AdminGreenMotherDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.updateNoticePasswordReSet(dto);
		return "forward:/admin/greenMother/selectGreenMotherList";
	}
	/**
	 * �����Ӵ� - ���� �ʱ�ȭ
	 * @return
	 */
	@RequestMapping(value = "/greenMother/passwordCommentReset")
	public String passwordCommentReset(final HttpSession session, final GreenMotherCommentDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.updateCommentPasswordReSet(dto);

		AdminGreenMotherDTO rtnDto = new AdminGreenMotherDTO();
		rtnDto.setnSeq(dto.getnSeq());
		return "forward:/admin/greenMother/greenMotherModifyInit";
	}
	/**
	 * �����Ӵ� - ���� ����
	 * @return
	 */
	@RequestMapping(value = "/greenMother/modifyGreenMotherComment")
	public String modifyGreenMotherComment(final HttpSession session, final GreenMotherCommentDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.updateGreenMotherComment(dto);
		AdminGreenMotherDTO rtnDto = new AdminGreenMotherDTO();
		rtnDto.setnSeq(dto.getnSeq());
		return "forward:/admin/greenMother/greenMotherModifyInit";
	}
	/**
	 * �����Ӵ� - ���� ����
	 * @return
	 */
	@RequestMapping(value = "/greenMother/deleteGreenMotherComment")
	public String deleteGreenMotherComment(final HttpSession session, final GreenMotherCommentDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		
		adminGreenMotherDAO.deleteGreenMotherComment(dto);

		AdminGreenMotherDTO rtnDto = new AdminGreenMotherDTO();
		rtnDto.setnSeq(dto.getnSeq());
		return "forward:/admin/greenMother/greenMotherModifyInit";
	}
	/**
	 * �����Ӵ� - ��÷�� ����
	 * @return
	 */
	@RequestMapping(value = "/greenMother/modifyGreenMotherNotice")
	public String modifyGreenMotherNotice(final HttpSession session, final AdminGreenMotherDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsName());
		dto.setsUpId(loginInfo.getsName());
		
		final String sSubPath = propertyService.getProperty(AdminSystemPropertyEnum.GREENMOTHER_IMAGE_UPLOAD_URL.getKey());
		final DateTime dt = new DateTime();
		final String fileUrl = FTPService.FILE_SEPARATOR + sSubPath + FTPService.FILE_SEPARATOR + dt.toString("yyyy")+ FTPService.FILE_SEPARATOR + dt.toString("MM");
		
		if(dto.getImageFile1() != null){
	    	adminCommonService.fileUpload(dto.getImageFile1(), fileUrl, "N");
	    	
	    	dto.setsFileTypeURI1(FTPService.FILE_SEPARATOR + dt.toString("yyyy")+ FTPService.FILE_SEPARATOR + dt.toString("MM") + FTPService.FILE_SEPARATOR );
	    	dto.setsFileName1(dto.getImageFile1().getOriginalFilename());
		}
		if(dto.getImageFile2() != null){
	    	adminCommonService.fileUpload(dto.getImageFile2(), fileUrl, "N");
	    	
	    	dto.setsFileTypeURI2(FTPService.FILE_SEPARATOR + dt.toString("yyyy")+ FTPService.FILE_SEPARATOR + dt.toString("MM") + FTPService.FILE_SEPARATOR );
	    	dto.setsFileName2(dto.getImageFile2().getOriginalFilename());
		}
		
		adminGreenMotherDAO.updateGreenMotherNotice(dto);
		return "forward:/admin/greenMother/selectGreenMotherList";
	}
}
