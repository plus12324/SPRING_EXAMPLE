/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.MainScreenDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FTPService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.dto.web.main.MenuDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.admin.MainMenuEnum;
import com.educar.exception.InvalidRequestException;

/**
 * ����ȭ�� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/mainScreen")
public class MainScreenController {
	@Autowired
	private MainScreenDAO mainScreenDAO;
	@Autowired
	private AdminCommonService adminCommonService;
	@Autowired
	private FTPService ftpService;
	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;
	/** �޼��� ���� **/
	@Autowired
	private MessageSourceService message;

	/**
	 * �޴� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/menuManagementInit")
	public ModelAndView menuManagementInit() {
		final ModelAndView mv = new ModelAndView();

		// �޴� ����Ʈ ��ȸ
		this.getMenuList(mv);

		mv.setViewName("contentMng/menulist");
		return mv;
	}

	/**
	 * ��� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/bannerManagementInit")
	public ModelAndView bannerManagementInit() {
		final ModelAndView mv = new ModelAndView();

		// ��� ����Ʈ ��ȸ
		this.getBannerList(mv);

		mv.setViewName("contentMng/bannerlist");
		return mv;
	}

	/**
	 * �޴� ���� ����
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/confirm")
	public String confirm(final MenuDTO dto) {
		// ���� ����
		mainScreenDAO.updateMenuOrder(dto.getMenuList());

		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		String forwardUrl = "forward:/admin/mainScreen/bannerManagementInit";
		if (dto != null && dto.getMenuList() != null && dto.getMenuList().size() > 0) {
			final String sMenuType = dto.getMenuList().get(BigInteger.ZERO.intValue()).getsMenuType();
			forwardUrl = this.isBannerMenu(sMenuType) ? forwardUrl : "forward:/admin/mainScreen/menuManagementInit";
		}

		return forwardUrl;
	}

	/**
	 * �޴� ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/menuRegisterInit")
	public ModelAndView menuRegisterInit(final HttpSession session, final String sMenuType) {
		final ModelAndView mv = new ModelAndView();

		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		final String viewName = this.isBannerMenu(sMenuType) ? "contentMng/banner_register" : "contentMng/menu_register";
		mv.setViewName(viewName);
		mv.addObject("sMenuType", sMenuType);
		mv.addObject("sRegiName", loginInfo.getsName());
		return mv;
	}

	/**
	 * �޴� ���
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/menuRegister")
	public String menuRegister(final HttpSession session, final MenuDTO dto) {
		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		final String sRegId = loginInfo.getsName();
		dto.setsRegId(sRegId);
		dto.setsUpId(sRegId);

		// ���� ���ε� �� �̹��� ��ũ URL�� ����
		this.fileUpload(dto);

		String forwardUrl = "forward:/admin/mainScreen/menuManagementInit";
		// ��ʰ����ϰ��
		if (this.isBannerMenu(dto.getsMenuType())) {
			dto.setsOpenDate(DateTime.now().toString("yyyyMMdd"));
			forwardUrl = "forward:/admin/mainScreen/bannerManagementInit";
		}
		// �޴� ���
		mainScreenDAO.insertMenu(dto);

		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		return forwardUrl;
	}

	/**
	 * �޴� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/menuModifyInit")
	public ModelAndView menuModifyInit(final HttpSession session, final MenuDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final MenuDTO result = mainScreenDAO.selectMenu(dto.getnSeq());

		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		result.setsUpId(loginInfo.getsName());

		final String viewName = this.isBannerMenu(dto.getsMenuType()) ? "contentMng/banner_modify" : "contentMng/menu_modify";

		mv.setViewName(viewName);
		mv.addObject("result", result);
		return mv;
	}

	/**
	* �޴� ����
	* @return
	*/
	@RequestMapping(value = "/mainScreen/menuModify")
	public String menuModify(final HttpSession session, final MenuDTO dto) {

		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());

		// ���� ���ε� �� �̹��� ��ũ URL�� ����
		this.fileUpload(dto);

		// ������ ������� sImageLinkURL�� ������Ʈ ���� �ʴ´�.
		if (dto.getsImageFile() == null || dto.getsImageFile().isEmpty()) {
			dto.setsImageLinkURL(null);
		}

		mainScreenDAO.updateMenu(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		final String forwardUrl = this.isBannerMenu(dto.getsMenuType()) ? "forward:/admin/mainScreen/bannerManagementInit" : "forward:/admin/mainScreen/menuManagementInit";

		return forwardUrl;
	}

	/**
	 * �޴� ����
	 * @return
	 */
	@RequestMapping(value = "/mainScreen/deleteMenu")
	public String deleteMenu(final MenuDTO dto) {
		final List<Long> deleteSeqList = new ArrayList<Long>();
		String sMenuType = StringUtils.EMPTY;
		if (dto.getMenuList() != null) {
			for (final MenuDTO menu : dto.getMenuList()) {
				if (BigInteger.ONE.toString().equals(menu.getCheckValue())) {
					deleteSeqList.add(menu.getnSeq());
					sMenuType = menu.getsMenuType();
				}
			}
		}
		if (!deleteSeqList.isEmpty()) {
			mainScreenDAO.deleteMenu(deleteSeqList);
			// ����ĳ�� �ʱ�ȭ
			adminCommonService.clearQueryCache();
		}
		final String forwardUrl = this.isBannerMenu(sMenuType) ? "forward:/admin/mainScreen/bannerManagementInit" : "forward:/admin/mainScreen/menuManagementInit";
		return forwardUrl;
	}

	/**
	 * ���� ���ε� �� �̹��� ��ũ URL�� dto�� ����
	 * @param dto
	 */
	private void fileUpload(final MenuDTO dto) {
		if (dto.getsImageFile() == null || dto.getsImageFile().isEmpty()) {
			return;
		}
		String folderName = StringUtils.EMPTY;
		if (MainMenuEnum.CENTER_MENU.getCode().equals(dto.getsMenuType())) {
			folderName = "mainMenu";
		} else if (MainMenuEnum.FIRST_VISIT.getCode().equals(dto.getsMenuType())) {
			folderName = "firstVisit";
		} else if (MainMenuEnum.SIGN_UP_CUSTOMERS.getCode().equals(dto.getsMenuType())) {
			folderName = "signUpCustomers";
		} else if (MainMenuEnum.ISSUE_ZONE.getCode().equals(dto.getsMenuType())) {
			folderName = "issueZone";
		} else if (MainMenuEnum.BANNER_ZONE.getCode().equals(dto.getsMenuType())) {
			folderName = "bannerZone";
		} else {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.InvalidRequest), ResponseStatusEnum.DEFAULT_ERROR);
		}
		// ���� �̸�
		final String fileName = adminCommonService.getFileReName(dto.getsImageFile().getOriginalFilename());
		// ���� ������
		byte[] bytes = null;
		try {
			bytes = dto.getsImageFile().getBytes();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}

		// FTP ���ε� ���� ���
		final DateTime dt = new DateTime();
		final String imageSubPath = propertyService.getProperty(AdminSystemPropertyEnum.MENU_IMAGE_PATH_SUB.getKey());
		final String imageBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey()) + imageSubPath;
		final String[] imageSubPathArray = { folderName, dt.toString("yyyy"), dt.toString("MM") };

		// ������ ����� ��ġ
		final StringBuilder remoteFilePath = new StringBuilder();
		remoteFilePath.append(imageBasePath);

		// �̹��� ��ũ URL
		final StringBuilder imageLinkURL = new StringBuilder();
		imageLinkURL.append(imageSubPath);

		for (final String path : imageSubPathArray) {
			remoteFilePath.append(FTPService.FILE_SEPARATOR).append(path);
			imageLinkURL.append(FTPService.FILE_SEPARATOR).append(path);
		}
		remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
		imageLinkURL.append(FTPService.FILE_SEPARATOR).append(fileName);
		// �̹��� ��ũURL dto�� ����
		dto.setsImageLinkURL(imageLinkURL.toString());
		// FTP�� WEBTOB�� ����
		for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
			// ���丮�� ������� ����
			ftpService.makeDirectory(webtobConnection, imageBasePath, imageSubPathArray);
			// ���ε�
			ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
		}
	}

	/**
	 * �޴� ����Ʈ�� ��ȸ�Ͽ� ModelAndView�� ����
	 * @param mv
	 */
	private void getMenuList(final ModelAndView mv) {
		final List<MenuDTO> mainMenuList = mainScreenDAO.getMenuList(MainMenuEnum.CENTER_MENU.getCode());
		final List<MenuDTO> firstVisitList = mainScreenDAO.getMenuList(MainMenuEnum.FIRST_VISIT.getCode());
		final List<MenuDTO> signUpCustomersList = mainScreenDAO.getMenuList(MainMenuEnum.SIGN_UP_CUSTOMERS.getCode());

		mv.addObject("mainMenuList", mainMenuList);
		mv.addObject("firstVisitList", firstVisitList);
		mv.addObject("signUpCustomersList", signUpCustomersList);
	}

	/**
	 * �޴� ����Ʈ�� ��ȸ�Ͽ� ModelAndView�� ����
	 * @param mv
	 */
	private void getBannerList(final ModelAndView mv) {
		final List<MenuDTO> issueZoneList = mainScreenDAO.getMenuList(MainMenuEnum.ISSUE_ZONE.getCode());
		final List<MenuDTO> bannerZoneList = mainScreenDAO.getMenuList(MainMenuEnum.BANNER_ZONE.getCode());

		mv.addObject("issueZoneList", issueZoneList);
		mv.addObject("bannerZoneList", bannerZoneList);
	}

	/**
	 * ��ʰ��� �޴� �Ǵ�
	 * @param sMenuType
	 * @return
	 */
	private boolean isBannerMenu(final String sMenuType) {
		boolean resultValue = false;
		if (MainMenuEnum.ISSUE_ZONE.getCode().equals(sMenuType) || MainMenuEnum.BANNER_ZONE.getCode().equals(sMenuType)) {
			resultValue = true;
		}
		return resultValue;
	}
}
