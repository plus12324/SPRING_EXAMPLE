/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.ProductMainScreenDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.dto.web.main.InsuranceProductMainMenuDTO;

/**
 * �����ǰ �ʱ�ȭ��
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/productMainScreen")
public class ProductMainScreenController {
	@Autowired
	private AdminCommonService adminCommonService;
	@Autowired
	private ProductMainScreenDAO productMainScreenDAO;
	@Autowired
	private FTPService ftpService;
	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;

	/**
	 * �����ǰ ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/menuManagementInit")
	public ModelAndView menuManagementInit() {
		final ModelAndView mv = new ModelAndView();
		final List<InsuranceProductMainMenuDTO> resultList = productMainScreenDAO.selectProductMainScreenList();
		mv.addObject("resultList", resultList);
		mv.setViewName("contentMng/productlist");
		return mv;
	}

	/**
	 * �޴� ���� ����
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/confirm")
	public String confirm(final InsuranceProductMainMenuDTO productMainScreenDTO) {
		// ���� ����
		productMainScreenDAO.updateMenuOrder(productMainScreenDTO.getProductMainMenuList());
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		return "forward:/admin/productMainScreen/menuManagementInit";
	}

	/**
	 * �޴� ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/menuRegisterInit")
	public ModelAndView menuRegisterInit() {
		return new ModelAndView("contentMng/product_register");
	}

	/**
	 * �޴� ���
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/menuRegister")
	public String menuRegister(final HttpSession session, final InsuranceProductMainMenuDTO dto) {
		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		final String sRegId = loginInfo.getsName();
		dto.setsUpId(sRegId);
		dto.setsRegId(sRegId);

		// �⺻�̹���, Ȯ���̹��� ���ε� �� �̹���URL ����
		this.fileUpload(dto);
		// �޴� ���
		productMainScreenDAO.insertMenu(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		return "forward:/admin/productMainScreen/menuManagementInit";
	}

	/**
	 * �޴� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/menuModifyInit")
	public ModelAndView menuModifyInit(final InsuranceProductMainMenuDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final InsuranceProductMainMenuDTO result = productMainScreenDAO.selectMenu(dto.getnSeq());

		mv.addObject("result", result);
		mv.setViewName("contentMng/product_modify");
		return mv;
	}

	/**
	* �޴� ����
	* @return
	*/
	@RequestMapping(value = "/productMainScreen/menuModify")
	public String menuModify(final HttpSession session, final InsuranceProductMainMenuDTO dto) {

		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());

		// ���� ���ε� �� �̹��� ��ũ URL�� ����
		this.fileUpload(dto);

		productMainScreenDAO.updateMenu(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		return "forward:/admin/productMainScreen/menuManagementInit";
	}

	/**
	 * �޴� ����
	 * @return
	 */
	@RequestMapping(value = "/productMainScreen/deleteMenu")
	public String deleteMenu(final InsuranceProductMainMenuDTO dto) {
		final List<Long> deleteSeqList = new ArrayList<Long>();
		if (dto.getProductMainMenuList() != null) {
			for (final InsuranceProductMainMenuDTO productMenu : dto.getProductMainMenuList()) {
				if (BigInteger.ONE.toString().equals(productMenu.getCheckValue())) {
					deleteSeqList.add(productMenu.getnSeq());
				}
			}
		}
		if (!deleteSeqList.isEmpty()) {
			productMainScreenDAO.deleteMenu(deleteSeqList);
			// ����ĳ�� �ʱ�ȭ
			adminCommonService.clearQueryCache();
		}
		return "forward:/admin/productMainScreen/menuManagementInit";
	}

	/**
	 * ���� ���ε� �� �̹��� ��ũ URL�� dto�� ����
	 * @param dto
	 */
	private void fileUpload(final InsuranceProductMainMenuDTO dto) {
		// �⺻ �̹��� ���ε�
		if (dto.getsImageFile() != null && !dto.getsImageFile().isEmpty()) {
			final String linkUrl = fileUpload(dto.getsImageFile());
			dto.setsImageLinkURL(linkUrl);
		}
		// Ȯ�� �̹��� ���ε�
		if (dto.getsThumbImageFile() != null && !dto.getsThumbImageFile().isEmpty()) {
			final String linkUrl = fileUpload(dto.getsThumbImageFile());
			dto.setsImageThumbLinkURL(linkUrl);
		}
	}

	/**
	 * ���� ���ε� �� �̹��� ��ũ URL�� dto�� ����
	 * @param file
	 * @return
	 */
	private String fileUpload(final MultipartFile file) {
		// ���� �̸�
		final String fileName = adminCommonService.getFileReName(file.getOriginalFilename());
		// ���� ������
		byte[] bytes = null;
		try {
			bytes = file.getBytes();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}

		// FTP ���ε� ���� ���
		final DateTime dt = new DateTime();
		final String imageSubPath = propertyService.getProperty(AdminSystemPropertyEnum.INSURANCE_PRODUCT_IMAGE_PATH_SUB.getKey());
		final String imageBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey()) + imageSubPath;
		final String[] imageSubPathArray = { dt.toString("yyyy"), dt.toString("MM") };

		// ������ ����� ��ġ
		final StringBuilder remoteFilePath = new StringBuilder();
		remoteFilePath.append(imageBasePath);

		// �̹��� ��ũ URL
		final StringBuilder imageLinkURL = new StringBuilder();
		imageLinkURL.append(imageSubPath);

		for (final String path : imageSubPathArray) {
			remoteFilePath.append(FTPService.FILE_SEPARATOR).append(path);
			imageLinkURL.append(FTPService.FILE_SEPARATOR).append(path);
		}
		remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
		imageLinkURL.append(FTPService.FILE_SEPARATOR).append(fileName);
		// FTP�� WEBTOB�� ����
		for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
			// ���丮�� ������� ����
			ftpService.makeDirectory(webtobConnection, imageBasePath, imageSubPathArray);
			// ���ε�
			ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
		}

		return imageLinkURL.toString();
	}
}
