/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * ������ �������� ��Ʈ�ѷ�
 * @author �ּ�ȯ(David SW Choi) 
 * @since 1.0.0
 */
@Controller(value = "/admin/test")
public class AdminUserController {

	@RequestMapping(value = "/test2/test3")
	public ModelAndView test() {
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("board");
		return mv;
	}
}
