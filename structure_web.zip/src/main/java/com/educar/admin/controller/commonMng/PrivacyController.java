/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.commonMng;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.commonMng.PrivacyDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.dto.commonMng.PrivacyDTO;
import com.educar.admin.dto.commonMng.PrivacyHistoryDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.admin.service.commonMng.PrivacyService;
import com.educar.common.dto.PageDTO;

/**
 * ��� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/privacy")
public class PrivacyController {
	@Autowired
	private PrivacyDAO privacyDAO;
	@Autowired
	private PrivacyService privacyService;
	@Autowired
	private AdminCommonService adminCommonService;

	/**
	 * ��� ��ȸ
	 * @param dto  
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyList")
	public ModelAndView privacyList(final PrivacyDTO dto) {
		final Integer totalCount = privacyDAO.selectPrivacyCount(dto);
		
		List<PrivacyDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = privacyDAO.selectPrivacyList(dto);
		}
		final PageDTO pageDTO = dto;
		
		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.addObject("condition", dto);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/privacy_list");
		return mv;
	}

	/**
	 * ��� �̷� ��ȸ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyHistoryList")
	public ModelAndView privacyHistoryList(final PrivacyHistoryDTO dto) {

		final Integer totalCount = privacyDAO.selectPrivacyHistoryCount(dto);
		List<PrivacyHistoryDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = privacyDAO.selectPrivacyHistoryList(dto);
		}

		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.addObject("condition", dto);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/privacyHistory_list");
		return mv;
	}

	/**
	 * ��� �̷� �� ��ȸ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyHistoryDetail")
	public ModelAndView privacyHistoryDetail(final long nSeq) {
		final PrivacyHistoryDTO result = privacyDAO.selectPrivacyHistoryInfo(nSeq);
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.setViewName("commanagement/privacyHistory_detail");
		return mv;
	}

	/**
	 * ��� ���� �ʱ�ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyModifyInit")
	public ModelAndView privacyModifyInit(final HttpSession session, final long nSeq) {
		final PrivacyDTO result = privacyDAO.selectPrivacyInfo(nSeq);

		// �α����� ���� �̸��� �ִ´�
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		result.setsModiName(loginInfo.getsName());

		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.setViewName("commanagement/privacy_modify");
		return mv;
	}

	/**
	 * ��� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyModify")
	public String privacyModify(final PrivacyDTO dto) {
		privacyService.privacyModify(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		return "forward:/admin/privacy/privacyList";
	}
	/**
	 * ��� ���� �ʱ�ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyInit")
	public ModelAndView privacyInit() {
		return new ModelAndView("commanagement/privacy_register");
	}
	
	/**
	 * ��� ���
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/privacy/privacyRegister")
	public String privacyRegister(final PrivacyDTO dto) {
		privacyDAO.insertPrivacyInfo(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		return "forward:/admin/privacy/privacyList";
	}
}
