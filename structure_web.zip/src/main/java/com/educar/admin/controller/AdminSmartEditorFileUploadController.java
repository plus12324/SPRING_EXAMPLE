/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import java.io.IOException;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;

/**
 * ������ ����Ʈ ������ ���� ���ε� ��Ʈ�ѷ�
 * @author ������
 *
 */
@Controller(value = "/admin/smartEditor")
public class AdminSmartEditorFileUploadController {
	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;
	@Autowired
	private AdminCommonService adminCommonService;
	@Autowired
	private FTPService ftpService;

	@RequestMapping(value = "/smartEditor/upload")
	public String upload(final MultipartRequest request, final String callback, final String callback_func) throws IOException {
		final String imageCallbackUrl = propertyService.getProperty(AdminSystemPropertyEnum.EDITOR_IMAGE_UPLOAD_URL.getKey());
		final String imageCallbackSubUrl = propertyService.getProperty(AdminSystemPropertyEnum.EDITOR_IMAGE_PATH_SUB.getKey());

		final MultipartFile file = request.getFile(request.getFileNames().next());
		// ���� �̸�
		final String fileName = adminCommonService.getFileReName(file.getOriginalFilename());
		// ���� ������
		final byte[] bytes = file.getBytes();

		// FTP ���ε� ���� ���
		final DateTime dt = new DateTime();
		final String imageBasePath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey()) + imageCallbackSubUrl;
		final String[] imageSubPathArray = { dt.toString("yyyy"), dt.toString("MM") };

		// �ݹ鿡 ���� ���� url
		final StringBuilder remoteImageCallbackUrl = new StringBuilder();
		remoteImageCallbackUrl.append(imageCallbackSubUrl);

		// �̹��� ���忡 ���� remote full ���
		final StringBuilder remoteImagePath = new StringBuilder();
		remoteImagePath.append(imageBasePath);
		for (final String temp : imageSubPathArray) {
			remoteImagePath.append(FTPService.FILE_SEPARATOR).append(temp);
			remoteImageCallbackUrl.append(FTPService.FILE_SEPARATOR).append(temp);
		}
		remoteImagePath.append(FTPService.FILE_SEPARATOR).append(fileName);

		// FTP�� WEBTOB�� ����
		for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
			// ���丮�� ������� ����
			ftpService.makeDirectory(webtobConnection, imageBasePath, imageSubPathArray);
			// ���ε�
			ftpService.upload(webtobConnection, bytes, remoteImagePath.toString());
		}

		final StringBuilder sb = new StringBuilder();
		sb.append(callback).append("?callback_func=").append(callback_func);
		sb.append("&bNewLine=true");
		sb.append("&sFileName=" + fileName);
		sb.append("&sFileURL=").append(imageCallbackUrl).append(remoteImageCallbackUrl.toString()).append(FTPService.FILE_SEPARATOR).append(fileName);

		return "redirect:" + sb.toString();
	}
}
