/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.service.DistributedCacheService;
import com.educar.enumeration.CacheEnum;

/**
 * ����ĳ�� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/queryCache")
public class QueryCacheController {

	/** �л�ĳ�� ���� **/
	@Autowired
	private DistributedCacheService distributedCacheService;
	/** logger **/
	private Logger logger = Logger.getLogger(getClass());

	/**
	 * �α��� �ʱ� ������
	 * @return
	 */
	@RequestMapping(value = "/queryCache/clear")
	@ResponseBody
	public boolean queryCacheClear() {
		final Cache cache = distributedCacheService.getCache(CacheEnum.QUERY_CACHE_MAP.getName());
		cache.clear();
		logger.debug("���� ĳ�� �ʱ�ȭ");
		return true;
	}
}
