/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.commonMng.PartnershipDAO;
import com.educar.admin.dao.contractMng.AdminContractMngDAO;
import com.educar.admin.dto.contractMng.AdminCarContractDTO;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.PairDTO;

/**
 * ������ - ������ ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller
public class AdminContractMngController {
	@Autowired
	private AdminContractMngDAO adminContractMngDAO;
	@Autowired
	private PartnershipDAO partnershipDAO;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	@Autowired
	private AdminCommonService adminCommonService;
	/** Message Service */
	@Autowired
	private MessageSourceService messageService;
	/**
	 * �����ŷ�ȸ������ - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/contractMng/selectCarContractList")
	public ModelAndView selectMemberList(final AdminCarContractDTO dto) {

		final Integer totalCount = adminContractMngDAO.selectCarContractCount(dto);
		List<AdminCarContractDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminContractMngDAO.selectCarContractList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		//�����ڵ� ��������
		final List<PairDTO> partnershipCodeList = partnershipDAO.selectPartnershipCodeList();
		
		mv.addObject("partnershipCodeList", partnershipCodeList);
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contractMng/carContract_list");
		return mv;
	}
	
}
