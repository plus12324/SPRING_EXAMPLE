/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.commonMng;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.commonMng.PartnershipDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.dto.commonMng.PartnershipDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.commonMng.PartnershipService;
import com.educar.common.dto.PageDTO;
import com.educar.dto.web.PairDTO;


/**
 * ���޻� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/partnership")
public class PartnershipController {
	@Autowired
	private PartnershipDAO partnershipDAO;
	@Autowired
	private PartnershipService partnershipService;
	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());
	/**
	 * ���޻� ��ȸ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipRegisterList")
	public ModelAndView partnershipRegisterList(final PartnershipDTO dto) {
		final Integer totalCount = partnershipDAO.selectPartnershipListCount();
		List<PartnershipDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = partnershipDAO.selectPartnershipList(dto);
		}

		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/partnership_management");
		return mv;
	}

	/**
	 * ���޻� ������ȸ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipAccountList")
	public ModelAndView partnershipAccountList(final PartnershipDTO dto) {
		final Integer totalCount = partnershipDAO.selectPartnershipAccountCount(dto);
		List<PartnershipDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = partnershipDAO.selectPartnershipAccountList(dto);
		}
		
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/partnershipaccount");
		return mv;
	}
	
	/**
	 * ���޻� ������ȸ(������)
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipAdminAccountList")
	public ModelAndView partnershipAdminAccountList(final PartnershipDTO dto) {
		final Integer totalCount = partnershipDAO.selectPartnershipAccountAdminCount(dto);
		List<PartnershipDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = partnershipDAO.selectPartnershipAccountAdminList(dto);
		}

		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("commanagement/partnershipadminaccount");
		return mv;
	}

	/**
	 * ���޻� ���ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipRegisterInit")
	public ModelAndView partnershipRegisterInit() {
		final List<PairDTO> partnershipCodeList = partnershipDAO.selectPartnershipCodeList();
		final List<PairDTO> longTermCodeList = partnershipDAO.selectLongTermCodeList();
		final ModelAndView mv = new ModelAndView();
		mv.addObject("partnershipCodeList", partnershipCodeList);
		mv.addObject("longTermCodeList", longTermCodeList);
		mv.setViewName("commanagement/partnership_register");
		return mv;
	}
	
	/**
	 * ���޻���� ��ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipAccountInit")
	public ModelAndView partnershipAccountInit(final String sAdminID) {
		final PartnershipDTO partnershipAccountInfo;
		
		if(sAdminID != null && sAdminID.length() > 0)
			partnershipAccountInfo = partnershipDAO.selectPartnershipAccountInfo(sAdminID);
		else
			partnershipAccountInfo = null;
		
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", partnershipAccountInfo);
		mv.setViewName("commanagement/partnershipaccount_view");
		return mv;
	}
		
	
	/**
	 * ���޻����(������) ��ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipAdminAccountInit")
	public ModelAndView partnershipAdminAccountInit(final PartnershipDTO dto) {
		final PartnershipDTO partnershipAdminAccountInfo;
		
		if(dto.getsSSN() != null && dto.getsIPAddress() != null)
			partnershipAdminAccountInfo = partnershipDAO.selectPartnershipAdminAccountInfo(dto);
		else
			partnershipAdminAccountInfo = null;
		
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", partnershipAdminAccountInfo);
		mv.setViewName("commanagement/partnershipadminaccount_view");
		return mv;
	}
	
	
	/**
	 * ���޻����(������) �ߺ���ȸ
	 * @param res
	 * @param sAdminID
	 * @throws IOException
	 */
	@RequestMapping(value = "/partnership/partnershipAdminAccountIdDupChk")
	public void partnershipAdminAccountIdDupChk(HttpServletResponse res, final PartnershipDTO dto) throws IOException{
		final int cnt = partnershipDAO.selectpartnershipAdminAccountIdDupChk(dto);
		printReturnMsg(res, cnt);
	}
	
	/**
	 * ���޻���� �ߺ���ȸ
	 * @param res
	 * @param sAdminID
	 * @throws IOException
	 */
	@RequestMapping(value = "/partnership/partnershipAccountIdDupChk")
	public void partnershipAccountIdDupChk(HttpServletResponse res, final String sAdminID) throws IOException{
		final int cnt = partnershipDAO.selectpartnershipAccountIdDupChk(sAdminID);
		printReturnMsg(res, cnt);
	}
	
	/**
	 * ajax �ݹ� �� msg
	 * @param res
	 * @param cnt
	 * @throws IOException
	 */
	public void printReturnMsg(HttpServletResponse res,int cnt) throws IOException{
		res.setContentType("text/html; charset=utf-8");
		res.setHeader("pragma", "no-cache");
		res.setHeader("cache-control", "no-cache");
		res.setHeader("expires", "0");
		PrintWriter out = res.getWriter();		
		out.println(cnt);
		out.flush();
		out.close();
	}

	/**
	 * ���޻� ���
	 * @param dto	
	 * @return
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	@RequestMapping(value = "/partnership/partnershipRegister")
	public String partnershipRegister(final PartnershipDTO dto) throws Exception{
		// ���޻� ���
		partnershipService.partnershipRegister(dto);
		
		return "forward:/admin/partnership/partnershipRegisterList";
	}
	
	/**        
	 * ���޻� ���
	 * @param dto	
	 * @return
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	@RequestMapping(value = "/partnership/partnershipAccountModify")
	public String partnershipAccountModify(final HttpSession session, final PartnershipDTO dto) {
		String rtnMsg = "forward:/admin/partnership/partnershipAccountList";		
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUserID(loginInfo.getsName());
		String sIsrt = dto.getsIsrt();
		if(sIsrt != null && "1".equals(sIsrt)){
			if(dto.getsSSN() != null && dto.getsSSN().length() > 0){
				partnershipDAO.insertPartnershipAdminAccount(dto);
				rtnMsg = "forward:/admin/partnership/partnershipAdminAccountList";
			}
			else{
				partnershipDAO.insertPartnershipAccount(dto);
			}
		}
		else{
			if(dto.getsSSN() != null && dto.getsSSN().length() > 0){
				partnershipDAO.updatePartnershipAdminAccountInfo(dto);
				rtnMsg = "forward:/admin/partnership/partnershipAdminAccountList";
			}
			else{
				partnershipDAO.updatePartnershipAccountInfo(dto);
			}
		}
	
		return rtnMsg;
	}

	/**
	 * ���޻� ���� ������ �̵�	
	 * @param nSeq
	 * @return
	 */
	@RequestMapping(value = "/partnership/partnershipModifyInit")
	public ModelAndView partnershipModifyInit(final long nSeq) {
		final PartnershipDTO result = partnershipDAO.selectPartnershipInfo(nSeq);
		final List<PairDTO> longTermCodeList = partnershipDAO.selectLongTermCodeList();
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.addObject("longTermCodeList", longTermCodeList);
		mv.setViewName("commanagement/partnership_modify");
		return mv;
	}
      
	/**
	 * ���޻� ���� ������ �̵�	
	 * @param nSeq
	 * @return
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	@RequestMapping(value = "/partnership/partnershipModify")
	public String partnershipModify(final PartnershipDTO dto) throws JDOMException, IOException {
		// ���޻� ����
		partnershipService.partnershipModify(dto);
		return "forward:/admin/partnership/partnershipRegisterList";
	}

	/**
	 * ���޻� ����	
	 * @param nSeq
	 * @return
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	@RequestMapping(value = "/partnership/partnershipDelete")
	public String partnershipDelete(final PartnershipDTO dto) throws JDOMException, IOException {
		// ���޻� ����
		partnershipService.partnershipDelete(dto);
		return "forward:/admin/partnership/partnershipRegisterList";
	}
	
	/**
	 * ���޻���� ����	
	 * @param nSeq
	 * @return
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	@RequestMapping(value = "/partnership/partnershipAccountDelete")
	public String partnershipAccountDelete(final PartnershipDTO dto) throws JDOMException, IOException {
		String rtnMsg = "forward:/admin/partnership/partnershipAccountList";
		if(dto.getsAdminID() != null){
			partnershipDAO.deletePartnershipAccountInfo(dto.getsAdminID());
		}
		else{
			partnershipDAO.deletePartnershipAdminAccountInfo(dto);
			rtnMsg = "forward:/admin/partnership/partnershipAdminAccountList";
		}
		return rtnMsg;
	}
}
