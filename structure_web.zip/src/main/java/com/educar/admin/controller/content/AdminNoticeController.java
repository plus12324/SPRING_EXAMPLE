/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller.content;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dao.content.AdminNoticeDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.dto.web.NoticeDTO;

/**
 * �������� ���� ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@Controller(value = "/admin/notice")
public class AdminNoticeController {
	@Autowired
	private AdminNoticeDAO noticeDAO;
	@Autowired
	private AdminCommonService adminCommonService;

	/**
	 * �������� ���� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/notice/selectNoticeList")
	public ModelAndView selectNoticeList(final NoticeDTO dto) {
		final Integer totalCount = noticeDAO.selectNoticeListCount(dto);
		List<NoticeDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = noticeDAO.selectNoticeList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("contentMng/noticelist");
		return mv;
	}

	/**
	 * �������� ��� ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/notice/noticeRegisterInit")
	public ModelAndView noticeRegisterInit(final HttpSession session, final NoticeDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/notice_register");
		return mv;
	}

	/**
	 * �������� ���
	 * @return
	 */
	@RequestMapping(value = "/notice/noticeRegister")
	public String noticeRegister(final HttpSession session, final NoticeDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsRegId(loginInfo.getsName());
		dto.setsUpId(loginInfo.getsName());
		// üũ�ڽ� �� ����
		this.setCheckBox(dto);
		noticeDAO.insertNotice(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		return "forward:/admin/notice/selectNoticeList";
	}

	/**
	 * �������� ����ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/notice/noticeModifyInit")
	public ModelAndView noticeModifyInit(final HttpSession session, final NoticeDTO dto) {
		final ModelAndView mv = new ModelAndView();
		final NoticeDTO result = noticeDAO.selectNoticeInfo(dto.getnSeq());

		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());

		mv.addObject("result", result);
		mv.addObject("sRegiName", loginInfo.getsName());
		mv.setViewName("contentMng/notice_modify");
		return mv;
	}

	/**
	 * �������� ����
	 * @return
	 */
	@RequestMapping(value = "/notice/noticeModify")
	public String noticeModify(final HttpSession session, final NoticeDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsUpId(loginInfo.getsName());
		// üũ�ڽ� �� ����
		this.setCheckBox(dto);
		noticeDAO.updateNotice(dto);
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();

		return "forward:/admin/notice/selectNoticeList";
	}

	/**
	 * �������� ����
	 * @return
	 */
	@RequestMapping(value = "/notice/noticeDelete")
	public String noticeDelete(final NoticeDTO dto) {
		// ����
		noticeDAO.deleteAdminAccount(dto.getnSeq());

		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		return "forward:/admin/notice/selectNoticeList";
	}

	/**
	 * <pre>
	 * üũ�ڽ� ����
	 * �����ϰ�� N�� ����
	 * </pre>
	 * @param dto
	 */
	private void setCheckBox(final NoticeDTO dto) {
		// ��� ���� ����
		if (StringUtils.isBlank(dto.getsTopYn())) {
			dto.setsTopYn("N");
		}
		// PC���� ����
		if (StringUtils.isBlank(dto.getsPCViewYN())) {
			dto.setsPCViewYN("N");
		}
		// ����� ���� ����
		if (StringUtils.isBlank(dto.getsMobileViewYN())) {
			dto.setsMobileViewYN("N");
		}
	}
}
