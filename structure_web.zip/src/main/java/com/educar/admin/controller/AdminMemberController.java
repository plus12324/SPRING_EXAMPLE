/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.tuckey.web.filters.urlrewrite.utils.StringUtils;

import com.educar.admin.dao.memberMng.AdminMemberMngDAO;
import com.educar.admin.dto.commonMng.AdminAccountDTO;
import com.educar.admin.dto.memberMng.AdminMemberChgListDTO;
import com.educar.admin.dto.memberMng.AdminMemberInfoListDTO;
import com.educar.admin.dto.memberMng.AdminMemberJoinWithdrawListDTO;
import com.educar.admin.dto.memberMng.AdminMemberUnLockDTO;
import com.educar.admin.dto.memberMng.AdminSmsLogDTO;
import com.educar.admin.dto.memberMng.AdminSmsSendDTO;
import com.educar.admin.dto.memberMng.AdminSmsSpendFileDTO;
import com.educar.admin.dto.memberMng.EWEBLR002DTO;
import com.educar.admin.dto.memberMng.NVSendMailHistoryDTO;
import com.educar.admin.enumeration.AdminSessionNameEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.dto.PageDTO;
import com.educar.common.service.MessageSourceService;

/**
 * ȸ������ ��Ʈ�ѷ�
 * @author ���ѳ�
 * @since 1.0.0
 */
@Controller
public class AdminMemberController {
	@Autowired
	private AdminMemberMngDAO adminMemberMngDAO;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	@Autowired
	private AdminCommonService adminCommonService;
	/** Message Service */
	@Autowired
	private MessageSourceService messageService;
	
	private PlatformTransactionManager txManager;
	private final int TIME_OUT = 10;

	public void setTransactionManager(PlatformTransactionManager manager) {
		this.txManager = manager;
	}
	
	/**
	 * �����ŷ�ȸ������ - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/memberMng/selectMemberList")
	public ModelAndView selectMemberList(final AdminMemberInfoListDTO dto) {

		final Integer totalCount = adminMemberMngDAO.selectMemberInfoCount(dto);
		List<AdminMemberInfoListDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectMemberInfoList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/memberinfolist");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������ (����)
	 * @return
	 */
	@RequestMapping(value = "/memberMng/selectMemberExcel")
	public ModelAndView selectMemberExcel(final HttpServletResponse response, final AdminMemberInfoListDTO dto) {

		final Integer totalCount = adminMemberMngDAO.selectMemberInfoCount(dto);
		List<AdminMemberInfoListDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectMemberInfoList(dto);
		}
		final String fileName = "CUSAA01List.xls";
		final PageDTO pageDTO = dto;

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/memberinfolistExcel");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������ - �� ��ȸ ������
	 * @return
	 */
	@RequestMapping(value = "/memberMng/detailMemberInfo")
	public ModelAndView detailMemberInfo(final AdminMemberInfoListDTO dto) {
		//�⺻����
		final AdminMemberInfoListDTO baseInfo = adminMemberMngDAO.selectMemBaseInfo(dto);
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("baseInfo", baseInfo);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/memberinfoview");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������  - �⺻����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/defaltMemberInfo")
	public ModelAndView defaltMemberInfo(final AdminMemberInfoListDTO dto) {

		//������
		final AdminMemberInfoListDTO detailInfo = adminMemberMngDAO.selectMemDetailInfo(dto);

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", detailInfo);

		mv.setViewName("memberMng/memberinfoDefalt");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������ - �ּҺ��泻��
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/memberChgForAddr")
	public ModelAndView memberChgForAddr(final AdminMemberChgListDTO dto) {

		List<AdminMemberChgListDTO> chgAddrList = null;

		final Integer totalCount = adminMemberMngDAO.selectMemberChgAddrCnt(dto);
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			chgAddrList = adminMemberMngDAO.selectMemberChgAddrList(dto);
		}

		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("chgAddrList", chgAddrList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("ID", dto.getID());
		mv.setViewName("memberMng/memberinfoAddr");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������ - ��ȭ��ȣ ���泻��
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/memberChgForTel")
	public ModelAndView memberChgForTel(final AdminMemberChgListDTO dto) {
		List<AdminMemberChgListDTO> chgTelList = null;

		final Integer totalCount = adminMemberMngDAO.selectMemberChgTelCnt(dto);
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			chgTelList = adminMemberMngDAO.selectMemberChgTelList(dto);
		}

		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("chgTelList", chgTelList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("ID", dto.getID());
		mv.setViewName("memberMng/memberinfoTel");
		return mv;
	}
	/**
	 * �����ŷ�ȸ������ - �̸��� ���泻��
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/memberChgForEmail")
	public ModelAndView memberChgForEmail(final AdminMemberChgListDTO dto) {
		List<AdminMemberChgListDTO> chgEmailList = null;

		final Integer totalCount = adminMemberMngDAO.selectMemberChgEmailCnt(dto);
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			chgEmailList = adminMemberMngDAO.selectMemberChgEmailList(dto);
		}

		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("chgEmailList", chgEmailList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("ID", dto.getID());
		mv.setViewName("memberMng/memberinfoEmail");
		return mv;
	}
	/**
	 * ���ں� ȸ������/Ż����Ȳ
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/memberWithDraw")
	public ModelAndView memberWithDraw(final AdminMemberJoinWithdrawListDTO dto) {
		final DateTime dt = new DateTime();

		if(StringUtils.isBlank(dto.getsStartDate())){
			dto.setsStartDate(dt.plusMonths(-1).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getsEndDate())){
			dto.setsEndDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectMemberJoinWithDrawCnt(dto);
		List<AdminMemberJoinWithdrawListDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectMemberJoinWithDrawList(dto);
		}
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("condition", dto);
		mv.setViewName("memberMng/memberwithdraw");
		return mv;
	}
	/**
	 * ���ں� ȸ������/Ż����Ȳ(����)
	 * @return
	 */
	@RequestMapping(value = "/memberMng/memberWithDrawExcel")
	public ModelAndView memberWithDrawExcel(final HttpServletResponse response, final AdminMemberJoinWithdrawListDTO dto) {

		final List<AdminMemberJoinWithdrawListDTO> resultList = adminMemberMngDAO.selectMemberJoinWithDrawExcel(dto);

		final String fileName = "WEBDM01List.xls";

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.setViewName("memberMng/memberwithdrawExcel");
		return mv;
	}
	/**
	 * ȸ��Ż�� �̷�/����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/selectMemWithDrawReason")
	public ModelAndView selectMemWithDrawReason(final EWEBLR002DTO dto) {
		final DateTime dt = new DateTime();

		if(StringUtils.isBlank(dto.getStartDate())){
			dto.setStartDate(dt.toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getEndDate())){
			dto.setEndDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectMemberWithDrawReasonCnt(dto);
		List<EWEBLR002DTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectMemberWithDrawReasonList(dto);

			String reason = "";
			final StringBuilder sbReasonText = new StringBuilder();
			String reasonCode1 = "", reasonCode2 = "", reasonCode3 = "", reasonCode4 = "",
					reasonCode5 = "", reasonCode6 = "", reasonCode7 = "", reasonCode8 = "", reasonCode9 = "";
			String strReason = "";
			for(int i = 0; i < resultList.size(); i++){
				reason = resultList.get(i).getsReason();
				sbReasonText.setLength(0);
				//for(int j=0; j < reason.length(); i++){
				reasonCode1 = reason.substring(0,1).equals("1")?"���� ���� ����,":"";
				reasonCode2 = reason.substring(1,2).equals("1")?"���� ��ģ�� �� ����,":"";
				reasonCode3 = reason.substring(2,3).equals("1")?"���� �ý��� ����,":"";
				reasonCode4 = reason.substring(3,4).equals("1")?"���� ���� �Ҹ�,":"";
				reasonCode5 = reason.substring(4,5).equals("1")?"���ϴ� ��ǰ�� ã�� �����,":"";
				reasonCode6 = reason.substring(5,6).equals("1")?"���� ��ġ �Ҹ�,":"";
				reasonCode7 = reason.substring(6,7).equals("1")?"�������� ���� ���,":"";
				reasonCode8 = reason.substring(7,8).equals("1")?"ȸ������ �� ���� ����,":"";
				reasonCode9 = reason.substring(8,9).equals("1")?"��Ÿ,":"";

				sbReasonText.append(reasonCode1).append(reasonCode2).append(reasonCode3).append(reasonCode4)
				            .append(reasonCode5).append(reasonCode6).append(reasonCode7).append(reasonCode8).append(reasonCode9);
				strReason = sbReasonText.toString();
				if(strReason.length()>0){
					strReason = strReason.substring(0, strReason.length()-1);
				}
				resultList.get(i).setsReason(strReason);
			}
		}
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("condition", dto);
		mv.setViewName("memberMng/memberwithdrawreason");
		return mv;
	}
	/**
	 * ȸ��Ż�� �̷�/����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/selectMemWithDrawReasonExcel")
	public ModelAndView selectMemWithDrawReasonExcel(final HttpServletResponse response, final EWEBLR002DTO dto) {
		final DateTime dt = new DateTime();

		if(StringUtils.isBlank(dto.getStartDate())){
			dto.setStartDate(dt.plusMonths(-6).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getEndDate())){
			dto.setEndDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectMemberWithDrawReasonCnt(dto);
		List<EWEBLR002DTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectMemberWithDrawReasonList(dto);

			String reason = "";
			final StringBuilder sbReasonText = new StringBuilder();
			String reasonCode1 = "", reasonCode2 = "", reasonCode3 = "", reasonCode4 = "",
					reasonCode5 = "", reasonCode6 = "", reasonCode7 = "", reasonCode8 = "", reasonCode9 = "";
			String strReason = "";
			for(int i = 0; i < resultList.size(); i++){
				reason = resultList.get(i).getsReason();
				sbReasonText.setLength(0);
				reasonCode1 = reason.substring(0,1).equals("1")?"���� ���� ����,":"";
				reasonCode2 = reason.substring(1,2).equals("1")?"���� ��ģ�� �� ����,":"";
				reasonCode3 = reason.substring(2,3).equals("1")?"���� �ý��� ����,":"";
				reasonCode4 = reason.substring(3,4).equals("1")?"���� ���� �Ҹ�,":"";
				reasonCode5 = reason.substring(4,5).equals("1")?"���ϴ� ��ǰ�� ã�� �����,":"";
				reasonCode6 = reason.substring(5,6).equals("1")?"���� ��ġ �Ҹ�,":"";
				reasonCode7 = reason.substring(6,7).equals("1")?"�������� ���� ���,":"";
				reasonCode8 = reason.substring(7,8).equals("1")?"ȸ������ �� ���� ����,":"";
				reasonCode9 = reason.substring(8,9).equals("1")?"��Ÿ,":"";

				sbReasonText.append(reasonCode1).append(reasonCode2).append(reasonCode3).append(reasonCode4)
				            .append(reasonCode5).append(reasonCode6).append(reasonCode7).append(reasonCode8).append(reasonCode9);
				strReason = sbReasonText.toString();
				if(strReason.length()>0){
					strReason = strReason.substring(0, strReason.length()-1);
				}
				resultList.get(i).setsReason(strReason);
			}
		}

		final String fileName = "EWEBLR002List.xls";

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.setViewName("memberMng/memberwithdrawreasonExcel");
		return mv;
	}
	/**
	 * ���� ���� �߼� Ȯ��
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/sendMailList")
	public ModelAndView selectSendMailList(final NVSendMailHistoryDTO dto) {
		final DateTime dt = new DateTime();

		if(StringUtils.isBlank(dto.getStartDate())){
			dto.setStartDate(dt.toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getEndDate())){
			dto.setEndDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectSendMailListCnt(dto);
		List<NVSendMailHistoryDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectSendMailList(dto);
		}
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("condition", dto);
		mv.setViewName("memberMng/customeremailok");
		return mv;
	}
	/**
	 * ���� ���� �߼� Ȯ��(����)
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/sendMailListExcel")
	public ModelAndView selectSendMailExcel(final HttpServletResponse response, final NVSendMailHistoryDTO dto) {
		final DateTime dt = new DateTime();

		if(StringUtils.isBlank(dto.getStartDate())){
			dto.setStartDate(dt.plusMonths(-3).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(dto.getEndDate())){
			dto.setEndDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectSendMailListCnt(dto);
		List<NVSendMailHistoryDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectSendMailList(dto);
		}
		final String fileName = "NVSENDMAILHISTORY.xls";

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.setViewName("memberMng/customeremailokExcel");
		return mv;
	}
	/**
	 * ���� ���� �߼� Ȯ��(����)
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/sendMailView")
	public ModelAndView selectSendMailView(final HttpServletResponse response, final NVSendMailHistoryDTO dto) {

		final NVSendMailHistoryDTO result = adminMemberMngDAO.selectSendMailView(dto);

		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.setViewName("memberMng/customeremailok_view");
		return mv;
	}
	/**
	 * ���� ���� �߼� - ���� (HTML)
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/sendMailContent")
	public ModelAndView sendMailContents(final HttpServletResponse response, final HttpServletRequest request) throws IOException {

		final String strSerial = request.getParameter("serial");
		logger.debug(">>>>>>>>>>>>>>>>>>>>>" + strSerial);
		final NVSendMailHistoryDTO result = adminMemberMngDAO.selectSendMailContents(strSerial);
		final String content = result.getBODY_HTML();

		if (!StringUtils.isBlank(content)) {
			response.setCharacterEncoding("euc-kr");
			response.setContentType("text/html");
			response.getWriter().print(content);
		}
		return null;
	}

	/**
	 * SMS �뷮�߼� - �������
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSpendFileList")
	public ModelAndView selectSmsSpendFileList(final AdminSmsSpendFileDTO dto) {

		final Integer totalCount = adminMemberMngDAO.selectSmsSpendFileCnt(dto);
		List<AdminSmsSpendFileDTO> resultList = null;

		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectSmsSpendFileList(dto);
		}
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/smsspend_list");
		return mv;
	}
	/**
	 * SMS �뷮�߼� - ������ ���� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSpendFileDelete")
	public String selectSmsSpendFileDelete(final AdminSmsSpendFileDTO dto){
		
		final Integer totalCount = adminMemberMngDAO.deleteSmsFile(dto);

		if(totalCount > 0 ){
			this.selectSmsSpendFileList(dto);
		}
		// ����ĳ�� �ʱ�ȭ
		adminCommonService.clearQueryCache();
		return "forward:/admin/memberMng/smsSpendFileList";
	}
	/**
	 * SMS �뷮�߼� - �������_����ȭ�� �̵�
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSpendFileEditInit")
	public ModelAndView smsSpendFileEditInit(final HttpSession session, final AdminSmsSpendFileDTO dto) {
		
		AdminSmsSpendFileDTO result = null;
		if(dto.getsEditDiv().equals("m")){
			result = adminMemberMngDAO.selectSmsSpendFileInfo(dto);
		}
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		final ModelAndView mv = new ModelAndView();
		mv.addObject("result", result);
		mv.addObject("sRegiName", loginInfo.getsName());
		mv.addObject("sAdminID", loginInfo.getsEmployeeNumber());
		mv.addObject("sEditDiv", dto.getsEditDiv());
		mv.setViewName("memberMng/smsspend_modify");
		return mv;
	}
	/**
	 * SMS �뷮�߼� - ������ ���� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSpendFileEdit")
	public String smsSpendFileEdit(HttpServletRequest request, final AdminSmsSpendFileDTO dto){
		try {
			logger.info(">>>>>>>>>>>>>>>>>>>>>>  SMS �뷮�߼� ���� ���/���� start ");
			Hashtable<Object, Object> ht = AdminCommonService.fileToBinary(request, "smsFile");
			
			Map<Object, Object> dbparam = new HashMap<Object, Object>();
			if (ht != null && !ht.isEmpty()) {
				
				dbparam.put("sContent", ht.get("binaryFile"));
				dbparam.put("sFileName", ht.get("fileName"));
				dbparam.put("nFileSize", ((Long) ht.get("fileSize")).intValue() / 1024);

				String rtnvalue = (String) adminMemberMngDAO.insertBinaryFileInfo(dbparam);
				
				dbparam.put("nFileNum", rtnvalue);
				dbparam.put("sTitle", dto.getsTitle());
				dbparam.put("sAdminID", dto.getsAdminID());
				
				
				if(dto.getsEditDiv().equals("m")){
					dbparam.put("nSeq", dto.getnSeq());
					adminMemberMngDAO.updateSmsFile(dbparam);
				}else{
					adminMemberMngDAO.insertSmsFile(dbparam);
				}
			}
			
			logger.info(">>>>>>>>>>>>>>>>>>>>>>  SMS �뷮�߼� ���� ���/���� end");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "forward:/admin/memberMng/smsSpendFileList";
	}
	/**
	 * SMS �뷮�߼� - ������ ���� �ٿ�ε�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsFileDown")
	public ModelAndView smsFileDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		final String strSerial = request.getParameter("nFileNum");
		final AdminSmsSpendFileDTO dto = new AdminSmsSpendFileDTO();
		AdminSmsSpendFileDTO responseDto = null;
		if (!StringUtils.isBlank(strSerial)) {
		
			dto.setnFileNum(strSerial);
			responseDto = adminMemberMngDAO.getBinaryFileInfo(dto);

			if(!responseDto.getsFileName().equals(null)){
				String sFileName = responseDto.getsFileName();
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment; filename=" + java.net.URLEncoder.encode(sFileName, "utf-8") + ";");
				response.setHeader("Content-Transfer-Encoding", "binary");
				response.setHeader("Accept-Ranges", "bytes");
					
				byte[] content = null;
				try {
					content = responseDto.getsContent();
					BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(content));
					BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
					
					FileCopyUtils.copy(bis, bos);
				} catch (final IOException e) {
					throw new RuntimeException(e);
				}
				
			}
		}
		
		return null;
	}
	/**
	 * SMS �뷮�߼� - �߼۷α� ���
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSendLogList")
	public ModelAndView selectSmsSendLogList(final AdminSmsLogDTO dto) {
		final DateTime dt = new DateTime();
		if(StringUtils.isBlank(dto.getStartOpenDate())){
			dto.setStartOpenDate(dt.toString("yyyyMMdd"));
		}
		final Integer totalCount = adminMemberMngDAO.selectSmsSendLogCnt(dto);
		List<AdminSmsLogDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectSmsSendLogList(dto);
		}
		final ModelAndView mv = new ModelAndView();
		final PageDTO pageDTO = dto;
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.addObject("condition", dto);
		mv.setViewName("memberMng/smsspend_logolist");
		return mv;
	}
	/**
	 * SMS �뷮�߼� - SMS �뷮�߼� ȭ�� �̵�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSendInit")
	public ModelAndView smsSendInit(final AdminSmsSpendFileDTO dto) {

		List<AdminSmsSpendFileDTO> fileList = adminMemberMngDAO.selectSmsSpendFileList(dto);
		
		final ModelAndView mv = new ModelAndView();
		mv.addObject("fileList", fileList);
		mv.setViewName("memberMng/smsspend_msg");
		return mv;
	}
	/**
	 * SMS �뷮�߼� - SMS �뷮�߼� 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsSend")
	public ModelAndView smsSend(final AdminSmsSendDTO dto) {

		final AdminSmsSpendFileDTO requestFileNum = new AdminSmsSpendFileDTO();
		//final Calendar cal = Calendar.getInstance();
		//final SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSSSSS");
		requestFileNum.setnFileNum(dto.getnFileNum());
		final AdminSmsSpendFileDTO responseDto = adminMemberMngDAO.getBinaryFileInfo(requestFileNum);
		final byte[] btContent;
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		if(!responseDto.equals(null)){
			btContent = responseDto.getsContent();
			int contentCount = 0; // ���Ͽ� �ֹι�ȣ �ڵ�����ȣ ���� �����͸� ī��Ʈ �ϴ� ����
			if (btContent != null && btContent.length > 0) {
    			String sContent = new String(btContent);
    			String[] arrContent = sContent.split("\\n"); // �ֹι�ȣ ��ȭ��ȣ ���� �迭
    			
    			String[] values;
    			String sCustNo,sReceiverTel;
    			int smsSendCnt = 0;   // SMS �߼� ���� üũ �Ǽ�
    			
    			
    			/*Map<Object, Object> dbparam = new HashMap<Object, Object>();
    			int nSerial;
    			String sSerial;
    			DefaultTransactionDefinition td = null;
    			TransactionStatus status = null;*/
    			logger.info(">>>>>>>>>>>>>>>>>>>>>>1");
    			for(int i = 0; i < arrContent.length; i++){
    				values = (arrContent[i]).split("\\t");
    				
    				sCustNo 		= values[0].trim();
    				sReceiverTel 	= values[1].trim();
    				if(sCustNo.length() > 7){
    					sCustNo = sCustNo.substring(0, 7);
    				}
    				logger.info(">>>>>>>>>>>>>>>>>>>>>>2");
    				if (!StringUtils.isBlank(sCustNo) && !StringUtils.isBlank(sReceiverTel)) {
    
    					dto.setsCustNo(sCustNo);
    					dto.setsReceiverTel(sReceiverTel);
    					dto.setSEND_FLAG("Y");
    					smsSendCnt = adminMemberMngDAO.selectSmsSendYN(dto);
    					
    					if(smsSendCnt == 0){
    											
    						++contentCount;
    						/*
    						td = new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    						td.setIsolationLevel(TransactionDefinition.ISOLATION_SERIALIZABLE);
    						td.setTimeout(TIME_OUT);
    						status = txManager.getTransaction(td);
    						
    						dbparam.clear();
    						try {
    							nSerial = 163465358 + contentCount; //KeyUtil.getIntKey(".nSerial");
    						} catch (final Exception e) {
    							throw new RuntimeException("Key ������ �����Ͽ����ϴ�.");
    						}
    						try {
    							sSerial = "S" + KeyUtil.getStringKey("sSMSSerial");
    						} catch (final Exception e) {
    							throw new RuntimeException("Key ������ �����Ͽ����ϴ�.");
    						}
    						logger.info(">>>>>>>>>>>>>>>>>>>>>>");
    						logger.info(">>>>>>>>>>>>>>>>>>>>>> nSerial : " + nSerial + " / " + sSerial);
    						logger.info(">>>>>>>>>>>>>>>>>>>>>>");
    						dbparam.put("nSerial", nSerial);
    						dbparam.put("sDmCode", "S920");
    						dbparam.put("sType",   "3");
    						dbparam.put("sCustNo", sCustNo);
    						dbparam.put("nSeqNo", 0);
    						dbparam.put("sCellPhone1", dto.getsReceiverTel().substring(0, 3));
    						dbparam.put("sCellPhone2", dto.getsReceiverTel().substring(3, 7));
    						dbparam.put("sCellPhone3", dto.getsReceiverTel().substring(7, dto.getsReceiverTel().length()));
    						dbparam.put("sKeyType", "9");
    						dbparam.put("sRelKey", sCustNo);
    						dbparam.put("sStatus", "1");
    						dbparam.put("sContents", dto.getsMessage());
    						dbparam.put("sUserID", "8000001");
    						dbparam.put("sMsgID", sSerial);
    						dbparam.put("nTotPrem", 0);
    						dbparam.put("sPlateNo", "");
    						logger.info(">>>>>>>>>>>>>>>>>>>>>>3");
    						adminMemberMngDAO.insertSMSSendCCCIA04(dbparam);
    						*/
    						logger.info(">>>>>>>>>>>>>>>>>>>>>>4");
    						// �α׿� sms �߼� ť�� �����ϴ� ����
    						adminMemberMngDAO.insertSMSSendLog(dto);
    						adminMemberMngDAO.insertSMSSendQueue(dto);
    						
    					}
    				}
				}
			}else{
				mav.addObject("returnMSG", "�����Ͻ� ���Ͽ� ������ �����ϴ�.");
				mav.addObject("returnURL", "smsSendInit.do");
				
				//throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).build();
			}
			
			if (contentCount > 0) {
				mav.addObject("returnMSG", "�߼� �Ϸ�Ǿ����ϴ�.");
				mav.addObject("returnURL", "smsSendInit.do");
			}else{
				mav.addObject("returnMSG", "�̹� �߼�ó���� �Ǿ����ϴ�.");
				mav.addObject("returnURL", "smsSendInit.do");
			}
		}else{
			mav.addObject("returnMSG", " �߼��� ���������� ó������ ���߽��ϴ�.");
			mav.addObject("returnURL", "smsSendInit.do");
		}

		
		return mav;
	}
	/**
	 * SMS �뷮�߼� - SMS �뷮�߼� - �׽�Ʈ�߼�
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/memberMng/smsTestSend")
	public ModelAndView smsTestSend(final HttpSession session, final AdminSmsSendDTO dto) {
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		
		
		
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		
		dto.setsAdminID(loginInfo.getsEmployeeNumber());
		dto.setnFileNum("0");
		dto.setSEND_FLAG("Y");
		adminMemberMngDAO.insertSMSSendLog(dto);
		adminMemberMngDAO.insertSMSSendQueue(dto);

		mav.addObject("returnMSG", "�߼� �Ϸ�Ǿ����ϴ�.");
		mav.addObject("returnURL", "smsSendInit.do");
		return mav;
	}
	/**
	 * ��й�ȣ ���� ���� - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/memberMng/initErrorClear")
	public ModelAndView initErrorClear(final AdminMemberUnLockDTO dto) {

		final Integer totalCount = adminMemberMngDAO.selectPassUnlockCount(dto);
		List<AdminMemberUnLockDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectPassUnlockList(dto);
		}
		final PageDTO pageDTO = dto;

		final ModelAndView mv = new ModelAndView();
		mv.addObject("condition", dto);
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/certificationErrorClear");
		return mv;
	}
	/**
	 * ��й�ȣ ���� ���� (����)
	 * @return
	 */
	@RequestMapping(value = "/memberMng/initErrorClearExcel")
	public ModelAndView initErrorClearExcel(final HttpServletResponse response, final AdminMemberUnLockDTO dto) {

		final Integer totalCount = adminMemberMngDAO.selectPassUnlockCount(dto);
		List<AdminMemberUnLockDTO> resultList = null;
		if (totalCount != null && totalCount != 0) {
			dto.setTotalCount(totalCount);
			resultList = adminMemberMngDAO.selectPassUnlockList(dto);
		}
		final String fileName = "WEBDM01_password_err_member.xls";
		final PageDTO pageDTO = dto;

		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		final ModelAndView mv = new ModelAndView();
		mv.addObject("resultList", resultList);
		mv.addObject("pageDTO", pageDTO);
		mv.setViewName("memberMng/certificationErrorClearExcel");
		return mv;
	}
	/**
	 * ��й�ȣ ���� ���� - ��ȸ
	 * @return
	 */
	@RequestMapping(value = "/memberMng/setErrorClear")
	public ModelAndView setErrorClear(final HttpSession session, final AdminMemberUnLockDTO dto) {
		final AdminAccountDTO loginInfo = (AdminAccountDTO) session.getAttribute(AdminSessionNameEnum.ADMIN_LOGIN_INFO.toString());
		dto.setsFailClearID(loginInfo.getsEmployeeNumber());
		//��������
		adminMemberMngDAO.setPassUnlock(dto);

		
		final ModelAndView mav = new ModelAndView();
		mav.setViewName("common/message");
		mav.addObject("returnMSG", "�����Ǿ����ϴ�.");
		mav.addObject("returnURL", "/admin/memberMng/initErrorClear.do");
		
		return mav;
	}
}
