/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jxl.common.Logger;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.vo.FTPConnectionInfoVO;

/**
 * ������ ���� ����
 * @author ������
 * @since 1.0.0
 */
@Service
public class AdminCommonService {
	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;
	/** logger **/
	private Logger logger = Logger.getLogger(getClass());
	@Autowired
	private FTPService ftpService;
	/**
	 * ���� ĳ���� �����Ѵ�
	 */
	public void clearQueryCache() {
		final List<String> cacheClearUrlList = new ArrayList<String>();
		cacheClearUrlList.add(propertyService.getProperty(AdminSystemPropertyEnum.CACHE_CLEAR_WAS1_URL.getKey()));
		cacheClearUrlList.add(propertyService.getProperty(AdminSystemPropertyEnum.CACHE_CLEAR_WAS2_URL.getKey()));
		for (final String cacheClearUrl : cacheClearUrlList) {
			BufferedReader reader = null;
			try {
				final URL url = new URL(cacheClearUrl + "/admin/queryCache/clear");
				final URLConnection urlConnection = url.openConnection();
				urlConnection.setUseCaches(false);
				reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
			} catch (final IOException e) {
				logger.error("���� ĳ�� �ʱ�ȭ url���ῡ �����Ͽ����ϴ�.");
				throw new RuntimeException(e);
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (final Exception e) {
					}
				}
			}
		}
		logger.debug("���� ĳ�� �ʱ�ȭ �Ϸ�");
	}

	/**
	 * ���� �̸��� ����
	 * @param fileName
	 * @return
	 */
	public String getFileReName(final String fileName) {
		String returnValue = StringUtils.EMPTY;
		if (fileName != null && fileName.lastIndexOf(".") > 0) {
			final int lastIndex = fileName.lastIndexOf(".");
			returnValue = fileName.substring(0, lastIndex) + System.nanoTime() + "." + fileName.substring(lastIndex + 1);
		} else {
			returnValue = fileName;
		}
		return returnValue;
	}
	
	/**
	 * SMS ����  To Binary
	 * @param request
	 * @param fileNodeName
	 * @return
	 * @throws Exception
	 */
	public static Hashtable<Object, Object> fileToBinary(HttpServletRequest request, String fileNodeName)throws IOException{
		
		// ���� ���� request���� MultipartHttpServletRequest�� ���ε� ��Ų��.
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		// request�� "file"�� ã�� file��ü�� �����Ѵ�.
		MultipartFile file = multipartRequest.getFile(fileNodeName);
		
		Hashtable<Object, Object> ht = null;
		
		if (!file.isEmpty()) {
			
			String fileName = file.getOriginalFilename();
			long fileSize = file.getSize();
			
			// byte array ����� ���ؼ�

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			BufferedInputStream bis = new BufferedInputStream(file.getInputStream());
			BufferedOutputStream bos = new BufferedOutputStream(baos);
			
			// �� �Լ����� ���簡 ������ in out stream �� �ݾ��ش�
			FileCopyUtils.copy(bis, bos);
			
			byte[] binaryFile = baos.toByteArray();
			
			// ���� ���� �� ���� ��Ʈ��
			ht = new Hashtable<Object, Object>();
			ht.put("fileName", fileName);
			ht.put("fileSize", Long.valueOf(fileSize));
			ht.put("binaryFile", binaryFile);
			
		}
		
		return ht;
	}

	/**
	 * ���� ���ε� 
	 * @param file		��Ƽ ����
	 * @param subPath 	���ε� ���� ���
	 * @param reNameYn	���ϸ� ���� ����
	 * @return
	 */
	public void fileUpload(final MultipartFile file, final String subPath, final String reNameYn) {
		// ���� �̸�
		final String fileName;
		if(reNameYn.equals("Y")){
			fileName = this.getFileReName(file.getOriginalFilename());
		}else{
			fileName = file.getOriginalFilename();
		}
		// ���� ������
		byte[] bytes = null;
		try {
			bytes = file.getBytes();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}
		
		// FTP ���ε� ���� ���
		String fileBasePath = "";
		//������ ����� ��ġ
		final StringBuilder remoteFilePath = new StringBuilder();
		if(!reNameYn.equals("E")){
			fileBasePath= propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey())+subPath;
			remoteFilePath.append(fileBasePath);
		}
		else{
			fileBasePath= propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey());
			remoteFilePath.append(fileBasePath+subPath);
		}
		
		//��ũ URL
		final StringBuilder fileURL = new StringBuilder();
		fileURL.append(subPath);

		remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileName);
		fileURL.append(FTPService.FILE_SEPARATOR).append(fileName);
		// FTP�� WEBTOB�� ����
		for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
			
			// ���丮�� ������� ����
			if(!reNameYn.equals("E"))
				ftpService.makeDirectory(webtobConnection, fileBasePath);
			else{
				String[] tmpPath = {subPath};
				ftpService.makeDirectory(webtobConnection, fileBasePath, tmpPath);
			}
			// ���ε�
			logger.debug(webtobConnection.getIp() +"/" + webtobConnection.getId() + "/" );
			ftpService.upload(webtobConnection, bytes, remoteFilePath.toString());
		}
	}
}
