/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.service.commonMng;

import java.io.*;

import org.jdom2.*;
import org.jdom2.output.*;
import org.jdom2.input.*;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.educar.admin.dao.commonMng.PartnershipDAO;
import com.educar.admin.dto.commonMng.PartnershipDTO;
import com.educar.admin.enumeration.AdminSystemPropertyEnum;
import com.educar.admin.service.AdminCommonService;
import com.educar.common.service.ApplicationContextProvider;
import com.educar.common.service.DistributedCacheService;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.common.util.XMLUtil;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.common.vo.JehuCodeVO;
import com.educar.enumeration.CacheEnum;
import com.educar.enumeration.CacheKeyEnum;
import com.educar.enumeration.ResponseContentEnum;
import com.educar.exception.InvalidRequestException;

/**
 * ���޻� ���� ����	
 * @author ������	
 * @since 1.0.0	
 */
@Service
public class PartnershipService {
	/** ����ó ���� DAO **/
	@Autowired
	PartnershipDAO partnershipDAO;
	/** ������ ���뼭�� **/
	@Autowired
	AdminCommonService adminCommonService;
	/** FTP ���� **/
	@Autowired
	FTPService ftpService;
	/** ������Ƽ ���� **/
	@Autowired
	PropertyService propertyService;
	/** jehuXml.xml ĳ�� ������� **/
	@Autowired
	private DistributedCacheService cacheService;

	private enum ImageFolderEnum {
		/** **/
		LOGO("logo"),
		/** **/
		MEMBER_SHIP("memberShip"),
		/** **/
		SAVING("saving"),
		/** **/
		BEST("best"),
		/** **/
		MOBILE("mobile"),
		/** **/
		MEMBER_SHIP2("memberShip2"),
		/** **/
		MAIN("main");

		private String folderName;

		private ImageFolderEnum(final String folderName) {
			this.folderName = folderName;
		}

		public String getFolderName() {
			return this.folderName;
		}
	}

	/**
	 * ���޻� ���
	 * @param dto
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	public void partnershipRegister(final PartnershipDTO dto) throws JDOMException, IOException {
		jehuXmlSave(dto,"insert");
		
		// ���� ���ε� �� �̹���rename, �̹���URL ����
		final PartnershipDTO result = this.fileUpload(dto);
		// üũ�ڽ��� ���� ����
		this.setCheckboxValue(dto);
		// insert
		partnershipDAO.insertPartnership(result);
	}
	 
	
	/**
	 * jehuXml.xml �Ľ� IOó��
	 * @param dto
	 * @param saveFlag
	 * @throws JDOMException
	 * @throws IOException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void jehuXmlSave(final PartnershipDTO dto, String saveFlag) throws JDOMException, IOException{
		SAXBuilder builder = new SAXBuilder();
		String jehuXmlPath = propertyService.getProperty("admin.jehu.jehuXmlPath");
		Document doc 	   = builder.build(jehuXmlPath);
		Element data   	   = new Element("data");
		Element root 	   = doc.getRootElement();
		List dataList 	   = root.getChildren();
		
		if(dataList != null)
		{
			if("insert".equals(saveFlag)){
				for(int i=0 ; i<dataList.size() ; i++)
				{
					data 			= (Element) dataList.get(i);
					String dataAttr = data.getAttributeValue("hashkey");
					//������Ʈ data �Ӽ� hashkey �� �ߺ� Ȯ��
					if(dto.getsHashkey().equals(dataAttr)){
						throw new InvalidRequestException.Builder("data �Ӽ��� : "+ dataAttr +"�� �ߺ��Ǿ����ϴ�.").responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
					}
				}
				
				Element newData   = new Element("data");
				newData.setAttribute("hashkey", dto.getsHashkey());
				root.addContent(newData);
				
				Element newMoneta = new Element(dto.getsHashkey());
				newData.addContent(newMoneta);
				
				//�űԿ�����Ʈ ����
				Element xmlFileYn 				= new Element("xmlFileYn");
				Element xmlFile 				= new Element("xmlFile");
				Element sContactPath 			= new Element("sContactPath");
				Element sEventDiv 				= new Element("sEventDiv");
				Element sUserID 				= new Element("sUserID");
				Element sUserNm 				= new Element("sUserNm");
				Element sAffiliatedConcern 		= new Element("sAffiliatedConcern");
				Element onePageYn 				= new Element("onePageYn");
				Element onePageInsuranceType 	= new Element("onePageInsuranceType");
				Element riaPopTitleImgName 		= new Element("riaPopTitleImgName");
				Element homepageJehuYn 			= new Element("homepageJehuYn");
				Element landingYn 				= new Element("landingYn");
				
				//�� value�Ӽ��� ���ε�
				xmlFileYn.setAttribute				("value", "");
				xmlFile.setAttribute				("value", "");
				sContactPath.setAttribute			("value", dto.getsContactPath());
				sEventDiv.setAttribute				("value", dto.getsEventDiv());
				sUserID.setAttribute				("value", dto.getsUserID());
				sUserNm.setAttribute				("value", dto.getsAffiliatedConcernName());
				sAffiliatedConcern.setAttribute		("value", dto.getsAffiliatedConcern());
				onePageYn.setAttribute				("value", "");
				onePageInsuranceType.setAttribute	("value", "");
				riaPopTitleImgName.setAttribute		("value", "");
				homepageJehuYn.setAttribute			("value", dto.getsHomepageJehuYn());
				landingYn.setAttribute				("value", "");
				
				//��ҿϼ�
				newMoneta.addContent(xmlFileYn);
				newMoneta.addContent(xmlFile);
				newMoneta.addContent(sContactPath);
				newMoneta.addContent(sEventDiv);
				newMoneta.addContent(sUserID);
				newMoneta.addContent(sUserNm);
				newMoneta.addContent(sAffiliatedConcern);
				newMoneta.addContent(onePageYn);
				newMoneta.addContent(onePageInsuranceType);
				newMoneta.addContent(riaPopTitleImgName);
				newMoneta.addContent(homepageJehuYn);
				newMoneta.addContent(landingYn);
			}
			else if("delete".equals(saveFlag)){
				for(int i=0 ; i<dataList.size() ; i++)
				{
					data 			= (Element) dataList.get(i);
					String dataAttr = data.getAttributeValue("hashkey");
					
					if(dto.getsHashkey().equals(dataAttr)){
						//��Ҹ� ������
						dataList.remove(i);
					}
				}
			}
			else{
				List monetaList = null;
				
				for(int i=0 ; i<dataList.size() ; i++)
				{
					data 			= (Element) dataList.get(i);
					String dataAttr = data.getAttributeValue("hashkey");
					
					//�ش��ϴ� hashkey�Ӽ��� �ش��ϴ� �ڽĳ�� value�Ӽ� ����
					if(dto.getsHashkey().equals(dataAttr)){
						monetaList = ((Element)data.getChildren().get(0)).getChildren();
						((Element)monetaList.get(0)).setAttribute ("value", "");								//xmlFileYn
						((Element)monetaList.get(1)).setAttribute ("value", "");								//xmlFile
						((Element)monetaList.get(2)).setAttribute ("value", dto.getsContactPath());				//sContactPath
						((Element)monetaList.get(3)).setAttribute ("value", dto.getsEventDiv());				//sEventDiv
						((Element)monetaList.get(4)).setAttribute ("value", dto.getsUserID());					//sUserID
						((Element)monetaList.get(5)).setAttribute ("value", dto.getsAffiliatedConcernName());	//sUserNm
						((Element)monetaList.get(6)).setAttribute ("value", dto.getsAffiliatedConcern());		//sAffiliatedConcern
						((Element)monetaList.get(7)).setAttribute ("value", "");								//onePageYn
						((Element)monetaList.get(8)).setAttribute ("value", "");								//onePageInsuranceType
						((Element)monetaList.get(9)).setAttribute ("value", "");								//riaPopTitleImgName
						((Element)monetaList.get(10)).setAttribute("value", dto.getsHomepageJehuYn());			//homepageJehuYn
						((Element)monetaList.get(11)).setAttribute("value", "");								//landingYn
					}
				}
			}
			
			XMLOutputter out = new XMLOutputter();
			Format f 		 = out.getFormat();
			f.setEncoding("euc-kr");						//�ѱ�ó��
			f.setLineSeparator("\n");						//����鿩����
			f.setIndent("\t");								//�鿩����
			f.setTextMode(Format.TextMode.TRIM);			//Text�� ���� �ڵ� �ٹٲ�����
			out.setFormat(f); 								//���ο� Format���� ����
			out.output(doc, new FileWriter(jehuXmlPath));	//���� ����
			
			//jehuXml.xml ĳ�� ������
			final Map<String, Object> jehuMap = XMLUtil.getResultMap(XMLUtil.loadXML("META-INF/code/jehuXml.xml"));
			final Map<String, JehuCodeVO> jehuCodeMap = new HashMap<String, JehuCodeVO>();
			for (final String key : jehuMap.keySet()) {
				if (Map.class.isAssignableFrom(jehuMap.get(key).getClass())) {
					jehuCodeMap.put(key, XMLUtil.getResultObject(JehuCodeVO.class, (Map<String, Object>) jehuMap.get(key)));
				}
			}
			final Cache codeCache = cacheService.getCache(CacheEnum.CODE_CACHE_MAP.getName());			
			codeCache.put(CacheKeyEnum.JEHU_CODE.name(), jehuCodeMap);
		}
		else{
			throw new InvalidRequestException.Builder("jehuXml.xml �� ������ ����ų� �������� �ʽ��ϴ�.").responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
		}
	}

	/**
	 * ���޻� ����
	 * @param dto
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	public void partnershipModify(final PartnershipDTO dto) throws JDOMException, IOException {
		
		jehuXmlSave(dto,"update");
		
		// ���� ���ε� �� �̹���rename, �̹���URL ����
		final PartnershipDTO result = this.fileUpload(dto);
		// üũ�ڽ��� ���� ����
		this.setCheckboxValue(dto);
		// update
		partnershipDAO.updatePartnershipInfo(result);
	}
	
	/**
	 * ���޻� ����
	 * @param dto
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	public void partnershipDelete(final PartnershipDTO dto) throws JDOMException, IOException {
		
		jehuXmlSave(dto,"delete");
		
		// delete       
		partnershipDAO.deletePartnershipInfo(dto);
	}

	/**
	 * üũ�ڽ��� ���� �����Ѵ�.
	 * @param dto
	 */
	private void setCheckboxValue(final PartnershipDTO dto) {
		dto.setsCarCalc(this.getCheckboxValue(dto.getsCarCalc()));
		dto.setsCarCounsel(this.getCheckboxValue(dto.getsCarCounsel()));
		dto.setsGeneralCalc(this.getCheckboxValue(dto.getsGeneralCalc()));
		dto.setsGeneralCounsel(this.getCheckboxValue(dto.getsGeneralCounsel()));
		dto.setsLongCounsel(this.getCheckboxValue(dto.getsLongCounsel()));
	}

	/**
	 * üũ�ڽ��� ���� ��ȯ. ������ ��� 0�� ��ȯ
	 * @param value
	 * @return
	 */
	private String getCheckboxValue(String value) {
		if (StringUtils.isBlank(value)) {
			value = BigInteger.ZERO.toString();
		}
		return value;
	}

	/**
	 * ���� ���ε� �� �̹��� rename, �̹���URL ����
	 * @param dto
	 * @return
	 */
	private PartnershipDTO fileUpload(final PartnershipDTO dto) {
		// ����ó �ڵ�
		final String sAffiliatedConcernCode = dto.getsAffiliatedConcern();
		final String jehuContentRootPath = propertyService.getProperty(AdminSystemPropertyEnum.WEBTOB_BASE.getKey());
		final String jehuContentSubPath = propertyService.getProperty(AdminSystemPropertyEnum.JEHU_CONTENT_SUB.getKey());
		// ������ ����� root path
		final StringBuilder remotePath = new StringBuilder();
		remotePath.append(jehuContentRootPath).append(jehuContentSubPath);

		final DateTime dt = new DateTime();
		final String year = dt.toString("yyyy");
		final String month = dt.toString("MM");

		final Map<ImageFolderEnum, MultipartFile> imageFileMap = new HashMap<ImageFolderEnum, MultipartFile>();
		final Map<ImageFolderEnum, String> fileNameMap = new HashMap<ImageFolderEnum, String>();
		for (final ImageFolderEnum folderEnum : ImageFolderEnum.values()) {
			MultipartFile file = null;
			switch (folderEnum) {
				case LOGO:
					file = dto.getLogoImageFile();
					break;
				case MEMBER_SHIP:
					file = dto.getMemberShipImageFile();
					break;
				case SAVING:
					file = dto.getSavingImageFile();
					break;
				case BEST:
					file = dto.getBestImageFile();
					break;
				case MOBILE:
					file = dto.getMobileImageFile();
					break;
				case MEMBER_SHIP2:
					file = dto.getMemberShip2ImageFile();
					break;
				case MAIN:
					file = dto.getMainImageFile();
					break;
			}
			if (file != null && !file.isEmpty()) {
				imageFileMap.put(folderEnum, file);
				fileNameMap.put(folderEnum, adminCommonService.getFileReName(file.getOriginalFilename()));
			}
		}
		// ����, ���� WEBTOB�� FTP ����
		for (final FTPConnectionInfoVO webtobConnection : ftpService.getWebtoBConnectionInfoList()) {
			for (final ImageFolderEnum folderEnum : imageFileMap.keySet()) {
				final MultipartFile file = imageFileMap.get(folderEnum);
				if (file == null || file.isEmpty()) {
					continue;
				}
				byte[] localFileData = null;
				try {
					localFileData = file.getBytes();
				} catch (final IOException e) {
					throw new RuntimeException(e);
				}
				// ���丮�� ������ �����Ѵ�.
				final String[] makeRemotePaths = { sAffiliatedConcernCode, folderEnum.getFolderName(), year, month };
				ftpService.makeDirectory(webtobConnection, remotePath.toString(), makeRemotePaths);

				// �̹��� ���
				final StringBuilder imageURL = new StringBuilder();
				imageURL.append(jehuContentSubPath);
				// ������ ����� ��ġ
				final StringBuilder remoteFilePath = new StringBuilder();
				remoteFilePath.append(remotePath.toString());
				for (final String path : makeRemotePaths) {
					remoteFilePath.append(FTPService.FILE_SEPARATOR).append(path);
					imageURL.append(FTPService.FILE_SEPARATOR).append(path);
				}
				// �����̸�
				final String fileRename = fileNameMap.get(folderEnum);
				remoteFilePath.append(FTPService.FILE_SEPARATOR).append(fileRename);
				// �̹��� rename, �̹���URL ����
				switch (folderEnum) {
					case LOGO:
						dto.setsLogoImageURL(imageURL.toString());
						dto.setsLogoImageName(fileRename);
						break;
					case MEMBER_SHIP:
						dto.setsMembershipImageURL(imageURL.toString());
						dto.setsMembershipImageName(fileRename);
						break;
					case SAVING:
						dto.setsSavingImageURL(imageURL.toString());
						dto.setsSavingImageName(fileRename);
						break;
					case BEST:
						dto.setsBestImageURL(imageURL.toString());
						dto.setsBestImageName(fileRename);
						break;
					case MOBILE:
						dto.setsMobileImageURL(imageURL.toString());
						dto.setsMobileImageName(fileRename);
						break;
					case MEMBER_SHIP2:
						dto.setsMembership2ImageURL(imageURL.toString());
						dto.setsMembership2ImageName(fileRename);
						break;
					case MAIN:
						dto.setsMainImageURL(imageURL.toString());
						dto.setsMainImageName(fileRename);
						break;
				}
				// ���� ���ε�
				ftpService.upload(webtobConnection, localFileData, remoteFilePath.toString());
			}
		}
		return dto;
	}
}
