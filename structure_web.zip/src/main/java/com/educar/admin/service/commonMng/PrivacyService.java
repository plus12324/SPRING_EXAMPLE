/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.service.commonMng;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educar.admin.dao.commonMng.PrivacyDAO;
import com.educar.admin.dto.commonMng.PrivacyDTO;
import com.educar.admin.dto.commonMng.PrivacyHistoryDTO;
import com.educar.admin.service.AdminCommonService;

/**
 * ��� ���� ����
 * @author ������
 * @since 1.0.0
 */
@Service
public class PrivacyService {
	@Autowired
	private PrivacyDAO privacyDAO;

	@Autowired
	private AdminCommonService adminCommonService;

	/**
	 * ��� ����
	 * @param dto
	 */
	public void privacyModify(final PrivacyDTO dto) {
		// ��� ����
		privacyDAO.updatePrivacyInfo(dto);
		final PrivacyHistoryDTO history = new PrivacyHistoryDTO();
		BeanUtils.copyProperties(dto, history);
		if (StringUtils.isNotBlank(dto.getsRegiDate())) {
			history.setsOpenDate(dto.getsRegiDate().replaceAll("\\.", ""));
		}

		// �̷� ���
		privacyDAO.insertPrivacyHistory(history);

		// ���� ĳ�� ����
		adminCommonService.clearQueryCache();
	}
}
