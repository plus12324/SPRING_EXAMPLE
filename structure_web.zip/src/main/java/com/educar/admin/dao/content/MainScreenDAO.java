/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.main.MenuDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ����ȭ�� ���� DAO
 * @author ������
 * @since 1.0.0
 */
@Repository
public class MainScreenDAO extends EgovComAbstractDAO {
	/**
	 * �޴� ����Ʈ�� ��ȸ�Ѵ�
	 * @param menuType �޴� Ÿ��
	 * @return �޴�����Ʈ
	 */
	@SuppressWarnings("unchecked")
	public List<MenuDTO> getMenuList(final String menuType) {
		return list("mainScreen.selectMenuList", menuType);
	}

	/**
	 * ���� ����
	 * @param dto
	 * @return
	 */
	public int updateMenuOrder(final List<MenuDTO> dtoList) {
		return update("mainScreen.updateMenuOrder", dtoList);
	}

	/**
	 * �޴� ���
	 * @param dto
	 * @return null
	 */
	public Object insertMenu(final MenuDTO dto) {
		return insert("mainScreen.insertMenu", dto);
	}

	/**
	 * �޴� ����
	 * @param
	 * @return
	 */
	public int deleteMenu(final List<Long> nSeqList) {
		return delete("mainScreen.deleteMenu", nSeqList);
	}

	/**
	 * �޴� �Ѱ� ��ȸ
	 * @return
	 */
	public MenuDTO selectMenu(final Long nSeq) {
		return (MenuDTO) selectByPk("mainScreen.selectMenu", nSeq);
	}

	/**
	 * �޴� ����
	 * @param dto
	 * @return
	 */
	public int updateMenu(final MenuDTO dto) {
		return update("mainScreen.updateMenu", dto);
	}
}
