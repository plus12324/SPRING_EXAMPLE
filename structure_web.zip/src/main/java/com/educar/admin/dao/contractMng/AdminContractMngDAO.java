/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.contractMng;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.contractMng.AdminCarContractDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ������ DAO
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminContractMngDAO extends EgovComAbstractDAO {
	/**
	 * �����ŷ�ȸ�� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectCarContractCount(final AdminCarContractDTO dto) {
		return (Integer) selectByPk("adminContractMng.selectCarContractCount", dto);
	}
	/**
	 * �����ŷ�ȸ�� ����Ʈ ��ȸ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminCarContractDTO> selectCarContractList(final AdminCarContractDTO dto) {
		return list("adminContractMng.selectCarContractList", dto);
	}
	
}
