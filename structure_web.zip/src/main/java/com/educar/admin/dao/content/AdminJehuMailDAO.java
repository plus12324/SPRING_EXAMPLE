/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.content.AffiliatedRequestDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ������� ������
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminJehuMailDAO extends EgovComAbstractDAO {
	/**
	 * ���ϸ�� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectJehuMailListCount(final AffiliatedRequestDTO dto) {
		return (Integer) selectByPk("adminJehuMail.selectJehuMailListCount", dto);
	}

	/**
	 * ���ϸ��  ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AffiliatedRequestDTO> selectJehuMailList(final AffiliatedRequestDTO dto) {
		return list("adminJehuMail.selectJehuMailList", dto);
	}
	
	/**
	 * ������ �󼼺��� ��ȸ
	 * @param dto
	 * @return
	 */
	public AffiliatedRequestDTO selectJehuMailInfo(final AffiliatedRequestDTO dto) {
		return (AffiliatedRequestDTO) selectByPk("adminJehuMail.selectJehuMailInfo", dto);
	}
	
}
