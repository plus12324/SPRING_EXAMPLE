/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.content.AdminBalancesheetDTO;
import com.educar.admin.dto.content.AdminBiddingDTO;
import com.educar.admin.dto.content.AdminOccasionalDTO;
import com.educar.admin.dto.content.AdminRegularMngDisclosureDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * �濵���� DAO
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminDisclosureDAO extends EgovComAbstractDAO {
	/**
	 * ����濵���� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectRegularMngDisclsCnt(final AdminRegularMngDisclosureDTO dto) {
		return (Integer) selectByPk("adminDisclosure.selectMngDisclosuerCount", dto);
	}

	/**
	 * ����濵����  ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminRegularMngDisclosureDTO> selectRegularMngDisclsList(final AdminRegularMngDisclosureDTO dto) {
		return list("adminDisclosure.selectMngDisclosuerList", dto);
	}
	/**
	 * ����濵���� �Ѱ� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminRegularMngDisclosureDTO selectRegularMngDiscls(final AdminRegularMngDisclosureDTO dto) {
		return (AdminRegularMngDisclosureDTO) selectByPk("adminDisclosure.selectMngDisclosuer", dto);
	}
	/**
	 * ����濵���� ���
	 * @param dto
	 * @return
	 */
	public Object insertRegularMngDiscls(final AdminRegularMngDisclosureDTO dto) {
		return insert("adminDisclosure.insertRegularInfo", dto);
	}
	
	/**
	 * ����濵���� ����
	 * @param dto
	 * @return
	 */
	public int updateRegularMngDiscls(final AdminRegularMngDisclosureDTO dto) {
		return update("adminDisclosure.updateRegularInfo", dto);
	}
	/**
	 * ����濵���� ����
	 * @param dto
	 * @return
	 */
	public int deleteRegularMngDiscls(final AdminRegularMngDisclosureDTO dto) {
		return delete("adminDisclosure.deleteRegularInfo", dto);
	}
	/**
	 * ���ð濵���� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectOccasionalCount(final AdminOccasionalDTO dto) {
		return (Integer) selectByPk("adminDisclosure.selectOccasionalCount", dto);
	}

	/**
	 * ���ð濵����  ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminOccasionalDTO> selectOccasionalList(final AdminOccasionalDTO dto) {
		return list("adminDisclosure.selectOccasionalList", dto);
	}
	/**
	 * ���ð濵���� �Ѱ� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminOccasionalDTO selectOccasionalInfo(final AdminOccasionalDTO dto) {
		return (AdminOccasionalDTO) selectByPk("adminDisclosure.selectOccasionalInfo", dto);
	}
	/**
	 * ���ð濵���� ���
	 * @param dto
	 * @return
	 */
	public Object insertOccasional(final AdminOccasionalDTO dto) {
		int intSeq = (Integer) selectByPk("adminDisclosure.getMaxInsertCnt", null);
		dto.setSeq(String.valueOf(intSeq));
		return insert("adminDisclosure.insertOccasional", dto);
	}
	
	/**
	 * ���ð濵���� ����
	 * @param dto
	 * @return
	 */
	public int updateOccasional(final AdminOccasionalDTO dto) {
		return update("adminDisclosure.updateOccasional", dto);
	}
	/**
	 * ���ð濵���� ����
	 * @param dto
	 * @return
	 */
	public int deleteOccasional(final AdminOccasionalDTO dto) {
		return delete("adminDisclosure.deleteOccasional", dto);
	}
	/**
	 * ��������ǥ �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectBalancesheetCnt(final AdminBalancesheetDTO dto) {
		return (Integer) selectByPk("adminDisclosure.selectBalancesheetCount", dto);
	}

	/**
	 * ��������ǥ  ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminBalancesheetDTO> selectBalancesheetList(final AdminBalancesheetDTO dto) {
		return list("adminDisclosure.selectBalancesheetList", dto);
	}
	/**
	 * ��������ǥ �Ѱ� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminBalancesheetDTO selectBalancesheet(final AdminBalancesheetDTO dto) {
		return (AdminBalancesheetDTO) selectByPk("adminDisclosure.selectBalancesheet", dto);
	}
	/**
	 * ��������ǥ ���
	 * @param dto
	 * @return
	 */
	public Object insertBalancesheet(final AdminBalancesheetDTO dto) {
		int intSeq = (Integer) selectByPk("adminDisclosure.getMaxInsertCnt2", null);
		dto.setnSeq(String.valueOf(intSeq));
		return insert("adminDisclosure.insertBalancesheet", dto);
	}
	
	/**
	 * ��������ǥ ����
	 * @param dto
	 * @return
	 */
	public int updateBalancesheet(final AdminBalancesheetDTO dto) {
		return update("adminDisclosure.updateBalancesheet", dto);
	}
	/**
	 * ��������ǥ ����
	 * @param dto
	 * @return
	 */
	public int deleteBalancesheet(final AdminBalancesheetDTO dto) {
		return delete("adminDisclosure.deleteBalancesheet", dto);
	}
	/**
	 * �������� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectBiddingCnt(final AdminBiddingDTO dto) {
		return (Integer) selectByPk("adminDisclosure.selectBiddingCount", dto);
	}

	/**
	 * ��������  ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminBiddingDTO> selectBiddingList(final AdminBiddingDTO dto) {
		return list("adminDisclosure.selectBiddingList", dto);
	}
	/**
	 * �������� �Ѱ� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminBiddingDTO selectBidding(final AdminBiddingDTO dto) {
		return (AdminBiddingDTO) selectByPk("adminDisclosure.selectBidding", dto);
	}
	/**
	 * �������� ���
	 * @param dto
	 * @return
	 */
	public Object insertBidding(final AdminBiddingDTO dto) {
		return insert("adminDisclosure.insertBidding", dto);
	}
	
	/**
	 * �������� ����
	 * @param dto
	 * @return
	 */
	public int updateBidding(final AdminBiddingDTO dto) {
		return update("adminDisclosure.updateBidding", dto);
	}
	/**
	 * �������� ����
	 * @param dto
	 * @return
	 */
	public int deleteBidding(final AdminBiddingDTO dto) {
		return delete("adminDisclosure.deleteBidding", dto);
	}
}
