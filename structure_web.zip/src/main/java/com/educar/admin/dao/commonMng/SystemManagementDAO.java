package com.educar.admin.dao.commonMng;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.LoginUrlDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * �ý��۰��� DAO
 * @author �Ž¿�
 * @since 1.0.0
 */
@Repository
public class SystemManagementDAO extends EgovComAbstractDAO  {

	/**
	 * �α��ΰ��� url ���
	 * @param dto
	 * @return
	 */
	public Object insertLoginUrl(final LoginUrlDTO dto) {
		return insert("adminNotice.insertLoginUrl", dto);
	}
	
	/**
	 * �α��ΰ��� url ����
	 * @param dto
	 * @return
	 */
	public Object deleteLoginUrl(final LoginUrlDTO dto) {
		return delete("adminNotice.deleteLoginUrl", dto);
	}
	
}
