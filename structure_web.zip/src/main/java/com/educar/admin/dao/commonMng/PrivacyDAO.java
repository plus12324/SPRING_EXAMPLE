/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.commonMng;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.commonMng.PrivacyDTO;
import com.educar.admin.dto.commonMng.PrivacyHistoryDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ������� DAO
 * @author ������
 * @since 1.0.0
 */
@Repository
public class PrivacyDAO extends EgovComAbstractDAO {
	/**
	 * ��� ��� ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PrivacyDTO> selectPrivacyList(final PrivacyDTO dto) {
		return list("privacy.selectPrivacyList", dto);
	}
	/**
	 * ��� ��� �Ǽ�
	 * @param dto
	 * @return
	 */
	public Integer selectPrivacyCount(final PrivacyDTO dto) {
		return (Integer) selectByPk("privacy.selectPrivacyCount", dto);
	}
	/**
	 * ��� �̷� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectPrivacyHistoryCount(final PrivacyHistoryDTO dto) {
		return (Integer) selectByPk("privacy.selectPrivacyHistoryCount", dto);
	}

	/**
	 * ��� �̷� ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PrivacyHistoryDTO> selectPrivacyHistoryList(final PrivacyHistoryDTO dto) {
		return list("privacy.selectPrivacyHistoryList", dto);
	}

	/**
	 * ��� �̷� �� ��ȸ
	 * @param nSeq �Ϸù�ȣ
	 * @return PrivacyHistoryDTO
	 */
	public PrivacyHistoryDTO selectPrivacyHistoryInfo(final long nSeq) {
		return (PrivacyHistoryDTO) selectByPk("privacy.selectPrivacyHistoryInfo", nSeq);
	}

	/**
	 * Ű ������ �Ѱ��� �����͸� ��ȸ
	 * @param nSeq �Ϸù�ȣ
	 * @return PartnershipDTO
	 */
	public PrivacyDTO selectPrivacyInfo(final long nSeq) {
		return (PrivacyDTO) selectByPk("privacy.selectPrivacyInfo", nSeq);
	}

	/**
	 * ��� ����
	 * @param dto
	 * @return
	 */
	public int updatePrivacyInfo(final PrivacyDTO dto) {
		return update("privacy.updatePrivacyInfo", dto);
	}

	/**
	 * ��� �̷� ���
	 * @param dto
	 * @return null
	 */
	public Object insertPrivacyHistory(final PrivacyHistoryDTO dto) {
		return insert("privacy.insertPrivacyHistory", dto);
	}
	/**
	 * ��� ���
	 * @param dto
	 * @return
	 */
	public int insertPrivacyInfo(final PrivacyDTO dto) {
		return update("privacy.insertPrivacyInfo", dto);
	}


}
