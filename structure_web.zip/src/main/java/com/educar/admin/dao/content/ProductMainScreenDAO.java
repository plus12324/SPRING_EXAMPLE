/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.main.InsuranceProductMainMenuDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * �����ǰ ����ȭ�� ���� DAO
 * @author ������
 * @since 1.0.0
 */
@Repository
public class ProductMainScreenDAO extends EgovComAbstractDAO {
	/**
	 * �޴� ����Ʈ�� ��ȸ�Ѵ�
	 * @param menuType �޴� Ÿ��
	 * @return �޴�����Ʈ
	 */
	@SuppressWarnings("unchecked")
	public List<InsuranceProductMainMenuDTO> selectProductMainScreenList() {
		return list("productMainScreen.selectProductMainScreenList", null);
	}

	/**
	 * ���� ����
	 * @param dto
	 * @return
	 */
	public int updateMenuOrder(final List<InsuranceProductMainMenuDTO> dtoList) {
		return update("productMainScreen.updateMenuOrder", dtoList);
	}

	/**
	 * �޴� ���
	 * @param dto
	 * @return null
	 */
	public Object insertMenu(final InsuranceProductMainMenuDTO dto) {
		return insert("productMainScreen.insertMenu", dto);
	}

	/**
	 * �޴� ����
	 * @param
	 * @return
	 */
	public int deleteMenu(final List<Long> nSeqList) {
		return delete("productMainScreen.deleteMenu", nSeqList);
	}

	/**
	 * �޴� �Ѱ� ��ȸ
	 * @return
	 */
	public InsuranceProductMainMenuDTO selectMenu(final Long nSeq) {
		return (InsuranceProductMainMenuDTO) selectByPk("productMainScreen.selectMenu", nSeq);
	}

	/**
	 * �޴� ����
	 * @param dto
	 * @return
	 */
	public int updateMenu(final InsuranceProductMainMenuDTO dto) {
		return update("productMainScreen.updateMenu", dto);
	}
}
