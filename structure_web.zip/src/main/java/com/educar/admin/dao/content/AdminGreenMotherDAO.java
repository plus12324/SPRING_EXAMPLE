/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.AdminGreenMotherDTO;
import com.educar.dto.web.GreenMotherCommentDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * �����Ӵ� �Խ��� ���� DAO
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminGreenMotherDAO extends EgovComAbstractDAO {
	/**
	 * �Խñ� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectGreenMotherListCount(final AdminGreenMotherDTO dto) {
		return (Integer) selectByPk("adminGreenMother.selectGreenMotherCount", dto);
	}

	/**
	 * �Խñ� ��� ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminGreenMotherDTO> selectGreenMotherList(final AdminGreenMotherDTO dto) {
		return list("adminGreenMother.selectGreenMotherList", dto);
	}
	/**
	 * ��÷�� ���
	 * @param dto
	 * @return
	 */
	public Object insertGreenMotherWinner(final AdminGreenMotherDTO dto) {
		return insert("adminGreenMother.insertGreenMotherWinner", dto);
	}
	/**
	 * ��÷�� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminGreenMotherDTO selectGreenMotherWinner(final long nSeq) {
		return (AdminGreenMotherDTO) selectByPk("adminGreenMother.selectGreenMotherWinner", nSeq);
	}
	/**
	 * ��÷�� ����
	 * @param dto
	 * @return
	 */
	public Object updateGreenMotherWinner(final AdminGreenMotherDTO dto) {
		return update("adminGreenMother.updateGreenMotherWinner", dto);
	}
	/**
	 * �Խù� ����
	 * @param dto
	 * @return
	 */
	public Object deleteGreenMother(final long nSeq) {
		return delete("adminGreenMother.deleteGreenMother", nSeq);
	}
	/**
	 * �Խñ� �� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminGreenMotherDTO selectGreenMotherNoticeInfo(final long nSeq) {
		return (AdminGreenMotherDTO) selectByPk("adminGreenMother.selectGreenMotherView", nSeq);
	}
	/**
	 * ���� ��� ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public  List<GreenMotherCommentDTO> selectGreenMotherCmtList(final long nSeq) {
		return list("adminGreenMother.selectGreenMotherCommentList", nSeq);
	}
	/**
	 * �Խñ� ��й�ȣ �ʱ�ȭ
	 * @param dto
	 * @return
	 */
	public Object updateNoticePasswordReSet(final AdminGreenMotherDTO dto) {
		return update("adminGreenMother.updateNoticePasswordReSet", dto);
	}
	/**
	 * �Խñ� ����
	 * @param dto
	 * @return
	 */
	public Object updateGreenMotherNotice(final AdminGreenMotherDTO dto) {
		return update("adminGreenMother.updateGreenMotherNotice", dto);
	}
	/**
	 * ���� ��й�ȣ �ʱ�ȭ
	 * @param dto
	 * @return
	 */
	public Object updateCommentPasswordReSet(final GreenMotherCommentDTO dto) {
		return update("adminGreenMother.updateCommentPasswordReSet", dto);
	}
	/**
	 * ���� ����
	 * @param dto
	 * @return
	 */
	public Object updateGreenMotherComment(final GreenMotherCommentDTO dto) {
		return update("adminGreenMother.updateGreenMotherComment", dto);
	}
	/**
	 * ���� ����
	 * @param dto
	 * @return
	 */
	public Object deleteGreenMotherComment(final GreenMotherCommentDTO dto) {
		return delete("adminGreenMother.deleteGreenMotherComment", dto);
	}
	
}
