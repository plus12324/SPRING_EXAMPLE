/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.memberMng;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.memberMng.AdminMemberChgListDTO;
import com.educar.admin.dto.memberMng.AdminMemberInfoListDTO;
import com.educar.admin.dto.memberMng.AdminMemberJoinWithdrawListDTO;
import com.educar.admin.dto.memberMng.AdminMemberUnLockDTO;
import com.educar.admin.dto.memberMng.AdminSmsLogDTO;
import com.educar.admin.dto.memberMng.AdminSmsSendDTO;
import com.educar.admin.dto.memberMng.AdminSmsSpendFileDTO;
import com.educar.admin.dto.memberMng.EWEBLR002DTO;
import com.educar.admin.dto.memberMng.NVSendMailHistoryDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ȸ�� ���� DAO
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminMemberMngDAO extends EgovComAbstractDAO {
	/**
	 * �����ŷ�ȸ�� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectMemberInfoCount(final AdminMemberInfoListDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectMemberListCount", dto);
	}
	/**
	 * �����ŷ�ȸ�� ����Ʈ ��ȸ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberInfoListDTO> selectMemberInfoList(final AdminMemberInfoListDTO dto) {
		return list("adminMemberMng.selectMemberList", dto);
	}
	/**
	 * ȸ���⺻����
	 * @return
	 */
	public AdminMemberInfoListDTO selectMemBaseInfo(final AdminMemberInfoListDTO dto) {
		return (AdminMemberInfoListDTO) selectByPk("adminMemberMng.selectMemberBaseInfo", dto);
	}
	/**
	 * ȸ���⺻������
	 * @return
	 */
	public AdminMemberInfoListDTO selectMemDetailInfo(final AdminMemberInfoListDTO dto) {
		return (AdminMemberInfoListDTO) selectByPk("adminMemberMng.selectMemberDetailInfo", dto);
	}
	/**
	 * �ּҺ��泻��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberChgListDTO> selectMemberChgAddrList(final AdminMemberChgListDTO dto) {
		return list("adminMemberMng.selectChangeForAddr", dto);
	}
	/**
	 * ��ȭ���泻��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberChgListDTO> selectMemberChgTelList(final AdminMemberChgListDTO dto) {
		return list("adminMemberMng.selectChangeForTel", dto);
	}
	/**
	 * �̸��Ϻ��泻��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberChgListDTO> selectMemberChgEmailList(final AdminMemberChgListDTO dto) {
		return list("adminMemberMng.selectChangeForEmail", dto);
	}
	/**
	 * �ּҺ��泻�� �Ǽ�
	 * @return
	 */
	public Integer selectMemberChgAddrCnt(final AdminMemberChgListDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectChangeForAddrCnt", dto);
	}
	/**
	 * ��ȭ���泻�� �Ǽ�
	 * @return
	 */
	public Integer selectMemberChgTelCnt(final AdminMemberChgListDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectChangeForTelCnt", dto);
	}
	/**
	 * �̸��Ϻ��泻�� �Ǽ�
	 * @return
	 */
	public Integer selectMemberChgEmailCnt(final AdminMemberChgListDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectChangeForEmailCnt", dto);
	}
	/**
	 * ���ں� ȸ������/Ż����Ȳ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberJoinWithdrawListDTO> selectMemberJoinWithDrawList(final AdminMemberJoinWithdrawListDTO dto) {
		return list("adminMemberMng.selectMemberJoinWithdrawList", dto);
	}
	/**
	 * ���ں� ȸ������/Ż����Ȳ �Ǽ�
	 * @return
	 */
	public Integer selectMemberJoinWithDrawCnt(final AdminMemberJoinWithdrawListDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectMemberJoinWithdrawCnt", dto);
	}
	/**
	 * ���ں� ȸ������/Ż����Ȳ(����)
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberJoinWithdrawListDTO> selectMemberJoinWithDrawExcel(final AdminMemberJoinWithdrawListDTO dto) {
		return list("adminMemberMng.selectMemberJoinWithdrawExcel", dto);
	}
	/**
	 * ȸ��Ż�� �̷�/���� ����Ʈ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<EWEBLR002DTO> selectMemberWithDrawReasonList(final EWEBLR002DTO dto) {
		return list("adminMemberMng.selectMemWithDrawReason", dto);
	}
	/**
	 * ȸ��Ż�� �̷�/����  �Ǽ�
	 * @return
	 */
	public Integer selectMemberWithDrawReasonCnt(final EWEBLR002DTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectMemWithDrawReasonCnt", dto);
	}
	/**
	 * ���� ���Ϲ߼� Ȯ��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<NVSendMailHistoryDTO> selectSendMailList(final NVSendMailHistoryDTO dto) {
		return list("adminMemberMng.selectSendMailList", dto);
	}
	/**
	 * ���� ���Ϲ߼� Ȯ��  �Ǽ�
	 * @return
	 */
	public Integer selectSendMailListCnt(final NVSendMailHistoryDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectSendMailListCnt", dto);
	}
	/**
	 * ���� ���Ϲ߼� Ȯ�� - ����
	 */
	public NVSendMailHistoryDTO selectSendMailView(final NVSendMailHistoryDTO dto) {
		return (NVSendMailHistoryDTO)selectByPk("adminMemberMng.selectSendMailView", dto);
	}
	/**
	 * ���� ���Ϲ߼� Ȯ�� - ����(HTML)
	 */
	public NVSendMailHistoryDTO selectSendMailContents(final String serial) {
		return (NVSendMailHistoryDTO)selectByPk("adminMemberMng.selectSendMailContents", serial);
	}
	/**
	 * SMS �뷮�߼� - ���ϸ��
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminSmsSpendFileDTO> selectSmsSpendFileList(final AdminSmsSpendFileDTO dto) {
		return list("adminMemberMng.selectSmsSpendFileList", dto);
	}
	/**
	 * SMS �뷮�߼� - ���ϸ��  �Ǽ�
	 * @return
	 */
	public Integer selectSmsSpendFileCnt(final AdminSmsSpendFileDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectSmsSpendFileCnt", dto);
	}
	/**
	 * SMS �뷮�߼�  ����
	 * @param 
	 * @return
	 */
	public int deleteSmsSpendFile(final AdminSmsSpendFileDTO dto) {
		return delete("adminMemberMng.deleteSMSFiles", dto);
	}
	/**
	 * SMS �뷮�߼� - ����ȭ�� ��ȸ
	 * @return
	 */
	public AdminSmsSpendFileDTO selectSmsSpendFileInfo(final AdminSmsSpendFileDTO dto) {
		return (AdminSmsSpendFileDTO)selectByPk("adminMemberMng.selectSmsSpendFileInfo", dto);
	}
	/**
	 * SMS �뷮�߼�  ����
	 * @param
	 * @return
	 */
	public int deleteSmsFile(final AdminSmsSpendFileDTO dto) {
		return delete("adminMemberMng.deleteSMSFiles", dto);
	}
	/**
	 * SMS �뷮�߼� - ���� WEBFF04
	 * @return
	 */
	public Object insertBinaryFileInfo(final Map reqMap) {
		return insert("adminMemberMng.insertBinaryFile", reqMap);
	}
	/**
	 * SMS �뷮�߼� - ���� WEBDD15
	 * @return
	 */
	public int updateSmsFile(final Map reqMap) {
		return update("adminMemberMng.updateSMSFile", reqMap);
	}
	/**
	 * SMS �뷮�߼� - ���� WEBDD15
	 * @return
	 */
	public Object insertSmsFile(final Map reqMap) {
		return insert("adminMemberMng.insertSMSFile", reqMap);
	}
	/**
	 * SMS �뷮�߼� - ���ϰ������� WEBFF04
	 * @return
	 */
	public AdminSmsSpendFileDTO getBinaryFileInfo(final AdminSmsSpendFileDTO dto) {
		return (AdminSmsSpendFileDTO)selectByPk("adminMemberMng.getBinaryFileInfo", dto);
	}
	
	/**
	 * SMS �뷮�߼� - �߼۷α� ���
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminSmsLogDTO> selectSmsSendLogList(final AdminSmsLogDTO dto) {
		return list("adminMemberMng.selectSmsSendLogList", dto);
	}
	/**
	 * SMS �뷮�߼� - �߼۷α�  �Ǽ�
	 * @return
	 */
	public Integer selectSmsSendLogCnt(final AdminSmsLogDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectSmsSendLogCnt", dto);
	}
	
	/**
	 * SMS �뷮�߼� - �߼ۿ��� üũ 
	 * @return
	 */
	public Integer selectSmsSendYN(final AdminSmsSendDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectSMSSendYN", dto);
	}
	/**
	 * SMS �뷮�߼� -	 �뷮 �߼�(�α׿� �����ϴ� ����)
	 * @return
	 */
	public Object insertSMSSendLog(final AdminSmsSendDTO dto) {
		return insert("adminMemberMng.insertSMSSendLog", dto);
	}
	/**
	 * SMS �뷮�߼� -	 �뷮 �߼�(�߼� ť�� �����ϴ� ����)
	 * @return
	 */
	public Object insertSMSSendQueue(final AdminSmsSendDTO dto) {
		//return insert("adminMemberMng.insertNewSMSSendQueue", dto);
		return insert("adminMemberMng.insertSMSSendQueue", dto);
	}
	/**
	 * SMS �뷮�߼� -	 �Ⱓ�� ����
	 * @return
	 */
	public Object insertSMSSendCCCIA04(final Map reqMap) {
		return insert("adminMemberMng.insertSMSSendCCCIA04", reqMap);
	}
	/**
	 * ��й�ȣ ���� ���� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectPassUnlockCount(final AdminMemberUnLockDTO dto) {
		return (Integer) selectByPk("adminMemberMng.selectPassUnlockCount", dto);
	}
	/**
	 * ��й�ȣ ���� ���� ����Ʈ ��ȸ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminMemberUnLockDTO> selectPassUnlockList(final AdminMemberUnLockDTO dto) {
		return list("adminMemberMng.selectPassUnlockList", dto);
	}
	/**
	 * SMS �뷮�߼� -	 �뷮 �߼�(�α׿� �����ϴ� ����)
	 * @return
	 */
	public Object setPassUnlock(final AdminMemberUnLockDTO dto) {
		return update("adminMemberMng.updateLoginUnlock", dto);
	}
}
