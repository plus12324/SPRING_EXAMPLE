/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.admin.dao.content;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.admin.dto.content.AdminDownloadCenterDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * �ٿ�ε� ���� DAO
 * @author ���ѳ�
 * @since 1.0.0
 */
@Repository
public class AdminDownCenterDAO extends EgovComAbstractDAO {
	/**
	 * �ٿ�ε� �ѰǼ� ��ȸ
	 * @return
	 */
	public Integer selectDownLoadListCount(final AdminDownloadCenterDTO dto) {
		return (Integer) selectByPk("adminDownCenter.selectDownLoadListCount", dto);
	}

	/**
	 * �ٿ�ε� ��� ��ȸ
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdminDownloadCenterDTO> selectDownLoadList(final AdminDownloadCenterDTO dto) {
		return list("adminDownCenter.selectDownCenterList", dto);
	}
	/**
	 * �ٿ�ε� �Ѱ� ��ȸ
	 * @param dto
	 * @return
	 */
	public AdminDownloadCenterDTO selectDownLoadInfo(final AdminDownloadCenterDTO dto) {
		return (AdminDownloadCenterDTO)selectByPk("adminDownCenter.selectDownCenterInfo", dto);
	}
	/**
	 * ���ҽ� Key ��ȸ
	 * @return
	 */
	public Integer selectResourceKey(final AdminDownloadCenterDTO dto) {
		return (Integer) selectByPk("adminDownCenter.selectResourceKey", dto);
	}
	/**
	 * �ٿ�ε� ���
	 * @param dto
	 * @return
	 */
	public Object insertDownLoadInfo(final AdminDownloadCenterDTO dto) {
		return insert("adminDownCenter.insertDownCenterInfo", dto);
	}
	/**
	 * �ٿ�ε� ����
	 * @param dto
	 * @return
	 */
	public int updateDownLoadInfo(final AdminDownloadCenterDTO dto) {
		return update("adminDownCenter.updateDownCenterInfo", dto);
	}
	/**
	 * �ٿ�ε� ����
	 * @param dto
	 * @return
	 */
	public int deleteDownLoadInfo(final AdminDownloadCenterDTO dto) {
		return delete("adminDownCenter.deleteDownCenterInfo", dto);
	}
}
