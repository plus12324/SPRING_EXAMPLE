/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.GreenMotherAuthCheckDTO;
import com.educar.dto.web.GreenMotherCommentDTO;
import com.educar.dto.web.GreenMotherDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * <pre>
 * ������ - �����Ӵ� �Խ��� DAO
 * <pre>
 * @author ���ѳ�
 *
 */
@Repository
public class GreenMotherDAO extends EgovComAbstractDAO {

	/**
	 * <pre>
	 * �Խñ� ��� ��ȸ
	 * <pre>
	 * @param pageIndex	������ �ѹ�
	 * @return <GreenMotherDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<GreenMotherDTO> selectGreenMotherNoticeList(final GreenMotherDTO dto) {
		return list("greenMother.selectGreenMotherList", dto);
	}
	/**
	 * <pre>
	 * �Խñ� ��ü �Ǽ� ��ȸ
	 * <pre>
	 * @return Integer ��ü �Խñ� ��
	 */
	public Integer selectGreenMotherNoticeAllCount(final GreenMotherDTO dto) {
		return (Integer) selectByPk("greenMother.selectGreenMotherCount", dto);
	}
	/**
	 * <pre>
	 * �Խñ� ����ȸ
	 * <pre>
	 * @param nSeq	�Խñ� ��ȣ
	 * @return <GreenMotherDTO> �󼼳���
	 */
	public GreenMotherDTO selectGreenMotherNoticeView(final GreenMotherDTO dto) {
		return (GreenMotherDTO) selectByPk("greenMother.selectGreenMotherView", dto);
	}
	/**
	 * <pre>
	 * �Խñ� ��ȸ�� ����
	 * <pre>
	 * @param nSeq
	 */
	public int updateGreenMotherVisitCnt(final int nSeq) {
		return update("greenMother.updateGreenMotherVisitCnt", nSeq);
	}
	/**
	 * <pre>
	 * ���� ��� ��ȸ
	 * <pre>
	 * @param pageIndex	������ �ѹ�
	 * @return <GreenMotherDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<GreenMotherCommentDTO> selectGreenMotherCommentList(final int nSeq) {
		return list("greenMother.selectGreenMotherCommentList", nSeq);
	}
	/**
	 * <pre>
	 * �Խñ� ���� ��й�ȣ üũ
	 * <pre>
	 * @param nSeq	�Խñ� ��ȣ
	 * @return <GreenMotherDTO> �󼼳���
	 */
	public Boolean noticePasswordCheck(final GreenMotherAuthCheckDTO dto) {
		String sPassWord = "";
		boolean returnValue = false;
		if("N".equals(dto.getsChkDiv())){
			sPassWord =  (String) selectByPk("greenMother.checkNoticePassword", dto.getnSeq());
		}else{
			sPassWord =  (String) selectByPk("greenMother.checkCommentPassword", dto);
		}

		if(dto.getsPassword().equals(sPassWord)){
			returnValue = true;
		}
		
		return returnValue;
	}
	/**
	 * <pre>
	 * ���� ���
	 * <pre>
	 * @param nSeq
	 */
	public int insertGreenMotherComment(final GreenMotherCommentDTO dto) {
		return update("greenMother.insertGreenMotherComment", dto);
	}
	/**
	 * <pre>
	 * ���� ����
	 * <pre>
	 * @param nSeq
	 */
	public int updateGreenMotherComment(final GreenMotherCommentDTO dto) {
		return update("greenMother.updateGreenMotherComment", dto);
	}
	/**
	 * <pre>
	 * ���� ����
	 * <pre>
	 * @param nSeq
	 */
	public int deleteGreenMotherComment(final GreenMotherCommentDTO dto) {
		return delete("greenMother.deleteGreenMotherComment", dto);
	}
	
	/**
	 * <pre>
	 * �Խñ� ����
	 * <pre>
	 * @param nSeq
	 */
	public int deleteGreenMotherNotice(final int nSeq) {
		return delete("greenMother.deleteGreenMotherNotice", nSeq);
	}
	/**
	 * <pre>
	 * �Խñ� ���� �� ���� ���� üũ
	 * <pre>
	 * @param nSeq
	 */
	public int countGreenMotherComment(final int nSeq) {
		return (Integer) selectByPk("greenMother.selectCommentCount", nSeq);
	}
	/**
	 * <pre>
	 * �Խñ� ���
	 * <pre>
	 * @param GreenMotherDTO dto
	 */
	public int insertGreenMotherNotice(final GreenMotherDTO dto) {
		return update("greenMother.insertGreenMotherNotice", dto);
	}
	/**
	 * <pre>
	 * �Խñ� ����
	 * <pre>
	 * @param GreenMotherDTO dto
	 */
	public int updateGreenMotherNotice(final GreenMotherDTO dto) {
		return update("greenMother.updateGreenMotherNotice", dto);
	}
}