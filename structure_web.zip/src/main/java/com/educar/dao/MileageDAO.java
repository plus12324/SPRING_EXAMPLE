/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ���ϸ����� DAO
 * @author �Ž¿�
 *
 */
@Repository
public class MileageDAO extends EgovComAbstractDAO {
	
	/**
	 * ȸ������
	 * 
	 * @param ID
	 * @return
	 */
	public String selectSMSYN(final String ID) {
		return (String) selectByPk("myPage.selectSMSRejectYN", Long.valueOf(ID));
	}

}
