/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.products.ReserveReqeustLogDTO;
import com.educar.vo.web.ContractLogVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * <pre>
 * 
 * </pre>
 *
 * @author �ڼ���(SeongJin Park)
 *
 */
@Repository
public class LogDAO extends EgovComAbstractDAO {

	/**
	 * ���� ���� �α� ����
	 * @param dto
	 * @return 
	 */
	public Object addReserveReqeust(final ReserveReqeustLogDTO dto) {
		return insert("reserveReqeust.addReserveReqeust", dto);
	}

	/**
	 * ����� ��� �α� ����
	 * @param dto
	 * @return 
	 */
	public Object insertContractLog(final ContractLogVO vo) {
		return insert("contractLog.insertContractLog", vo);
	}
}
