/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.myeducar.MileageAfiliatedConcernDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ���ϸ��� ���޾�ü ��ȸ
 * @author ������
 * @since 1.0.0
 */
@Repository
public class MyEducarDAO extends EgovComAbstractDAO {
	/**
	 * <pre>
	 * ���ϸ��� ���޾�ü �ѰǼ� ��ȸ
	 * <pre>
	 * @return
	 */
	public Integer selectMileageAfiliatedConcernCount(final MileageAfiliatedConcernDTO dto) {
		return (Integer) selectByPk("myeducar.selectMileageAfiliatedConcernCount", dto);
	}

	/**
	 * <pre>
	 * ���ϸ��� ���޾�ü ��� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MileageAfiliatedConcernDTO> selectMileageAfiliatedConcernList(final MileageAfiliatedConcernDTO dto) {
		return list("myeducar.selectMileageAfiliatedConcernList", dto);
	}

	/**
	 * <pre>
	 * ���ϸ��� ���޾�ü �� ��� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MileageAfiliatedConcernDTO> selectAdrs1List() {
		return list("myeducar.selectAdrs1List", null);
	}
}
