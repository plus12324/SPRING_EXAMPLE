/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dao;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.MemberAddressDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ȸ���ּ� Dao
 * 
 * @author ������
 * 
 */
@Repository
public class MemberAddressDao extends EgovComAbstractDAO {
	/**
	 * ��Ʈ �÷� �ʱ�ȭ(null�� ������Ʈ)
	 * 
	 * @param ID ȸ��Master(WEBDD01)���̺��� ID
	 * @return update�� �׸� ��
	 */
	public int updateMemberAddressInitLast(final MemberAddressDTO dto) {
		return update("memberAddress.updateMemberAddressInitLast", dto);
	}

	/**
	 * ȸ���ּҸ� insert�Ѵ�
	 * 
	 * @param dto
	 * @return null
	 */
	public Object insertMemberAddress(final MemberAddressDTO dto) {
		return insert("memberAddress.insertMemberAddress", dto);
	}
}
