/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao.jehu;

import org.springframework.stereotype.Repository;

import com.educar.dto.jehu.JehuDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * @author ������
 *
 */
@Repository
public class JehuDAO extends EgovComAbstractDAO {

	/**
	 * ���� ��ȸ
	 * @return
	 */
	public JehuDTO selectJehu(final String sAffiliatedConcern) {
		return (JehuDTO) selectByPk("jehu.selectJehu", sAffiliatedConcern);
	}

	/**
	 * ��⺸�� �� ��ȸ
	 * @param code
	 * @return
	 */
	public String selectLongTermCodeName(final String code) {
		return (String) selectByPk("jehu.selectLongTermCodeName", code);
	}
}
