/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.educar.dto.web.BenefitsDivisionDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ���� ���� �ڵ� ��ȸ DAO
 * @author ������
 *
 */
@Repository
public class BenefitsDivisionDAO extends EgovComAbstractDAO {
	/**
	 * ���� ���а� ��ü ��ȸ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<BenefitsDivisionDTO> selectBenefitsDivisionAllList() {
		return list("benefitsDivision.selectBenefitsDivisionAllList", StringUtils.EMPTY);
	}
}
