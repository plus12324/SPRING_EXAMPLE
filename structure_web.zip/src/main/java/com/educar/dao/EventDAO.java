/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.CustomerSatisfactionInputDTO;
import com.educar.dto.web.Event10AnniversaryDTO;
import com.educar.dto.web.EventDTO;
import com.educar.dto.web.EventTaskDTO;
import com.educar.dto.web.EventWinnerDTO;
import com.educar.dto.web.TheKFellowInfoDTO;
import com.educar.dto.web.TheKPreferenceInfoDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * <pre>
 * �̺�Ʈ DAO
 * <pre>
 * @author ��â��
 *
 */
@Repository
public class EventDAO extends EgovComAbstractDAO {
	// TODO : AS-IS DB������ ����
	/**
	 * <pre>
	 * �������� �̺�Ʈ ��� ��ȸ
	 * <pre>
	 * @return <EventDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<EventDTO> selectEventList(final EventDTO dto) {
		return list("event.selectEventList", dto);
	}

	/**
	 * <pre>
	 * �������� �̺�Ʈ �� ���� ��ȸ
	 * <pre>
	 * @param 
	 * @return <EventDTO> �󼼳���
	 */
	public EventDTO selectEventView(final EventDTO dto) {
		return (EventDTO) selectByPk("event.selectEventView", dto);
	}

	/**
	 * <pre>
	 * ���� �̺�Ʈ ��� ��ȸ
	 * <pre>
	 * @return <EventDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<EventDTO> selectPastEventList(final EventDTO dto) {
		return list("event.selectPastEventList", dto);
	}

	/**
	 * <pre>
	 * ���� �̺�Ʈ ��ü �Ǽ� ��ȸ
	 * <pre>
	 * @return Integer ���� �̺�Ʈ ��ü �Խñ� ��
	 */
	public Integer selectPastEventListAllCount(final EventDTO dto) {
		return (Integer) selectByPk("event.selectPastEventListAllCount", dto);
	}

	/**
	 * <pre>
	 * �̺�Ʈ ��÷�� ��ȸ
	 * <pre>
	 * @param eventWinnerDTO
	 * @return
	 */
	public EventWinnerDTO selectEventWinner(final EventWinnerDTO eventWinnerDTO) {
		return (EventWinnerDTO) selectByPk("event.selectEventWinner", eventWinnerDTO);
	}
	
	/**
	 * <pre>
	 * �̺�Ʈ ��÷�� ��ǰ�� ��ȸ
	 * <pre>
	 * @param eventWinnerDTO
	 * @return
	 */
	public EventWinnerDTO selectEventWinnerProduct(final EventWinnerDTO eventWinnerDTO) {
		return (EventWinnerDTO) selectByPk("event.selectEventWinnerProduct", eventWinnerDTO);
	}
	
	
	/**
	 * <pre>
	 * �̺�Ʈ �Ⱓ ��ȸ
	 * <pre>
	 * @param eventWinnerDTO
	 * @return
	 */
	public EventTaskDTO selectEventDate(final EventTaskDTO dto) {
		return (EventTaskDTO)selectByPk("event.selectEventDate", dto);
	}
	
	
	/**
	 * �̺�Ʈ ���𿩺� ��ȸ
	 * @param dto
	 * @return
	 */
	public int selectEventDupcheck(final EventTaskDTO dto){
		return (Integer) selectByPk("event.selectEventDupcheck",dto);
	}
	
	/**
	 * <pre>
	 * ����̺�Ʈ webbb37 ���� / sns evnet ����
	 * <pre>
	 * @param EventTaskDTO
	 * @return
	 */
	public void insertWEBBB37(final EventTaskDTO eventTaskDTO) {
		final EventTaskDTO dateDto = (EventTaskDTO)selectByPk("event.selectEventDate", eventTaskDTO);
//		eventTaskDTO.setsStartDate(dateDto.getsStartDate());
//		eventTaskDTO.setsEndDate(dateDto.getsEndDate());
		eventTaskDTO.setsStartDate("20141101");
		eventTaskDTO.setsEndDate("20141201");
		insert("event.insertWEBBB37", eventTaskDTO);
	}
	
	/**
	 * <pre>
	 * theKFellow webbb29 ����
	 * <pre>
	 * @param EventTaskDTO
	 * @return
	 */
	public void insertWEBBB29(final TheKFellowInfoDTO theKFellowInfoDTO) {
		
		insert("event.insertWEBBB29", theKFellowInfoDTO);
	}
	
	/**
	 * <pre>
	 * ��ȣ������ webbb22 ����
	 * <pre>
	 * @param EventTaskDTO
	 * @return
	 */
	public void insertWEBBB22(final TheKPreferenceInfoDTO theKPreferenceInfoDTO) {
		
		final int nSeqNo = (Integer) selectByPk("event.countWEBBB22" ,null);
		theKPreferenceInfoDTO.setnSeqNo(nSeqNo);
		
		insert("event.insertWEBBB22", theKPreferenceInfoDTO);
	}
	
	/**
	 * <pre>
	 * ���������� ���� ���� ���
	 * <pre>
	 * @return
	 */
	public void insertWEBBB36(final CustomerSatisfactionInputDTO customerSatisfactionInputDTO) {
		insert("event.insertWEBBB36", customerSatisfactionInputDTO);
	}
	/**
	 * <pre>
	 * 10�ֳ� URL ����
	 * <pre>
	 * @return
	 */
	public void insertWEBDD54(final Event10AnniversaryDTO event10AnniversaryDTO) {
		insert("event.insertWEBDD54", event10AnniversaryDTO);
	}
	/**
	 * <pre>
	 * 10�ֳ� ������ ����
	 * <pre>
	 * @return
	 */
	public void insertWEBDD55(final Event10AnniversaryDTO event10AnniversaryDTO) {
		insert("event.insertWEBDD55", event10AnniversaryDTO);
	}
	/**
	 * <pre>
	 *  10�ֳ� ���� URL üũ
	 * <pre>
	 * @param eventWinnerDTO
	 * @return
	 */
	public Event10AnniversaryDTO selectURLCheck(final Event10AnniversaryDTO event10AnniversaryDTO) {
		return (Event10AnniversaryDTO) selectByPk("event.selectURLCheck", event10AnniversaryDTO);
	}
	/**
	 * <pre>
	 * 10�ֳ� ������ ��� ��ȸ
	 * <pre>
	 * @return <EventDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<Event10AnniversaryDTO> select10thList(final Event10AnniversaryDTO dto) {
		return list("event.select10thList", dto);
	}
	/**
	 * <pre>
	 * �޴����ߺ���, url���� ��ȸ
	 * <pre>
	 * @return <EventDTO>
	 */
	@SuppressWarnings("unchecked")
	public List<Event10AnniversaryDTO> select10thInfoCnt(final Event10AnniversaryDTO dto) {
		return list("event.select10thInfoCnt", dto);
	}	
	
	/**
	 * <pre>
	 * ģ���Ұ� �̺�Ʈ SMS ���� Ƚ�� �� ��¥ Ȯ��
	 * <pre>
	 * @return <Event10AnniversaryDTO>
	 */
	public Event10AnniversaryDTO select10thSMS(final Event10AnniversaryDTO dto){
		return (Event10AnniversaryDTO) selectByPk("event.select10thSMS",dto);
	}
	
	
	/**
	 * <pre>
	 * ģ���Ұ� �̺�Ʈ SMS ���� Ƚ�� �� ��¥ ������Ʈ
	 * <pre>
	 */
	public void update10thSMSDate(final Event10AnniversaryDTO dto){
		update("event.update10thSMSDate",dto);
	}
	
}