/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.dto.web.claim.EmergencyActionDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * ����⵿ ����
 * @author ������
 * @since 1.0.0
 */
@Repository
public class ClaimDAO extends EgovComAbstractDAO {
	/**
	 * <pre>
	 * ����⵿ ���� �ѰǼ� ��ȸ
	 * <pre>
	 * @return
	 */
	public Integer selectEmergencyActionCount(final EmergencyActionDTO dto) {
		return (Integer) selectByPk("claim.selectEmergencyActionCount", dto);
	}

	/**
	 * <pre>
	 * ����⵿ ���� ��� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<EmergencyActionDTO> selectEmergencyActionList(final EmergencyActionDTO dto) {
		return list("claim.selectEmergencyActionList", dto);
	}

	/**
	 * <pre>
	 * ����⵿ ���� �� ��� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<EmergencyActionDTO> selectAdrs1List() {
		return list("claim.selectAdrs1List", null);
	}

	/**
	 * <pre>
	 * ����⵿ ���� �� ��� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<EmergencyActionDTO> selectAdrs2List(final String sAdrs1) {
		return list("claim.selectAdrs2List", sAdrs1);
	}
}
