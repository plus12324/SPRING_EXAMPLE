package com.educar.common.aop;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;

import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.dto.web.login.LoginDTO;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.LoginBackBoneService;
import com.educar.service.web.LoginService;

/**
 * ������ȸ ������ ASPECT ����
 * @author ������
 *
 */
@Aspect
public class NewwebAop {
	/** Message service */
	@Autowired
	private MessageSourceService message;
	
	/** session service */
	@Autowired
	private SessionService sessionService;
	
	/** �α��� ���� **/
	@Autowired
	private LoginService loginService;
	
	/** �α��� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private LoginBackBoneService loginServiceBackBone;
	
	/** �ΰ� */
	private final Logger logger = Logger.getLogger(this.getClass());
		
	@Pointcut("execution(public * com.educar.controller.web.myeducar.*Controller.*(..))")
	// && execution(public * com.educar.controller.web.myeducar.DrivingPolicyController.*(..))
    public void targetMethod() {}
	
	
	/**
	 * ���ӵ� controller ȣ�� Ƚ�� Ȯ��
	 * @param thisJoinPoint
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before("targetMethod()")
	public void beforeTargetMethod(JoinPoint thisJoinPoint) {
		for ( Object o : thisJoinPoint.getArgs() ){ 
			if ( o instanceof HttpServletRequest || o instanceof HttpSession){
				Map cntInfo = null;
				HttpSession session = null;
				String ssn = null;
				String method = thisJoinPoint.getSignature().getName();
				session = o instanceof HttpSession ? (HttpSession)o : ((HttpServletRequest) o).getSession();
				ssn = sessionService.getSSNFromSession(session);
								
				if(ssn != null){
					
					if(session.getAttribute("cnt") == null){
						//cnt �Ӽ� �ʱ�ȭ
						cntInfo = new HashMap();
						cntInfo.put("cnt", 0);
						cntInfo.put("time", System.currentTimeMillis());
						cntInfo.put("method", method);
						session.setAttribute("cnt", cntInfo);
					}
					else{
						cntInfo = (HashMap) session.getAttribute("cnt");
						
						int cnt = (Integer)cntInfo.get("cnt");
						long timeDiff = (System.currentTimeMillis()- (Long)cntInfo.get("time"))/1000;
						logger.info( timeDiff + "�� ����");
						
						logger.info("��NewwebAop.method : " + method);
						logger.info("��NewwebAop.cntInfo(method) : " + cntInfo.get("method").toString());
						
						if(timeDiff < 10 && method.equals(cntInfo.get("method").toString())){
							if(timeDiff >0) cnt = cnt + 1;
							logger.info("��NewwebAop.cnt++ : " + cnt);
						}else{
							cnt = 0;
						}
						
						cntInfo.put("cnt", cnt);
						cntInfo.put("time", System.currentTimeMillis());
						cntInfo.put("method", method);
						session.setAttribute("cnt", cntInfo);
					}
				}
			}
		}
	}

	/**
	 * 10ȸ �̻� ��ȸ �� �α׾ƿ� & �������
	 * @param thisJoinPoint
	 */
	@After("targetMethod()")
	public void afterTargetMethod(JoinPoint thisJoinPoint) {
		
		for ( Object o : thisJoinPoint.getArgs() ){
			if ( o instanceof HttpServletRequest || o instanceof HttpSession){
				
				HttpSession session = null;
				String ssn = null;
				
				session = o instanceof HttpSession ? (HttpSession)o : ((HttpServletRequest) o).getSession();
				ssn = sessionService.getSSNFromSession(session);
				
				if(ssn != null){
					Map cntInfo = (HashMap) session.getAttribute("cnt");
					if((Integer)cntInfo.get("cnt") >= 10){
						
						final String ID = loginServiceBackBone.getWebID(ssn);
						if(!StringUtil.isNullOrEmpty(ID)){
							
							//After locking, throw exception
							final LoginDTO loginDto = new LoginDTO();
							loginDto.setID(Integer.valueOf(ID));
							loginDto.setnPasswordFailureCount("10");
							loginDto.setsPassFlag("1");
							loginService.setPasswordFailInfo(loginDto);
							
							//����� �α׾ƿ�
							session.invalidate();
							
							String msg = "���� 10ȸ �̻� ������ ��ȸ��û�� �����Ǿ����ϴ�.\\n'Home>�α��μ���>��й�ȣ ���� ����' ���� ���������� �����ϼ���.";
							throw new InvalidRequestException.Builder(msg).forwardUrl(WebServletEnum.PASSWORD_ERR_UNLOCK).build();
						}
					}
				}
			}
		}//end for
	}
}

