/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.log4j.Logger;

/**
 * Serializable Object�� Deep copy�ϴ� util
 * @author �ּ�ȯ(David SW Choi) 
 * @since 1.0.0
 */
public class DeepCopyUtil {

	private static Logger logger = Logger.getLogger(DeepCopyUtil.class);

	@SuppressWarnings("unchecked")
	public static <T> T clone(final T t) {
		T clone = null;
		ByteArrayOutputStream bos = null;
		ObjectOutputStream os = null;
		try {
			bos = new ByteArrayOutputStream();
			os = new ObjectOutputStream(bos);
			os.writeObject(t);
			os.flush();
			final byte[] clonedByte = bos.toByteArray();
			final ByteArrayInputStream bis = new ByteArrayInputStream(clonedByte);
			clone = (T) new ObjectInputStream(bis).readObject();
		} catch (final IOException ie) {
			logger.error("���� IO �����Դϴ�");
		} catch (final ClassNotFoundException cle) {
			logger.error("Serializble ������ object�� clone��");
		} finally {
			try {
				bos.close();
				os.close();
			} catch (final Exception e) {
				// nothing can be done here
				logger.error(e.getMessage());
			}
		}
		return clone;
	}
}
