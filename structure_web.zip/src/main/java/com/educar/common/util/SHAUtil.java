/*
 * Copyright (c) 2006 educar, Inc. All Rights Reserved.
 *
 * Version History :
 *     1.0  Created by ���±� (2006-03-24)
 *
 */
package com.educar.common.util;

import java.security.MessageDigest;

/**
 * MD5Util is a collection of static Entity utility methods.
 *
 * @author     ���
 * @version    1.0
 * @cdate      2011-08-05
 */

public class SHAUtil {

	private static final String SHA_256 = "SHA-256";

	// all static methods, so no need for a public constructor
	private SHAUtil() {

	}

	/**
	 * SHAUtil:  toSHA256 
	 * ��ȣȭ(�� ==> ��ȣ��)
	 * @author  ���
	 * @cdate  	2011-08-05
	 * @param  	��   String
	 * @return  ��ȣ�� String
	 */
	public static String toSHA256(final String str) {

		StringBuffer outStr = null;

		try {

			if (str == null) {
				throw new NullPointerException();
			}

			final MessageDigest md = MessageDigest.getInstance(SHA_256);
			final byte[] hash = md.digest(str.getBytes());

			int onebyte;
			int i = 0;

			outStr = new StringBuffer(hash.length * 2);

			while (i < hash.length) {
				onebyte = ((0x000000ff & hash[i]) | 0xffffff00);
				outStr.append(Integer.toHexString(onebyte).substring(6));
				i++;
			}

		} catch (final Exception e) {
			throw new RuntimeException(e);
		}

		return outStr.toString();
	}

	/**
	 * SHAUtil:  toSHA256inMD5 
	 * ��ȣȭ(�� ==> ��ȣ��)
	 * @author  ���
	 * @cdate  	2011-08-05
	 * @param  	��   String
	 * @return  ��ȣ�� String
	 */
	public static String toSHA256inMD5(final String str) {
		String result = "";

		try {

			result = MD5Util.toMD5(str);

			result = toSHA256(result);

		} catch (final Exception e) {
		}

		return result;
	}

}