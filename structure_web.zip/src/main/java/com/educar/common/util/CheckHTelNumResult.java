/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.util;

import kr.co.conch.aspect.exception.VaildationBaseException;
import kr.co.conch.validator.annotation.CustomValidatorResult;

/**
 * ��ȭ��ȣ üũ ���
 * @author ������
 * @since 1.1.0
 */
public class CheckHTelNumResult implements CustomValidatorResult {
	private boolean isSuccess = true;
	private static final String ERROR_MESSAGE = "�ùٸ��� ���� �ڵ��� ��ȣ �Դϴ�.";

	/* (non-Javadoc)
	 * @see kr.co.conch.validator.annotation.CustomValidatorResult#isSuccess()
	 */
	@Override
	public boolean isSuccess() {
		return this.isSuccess;
	}

	@Override
	public void setIsSuccess(final boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	/* (non-Javadoc)
	 * @see kr.co.conch.validator.annotation.CustomValidatorResult#getMessage()
	 */
	@Override
	public String getMessage() {
		return ERROR_MESSAGE;
	}

	/* (non-Javadoc)
	 * @see kr.co.conch.validator.annotation.CustomValidatorResult#getException()
	 */
	@Override
	public Class<? extends VaildationBaseException> getException() {
		return VaildationBaseException.class;
	}
}
