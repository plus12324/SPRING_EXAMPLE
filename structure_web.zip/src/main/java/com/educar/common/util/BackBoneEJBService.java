/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.inswave.webview.ejb.WebView;
import com.inswave.webview.ejb.WebViewHome;

/**
 * <pre>
 * �Ⱓ�� ����ȭ ������ Failover ó���� ����ϴ� Ŭ�����̴�.
 * Primary �� Secondary �ּҴ� backbone-ejb-config���� ���� �����ϴ�.
 * backbone-ejb-config�� home cache�� false�θ� ����Ѵ�.  
 * true�� ��� �ٸ� ������ ���� ó���� �ʿ��ϴ�.
 * </pre>
 * See <a href="http://dev-server:8020/browse/EDUCAR-212">Jira(�Ⱓ�� FAILOVER)</a>
 * @author ������(KTH) 
 * @since 0.0.10
 */
public class BackBoneEJBService {

	private String jndiName;
	private String jndiFactory;
	private String jndiUrl;

	private List<String> primaryList;
	private List<String> secondaryList;

	public WebView getWebView(final String ip) throws CreateException, Exception {
		final Hashtable<String, String> ht = new Hashtable<String, String>();
		ht.put(Context.INITIAL_CONTEXT_FACTORY, jndiFactory);
		ht.put(Context.URL_PKG_PREFIXES, jndiUrl);
		ht.put(Context.PROVIDER_URL, ip);
		final Context ctx = new InitialContext(ht);
		final WebViewHome home = (WebViewHome) ctx.lookup(getJndiName());
		return home.create();
	}

	/**
	 * @return the jndiFactory
	 */
	public String getJndiFactory() {
		return jndiFactory;
	}

	/**
	 * @param jndiFactory the jndiFactory to set
	 */
	public void setJndiFactory(final String jndiFactory) {
		this.jndiFactory = jndiFactory;
	}

	/**
	 * @return the jndiUrl
	 */
	public String getJndiUrl() {
		return jndiUrl;
	}

	/**
	 * @param jndiUrl the jndiUrl to set
	 */
	public void setJndiUrl(final String jndiUrl) {
		this.jndiUrl = jndiUrl;
	}

	/**
	 * @return the jndiName
	 */
	public String getJndiName() {
		return jndiName;
	}

	/**
	 * @param jndiName the jndiName to set
	 */
	public void setJndiName(final String jndiName) {
		this.jndiName = jndiName;
	}

	/**
	 * @return the primaryList
	 */
	public List<String> getPrimaryList() {
		return primaryList;
	}

	/**
	 * @param primaryList the primaryList to set
	 */
	public void setPrimaryList(final List<String> primaryList) {
		this.primaryList = primaryList;
	}

	/**
	 * @return the secondaryList
	 */
	public List<String> getSecondaryList() {
		return secondaryList;
	}

	/**
	 * @param secondaryList the secondaryList to set
	 */
	public void setSecondaryList(final List<String> secondaryList) {
		this.secondaryList = secondaryList;
	}

	/**
	 * ���� ip�� list�� ��ȯ
	 * @return
	 */
	public List<String> getEjbIPList() {
		final List<String> ejbIPList = new ArrayList<String>();
		Collections.shuffle(this.primaryList);
		Collections.shuffle(this.secondaryList);
		ejbIPList.addAll(this.primaryList);
		ejbIPList.addAll(this.secondaryList);

		return ejbIPList;
	}
}
