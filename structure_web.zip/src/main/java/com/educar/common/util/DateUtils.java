package com.educar.common.util;

import java.util.Calendar;

import org.apache.commons.lang.StringUtils;

/*
 * [added by shlee]
 * Date ���� ��ƿ
 */
public class DateUtils {

	/**
	 * compare date
	 *
	 * @param bfDate - before date (yyyyMMdd)
	 * @param afDate - after date (yyyyMMdd)
	 * @param type - 1:��, 2:��, 3:�� 4:��, 5:��, 6:�� (��,��,�ʴ� ���� Ȯ��)
	 * @return different value
	 */
	public static long DateDiff(final String bfDate, final String afDate, final String type) {

		long ret = -1;

		if (StringUtils.isEmpty(bfDate) || StringUtils.isEmpty(afDate) || StringUtils.isEmpty(type)) {
			return -1; // �� �����Ͱ� ����
		}

		if (bfDate.length() != 8 || afDate.length() != 8) {
			return -2; // yyyyMMdd �� �ƴ�
		}

		if (Integer.parseInt(bfDate) > Integer.parseInt(afDate)) {
			return -3; // bfDate �� ��ŭ
		}

		final int bfYear = Integer.parseInt(bfDate.substring(0, 4));
		final int bfMon = Integer.parseInt(bfDate.substring(5, 6));
		final int bfDay = Integer.parseInt(bfDate.substring(7, 8));

		final int afYear = Integer.parseInt(afDate.substring(0, 4));
		final int afMon = Integer.parseInt(afDate.substring(5, 6));
		final int afDay = Integer.parseInt(afDate.substring(7, 8));

		ret = -4; // type ��Ī ����
		if ("1".equals(type)) {
			ret = afYear - bfYear;
		} else if ("2".equals(type)) {
			final int afMonTmp = (afYear - bfYear) * 12 + afMon;
			ret = afMonTmp - bfMon;
		} else {

			final Calendar cal1 = Calendar.getInstance();
			final Calendar cal2 = Calendar.getInstance();

			cal1.set(bfYear, bfMon, bfDay);
			cal2.set(afYear, afMon, afDay);

			final long milliseconds1 = cal1.getTimeInMillis();
			final long milliseconds2 = cal2.getTimeInMillis();
			final long diff = milliseconds2 - milliseconds1;

			if ("3".equals(type)) {
				ret = diff / (24 * 60 * 60 * 1000);
			}
			/*
			// ���� Ȯ��
			else if ( type == "4" ) {
				ret = diff / (60 * 60 * 1000);
			}
			else if ( type == "5" ) {
				ret = diff / (60 * 1000);
			}
			else {	//  "6"
				ret = diff / 1000;
			}
			*/
		}

		return ret;
	}

	/**
	 * �� ���� ���
	 * @param sCustNo	�ֹε�� ��ȣ(13�ڸ� Ǯ)
	 * @return
	 */
	public static int getFullAge(final String sCustNo) {

		int fullAge = 0;

		if (StringUtils.isNotEmpty(sCustNo) && StringUtils.length(sCustNo) > 7) {
			final Calendar cal = Calendar.getInstance();
			final int year = cal.get(Calendar.YEAR);
			final int month = cal.get(Calendar.MONTH) + 1;
			final int day = cal.get(Calendar.DAY_OF_MONTH);

			String chkAge = StringUtils.defaultString(StringUtils.substring(sCustNo, 6, 7), "0");
			switch (Integer.parseInt(chkAge, 10)) {
				case 0: // 1800����
					break;
				case 1: // ���� 1900���� ��
				case 2: // ���� 1900���� ��
				case 5: // �ܱ� 1900���� ��
				case 6: // �ܱ� 1900���� ��
					chkAge = "19" + sCustNo.substring(0, 2);
					break;
				case 3: // ���� 2000���� ��
				case 4: // ���� 2000���� ��
				case 7: // �ܱ� 2000���� ��
				case 8: // �ܱ� 2000���� ��
					chkAge = "20" + sCustNo.substring(0, 2);
					break;
			}
			fullAge = year - Integer.parseInt(chkAge, 10);

			if (month < Integer.parseInt(sCustNo.substring(2, 4), 10)) {
				fullAge = fullAge - 1;
			} else if (month == Integer.parseInt(sCustNo.substring(2, 4), 10)) {
				if (day < Integer.parseInt(sCustNo.substring(4, 6), 10)) {
					fullAge = fullAge - 1;
				}
			}
		}

		return fullAge;
	}
	
	/**
	 * �ֹι�ȣ ��ȿ��üũ
	 * 20141027 �ܱ����ֹι�ȣ�� üũ�����ϰ� ����
	 * @param ssn
	 * @return
	 */
	public static boolean getSSNValid(final String ssn) {
		
		boolean isKorean = true; 
		int	check	= 0;  
		if( ssn == null || ssn.length() != 13 ) return false; 
		if( Character.getNumericValue( ssn.charAt( 6 ) ) > 4 && Character.getNumericValue( ssn.charAt( 6 ) ) < 9 ) { 
			isKorean = false; 
		} 
		for( int i = 0 ; i < 12 ; i++ ) { 
			if( isKorean ) check += ( ( i % 8 + 2 ) * Character.getNumericValue( ssn.charAt( i ) ) ); 
			else check += ( ( 9 - i % 8 ) * Character.getNumericValue( ssn.charAt( i ) ) ); 
		} 
		if( isKorean ) { 
			check = 11 - ( check % 11 ); 
			check %= 10;	
		}else { 
			int remainder = check % 11; 
			if ( remainder == 0 ) check = 1; 
			else if ( remainder==10 ) check = 0; 
			else check = remainder; 
	
			int check2 = check + 2; 
			if ( check2 > 9 ) check = check2 - 10; 
			else check = check2;	
		} 

		if( check == Character.getNumericValue( ssn.charAt( 12 ) ) ) return true; 
		else return false; 
	}
}
