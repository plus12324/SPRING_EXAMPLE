/*
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.common.util;

import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;

import com.educar.exception.XMLValidationException;

/**
 * <pre>
 * jaxb pojo Object �� w3c.dom.Document ��ü�� ��ȯ���ִ� Ŭ����.
 * 
 * TODO: XMLValidationException�߻��� �޼��� �����Ͽ� ���� �ʿ�
 * </pre>
 * 
 * @author ������(TaeHyung Kim)
 */
public class GenericDocumentConverter {
	/**
	 * EUC-KR static ���
	 */
	public static final String ENCODING = "EUC-KR";

	/**
	 * jaxb pojo Object �� marshaller ��ü�� ��ȯ
	 * 
	 * @param object jaxb pojo Object
	 * @param rootName xml������Ʈ�� �ֻ��� �̸�
	 * @return marshaller ��ü
	 * @throws XMLValidationException
	 */
	private static <T> Marshaller getMarshaller(final T object, final String rootName) {
		try {
			//			final JAXBContext jxbc = JAXBContextFactory.createContext(new Class[] { object.getClass() }, null);
			final JAXBContext jxbc = JAXBContext.newInstance(new Class[] { object.getClass() });
			final Marshaller marshaller = jxbc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_ENCODING, ENCODING);
			return marshaller;
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * jaxb pojo Object �� unMarshaller ��ü�� ��ȯ
	 * 
	 * @param classType ����Ÿ�� Ŭ����
	 * @return unMarshaller ��ü
	 * @throws XMLValidationException
	 */
	private static <T> Unmarshaller getUnmarshaller(final Class<T> classType) {
		try {
			final JAXBContext jxbc = JAXBContext.newInstance(new Class[] { classType });
			return jxbc.createUnmarshaller();
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * jaxb pojo Object �� w3c.dom.Document ��ü�� ��ȯ�Ͽ� ��ȯ
	 * 
	 * @param object jaxb pojo Object
	 * @param rootName xml������Ʈ�� �ֻ��� �̸�
	 * @return w3c.dom.Document ��ü
	 * @throws XMLValidationException
	 */
	public static <T> Document getDocument(final T object, final String rootName) {
		try {
			final Document dc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
			final Marshaller marshaller = GenericDocumentConverter.getMarshaller(object, rootName);
			@SuppressWarnings("unchecked")
			final JAXBElement<T> jaxbElement = new JAXBElement<T>(new QName(rootName), (Class<T>) object.getClass(), object);
			// jaxbElements�� w3c.dom.Document�� ��ȯ
			marshaller.marshal(jaxbElement, dc);

			return dc;
		} catch (final ParserConfigurationException e) {
			throw new XMLValidationException(e);
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * jaxb pojo Object���� xml�� ��ȯ�Ͽ� ��ȯ
	 * 
	 * @param object jaxb pojo Object
	 * @param rootName xml������Ʈ�� �ֻ��� �̸�
	 * @return xml ���ڿ�(String)
	 * @throws XMLValidationException
	 */
	public static <T> String getXml(final T object, final String rootName) {
		final StringWriter result = new StringWriter();
		final Marshaller marshaller = GenericDocumentConverter.getMarshaller(object, rootName);
		@SuppressWarnings("unchecked")
		final JAXBElement<T> jaxbElement = new JAXBElement<T>(new QName(rootName), (Class<T>) object.getClass(), object);
		try {
			// jaxbElements�� StringWirter�� ��ȯ
			marshaller.marshal(jaxbElement, result);
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
		return result.toString();
	}

	/**
	 * w3c.dom.Document ��ü�� jaxb pojo Object�� ��ȯ�Ͽ� ��ȯ
	 * 
	 * @param dc ��ȯ�Ϸ��� w3c.dom.Document
	 * @param classType ����Ÿ�� Ŭ����
	 * @return jaxb pojo ��ü
	 * @throws XMLValidationException
	 */
	public static <T> T getJaxbObject(final Document dc, final Class<T> classType) {
		try {
			final Unmarshaller unMarshaller = GenericDocumentConverter.getUnmarshaller(classType);
			@SuppressWarnings("unchecked")
			final T result = (T) unMarshaller.unmarshal(dc);

			return result;
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * xmlString�� jaxb pojo Object�� ��ȯ�Ͽ� ��ȯ
	 * 
	 * @param xmlString ��ȯ�Ϸ��� xml
	 * @param classType ����Ÿ�� Ŭ����
	 * @return jaxb pojo ��ü
	 * @throws XMLValidationException
	 */
	public static <T> T getJaxbObject(final String xmlString, final Class<T> classType) {
		try {
			final Unmarshaller unMarshaller = GenericDocumentConverter.getUnmarshaller(classType);
			@SuppressWarnings("unchecked")
			final T result = (T) unMarshaller.unmarshal(new StreamSource(new StringReader(xmlString)));

			return result;
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * ��ȯ�� Document�� OutputStream�� ���
	 * 
	 * @param doc w3c.dom.Document ��ü
	 * @param out ����� outputstream
	 * @throws XMLValidationException
	 */
	public static void print(final Document doc, final OutputStream out) {
		GenericDocumentConverter.print(doc, out, Boolean.FALSE);
	}

	/**
	 * ��ȯ�� Document�� OutputStream�� ���
	 * 
	 * @param doc w3c.dom.Document ��ü
	 * @param out ����� outputstream
	 * @param isDebug true�ϰ�� �ε�Ʈ�� �־ ������
	 * @throws XMLValidationException
	 */
	public static void print(final Document doc, final OutputStream out, final boolean isDebug) {
		try {
			final TransformerFactory tfactory = TransformerFactory.newInstance();
			final Transformer serializer = tfactory.newTransformer();
			// �Ƹ���� ���
			if (isDebug) {
				serializer.setOutputProperty(OutputKeys.INDENT, "yes");
			}
			serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			serializer.setOutputProperty("encoding", ENCODING);

			// ���
			serializer.transform(new DOMSource(doc), new StreamResult(out));
		} catch (final TransformerException e) {
			throw new XMLValidationException(e);
		}
	}

	/**
	 * ��ȯ�� jaxb pojo Object�� OutputStream�� ���
	 * 
	 * @param object jaxb pojo Object
	 * @param rootName xml������Ʈ�� �ֻ��� �̸�
	 * @param out ����� outputstream
	 * @throws XMLValidationException
	 */
	public static <T> void print(final T object, final String rootName, final OutputStream out) {
		try {
			final Document doc = GenericDocumentConverter.getDocument(object, rootName);
			final Marshaller marshaller = GenericDocumentConverter.getMarshaller(object, rootName);
			final Unmarshaller unMarshaller = GenericDocumentConverter.getUnmarshaller(object.getClass());
			marshaller.marshal(unMarshaller.unmarshal(doc, object.getClass()), out);
		} catch (final JAXBException e) {
			throw new XMLValidationException(e);
		}
	}
}
