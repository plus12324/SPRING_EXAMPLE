/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.service.backbone.SendBackBoneService;

/**
 * <pre>
 * ���Űź� ��Ʈ�ѷ�
 * <pre>
 * @author ������
 * @since 0.0.10
 */
@Controller
@RequestMapping("/reject")
public class RejectController {

	
	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** �̸��� ���Űź� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private SendBackBoneService sendBackBoneService;

	/**
	 * <pre>
	 * �̸��� ���Űź�
	 * <pre>
	 * @param request
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/rejectEmail")
	public void rejectEmail(final HttpServletResponse servletResponse, @RequestParam(required = true) final String sEmail) throws IOException {
		final boolean isSuccess = sendBackBoneService.rejectEmail(sEmail);
		final String message = isSuccess ? messageService.getMessage(ExceptionMessage.RejectEmailSuccess) : messageService.getMessage(ExceptionMessage.RejectEmailFail);

		final String returnValue = "<script type='text/javascript'>" +
				"alert('" + message + "');" +
				"var win=window.open('','_self');" +
				"win.close();" +		
						"</script>";
		servletResponse.setContentType("text/html");
		servletResponse.setCharacterEncoding("UTF-8");
		servletResponse.getWriter().print(returnValue);
	}
}
