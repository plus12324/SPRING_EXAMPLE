/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.educar.common.dto.PGPayDTO;
import com.educar.common.dto.PGPayInitDTO;
import com.educar.common.dto.PGPayResultDTO;
import com.educar.common.service.PGPaymentService;
import com.educar.common.service.PropertyService;
import com.educar.dto.web.payment.DirectTransferRequestDTO;
import com.educar.enumeration.PGPropertyEnum;
import com.educar.service.backbone.PaymentBackBoneService;

/**
 * PG ��Ʈ�ѷ�
 * @author ������
 * @since 0.0.9
 */
@Deprecated
public class PGPaymentController {

	@Autowired
	PGPaymentService pgPaymentService;
	@Autowired
	PaymentBackBoneService paymentBackBoneService;

	/** ������Ƽ ���� **/
	@Autowired
	private PropertyService propertyService;

	private static final String AMOUNT = "5000";

	/**
	 * �ʱ�ȭ�� ��ȸ
	 * @return
	 */
	@RequestMapping("/pay/pgInitPay")
	public ModelAndView initPay() {
		final ModelAndView mv = new ModelAndView("/pay/payMain.jsp");
		// TODO: �Ⱓ�迡�� ���������� �����ʿ�.
		final DirectTransferRequestDTO dto = new DirectTransferRequestDTO();
		dto.setsReqDate("20121105");
		dto.setsApplyType("A");
		dto.setsApplyYM("1211");
		dto.setsApplySer("0000001");
		dto.setsInsType("0130");
		dto.setsLastAgnt("8000001");
		dto.setnOutAmt("5000");
		dto.setsMsgType("EFT");
		dto.setsEpType("CERT");
		dto.setsApproveNo(propertyService.getProperty(PGPropertyEnum.HD_APPROVE_NO.getKey()));
		dto.setsReceiptAcctNo(propertyService.getProperty(PGPropertyEnum.HD_RECEIPT_ACNT.getKey()));
		// final String hd_serial_no = paymentBackBoneService.insertRequestPayOutAmt(dto, UserIDEnum.WEB_USER.getCode());
		final String hd_serial_no = "0000006";
		// PG���� �ʱ�ȭ �޼ҵ�
		final PGPayInitDTO initDTO = pgPaymentService.getPGPayInitDTO(hd_serial_no, "test@test.com", AMOUNT);

		mv.addObject("pgInitDTO", initDTO);

		return mv;
	}

	/**
	 * ���� ����
	 * @param dto
	 * @return
	 */
	@RequestMapping("/pay/pay")
	public ModelAndView pay(final PGPayDTO dto) {
		final ModelAndView mv = new ModelAndView("/pay/pay.jsp");

		final PGPayResultDTO result = pgPaymentService.excute(dto, AMOUNT);

		// paymentBackBoneService.updateResultPayOutAmt(result, UserIDEnum.WEB_USER.getCode());
		mv.addObject("result", result);
		return mv;
	}
}
