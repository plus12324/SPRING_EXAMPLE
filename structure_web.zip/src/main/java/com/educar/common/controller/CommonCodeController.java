/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.controller;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dto.web.CarDetailSearchDTO;
import com.educar.dto.web.CarDetailSearchResultDTO;
import com.educar.dto.web.JobClassificationDTO;
import com.educar.dto.web.VehicleListDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.service.backbone.CarSearchBackBoneService;
import com.educar.service.web.CodeService;

/**
 * <pre>
 * �ڵ� ��ȸ ��Ʈ�ѷ�(code..tableName)
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("commonCode")
@Controller
public class CommonCodeController {

	/** �ڵ���ȸ ���� */
	@Autowired
	private CodeService codeService;

	@Autowired
	private CarSearchBackBoneService carSearchBackBoneService;

	/**
	 * <pre>
	 * �ڵ��� ã�� - ����ȸ�纰�� ã��
	 * �ڵ��� ���� ȸ�纰 ����, ���� ���ڷ� �ڵ����� ��� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectCarNameList")
	@ResponseBody
	public GenericRestResponse<CarDetailSearchResultDTO> selectCarNameList(@NotNull @RequestBody final GenericRestRequest<CarDetailSearchDTO> request) {
		final List<CarDetailSearchResultDTO> list = carSearchBackBoneService.getValidCarNameForDeclare(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<CarDetailSearchResultDTO> response = new GenericRestResponse<CarDetailSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * �ڵ��� ã�� - �ڵ��������� ã��
	 * �ڵ��������� �ڵ��� �� ���� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectCarInfoList")
	@ResponseBody
	public GenericRestResponse<CarDetailSearchResultDTO> selectCarInfoList(@NotNull @RequestBody final GenericRestRequest<CarDetailSearchDTO> request) {
		final List<CarDetailSearchResultDTO> list = carSearchBackBoneService.carDetailList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<CarDetailSearchResultDTO> response = new GenericRestResponse<CarDetailSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * ���� ��ȸ
	 * sInsType(0418) - �̷�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectVehicleList")
	@ResponseBody
	public GenericRestResponse<VehicleListDTO> selectVehicleList(@NotNull @RequestBody final GenericRestRequest<VehicleListDTO> request) {
		final List<VehicleListDTO> list = codeService.selectVehicleList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<VehicleListDTO> response = new GenericRestResponse<VehicleListDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * ���� ��з� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectJobMainList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> selectJobMainList() {
		// ���� ��з� DB ��ȸ
		final List<JobClassificationDTO> list = codeService.selectJobMainCodeList();
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * ���� �ߺз� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectJobDivisionList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> selectJobDivisionList(@NotNull @RequestBody final GenericRestRequest<JobClassificationDTO> request) {
		final JobClassificationDTO jcdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���� �ߺз� DB ��ȸ
		final List<JobClassificationDTO> list = codeService.selectJobDivisionCodeList(jcdto.getKey());
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * ���� �Һз� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectJobSubList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> selectJobSubList(@NotNull @RequestBody final GenericRestRequest<JobClassificationDTO> request) {
		final JobClassificationDTO jcdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���� �Һз�, �����޼�(sDriveClassDB) ��ȸ
		final List<JobClassificationDTO> list = codeService.selectJobSubCodeList(jcdto.getKey());
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * ���� �� �����ڵ� ���� ����
	 * <pre>
	 */
	@RequestMapping("sessionSetAffiliatedConcernKey")
	@ResponseBody
	public void sessionSetAffiliatedConcernKey(final HttpSession session, @RequestBody final GenericRestRequest<Void> request) {
		// ���� �ڵ带 ���ǿ� ����
		if (request != null && StringUtils.isNotBlank(request.getsAffiliatedConcernKey())) {
			session.setAttribute(SessionNameEnum.AFFILIATED_CONCERN_KEY.name(), request.getsAffiliatedConcernKey());
		}
	}
	
	/**
	 * <pre>
	 * [2014 �����ڵ� ����] ���� ��з� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("select2014JobMainList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> select2014JobMainList(@NotNull @RequestBody final GenericRestRequest<JobClassificationDTO> request) {
		final JobClassificationDTO jcdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���� ��з� DB ��ȸ
		if(StringUtil.isNullOrEmpty(jcdto.getsStdDate())){
			final DateTime now = new DateTime();
			jcdto.setsStdDate(now.toString("yyyyMMdd"));
		}
		final List<JobClassificationDTO> list = codeService.select2014JobMainCodeList(jcdto);
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * [2014 �����ڵ� ����]  ���� �ߺз� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("select2014JobDivisionList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> select2014JobDivisionList(@NotNull @RequestBody final GenericRestRequest<JobClassificationDTO> request) {
		final JobClassificationDTO jcdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���� �ߺз� DB ��ȸ
		if(StringUtil.isNullOrEmpty(jcdto.getsStdDate())){
			final DateTime now = new DateTime();
			jcdto.setsStdDate(now.toString("yyyyMMdd"));
		}
		final List<JobClassificationDTO> list = codeService.select2014JobDivisionCodeList(jcdto);
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}

	/**
	 * <pre>
	 * [2014 �����ڵ� ����] ���� �Һз� ��������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("select2014JobSubList")
	@ResponseBody
	public GenericRestResponse<JobClassificationDTO> select2014JobSubList(@NotNull @RequestBody final GenericRestRequest<JobClassificationDTO> request) {
		final JobClassificationDTO jcdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���� �Һз�, �����޼�(sDriveClassDB) ��ȸ
		if(StringUtil.isNullOrEmpty(jcdto.getsStdDate())){
			final DateTime now = new DateTime();
			jcdto.setsStdDate(now.toString("yyyyMMdd"));
		}
		final List<JobClassificationDTO> list = codeService.select2014JobSubCodeList(jcdto);
		final GenericRestResponse<JobClassificationDTO> response = new GenericRestResponse<JobClassificationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}
}
