/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.common.controller;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.util.PropertyUtil;
import com.educar.enumeration.VersionEnum;

/**
 * TODO : EDUCAR-359 - production mode���� ���� ������ �Ⱥ��̰� ���� �ʿ�
 * Common Controller
 * @author �ڼ���(SeongJin Park)
 */
@Controller
public class VersionController {

	/**
	 * ������Ʈ ���� version
	 */
	private String version;

	/**
	 * version ���� �ʱ�ȭ �Ѵ�.
	 * version.txt�� ������ �о ó��, ������ version unavailable
	 */
	@PostConstruct
	public void init() {
		final String versionFileName = "version.txt";
		if (this.getClass().getClassLoader().getResourceAsStream(versionFileName) != null) {
			final PropertyUtil propertyUtil = new PropertyUtil(versionFileName);
			version = propertyUtil.getProperty(VersionEnum.VersionNumber.name()) + "  " + propertyUtil.getProperty(VersionEnum.BuildTime.name());
		} else {
			version = "required build!";
		}
	}

	/**
	 * ������Ʈ ���� version ��ȸ
	 */
	@RequestMapping("/version")
	@ResponseBody
	public GenericRestResponse<String> version() {
		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		response.setMessage(version);
		return response;
	}
}
