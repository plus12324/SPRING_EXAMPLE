/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.controller;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.tuckey.web.filters.urlrewrite.utils.StringUtils;

import com.educar.common.dto.CityCountyCodeDTO;
import com.educar.common.dto.NewRoadNameAddSearchDTO;
import com.educar.common.dto.PostCodeAddressSearchDTO;
import com.educar.common.dto.RoadNameAddressSearchDTO;
import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.claim.ClaimCodeDTO;
import com.educar.dto.web.claim.ClaimPostCodeAddressResultDTO;
import com.educar.dto.web.claim.ClaimRoadNameAddressResultDTO;
import com.educar.dto.web.products.SchoolSearchResultDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.ClaimBackBoneService;

/**
 * <pre>
 * ������ȣ �˻� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@Controller
@RequestMapping("/address")
public class AddressController {

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	
	/** ���� �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private ClaimBackBoneService claimBackBoneService;

	/**
	 * <pre>
	 * ������ȣ ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectPostCodeAddress")
	@ResponseBody
	public GenericRestResponse<PostCodeAddressSearchDTO> selectPostCodeAddress(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sTownName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<PostCodeAddressSearchDTO> resultList = adresssSearchBackBoneService.postCodeAddressList(sTownName);

		final GenericRestResponse<PostCodeAddressSearchDTO> response = new GenericRestResponse<PostCodeAddressSearchDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}
	
	/**
	 * <pre>
	 * ���θ��ּ� ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectRoadNameAddress")
	@ResponseBody
	public GenericRestResponse<RoadNameAddressSearchDTO> selectRoadNameAddress(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sRoadName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<RoadNameAddressSearchDTO> resultList = adresssSearchBackBoneService.roadNameAddressList(sRoadName);

		final GenericRestResponse<RoadNameAddressSearchDTO> response = new GenericRestResponse<RoadNameAddressSearchDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * ����� ������ȣ ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 * �Ž¿�
	 */
	@RequestMapping("/selectPostCodeRewardAddress")
	@ResponseBody
	public GenericRestResponse<ClaimPostCodeAddressResultDTO> selectPostCodeRewardAddress(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sTownName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<ClaimPostCodeAddressResultDTO> resultList = claimBackBoneService.claimPostCodeAddressList(sTownName);
		
		final GenericRestResponse<ClaimPostCodeAddressResultDTO> response = new GenericRestResponse<ClaimPostCodeAddressResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}
	
	/**
	 * <pre>
	 * ����� ���θ� �ּ� ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 * �Ž¿�
	 */
	@RequestMapping("/selectRewardRoadNameAddress")
	@ResponseBody
	public GenericRestResponse<ClaimRoadNameAddressResultDTO> selectRewardRoadNameAddress(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sTownName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<ClaimRoadNameAddressResultDTO> resultList = claimBackBoneService.claimRoadNameAddressList(null, sTownName);
		 
		final GenericRestResponse<ClaimRoadNameAddressResultDTO> response = new GenericRestResponse<ClaimRoadNameAddressResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}	
	
	
	/**
	 * �б��� �˻�
	 */
	@RequestMapping("/selectSchool")
	@ResponseBody
	public GenericRestResponse<SchoolSearchResultDTO> selectSchool(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sSchoolName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<SchoolSearchResultDTO> response = new GenericRestResponse<SchoolSearchResultDTO>();

		if (StringUtils.isBlank(sSchoolName)) {
			// ��ü �˻��ǹǷ� ������ �Է�������� ����
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(messageService.getMessage(ExceptionMessage.InvalidRequest));
		} else {
			final List<SchoolSearchResultDTO> resultList = adresssSearchBackBoneService.selectSchoolByNameForWeb(sSchoolName);
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(resultList);
		}
		return response;
	}

	/**
	 * ����ڸ� �˻�
	 */
	@RequestMapping("/selectOffice")
	@ResponseBody
	public GenericRestResponse<SchoolSearchResultDTO> selectOffice(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sOfficeName = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<SchoolSearchResultDTO> response = new GenericRestResponse<SchoolSearchResultDTO>();

		if (StringUtils.isBlank(sOfficeName)) {
			// ��ü �˻��ǹǷ� ������ �Է�������� ����
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(messageService.getMessage(ExceptionMessage.InvalidRequest));
		} else {
			final List<SchoolSearchResultDTO> resultList = adresssSearchBackBoneService.selectOfficeName(sOfficeName);
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(resultList);
		}
		return response;
	}

	/**
	 * ��/���� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<ClaimCodeDTO>
	 */
	@RequestMapping("/selectCity")
	@ResponseBody
	public GenericRestResponse<ClaimCodeDTO> selectCity(@RequestBody @NotNull final GenericRestRequest<String> request) {
		final List<ClaimCodeDTO> resultList = adresssSearchBackBoneService.selectCity();
		final GenericRestResponse<ClaimCodeDTO> response = new GenericRestResponse<ClaimCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * ��/�� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<SchoolStaffSearchResultDTO> ������ ����Ʈ (��, �ּ�, ��ȭ��ȣ, �ѽ���ȣ, ������ǥ��ȣ)
	 */
	@RequestMapping("/selectGu")
	@ResponseBody
	public GenericRestResponse<ClaimCodeDTO> selectGu(@RequestBody @NotNull final GenericRestRequest<String> request) {
		final String selectCity = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<ClaimCodeDTO> resultList = adresssSearchBackBoneService.selectGu(selectCity);
		final GenericRestResponse<ClaimCodeDTO> response = new GenericRestResponse<ClaimCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}
	
	
	/**
	 * (����)��/���� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<CityCodeDTO>
	 */
	@RequestMapping("/selectCmnCity")
	@ResponseBody
	public GenericRestResponse<CityCountyCodeDTO> selectCmnCity(@RequestBody @NotNull final GenericRestRequest<String> request) {
		final List<CityCountyCodeDTO> resultList = adresssSearchBackBoneService.selectCityCode();
		final GenericRestResponse<CityCountyCodeDTO> response = new GenericRestResponse<CityCountyCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * (����)��/�� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<CountyCodeDTO> 
	 */
	@RequestMapping("/selectCmnGu")
	@ResponseBody
	public GenericRestResponse<CityCountyCodeDTO> selectCmnGu(@RequestBody @NotNull final GenericRestRequest<String> request) {
		final String selectCity = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<CityCountyCodeDTO> resultList = adresssSearchBackBoneService.selectGuCode(selectCity);
		final GenericRestResponse<CityCountyCodeDTO> response = new GenericRestResponse<CityCountyCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}
	
	
	/**
	 * <pre>
	 * new ���θ��ּ� ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectNewRoadNameAddr")
	@ResponseBody
	public GenericRestResponse<NewRoadNameAddSearchDTO> selectNewRoadNameAddress(@NotNull @RequestBody final GenericRestRequest<NewRoadNameAddSearchDTO> request) {
		final NewRoadNameAddSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<NewRoadNameAddSearchDTO> resultList = adresssSearchBackBoneService.newRoadNameAddressList(requestDto);

		final GenericRestResponse<NewRoadNameAddSearchDTO> response = new GenericRestResponse<NewRoadNameAddSearchDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}
	
	/**
	 * <pre>
	 * ǥ�ص��θ� �ּ� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectStandardAddrInfo")
	@ResponseBody
	public GenericRestResponse<StandardRoadAddrDTO> selectStandardAddrInfo(@NotNull @RequestBody final GenericRestRequest<StandardRoadAddrDTO> request) {
		final StandardRoadAddrDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final StandardRoadAddrDTO result = adresssSearchBackBoneService.selectStandardAddr(requestDto);

		final GenericRestResponse<StandardRoadAddrDTO> response = new GenericRestResponse<StandardRoadAddrDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}
}
