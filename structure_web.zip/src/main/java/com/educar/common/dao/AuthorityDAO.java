/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.common.dto.AuthorityUrlDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * <pre>
 * ���� ���� DAO
 * </pre>
 *
 * @author �ڼ���(SeongJin Park)
 *
 */
@Repository
public class AuthorityDAO extends EgovComAbstractDAO {

	/**
	 * 
	 * <pre>
	 * URL ���� ��ȸ
	 * <pre>
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AuthorityUrlDTO> selectAuthorityUrlList(final AuthorityUrlDTO dto) {
		return (List<AuthorityUrlDTO>) list("authority.selectAuthorityUrlList", dto);
	}
}
