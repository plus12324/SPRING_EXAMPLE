/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.common.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.educar.common.dto.PolicyDTO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/**
 * <pre>
 * ������� Dao
 * </pre>
 * 
 * @author �ڼ���(SeongJin Park)
 * 
 */
@Repository
public class PolicyDAO extends EgovComAbstractDAO {

	/**
	 * 
	 * <pre>
	 * ������� ����Ʈ ��ȸ
	 * 
	 * <pre>
	 * @param indexes
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PolicyDTO> getPolicyList(final List<Long> indexList) {
		return (List<PolicyDTO>) list("policy.getPolicyList", indexList);
	}
}
