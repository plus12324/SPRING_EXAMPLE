/**
 * Copyright (c) 2014, All rights reserved.
 * �����̼��غ��� ������
 * All codes are licensed to The-K
 */
package com.educar.common.interceptor;

import java.io.Serializable;
import java.util.Map;
import javax.servlet.http.HttpSession;

public class LoginSessionID implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static Map<String,HttpSession> map;
	
	public Map<String, HttpSession> getMap() {
		return map;
	}

	public void setMap(Map<String, HttpSession> map) {
		this.map = map;
	}
}
