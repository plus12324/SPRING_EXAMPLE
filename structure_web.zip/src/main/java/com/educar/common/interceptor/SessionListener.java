package com.educar.common.interceptor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionBindingEvent;

import org.apache.log4j.Logger;
import com.educar.common.service.DistributedCacheService;
import com.educar.enumeration.CacheEnum;
import com.educar.enumeration.CacheKeyEnum;

import org.springframework.cache.Cache;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SessionListener implements HttpSessionBindingListener {
	
	private final Logger logger = Logger.getLogger(this.getClass());	
	private String ssn = ""; 
	
	public SessionListener(){}
	
	public SessionListener(String ssn){
		this.ssn = ssn;
	}
	
	@Override
	public void valueBound(HttpSessionBindingEvent se) {		
		//���� ����
		HttpSession session = se.getSession();
		
		/** �ߺ��α��� Ȯ�� map ���� **/
		if(session != null){
			
			ApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(session.getServletContext());
			DistributedCacheService cacheService = (DistributedCacheService) ctx.getBean("cacheManager");
			LoginSessionID loginSessionID = (LoginSessionID) cacheService.getLoginSessionMap();
						
			if(loginSessionID == null)	
				loginSessionID = (LoginSessionID) ctx.getBean("loginSessionID");
						
			Map<String, HttpSession> tmp = (HashMap<String, HttpSession>) loginSessionID.getMap();
						
			if(tmp == null){
				tmp = new HashMap<String, HttpSession>();
			}
			else {
				Set key= tmp.keySet();				
				for(Iterator i = key.iterator();i.hasNext();){
					String keyNo = (String)i.next();
					
					if(ssn.equals(keyNo)){
						HttpSession preSession = tmp.get(keyNo);
						
						logger.info("[�ڼ��Ǹ�����][�ߺ��α���Ž��] valueBound().��������� INVALIDATE()�Ϸ�! : " + keyNo);
						if(preSession != null)	preSession.invalidate();
						break;
					}
				}
			}
			
			tmp.put(ssn, session);
			
			//applicationContext ����ҿ� ����
			loginSessionID.setMap(tmp);
			
			//hazelcast �л�ĳ���� ����
			final Cache sessionCache = cacheService.getCache(CacheEnum.SESSION_CACHE_MAP.getName());
			sessionCache.put(CacheKeyEnum.SESSION_MAP.name(), loginSessionID);
		}
		/** �ߺ��α��� Ȯ�� map �� **/
	}	
	
	@Override
	public void valueUnbound(HttpSessionBindingEvent se) {		
		//���� ����
		HttpSession session = se.getSession();
		
		ApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(session.getServletContext());
		DistributedCacheService cacheService = (DistributedCacheService) ctx.getBean("cacheManager");
		LoginSessionID loginSessionID = (LoginSessionID) cacheService.getLoginSessionMap();
		
		Map<String, HttpSession> historyMap = (HashMap<String, HttpSession>) loginSessionID.getMap();    	
		
		if(historyMap != null){
			Set historyKey= historyMap.keySet();
			for(Iterator i = historyKey.iterator();i.hasNext();){
				String keyNo = (String)i.next();
				
				if(ssn.equals(keyNo)){
					historyMap.remove(keyNo);
					logger.info("[�ڼ��Ǹ�����] valueUnbound().historyMap.remove() �Ϸ�! : " + keyNo);
					break;
				}
			}
		}		
		
		//applicationContext ����ҿ� ����
		loginSessionID.setMap(historyMap);
		
		// �л�ĳ���� ����
		final Cache sessionCache = cacheService.getCache(CacheEnum.SESSION_CACHE_MAP.getName());
		sessionCache.put(CacheKeyEnum.SESSION_MAP.name(), loginSessionID);
	}
}
