/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * <pre>
 * ���� session VO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "paymentVO")
public class PaymentVO implements Serializable {

	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** û���ȣ���� **/
	@ValidateLength(required = true, max = 1)
	private String sApplyType;
	/** û���ȣ�⵵ **/
	@ValidateDate(required = true, dateFormat = DateFormat.yyyy)
	private String sApplyYM;
	/** û���ȣSER **/
	@ValidateLength(required = true, max = 7, min = 7)
	private String sApplySer;
	/** �輭 ���� �ڵ� **/
	@ValidateRegex(regex = "[ABC][1-4]")
	private String sEndorseCodeForWeb;
	/** ���� �ݾ�(�ִ� 9,999,999 ���� ����) */
	@ValidateRegex(regex = "[0-9]{7}")
	private String nReqAmt;
	/** ȯ�� �ݾ�(�ִ� 9,999,999 ���� ����) */
	@ValidateRegex(regex = "[0-9]{7}")
	private String nRefundAmt;
	/** ����� ���� **/
	@ValidateLength(required = true, min = 2, max = 20)
	private String sUserName;
	/** ���� �ڵ�(���ΰ��� Ȯ�ο�) **/
	private String sOwnedBankCode;
	/** ���� ��ȣ(���ΰ��� Ȯ�ο�) **/
	private String sOwnedAccountNo;
	/** ���ΰ��� Ȯ�� ���� default=false (���ΰ��� Ȯ�ο�) **/
	private boolean isOwnedAccount = false;
	/** ���� ��ǰ�� ���� ����(InsuranceProductEnum.getType() 0:�ڵ���, 1:�Ϲ�, 2:���) **/
	private String sInsGrp;
	/** ī�� ����Ʈ : ī�� ������ ��� **/
	private int nCardPoint;
	/** ���� �ڵ� **/
	private String sInsType;
	/** 35�� ���� �ʿ俩�� **/
	private boolean isRequiredAgree35 = false;
	/** ��α��� ������ ��� ����ϴ� ���� �̸� **/
	private String sessionName;

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sEndorseCodeForWeb
	 */
	public String getsEndorseCodeForWeb() {
		return sEndorseCodeForWeb;
	}

	/**
	 * @param sEndorseCodeForWeb the sEndorseCodeForWeb to set
	 */
	public void setsEndorseCodeForWeb(final String sEndorseCodeForWeb) {
		this.sEndorseCodeForWeb = sEndorseCodeForWeb;
	}

	/**
	 * @return the nReqAmt
	 */
	public String getnReqAmt() {
		return nReqAmt;
	}

	/**
	 * @param nReqAmt the nReqAmt to set
	 */
	public void setnReqAmt(final String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}

	/**
	 * @return the nRefundAmt
	 */
	public String getnRefundAmt() {
		return nRefundAmt;
	}

	/**
	 * @param nRefundAmt the nRefundAmt to set
	 */
	public void setnRefundAmt(final String nRefundAmt) {
		this.nRefundAmt = nRefundAmt;
	}

	/**
	 * @return the sUserName
	 */
	public String getsUserName() {
		return sUserName;
	}

	/**
	 * @param sUserName the sUserName to set
	 */
	public void setsUserName(final String sUserName) {
		this.sUserName = sUserName;
	}

	/**
	 * @return the sOwnedBankCode
	 */
	public String getsOwnedBankCode() {
		return sOwnedBankCode;
	}

	/**
	 * @param sOwnedBankCode the sOwnedBankCode to set
	 */
	public void setsOwnedBankCode(final String sOwnedBankCode) {
		this.sOwnedBankCode = sOwnedBankCode;
	}

	/**
	 * @return the sOwnedAccountNo
	 */
	public String getsOwnedAccountNo() {
		return sOwnedAccountNo;
	}

	/**
	 * @param sOwnedAccountNo the sOwnedAccountNo to set
	 */
	public void setsOwnedAccountNo(final String sOwnedAccountNo) {
		this.sOwnedAccountNo = sOwnedAccountNo;
	}

	/**
	 * @return the isOwnedAccount
	 */
	public boolean isOwnedAccount() {
		return isOwnedAccount;
	}

	/**
	 * @param isOwnedAccount the isOwnedAccount to set
	 */
	public void setOwnedAccount(final boolean isOwnedAccount) {
		this.isOwnedAccount = isOwnedAccount;
	}

	/**
	 * @return the sInsGrp
	 */
	public String getsInsGrp() {
		return sInsGrp;
	}

	/**
	 * @param sInsGrp the sInsGrp to set
	 */
	public void setsInsGrp(final String sInsGrp) {
		this.sInsGrp = sInsGrp;
	}

	/**
	 * @return the nCardPoint
	 */
	public int getnCardPoint() {
		return nCardPoint;
	}

	/**
	 * @param nCardPoint the nCardPoint to set
	 */
	public void setnCardPoint(final int nCardPoint) {
		this.nCardPoint = nCardPoint;
	}

	public String getApplyNo() {
		return sApplyType + sApplyYM + sApplySer;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the isRequiredAgree35
	 */
	public boolean isRequiredAgree35() {
		return isRequiredAgree35;
	}

	/**
	 * @param isRequiredAgree35 the isRequiredAgree35 to set
	 */
	public void setRequiredAgree35(final boolean isRequiredAgree35) {
		this.isRequiredAgree35 = isRequiredAgree35;
	}

	/**
	 * @return the sessionName
	 */
	public String getSessionName() {
		return sessionName;
	}

	/**
	 * @param sessionName the sessionName to set
	 */
	public void setSessionName(final String sessionName) {
		this.sessionName = sessionName;
	}
}
