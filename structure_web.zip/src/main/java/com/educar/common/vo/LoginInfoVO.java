/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.enumeration.AuthorityEnum;

/**
 * ���ǿ� ������ �α��� ���� ��ü
 * 
 * @author ������
 * 
 */
@XmlRootElement(name = "loginInfoVO")
public class LoginInfoVO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ���ڱ���ȸ��ID **/
	private String ID;
	/** �̸� **/
	private String sName;
	/** ���� **/
	private AuthorityEnum sAutority;
	/** �ֹι�ȣ **/
	private String SSN;
	/** ������� **/
	private String sBirthDate;
	/** ���� **/
	private String sSex;
	/** �޴��� ��ȣ 1 */
	private String sCellPhone1;
	/** �޴��� ��ȣ 2 */
	private String sCellPhone2;
	/** �޴��� ��ȣ 3 */
	private String sCellPhone3;
	/** �̸����ּ� */
	private String sEmail;
	/** �ű��ּ� Ÿ��(0:�����ּ�, 1 : ���θ��ּ�) */
	private String sZipType;
	/** ������ȣ �� 3�ڸ� **/
	private String sZip1;
	/** ������ȣ �� 3�ڸ� **/
	private String sZip2;
	/** �ּ� 1**/
	private String sAdrs1;
	/** �ּ� 2 **/
	private String sAdrs2;
	/** �ּ� 3 **/
	private String sAdrs3;
	/** ������ �ּ� **/
	private String sAdrsAdd;

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sAutority
	 */
	public AuthorityEnum getsAutority() {
		return sAutority;
	}

	/**
	 * @param sAutority the sAutority to set
	 */
	public void setsAutority(final AuthorityEnum sAutority) {
		this.sAutority = sAutority;
	}

	/**
	 * @return the sSN
	 */
	public String getSSN() {
		return SSN;
	}

	/**
	 * @param sSN the sSN to set
	 */
	public void setSSN(final String sSN) {
		SSN = sSN;
	}

	/**
	 * @return the sZipType
	 */
	public String getsZipType() {
		return sZipType;
	}

	/**
	 * @param sZipType the sZipType to set
	 */
	public void setsZipType(final String sZipType) {
		this.sZipType = sZipType;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the birthday
	 */
	public String getsBirthDate() {
		return sBirthDate;
	}

	/**
	 * @param birthday the birthday to set
	 */
	public void setsBirthDate(final String sBirthDate) {
		this.sBirthDate = sBirthDate;
	}

	/**
	 * @return the sex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sex the sex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final String iD) {
		ID = iD;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}

	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(final String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}
}
