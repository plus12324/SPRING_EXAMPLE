/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

/**
 * �⺻ �ڵ� ���� VO
 * @author ������
 *
 */
public class BasicCodeVO implements Serializable {
	/** default **/
	private static final long serialVersionUID = 1L;
	private String sQuestion;
	private String sContactPath;
	private String sEventDiv;
	private String CCCEA07Task1;
	private String sDescription1;
	private String CCCEA07Task2;
	private String sDescription2;
	private String CCCEA07Task3;
	private String sDescription3;
	private String CCCEA07Task4;
	private String sDescription4;
	private String CCCEA07Task5;
	private String sDescription5;
	private String CCCEA04TimeInTask;
	private String CCCEA04TimeOutTask;
	private String CCCEA04TimeInGiContractorTask;
	private String CCCEA04TimeOutGiContractorTask;
	private String CCCEA04TimeInMiContractorTask;
	private String CCCEA04TimeOutMiContractorTask;
	private String CCCEA04TimeOutWSRTask;

	/**
	 * @return the sQuestion
	 */
	public String getsQuestion() {
		return sQuestion;
	}

	/**
	 * @param sQuestion the sQuestion to set
	 */
	public void setsQuestion(final String sQuestion) {
		this.sQuestion = sQuestion;
	}

	/**
	 * @return the sContactPath
	 */
	public String getsContactPath() {
		return sContactPath;
	}

	/**
	 * @param sContactPath the sContactPath to set
	 */
	public void setsContactPath(final String sContactPath) {
		this.sContactPath = sContactPath;
	}

	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}

	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(final String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	/**
	 * @return the cCCEA07Task1
	 */
	public String getCCCEA07Task1() {
		return CCCEA07Task1;
	}

	/**
	 * @param cCCEA07Task1 the cCCEA07Task1 to set
	 */
	public void setCCCEA07Task1(final String cCCEA07Task1) {
		CCCEA07Task1 = cCCEA07Task1;
	}

	/**
	 * @return the sDescription1
	 */
	public String getsDescription1() {
		return sDescription1;
	}

	/**
	 * @param sDescription1 the sDescription1 to set
	 */
	public void setsDescription1(final String sDescription1) {
		this.sDescription1 = sDescription1;
	}

	/**
	 * @return the cCCEA07Task2
	 */
	public String getCCCEA07Task2() {
		return CCCEA07Task2;
	}

	/**
	 * @param cCCEA07Task2 the cCCEA07Task2 to set
	 */
	public void setCCCEA07Task2(final String cCCEA07Task2) {
		CCCEA07Task2 = cCCEA07Task2;
	}

	/**
	 * @return the sDescription2
	 */
	public String getsDescription2() {
		return sDescription2;
	}

	/**
	 * @param sDescription2 the sDescription2 to set
	 */
	public void setsDescription2(final String sDescription2) {
		this.sDescription2 = sDescription2;
	}

	/**
	 * @return the cCCEA07Task3
	 */
	public String getCCCEA07Task3() {
		return CCCEA07Task3;
	}

	/**
	 * @param cCCEA07Task3 the cCCEA07Task3 to set
	 */
	public void setCCCEA07Task3(final String cCCEA07Task3) {
		CCCEA07Task3 = cCCEA07Task3;
	}

	/**
	 * @return the sDescription3
	 */
	public String getsDescription3() {
		return sDescription3;
	}

	/**
	 * @param sDescription3 the sDescription3 to set
	 */
	public void setsDescription3(final String sDescription3) {
		this.sDescription3 = sDescription3;
	}

	/**
	 * @return the cCCEA07Task4
	 */
	public String getCCCEA07Task4() {
		return CCCEA07Task4;
	}

	/**
	 * @param cCCEA07Task4 the cCCEA07Task4 to set
	 */
	public void setCCCEA07Task4(final String cCCEA07Task4) {
		CCCEA07Task4 = cCCEA07Task4;
	}

	/**
	 * @return the sDescription4
	 */
	public String getsDescription4() {
		return sDescription4;
	}

	/**
	 * @param sDescription4 the sDescription4 to set
	 */
	public void setsDescription4(final String sDescription4) {
		this.sDescription4 = sDescription4;
	}

	/**
	 * @return the cCCEA07Task5
	 */
	public String getCCCEA07Task5() {
		return CCCEA07Task5;
	}

	/**
	 * @param cCCEA07Task5 the cCCEA07Task5 to set
	 */
	public void setCCCEA07Task5(final String cCCEA07Task5) {
		CCCEA07Task5 = cCCEA07Task5;
	}

	/**
	 * @return the sDescription5
	 */
	public String getsDescription5() {
		return sDescription5;
	}

	/**
	 * @param sDescription5 the sDescription5 to set
	 */
	public void setsDescription5(final String sDescription5) {
		this.sDescription5 = sDescription5;
	}

	/**
	 * @return the cCCEA04TimeInTask
	 */
	public String getCCCEA04TimeInTask() {
		return CCCEA04TimeInTask;
	}

	/**
	 * @param cCCEA04TimeInTask the cCCEA04TimeInTask to set
	 */
	public void setCCCEA04TimeInTask(final String cCCEA04TimeInTask) {
		CCCEA04TimeInTask = cCCEA04TimeInTask;
	}

	/**
	 * @return the cCCEA04TimeOutTask
	 */
	public String getCCCEA04TimeOutTask() {
		return CCCEA04TimeOutTask;
	}

	/**
	 * @param cCCEA04TimeOutTask the cCCEA04TimeOutTask to set
	 */
	public void setCCCEA04TimeOutTask(final String cCCEA04TimeOutTask) {
		CCCEA04TimeOutTask = cCCEA04TimeOutTask;
	}

	/**
	 * @return the cCCEA04TimeInGiContractorTask
	 */
	public String getCCCEA04TimeInGiContractorTask() {
		return CCCEA04TimeInGiContractorTask;
	}

	/**
	 * @param cCCEA04TimeInGiContractorTask the cCCEA04TimeInGiContractorTask to set
	 */
	public void setCCCEA04TimeInGiContractorTask(final String cCCEA04TimeInGiContractorTask) {
		CCCEA04TimeInGiContractorTask = cCCEA04TimeInGiContractorTask;
	}

	/**
	 * @return the cCCEA04TimeOutGiContractorTask
	 */
	public String getCCCEA04TimeOutGiContractorTask() {
		return CCCEA04TimeOutGiContractorTask;
	}

	/**
	 * @param cCCEA04TimeOutGiContractorTask the cCCEA04TimeOutGiContractorTask to set
	 */
	public void setCCCEA04TimeOutGiContractorTask(final String cCCEA04TimeOutGiContractorTask) {
		CCCEA04TimeOutGiContractorTask = cCCEA04TimeOutGiContractorTask;
	}

	/**
	 * @return the cCCEA04TimeInMiContractorTask
	 */
	public String getCCCEA04TimeInMiContractorTask() {
		return CCCEA04TimeInMiContractorTask;
	}

	/**
	 * @param cCCEA04TimeInMiContractorTask the cCCEA04TimeInMiContractorTask to set
	 */
	public void setCCCEA04TimeInMiContractorTask(final String cCCEA04TimeInMiContractorTask) {
		CCCEA04TimeInMiContractorTask = cCCEA04TimeInMiContractorTask;
	}

	/**
	 * @return the cCCEA04TimeOutMiContractorTask
	 */
	public String getCCCEA04TimeOutMiContractorTask() {
		return CCCEA04TimeOutMiContractorTask;
	}

	/**
	 * @param cCCEA04TimeOutMiContractorTask the cCCEA04TimeOutMiContractorTask to set
	 */
	public void setCCCEA04TimeOutMiContractorTask(final String cCCEA04TimeOutMiContractorTask) {
		CCCEA04TimeOutMiContractorTask = cCCEA04TimeOutMiContractorTask;
	}

	/**
	 * @return the cCCEA04TimeOutWSRTask
	 */
	public String getCCCEA04TimeOutWSRTask() {
		return CCCEA04TimeOutWSRTask;
	}

	/**
	 * @param cCCEA04TimeOutWSRTask the cCCEA04TimeOutWSRTask to set
	 */
	public void setCCCEA04TimeOutWSRTask(final String cCCEA04TimeOutWSRTask) {
		CCCEA04TimeOutWSRTask = cCCEA04TimeOutWSRTask;
	}

}
