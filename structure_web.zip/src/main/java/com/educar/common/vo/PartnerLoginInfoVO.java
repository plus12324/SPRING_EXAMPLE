/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���ǿ� ������ ���¾�ü �α��� ���� ��ü
 * 
 * @author ���ѳ�
 * 
 */
@XmlRootElement(name = "partnerLoginInfoVO")
public class PartnerLoginInfoVO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ����ڵ�Ϲ�ȣ **/
	private String sBizRegiNo;
	/** ����ڸ� **/
	private String sCompanyName;
	/** ���¾�ü�ڵ� **/
	private String sCorrespondent;
	/** ��ü���� **/
	private String sCompanyType;
	/** ����ڱ��� **/
	private String sJobDiv;
	/** 	����ڸ�	 **/ 
	private String 	sName;
	/** 	�������	 **/ 
	private String 	sBirthYear;
	/** 	����	 **/ 
	private String 	sJobTitle;
	/** 	�ڵ���1	 **/ 
	private String 	sCellPhone1;
	/** 	�ڵ���2	 **/ 
	private String 	sCellPhone2;
	/** 	�ڵ���3	 **/ 
	private String 	sCellPhone3;
	/** �����ü ���� **/
	private String sAppDiv;
	/**
	 * @return the sBizRegiNo
	 */
	public String getsBizRegiNo() {
		return sBizRegiNo;
	}
	/**
	 * @param sBizRegiNo the sBizRegiNo to set
	 */
	public void setsBizRegiNo(String sBizRegiNo) {
		this.sBizRegiNo = sBizRegiNo;
	}
	/**
	 * @return the sCompanyName
	 */
	public String getsCompanyName() {
		return sCompanyName;
	}
	/**
	 * @param sCompanyName the sCompanyName to set
	 */
	public void setsCompanyName(String sCompanyName) {
		this.sCompanyName = sCompanyName;
	}
	/**
	 * @return the sCorrespondent
	 */
	public String getsCorrespondent() {
		return sCorrespondent;
	}
	/**
	 * @param sCorrespondent the sCorrespondent to set
	 */
	public void setsCorrespondent(String sCorrespondent) {
		this.sCorrespondent = sCorrespondent;
	}
	/**
	 * @return the sCompanyType
	 */
	public String getsCompanyType() {
		return sCompanyType;
	}
	/**
	 * @param sCompanyType the sCompanyType to set
	 */
	public void setsCompanyType(String sCompanyType) {
		this.sCompanyType = sCompanyType;
	}
	/**
	 * @return the sJobDiv
	 */
	public String getsJobDiv() {
		return sJobDiv;
	}
	/**
	 * @param sJobDiv the sJobDiv to set
	 */
	public void setsJobDiv(String sJobDiv) {
		this.sJobDiv = sJobDiv;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sBirthYear
	 */
	public String getsBirthYear() {
		return sBirthYear;
	}
	/**
	 * @param sBirthYear the sBirthYear to set
	 */
	public void setsBirthYear(String sBirthYear) {
		this.sBirthYear = sBirthYear;
	}
	/**
	 * @return the sJobTitle
	 */
	public String getsJobTitle() {
		return sJobTitle;
	}
	/**
	 * @param sJobTitle the sJobTitle to set
	 */
	public void setsJobTitle(String sJobTitle) {
		this.sJobTitle = sJobTitle;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sAppDiv
	 */
	public String getsAppDiv() {
		return sAppDiv;
	}
	/**
	 * @param sAppDiv the sAppDiv to set
	 */
	public void setsAppDiv(String sAppDiv) {
		this.sAppDiv = sAppDiv;
	}
	
	
}
