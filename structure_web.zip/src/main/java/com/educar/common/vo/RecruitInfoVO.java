/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;



/**
 *  ���ǿ� ������ �Ի����� ���� ��ü
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "recruitInfoVO")
@XmlAccessorType(XmlAccessType.FIELD)
public class RecruitInfoVO implements Serializable{
	
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/**	ä���ȣ             	**/	
	private String	sHireNo;
	
	/**	�ѱ۸�	**/	
	private String	sKorName;
	
	/**	Email	**/	
	private String	sEmail;
	
	/**	������ȣ            **/	
	public String	nApplyNo;
	
	/**	�̷¼�����Ϸ�           **/	
	public String	sResumeConfirmYN;	
	
	/**	��������й�ȣ	**/	
	private String	sPassword;
	
	
	/**	������� 0:�űԻ���� ����̵� 1:�̷¼� �ۼ��̵� 2:�̷¼� �����̵�           **/	
	public String	result;	 

	
	
	/**
	 * @return the sKorName
	 */
	public String getsKorName() {
		return sKorName;
	}

	/**
	 * @param sKorName the sKorName to set
	 */
	public void setsKorName(String sKorName) {
		this.sKorName = sKorName;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sResumeConfirmYN
	 */
	public String getsResumeConfirmYN() {
		return sResumeConfirmYN;
	}

	/**
	 * @param sResumeConfirmYN the sResumeConfirmYN to set
	 */
	public void setsResumeConfirmYN(String sResumeConfirmYN) {
		this.sResumeConfirmYN = sResumeConfirmYN;
	}

	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}

	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}








	
	

	
	
}
