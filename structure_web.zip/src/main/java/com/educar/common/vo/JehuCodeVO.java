/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.vo;

import java.io.Serializable;

/**
 * ���� �ڵ� ���� VO
 * @author ������
 *
 */
public class JehuCodeVO implements Serializable {
	/** default **/
	private static final long serialVersionUID = 1L;
	private String xmlFileYn;
	private String xmlFile;
	private String sContactPath;
	private String sEventDiv;
	private String sUserID;
	private String sUserNm;
	private String sAffiliatedConcern;
	private String onePageYn;
	private String onePageInsuranceType;
	private String riaPopTitleImgName;
	private String homepageJehuYn;
	private String landingYn;

	/**
	 * @return the xmlFileYn
	 */
	public String getXmlFileYn() {
		return xmlFileYn;
	}

	/**
	 * @param xmlFileYn the xmlFileYn to set
	 */
	public void setXmlFileYn(final String xmlFileYn) {
		this.xmlFileYn = xmlFileYn;
	}

	/**
	 * @return the xmlFile
	 */
	public String getXmlFile() {
		return xmlFile;
	}

	/**
	 * @param xmlFile the xmlFile to set
	 */
	public void setXmlFile(final String xmlFile) {
		this.xmlFile = xmlFile;
	}

	/**
	 * @return the sContactPath
	 */
	public String getsContactPath() {
		return sContactPath;
	}

	/**
	 * @param sContactPath the sContactPath to set
	 */
	public void setsContactPath(final String sContactPath) {
		this.sContactPath = sContactPath;
	}

	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}

	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(final String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the sUserNm
	 */
	public String getsUserNm() {
		return sUserNm;
	}

	/**
	 * @param sUserNm the sUserNm to set
	 */
	public void setsUserNm(final String sUserNm) {
		this.sUserNm = sUserNm;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the onePageYn
	 */
	public String getOnePageYn() {
		return onePageYn;
	}

	/**
	 * @param onePageYn the onePageYn to set
	 */
	public void setOnePageYn(final String onePageYn) {
		this.onePageYn = onePageYn;
	}

	/**
	 * @return the onePageInsuranceType
	 */
	public String getOnePageInsuranceType() {
		return onePageInsuranceType;
	}

	/**
	 * @param onePageInsuranceType the onePageInsuranceType to set
	 */
	public void setOnePageInsuranceType(final String onePageInsuranceType) {
		this.onePageInsuranceType = onePageInsuranceType;
	}

	/**
	 * @return the riaPopTitleImgName
	 */
	public String getRiaPopTitleImgName() {
		return riaPopTitleImgName;
	}

	/**
	 * @param riaPopTitleImgName the riaPopTitleImgName to set
	 */
	public void setRiaPopTitleImgName(final String riaPopTitleImgName) {
		this.riaPopTitleImgName = riaPopTitleImgName;
	}

	/**
	 * @return the homepageJehuYn
	 */
	public String getHomepageJehuYn() {
		return homepageJehuYn;
	}

	/**
	 * @param homepageJehuYn the homepageJehuYn to set
	 */
	public void setHomepageJehuYn(final String homepageJehuYn) {
		this.homepageJehuYn = homepageJehuYn;
	}

	/**
	 * @return the landingYn
	 */
	public String getLandingYn() {
		return landingYn;
	}

	/**
	 * @param landingYn the landingYn to set
	 */
	public void setLandingYn(final String landingYn) {
		this.landingYn = landingYn;
	}

}
