/*-
 * Copyright (c) 2012, Conch
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.educar.common.dto.web;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <pre>
 * Http Request�� XML ������ ����ȭ ��Ű�� Rest Style�� GenericRequest
 * </pre>
 * 
 * @author �ּ�ȯ(David SW Choi)
 * @since 0.0.1
 */
@XmlType(propOrder = { "offset", "limit", "requestData", "sAffiliatedConcernKey" })
@XmlRootElement(name = "request")
public class GenericRestRequest<T> {

	/**
	 * pagination�� offset
	 * @deprecated	EJB ��뿩�� ���� �� ���� ó��
	 */
	@Deprecated
	private int offset;

	/**
	 * pagination�� limit
	 * @deprecated	EJB ��뿩�� ���� �� ���� ó��
	 */
	@Deprecated
	private int limit;

	@XmlElement(name = "data")
	@XmlElementWrapper(name = "requestBody")
	private List<T> requestData;

	/**
	 * <pre>
	 * ���� �ڵ� key��
	 * ���� ȭ�鿡�� �ڵ尪�� �����Ͽ� �Ѱ��ش�.
	 * �Ϲ� ����ī������ �� �Ǵ� null
	 * </pre>
	 **/
	private String sAffiliatedConcernKey;

	/**
	 * data�� ��ȯ�Ѵ�
	 * 
	 * @return the data
	 */
	public List<T> getRequestData() {
		return requestData;
	}

	/**
	 * List�� data�� �߰��Ѵ�
	 * 
	 * @param entity
	 */
	public void addRequestData(final T entity) {
		if (requestData == null) {
			requestData = new ArrayList<T>();
		}
		requestData.add(entity);
	}

	/**
	 * @return the offset
	 */
	public int getOffset() {
		return offset;
	}

	/**
	 * @param offset the offset to set
	 */
	public void setOffset(final int offset) {
		this.offset = offset;
	}

	/**
	 * @return the limit
	 */
	public int getLimit() {
		return limit;
	}

	/**
	 * @param limit the limit to set
	 */
	public void setLimit(final int limit) {
		this.limit = limit;
	}

	/**
	 * @return the sAfiliatedConcernKey
	 */
	public String getsAffiliatedConcernKey() {
		return sAffiliatedConcernKey;
	}

	/**
	 * @param sAfiliatedConcernKey the sAfiliatedConcernKey to set
	 */
	public void setsAffiliatedConcernKey(final String sAffiliatedConcernKey) {
		this.sAffiliatedConcernKey = sAffiliatedConcernKey;
	}

}
