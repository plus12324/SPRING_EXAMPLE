/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * �����ּ� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "postCodeAddressSearchDTO")
public class PostCodeAddressSearchDTO {
	/** �Ϸù�ȣ **/
	private String nSeqNo;
	/** ������ȣ **/
	private String sZipCode;
	/** �ּ� **/
	private String sZipName;
	/** �õ��� **/
	private String sCityName;
	/** ��/�� **/
	private String sCountyName;
	/** ��/��/�� **/
	private String sTownName;
	/** �뷮���ó **/
	private String sBuildingName;
	/** �������� **/
	private String sIsland;
	/** �������� **/
	private String sFromNo;
	/** ������ **/
	private String sToNo;
	/** ��뿩�� **/
	private String sUse;
	/** ���ſ�����ȣ **/
	private String sOldCode;

	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}

	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(final String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}

	/**
	 * @return the sZipCode
	 */
	public String getsZipCode() {
		return sZipCode;
	}

	/**
	 * @param sZipCode the sZipCode to set
	 */
	public void setsZipCode(final String sZipCode) {
		this.sZipCode = sZipCode;
	}

	/**
	 * @return the sZipName
	 */
	public String getsZipName() {
		return sZipName;
	}

	/**
	 * @param sZipName the sZipName to set
	 */
	public void setsZipName(final String sZipName) {
		this.sZipName = sZipName;
	}

	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}

	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(final String sCityName) {
		this.sCityName = sCityName;
	}

	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}

	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(final String sCountyName) {
		this.sCountyName = sCountyName;
	}

	/**
	 * @return the sTownName
	 */
	public String getsTownName() {
		return sTownName;
	}

	/**
	 * @param sTownName the sTownName to set
	 */
	public void setsTownName(final String sTownName) {
		this.sTownName = sTownName;
	}

	/**
	 * @return the sBuildingName
	 */
	public String getsBuildingName() {
		return sBuildingName;
	}

	/**
	 * @param sBuildingName the sBuildingName to set
	 */
	public void setsBuildingName(final String sBuildingName) {
		this.sBuildingName = sBuildingName;
	}

	/**
	 * @return the sIsland
	 */
	public String getsIsland() {
		return sIsland;
	}

	/**
	 * @param sIsland the sIsland to set
	 */
	public void setsIsland(final String sIsland) {
		this.sIsland = sIsland;
	}

	/**
	 * @return the sFromNo
	 */
	public String getsFromNo() {
		return sFromNo;
	}

	/**
	 * @param sFromNo the sFromNo to set
	 */
	public void setsFromNo(final String sFromNo) {
		this.sFromNo = sFromNo;
	}

	/**
	 * @return the sToNo
	 */
	public String getsToNo() {
		return sToNo;
	}

	/**
	 * @param sToNo the sToNo to set
	 */
	public void setsToNo(final String sToNo) {
		this.sToNo = sToNo;
	}

	/**
	 * @return the sUse
	 */
	public String getsUse() {
		return sUse;
	}

	/**
	 * @param sUse the sUse to set
	 */
	public void setsUse(final String sUse) {
		this.sUse = sUse;
	}

	/**
	 * @return the sOldCode
	 */
	public String getsOldCode() {
		return sOldCode;
	}

	/**
	 * @param sOldCode the sOldCode to set
	 */
	public void setsOldCode(final String sOldCode) {
		this.sOldCode = sOldCode;
	}

}
