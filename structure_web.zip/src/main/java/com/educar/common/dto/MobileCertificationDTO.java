/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;


/**
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
public class MobileCertificationDTO {

	/** ���� **/
	private String sInsrdName;
	/** �ֹι�ȣ **/
	private String sInsrdID;
	/** �ڵ��� ��Ż� **/
	private String sCellPhoneCorp;
	/** �ڵ�����ȣ1 **/
	private String sCellPhone1;
	/** �ڵ�����ȣ2 **/
	private String sCellPhone2;
	/** �ڵ�����ȣ3 **/
	private String sCellPhone3;

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @return the sCellPhoneCorp
	 */
	public String getsCellPhoneCorp() {
		return sCellPhoneCorp;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @param sCellPhoneCorp the sCellPhoneCorp to set
	 */
	public void setsCellPhoneCorp(final String sCellPhoneCorp) {
		this.sCellPhoneCorp = sCellPhoneCorp;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
}
