/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

/**
 * MMS ���� DTO
 * 
 * @author �Ž¿�
 * 
 */
public class MMSSendDTO {
	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	/** ������� **/
	private String sDmCode;
	/** �ڵ�����ȣ1 **/
	private String sCellPhone1;
	/** �ڵ�����ȣ2 **/
	private String sCellPhone2;
	/** �ڵ�����ȣ3 **/
	private String sCellPhone3;
	/** ���� **/
	private String sContents;
	/** ���� **/
	private String SUBJECT;

	public String getSUBJECT() {
		return SUBJECT;
	}

	public void setSUBJECT(String sUBJECT) {
		SUBJECT = sUBJECT;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sContents
	 */
	public String getsContents() {
		return sContents;
	}

	/**
	 * @param sContents the sContents to set
	 */
	public void setsContents(final String sContents) {
		this.sContents = sContents;
	}

	/**
	 * @return the sDmCode
	 */
	public String getsDmCode() {
		return sDmCode;
	}

	/**
	 * @param sDmCode the sDmCode to set
	 */
	public void setsDmCode(final String sDmCode) {
		this.sDmCode = sDmCode;
	}
}
