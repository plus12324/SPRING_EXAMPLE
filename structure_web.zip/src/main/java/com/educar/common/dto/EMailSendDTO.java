/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

/**
 * <pre>
 * Email ���� DTO
 * </pre>
 * 
 * @author ������
 * 
 */
public class EMailSendDTO {
	// /** �ܺ�Ű Ÿ�� (1: û���ȣ) **/
	// private static final String KEY_TYPE_OFFER_NO = "1";
	// /** �ܺ�Ű Ÿ�� (2: ����ȣ) **/
	// private static final String KEY_TYPE_COVENANT_NO = "2";
	// /** �ܺ�Ű Ÿ�� (3: �����ȣ) **/
	// private static final String KEY_TYPE_ACCIDENT_NO = "3";
	// /** �ܺ�Ű Ÿ�� (9: ��Ÿ) **/
	// private static final String KEY_TYPE_ETC = "9";
	/** �ֹι�ȣ **/
	private String sCustNo;
	/** �������� **/
	private String sSubject;
	/** �������� **/
	private String sToName;
	/** �����̸��� **/
	private String sToEmail;
	/** �ܺ�Ű **/
	private String sRelKey;
	/** �ܺ�Ű Ÿ�� 1: û���ȣ, 2: ����ȣ, 3: �����ȣ, 9: ��Ÿ **/
	private String sKeyType;
	/**  **/
	private String sBodyHTML;
	/** ���ϰ�� **/
	private String xslPath;
	/** ������ ���ø� ���� �ڵ� **/
	private String INTRO_FILE_NM;
	
	/** �߽��̸��� **/
	private String sFromEmail;
	/** �߽��ڸ� **/
	private String sFromName;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sSubject
	 */
	public String getsSubject() {
		return sSubject;
	}

	/**
	 * @param sSubject the sSubject to set
	 */
	public void setsSubject(final String sSubject) {
		this.sSubject = sSubject;
	}

	/**
	 * @return the sToName
	 */
	public String getsToName() {
		return sToName;
	}

	/**
	 * @param sToName the sToName to set
	 */
	public void setsToName(final String sToName) {
		this.sToName = sToName;
	}

	/**
	 * @return the sToEmail
	 */
	public String getsToEmail() {
		return sToEmail;
	}

	/**
	 * @param sToEmail the sToEmail to set
	 */
	public void setsToEmail(final String sToEmail) {
		this.sToEmail = sToEmail;
	}

	/**
	 * @return the sRelKey
	 */
	public String getsRelKey() {
		return sRelKey;
	}

	/**
	 * @param sRelKey the sRelKey to set
	 */
	public void setsRelKey(final String sRelKey) {
		this.sRelKey = sRelKey;
	}

	/**
	 * @return the sKeyType
	 */
	public String getsKeyType() {
		return sKeyType;
	}

	/**
	 * @param sKeyType the sKeyType to set
	 */
	public void setsKeyType(final String sKeyType) {
		this.sKeyType = sKeyType;
	}

	/**
	 * @return the sBodyHTML
	 */
	public String getsBodyHTML() {
		return sBodyHTML;
	}

	/**
	 * @param sBodyHTML the sBodyHTML to set
	 */
	public void setsBodyHTML(final String sBodyHTML) {
		this.sBodyHTML = sBodyHTML;
	}

	/**
	 * @return the xslPath
	 */
	public String getXslPath() {
		return xslPath;
	}

	/**
	 * @param xslPath the xslPath to set
	 */
	public void setXslPath(final String xslPath) {
		this.xslPath = xslPath;
	}

	/**
	 * @return the iNTRO_FILE_NM
	 */
	public String getINTRO_FILE_NM() {
		return INTRO_FILE_NM;
	}

	/**
	 * @param iNTRO_FILE_NM the iNTRO_FILE_NM to set
	 */
	public void setINTRO_FILE_NM(final String iNTRO_FILE_NM) {
		INTRO_FILE_NM = iNTRO_FILE_NM;
	}

	/**
	 * @return the sFromEmail
	 */
	public String getsFromEmail() {
		return sFromEmail;
	}

	/**
	 * @param sFromEmail the sFromEmail to set
	 */
	public void setsFromEmail(String sFromEmail) {
		this.sFromEmail = sFromEmail;
	}

	/**
	 * @return the sFromName
	 */
	public String getsFromName() {
		return sFromName;
	}

	/**
	 * @param sFromName the sFromName to set
	 */
	public void setsFromName(String sFromName) {
		this.sFromName = sFromName;
	}
	
	
}
