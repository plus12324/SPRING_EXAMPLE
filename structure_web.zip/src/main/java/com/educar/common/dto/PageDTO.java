/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import java.io.Serializable;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlTransient;

/**
 * <pre>
 * ������ ó���� ���� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlTransient
public class PageDTO implements Serializable {

	/**
	 * default serial id for backward compatiability
	 */
	private static final long serialVersionUID = 1L;
	/** ������ �ε��� */
	private int pageIndex = BigInteger.ONE.intValue();
	/** ������ ������*/
	private int pageSize = BigInteger.TEN.intValue();
	/** ��ü �Ǽ� 
	 * �ش� �ʵ� �̸��� ���� ����Ǿ �ȵȴ�
	 * ManagementDisclosureService���� reflection���� ����ϰ� ����
	 */
	private int totalCount;
	/** ��ü ������ �� */
	@SuppressWarnings("unused")
	private int totalPageCount;
	/** ������ �׺���̼� */
	private NavigationViewDTO preViewDto;
	/** ������ �׺���̼� */
	private NavigationViewDTO nextViewDto;

	/**
	 * ������ offset(������) ��ȸ
	 * @return the offset
	 */
	public int getOffset() {
		return this.pageSize * (this.pageIndex - 1);
	}

	/**
	 * @return the limit
	 */
	public int getLimit() {
		int limit = this.pageSize * this.pageIndex;

		if (this.totalCount < limit) {
			limit = this.totalCount;
		}

		return limit;
	}

	/**
	 * @return the pageIndex
	 */
	public int getPageIndex() {
		return pageIndex;
	}

	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(final int pageIndex) {
		this.pageIndex = pageIndex;
	}

	/**
	 * @return the pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(final int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(final int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the totalPageCount
	 */
	public int getTotalPageCount() {
		if (this.totalCount == BigInteger.ZERO.intValue()) {
			return BigInteger.ONE.intValue();
		}
		return (int) Math.ceil((double) this.totalCount / this.pageSize);
	}

	/**
	 * @param totalPageCount the totalPageCount to set
	 */
	public void setTotalPageCount(final int totalPageCount) {
		this.totalPageCount = totalPageCount;
	}

	/**
	 * @return the preViewDto
	 */
	public NavigationViewDTO getPreViewDto() {
		return preViewDto;
	}

	/**
	 * @param preViewDto the preViewDto to set
	 */
	public void setPreViewDto(final NavigationViewDTO preViewDto) {
		this.preViewDto = preViewDto;
	}

	/**
	 * @return the nextViewDto
	 */
	public NavigationViewDTO getNextViewDto() {
		return nextViewDto;
	}

	/**
	 * @param nextViewDto the nextViewDto to set
	 */
	public void setNextViewDto(final NavigationViewDTO nextViewDto) {
		this.nextViewDto = nextViewDto;
	}
}
