/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;



/**
 * <pre>
 * ��/��/�� �ڵ� �˻� DTO
 * </pre>
 * 
 * @author ���ѳ�
 * 
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cityCountyCodeDTO")
public class CityCountyCodeDTO {
	/** 	�ñ�������	**/ 
	private String 	siDoGubun;
	/** 	�õ��ڵ�	**/ 
	private String 	siDoCode	;
	/** 	�õ���	**/ 
	private String 	sCityName;
	/** 	�ñ�����	**/ 
	private String 	sCountyName;
	/** 	�õ��ڵ�	**/ 
	private String 	sidoCode	;
	/** 	�ñ����ڵ�	**/ 
	private String 	sigunguCode;
	/** 	�����ڵ�	**/ 
	private String 	sVillageInLaw;
	/**
	 * @return the sidoGubun
	 */
	
	/**
	 * @return the siDoCode
	 */
	public String getSiDoCode() {
		return siDoCode;
	}
	/**
	 * @return the siDoGubun
	 */
	public String getSiDoGubun() {
		return siDoGubun;
	}
	/**
	 * @param siDoGubun the siDoGubun to set
	 */
	public void setSiDoGubun(String siDoGubun) {
		this.siDoGubun = siDoGubun;
	}
	/**
	 * @param siDoCode the siDoCode to set
	 */
	public void setSiDoCode(String siDoCode) {
		this.siDoCode = siDoCode;
	}
	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}
	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(String sCityName) {
		this.sCityName = sCityName;
	}
	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}
	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(String sCountyName) {
		this.sCountyName = sCountyName;
	}
	/**
	 * @return the sidoCode
	 */
	public String getSidoCode() {
		return sidoCode;
	}
	/**
	 * @param sidoCode the sidoCode to set
	 */
	public void setSidoCode(String sidoCode) {
		this.sidoCode = sidoCode;
	}
	/**
	 * @return the sigunguCode
	 */
	public String getSigunguCode() {
		return sigunguCode;
	}
	/**
	 * @param sigunguCode the sigunguCode to set
	 */
	public void setSigunguCode(String sigunguCode) {
		this.sigunguCode = sigunguCode;
	}
	/**
	 * @return the sVillageInLaw
	 */
	public String getsVillageInLaw() {
		return sVillageInLaw;
	}
	/**
	 * @param sVillageInLaw the sVillageInLaw to set
	 */
	public void setsVillageInLaw(String sVillageInLaw) {
		this.sVillageInLaw = sVillageInLaw;
	}
	
	
}
