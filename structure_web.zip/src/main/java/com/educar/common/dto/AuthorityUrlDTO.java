/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import java.io.Serializable;

/**
 * <pre>
 * �α����� �ʿ��� URL dto
 * ĳ���� ����
 * </pre>
 *
 * @author �ڼ���(SeongJin Park)
 *
 */
@SuppressWarnings("serial")
public class AuthorityUrlDTO implements Serializable {

	/** ID */
	private Long ID;
	/** url */
	private String sUrl;
	/** ���ٱ��� */
	private String sAuthority;
	/**
	 * @return the iD
	 */
	public Long getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(Long iD) {
		ID = iD;
	}
	/**
	 * @return the sUrl
	 */
	public String getsUrl() {
		return sUrl;
	}
	/**
	 * @param sUrl the sUrl to set
	 */
	public void setsUrl(String sUrl) {
		this.sUrl = sUrl;
	}
	/**
	 * @return the sAuthority
	 */
	public String getsAuthority() {
		return sAuthority;
	}
	/**
	 * @param sAuthority the sAuthority to set
	 */
	public void setsAuthority(String sAuthority) {
		this.sAuthority = sAuthority;
	}
}
