/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "agreeDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AgreeDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ��� TYPE  1: ���Լ���, ��ǰ���� 2: ���� **/
	private String policyAgreeType;
	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	/** �������(���Լ��� ����) ������� ���Ǵ� Y, ���� N **/
	@XmlElementWrapper(name = "joinAgreeList")
	private List<String> joinAgree;
	/** �������(Call ��ǰ�Ұ� �����̿� �� ��������) ������� ���Ǵ� Y, ���� N **/
	@XmlElementWrapper(name = "callAgreeList")
	private List<String> callAgree;
	
	/** �ֹε�Ϲ�ȣ 1**/
	private String sCustNo1;
	/** �ֹε�Ϲ�ȣ 2**/
	private String sCustNo2;
	/** Ű���庸�� ��ȣȭ Key **/
	private String hid_key_data;
	
	/**
	 * @return the policyAgreeType
	 */
	public String getPolicyAgreeType() {
		return policyAgreeType;
	}

	/**
	 * @param policyAgreeType the policyAgreeType to set
	 */
	public void setPolicyAgreeType(final String policyAgreeType) {
		this.policyAgreeType = policyAgreeType;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the joinAgree
	 */
	public List<String> getJoinAgree() {
		return joinAgree;
	}

	/**
	 * @param joinAgree the joinAgree to set
	 */
	public void setJoinAgree(final List<String> joinAgree) {
		this.joinAgree = joinAgree;
	}

	/**
	 * @return the callAgree
	 */
	public List<String> getCallAgree() {
		return callAgree;
	}

	/**
	 * @param callAgree the callAgree to set
	 */
	public void setCallAgree(final List<String> callAgree) {
		this.callAgree = callAgree;
	}

	/**
	 * @return the sCustNo1
	 */
	public String getsCustNo1() {
		return sCustNo1;
	}

	/**
	 * @param sCustNo1 the sCustNo1 to set
	 */
	public void setsCustNo1(String sCustNo1) {
		this.sCustNo1 = sCustNo1;
	}

	/**
	 * @return the sCustNo2
	 */
	public String getsCustNo2() {
		return sCustNo2;
	}

	/**
	 * @param sCustNo2 the sCustNo2 to set
	 */
	public void setsCustNo2(String sCustNo2) {
		this.sCustNo2 = sCustNo2;
	}

	/**
	 * @return the hid_key_data
	 */
	public String getHid_key_data() {
		return hid_key_data;
	}

	/**
	 * @param hid_key_data the hid_key_data to set
	 */
	public void setHid_key_data(String hid_key_data) {
		this.hid_key_data = hid_key_data;
	}

}
