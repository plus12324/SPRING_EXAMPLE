/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import java.io.Serializable;

/**
 * <pre>
 * ������/������ ó���� ���� �׺���̼� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
public class NavigationViewDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** �Խñ� ���� */
	private Integer nSeq;
	/** �Խñ� ���� */
	private String sTitle;
	
	/** �ۼ��� **/
	private String sName;
	/** �Խ��� **/
	private String sOpenDate;
	/** �������Ͽ��� **/
	private String sFileYn;
	/** ���� �� **/
	private String nCmtCnt;

	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Integer nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sFileYn
	 */
	public String getsFileYn() {
		return sFileYn;
	}

	/**
	 * @param sFileYn the sFileYn to set
	 */
	public void setsFileYn(String sFileYn) {
		this.sFileYn = sFileYn;
	}

	/**
	 * @return the nCmtCnt
	 */
	public String getnCmtCnt() {
		return nCmtCnt;
	}

	/**
	 * @param nCmtCnt the nCmtCnt to set
	 */
	public void setnCmtCnt(String nCmtCnt) {
		this.nCmtCnt = nCmtCnt;
	}
}
