/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ǥ���ּ� ��ȸ
 * </pre>
 * 
 * @author ���ѳ�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "standardRoadAddrDTO")
public class StandardRoadAddrDTO {
	/** 	�ּҰ�����ȣ	**/ 
	private String 	sAddrMgtNo;
	/** 	�ּ�+����	**/ 
	private String 	varAllAddress;
	/** 	���̺���	**/ 
	private String 	tableNm;
	/** 	�Է���	**/ 
	private String 	loginId;
	/** 	ǥ��ȭ ������ȣ	**/ 
	private String 	varPost;
	/** 	ǥ��ȭ �����ּ�1 (�õ�)**/
	private String web_sCityName;
	/** 	ǥ��ȭ �����ּ�2 (������)**/
	private String web_sCountyName;
	/** 	ǥ��ȭ �����ּ�3 (��/�� +���θ�) **/
	private String web_sTownName;
	/** 	ǥ��ȭ ���� �ּ�	**/ 
	private String 	AnlysStndRdNmHighAddrA;
	/** 	ǥ��ȭ �����ּ�	**/ 
	private String 	AnlysStndRdNmUndrAddrA;
	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}
	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}
	/**
	 * @return the varAllAddress
	 */
	public String getVarAllAddress() {
		return varAllAddress;
	}
	/**
	 * @param varAllAddress the varAllAddress to set
	 */
	public void setVarAllAddress(String varAllAddress) {
		this.varAllAddress = varAllAddress;
	}
	/**
	 * @return the tableNm
	 */
	public String getTableNm() {
		return tableNm;
	}
	/**
	 * @param tableNm the tableNm to set
	 */
	public void setTableNm(String tableNm) {
		this.tableNm = tableNm;
	}
	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}
	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	/**
	 * @return the varPost
	 */
	public String getVarPost() {
		return varPost;
	}
	/**
	 * @param varPost the varPost to set
	 */
	public void setVarPost(String varPost) {
		this.varPost = varPost;
	}
	/**
	 * @return the web_sCityName
	 */
	public String getWeb_sCityName() {
		return web_sCityName;
	}
	/**
	 * @param web_sCityName the web_sCityName to set
	 */
	public void setWeb_sCityName(String web_sCityName) {
		this.web_sCityName = web_sCityName;
	}
	/**
	 * @return the web_sCountyName
	 */
	public String getWeb_sCountyName() {
		return web_sCountyName;
	}
	/**
	 * @param web_sCountyName the web_sCountyName to set
	 */
	public void setWeb_sCountyName(String web_sCountyName) {
		this.web_sCountyName = web_sCountyName;
	}
	/**
	 * @return the web_sTownName
	 */
	public String getWeb_sTownName() {
		return web_sTownName;
	}
	/**
	 * @param web_sTownName the web_sTownName to set
	 */
	public void setWeb_sTownName(String web_sTownName) {
		this.web_sTownName = web_sTownName;
	}
	/**
	 * @return the anlysStndRdNmHighAddrA
	 */
	public String getAnlysStndRdNmHighAddrA() {
		return AnlysStndRdNmHighAddrA;
	}
	/**
	 * @param anlysStndRdNmHighAddrA the anlysStndRdNmHighAddrA to set
	 */
	public void setAnlysStndRdNmHighAddrA(String anlysStndRdNmHighAddrA) {
		AnlysStndRdNmHighAddrA = anlysStndRdNmHighAddrA;
	}
	/**
	 * @return the anlysStndRdNmUndrAddrA
	 */
	public String getAnlysStndRdNmUndrAddrA() {
		return AnlysStndRdNmUndrAddrA;
	}
	/**
	 * @param anlysStndRdNmUndrAddrA the anlysStndRdNmUndrAddrA to set
	 */
	public void setAnlysStndRdNmUndrAddrA(String anlysStndRdNmUndrAddrA) {
		AnlysStndRdNmUndrAddrA = anlysStndRdNmUndrAddrA;
	}
}
