/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ���θ��ּ� �˻� DTO
 * </pre>
 * 
 * @author ���ѳ�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "newRoadNameAddSearchDTO")
public class NewRoadNameAddSearchDTO {
	/** 	���θ�/���鵿 ����	**/ 
	private String 	chkRdo;
	/** 	�ǹ����� 	**/ 
	private String 	mainNo;
	/** 	�ǹ��ι� 	**/ 
	private String 	subNo;
	/** 	�ǹ���	**/ 
	private String 	sBuildingNameSet;
	/** 	�õ�/�ñ��� �ڵ�	**/ 
	private String 	sgCode;
	/** 	�˻���	**/ 
	private String 	sSearchText;
	/** 	�����ڵ�	**/ 
	private String 	sVillageInLaw;
	/** 	���θ��ڵ�	**/ 
	private String 	sRoadCode;
	/** 	���� �õ�	**/ 
	private String 	sCityName;
	/** 	�ñ��� 	**/ 
	private String 	sCountyName;
	/** 	���鵿	**/ 
	private String 	sTownName	;
	/** 	�� ����	**/ 
	private String 	nJibunMainNo;
	/** 	�� ����	**/ 
	private String 	nJibunSubNo;
	/** 	���θ�	**/ 
	private String 	sRoadName;
	/** 	����	**/ 
	private String 	sRiName;
	/** 	�ǹ��� ����	**/ 
	private String 	nBuildingMainNo;
	/** 	�ǹ��� �ι�	**/ 
	private String 	nBuildingSubNo;
	/** 	������ȣ	**/ 
	private String 	sZipCode	;
	/** 	���ʱ�����ȣ	**/ 
	private String 	sNZipCode;
	/** 	�ּҰ�����ȣ	**/ 
	private String 	sAddrMgtNo;
	/** 	�꿩��	**/ 
	private String 	sSanYnCd;
	/** 	���鵿�Ϸù�ȣ	**/ 
	private String 	sEupmyungdongSeqno;
	/** 	���Ͽ���	**/ 
	private String 	sBasement;
	/** 	������ȣ �Ϸù�ȣ	**/ 
	private String 	sZipCodeSeqno;
	/** ���θ��ּһ��� **/
	private String sDoroAddr1;
	
	/** 	�ּ�ǥ�ؼ���	**/ 
	private String 	nAddrStdSeq;
	/** 	�����ּұ���	**/ 
	private String 	sOrgZipType	;
	/** 	����������ȣ	**/
	private String 	sOrgZipCode;
	/** 	�����ּ�	**/ 
	private String 	sOrgAddr	;
	
	
	/**
	 * @return the chkRdo
	 */
	public String getChkRdo() {
		return chkRdo;
	}
	/**
	 * @param chkRdo the chkRdo to set
	 */
	public void setChkRdo(String chkRdo) {
		this.chkRdo = chkRdo;
	}
	/**
	 * @return the mainNo
	 */
	public String getMainNo() {
		return mainNo;
	}
	/**
	 * @param mainNo the mainNo to set
	 */
	public void setMainNo(String mainNo) {
		this.mainNo = mainNo;
	}
	/**
	 * @return the subNo
	 */
	public String getSubNo() {
		return subNo;
	}
	/**
	 * @param subNo the subNo to set
	 */
	public void setSubNo(String subNo) {
		this.subNo = subNo;
	}
	/**
	 * @return the sBuildingNameSet
	 */
	public String getsBuildingNameSet() {
		return sBuildingNameSet;
	}
	/**
	 * @param sBuildingNameSet the sBuildingNameSet to set
	 */
	public void setsBuildingNameSet(String sBuildingNameSet) {
		this.sBuildingNameSet = sBuildingNameSet;
	}
	/**
	 * @return the sgCode
	 */
	public String getSgCode() {
		return sgCode;
	}
	/**
	 * @param sgCode the sgCode to set
	 */
	public void setSgCode(String sgCode) {
		this.sgCode = sgCode;
	}
	/**
	 * @return the sSearchText
	 */
	public String getsSearchText() {
		return sSearchText;
	}
	/**
	 * @param sSearchText the sSearchText to set
	 */
	public void setsSearchText(String sSearchText) {
		this.sSearchText = sSearchText;
	}
	/**
	 * @return the sVillageInLaw
	 */
	public String getsVillageInLaw() {
		return sVillageInLaw;
	}
	/**
	 * @param sVillageInLaw the sVillageInLaw to set
	 */
	public void setsVillageInLaw(String sVillageInLaw) {
		this.sVillageInLaw = sVillageInLaw;
	}
	/**
	 * @return the sRoadCode
	 */
	public String getsRoadCode() {
		return sRoadCode;
	}
	/**
	 * @param sRoadCode the sRoadCode to set
	 */
	public void setsRoadCode(String sRoadCode) {
		this.sRoadCode = sRoadCode;
	}
	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}
	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(String sCityName) {
		this.sCityName = sCityName;
	}
	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}
	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(String sCountyName) {
		this.sCountyName = sCountyName;
	}
	/**
	 * @return the sTownName
	 */
	public String getsTownName() {
		return sTownName;
	}
	/**
	 * @param sTownName the sTownName to set
	 */
	public void setsTownName(String sTownName) {
		this.sTownName = sTownName;
	}
	/**
	 * @return the nJibunMainNo
	 */
	public String getnJibunMainNo() {
		return nJibunMainNo;
	}
	/**
	 * @param nJibunMainNo the nJibunMainNo to set
	 */
	public void setnJibunMainNo(String nJibunMainNo) {
		this.nJibunMainNo = nJibunMainNo;
	}
	/**
	 * @return the nJibunSubNo
	 */
	public String getnJibunSubNo() {
		return nJibunSubNo;
	}
	/**
	 * @param nJibunSubNo the nJibunSubNo to set
	 */
	public void setnJibunSubNo(String nJibunSubNo) {
		this.nJibunSubNo = nJibunSubNo;
	}
	/**
	 * @return the sRoadName
	 */
	public String getsRoadName() {
		return sRoadName;
	}
	/**
	 * @param sRoadName the sRoadName to set
	 */
	public void setsRoadName(String sRoadName) {
		this.sRoadName = sRoadName;
	}
	/**
	 * @return the sRiName
	 */
	public String getsRiName() {
		return sRiName;
	}
	/**
	 * @param sRiName the sRiName to set
	 */
	public void setsRiName(String sRiName) {
		this.sRiName = sRiName;
	}
	/**
	 * @return the nBuildingMainNo
	 */
	public String getnBuildingMainNo() {
		return nBuildingMainNo;
	}
	/**
	 * @param nBuildingMainNo the nBuildingMainNo to set
	 */
	public void setnBuildingMainNo(String nBuildingMainNo) {
		this.nBuildingMainNo = nBuildingMainNo;
	}
	/**
	 * @return the nBuildingSubNo
	 */
	public String getnBuildingSubNo() {
		return nBuildingSubNo;
	}
	/**
	 * @param nBuildingSubNo the nBuildingSubNo to set
	 */
	public void setnBuildingSubNo(String nBuildingSubNo) {
		this.nBuildingSubNo = nBuildingSubNo;
	}
	/**
	 * @return the sZipCode
	 */
	public String getsZipCode() {
		return sZipCode;
	}
	/**
	 * @param sZipCode the sZipCode to set
	 */
	public void setsZipCode(String sZipCode) {
		this.sZipCode = sZipCode;
	}
	/**
	 * @return the sNZipCode
	 */
	public String getsNZipCode() {
		return sNZipCode;
	}
	/**
	 * @param sNZipCode the sNZipCode to set
	 */
	public void setsNZipCode(String sNZipCode) {
		this.sNZipCode = sNZipCode;
	}
	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}
	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}
	/**
	 * @return the sSanYnCd
	 */
	public String getsSanYnCd() {
		return sSanYnCd;
	}
	/**
	 * @param sSanYnCd the sSanYnCd to set
	 */
	public void setsSanYnCd(String sSanYnCd) {
		this.sSanYnCd = sSanYnCd;
	}
	/**
	 * @return the sEupmyungdongSeqno
	 */
	public String getsEupmyungdongSeqno() {
		return sEupmyungdongSeqno;
	}
	/**
	 * @param sEupmyungdongSeqno the sEupmyungdongSeqno to set
	 */
	public void setsEupmyungdongSeqno(String sEupmyungdongSeqno) {
		this.sEupmyungdongSeqno = sEupmyungdongSeqno;
	}
	/**
	 * @return the sBasement
	 */
	public String getsBasement() {
		return sBasement;
	}
	/**
	 * @param sBasement the sBasement to set
	 */
	public void setsBasement(String sBasement) {
		this.sBasement = sBasement;
	}
	/**
	 * @return the sZipCodeSeqno
	 */
	public String getsZipCodeSeqno() {
		return sZipCodeSeqno;
	}
	/**
	 * @param sZipCodeSeqno the sZipCodeSeqno to set
	 */
	public void setsZipCodeSeqno(String sZipCodeSeqno) {
		this.sZipCodeSeqno = sZipCodeSeqno;
	}
	/**
	 * @return the sDoroAddr1
	 */
	public String getsDoroAddr1() {
		return sDoroAddr1;
	}
	/**
	 * @param sDoroAddr1 the sDoroAddr1 to set
	 */
	public void setsDoroAddr1(String sDoroAddr1) {
		this.sDoroAddr1 = sDoroAddr1;
	}
	/**
	 * @return the nAddrStdSeq
	 */
	public String getnAddrStdSeq() {
		return nAddrStdSeq;
	}
	/**
	 * @param nAddrStdSeq the nAddrStdSeq to set
	 */
	public void setnAddrStdSeq(String nAddrStdSeq) {
		this.nAddrStdSeq = nAddrStdSeq;
	}
	/**
	 * @return the sOrgZipType
	 */
	public String getsOrgZipType() {
		return sOrgZipType;
	}
	/**
	 * @param sOrgZipType the sOrgZipType to set
	 */
	public void setsOrgZipType(String sOrgZipType) {
		this.sOrgZipType = sOrgZipType;
	}
	/**
	 * @return the sOrgZipCode
	 */
	public String getsOrgZipCode() {
		return sOrgZipCode;
	}
	/**
	 * @param sOrgZipCode the sOrgZipCode to set
	 */
	public void setsOrgZipCode(String sOrgZipCode) {
		this.sOrgZipCode = sOrgZipCode;
	}
	/**
	 * @return the sOrgAddr
	 */
	public String getsOrgAddr() {
		return sOrgAddr;
	}
	/**
	 * @param sOrgAddr the sOrgAddr to set
	 */
	public void setsOrgAddr(String sOrgAddr) {
		this.sOrgAddr = sOrgAddr;
	}
	
	
}
