/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educar.common.dao.AuthorityDAO;
import com.educar.common.dto.AuthorityUrlDTO;

/**
 * <pre>
 * ���� ���� ����
 * </pre>
 *
 * @author �ڼ���(SeongJin Park)
 *
 */
@Service
public class AuthorityService {

	@Autowired
	private AuthorityDAO dao;

	/**
	 * 
	 * <pre>
	 *  URL ���� ��ȸ 
	 * <pre>
	 * @return
	 */
	public List<AuthorityUrlDTO> selectAuthorityUrlList() {
		return dao.selectAuthorityUrlList(new AuthorityUrlDTO());
	}
}
