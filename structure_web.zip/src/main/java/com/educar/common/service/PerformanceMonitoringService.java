/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.service;

import java.util.Enumeration;

import javax.annotation.PostConstruct;

import org.apache.log4j.Appender;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.perf4j.StopWatch;
import org.perf4j.log4j.AsyncCoalescingStatisticsAppender;
import org.perf4j.log4j.GraphingStatisticsAppender;
import org.springframework.stereotype.Service;

import com.educar.mbean.GraphObject;

/**
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@Service
public class PerformanceMonitoringService {

	/** StopWatch�� default logger�� ������ �´� **/
	private Logger stopWatchLogger = Logger.getLogger(StopWatch.DEFAULT_LOGGER_NAME);
	private Logger logger = Logger.getLogger(getClass());
	private AsyncCoalescingStatisticsAppender monitoringAppender = null;

	/** ����͸� appender�� �̸�, ������ ���̹Ƿ� static ���ʿ� **/
	private String monitoringAppenderName = "monitoringAppender";
	private String graphAppenderName = "graphAppender";

	/**
	 * Go Live ��, property �Ǵ� DB���� ���� �����ϰ� �����ؾ� �Ѵ�.
	 * Live�� GraphService ���� �ʿ� �� ���� stat ���񽺸� ����ϴ°� ����.
	 * ����� ������ ���ؽ�Ʈ �ε� �� �ٷ� ���� �Ѵ�.
	 */
	@PostConstruct
	public void initGraphService() {
		stopWatchLogger.setAdditivity(false);
		final DailyRollingFileAppender appender = new DailyRollingFileAppender();
		appender.setName(graphAppenderName);
		appender.setFile("monintoring.log");
		appender.setLayout(new PatternLayout());
		appender.activateOptions();
		stopWatchLogger.addAppender(appender);
	}

	public void stopGraphService() {
		stopWatchLogger.removeAppender(graphAppenderName);
	}

	public void activateMonitoringService(final long timeSlice) {
		logger.debug("����͸� ���񽺸� �����մϴ�");
		final FileAppender fileAppender = new FileAppender();
		fileAppender.setName(FileAppender.class.getName());
		fileAppender.setFile("performance_stat.log");
		fileAppender.setLayout(new PatternLayout());
		fileAppender.setAppend(false);
		fileAppender.activateOptions();
		monitoringAppender = new AsyncCoalescingStatisticsAppender();
		monitoringAppender.setName(monitoringAppenderName);
		monitoringAppender.setTimeSlice(timeSlice);
		monitoringAppender.addAppender(fileAppender);
		monitoringAppender.activateOptions();
		stopWatchLogger.addAppender(monitoringAppender);
	}

	public void deactivateMonitoringService() {
		if (monitoringAppender != null) {
			logger.debug("����͸� ���񽺸� �����մϴ�");
			// downstream appender�� �� ���� �Ѵ�.
			monitoringAppender.removeAllAppenders();
			logger.debug("����͸� ������ ��� downstream appender�� �����մϴ�");
			// �ΰſ��� monitoringAppender�� ���� �Ѵ�.
			logger.removeAppender(monitoringAppenderName);
		}
	}

	public void addDownstreamAppender(final Appender appender) {
		if (monitoringAppender != null) {
			//			logger.debug("Downstream appender :" + appender.getName() + " �߰�");
			monitoringAppender.addAppender(appender);
		}
	}

	public void removeDownStreamAppender(final Appender appender) {
		if (monitoringAppender != null) {
			logger.debug("Downstream appender :" + appender.getName() + " ����");
			monitoringAppender.removeAppender(monitoringAppender);
		}
	}

	public void removeAllDownstreamAppenders() {
		if (monitoringAppender != null) {
			monitoringAppender.removeAllAppenders();
		}
	}

	@SuppressWarnings("unchecked")
	public GraphObject showGraph() {
		final GraphObject obj = new GraphObject();
		if (monitoringAppender != null) {
			final Enumeration<Appender> en = monitoringAppender.getAllAppenders();
			while (en.hasMoreElements()) {
				final Appender appender = en.nextElement();
				if (appender instanceof GraphingStatisticsAppender) {
					final GraphingStatisticsAppender graphic = (GraphingStatisticsAppender) appender;
					final StringBuilder sb = new StringBuilder();
					final String graphUrl = graphic.getChartGenerator().getChartUrl();
					sb.append("<a href=\"").append(graphUrl).append("\">").append(graphic.getGraphType()).append("</a>").append("<br/>");
					obj.addGraph(sb.toString());
				}
			}
		}
		return obj;
	}
}
