/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.service;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.PropertiesFactoryBean;

/**
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
public class PropertyService implements BeanPostProcessor {

	private ConcurrentHashMap<Object, Object> properties = new ConcurrentHashMap<Object, Object>();

	/**
	 * ���������� �ε��� ��� property�� value�� key�� ������ �´�.
	 * @param key
	 * @return
	 */
	public String getProperty(final String key) {
		return (String) properties.get(key);
	}

	/**
	 * do nothing, just skip
	 */
	@Override
	public Object postProcessBeforeInitialization(final Object bean, final String beanName) throws BeansException {
		return bean;
	}

	/**
	 * PropertiesFactoryBean ��� ó�� �Ѵ�.
	 */
	@Override
	public Object postProcessAfterInitialization(final Object bean, final String beanName) throws BeansException {
		if (bean instanceof PropertiesFactoryBean) {
			final PropertiesFactoryBean propBean = (PropertiesFactoryBean) bean;
			try {
				final Properties props = propBean.getObject();
				// property�� ī�� �Ѵ�...
				properties.putAll(props);
			} catch (final IOException e) {
				// can't really do anything but give up on this.
				e.printStackTrace();
			}
		}
		return bean;
	}

}
