/*-
 * Copyright (c) 2012, Conch
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.educar.common.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.env.Environment;

import com.dreamsecurity.e2e.MagicSE2;
import com.educar.common.dto.AuthorityUrlDTO;
import com.educar.common.util.XMLUtil;
import com.educar.common.vo.BasicCodeVO;
import com.educar.common.vo.JehuCodeVO;
import com.educar.enumeration.AuthorityEnum;
import com.educar.enumeration.CacheEnum;
import com.educar.enumeration.CacheKeyEnum;
import com.educar.enumeration.SystemPropertyEnum;

/**
 * @author �ּ�ȯ(David SW Choi)
 * 
 */
public class ApplicationContextProvider implements ApplicationContextAware, ApplicationListener<ApplicationEvent> {

	private static List<String> springActiveProfile;

	private Logger logger = Logger.getLogger(this.getClass());
	/**
	 * spring context
	 */
	private static ApplicationContext context;

	/** ���� ���� */
	@Autowired
	private AuthorityService service;

	@Autowired
	private DistributedCacheService cacheService;

	@Autowired
	private Environment environment;
	
	/** property ���� **/
	@Autowired
	private PropertyService propertyService;
	
	/**
	 * �������� ���� ���
	 */
	@Value("#{systemProperties['dream.e2e.valid']}")
	private Boolean DREAM_E2E_VALID;

	/**
	 * auto injected by spring aware
	 */
	@Override
	public void setApplicationContext(final ApplicationContext applicationContext) throws BeansException {
		context = applicationContext;
	}

	/**
	 * ApplicationContext�� ����
	 * 
	 * @return spring app context
	 */
	public static ApplicationContext getApplicationContext() {
		return context;
	}

	/**
	 * Spring app context �ε� �� bootstrapping �� ���� �۾��� eg) cache loading ��
	 */
	@Override
	public void onApplicationEvent(final ApplicationEvent event) {

		// bootstraping �� context Refreshed event�� �ι� �߻���. root��, dispatcher servlet
		// �̸� �����ؾ���.
		if (event instanceof ContextRefreshedEvent) {
			if (event.getSource() instanceof ApplicationContext) {
				final ApplicationContext ctx = (ApplicationContext) event.getSource();
				if (ctx.getParent() == null) {
					logger.debug("Initialized Root Application Context");
					logger.debug("Loading cache....");
					try {
						cacheService.initCacheManager();
					} catch (final Exception e) {
						e.printStackTrace();
						System.exit(-1);
					}
					// ������ active profiles�� hashMap�� �ִ´�
					// �̴� readonly�θ� ����ؾ� �Ѵ�.
					if (environment.getActiveProfiles().length == 1) {
						springActiveProfile = Arrays.asList(environment.getActiveProfiles());
					} else {
						throw new RuntimeException("Active Profile�� �Ѱ����� �մϴ�.  JVM argument�� Ȯ���ϼ���");
					}
					this.loadCache();
					// basicCode, ����code xml�� �ε��Ͽ� �л�ĳ���� ����
					this.loadCodeXML();
					// ����� �帲 E2E�� �������� �ʱ�ȭ
					try {
						this.magicE2Einit();
					} catch (final Exception e) {
						e.printStackTrace();
						System.exit(-1);
					}
				}
			}
		}
	}

	/**
	 * bootstraping�� �ε��ؾ� �� �л� ĳ���� �߰��Ѵ�
	 */
	public void loadCache() {
		// ���� ����Ʈ ��ȸ
		final List<AuthorityUrlDTO> authorityList = service.selectAuthorityUrlList();
		// �α����� �ʿ��� URL
		final List<AuthorityUrlDTO> needLoginURL = new ArrayList<AuthorityUrlDTO>();
		// �α����� �ʿ��� XML
		final List<AuthorityUrlDTO> needLoginXML = new ArrayList<AuthorityUrlDTO>();;
		// �α����� �ʿ����� ���� URL
		final List<AuthorityUrlDTO> needlessLoginURL = new ArrayList<AuthorityUrlDTO>();
		// �α����� �ʿ����� ���� XML
		final List<AuthorityUrlDTO> needlessLoginXML = new ArrayList<AuthorityUrlDTO>();
		for (final AuthorityUrlDTO dto : authorityList) {
			if (StringUtils.isBlank(dto.getsUrl()) || StringUtils.isBlank(dto.getsAuthority())) {
				continue;
			} else if (AuthorityEnum.GUEST.name().equals(dto.getsAuthority())) {
				if (StringUtils.endsWithIgnoreCase(dto.getsUrl(), ".do")) {
					needlessLoginURL.add(dto);
					continue;
				} else if (StringUtils.endsWithIgnoreCase(dto.getsUrl(), ".xml")) {
					needlessLoginXML.add(dto);
					continue;
				}
			} else {
				if (StringUtils.endsWithIgnoreCase(dto.getsUrl(), ".do")) {
					needLoginURL.add(dto);
					continue;
				} else if (StringUtils.endsWithIgnoreCase(dto.getsUrl(), ".xml")) {
					needLoginXML.add(dto);
					continue;
				}
			}
			if (logger.isDebugEnabled()) {
				logger.debug("garbage URL : " + dto.getID() + " | " + dto.getsUrl() + " | " + dto.getsAuthority());
			}
		}

		// �л�ĳ���� ����
		final Cache authCache = cacheService.getCache(CacheEnum.AUTH_CACHE_MAP.getName());
		authCache.put(CacheKeyEnum.LOGIN_CHECK_URL.name(), needLoginURL);
		authCache.put(CacheKeyEnum.LOGIN_CHECK_XML.name(), needLoginXML);
		authCache.put(CacheKeyEnum.WITHOUT_LOGIN_CHECK_URL.name(), needlessLoginURL);
		authCache.put(CacheKeyEnum.WITHOUT_LOGIN_CHECK_XML.name(), needlessLoginXML);
		if (logger.isDebugEnabled()) {
			logger.debug("LOGIN_CHECK_URL size : " + cacheService.get(CacheEnum.AUTH_CACHE_MAP, CacheKeyEnum.LOGIN_CHECK_URL.name(), List.class).size());
			logger.debug("LOGIN_CHECK_XML size : " + cacheService.get(CacheEnum.AUTH_CACHE_MAP, CacheKeyEnum.LOGIN_CHECK_XML.name(), List.class).size());
			logger.debug("WITHOUT_LOGIN_CHECK_URL size : " + cacheService.get(CacheEnum.AUTH_CACHE_MAP, CacheKeyEnum.WITHOUT_LOGIN_CHECK_URL.name(), List.class).size());
			logger.debug("WITHOUT_LOGIN_CHECK_XML size : " + cacheService.get(CacheEnum.AUTH_CACHE_MAP, CacheKeyEnum.WITHOUT_LOGIN_CHECK_XML.name(), List.class).size());
		}
	}
	
	/**
	 * ����� ����E2E�� ����ϱ� ���� �ʱ�ȭ
	 * @throws Exception 
	 */
	public void magicE2Einit() throws Exception {
		//10.1.1.131, 10.1.1.34, 10.11.1.34 ���� �ʱ�ȭ ���ش�.
		if(DREAM_E2E_VALID){
			MagicSE2.MagicSE_Init( propertyService.getProperty(SystemPropertyEnum.DREAM_E2E_FILE_PATH.getKey()) );
		}
	}

	/**
	 * basicCode, ����code xml�� �ε��Ͽ� �л�ĳ���� ����
	 */
	@SuppressWarnings("unchecked")
	public void loadCodeXML() {
		// basic �ڵ� ����
		final Map<String, Object> basicMap = XMLUtil.getResultMap(XMLUtil.loadXML("META-INF/code/basicCode.xml"));
		final Map<String, BasicCodeVO> basicCodeMap = new HashMap<String, BasicCodeVO>();
		for (final String key : basicMap.keySet()) {
			if (Map.class.isAssignableFrom(basicMap.get(key).getClass())) {
				final BasicCodeVO basicCodeVO = XMLUtil.getResultObject(BasicCodeVO.class, (Map<String, Object>) basicMap.get(key));
				basicCodeMap.put(key, basicCodeVO);
			}
		}

		// ���� �ڵ� ����
		final Map<String, Object> jehuMap = XMLUtil.getResultMap(XMLUtil.loadXML("META-INF/code/jehuXml.xml"));
		final Map<String, JehuCodeVO> jehuCodeMap = new HashMap<String, JehuCodeVO>();
		for (final String key : jehuMap.keySet()) {
			if (Map.class.isAssignableFrom(jehuMap.get(key).getClass())) {
				jehuCodeMap.put(key, XMLUtil.getResultObject(JehuCodeVO.class, (Map<String, Object>) jehuMap.get(key)));
			}
		}
		// �л�ĳ���� ����
		final Cache codeCache = cacheService.getCache(CacheEnum.CODE_CACHE_MAP.getName());
		codeCache.put(CacheKeyEnum.BASIC_CODE.name(), basicCodeMap);
		codeCache.put(CacheKeyEnum.JEHU_CODE.name(), jehuCodeMap);
	}

	/**
	 * ������ active profile�� �ִ��� Ȯ���Ѵ�.
	 * @param profile
	 * @return boolean True if contains
	 */
	public static boolean containsProfile(final String profile) {
		return springActiveProfile.contains(profile);
	}

	/**
	 * ������ active profiles�� ��ȯ, 1���� active���� �Ѵ�.....
	 * @return springActiveProfile list
	 */
	public static String getActiveProfile() {
		return springActiveProfile.size() == 1 ? springActiveProfile.get(BigInteger.ZERO.intValue()) : null;
	}

	/**
	 * vararg ���� profile�� active profile���� Ȯ��
	 * @param profiles
	 * @return
	 */
	public static boolean containsProfiles(final String... profiles) {
		for (final String profile : profiles) {
			if (containsProfile(profile)) {
				return true;
			}
		}
		return false;
	}
}
