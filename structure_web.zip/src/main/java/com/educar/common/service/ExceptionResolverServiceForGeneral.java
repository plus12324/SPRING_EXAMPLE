/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.common.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.conch.aspect.exception.ValidationException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.educar.common.dto.web.GenericRestResponse;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.BackBoneException;
import com.educar.exception.InvalidRequestException;

/**
 * ���� Exception ó�� �� Resolver
 * @author �ּ�ȯ(David SW Choi)
 */
public class ExceptionResolverServiceForGeneral implements HandlerExceptionResolver {

	/** logger */
	private final Logger logger = Logger.getLogger(this.getClass());

	/** Message Service **/
	@Autowired
	private MessageSourceService message;

	/**
	 * @see org.springframework.web.servlet.HandlerExceptionResolver#resolveException(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
	 */
	@Override
	public ModelAndView resolveException(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final Exception ex) {
		// �α� ���
		logger.warn(getClass().getName(), ex);
		// ���� �ڵ�
		int errorCode = ResponseStatusEnum.SYSTEM_ERROR.getCode();
		// ���� �޼���
		String errorMessage = message.getMessage(ExceptionMessage.ExceptionUnknownError);
		// ȭ����ȯ URL
		WebServletEnum forwardURL = WebServletEnum.EMPTY_URL;

		// validator framework���� �߻��ϴ� ����
		if (ex instanceof ValidationException) {
			errorMessage = StringUtils.defaultString(ex.getMessage(), errorMessage);
			errorCode = ResponseStatusEnum.VALIDATION_EXCEPTION.getCode();
		}
		// �߸��� ��û���� ���� ����
		else if (ex instanceof InvalidRequestException) {
			final InvalidRequestException ire = (InvalidRequestException) ex;
			if (ire != null) {
				errorMessage = StringUtils.defaultString(ire.getMessage(), errorMessage);
				if (ire.getResponseCode() != null) {
					errorCode = ire.getResponseCode().getCode();
				}
				if (ire.getForwardUrl() != null) {
					forwardURL = ire.getForwardUrl();
				}
			}
		}
		// �Ⱓ�� ȣ�� �� �߻��ϴ� Exception
		// ���� �޽����� throw �ϴ� ������ �ۼ��Ͽ� ������ �Ѵ�.
		else if (ex instanceof BackBoneException) {
			final BackBoneException bre = (BackBoneException) ex;
			errorMessage = StringUtils.defaultString(ex.getMessage(), errorMessage);
			errorCode = ResponseStatusEnum.BACK_BONE_EXCEPTION.getCode();
			if (bre.getForwardUrl() != null) {
				forwardURL = bre.getForwardUrl();
			}
		}
		// ��� DB���� Spring Exception, generally unrecoverable
		else if (ex instanceof DataAccessException) {
			errorCode = ResponseStatusEnum.DATA_ACCESS_EXCEPTION.getCode();
		}
		// Spring ���� maxUploadSize Exception
		else if (ex instanceof MaxUploadSizeExceededException) {
			logger.warn("File Upload - Max Size Exceeded");
			final MaxUploadSizeExceededException musee = (MaxUploadSizeExceededException) ex;
			String maxUploadSize = "";
			if (musee.getMaxUploadSize() < 1024 * 1024) {
				maxUploadSize = musee.getMaxUploadSize() / 1024 + "KB";
			} else {
				maxUploadSize = musee.getMaxUploadSize() / (1024 * 1024) + "MB";
			}
			errorMessage = message.getMessage(ExceptionMessage.FileUploadMaxSize, maxUploadSize);
		}
		// �׿� ����

		// ���� �ڵ� �� �޼��� ����
		final GenericRestResponse<Void> restResponse = new GenericRestResponse<Void>();
		restResponse.setStatus(errorCode);
		restResponse.setMessage(errorMessage);
		restResponse.setForwardURL(forwardURL, request.getSession());

		final ModelAndView mav = new ModelAndView();
		mav.addObject("error", restResponse);
		return mav;
	}
}
