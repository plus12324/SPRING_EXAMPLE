/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobileapp.mileage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;

/**
 * @author �Ž¿�
 *
 */
@Controller
@RequestMapping("/mileage")
public class MileageController {

	
	/**                                                                                                                                                                 
	 * �ڵ������ϸ��� ��� ó�� - ���������Է�                                                                                                                             
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception                                                                                                                                                
	 */
	@RequestMapping("/carMilePhoto1Insert")
	public ModelAndView carMilePhoto1Insert(HttpServletRequest request, HttpServletResponse response) throws Exception {                                                    
		                                 
		
		ModelAndView mav = new ModelAndView();
		/*
		mav.setViewName("mobileWeb2011/carMile/carMilePhoto1InsertResult");
		
		Param param = new HttpServletParam(request);
		
		String sName 	= URLDecoder.decode(param.getString("sName", ""),"utf-8");
		String sCustNo1 = param.getString("sCustNo1", "");
		String sCustNo2 = param.getString("sCustNo2", "");
		String sCustNo = sCustNo1 +sCustNo2;
		String sCellPhone1 = param.getString("sCellPhone1", "");
		String sCellPhone2 = param.getString("sCellPhone2", "");
		String sCellPhone3 = param.getString("sCellPhone3", "");
		
		
		if ( sCustNo.length() != 13 ) {
			mav.addObject("carMileInsertCode", "FAIL");                                                                                                                              
		    mav.addObject("carMileInsertMsg",  "�������� ���� ����� �ƴմϴ�.");
		    return mav;
		}


		
//		SiteMapJehu siteMapJehu = new SiteMapJehu(request, 2);

		String sAffiliatedConcern 	= siteMapJehu.getSAffiliatedConcern();  // ����ó �ڵ�
		String sEventDiv 			= siteMapJehu.getSEventDiv();
		String sUserID 				= siteMapJehu.getSUserID();
		String sContactPath 		= siteMapJehu.getSContactPath();		//���԰��

		////////////////////////////////////////////////////
		//�Ķ���� ����
		DataTable dParam = new DataTable();
		
		dParam.put("sCustNo",sCustNo);
		dParam.put("sName", sName);
		dParam.put("sCellPhone1", sCellPhone1);
		dParam.put("sCellPhone2", sCellPhone2);
		dParam.put("sCellPhone3", sCellPhone3);

		dParam.put("sAffiliatedConcern", sAffiliatedConcern);	//����ó�ڵ�
		dParam.put("sUserID", sUserID);
		dParam.put("sEventDiv", sEventDiv);
		dParam.put("sContactPath", sContactPath);
		
		//����ȸ������ �˻�		
		int isCustomerYN = ((Integer)commonDAO.queryForObject("estimate.isCustomerYN", sCustNo)).intValue();
        
		
		// �ű԰���
		mav.addObject("carMileInsertCode", "SUCCESS");
		if(isCustomerYN < 1)
		{
			Document dResult = InswaveUtil.contSaveCustomer(dParam);
		    mav.addObject("carMileInsertMsg",  "�ű԰�������");
		}
		else {
		    mav.addObject("carMileInsertMsg",  "������������");
		}
		*/
		return mav;       
		
		                                                                                                                                                
	}              
	
	
	
}
