/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.recruit;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.EMailSendDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MailTempletService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.PropertyService;
import com.educar.dao.RecruitDAO;
import com.educar.dto.recruit.notify.JobDetailDTO;
import com.educar.dto.recruit.notify.JobGenDetailWrapperDTO;
import com.educar.dto.recruit.notify.JobListDTO;
import com.educar.dto.recruit.notify.JobMasterDTO;
import com.educar.dto.recruit.notify.NewResumeApplyDTO;
import com.educar.dto.recruit.notify.RecruitEmailSendDTO;
import com.educar.dto.recruit.notify.ResultInquiryDTO;
import com.educar.dto.recruit.notify.ResumeApplyListDTO;
import com.educar.dto.web.main.RecruitDTO;
import com.educar.enumeration.EmailAuthStatusEnum;
import com.educar.enumeration.MailTempletType;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.SystemPropertyEnum;
import com.educar.enumeration.UserIDEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.SendBackBoneService;
import com.educar.service.recruit.backbone.RecruitBackBoneBaseService;
import com.educar.service.recruit.backbone.ResumeApplyListBackBoneService;
import com.educar.service.web.CertificationService;
import com.educar.vo.web.AuthNumberVO;

/**
 * @author ���ѳ�
 *
 */
@Controller
@RequestMapping("/recruit")
public class RecruitController {

	@Autowired
	private RecruitBackBoneBaseService recruitBackBoneBaseService;
	@Autowired
	private ResumeApplyListBackBoneService resumeApplyListBackBoneService;

	/** SMS / �̸��� �߼� ���� */
	@Autowired
	private SendBackBoneService sendBackBoneService;

	/** MessageSource */
	@Autowired
	private MessageSourceService message;

	/** ä�볻�� DAO **/
	@Autowired
	private RecruitDAO recruitDAO;

	@Autowired
	private PropertyService propertyService;

	@Autowired
	private MailTempletService mailTempletService;
	
	@Autowired
	private CertificationService certificationService;
	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());

	/** ���� �̸��� ���� */
	private static final String SEND_EMAIL_SUBJECT = "The-K ���غ��� ä�� ���� �̸����Դϴ�.";
	@Value("#{systemProperties['certification.expired.time']}")
	private int EXPIRED_TIME;

	/**
	 * <pre>
	 * �ű��̷¼� ���
	 * <pre>
	 * @param servletRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "insertNewResume")
	@ResponseBody
	public GenericRestResponse<Void> insertNewResume(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<NewResumeApplyDTO> request) {
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		final NewResumeApplyDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		if (recruitBackBoneBaseService.insertNewResume(inputDTO)) {
			// SESSION�� ä������ ���
			session.setAttribute(SessionNameEnum.RECRUIT_INFO.toString(), inputDTO);
			// �ű��̷¼���� �Ϸ�(newResumeOk)ȭ�� �̵�
			response.setForwardURL(WebServletEnum.RECRUIT_NEWRESUME_OK_URL, session);
			// ����� ��ȯ
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		} else {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		}

		return response;
	}

	/**
	 * <pre>
	 * �ű��̷¼� - �̸��� �߼�
	 * <pre>
	 * @param servletRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "newResumeOk")
	@ResponseBody
	public GenericRestResponse<NewResumeApplyDTO> newResumeOk(final HttpSession session, final HttpServletRequest request) {

		// ������ȣ ����
		final Random random = new Random();
		final int authNumber = 100000 + random.nextInt(900000);
		final String domainString = propertyService.getProperty(SystemPropertyEnum.DOMAIN_CALLBACK_URL.getKey());
		// String domainString = "10.1.5.148";
		final NewResumeApplyDTO sessionReDto = (NewResumeApplyDTO) session.getAttribute(SessionNameEnum.RECRUIT_INFO.toString());
		final GenericRestResponse<NewResumeApplyDTO> response = new GenericRestResponse<NewResumeApplyDTO>();
		// �Ⱓ�� ����
		final String strEmail = sessionReDto.getsEmail(); // �̸���
		final String userIp = request.getRemoteAddr();

		if (StringUtils.isBlank(strEmail)) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.IssueAuthNumberError), ResponseStatusEnum.DEFAULT_ERROR);
		}
		logger.debug(">>>>>>>>>>>>>>>>>>.." + sessionReDto.getsEmail());

			
		final String callBackURL = propertyService.getProperty(SystemPropertyEnum.DOMAIN_CALLBACK_URL.getKey());
		
		
		// ���� �̸��� ����
		final String email = strEmail;
		if (StringUtils.isBlank(email)) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.IssueAuthNumberError), ResponseStatusEnum.DEFAULT_ERROR);
		}
		// �Ⱓ�� ����
		final EMailSendDTO emailSendDTO = new EMailSendDTO();
		emailSendDTO.setsSubject(SEND_EMAIL_SUBJECT);
		emailSendDTO.setsToName(sessionReDto.getsKorName());
		emailSendDTO.setsToEmail(strEmail);
		// ġȯ�� ����
		final Map<String, String> replaceMap = new HashMap<String, String>();
		replaceMap.put("[$userName$]", sessionReDto.getsKorName());
		replaceMap.put("[$callBackURL$]", callBackURL);
		replaceMap.put("[$authNumber$]", String.valueOf(authNumber));
		replaceMap.put("[$email$]", email);
		// ���ø� ��������
		String mailContent = mailTempletService.getMailContent(MailTempletType.AUTH_RECRUIT_EMAIL, replaceMap);
		
		mailContent = mailContent.replaceAll("<", "&lt;");
		mailContent = mailContent.replaceAll(">", "&gt;");
		
		emailSendDTO.setsBodyHTML(mailContent);
		logger.debug(mailContent);
		if (!sendBackBoneService.sendEmail(emailSendDTO, userIp)) {
			logger.error("���� �̸��� �߼� ����");
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.IssueAuthNumberError), ResponseStatusEnum.DEFAULT_ERROR);
		}
		logger.debug("�̸��� ���� �߼� ����");
		
		logger.debug("�߱޵� ������ȣ�� ===>" + authNumber);

		final AuthNumberVO authNumberVO = new AuthNumberVO();
		authNumberVO.setAuthNumber(authNumber);
		authNumberVO.setUserEmail(strEmail);
		authNumberVO.setUserIp(userIp);
		// session expired time ���� (30 ��)
		// JODA TIME �� �̿��� EXPIRED_TIME ���ϱ�
		final DateTime date = new DateTime();
		authNumberVO.setExpireDate(date.plusMinutes(this.EXPIRED_TIME * 3).toDate());

		// ������� ���� DB�� ����
		certificationService.insertEmailCertification(authNumberVO);
		// ���ǿ� ���� ����
		request.getSession().setAttribute(SessionNameEnum.RECRUIT_AUTHNUMBER.toString(), authNumberVO);

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(sessionReDto);
		return response;
	}

	/**
	 * <pre>
	 * �̸��Ͽ��� ������ư Ŭ�� �� �������� ó�� 
	 * <pre>
	 * @param servletRequest
	 * @param servletResponse
	 * @param email
	 * @param auth
	 * @throws Exception
	 */
	@RequestMapping(value = "checkEmailAuth")
	@ResponseBody
	public void checkEmailAuth(final HttpServletRequest servletRequest, final HttpServletResponse servletResponse, @RequestParam(value = "email", required = true) final String email, @RequestParam(value = "auth", required = true) final String auth) throws Exception {
		final String userIp = servletRequest.getRemoteAddr();
		final AuthNumberVO inputVO = new AuthNumberVO();
		inputVO.setUserEmail(email);
		inputVO.setUserIp(userIp);
		final AuthNumberVO vo = certificationService.selectEmailCertification(inputVO);

		final EmailAuthStatusEnum authStatus = this.checkAuthNumberAndEmail(vo, email, auth);

		// DB�� ���� ���� ����
		if (EmailAuthStatusEnum.SUCCESS.equals(authStatus)) {
			// �̸��� Ȯ�� update
			vo.setAuth(Boolean.TRUE);
			certificationService.updateEmailCertificationSuccess(vo);

			// �Ի����� �� ���� ���� �̵��ϱ�
			// /static/recruit/notify/resumeApply.xml

			final String result = recruitBackBoneBaseService.setUpdateEmailReceive(email);
			logger.debug("checkEmailAuth result >>> : " + result);
		}
		servletResponse.setContentType("text/html");
		servletResponse.setCharacterEncoding("UTF-8");
		servletResponse.getWriter().print(this.getScriptMessage(userIp, authStatus));
	}

	/**
	 * <pre>
	 * ĳ������ �̸��� �ĸ����͸� ���Ͽ� ���� ��� ����
	 * <pre>
	 * @param vo
	 * @param email
	 * @param auth
	 * @param userIp 
	 * @return
	 */
	private EmailAuthStatusEnum checkAuthNumberAndEmail(final AuthNumberVO vo, final String email, final String auth) {
		if (vo == null) {
			return EmailAuthStatusEnum.NOT_EXIST_VO;
		}
		// �̸��� �� ��
		if (!email.equals(vo.getUserEmail())) {
			return EmailAuthStatusEnum.NOT_EQUALE_EMAIL;
		}
		// ���� Ű ��
		if (!auth.equals(String.valueOf(vo.getAuthNumber()))) {
			return EmailAuthStatusEnum.NOT_EQUALE_AUTH_NUMBER;
		}
		if (!auth.equals(String.valueOf(vo.getAuthNumber()))) {
			return EmailAuthStatusEnum.NOT_EQUALE_AUTH_NUMBER;
		}
		return EmailAuthStatusEnum.SUCCESS;
	}

	/**
	 * <pre>
	 * ���� ����� ���� �޼����� ��ȸ�Ͽ� html ���·� ���� -> alert���� ǥ��
	 * <pre>
	 * @param emailAuthStatusEnum
	 * @return
	 */
	private String getScriptMessage(final String serverPort, final EmailAuthStatusEnum emailAuthStatusEnum) {
		String authMessage = null;
		switch (emailAuthStatusEnum) {
			case NOT_EXIST_VO:
				authMessage = message.getMessage(ExceptionMessage.IssueAuthNumberEmailExpired);
				break;
			case NOT_EQUALE_EMAIL:
				authMessage = message.getMessage(ExceptionMessage.IssueAuthNumberFailNotEqualEmail);
				break;
			case NOT_EQUALE_USER_IP:
				authMessage = message.getMessage(ExceptionMessage.IssueAuthNumberFailNotEqualIp);
				break;
			case NOT_EQUALE_AUTH_NUMBER:
				authMessage = message.getMessage(ExceptionMessage.IssueAuthNumberFailCertification);
				break;
			default:
				authMessage = "������ �����Ͽ����ϴ�.";
				break;
		}
		logger.error(authMessage);
		return "<script type='text/javascript'>alert('" + authMessage + "');location.href='http://recruit.educar.co.kr/websquare/educar.jsp?w2xPath=/static/recruit/notify/resumeApply.xml';</script>";
	}

	/**
	 * <pre>
	 * ä����� 
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "newJobList")
	@ResponseBody
	public GenericRestResponse<JobListDTO> newJobList(@RequestBody final GenericRestRequest<JobListDTO> request) {

		final JobListDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<JobListDTO> response = new GenericRestResponse<JobListDTO>();

		List<JobListDTO> jobList = recruitBackBoneBaseService.selectJobList(requestDTO);
		if (jobList == null) {
			jobList = new ArrayList<JobListDTO>();
		}
		response.setResultCount(jobList.size());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(jobList);
		return response;
	}

	/**
	 * ä������ MASTER ��ȸ
	 */
	@RequestMapping("jobMaster")
	@ResponseBody
	public GenericRestResponse<JobGenDetailWrapperDTO> jobMaster(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<JobListDTO> request) {
		final GenericRestResponse<JobGenDetailWrapperDTO> response = new GenericRestResponse<JobGenDetailWrapperDTO>();

		// �� ������ �ϳ��� �־�� �Ѵ�. Null�� @NotNull���� ó����.
		final JobListDTO dto = request.getRequestData().size() > 1 ? null : request.getRequestData().get(BigInteger.ZERO.intValue());

		final String sHireNo = dto.getsHireNo();
		logger.debug(">>>>>>>>>>>>>>>>>>>>>" + sHireNo);

		final JobMasterDTO masterResult = recruitBackBoneBaseService.selectJobMaster(sHireNo);
		logger.debug(">>>>>>>>>>>>>>>>>>>>> detail select");
		final List<JobDetailDTO> detailList = recruitBackBoneBaseService.selectJobDetail(sHireNo);

		final JobGenDetailWrapperDTO wrapperDTO = new JobGenDetailWrapperDTO();

		wrapperDTO.setMasterResult(masterResult);
		wrapperDTO.setDetailList(detailList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(wrapperDTO);
		return response;
	}

	/**
	 * <pre>
	 * ����� ä����� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getInquiryList")
	@ResponseBody
	public GenericRestResponse<ResumeApplyListDTO> getInquiryList(@NotNull @RequestBody final GenericRestRequest<ResumeApplyListDTO> request) {
		final String sFmdt = DateTime.now().plusMonths(-6).toString("yyyyMMdd"); // 3���� ��
		final List<ResumeApplyListDTO> ResumeApplyList = resumeApplyListBackBoneService.getResumeApplyList("20120101"); // sFmdt ����

		logger.debug("sFmdt!!!!!>>>" + sFmdt);

		final GenericRestResponse<ResumeApplyListDTO> response = new GenericRestResponse<ResumeApplyListDTO>();
		if (ResumeApplyList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(ResumeApplyList);
		}

		return response;
	}

	/**
	 * <pre>
	 * �������Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "inquiryCheck")
	@ResponseBody
	public GenericRestResponse<ResultInquiryDTO> inquiryCheck(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<ResultInquiryDTO> request) {
		final GenericRestResponse<ResultInquiryDTO> response = new GenericRestResponse<ResultInquiryDTO>();

		final ResultInquiryDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		final ResultInquiryDTO result = recruitBackBoneBaseService.checkResultInquiry(inputDTO);
		if (StringUtil.isNullOrEmpty(result.getsKorName())) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			// SESSION�� ä������ ���
			session.setAttribute(SessionNameEnum.RECRUIT_RESULT_INFO.toString(), inputDTO);
			response.setForwardURL(WebServletEnum.RECRUIT_RESULT_OK_URL, session);
		}
		return response;

	}

	/**
	 * <pre>
	 * ���������ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "resultOk")
	@ResponseBody
	public GenericRestResponse<ResultInquiryDTO> selectResultOk(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<ResultInquiryDTO> request) {
		final ResultInquiryDTO sessionRecruitDto = (ResultInquiryDTO) session.getAttribute(SessionNameEnum.RECRUIT_RESULT_INFO.toString());
		final GenericRestResponse<ResultInquiryDTO> response = new GenericRestResponse<ResultInquiryDTO>();

		final ResultInquiryDTO result = recruitBackBoneBaseService.checkResultInquiry(sessionRecruitDto);

		response.addResponseData(result);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;

	}

	/**
	 * <pre>
	 * ä���� ��� ��ȸ 
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "resultInquiry")
	@ResponseBody
	public GenericRestResponse<JobListDTO> selectResultInquiry(@RequestBody final GenericRestRequest<JobListDTO> request) {

		final JobListDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<JobListDTO> response = new GenericRestResponse<JobListDTO>();

		List<JobListDTO> jobList = recruitBackBoneBaseService.selectJobList(requestDTO);
		if (jobList == null) {
			jobList = new ArrayList<JobListDTO>();
		}
		response.setResultCount(jobList.size());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(jobList);
		return response;
	}

	/**
	 * <pre>
	 * ä�빮�� - �̸��� �߼�
	 * <pre>
	 * @param servletRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "questionSend")
	@ResponseBody
	public GenericRestResponse<EMailSendDTO> questionSendEmail(@RequestBody final GenericRestRequest<RecruitEmailSendDTO> request) {

		final RecruitEmailSendDTO requestEmailDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final EMailSendDTO sendEmailDto = new EMailSendDTO();
		final GenericRestResponse<EMailSendDTO> response = new GenericRestResponse<EMailSendDTO>();
		logger.debug(">>>>>>>>>>>>>>> fromEmail : " + requestEmailDto.getsFromEmail());
		sendEmailDto.setsFromEmail(requestEmailDto.getsFromEmail());
		sendEmailDto.setsToEmail("recruit@educar.co.kr"); // ä������ ���Ϸ� �߼�
		sendEmailDto.setsToName("ä������");
		sendEmailDto.setsSubject(requestEmailDto.getsSubject());
		sendEmailDto.setsBodyHTML(requestEmailDto.getsBodyHTML());

		final boolean returnValue = sendBackBoneService.sendEmail(sendEmailDto, UserIDEnum.WEB_USER.getCode());
		if (returnValue) {
			logger.debug("�̸��� �߼ۼ���");
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		} else {
			logger.debug("�̸��� �߼۽���");
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		}

		return response;
	}

	/**
	 * ä�� ���� - ä����� list ��ȸ
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getRecruitList")
	@ResponseBody
	public GenericRestResponse<RecruitDTO> getRecruitList(@RequestBody final GenericRestRequest<RecruitDTO> request) {
		final GenericRestResponse<RecruitDTO> response = new GenericRestResponse<RecruitDTO>();

		final List<RecruitDTO> recruitList = recruitDAO.selectRecruitInfo();

		response.setData(recruitList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setMessage((DateTime.now().toString("yyyyMMdd")));
		return response;
	}

	/**
	 * <pre>
	 * �����̸��� ��߼�
	 * <pre>
	 * @param servletRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "reSendEmail")
	@ResponseBody
	public GenericRestResponse<Void> reSendEmail(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<NewResumeApplyDTO> request) {
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		final NewResumeApplyDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		session.setAttribute(SessionNameEnum.RECRUIT_INFO.toString(), inputDTO);
		// �ű��̷¼���� �Ϸ�(newResumeOk)ȭ�� �̵�
		response.setForwardURL(WebServletEnum.RECRUIT_NEWRESUME_OK_URL, session);
		// ����� ��ȯ
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}
}
