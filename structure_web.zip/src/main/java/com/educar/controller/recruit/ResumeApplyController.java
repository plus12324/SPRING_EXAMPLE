/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.recruit;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FTPService;
import com.educar.common.service.FileService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.PropertyService;
import com.educar.common.service.SessionService;
import com.educar.common.vo.RecruitInfoVO;
import com.educar.dto.recruit.notify.ApplyPathCodeDTO;
import com.educar.dto.recruit.notify.ApplyStep1DTO;
import com.educar.dto.recruit.notify.ApplyStep1Ofhrmaa03DocDTO;
import com.educar.dto.recruit.notify.ApplyStep1OutputDTO;
import com.educar.dto.recruit.notify.ApplyStep2DTO;
import com.educar.dto.recruit.notify.ApplyStep3DTO;
import com.educar.dto.recruit.notify.ApplyStep3OutputDTO;
import com.educar.dto.recruit.notify.ApplyStep4DTO;
import com.educar.dto.recruit.notify.ApplyStep5DTO;
import com.educar.dto.recruit.notify.JobDetailDTO;
import com.educar.dto.recruit.notify.ResumeApplyListDTO;
import com.educar.dto.recruit.notify.UpdateApplyStep2DTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.SystemPropertyEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.recruit.backbone.RecruitBackBoneBaseService;
import com.educar.service.recruit.backbone.ResumeApplyListBackBoneService;

/**
 * @author �Ž¿�
 *
 */

@Controller
@RequestMapping("/resumeApply")
public class ResumeApplyController {

	/** Logger */
	private final Logger logger = Logger.getLogger(getClass());

	@Autowired
	private ResumeApplyListBackBoneService resumeApplyListBackBoneService;

	@Autowired
	private RecruitBackBoneBaseService recruitBackBoneBaseService;

	/** ���� ���� **/
	@Autowired
	private SessionService sessionService;

	@Autowired
	private FileService fileService;

	@Autowired
	private FTPService ftpService;
	@Autowired
	private PropertyService propService;

	/** �޼��� **/
	@Autowired
	private MessageSourceService messageService;
	
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	/**
	 * <pre>
	 * �������� ä����� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getApplyList")
	@ResponseBody
	public GenericRestResponse<ResumeApplyListDTO> getApplyList(@NotNull @RequestBody final GenericRestRequest<ResumeApplyListDTO> request) {

		final List<ResumeApplyListDTO> ResumeApplyList = resumeApplyListBackBoneService.getResumeApplyListPossible();

		final GenericRestResponse<ResumeApplyListDTO> response = new GenericRestResponse<ResumeApplyListDTO>();
		if (ResumeApplyList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(ResumeApplyList);
		}
		logger.debug("Controller+response>>>>>>" + response);

		return response;

	}

	/**
	 * <pre>
	 *  ���ǿ��� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "checkRecruitSession")
	@ResponseBody
	public GenericRestResponse<RecruitInfoVO> checkRecruitSession(final HttpSession session) {

		final RecruitInfoVO recruitVO = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());
		final GenericRestResponse<RecruitInfoVO> response = new GenericRestResponse<RecruitInfoVO>();

		if (recruitVO == null) {
			response.setStatus(ResponseStatusEnum.NEED_LOGIN.getCode());
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(recruitVO);
		}

		return response;
	}

	/**
	 * <pre>
	 *  �Ի����� ���� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "selectCheckApplyInfo")
	@ResponseBody
	public GenericRestResponse<RecruitInfoVO> selectCheckApplyInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<RecruitInfoVO> request) {
		final RecruitInfoVO inputVO = request.getRequestData().get(BigInteger.ZERO.intValue());

		final RecruitInfoVO result = resumeApplyListBackBoneService.selectCheckApplyInfo(inputVO);

		inputVO.setnApplyNo(result.getnApplyNo());

		final GenericRestResponse<RecruitInfoVO> response = new GenericRestResponse<RecruitInfoVO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		if ("0".equals(result.getResult())) { // 0:�űԻ���� ����̵� 1:�̸��������̵�  2:�̷¼� �ۼ��̵� 3:�̷¼� �����̵� 4:�ۼ��Ϸ�
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setMessage("1");

		} else if ("1".equals(result.getResult())) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setMessage(result.getResult());

		}

		else if ("2".equals(result.getResult())) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setMessage(result.getResult());
			//��ó�� ���� �߰�..���� step���� ���ǿ��� ���������´�.
			session.setAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString(), inputVO);

		}

		else if ("3".equals(result.getResult())) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setMessage(result.getResult());

			//��ó�� ���� �߰�..���� step���� ���ǿ��� ���������´�.
			session.setAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString(), inputVO);

		}

		else if ("4".equals(result.getResult())) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setMessage(result.getResult());

		}

		else {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
		}

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����1�ܰ� ������ set�Ѵ�(nApplyNo������ȣ ������)(setApplyStep1)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "setApplyStep1")
	@ResponseBody
	public GenericRestResponse<Void> setApplyStep1(final HttpSession session, final GenericRestRequest<Void> request) {

		final RecruitInfoVO recruitVO = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		//backboneseveice ȣ��� DTO ����
		final ApplyStep1DTO requestDTO = new ApplyStep1DTO();

		/*
		 		//Null�� ������ DTO ����
		final ApplyStep1Ofhrmaa03DocDTO tempRequestDTO = new ApplyStep1Ofhrmaa03DocDTO();  
		 
		final String[] filedsToProcess = { "nOrgSeq", "sHireType", "sCareerType", "sRecruitGroup", 
				"sEngName", "sChiName", "sCitizenNo", "sBirthDt", "sBirthdayType", "sSex",  
				"sFamilyMaster", "sFamilyMasterRel", "sHomeTel1", "sHomeTel2", "sHomeTel3", "sCellPhone1", "sCellPhone2", 
				"sCellPhone3", "sUrgentTel1", "sUrgentTel2", "sUrgentTel3", "sCurrZip", "sCurrAdrs", "sCurrAdrsAdd", 
				"sBirthZip", "sBirthAdrs", "sBirthAdrsAdd", "sHopeGroup", "sHopeWorkSite1", "sHopeWorkSite2", 
				"sRealPromoteDt", "nCurrSalary", "nHopeSalary", "sHopeClass", "nHeight", "nWeight", "nLeftEyesight", 
				"nRightEyesight", "sColorBlindYN", "sHobby1", "sHobby2", "sSpecialty", "sReligionCode", "sMilitaryStat", 
				"sMilitaryType", "sMilitaryNo", "sMilitaryGroup", "sMilitaryClass", "sMilitaryFmdt", "sMilitaryTodt", 
				"sRemissionCode", "sExploitYN", "sExploitType", "sRecmdCode", "sRecmdNm", "sNote", "sSelCode", "sPassYN",
				"sResumeConfirmYN", "sUserIP", "sUserID", "sInputDate", "sInputTime", "sCertifyNo", "sApplyPath1", 
				"sApplyPath2"};
			

		
		requestDTO.setHRMAA03(this.nvlSpecificStringFields(tempRequestDTO, filedsToProcess, "" ) ); //Null �� ����
		*/

		requestDTO.setHRMAA03(new ApplyStep1Ofhrmaa03DocDTO());

		requestDTO.getHRMAA03().setsHireNo(recruitVO.getsHireNo());
		requestDTO.getHRMAA03().setsEmail(recruitVO.getsEmail());
		requestDTO.getHRMAA03().setsKorName(recruitVO.getsKorName());
		requestDTO.getHRMAA03().setsPassword(recruitVO.getsPassword());

		resumeApplyListBackBoneService.setApplyStep1(requestDTO);

		//�麻���񽺷� ������ nApplyNO�� �������� ���ǿ� �ٽ� ����

		final RecruitInfoVO result = resumeApplyListBackBoneService.selectCheckApplyInfo(recruitVO);
		//�������� �̸����� ���ο� �����̸��Ͽ� ����
		result.setsEmail(recruitVO.getsEmail());

		session.setAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString(), result);

		final RecruitInfoVO dd = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**
	 * <pre>
	 * ������θ� ������ �´�.
	 * <pre>
	 * @param String
	 * @return ApplyPathCodeDTO
	 */
	@RequestMapping(value = "getApplyPathCode")
	@ResponseBody
	public GenericRestResponse<ApplyPathCodeDTO> getApplyPathCode() {

		final GenericRestResponse<ApplyPathCodeDTO> response = new GenericRestResponse<ApplyPathCodeDTO>();
		/*�麻����ȣ��*/
		final List<ApplyPathCodeDTO> detailList = resumeApplyListBackBoneService.getApplyPathCode("193");

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(detailList);

		return response;
	}

	/**
	 * <pre>
	 * ������� �󼼸� ������ �´�.
	 * <pre>
	 * @param String
	 * @return ApplyPathCodeDTO
	 */
	@RequestMapping(value = "getApplyPathDetailCode")
	@ResponseBody
	public GenericRestResponse<ApplyPathCodeDTO> getApplyPathDetailCode() {

		final GenericRestResponse<ApplyPathCodeDTO> response = new GenericRestResponse<ApplyPathCodeDTO>();
		/*�麻����ȣ��*/
		final List<ApplyPathCodeDTO> detailList = resumeApplyListBackBoneService.getApplyPathCode("194");

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(detailList);

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����1�ܰ� ������ �����´�.(getApplyStep1)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getApplyStep1")
	@ResponseBody
	public GenericRestResponse<ApplyStep1OutputDTO> getApplyStep1(final HttpSession session) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());
		final ApplyStep1OutputDTO resultList = resumeApplyListBackBoneService.getApplyStep1(recruitInfo);
		final GenericRestResponse<ApplyStep1OutputDTO> response = new GenericRestResponse<ApplyStep1OutputDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����1�ܰ� ������ �����Ѵ�.(updateApplyStep1)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "updateApplyStep1")
	@ResponseBody
	public GenericRestResponse<Void> updateApplyStep1(final HttpServletRequest servletRequest, final HttpSession session, @NotNull @RequestBody final GenericRestRequest<ApplyStep1DTO> request) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep1DTO inputdto = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId(sessionService.getUserID(session));
		//�� ���θ� ǥ���ּ� 
		//���ּ� �ּ�
		if(inputdto.getHRMAA03().getsCurrStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(inputdto.getHRMAA03().getsCurrAddrMgtNo());
			stndAddrDto.setVarPost(inputdto.getHRMAA03().getsCurrZip());
			stndAddrDto.setVarAllAddress(inputdto.getHRMAA03().getsCurrDoroAddr() + inputdto.getHRMAA03().getsCurrAdrsAdd());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);
			inputdto.getHRMAA03().setsCurrAdrs(resultAdr.getAnlysStndRdNmHighAddrA());
			inputdto.getHRMAA03().setsCurrAdrsAdd(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
		//������
		if(inputdto.getHRMAA03().getsBirthStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(inputdto.getHRMAA03().getsBirthAddrMgtNo());
			stndAddrDto.setVarPost(inputdto.getHRMAA03().getsBirthZip());
			stndAddrDto.setVarAllAddress(inputdto.getHRMAA03().getsBirthDoroAddr() + inputdto.getHRMAA03().getsBirthAdrsAdd());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);
			inputdto.getHRMAA03().setsBirthAdrs(resultAdr.getAnlysStndRdNmHighAddrA());
			inputdto.getHRMAA03().setsBirthAdrsAdd(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
		
		//���ǿ� �ִ� ä���ȣ,������ȣ ����
		inputdto.setBaseDoc(recruitInfo);

		//�۾��� ��� �� ip ����
		final String userIp = servletRequest.getRemoteAddr();
		inputdto.getHRMAA03().setsUserIP(userIp);
		inputdto.getHRMAA03().setsUserID("8000001");

		//�Ⱓ�� ȣ��
		final ApplyStep1DTO resultList = resumeApplyListBackBoneService.updateApplyStep1(inputdto);

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**
	 * step1 �������ε�
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "updateApplyStep1Photo")
	@ResponseBody
	public GenericRestResponse<Void> updateApplyStep1Photo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<ApplyStep1DTO> request) {

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep1DTO inputdto = request.getRequestData().get(BigInteger.ZERO.intValue());

		final String fileId = inputdto.getFileId();

		// �ӽ� ����� ������ �ҷ� �´�
		final File file = fileService.getFileByID(fileId);
		if (file == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SaveFail, "������ �����ϴ�.")).build();
		}

		// FTP�� �����ϱ� ���� ���� �̸��� �����Ѵ�
		final String newFileName = recruitInfo.getsHireNo() + "-" + recruitInfo.getnApplyNo() + ".jpg";
		logger.debug("������ �����̸��� : " + newFileName);
		final File newFile = new File(newFileName);
		file.renameTo(newFile);
		// ftp ������ �˾ƿ´�..
		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		String ip = null;
		String userId = null;
		String password = null;
		final String remoteFilePath = propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_SERVER_PATH.getKey());
		try {
			final String urlParam = propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_URL_PARAM.getKey());
			final URL url = new URL(propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_URL.getKey()));
			final URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(urlParam);
			writer.flush();
			String line;
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				final String[] params = line.split("=");
				if (params.length == 2) {
					if (params[0].trim().equals("ip")) {
						ip = params[1].trim();
					}
					if (params[0].trim().equals("id")) {
						userId = params[1].trim();
					}
					if (params[0].trim().equals("password")) {
						password = params[1].trim();
					}
				}
			}
		} catch (final Exception e) {
			// FTP �ּҸ� ������ ���� jsp ȣ�� ����
			throw new RuntimeException(e);
		} finally {
			// clean up connection
			try {
				writer.close();
				reader.close();
			} catch (final IOException e) {
				// can't do anthing here when shit happens.
				throw new RuntimeException(e);
			}
		}
		logger.debug("����Ʈ �λ� ���� IP :" + ip);
		logger.debug("����Ʈ �λ� ���� ���� ��ġ :" + remoteFilePath);
		ftpService.upload(ip, userId, password, newFile, remoteFilePath + newFile.getName());
		logger.debug("������� �Ϸ�");

		// ���ǿ��� ä���ȣ, ������ȣ�� �ܾ�� �����̸����� ����Ѵ�.

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**
	 * <pre>
	 * Todo �Ի�����2�ܰ� ������ �����´�.(getApplyStep2)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getApplyStep2")
	@ResponseBody
	public GenericRestResponse<ApplyStep2DTO> getApplyStep2(final HttpSession session) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());
		final List<ApplyStep2DTO> resultList = resumeApplyListBackBoneService.getApplyStep2(recruitInfo);
		final GenericRestResponse<ApplyStep2DTO> response = new GenericRestResponse<ApplyStep2DTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����2�ܰ� ������ �����Ѵ�.(updateApplyStep2)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "updateApplyStep2")
	@ResponseBody
	public GenericRestResponse<ApplyStep2DTO> updateApplyStep2(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<UpdateApplyStep2DTO> request) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());
		final UpdateApplyStep2DTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		inputDTO.setBaseDoc(recruitInfo);

		final List<ApplyStep2DTO> resultList = resumeApplyListBackBoneService.updateApplyStep2(inputDTO);

		final GenericRestResponse<ApplyStep2DTO> response = new GenericRestResponse<ApplyStep2DTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * Todo �Ի�����3�ܰ� ������ �����´�.(getApplyStep3)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getApplyStep3")
	@ResponseBody
	public GenericRestResponse<ApplyStep3OutputDTO> getApplyStep3(final HttpSession session) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep3OutputDTO resultList = resumeApplyListBackBoneService.getApplyStep3(recruitInfo);
		final GenericRestResponse<ApplyStep3OutputDTO> response = new GenericRestResponse<ApplyStep3OutputDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����3�ܰ� ������ �����Ѵ�.(updateApplyStep2)
	 * <pre>
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "updateApplyStep3")
	@ResponseBody
	public GenericRestResponse<ApplyStep3DTO> updateApplyStep3(final HttpSession session, @RequestBody final GenericRestRequest<ApplyStep3DTO> request) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());
		final ApplyStep3DTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		inputDTO.setBaseDoc(recruitInfo);

		final List<ApplyStep3DTO> resultList = resumeApplyListBackBoneService.updateApplyStep3(inputDTO);

		final GenericRestResponse<ApplyStep3DTO> response = new GenericRestResponse<ApplyStep3DTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}

	/**
	 * <pre>
	 * �Ի�����4�ܰ� ������ �����´�.(getApplyStep4)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getApplyStep4")
	@ResponseBody
	public GenericRestResponse<ApplyStep4DTO> getApplyStep4(final HttpSession session) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep4DTO result = resumeApplyListBackBoneService.getApplyStep4(recruitInfo);

		final GenericRestResponse<ApplyStep4DTO> response = new GenericRestResponse<ApplyStep4DTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}

	/**
	 * <pre>
	 * Todo �Ի�����4�ܰ� ������ update�Ѵ�.(updateApplyStep4)
	 * <pre>
	 * @param request 
	 * @return
	 */
	@RequestMapping(value = "updateApplyStep4")
	@ResponseBody
	public GenericRestResponse<ApplyStep4DTO> updateApplyStep4(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<ApplyStep4DTO> request) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep4DTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		inputDTO.setnApplyNo(recruitInfo.getnApplyNo());
		inputDTO.setsHireNo(recruitInfo.getsHireNo());

		final ApplyStep4DTO result = resumeApplyListBackBoneService.updateApplyStep4(inputDTO);

		final GenericRestResponse<ApplyStep4DTO> response = new GenericRestResponse<ApplyStep4DTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**
	 * <pre>
	 * Todo �Ի������� ����(setApplyStep5)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "setApplyStep5")
	@ResponseBody
	public GenericRestResponse<ApplyStep5DTO> setApplyStep5(final HttpSession session) {

		final RecruitInfoVO recruitInfo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		final ApplyStep5DTO result = resumeApplyListBackBoneService.setApplyStep5(recruitInfo);

		final GenericRestResponse<ApplyStep5DTO> response = new GenericRestResponse<ApplyStep5DTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**
	 * �Ի� ���� ������ FTP�� �ε� ��, �������� ������Ʈ�� byte�� �����ش�
	 * @param fileName ä���ȣ + ������ȣ + .jpg
	 * @throws IOException 
	 */
	@RequestMapping(value = "/downloadImage")
	public void getImageFile(@RequestParam(value = "fileName") final String fileName, final HttpServletResponse response) throws IOException {

		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		String ip = null;
		String userId = null;
		String password = null;
		final String remoteFilePath = propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_SERVER_PATH.getKey());
		try {
			final String urlParam = propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_URL_PARAM.getKey());
			final URL url = new URL(propService.getProperty(SystemPropertyEnum.RECRUIT_FTP_URL.getKey()));
			final URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(urlParam);
			writer.flush();
			String line;
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				final String[] params = line.split("=");
				if (params.length == 2) {
					if (params[0].trim().equals("ip")) {
						ip = params[1].trim();
					}
					if (params[0].trim().equals("id")) {
						userId = params[1].trim();
					}
					if (params[0].trim().equals("password")) {
						password = params[1].trim();
					}
				}
			}
		} catch (final Exception e) {
			// FTP �ּҸ� ������ ���� jsp ȣ�� ����
			throw new RuntimeException(e);
		} finally {
			// clean up connection
			try {
				writer.close();
				reader.close();
			} catch (final IOException e) {
				// can't do anthing here when shit happens.
				throw new RuntimeException(e);
			}
		}

		final ByteArrayOutputStream os = ftpService.download(ip, userId, password, fileName, remoteFilePath);
		final byte[] data = os.toByteArray();
		final int fileLength = data.length;
		logger.debug("�ٿ�ε� ���� ���� ������� :" + fileLength);
		response.setBufferSize(fileLength);
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		response.setContentLength(fileLength);
		// output stream�� ������ write�Ѵ�.
		FileCopyUtils.copy(data, response.getOutputStream());
		// bis.close();
		response.getOutputStream().flush();
		response.getOutputStream().close();
		logger.debug("response�� ���� write �Ϸ�");
	}

	/**
	 * <pre>
	 * Todo ���úо� ���� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "getRecuritViewInfo")
	@ResponseBody
	public GenericRestResponse<JobDetailDTO> getRecuritViewInfo(final HttpSession session) {
		final GenericRestResponse<JobDetailDTO> response = new GenericRestResponse<JobDetailDTO>();

		/*���ǿ��� ������ data ������ ���úо� ����Ȯ��*/
		final RecruitInfoVO vo = (RecruitInfoVO) session.getAttribute(SessionNameEnum.RESUME_APPLY_INFO.toString());

		/*�麻����ȣ��*/
		final List<JobDetailDTO> detailList = recruitBackBoneBaseService.selectJobDetail(vo.getsHireNo());

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(detailList);

		return response;

	}

	/**
	 * Ư�� ��� �Ⱓ�� ȣ�� �� ���� ���� Null�� �ʵ��� ���� 00 �Ǵ� nvl ó���� �Ҷ��� �ʿ���ϰ� �Ѵ�.
	 * �̷� ��� ����ϸ� ���� method;
	 * @param dto Process �� �ڹ� object
	 * @param fieldsToProcess ó���� String �ʵ� �̸��� arrayList
	 * @param nvlString ó���� ��Ʈ��
	 * @return dto
	 */
	private <T> T nvlSpecificStringFields(final T dto, final String[] fieldsToProcess, final String nvlString) {
		final List<String> fieldsToProcessList = Arrays.asList(fieldsToProcess);
		final Field[] fields = dto.getClass().getDeclaredFields();
		for (final Field field : fields) {

			try {
				if (!String.class.isAssignableFrom(field.getType())) {
					continue;
				}
				field.setAccessible(true);
				final String obj = (String) field.get(dto);
				if (fieldsToProcessList.contains(field.getName()) && StringUtils.isBlank(obj)) {
					field.set(dto, nvlString);
				}
			} catch (final Exception e) {
				throw new RuntimeException(e);
			}
		}
		return dto;
	}

}
