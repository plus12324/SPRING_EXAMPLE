/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.partner;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Document;

import com.educar.common.service.SessionService;
import com.educar.common.vo.PartnerLoginInfoVO;
import com.educar.dto.partner.PartnerCompanyInfoDTO;
import com.educar.dto.partner.PartnerCompanyInfoWrapperDTO;
import com.educar.dto.partner.PartnerInsuInquiryListDTO;
import com.educar.dto.partner.PartnerInsuJoinDTO;
import com.educar.dto.partner.PartnerLoginDTO;
import com.educar.dto.partner.PartnerPayInsuWrapperDTO;
import com.educar.dto.partner.PartnerQualityDTO;
import com.educar.dto.partner.PartnerStaffInfoDTO;
import com.educar.dto.partner.PartnerTempPwdSendDTO;
import com.educar.dto.web.PhoneCertificationInputDTO;
import com.educar.enumeration.SessionNameEnum;
import com.educar.service.backbone.PartnerBackBoneService;
import com.educar.service.web.CertificationForSciService;
import com.inswave.util.XMLUtil;

/**
 * ���¾�ü �ý��� ��Ʈ�ѷ�
 * @author ���ѳ�
 *
 */
@Controller
public class PartnerController {

	/** SCI (����ſ���) �ſ�ī��, �޴��� �������� ���� **/
	@Autowired
	private CertificationForSciService certificationForSciService;
	
	/** �Ⱓ�� ���� */
	@Autowired
	private PartnerBackBoneService partnerBackBoneService;
	/** session service */
	@Autowired
	private SessionService sessionService;
	/** logger */
	private Logger logger = Logger.getLogger(this.getClass());
	
	
	@RequestMapping(value = "/partner/memberJoinInit")
	public ModelAndView memberJoinInit(final HttpServletRequest request) {
		
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/login/member_Join.jsp");
		return mv;
	}
	
	@RequestMapping(value = "/partner/certiInit")
	public ModelAndView certiInit(final HttpServletRequest request) {
		
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/popup/popCertification.jsp");
		return mv;
	}
	/**
	 * �α���
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/login")
	public ModelAndView login(final HttpSession session, final HttpServletRequest servletRequest, final PartnerLoginDTO reqDto) {
		
		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		final PartnerLoginDTO responseDto = partnerBackBoneService.partnerLogin(reqDto);
		
		if("0".equals(responseDto.getResult())){
			XMLUtil.setString(partnerDoc, "sMsgCode"		, "01");
			XMLUtil.setString(partnerDoc, "sMsg"		, responseDto.getMsg());
			
		}else{
			//��ü���� ��ȸ
			final PartnerCompanyInfoDTO compInfo = partnerBackBoneService.getCompanyInfo(responseDto.getsBizRegiNo()).getCLMMA09();
			final PartnerLoginInfoVO loginVo = new PartnerLoginInfoVO();
			
			loginVo.setsBizRegiNo(responseDto.getsBizRegiNo());
			loginVo.setsCompanyName(compInfo.getsCompanyKorName());
			loginVo.setsCorrespondent(responseDto.getsCorrespondent());
			loginVo.setsCompanyType(responseDto.getsCompanyType());
			loginVo.setsJobDiv(responseDto.getsJobDiv());
			loginVo.setsAppDiv(responseDto.getsAppDiv());
			loginVo.setsName(responseDto.getsName());
			loginVo.setsJobTitle(responseDto.getsJobTitle());
			loginVo.setsBirthYear(responseDto.getsBirthYear());
			loginVo.setsCellPhone1(responseDto.getsCellPhone1());
			loginVo.setsCellPhone2(responseDto.getsCellPhone2());
			loginVo.setsCellPhone3(responseDto.getsCellPhone3());
			
			
			//�α��� ��ü ���� ���ǿ� ���
			session.setAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.name(), loginVo);
			
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "00");
			XMLUtil.setString(partnerDoc, "sMsg"		, responseDto.getMsg());
			XMLUtil.setString(partnerDoc, "sAppDiv"		, responseDto.getsAppDiv());
		}
		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}

	/**
	 * �޴��� ��������
	 * @return
	 */
	@RequestMapping(value = "/partner/phoneCertification")
	public ModelAndView phoneCertification(final HttpSession session,  final PhoneCertificationInputDTO request) {
		String strInsrdName = request.getsInsrdName();
		
		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		try {
			strInsrdName = URLDecoder.decode( strInsrdName, "utf-8");
			request.setsInsrdName(strInsrdName);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final PhoneCertificationInputDTO outputDTO;// = certificationService.oknameBirthDayCertification(request);
		// ������� ��������
		if(StringUtil.isNullOrEmpty(request.getsCertMsg())){	
			logger.debug("�޴��� �������� - ���� ����");
			outputDTO = certificationForSciService.sciCertificationForPhone(request);
		}else{
			logger.debug("�޴��� �������� - ������ >> " + request.getsCertMsg());
			outputDTO = certificationForSciService.sciCertificationForPhoneRetry(request);
		}
		
		if (!outputDTO.isSuccess()) {
			XMLUtil.setString(partnerDoc, "sMsgCode"		, "01");
		} else {
			XMLUtil.setString(partnerDoc, "sMsgCode"		, "00");
			XMLUtil.setString(partnerDoc, "sSvcTxSeqno"  	, outputDTO.getSvcTxSeqno());  //�ŷ��Ϸù�ȣ
    		XMLUtil.setString(partnerDoc, "sCertMsg"  	, outputDTO.getsCertMsg());
    		XMLUtil.setString(partnerDoc, "reSndCnt"  	, outputDTO.getReSndCnt());
		}

		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}
	/**
	 * �޴��� �������� Ȯ��
	 * @return
	 */
	@RequestMapping(value = "/partner/phoneCertificationCheck")
	public ModelAndView phoneCertificationCheck(final HttpSession session,  final PhoneCertificationInputDTO request) {
		
		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		String strInsrdName = request.getsInsrdName();
		try {
			strInsrdName = URLDecoder.decode( strInsrdName, "utf-8");
			request.setsDiv("L1");
			request.setsInsrdName(strInsrdName);
			request.setsCustNo(request.getsBirthDay().substring(2)+"0000000");
			request.setsUserID(sessionService.getUserID(session));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// ������� ��������
		//final boolean checkResult = certificationService.oknameBirthDayCertificationCheck(request);
		// ������� ��������
		final PhoneCertificationInputDTO resultDTO = certificationForSciService.sciCertificationForPhoneCheck(request);
		if (resultDTO.isSuccess()) {
			XMLUtil.setString(partnerDoc, "sMsgCode"		, "00");
		} else {
			XMLUtil.setString(partnerDoc, "sMsgCode"		, "01");
		}
		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}
	/**
	 * ��й�ȣ ã�� - �ӽú�й�ȣ ����
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/findPwd")
	public ModelAndView findPwd(final HttpServletRequest servletRequest, final PartnerTempPwdSendDTO reqDto) {
		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		final PartnerTempPwdSendDTO result = partnerBackBoneService.sendTempPassWord(reqDto);

		if(result.getResult().equals("1")){
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "00");
			XMLUtil.setString(partnerDoc, "sMsg"		, "�ӽú�й�ȣ�� �߼��Ͽ����ϴ�.");
		}else{
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "01");
			XMLUtil.setString(partnerDoc, "sMsg"		, result.getsMessage());
		}
		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}
	/**
	 * ��ü��ȸ
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/getCompInfo")
	public ModelAndView getCompInfo(final HttpSession session, final String sBizRegiNo) {

		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		final PartnerCompanyInfoWrapperDTO responseDto = partnerBackBoneService.getCompanyInfo(sBizRegiNo);
		

		if(responseDto.getTotalRows().equals("0")){
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "01");
			XMLUtil.setString(partnerDoc, "sMsg"		, "�ش��ü�� ���ų� ������ �߻��߽��ϴ�.\n����ڿ��� �����ϼ���.");
		}else{
			
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "00");
			XMLUtil.setString(partnerDoc, "sCnt"	, responseDto.getTotalRows());
			
			XMLUtil.setString(partnerDoc, "sCompanyKorName"	, responseDto.getCLMMA09().getsCompanyKorName());
			XMLUtil.setString(partnerDoc, "sCompanyEngName"	, responseDto.getCLMMA09().getsCompanyEngName());
			XMLUtil.setString(partnerDoc, "sBossSocNo"	, responseDto.getCLMMA09().getsBossSocNo());
			XMLUtil.setString(partnerDoc, "sZip1"	, responseDto.getCLMMA09().getsZip1());
			XMLUtil.setString(partnerDoc, "sZip2"	, responseDto.getCLMMA09().getsZip2());
			XMLUtil.setString(partnerDoc, "sAddress1"	, responseDto.getCLMMA09().getsAddress1());
			XMLUtil.setString(partnerDoc, "sAddress2"	, responseDto.getCLMMA09().getsAddress2());
			XMLUtil.setString(partnerDoc, "sTel1"	, responseDto.getCLMMA09().getsTel1());
			XMLUtil.setString(partnerDoc, "sTel2"	, responseDto.getCLMMA09().getsTel2());
			XMLUtil.setString(partnerDoc, "sTel3"	, responseDto.getCLMMA09().getsTel3());
			XMLUtil.setString(partnerDoc, "sFaxTel1"	, responseDto.getCLMMA09().getsFaxTel1());
			XMLUtil.setString(partnerDoc, "sFaxTel2"	, responseDto.getCLMMA09().getsFaxTel2());
			XMLUtil.setString(partnerDoc, "sFaxTel3"	, responseDto.getCLMMA09().getsFaxTel3());
			XMLUtil.setString(partnerDoc, "sCorrespondent"	,  responseDto.getCLMMA09().getsCorrespondent());
		}
		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}
	
	/**
	 * �α׾ƿ�
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/logout")
	public ModelAndView logout(final HttpSession session) {
		final ModelAndView mv = new ModelAndView();
		session.setAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.name(), null);
		mv.setViewName("/partner/message.jsp");
		mv.addObject("returnMSG", "");
		mv.addObject("returnURL", "logout");
		return mv;
	}
	/**
	 * ȸ���������� ȭ�� 
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/memModifyInit")
	public ModelAndView memberModifyInit(final HttpSession session) {
		
		final ModelAndView mv = new ModelAndView();
		
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
		if(loginInfo == null){
			mv.setViewName("/partner/message.jsp");
			mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
			mv.addObject("returnURL", "index");
			return mv;
		}
		
		final PartnerCompanyInfoWrapperDTO responseDto = partnerBackBoneService.getCompanyInfo(loginInfo.getsBizRegiNo());
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + loginInfo.getsName());
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + loginInfo.getsJobTitle());
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + loginInfo.getsBirthYear());
		
		mv.setViewName("/partner/login/member_Edit.jsp");
		mv.addObject("loginInfo", loginInfo);
		mv.addObject("joinType", loginInfo.getsBizRegiNo().substring(3, 4));
		mv.addObject("result", responseDto.getCLMMA09());
		return mv;
	}
	/**
	 * ���¾�ü ȸ������
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/insuJoin")
	public ModelAndView insuJoin(final HttpSession session, final PartnerInsuJoinDTO reqDto) {

		final ModelAndView mv = new ModelAndView();
		Document partnerDoc = XMLUtil.getDocument("partner");	 
		mv.setViewName("/partner/partnerResult.jsp");
		
		reqDto.setsJoinDate(DateTime.now().toString("yyyyMMdd"));
		reqDto.setsJoinTime(DateTime.now().toString("HHssmm"));
		reqDto.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		reqDto.setsInputTime(DateTime.now().toString("HHssmm"));
		String strName = reqDto.getsName();
		try {
			strName = URLDecoder.decode( strName, "utf-8");
			reqDto.setsName(strName);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final boolean boolResult = partnerBackBoneService.insuJoin(reqDto);

		if(boolResult){
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "00");
		}else{
			XMLUtil.setString(partnerDoc, "sMsgCode"	, "01");
		}
		mv.addObject("partnerDoc", partnerDoc);
		return mv;
	}
	
	/**
	 * ȸ����������
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/memModify")
	public ModelAndView memModify(final HttpSession session, final PartnerInsuJoinDTO reqDto) {

		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/message.jsp");
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
			if(loginInfo == null){
				mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
				mv.addObject("returnURL", "index");
				return mv;
			}
		//ȸ����������	
		reqDto.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		reqDto.setsInputDate(DateTime.now().toString("HHssmm"));
		final boolean boolResult = partnerBackBoneService.insuModify(reqDto);

		if(boolResult){
			session.setAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.name(), null);
			mv.addObject("returnMSG", "ȸ���������� �Ϸ��Ͽ����ϴ�.");
			mv.addObject("returnURL", "index");
		}else{
			mv.addObject("returnMSG", "ȸ���������� �����Ͽ����ϴ�.");
			mv.addObject("returnURL", "/partner/memModifyInit.do");
		}
		return mv;
	}
	/**
	 * ȸ������Ż��
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/memberSecede")
	public ModelAndView memberSecede(final HttpSession session, final PartnerInsuJoinDTO reqDto) {

		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/message.jsp");
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
			if(loginInfo == null){
				mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
				mv.addObject("returnURL", "index");
				return mv;
			}
		//ȸ��Ż��
		reqDto.setsSecedeDate(DateTime.now().toString("yyyyMMdd"));
		reqDto.setsSecedeDate(DateTime.now().toString("HHssmm"));
		final boolean boolResult = partnerBackBoneService.insuMemberSecede(reqDto);

		if(boolResult){
			session.setAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.name(), null);
			mv.addObject("returnMSG", "ȸ��Ż�� �Ϸ��Ͽ����ϴ�.");
			mv.addObject("returnURL", "index");
		}else{
			mv.addObject("returnMSG", "ȸ��Ż�� �����Ͽ����ϴ�.");
			mv.addObject("returnURL", "/partner/memModifyInit.do");
		}
		return mv;
	}
	/**
	 * ���޺���ݳ��� - �ʱ�ȭ��
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/payInsuranceRepairInit")
	public ModelAndView payInsuranceRepairInit(final HttpSession session, final PartnerPayInsuWrapperDTO reqDto) {
		
		final ModelAndView mv = new ModelAndView();
		
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
		if(loginInfo == null){
			mv.setViewName("/partner/message.jsp");
			mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
			mv.addObject("returnURL", "index");
			return mv;
		}
		final DateTime dt = new DateTime();
		if(StringUtils.isBlank(reqDto.getSearchFrm())){
			reqDto.setSearchFrm(dt.plusMonths(-11).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(reqDto.getSearchTo())){
			reqDto.setSearchTo(dt.toString("yyyyMMdd"));
		}

		mv.setViewName("/partner/inquiry/payInsuranceRepair.jsp");
		mv.addObject("compInfo", loginInfo);
		mv.addObject("condition", reqDto);
		mv.addObject("rowCnt", "0");
		return mv;
	}
	/**
	 * ���޺���ݳ���
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/payInsuranceRepair")
	public ModelAndView payInsuranceRepair(final HttpSession session, final PartnerPayInsuWrapperDTO reqDto) {
		
		final ModelAndView mv = new ModelAndView();
		
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
		if(loginInfo == null){
			mv.setViewName("/partner/message.jsp");
			mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
			mv.addObject("returnURL", "index");
			return mv;
		}
		final DateTime dt = new DateTime();
		if(StringUtils.isBlank(reqDto.getSearchFrm())){
			reqDto.setSearchFrm(dt.plusMonths(-11).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(reqDto.getSearchTo())){
			reqDto.setSearchTo(dt.toString("yyyyMMdd"));
		}
		
		final PartnerPayInsuWrapperDTO response = partnerBackBoneService.getPayInsuList(reqDto);
		
		mv.setViewName("/partner/inquiry/payInsuranceRepair.jsp");
		mv.addObject("compInfo", loginInfo);
		mv.addObject("condition", reqDto);
		mv.addObject("clmce01", response.getClmce01());
		mv.addObject("clmc001", response.getClmc001());
		mv.addObject("rowCnt", response.getClmc001().size());

		return mv;
	}
	/**
	 * �԰��������� - �ʱ�ȭ��
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/inquiryInit")
	public ModelAndView inquiryInit(final HttpSession session, final PartnerInsuInquiryListDTO reqDto) {
		
		final ModelAndView mv = new ModelAndView();
		
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
		if(loginInfo == null){
			mv.setViewName("/partner/message.jsp");
			mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
			mv.addObject("returnURL", "index");
			return mv;
		}
		final DateTime dt = new DateTime();
		if(StringUtils.isBlank(reqDto.getsAcctRegiDateFrom())){
			reqDto.setsAcctRegiDateFrom(dt.plusMonths(-3).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(reqDto.getsAcctRegiDateTo())){
			reqDto.setsAcctRegiDateTo(dt.toString("yyyyMMdd"));
		}

		mv.setViewName("/partner/inquiry/inquiryWarehousing.jsp");
		mv.addObject("compInfo", loginInfo);
		mv.addObject("condition", reqDto);
		mv.addObject("rowCnt", "0");
		return mv;
	}
	/**
	 * �԰���������
	 * @param session
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/inquiryList")
	public ModelAndView inquiryList(final HttpSession session, final PartnerInsuInquiryListDTO reqDto) {
		
		final ModelAndView mv = new ModelAndView();
		
		//�α��� ���� üũ
		final PartnerLoginInfoVO loginInfo = (PartnerLoginInfoVO)session.getAttribute(SessionNameEnum.PARTNER_LOGIN_INFO.toString());
		if(loginInfo == null){
			mv.setViewName("/partner/message.jsp");
			mv.addObject("returnMSG", "�α��� ������ ����Ǿ����ϴ�.");
			mv.addObject("returnURL", "index");
			return mv;
		}
		final DateTime dt = new DateTime();
		if(StringUtils.isBlank(reqDto.getsAcctRegiDateFrom())){
			reqDto.setsAcctRegiDateFrom(dt.plusMonths(-3).toString("yyyyMMdd"));
		}
		if(StringUtils.isBlank(reqDto.getsAcctRegiDateTo())){
			reqDto.setsAcctRegiDateTo(dt.toString("yyyyMMdd"));
		}
		final List<PartnerInsuInquiryListDTO> response = partnerBackBoneService.inquiryList(reqDto);
		
		mv.setViewName("/partner/inquiry/inquiryWarehousing.jsp");
		mv.addObject("compInfo", loginInfo);
		mv.addObject("condition", reqDto);
		mv.addObject("result", response);
		mv.addObject("rowCnt", response.size());
		return mv;
	}
	/**
	 * ����� ��ȸ
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/popIncharge")
	public ModelAndView popIncharge(final HttpSession session, final String sStaffNo) {

		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/popup/popIncharge.jsp");
		final PartnerStaffInfoDTO responseDto = partnerBackBoneService.getStaffInfo(sStaffNo);
		mv.addObject("result", responseDto);
		return mv;
	}
	/**
	 * ǰ���������� �˾�
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/qualityPop")
	public ModelAndView qualityPop(final HttpSession session, final PartnerQualityDTO request){
		
		final DateTime dt = new DateTime();
		final String strCurrDate = dt.toString("yyyyMMdd");
		request.setsCurrDate(strCurrDate);
		request.setsReleaseDate(strCurrDate);

		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/popup/popQualityGuarantee.jsp");	
		mv.addObject("result",request);
		mv.addObject("logYn", "N");
		mv.addObject("rtnValue", "");
		return mv;
	}
	/**
	 * ǰ���������� ���
	 * @param servletRequest
	 * @param reqDto
	 * @return
	 */
	@RequestMapping(value = "/partner/printQualityLog")
	public ModelAndView printQualityLog(final HttpSession session, final PartnerQualityDTO request){
		final DateTime dt = new DateTime();
		final String strCurrDate = dt.toString("yyyyMMdd");
		request.setsCurrDate(strCurrDate);
		
		
		
		
		final String rtnValue = partnerBackBoneService.printQualityLog(request);
		
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("/partner/popup/popQualityGuarantee.jsp");	
		mv.addObject("result",request);
		mv.addObject("logYn", "Y");
		mv.addObject("rtnValue", rtnValue);
		return mv;
	}
}
