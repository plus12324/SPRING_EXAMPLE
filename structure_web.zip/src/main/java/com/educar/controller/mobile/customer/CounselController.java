/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.customer;

import javax.servlet.http.HttpServletRequest;

import kr.co.conch.validator.annotation.Validate;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.dto.web.VOCRegistrationDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.VOCWebTypeEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.VOCBackBoneService;

/**
 * �������� ����û
 * @author ��â��(slander)
 */
@Controller("counselControllerForCustomer")
@RequestMapping("/mobile/customer")
public class CounselController {

	/** logger */
	private final Logger logger = Logger.getLogger(this.getClass());

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** session service */
	@Autowired
	private SessionService sessionService;

	/** �����ǼҸ� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private VOCBackBoneService vocBackBoneService;

	/**
	 * �����ǰ ����û
	 * @param vocRegistrationDTO VOC �������� �Է� DTO
	 * @param servletRequest HttpServletRequest
	 */
	@RequestMapping("counselRequest")
	@Validate(merge = { "com.educar.dto.web.VOCRegistrationDTO", "sCellPhone1", "sCellPhone2", "sCellPhone3" }, register = CheckHTelNum.class)
	public void counselRequest(@Validate final VOCRegistrationDTO vocRegistrationDTO, final HttpServletRequest servletRequest) {
		vocRegistrationDTO.setsReplyType("1"); // �亯��� ��ȭ ����

		// �ֹε�Ϲ�ȣ ����. ���ǿ� �������� ������ null ����
		vocRegistrationDTO.setsCustNo(sessionService.getSSNFromSession(servletRequest.getSession()));
		// IP ����
		final String userIp = servletRequest.getRemoteAddr();
		vocRegistrationDTO.setsIP(userIp);
		// ����� : ���
		vocRegistrationDTO.setsWebType(VOCWebTypeEnum.COUNSEL.getCode());

		// ������ �Ҹ� �Ⱓ�� ȣ��
		if (!vocBackBoneService.insertVOC(vocRegistrationDTO, sessionService.getUserID(servletRequest.getSession()))) {
			logger.error("������ �Ҹ� �Ⱓ�� ȣ�⿡ �����Ͽ����ϴ�.");
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SaveFail)).forwardUrl(WebServletEnum.CUSTOMER_CENTER_INDEX_WEB)
					.responseCode(ResponseStatusEnum.FAIL_INSERT_DATA).build();
		}
	}
}
