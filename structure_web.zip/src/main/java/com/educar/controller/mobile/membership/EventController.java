/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.membership;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.EventDTO;
import com.educar.dto.web.EventWinnerDTO;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.web.EventService;

/**
 * ����ʼ��� - �̺�Ʈ
 * @author ��â��(slander)
 */
@Controller
@RequestMapping("/mobile/membership")
public class EventController {

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** �̺�Ʈ ���� */
	@Autowired
	private EventService eventService;

	/**
	 * ���� ���� �̺�Ʈ ��� ��ȸ
	 * @return ���� ���� �̺�Ʈ ���
	 */
	@RequestMapping("selectEventList")
	public List<EventDTO> selectEventList() {
		final EventDTO eventDTO = new EventDTO();
		// Ȩ������ �̺�Ʈ�� ��ȸ AC_CD 05000 ���� ����
		eventDTO.setAC_CD("05000");
		final List<EventDTO> eventDTOList = eventService.selectEventList(eventDTO);
		return eventDTOList;
	}

	/**
	 * �������� �̺�Ʈ �� ���� ��ȸ
	 * @param eventDTO �������� �̺�Ʈ DTO
	 * @return �������� �̺�Ʈ DTO
	 */
	@RequestMapping("selectEventView")
	public EventDTO selectEventView(EventDTO eventDTO) {
		eventDTO = eventService.selectEventView(eventDTO);
		if (eventDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SelectEmpty, "�������� �̺�Ʈ")).forwardUrl(WebServletEnum.HISTORY_BACK).build();
		}
		return eventDTO;
	}

	/**
	 * ���� �̺�Ʈ ��� ��ȸ
	 * @param eventDTO �������� �̺�Ʈ DTO
	 * @return ���� �̺�Ʈ ���
	 */
	@RequestMapping("selectEventPastList")
	public List<EventDTO> selectEventPastList(final EventDTO eventDTO) {
		final List<EventDTO> eventDTOList = eventService.selectPastEventList(eventDTO);
		return eventDTOList;
	}

	/**
	 * �̺�Ʈ ��÷�� ��ȸ
	 * @param eventWinnerDTO �̺�Ʈ ��÷�� Ȯ�� DTO
	 * @return �̺�Ʈ ��÷��
	 */
	@RequestMapping("selectEventWinner")
	public ModelMap selectEventWinner(final EventWinnerDTO eventWinnerDTO) {
		final String xssName = stripXSS(eventWinnerDTO.getName());
		final String xssHP = stripXSS(eventWinnerDTO.getHp());
		eventWinnerDTO.setName(xssName);
		eventWinnerDTO.setHp(xssHP);
		final EventWinnerDTO resultDTO = eventService.selectEventWinner(eventWinnerDTO);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("eventDTO", resultDTO);
		return modelMap;
	}
	
	public static String stripXSS(String value){
		if(value != null){
			value = value.replaceAll("\"", "");
			value = value.replaceAll("=", "");
			value = value.replaceAll("<", "");
			value = value.replaceAll(">", "");
			value = value.replaceAll("\\(", "");
			value = value.replaceAll("\\)", "");
			value = value.replaceAll("#", "");
			value = value.replaceAll("\\*/", "");
			value = value.replaceAll("\\*/", "");
			value = value.replaceAll("\\+", "");
			value = value.replaceAll(";", "");
			value = value.replaceAll("%", "");
		}
		return value;
	}
}
