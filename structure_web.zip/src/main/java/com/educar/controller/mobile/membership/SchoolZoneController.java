/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.membership;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.dto.web.MembershipPlusSchoolZoneDTO;
import com.educar.service.backbone.MembershipPlusBackBoneService;

/**
 * ��������ǰ����
 * @author ���ѳ�
 */
@Controller
@RequestMapping("/mobile/membership")
public class SchoolZoneController {

	/** ������÷��� back bone service **/
	@Autowired
	private MembershipPlusBackBoneService membershipPlusBackBoneService;

	/**
	 * <pre>
	 * ������ - �����Ӵ�ȸ ��ǰ��û
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "/applySchoolZoneGoods")
	public MembershipPlusSchoolZoneDTO applySchoolZoneGoods(final MembershipPlusSchoolZoneDTO reqDto) {

		final String result = membershipPlusBackBoneService.applySchoolZoneGoods(reqDto);
		reqDto.setsResult(result);
		return reqDto;
	}
	/**
	 * ������ - �����Ӵ�ȸ ��ǰ ��û���� ��ȸ
	 * @param request  GenericRestRequest<String> ������ȣ
	 * @return response Void
	 */
	@RequestMapping(value = "/applySchoolZoneGoodsList") 
	public List<MembershipPlusSchoolZoneDTO> applySchoolZoneGoodsList(final String strSchoolName) {
		
		final List<MembershipPlusSchoolZoneDTO> resultList = membershipPlusBackBoneService.selectSchoolZoneGoodsList(strSchoolName);
		
		for (final MembershipPlusSchoolZoneDTO dto : resultList) {
			dto.setsApplicantName(dto.getsApplicantName().substring(0, dto.getsApplicantName().length()-1) + '*');
		}
		
		return resultList;
	}
}
