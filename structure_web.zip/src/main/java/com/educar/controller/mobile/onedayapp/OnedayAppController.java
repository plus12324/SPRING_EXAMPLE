package com.educar.controller.mobile.onedayapp;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FileService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.vo.FileVO;
import com.educar.dao.OnedayAppDAO;
import com.educar.dto.mobile.OnedayApplyInfoOutputDTO;
import com.educar.dto.mobile.OnedayCalculationDTO;
import com.educar.dto.mobile.OnedayCalculationOnedayInfoDTO;
import com.educar.dto.mobile.OnedayCalculationOutputDTO;
import com.educar.dto.mobile.OnedayCouponCheckInputDTO;
import com.educar.dto.mobile.OnedayCouponCheckOutputDTO;
import com.educar.dto.mobile.OnedayCustomerInputDTO;
import com.educar.dto.mobile.OnedayCustomerOutputDTO;
import com.educar.dto.mobile.OnedayInsertPhotoDTO;
import com.educar.dto.mobile.OnedayMsgDTO;
import com.educar.dto.mobile.OnedayPhoneAdmitDTO;
import com.educar.dto.mobile.OnedayPhoneAdmitOutputDTO;
import com.educar.dto.mobile.OnedayReceiptInfoOutputDTO;
import com.educar.dto.mobile.OnedaySendEmailDTO;
import com.educar.dto.mobile.OnedaySessionDTO;
import com.educar.dto.mobile.OnedaySetPolicyDTO;
import com.educar.dto.mobile.OnedayStep2InputDTO;
import com.educar.dto.mobile.OnedayStep5InputDTO;
import com.educar.dto.mobile.OnedayStep7InputDTO;
import com.educar.dto.web.JehuCustDTO;
import com.educar.dto.web.NoticeDTO;
import com.educar.dto.web.PhoneCertificationInputDTO;
import com.educar.dto.web.login.MemberCheckDTO;
import com.educar.dto.web.ria.RIAStepOneSearchDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.LoginBackBoneService;
import com.educar.service.backbone.OnedayAppBackBoneService;
import com.educar.service.backbone.RIABackBoneService;
import com.educar.service.web.CertificationService;

/**
 * @author �Ž¿�
 *
 */
@Controller
@RequestMapping("/mobile/onedayapp")
public class OnedayAppController {
	
	@Autowired
	private FileService fileService;
	@Autowired
	private OnedayAppDAO dao;
	@Autowired
	private OnedayAppBackBoneService onedayAppBackBoneService;
	@Autowired
	private CertificationService certificationService;
	/** message service */
	@Autowired
	private MessageSourceService messageService;
	/** logger */
	private final Logger logger = Logger.getLogger(this.getClass());
	/** �α��� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private LoginBackBoneService loginServiceBackBone;
	
	//�������� ��ȣ
	private String sAgencyCode = "1078720972"; 

	/**
	 * �������ڵ�������  - ���� �˻�
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/oneDayCouponCheck")
	public ModelMap oneDayCouponCheck(final OnedayCouponCheckInputDTO inputDTO, HttpServletResponse response) throws Exception {
		
		ModelMap modelMap = new ModelMap();
		
		final String sCouponNumber = inputDTO.getsCouponNumber();
		
		String sAffiliatedConcern	= sCouponNumber.length() == 16 ? sCouponNumber.substring(0, 5) : "";
		String sEventDiv			= sCouponNumber.length() == 16 ? sCouponNumber.substring(5, 8) : "";
		String sCouponCode			= sCouponNumber.length() == 16 ? sCouponNumber.substring(8, 16) : "";
		
		inputDTO.setsHpNo(inputDTO.getsCellPhone1() + inputDTO.getsCellPhone2() + inputDTO.getsCellPhone3() );
		inputDTO.setsAffiliatedConcern(sAffiliatedConcern);
		inputDTO.setsCouponCode(sCouponCode);
		inputDTO.setsEventDiv(sEventDiv);
		//������ ���� ��뿩�� ��ȸ
		final OnedayCouponCheckOutputDTO result = dao.checkUseCoupon(inputDTO);
	
		// ��ġ�� �ܾ� Ȯ�� ���� start
		final String nBalAmtSum = onedayAppBackBoneService.getBalAmtByPolHolderID(sAgencyCode).trim();
		
		int iBalAmtSum = Integer.parseInt(nBalAmtSum);
		
		//���������� Y �̰ų� ��ġ�ܾ��� ����ݾ� ���� ������ msg return\
        if(iBalAmtSum < 10000 ){
        	modelMap.addAttribute("sMsgCode", "01");
    		modelMap.addAttribute("sMsg", "���� �������� ����� �Ұ��Ͽ��� 1566-3000 ���� �����Ͻñ� �ٶ��ϴ�.");  
    		return modelMap;
        }
        // ��ġ�� �ܾ� Ȯ�� ���� end
		
        // ���� ���󿩺� Ȯ��
        if(result == null ){
        	modelMap.addAttribute("sMsgCode", "01");
    		modelMap.addAttribute("sMsg", "������ȣ�� �ٽ� Ȯ���� �ּ���.");  
    		return modelMap;
        }
        
		// ���� ���� ���� Ȯ��
        if(StringUtils.isNotEmpty(result.getsCouponUseDate())){
        	modelMap.addAttribute("sMsgCode", "01");
    		modelMap.addAttribute("sMsg", "�Է��Ͻ� ������ �̹� ���� ��ȣ�̿��� Ȯ�� �ٶ��ϴ�.");  
    		return modelMap;
        }
        
        int icurrentDate = Integer.parseInt(DateTime.now().toString("yyyyMMdd"));
        // ���� ��ȿ���� Ȯ��
        if(StringUtils.isNotEmpty(result.getsCouponGiveDate() ) ){
        	
        	final DateTime dt = new DateTime(result.getsCouponGiveDate().substring(0, 4) + "-" + result.getsCouponGiveDate().substring(4, 6) + "-" + result.getsCouponGiveDate().substring(6));
        	int iCouponGiveDate  	= Integer.parseInt(result.getsCouponGiveDate() ); //��������
			int iCouponEndMm		= Integer.parseInt(result.getsCouponEndMm().trim() ); //��ȿ����
			int iCouponEndDate		= Integer.parseInt( dt.plusMonths(iCouponEndMm).toString("yyyyMMdd")   );
			
			logger.debug("sCouponGiveDate>"+result.getsCouponGiveDate());
			logger.debug("iCouponEndDate>"+iCouponEndDate);	
			logger.debug("iCouponEndDate>"+iCouponEndDate);
			
			// ��ȿ��뿩�� 
			if(!(iCouponGiveDate <= icurrentDate && icurrentDate <= iCouponEndDate)){
				modelMap.addAttribute("sMsgCode", "01");
	    		modelMap.addAttribute("sMsg", "�Է��Ͻ� ������ ��ȿ�Ⱓ�� ��� �� ��ȣ�̿��� Ȯ�� �ٶ��ϴ�.");  
	    		return modelMap;
			}
        }
        
        //�ֱ� 6���� �ȿ� ���� ����� ������ �ִ��� üũ 
  		int iCouponUseDateMax = 0;
  		if ( StringUtils.isNotEmpty(result.getsCouponUseDateMax()) ){
  			final DateTime dt = new DateTime(result.getsCouponUseDateMax().substring(0, 4) + "-" + result.getsCouponUseDateMax().substring(4, 6) + "-" + result.getsCouponUseDateMax().substring(6));
  			iCouponUseDateMax 	= "".equals(result.getsCouponUseDateMax())? 0 : Integer.parseInt( dt.plusMonths(6).toString("yyyyMMdd") );
  		}
  		if ( icurrentDate < iCouponUseDateMax ) {
			String sUseYear 	= result.getsCouponUseDateMax().length() == 8 ? result.getsCouponUseDateMax().substring(0,4) : "";
			String sUseMonth 	= result.getsCouponUseDateMax().length() == 8 ? result.getsCouponUseDateMax().substring(4,6) : "";
			String sUseDay 		= result.getsCouponUseDateMax().length() == 8 ? result.getsCouponUseDateMax().substring(6,8) : "";
			
			modelMap.addAttribute("sMsgCode", "01");
    		modelMap.addAttribute("sMsg", "�����̿��� 6���� ������ ��밡���Ͽ��� ���� ��Ź�ٶ��ϴ�. (" + sUseYear + "�� " + sUseMonth + "�� " + sUseDay + "�� �����̿�)");  
    		return modelMap;
		}
		
  		//���� ��� ����
		modelMap.addAttribute("sMsgCode", "00");
		modelMap.addAttribute("sMsg", "");  
		modelMap.addAttribute("sContactPath", result.getsContactPath() );  
		
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��5�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception                                                                                                                                                
	@RequestMapping("/oneDayStepGetUserInfo")
	public ModelMap oneDayStepGetUserInfo(final OnedayCalculationDTO inputDTO, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		//datacore �����Ű���庸�� ��ȣȭ
		logger.info("�ڡڡڡڡڡڡڡڡڡ�MIS Ű���� ��ȣȭ�� : " + inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2());
		if(inputDTO.getsInsrdID2().length() != 7 ){
			inputDTO.setsInsrdID2(certificationService.MISDecode(inputDTO.getsInsrdID2()));
		}
		logger.info("�ڡڡڡڡڡڡڡڡڡ�MIS Ű���� ��ȣȭ�� : " + inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2());
		final String sInsrdID = inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2();
		inputDTO.setsInsrdID(sInsrdID);
		
		//�ֹι�ȣ ��ȿ�� üũ
		if(!this.getSSNValid(sInsrdID) ){
			modelMap.addAttribute("result", Boolean.FALSE);
			modelMap.addAttribute("message", messageService.getMessage(ExceptionMessage.InvalidSSN) );  
			return modelMap;
		}
		final OnedayCustomerOutputDTO result = dao.getOneDayMemberInfo(sInsrdID);
		//TODO �ּ� �����ؼ� ���ǿ� ��������� ��
		
		//���� ���� ����
		session.setAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString(), inputDTO);
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute("sGender", inputDTO.getsInsrdID().substring(6, 7) );  //�����ʹ� �̰ɷ� �޳�
		
		//modelMap.addAttribute("sMsgCode", "00");
		//modelMap.addAttribute("sMsg", "");  
		return modelMap;
	}
	*/
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��5�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStepGetUserInfo")
	public ModelMap oneDayStepGetUserInfo(final OnedayCalculationDTO inputDTO, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		//datacore �����Ű���庸�� ��ȣȭ
		logger.info("�ڡڡڡڡڡڡڡڡڡ�MIS Ű���� ��ȣȭ�� : " + inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2());
		if(inputDTO.getsInsrdID2().length() != 7 ){
			inputDTO.setsInsrdID2(certificationService.MISDecode(inputDTO.getsInsrdID2()));
		}
		logger.info("�ڡڡڡڡڡڡڡڡڡ�MIS Ű���� ��ȣȭ�� : " + inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2());
		final String sInsrdID = inputDTO.getsInsrdID1() + inputDTO.getsInsrdID2();
		inputDTO.setsInsrdID(sInsrdID);
		
		//�ֹι�ȣ ��ȿ�� üũ
		if(!this.getSSNValid(sInsrdID) ){
			modelMap.addAttribute("result", Boolean.FALSE);
			modelMap.addAttribute("message", messageService.getMessage(ExceptionMessage.InvalidSSN) );  
			return modelMap;
		}
		// �Ⱓ�� ���� ȣ�� - ��������
		final MemberCheckDTO memberCheckDTO = loginServiceBackBone.selectCustInfo(sInsrdID);
		// �������� �����ؼ� ���ǿ� ����
		final OnedaySessionDTO sessionDTO = new OnedaySessionDTO();
		sessionDTO.setsInsrdID(inputDTO.getsInsrdID());
		sessionDTO.setsInsrdID1(inputDTO.getsInsrdID1());
		sessionDTO.setsInsrdID2(inputDTO.getsInsrdID2());
		sessionDTO.setsEmail(memberCheckDTO.getsEmail());
		sessionDTO.setsHomeZip(memberCheckDTO.getsHomeZip());
		sessionDTO.setsHomeAdrs1(memberCheckDTO.getsHomesAdrs1());
		sessionDTO.setsHomeAdrs2(memberCheckDTO.getsHomesAdrs2());
		sessionDTO.setsHomeAdrs3(memberCheckDTO.getsHomesAdrs3());
		sessionDTO.setsHomeAdd(memberCheckDTO.getsHomeAdrsAdd());
		
		//���� ���� ����
		session.setAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString(), sessionDTO);
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute("sInsrdID2", inputDTO.getsInsrdID2());  //�����ʹ� �̰ɷ� �޳�
		
		//modelMap.addAttribute("sMsgCode", "00");
		//modelMap.addAttribute("sMsg", "");  
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��2�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep2")
	public ModelMap oneDayStep2(final OnedayStep2InputDTO inputDTO, HttpServletRequest request, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		// ���� �ð�
		final DateTime dt = new DateTime();
		// �������� ������ �´�.
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		//������� �������� �Է� JehuCustDTO
		final JehuCustDTO jehuCustDTO = new JehuCustDTO();
		//��������϶� 
		if(inputDTO.getsCouponCheck().equalsIgnoreCase("Y") ){
			//����� �ڵ� ��ȸ
			inputDTO.setsAffiliatedConcern(inputDTO.getsCouponNumber().substring(0, 5));	 
			inputDTO.setsEventDiv(inputDTO.getsCouponNumber().substring(5, 8));
			inputDTO.setsContactPath(inputDTO.getsCouponNumber().substring(8, 16));
			final String sInfo = dao.getsAgencyCode(inputDTO);
			
			jehuCustDTO.setsInfo(sInfo);
			jehuCustDTO.setsCustNo(sessionDTO.getsInsrdID());
			jehuCustDTO.setsContactPath(inputDTO.getsContactPath());
			jehuCustDTO.setsEventDiv(inputDTO.getsEventDiv());
			jehuCustDTO.setsAffiliatedConcern(inputDTO.getsAffiliatedConcern());
			jehuCustDTO.setsName(inputDTO.getsInsrdName());
			
			//������ �������� �Է�(�ű�, ���� ����)
			loginServiceBackBone.putJehuCust(jehuCustDTO,sessionDTO.getsUserID() );
			
		}else{
		//���� ����� �ƴҶ�
			inputDTO.setsAffiliatedConcern("05001");	 
			inputDTO.setsEventDiv("");
			inputDTO.setsContactPath("");
		}
		
		//�������� ����
		// �ű԰����� ���
		if (!loginServiceBackBone.selectWebCustYN(sessionDTO.getsInsrdID())) {
			logger.info("�ڡڡڡڡڡڡڡڡڡڽű԰������ԡڡڡڡڡڡڡڡڡڡ�");
			//�ű԰�������
			onedayAppBackBoneService.contSaveCustomer(inputDTO,sessionDTO.getsUserID() );
			//�����ø����� ���� CUSAA44 ����
			onedayAppBackBoneService.agree0441(sessionDTO.getsInsrdID(), inputDTO.getsCUSAA04AgmYn() ,inputDTO.getsCUSAA41AgmYn(), sessionDTO.getsUserID() );
			//���߿���ȸ
			onedayAppBackBoneService.kidiContractRatio("1", "0", sessionDTO.getsInsrdID(), dt.minusMonths(15).toString("yyyyMMdd"), sessionDTO.getsUserID() );
		}else{
			logger.info("�ڡڡڡڡڡڡڡڡڡڱ����������ԡڡڡڡڡڡڡڡڡڡ�");
		}
		
		modelMap.addAttribute("result", Boolean.TRUE);
		
		return modelMap;
	}
	
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��4�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep4")
	public ModelMap oneDayStep4(final OnedayCalculationDTO inputDTO, HttpServletRequest request, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		
		//TODO E1 ������������ ���� �ϴºκ��� �־��µ� E1���� ������ �ȸ������
		
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		
		final OnedayCalculationOutputDTO result = onedayAppBackBoneService.contSaveSales(inputDTO, sessionDTO.getsUserID());
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute(result);
		
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �̸������� ��ȸ                                                                                                                             
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep5_1")
	public ModelMap oneDayStep5_1(HttpServletRequest request, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute(sessionDTO.getsEmail());
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��5�ܰ�(�������)                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep5")
	public ModelMap oneDayStep5(final OnedayStep5InputDTO inputDTO, HttpServletRequest request, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)request;  
		//�������� ������ �ͼ� inpuDTO�� �ּ����� �����Ѵ�. ������ ��ȭ�鿡�� ������ �Դµ� ���ȶ����� ���ǿ� �����ϰ� ���������� ����
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		inputDTO.setsEmail(sessionDTO.getsEmail());
		inputDTO.setsHomeZip(sessionDTO.getsHomeZip());
		inputDTO.setsHomeAdrs1(sessionDTO.getsHomeAdrs1());
		inputDTO.setsHomeAdrs2(sessionDTO.getsHomeAdrs2());
		inputDTO.setsHomeAdrs3(sessionDTO.getsHomeAdrs3());
		inputDTO.setsHomeAdd(sessionDTO.getsHomeAdd());
		
		final OnedayMsgDTO onedayMsgDTO = onedayAppBackBoneService.insertNewCustWeb(inputDTO, sessionDTO.getsUserID() );
		
		if( "00".equals(onedayMsgDTO.getsMsgCode()) ){
			//�������
			final OnedayInsertPhotoDTO onedayInsertPhotoDTO = new OnedayInsertPhotoDTO();

			//������ temp �� �����ϰ� fileID �����Ѵ�
			final List<String> fileID = new ArrayList<String>();
			String sPhotoNameList[] = {"carPhoto1", "carPhoto2", "carPhoto3", "carPhoto4"};
			for(int i=0; i < sPhotoNameList.length ; i++ ){      
				
				MultipartFile file = multipartRequest.getFile( sPhotoNameList[i] );
				FileVO fileVO = fileService.handleFileUploadPrepare(file, null);
				
				final byte[] bytes = file.getBytes();
				final String fileName = file.getOriginalFilename();
				
				fileVO.setName(fileName);
				fileVO = fileService.uploadTempFile(bytes, fileVO);
				
				System.out.println("fileID....................."+fileVO.getId());
				
				fileID.add(fileVO.getId());
	        }
			onedayInsertPhotoDTO.setFileID(fileID);
			
			final boolean result = onedayAppBackBoneService.insertOnedayPhoto(onedayInsertPhotoDTO, "2");
			
		}else{
			modelMap.addAttribute("sMsgCode", onedayMsgDTO.getsMsgCode());
			modelMap.addAttribute("sMsg", onedayMsgDTO.getsMsg());  
			return modelMap;
		}
			
		modelMap.addAttribute("result", Boolean.TRUE);
		
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��6�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep6")
	public ModelMap oneDayStep6(final OnedayCalculationDTO inputDTO, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		
		final OnedayApplyInfoOutputDTO result = onedayAppBackBoneService.getApplyInfobyApplyNo(inputDTO.getsApplyNo() );
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute(result);
		
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �߰������Է�_û��7�ܰ�                                                                                                                               
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayStep7")
	public ModelMap oneDayStep7(final OnedayStep7InputDTO inputDTO, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result", Boolean.TRUE);
		//���� ���尪 ������ �´�.
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		
		//�޴��� ���� ���μ���
		if("P".equals(inputDTO.getsPayType()) ){
			// �ߺ����� ����
			final OnedayMsgDTO onedayMsgDTO = onedayAppBackBoneService.validApplyBeforeAdmit(inputDTO.getsApplyNo(), inputDTO.getnReqAmt() );
			if( !"00".equals(onedayMsgDTO.getsMsgCode())){
				modelMap.addAttribute("sMsgCode", "01");
				modelMap.addAttribute("sMsg", onedayMsgDTO.getsMsg());  
				return modelMap;
			}
			
			//�޴��� ���� �Ķ���� ����
			final OnedayPhoneAdmitDTO onedayPhoneAdmitDTO = new OnedayPhoneAdmitDTO ();
			onedayPhoneAdmitDTO.setsApplyType(inputDTO.getsApplyNo().substring(0, 1) );
			onedayPhoneAdmitDTO.setsApplyYM(inputDTO.getsApplyNo().substring(1, 5));
			onedayPhoneAdmitDTO.setsApplySer(inputDTO.getsApplyNo().substring(5, 12));
			onedayPhoneAdmitDTO.setsCellDealNo(inputDTO.getsCellPhoneNo1() + inputDTO.getsCellPhoneNo2() +inputDTO.getsCellPhoneNo3() );
			onedayPhoneAdmitDTO.setsCellPhoneNo1(inputDTO.getsCellPhoneNo1());
			onedayPhoneAdmitDTO.setsCellPhoneNo2(inputDTO.getsCellPhoneNo2());
			onedayPhoneAdmitDTO.setsCellPhoneNo3(inputDTO.getsCellPhoneNo3());
			onedayPhoneAdmitDTO.setsCustCom(inputDTO.getsCustCom());
			onedayPhoneAdmitDTO.setsCellPhoneOwner(inputDTO.getsCellPhoneOwner());
			onedayPhoneAdmitDTO.setsCellPhoneOwnerID(inputDTO.getsCellPhoneOwnerID());
			onedayPhoneAdmitDTO.setnReqAmt(inputDTO.getnReqAmt());
			onedayPhoneAdmitDTO.setsReqAgntName(inputDTO.getsReqAgntName());
			onedayPhoneAdmitDTO.setsBeginDate(inputDTO.getsBeginDate());
			onedayPhoneAdmitDTO.setsEmail(inputDTO.getsEmail());
			onedayPhoneAdmitDTO.setsPhoneid(inputDTO.getsPhoneid());
			onedayPhoneAdmitDTO.setsCellDealNo(inputDTO.getsCellDealNo());
			//�������ڵ��� �޴�������
			final OnedayPhoneAdmitOutputDTO onedayPhoneAdmitOutputDTO =  onedayAppBackBoneService.requestPhoneAdmit(onedayPhoneAdmitDTO, sessionDTO.getsUserID());
			//�޴������� ������ ����Ȯ�� ó��
			if("0000".equals(onedayPhoneAdmitOutputDTO.getsRspCode()) ){
				//û����ȸ
				final OnedayApplyInfoOutputDTO result = onedayAppBackBoneService.getApplyInfobyApplyNo(inputDTO.getsApplyNo() );
				//����Ȯ�� ȣ���� ���� �Ķ���� ����
				final OnedaySetPolicyDTO onedaySetPolicyDTO = new OnedaySetPolicyDTO(); 
				onedaySetPolicyDTO.setsAutoConfirmReqNo(onedayPhoneAdmitOutputDTO.getsAdmitNo() );
				onedaySetPolicyDTO.setsApplyType(inputDTO.getsApplyNo().substring(0, 1));
				onedaySetPolicyDTO.setsApplyYM(inputDTO.getsApplyNo().substring(1, 5));
				onedaySetPolicyDTO.setsApplySer(inputDTO.getsApplyNo().substring(5, 12));
				onedaySetPolicyDTO.setsInsType(result.getApplyInfo().getsInsType());
				onedaySetPolicyDTO.setnRectPrem(inputDTO.getnReqAmt());
				onedaySetPolicyDTO.setsFromDate(inputDTO.getsBeginDate());
				onedaySetPolicyDTO.setsCollType(inputDTO.getsCollType() );
				onedaySetPolicyDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
				onedaySetPolicyDTO.setsInputTime(DateTime.now().toString("HHmmss"));
				onedaySetPolicyDTO.setsCellDealNo(onedayPhoneAdmitOutputDTO.getsCellDealNo());
				onedaySetPolicyDTO.setsCellPhone1(inputDTO.getsCellPhoneNo1());
				onedaySetPolicyDTO.setsCellPhone2(inputDTO.getsCellPhoneNo2());
				onedaySetPolicyDTO.setsCellPhone3(inputDTO.getsCellPhoneNo3());
				onedaySetPolicyDTO.setnCellPrem(inputDTO.getnReqAmt());
				onedaySetPolicyDTO.setnOutPrem("0");
				onedaySetPolicyDTO.setsRectType("01");
				onedaySetPolicyDTO.setnGiroPrem("0");
				//����Ȯ�� 
				final OnedayReceiptInfoOutputDTO onedayReceiptInfoOutputDTO = onedayAppBackBoneService.setPolicyReceiptInfo(onedaySetPolicyDTO, sessionDTO.getsUserID() );
				//����Ȯ�� ����
				if("1".equals(onedayReceiptInfoOutputDTO.getResult()) &&  onedayReceiptInfoOutputDTO.getsPolicyNo().length() == 12){
					modelMap.addAttribute("sMsgCode", "00");
					modelMap.addAttribute("sMsg", "����");  
					return modelMap;
				}else{
					//����Ȯ�� ����
					modelMap.addAttribute("sMsgCode", "01");
					modelMap.addAttribute("sMsg", "����ó�� �� ������ �߻��Ͽ����ϴ�.");  
					return modelMap;
				}
				
			}else{
			//�޴������� ���н�
				modelMap.addAttribute("sMsgCode", "01");
				modelMap.addAttribute("sMsg", "����ó�� �� ������ �߻��Ǿ����ϴ�.("+onedayPhoneAdmitOutputDTO.getsResultmsg() +")");  
				return modelMap;
			}
		
		}else if("V".equals(inputDTO.getsPayType())){
		//��������	
			// ��ġ�� �ܾ� Ȯ�� ���� start
			final String nBalAmtSum = onedayAppBackBoneService.getBalAmtByPolHolderID(sAgencyCode).trim();
			int iBalAmtSum = Integer.parseInt(nBalAmtSum);
			//���������� Y �̰ų� ��ġ�ܾ��� ����ݾ� ���� ������ msg return
	        if(iBalAmtSum < Integer.parseInt(inputDTO.getnCashPrem()) ){
	        	modelMap.addAttribute("sMsgCode", "01");
	    		modelMap.addAttribute("sMsg", "���� �������� ����� �Ұ��Ͽ��� 1566-3000 ���� �����Ͻñ� �ٶ��ϴ�.");  
	    		return modelMap;
	        }
	        // ��ġ�� �ܾ� Ȯ�� ���� end
			
	        //û����ȸ
			final OnedayApplyInfoOutputDTO result = onedayAppBackBoneService.getApplyInfobyApplyNo(inputDTO.getsApplyNo());
			//����Ȯ�� ȣ���� ���� �Ķ���� ����
			final OnedaySetPolicyDTO onedaySetPolicyDTO = new OnedaySetPolicyDTO(); 
			onedaySetPolicyDTO.setsApplyType(inputDTO.getsApplyNo().substring(0, 1));
			onedaySetPolicyDTO.setsApplyYM(inputDTO.getsApplyNo().substring(1, 5));
			onedaySetPolicyDTO.setsApplySer(inputDTO.getsApplyNo().substring(5, 12));
			onedaySetPolicyDTO.setsInsType(result.getApplyInfo().getsInsType());
			onedaySetPolicyDTO.setsFromDate(inputDTO.getsBeginDate());
			onedaySetPolicyDTO.setsCollType(inputDTO.getsCollType() );
			
			onedaySetPolicyDTO.setnRectPrem(inputDTO.getnCashPrem() );
			onedaySetPolicyDTO.setnCashPrem(inputDTO.getnCashPrem());
			onedaySetPolicyDTO.setsCouponNo(inputDTO.getsCouponNumber());
			onedaySetPolicyDTO.setsGroupNo(sAgencyCode);
			
			//����Ȯ�� 
			final OnedayReceiptInfoOutputDTO onedayReceiptInfoOutputDTO = onedayAppBackBoneService.setPolicyReceiptInfo(onedaySetPolicyDTO, sessionDTO.getsUserID() );
			//����Ȯ�� ����
			if("1".equals(onedayReceiptInfoOutputDTO.getResult()) &&  onedayReceiptInfoOutputDTO.getsPolicyNo().length() == 12){
				//������ ������� ���� �Ķ���� ����
				final OnedayCouponCheckInputDTO onedayCouponCheckInputDTO = new OnedayCouponCheckInputDTO();
				onedayCouponCheckInputDTO.setsHpNo(inputDTO.getsCellPhoneNo1() + inputDTO.getsCellPhoneNo2() + inputDTO.getsCellPhoneNo3() );
				onedayCouponCheckInputDTO.setsAffiliatedConcern(inputDTO.getsCouponNumber().substring(0, 5) );
				onedayCouponCheckInputDTO.setsEventDiv(inputDTO.getsCouponNumber().substring(5, 8));
				onedayCouponCheckInputDTO.setsCouponCode(inputDTO.getsCouponNumber().substring(8, 16));
				//������ ������� ���� ������Ʈ
				dao.updateCouponUseData(onedayCouponCheckInputDTO);
				
				modelMap.addAttribute("sMsgCode", "00");
				modelMap.addAttribute("sMsg", "����");  
				return modelMap;
			}else{
				//����Ȯ�� ����
				modelMap.addAttribute("sMsgCode", "01");
				modelMap.addAttribute("sMsg", "����ó�� �� ������ �߻��Ͽ����ϴ�.");  
				return modelMap;
			}
			
		}else if("C".equals(inputDTO.getsPayType())){
		//ī�����	
			
		}
		
		modelMap.addAttribute("result", Boolean.FALSE);
		return modelMap;
	}
	
	
	/**                                                                                                                                                                 
	 * �������ڵ������� �̸��� �ޱ�                                                                                                                       
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception  
	 * */                                                                                                                                              
	@RequestMapping("/oneDayReceiveEmail")
	public ModelMap oneDayReceiveEmail(final OnedaySendEmailDTO inputDTO, final HttpSession session) throws Exception {                                                    
		
		ModelMap modelMap = new ModelMap();
		
		final OnedaySessionDTO sessionDTO =(OnedaySessionDTO) session.getAttribute(SessionNameEnum.ONEDAY_CALCULATION_DRIVER_INFO.toString());
		final OnedayCalculationOnedayInfoDTO result = onedayAppBackBoneService.sendOneDayMail(inputDTO, sessionDTO.getsUserID() );
		
		modelMap.addAttribute("result", Boolean.TRUE);
		modelMap.addAttribute(result);
		
		return modelMap;
	}
	
	/**                                                                                                                                                                 
	 *  ������� �޴���������  ������� �޴��� ������ �ʿ��� Tradeid ���� ��ȸ�Ѵ�.                                                                                                   
	 *                                                                                                                                                                  
	 * @param request                                                                                                                                                   
	 * @param response                                                                                                                                                  
	 * @return                                                                                                                                                          
	 * @throws Exception                                                                                                                                                
	 */                              
	@RequestMapping("/getTradeID")
	public ModelMap getTradeID(final HttpSession session) throws Exception {                                                    
	
		ModelMap modelMap = new ModelMap();
		
		final String Tradeid = onedayAppBackBoneService.getTradeID();
		modelMap.addAttribute(Tradeid);
		return modelMap;                                                                                                                                  
	}
	
	
	/**
	 * �ֹι�ȣ ��ȿ��üũ
	 * @param ssn
	 * @return
	 */
	public boolean getSSNValid(final String ssn) {
		
		int tempInt[] = new int[13];
		
		int count=2;
		int sum=0;
		int compare=0;
		
		for(int i=0; i<ssn.length() ; i++){
			if(count > 9) count =2 ;
			tempInt[i] = Integer.parseInt(ssn.substring(i, i+1));
			sum += tempInt[i]*count;
			count++;
		}
		sum-=(tempInt[12]*6);
		compare = 11-(sum%11);
		
		if(compare<10&&compare==tempInt[12])	return true;
		else if(compare>=10){
			if((compare%10)==tempInt[12])	return true;
		}
		
		return false;		
	}
	
	/**
	 * ������� �տ� �⵵ �ٿ��ش�.
	 * @param ssn
	 * @return
	 */
	public String getYear(String ssn) {
		
		ssn = ssn.replace("-", "");
		// �ֹι�ȣ ���ڸ�
		final String ssn1 = ssn.substring(0, 6);
		// 2000�� ���� ����� ����
		final String sex = ssn.substring(6, 7);
		if ("1".equals(sex) || "2".equals(sex) || "5".equals(sex) || "6".equals(sex)) {
			return ("19" + ssn1);
		} else if ("3".equals(sex) || "4".equals(sex) ||"7".equals(sex) || "8".equals(sex)) {
			return ("20" + ssn1);
		}
		
		return "";
			
	}
	
	/**
	 * ���ܱ��� Ȯ��
	 * @param ssn
	 * @return 1: ������ 2: �ܱ���
	 */
	private String getInsrdType(final String sex) {
		if (StringUtils.contains("5678", sex)) {
			return "2";
		}
		return BigInteger.ONE.toString();
	}
	
	/**
	 * ����Ȯ��
	 * @param ssn
	 * @return 1: ���� 2: ����
	 */
	private String getGender(final String sex) {
		if (StringUtils.contains("1357", sex)) {
			return BigInteger.ONE.toString();
		}
		return BigInteger.ZERO.toString();
	}
		
}
