/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.myeducar;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.dto.web.InsuranceDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailOfPolca01InfoDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailSearchDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailSearchResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralCoverageSearchDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralCoverageSearchResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailOfContDetailList02DTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailOfContDetailList05DTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailWrapperDTO;
import com.educar.dto.web.myeducar.InsuranceLongTermDetailWrapperDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlOfLtiea00DtlDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlOfLtiea01PiboDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlResultDTO;
import com.educar.dto.web.myeducar.SelectLoanCsclsInqrSearchDTO;
import com.educar.dto.web.myeducar.SelectLoanCsclsInqrSearchResultDTO;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.InsuranceBackBoneService;

/**
 * ���̿���ī - �����ȸ
 * @author ��â��(slander)
 */
@Controller
@RequestMapping("/mobile/myeducar")
public class ContractSelectController {

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** Session service **/
	@Autowired
	private SessionService sessionService;

	/** ��� ��ȸ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;

	/**
	 * ������ Ȯ�� - ��ü ��� ��ȸ
	 * @param session HttpSession
	 * @return ���� ���� ��� ��ü ���
	 */
	@RequestMapping("contract/selectList")
	public List<InsuranceDTO> selectList(final HttpSession session) {
		// ���� ���� ���Ǹ� ��ȸ
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		return resultDTOList;
	}

	/**
	 * ������ Ȯ�� - �ڵ��� ���� �� ��ȸ
	 * @param sCrNo ����ȣ
	 * @return �ڵ��� ���� ��� ����ȸ ��� DTO
	 */
	@RequestMapping("contract/selectCarInfo")
	public InsuranceCarDetailSearchResultDTO selectCarInfo(final HttpSession session, final String sCrNo) {
		//20140731 ����������
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		final InsuranceCarDetailSearchDTO insuranceCarDetailSearchDTO = this.setInsuranceCarDetailSearchDTO(sCrNo);
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(sCrNo)){
				checkResult =false;
				insuranceCarDetailSearchDTO.setnEndorseNo(dto.getnLastEndorseNo());
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		final InsuranceCarDetailSearchResultDTO insuranceCarDetailSearchResultDTO = insuranceBackBoneService.getContractView(insuranceCarDetailSearchDTO);
		if (insuranceCarDetailSearchResultDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SelectEmpty)).build();
		}
		// ��� ����
		final InsuranceCarDetailOfPolca01InfoDTO insuranceCarDetailOfPolca01InfoDTO = insuranceCarDetailSearchResultDTO.getPolca01Info();
		// �ֹι�ȣ ****** ó��(010101-1******)
		insuranceCarDetailOfPolca01InfoDTO.setsInsrdID(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsInsrdID(), Boolean.TRUE));
		insuranceCarDetailOfPolca01InfoDTO.setsPolHolderID(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsPolHolderID(), Boolean.TRUE));
		// ����/ī���ȣ * ó��
		insuranceCarDetailOfPolca01InfoDTO.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsAcctNo()));

		// �Ǻ����� ����
		insuranceCarDetailSearchResultDTO.setInsrdInfo(null);
		// �Ǻ����� �߼��� �ּ� ����
		insuranceCarDetailSearchResultDTO.setInsrdSendAdrsInfo(null);

		return insuranceCarDetailSearchResultDTO;
	}

	/**
	 * ������ Ȯ�� - �Ϲ� ���� �� ��ȸ
	 * @param sCrNo ����ȣ
	 * @return �Ϲݺ��� �� ��ȸ Wrapper DTO
	 */
	@RequestMapping("contract/selectGeneralInfo")
	public InsuranceGeneralDetailWrapperDTO selectGeneralInfo(final HttpSession session, final String sCrNo) {
		//20140731 ����������
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(sCrNo)){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		// ����ȣ ���� üũ
		if (sCrNo.length() != 12) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).build();
		}
		final String sPolicyType = sCrNo.substring(0, 1);
		final String sPolicyKind = sCrNo.substring(1, 5);
		final String sPolicySer = sCrNo.substring(5);

		// �Ϲ� ���� ����ȸ
		final InsuranceGeneralDetailResultDTO insuranceGeneralDetailResultDTO = insuranceBackBoneService.selectDrvContDetailList(sPolicyType, sPolicyKind, sPolicySer);
		if (insuranceGeneralDetailResultDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SelectEmpty)).build();
		}

		// �Ϲ� ���� �㺸���� ��ȸ
		final InsuranceGeneralCoverageSearchDTO inputDTO = new InsuranceGeneralCoverageSearchDTO();
		inputDTO.setsBizTyp(sPolicyType);
		inputDTO.setsInsItmCod(sPolicyKind);
		inputDTO.setsSeq(sPolicySer);
		inputDTO.setnEndorseNo(insuranceGeneralDetailResultDTO.getContDetailList01().get(BigInteger.ZERO.intValue()).getnEndorseNo());
		inputDTO.setsInsCtrTpd(insuranceGeneralDetailResultDTO.getContDetailList01().get(BigInteger.ZERO.intValue()).getsInsCtrTpd());
		final List<InsuranceGeneralCoverageSearchResultDTO> coverageList = insuranceBackBoneService.selectCoverage(inputDTO);
		// �Ϲ� ���� ���Գ�����ȸ
		//final List<InsuranceGeneralDivPremResultDTO> paymentHistoryList = insuranceBackBoneService.selectDrvDivPremList(sPolicyType, sPolicyKind, sPolicySer);

		// �ֹι�ȣ ****** ó��(010101-1******)
		// �Ǻ�����
		final List<InsuranceGeneralDetailOfContDetailList02DTO> contDetailList02DTOList = insuranceGeneralDetailResultDTO.getContDetailList02();
		for (final InsuranceGeneralDetailOfContDetailList02DTO dto : contDetailList02DTOList) {
			dto.setsIsdCsmNum(SsnAsteriskConvert.getSsnAsterisk(dto.getsIsdCsmNum(), Boolean.TRUE));
		}
		// �����
		insuranceGeneralDetailResultDTO.getContDetailList03().setsPlrCsmNum(SsnAsteriskConvert.getSsnAsterisk(insuranceGeneralDetailResultDTO.getContDetailList03().getsPlrCsmNum(), Boolean.TRUE));
		final List<InsuranceGeneralDetailOfContDetailList05DTO> contDetailList05DTOList = insuranceGeneralDetailResultDTO.getContDetailList05();
		for (final InsuranceGeneralDetailOfContDetailList05DTO dto : contDetailList05DTOList) {
			// �ڵ���ü ����/ī���ȣ
			dto.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(dto.getsAcctNo()));
			// �ڵ���ü ������
			dto.setsDepositerID(SsnAsteriskConvert.getSsnAsterisk(dto.getsDepositerID(), Boolean.TRUE));
		}

		// �Ϲ� ���� ��ȸ ������ wrapperDTO�� ó��
		final InsuranceGeneralDetailWrapperDTO insuranceGeneralDetailWrapperDTO = new InsuranceGeneralDetailWrapperDTO();
		insuranceGeneralDetailWrapperDTO.setDetailResult(insuranceGeneralDetailResultDTO);
		insuranceGeneralDetailWrapperDTO.setCoverageList(coverageList);
		//insuranceGeneralDetailWrapperDTO.setPaymentHistoryList(paymentHistoryList);

		return insuranceGeneralDetailWrapperDTO;
	}

	/**
	 * ������ Ȯ�� - ��� ���� �� ��ȸ
	 * @param sCrNo ����ȣ
	 * @param nInrpsSeqno �Ǻ����� ����
	 * @return ��⺸�� �� ��ȸ Wrapper DTO
	 */
	@RequestMapping("contract/selectLongTermInfo")
	public InsuranceLongTermDetailWrapperDTO selectLongTermInfo(final HttpSession session, final String sCrNo, final String nInrpsSeqno) {
		//20140731 ����������
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(sCrNo)){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		// ����ȣ ���� üũ
		if (sCrNo.length() != 12) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).build();
		}
		// ��� ���� ����ȸ
		final SelectCntrDtlResultDTO cntrDtlResultDTO = insuranceBackBoneService.selectCntrDtl(sCrNo, nInrpsSeqno);
		if (cntrDtlResultDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SelectEmpty)).build();
		}

		// �ֹι�ȣ ****** ó��(010101-1******)
		// �����
		final SelectCntrDtlOfLtiea00DtlDTO cntrDtlDTO = cntrDtlResultDTO.getCNTR().get(BigInteger.ZERO.intValue());
		cntrDtlDTO.setsCrtorCd(SsnAsteriskConvert.getSsnAsterisk(cntrDtlDTO.getsCrtorCd(), Boolean.TRUE));
		// �Ǻ�����
		final List<SelectCntrDtlOfLtiea01PiboDTO> cntrPiboDTOList = cntrDtlResultDTO.getPIBO();
		for (final SelectCntrDtlOfLtiea01PiboDTO dto : cntrPiboDTOList) {
			dto.setsInrpsCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCd(), Boolean.TRUE));
		}
		// ���¹�ȣ �Ǵ� ī���ȣ * ó��
		cntrDtlDTO.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(cntrDtlDTO.getsAcctNo()));

		final String currentDate = DateTime.now().toString("yyyyMMdd");
		// ������ ������� ��ȸ
		final SelectLoanCsclsInqrSearchDTO loanSearchDTO = new SelectLoanCsclsInqrSearchDTO();
		loanSearchDTO.setsInqrTerm(BigInteger.ONE.toString());
		loanSearchDTO.setsCrNo(sCrNo);
		loanSearchDTO.setsDlOccrDate1(cntrDtlDTO.getsInsurStrtdate());
		loanSearchDTO.setsDlOccrDate2(currentDate);
		loanSearchDTO.setsYdate1(cntrDtlDTO.getsInsurStrtdate());
		loanSearchDTO.setsYdate2(currentDate);
		loanSearchDTO.setsTdate(currentDate);

		final List<SelectLoanCsclsInqrSearchResultDTO> loanResultList = insuranceBackBoneService.selectLoanCsclsInqr(loanSearchDTO);

		final InsuranceLongTermDetailWrapperDTO insuranceLongTermDetailWrapperDTO = new InsuranceLongTermDetailWrapperDTO();
		insuranceLongTermDetailWrapperDTO.setDetailResult(cntrDtlResultDTO);
		insuranceLongTermDetailWrapperDTO.setLoanResultList(loanResultList);

		return insuranceLongTermDetailWrapperDTO;
	}

	/**
	 * ���ǿ� �ִ� �ֹι�ȣ�� ��ȸ�ϰ� �ֹι�ȣ�� ������ �ֹι�ȣ ��ȯ�Ѵ�.<br>
	 * �ֹι�ȣ�� �������� ������ InvalidRequestException �� �߻��ϰ� �α��� �������� �̵��Ѵ�.
	 * @param session HttpSession
	 * @return �ֹι�ȣ
	 */
	private String getSSNFromSession(final HttpSession session) {
		final String ssn = sessionService.getSSNFromSession(session);
		// session �ֹι�ȣ�� ������ �α��� �������� �̵��Ѵ�.
		if (ssn == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyLoginInfo)).forwardUrl(WebServletEnum.LOGIN_COMMON).build();
		}
		return ssn;
	}

	/**
	 * 12�ڸ� ����ȣ�� InsuranceCarDetailSearchDTO �׸� ���� �����Ѵ�.
	 * @param sCrNo ����ȣ(12�ڸ�/ ��>L20111234567)
	 * @return �ڵ��� ���� ��� ����ȸ DTO
	 */
	private InsuranceCarDetailSearchDTO setInsuranceCarDetailSearchDTO(final String sCrNo) {
		if (sCrNo == null || sCrNo.length() != 12) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).build();
		}
		// ����ȣ �и�
		final InsuranceCarDetailSearchDTO dto = new InsuranceCarDetailSearchDTO();
		dto.setsPolicyType(sCrNo.substring(0, 1));
		dto.setsPolicyYM(sCrNo.substring(1, 5));
		dto.setsPolicySer(sCrNo.substring(5));
		return dto;
	}
}
