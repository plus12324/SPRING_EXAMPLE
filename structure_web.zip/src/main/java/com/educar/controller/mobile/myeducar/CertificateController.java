/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.myeducar;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.net.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.dto.web.InsuranceDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.InsuranceBackBoneService;

/**
 * ������
 * @author ��â��(slander)
 */
@Controller
@RequestMapping("/mobile/myeducar")
public class CertificateController {

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** Session service **/
	@Autowired
	private SessionService sessionService;

	/** ��� ��ȸ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;

	/**
	 * ������(��������,����������) ������ ��� ��ȸ
	 */
	@RequestMapping("contract/selectListForCertificate")
	public List<InsuranceDTO> selectListForCertificate(final HttpSession session, @RequestParam(value = "ssn", required = false) String requestSsn) {
		if (StringUtils.isNotBlank(requestSsn)) {
			requestSsn = new String(Base64.decodeBase64(requestSsn.getBytes()));
			if (requestSsn.length() != 13 || !StringUtils.isNumeric(requestSsn)) {
				requestSsn = null;
			}
		}
		final String ssn = StringUtils.defaultString(sessionService.getSSNFromSession(session), requestSsn);
		// ���� ���� ���Ǹ� ��ȸ
		if (StringUtils.isNotBlank(ssn)) {
			final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, ssn);
			return resultDTOList;
		} else {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.LOGIN_COMMON).responseCode(ResponseStatusEnum.NEED_LOGIN)
					.build();
		}
	}
}
