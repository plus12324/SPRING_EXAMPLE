/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dto.web.RecCampInfoDTO;
import com.educar.dto.web.RecCampCurrentStateInfoDTO;
import com.educar.dto.web.RecCampCurrentStateOutputDTO;
import com.educar.dto.web.RecCampDetailStateInfoDTO;
import com.educar.dto.web.RecCampDetailStateOutputDTO;
import com.educar.dto.web.RecCampPlateInfoOutputDTO;
import com.educar.dto.web.RecommandAgentInputDTO;
import com.educar.dto.web.ria.InstallmentPremiumResultDTO;
import com.educar.dto.web.RecCampInfoOutputDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.backbone.OnePageEventBackBoneService;
import com.educar.service.web.OnePageEventService;



/**
 * <pre>
 * ��������õķ����
 * <pre>
 * @author �Ž¿�
 *
 */
@Controller
@RequestMapping("/OnePageEvent")
public class OnePageEventController {
	
	/** ���������̺�Ʈ ����*/ 
	@Autowired
	private OnePageEventService onePageEventService;
	
	/** ���������̺�Ʈ �麻����*/ 
	@Autowired
	private OnePageEventBackBoneService onePageEventBackBoneService;
	
	/**
	 * <pre>
	 * ������ȣ ��ȸ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "searchRecCampsPlateNoInfo")
	public ModelMap searchRecCampsPlateNoInfo(final RecCampInfoDTO request) {
		
		final String sPlateNo = onePageEventService.searchRecCampsPlateNoInfo(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("sPlateNo", sPlateNo);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * ������ȣ ��� & ����
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "inputRecCampPlateNoInfo")
	public ModelMap inputRecCampPlateNoInfo(final RecCampInfoDTO request) {
		
		final String returnValue = onePageEventService.inputRecCampPlateNoInfo(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", returnValue);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * �Ұ����Է�
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "inputRecCampInfo")
	public ModelMap inputRecCampInfo(final RecCampInfoDTO request) {
		
		request.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		request.setsInputTime(DateTime.now().toString("HHssmm"));
		
		final String returnValue = onePageEventService.insertCUSAA38(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", returnValue);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * �Ұ�����ȸ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "recmdSearch")
	public List<RecCampInfoOutputDTO> recmdSearch(final RecCampInfoDTO request) {
		
		final List<RecCampInfoOutputDTO> result = onePageEventService.selectCUSAA38(request);
		return result;
	}
	
	/**
	 * <pre>
	 * �ߺ���õ���� Ȯ��
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "isExistsCUSAA38")
	public ModelMap isExistsCUSAA38(final RecCampInfoDTO request) {
		
		final String returnValue = onePageEventService.isExistsCUSAA38(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", returnValue);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * ����ȭ��û
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "inputRecCampRecall")
	public ModelMap InputRecCampRecall(final RecCampInfoDTO request) {
		
		final String returnValue = onePageEventService.inputRecCampRecall(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", returnValue);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * �����̰�����õķ���� ������������ ��ȸ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "selectMyPlateNoInfo")
	public ModelMap selectMyPlateNoInfo(final RecCampInfoDTO request) {
		
		final RecCampPlateInfoOutputDTO recCampPlateInfoOutputDTO = onePageEventService.selectMyPlateNoInfo(request);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", recCampPlateInfoOutputDTO);
		return modelMap;
	}
	
	/**
	 * <pre> 
	 * �����̰��� ��õķ���� ������Ȳ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "selectCompaginCurrentState")
	public List<RecCampCurrentStateOutputDTO> SelectCompaginCurrentState(final RecCampCurrentStateInfoDTO request) {
		
		final List<RecCampCurrentStateOutputDTO> result = onePageEventService.selectCurrentState(request);
		return result;
		
	}
	
	/**
	 * <pre>
	 * ������� ������������õ_����õ�ε��
	 * <pre>
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "insertAgentRecmdForMobile")
	public ModelMap insertAgentRecmdForMobile(final RecommandAgentInputDTO inputDTO) {
		
		final String Result = onePageEventBackBoneService.insertAgentRecmdForMobile(inputDTO);
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("returnValue", Result);
		return modelMap;
	}
	
	
	/**
	 * <pre>
	 * �����̰��� ��õķ���� ���ν�����ȸ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "selectCompaginDetailState")
	public ModelMap SelectCompaginDetailState(final RecCampDetailStateInfoDTO request) {
		
		final ModelMap modelMap = new ModelMap();
		boolean certi = true;
		
		if( "ed001".equals(request.getID()) && "ed001".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("01");	
		}else if( "ed002".equals(request.getID()) && "ed002".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("02");	
		}else if( "ed003".equals(request.getID()) && "ed003".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("03");	
		}else if( "ed004".equals(request.getID()) && "ed004".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("04");	
		}else if( "ed005".equals(request.getID()) && "ed005".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("05");	
		}else if( "ed006".equals(request.getID()) && "ed006".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("06");	
		}else if( "ed007".equals(request.getID()) && "ed007".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("07");	
		}else if( "ed008".equals(request.getID()) && "ed008".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("08");	
		}else if( "ed009".equals(request.getID()) && "ed009".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("09");	
		}else if( "ed010".equals(request.getID()) && "ed010".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("10");	
		}else if( "ed011".equals(request.getID()) && "ed011".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("11");	
		}else if( "ed012".equals(request.getID()) && "ed012".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("12");	 
		}else if( "ed013".equals(request.getID()) && "ed013".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("13");	
		}else if( "ed014".equals(request.getID()) && "ed014".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("14");	
		}else if( "ed015".equals(request.getID()) && "ed015".equals(request.getPassword()) ){
			request.setsRecmdAffiliation("15");	
		}else {
			certi = false;
		}
		
		if(certi == true){
			final List<RecCampDetailStateOutputDTO> resultList = onePageEventService.selectDetailState(request);
			modelMap.addAttribute("resultList", resultList);
		}
		
		modelMap.addAttribute("certi", certi);
		return modelMap; 
	}
	

	
}
