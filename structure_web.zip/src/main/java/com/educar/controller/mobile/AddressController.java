/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.educar.common.dto.CityCountyCodeDTO;
import com.educar.common.dto.NewRoadNameAddSearchDTO;
import com.educar.common.dto.PostCodeAddressSearchDTO;
import com.educar.common.dto.RoadNameAddressSearchDTO;
import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.dto.web.products.SchoolSearchResultDTO;
import com.educar.service.backbone.AdresssSearchBackBoneService;

/**
 * <pre>
 * <pre>
 * @author ������(Hyunsu Kim)
 *
 */
@Controller
@RequestMapping("/mobile/address")
public class AddressController {
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;

	/**
	 * <pre>
	 * ������ȣ ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectPostCodeAddress")
	public List<PostCodeAddressSearchDTO> selectPostCodeAddress(@RequestParam final String sTownName) {
		final List<PostCodeAddressSearchDTO> resultList = adresssSearchBackBoneService.postCodeAddressList(sTownName);
		return resultList;
	}

	/**
	 * <pre>
	 * ���θ��ּ� ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectRoadNameAddress")
	public List<RoadNameAddressSearchDTO> selectRoadNameAddress(@RequestParam final String sRoadName) {
		final List<RoadNameAddressSearchDTO> resultList = adresssSearchBackBoneService.roadNameAddressList(sRoadName);
		return resultList;
	}

	/**
	 * <pre>
	 * �б��� �˻�
	 * <pre>
	 * @param sSchoolName
	 * @return
	 */
	@RequestMapping("/selectSchool")
	public List<SchoolSearchResultDTO> selectSchool(@RequestParam final String sSchoolName) {
		final List<SchoolSearchResultDTO> resultList = adresssSearchBackBoneService.selectSchoolByNameForWeb(sSchoolName);
		return resultList;
	}
	
	/**
	 * (����)��/���� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<CityCodeDTO>
	 */
	@RequestMapping("/selectCmnCity")
	public List<CityCountyCodeDTO> selectCmnCity() {
		final List<CityCountyCodeDTO> resultList = adresssSearchBackBoneService.selectCityCode();
		return resultList;
	}

	/**
	 * (����)��/�� ��ȸ
	 * @param request ClaimCenterSearchDTO
	 * @return List<CountyCodeDTO> 
	 */
	@RequestMapping("/selectCmnGu")
	public List<CityCountyCodeDTO> selectCmnGu(@RequestParam final String selectCity) {
		final List<CityCountyCodeDTO> resultList = adresssSearchBackBoneService.selectGuCode(selectCity);
		return resultList;
	}
	/**
	 * <pre>
	 * new ���θ��ּ� ������ȣ �˻�
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectNewRoadNameAddr")
	public List<NewRoadNameAddSearchDTO> selectNewRoadNameAddress(NewRoadNameAddSearchDTO requestDto) {
		final List<NewRoadNameAddSearchDTO> resultList = adresssSearchBackBoneService.newRoadNameAddressList(requestDto);
		
		return resultList;
	}
	
	/**
	 * <pre>
	 * test ǥ���ּ� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectTestStatndardAddr")
	public StandardRoadAddrDTO selectTestStatndardAddr() {
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId("8000001");
		stndAddrDto.setVarPost("135860");
		stndAddrDto.setVarAllAddress("���� ������  �������,����SK���������,1313");
		stndAddrDto.setsAddrMgtNo("1168011800109530001027731");

		final StandardRoadAddrDTO resultList = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);
		
		return resultList;
	}
}
