/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.membership;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.web.BenefitsDivisionService;

/**
 * ���ð���
 * @author ��â��(slander)
 */
@Controller
@RequestMapping("/mobile/membership")
public class BenefitCalculatorController {

	/** message service */
	@Autowired
	private MessageSourceService message;

	/** ���� service */
	@Autowired
	private BenefitsDivisionService benefitsDivisionService;

	/**
	 * ���ð��� �ڵ� ��ȸ
	 */
	@RequestMapping("/selectBenefitCodeList")
	public ModelMap selectBenefitCodeList() {
		final String codeList = benefitsDivisionService.selectBenefitsDivisionAllList();
		// �ڵ� ��ȸ ����� ���� ��� ����
		if (StringUtils.isBlank(codeList)) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.MEMEBERSHIP_INDEX_WEB).build();
		}
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("codeList", codeList);
		return modelMap;
	}
}
