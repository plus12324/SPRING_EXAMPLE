/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;
import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dreamsecurity.e2e.MagicSE2;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.SessionService;
import com.educar.dao.EventDAO;
import com.educar.dto.jehu.JehuCustKeyDTO;
import com.educar.dto.web.CUSAA0441InfoDTO;
import com.educar.dto.web.DreamE2EDTO;
import com.educar.dto.web.Event10AnniversaryDTO;
import com.educar.dto.web.EventTaskDTO;
import com.educar.dto.web.PhoneCertificationInputDTO;
import com.educar.dto.web.ria.RIAStepOneSearchDTO;
import com.educar.dto.web.ria.WebAutoRenewInfoSearchDTO;
import com.educar.enumeration.DomainEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.ConsultationRequestBackBoneService;
import com.educar.service.backbone.LoginBackBoneService;
import com.educar.service.web.CertificationForSciService;
import com.educar.service.web.EventService;

/**
 * <pre>
 * <pre>
 * @author ������
 *
 */
@Controller
@RequestMapping("/mobile")
public class NewEventController {
	@Autowired
	private EventDAO newEventDAO;
	
	//------ �絿����--------
	/** ����Űä�� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private ConsultationRequestBackBoneService consultationRequestBackBoneService;
	@Autowired
	private SessionService sessionService;
	/** SCI (����ſ���) �ſ�ī��, �޴��� �������� ���� **/
	@Autowired
	private CertificationForSciService certificationForSciService;
	/** ����/��ǰ �����̿� ���� ȣ�� ���� **/
	@Autowired
	private LoginBackBoneService loginBackBoneService;
	/** �̺�Ʈ ���� */
	@Autowired
	private EventService eventService;
	private Logger logger = Logger.getLogger(getClass());
	/**
	 * <pre>
	 * �̺�Ʈ ����
	 * <pre>
	 * @param request
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("insertsnsevent")
	public void insertSnsEvent(HttpServletResponse res, EventTaskDTO dto) throws IOException {
		String CallbackMsg = "�̺�Ʈ ������ �Ϸ�Ǿ����ϴ�.";
		
		try{
			String toDay = DateTime.now().toString("yyyyMMdd");
			int mDate = Integer.parseInt(toDay);
			EventTaskDTO tmpDateInfo = newEventDAO.selectEventDate(dto);		
			
			//logger.info(tmpDateInfo.getsStartDate().toString());
			//logger.info(tmpDateInfo.getsEndDate().toString());
			
			if(mDate < Integer.parseInt(tmpDateInfo.getsStartDate().toString())
			|| mDate > Integer.parseInt(tmpDateInfo.getsEndDate().toString())){
				CallbackMsg = "�̺�Ʈ �Ⱓ�� �ƴմϴ�.";
			}
			else{
				//dto ����
				int cnt = newEventDAO.selectEventDupcheck(dto);
				if(cnt > 0){
					CallbackMsg = "�̹� �̺�Ʈ�� �����ϼ̽��ϴ�.";
				}
				else{
					dto.setsInputDate(toDay);
					dto.setsInputTime(DateTime.now().toString("HHssmm"));
					newEventDAO.insertWEBBB37(dto);
				}
			}
		}
		catch(Exception e){
			CallbackMsg = "�̺�Ʈ ������ �����Ͽ����ϴ�.";
		}
		finally{
			//Callback msg
			res.setCharacterEncoding("euc-kr");
			res.setContentType("text/html; charset=euc-kr");
			res.setHeader("pragma", "no-cache");
			res.setHeader("cache-control", "no-cache");
			res.setHeader("expires", "0");
			PrintWriter out = res.getWriter();
			out.println(CallbackMsg);
			out.flush();
			out.close();
		}
	}
	
	//�̺�Ʈ �����̷�Ʈó��___
	@RequestMapping(value = "/snsEvent")
	public void goEvent(final HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter out = res.getWriter();
		String no  	    = req.getParameter("no").toString();
		String YYYY 		= DateTime.now().toString("yyyy");
		String url      = "/static/mobile/newEvent/"+ YYYY +"/snsEvent"+ no +".html";
				
		out.println("<script type='text/javascript'>location.href='"+ url +"';</script>");
		out.flush();
		out.close();
	}
	
	/**
	 * �絿���ݿ� ���� ����Ű ��ȸ 
	 * @return
	 */
	@RequestMapping(value = "/getCustKey")
	public ModelMap getCustKey(final HttpServletRequest servletRequest, @NotNull final JehuCustKeyDTO request) {
		
		request.setsUserID(sessionService.getUserID(servletRequest.getSession()));
		request.setsProductType("1");
		final String jehuCustKey = consultationRequestBackBoneService.getJehuCustKey(request);
		request.setsCustNo(jehuCustKey);
		servletRequest.getSession().setAttribute(SessionNameEnum.RE_AGREE_INFO.toString(), request);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result", Boolean.TRUE);
		return modelMap;
	}
	/**
	 * �絿���ݿ� ���� ����Ű ��ȸ 
	 * @return
	 */
	@RequestMapping(value = "/getReAgreeSessionInfo")
	public ModelMap getReAgreeSessionInfo(final HttpSession session) {
		final JehuCustKeyDTO sessionInfo = (JehuCustKeyDTO) session.getAttribute(SessionNameEnum.RE_AGREE_INFO.toString());
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result", sessionInfo);
		return modelMap;
	}
	/**
	 *
	 * �絿���� - �������� SMS ��ȣ �ޱ� ȣ�� 
	 * @throws Exception 
	 * 
	 */
	@RequestMapping("/newEvent/phoneCertification")
	public ModelMap phoneCertification(final HttpSession session,  final PhoneCertificationInputDTO request) throws Exception {

		request.setsCellPhone(request.getsPhone() );
		request.setsInsrdName(request.getsCreName() );
		
		logger.debug("[N1403-00109]�������� ���а� ����  " + request.getsDiv());
		// �ֹι�ȣ ��� �޴��� ��������
		final PhoneCertificationInputDTO outputDTO;   // = certificationService.oknameBirthDayCertification(request);
		logger.debug("ssn >>>>" + request.getsCustNo());
		if(StringUtil.isNullOrEmpty(request.getsCertMsg())){	
			logger.debug("�޴��� �������� - ���� ����");
			outputDTO = certificationForSciService.sciCertificationForPhone(request);
		}else{
			logger.debug("�޴��� �������� - ������ >> " + request.getsCertMsg());
			outputDTO = certificationForSciService.sciCertificationForPhoneRetry(request);
		}
		if (!outputDTO.isSuccess()) {
			// �ſ�ī�� ���� �����ϰ�� ���� �޼��� ����
			throw new InvalidRequestException.Builder(outputDTO.getRetmsg()).build();
		} else {
			final ModelMap modelMap = new ModelMap();
			modelMap.addAttribute("result", outputDTO);
			return modelMap;
		}
		
	}
	/**
	 *  
	 *  �絿���� - �������� SMS ���� ��� Ȯ��
	 */
	@RequestMapping("/newEvent/phoneCertificationCheck")
	public ModelMap phoneCertificationCheck(final HttpSession session, @Validate final PhoneCertificationInputDTO request) {
		
		request.setsCellPhone(request.getsPhone() );
		request.setsInsrdName(request.getsCreName() );
		request.setsCusaa48AgrYn("Y");
		logger.debug("[N1403-00109]�������� ���а� ����  " + request.getsDiv());
		// �ֹι�ȣ ��� �޴��� ��������
		final PhoneCertificationInputDTO resultDTO = certificationForSciService.sciCertificationForPhoneCheck(request);
		
		//��ǰ�Ұ� ����
		final CUSAA0441InfoDTO cusAA0441InfoDTO = new CUSAA0441InfoDTO();
			
		cusAA0441InfoDTO.setsCustNo(request.getsCustNo());
		cusAA0441InfoDTO.setsCUSAA04AgmYn(DomainEnum.YES.getCode());

		cusAA0441InfoDTO.setsCUSAA41AgmYn("X");
		// �������(Call ��ǰ�Ұ� �����̿� �� ��������)
		loginBackBoneService.setCUSAA0441Info(cusAA0441InfoDTO, sessionService.getUserID(session));
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result",  Boolean.TRUE);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * ģ����õ �̺�Ʈ URL ����
	 * <pre>
	 * @param Event10AnniversaryDTO
	 * @throws Exception 
	*/ 
	@RequestMapping("/insert10thAnniversary")
	public ModelMap getStepPreInfo(final HttpSession session, final Event10AnniversaryDTO dto) throws Exception {
	
		
		final Calendar cal = Calendar.getInstance();
		final SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmm");//mmssSSSSSS
		final String sKey = df.format(cal.getTime());
		
		final String sUserID = sessionService.getUserID(session);
		logger.debug(">>>>>>>>>>>>>>>"+dto.getsEventDiv()+"<<<");
		dto.setsCreID(sUserID);
		dto.setsCreDate(DateTime.now().toString("yyyyMMdd"));
		dto.setsCreTime(DateTime.now().toString("HHssmm"));
		
		final StringBuffer bfStr = new StringBuffer();
		final Random rdStr = new Random();
		
		final String chars[] = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,1,2,3,4,5,6,7,8,9,0".split(",");
		bfStr.append(sKey);
		for(int i=0; i<6; i++){
			bfStr.append(chars[rdStr.nextInt(chars.length)]);
		}
		dto.setsRecommendUrl(bfStr.toString());
		//WEBDD54 insert
		final Event10AnniversaryDTO chkDto = eventService.selectURLCheck(dto);
		if(chkDto == null){
			eventService.insertWEBDD54(dto);
		}else{
			dto.setsRecommendUrl(chkDto.getsRecommendUrl());
		}
		
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result", dto);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * ģ����õ �Ұ��� ģ�� ��� ��ȸ
	 * <pre>
	 * @param Event10AnniversaryDTO
	 * @throws Exception 
	 */
	@RequestMapping("/select10thList")
	public ModelMap insert10thAnniversaryList(final HttpSession session, final Event10AnniversaryDTO dto) throws Exception {
	
		//WEBDD55 select
		final List<Event10AnniversaryDTO> dtoList = eventService.select10thList(dto);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("result", dtoList);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * 11�ֳ� �̺�Ʈ ����� insert
	 * <pre>
	 * @param EventTaskDTO
	 * @throws Exception
	 */
	@RequestMapping("/insert11thEvent")
	public ModelMap insert11thEvent(final HttpSession session, final EventTaskDTO eventTaskDTO) throws Exception {
	
		final ModelMap modelMap = new ModelMap();
		//���𿩺�üũ
		int cnt = newEventDAO.selectEventDupcheck(eventTaskDTO);
		if(cnt > 0){
			modelMap.addAttribute("result", Boolean.FALSE);
		}else{
			eventTaskDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
			eventTaskDTO.setsInputTime(DateTime.now().toString("HHssmm"));
			newEventDAO.insertWEBBB37(eventTaskDTO);
			modelMap.addAttribute("result", Boolean.TRUE);
		}
		return modelMap;
	}
}
