/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.myeducar;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.dto.web.InsuranceDTO;
import com.educar.dto.web.myeducar.CustomerContInfoTelInfoDTO;
import com.educar.dto.web.products.GeneralPrintProcessDTO;
import com.educar.dto.web.products.LongPrintProcessDTO;
import com.educar.dto.web.ria.CarSendCertificateDTO;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.InsuranceBackBoneService;
import com.educar.service.backbone.InsuranceProductsBackBoneService;
import com.educar.service.backbone.MyEducarServiceBackBoneService;
import com.educar.service.backbone.RIABackBoneService;

/**
 * <pre>
 * <pre>
 * @author
 */
@Controller
@RequestMapping("/mobile/myeducar")
public class ReportController {
	/** message service */
	@Autowired 
	private MessageSourceService messageService; 
	@Autowired
	private SessionService sessionService;
	@Autowired
	private InsuranceBackBoneService insuranceService;
	@Autowired
	private InsuranceProductsBackBoneService insuranceProductsBackBoneService;
	@Autowired
	private RIABackBoneService riaBackBoneService;
	@Autowired
	private MyEducarServiceBackBoneService myEducarServiceBackBoneService;
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;
	private Logger logger = Logger.getLogger(getClass());
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("report/list")
	public List<InsuranceDTO> insuranceContractList(final HttpSession session) {
		final List<InsuranceDTO> resultList = insuranceService.insuranceList(Boolean.TRUE, sessionService.getSSNFromSession(session));
		return resultList;
	}

	/**
	 * <pre>
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("report/selectCustPopInfo")
	public ModelMap selectCustPopInfo(final HttpSession session) {
		final CustomerContInfoTelInfoDTO telInfo = myEducarServiceBackBoneService.seletCustPopInfo(sessionService.getSSNFromSession(session)).getTelInfo();
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("sEmail", telInfo.getsEmail1());
		modelMap.addAttribute("sFax", telInfo.getsFax1() + telInfo.getsFax2() + telInfo.getsFax3());
		return modelMap;
	}

	/**
	 * <pre>
	 * <pre>
	 * @param session HttpSession
	 * @return
	 */
	@RequestMapping("report/sendCarInsSecurityFax")
	public ModelMap sendCarInsSecurityFax(final HttpSession session, final CarSendCertificateDTO carSendCertificateDTO) {
		
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(carSendCertificateDTO.getsPolicyNo() )){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		carSendCertificateDTO.setsCustNm(sessionService.getSNameFromSession(session));
		carSendCertificateDTO.setsPolHolderID(sessionService.getSSNFromSession(session));
		final ModelMap modelMap = new ModelMap();
		return modelMap.addAttribute(riaBackBoneService.sendCertificate(carSendCertificateDTO));
	}

	/**
	 * 
	 * @param generalPrintProcessDTO
	 * @return boolean
	 */
	@RequestMapping("report/sendGeneralPrintProcess")
	public ModelMap sendGeneralPrintProcess(final HttpSession session, final GeneralPrintProcessDTO generalPrintProcessDTO) {
		
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(generalPrintProcessDTO.getsBizCode() )){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		
		insuranceProductsBackBoneService.generalPrintProcess(generalPrintProcessDTO);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute(Boolean.TRUE);
		return modelMap;
	}

	/**
	 * @param longPrintProcessDTO
	 * @return boolean
	 */
	@RequestMapping("report/sendLongPrintProcess")
	public ModelMap sendLongPrintProcess(final HttpSession session, final LongPrintProcessDTO longPrintProcessDTO) {
		
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, this.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceDTO dto : resultDTOList){
			if(dto.getsCrNo().equals(longPrintProcessDTO.getsBizCode() )){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		insuranceProductsBackBoneService.longPrintProcess(longPrintProcessDTO, sessionService.getUserID(session));
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute(Boolean.TRUE);
		return modelMap;
	}
	
	/**
	 * @param session HttpSession
	 */
	private String getSSNFromSession(final HttpSession session) {
		final String ssn = sessionService.getSSNFromSession(session);
		if (ssn == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyLoginInfo)).forwardUrl(WebServletEnum.LOGIN_COMMON).build();
		}
		return ssn;
	}
}
