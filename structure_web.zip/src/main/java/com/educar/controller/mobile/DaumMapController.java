/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ���� ���� API Ȱ��
 * @author ��â��(slander)
 */
@Controller
@RequestMapping("/mobile")
public class DaumMapController {

	/** DAUM map API URL */
	@Value("#{systemProperties['daum.map.url']}")
	private String apiURL;

	/** DAUM map API Key */
	@Value("#{systemProperties['daum.map.key']}")
	private String apiKey;

	/**
	 * DAUM ���� API ����ϱ� ���� DAUM ��ü�� ȣ���� �ڹٽ�ũ��Ʈ URL ������ ��ȸ�Ѵ�.
	 * @return DAUM ��ü, �ڹٽ�ũ��Ʈ URL
	 * @throws IOException
	 */
	@RequestMapping("selectDaumMapAPI")
	public ModelMap selectDaumMapAPI() throws IOException {
		final ModelMap modelMap = new ModelMap();

		final URL daumURL = new URL(apiURL + "?apikey=" + apiKey);
		final URLConnection urlConnection = daumURL.openConnection();
		final HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
		httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		httpURLConnection.connect();

		final InputStream inputStream = httpURLConnection.getInputStream();
		final BufferedReader input = new BufferedReader(new InputStreamReader(inputStream));
		String line = "", daumJS = "", mapsJS = "";
		while ((line = input.readLine()) != null) {
			if (line.indexOf("document.write") == 0) {
				// UI ȣ���� �ڹٽ�ũ��Ʈ URL
				mapsJS = StringUtils.substringBetween(line, "src=", ".js");
				mapsJS = StringUtils.substringAfter(mapsJS, "//");
				mapsJS = mapsJS + ".js";
			} else if (line.indexOf("daum") >= 0) {
				// eval() ó���� DAUM ��ü
				daumJS = StringUtils.substringAfter(line, "daum:");
				daumJS = StringUtils.substringBeforeLast(daumJS, "})");
				daumJS = "daum=" + daumJS;
			}
			if (!"".equals(mapsJS) && !"".equals(daumJS)) {
				break;
			}
		}
		modelMap.addAttribute("daumJS", daumJS);
		modelMap.addAttribute("mapsJS", mapsJS);

		return modelMap;
	}
}
