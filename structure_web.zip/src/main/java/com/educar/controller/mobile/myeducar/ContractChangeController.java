/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.mobile.myeducar;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import jeus.util.StringUtil;

import kr.co.conch.validator.annotation.Validate;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.common.vo.PaymentVO;
import com.educar.dto.web.InsuranceDTO;
import com.educar.dto.web.endorse.CarEndorseDetailDTO;
import com.educar.dto.web.endorse.EditDriverScopeRequestDTO;
import com.educar.dto.web.endorse.EditDriverScopeResponseDTO;
import com.educar.dto.web.endorse.EndorseCarPlateNoDTO;
import com.educar.dto.web.endorse.EndorseCarPlateNoResponseDTO;
import com.educar.dto.web.endorse.EndorseConfirmDTO;
import com.educar.dto.web.endorse.EndorseDrivingScopeDTO;
import com.educar.dto.web.myeducar.CustContInfoListDTO;
import com.educar.dto.web.myeducar.CustPopInfoWrapperDTO;
import com.educar.dto.web.myeducar.CustomerContInfoSendAdrsDTO;
import com.educar.dto.web.myeducar.CustomerContInfoWrapperDTO;
import com.educar.dto.web.myeducar.InsuranceCarResultDTO;
import com.educar.dto.web.ria.CarSendCertificateDTO;
import com.educar.enumeration.InsuranceProductEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SendCertificateDMCodeEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.EndorseBackBoneService;
import com.educar.service.backbone.InsuranceBackBoneService;
import com.educar.service.backbone.MyEducarServiceBackBoneService;
import com.educar.service.backbone.RIABackBoneService;
import com.educar.service.web.MyPageService;

/**
 * <pre>
 * <pre>
 * @author ������(HyunSu Kim)
 *
 */
@Controller
@RequestMapping("/mobile/myeducar")
public class ContractChangeController {
	/** message service */
	@Autowired
	private MessageSourceService messageService;
	/** Session service **/
	@Autowired
	private SessionService sessionService;
	/** ���̿���ī  - �����ȸ/����, ����/ȯ�޳���, ���� **/
	@Autowired
	private MyEducarServiceBackBoneService myEducarServiceBackBoneService;
	/** ��� ��ȸ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;
	/** �ڵ��������ຯ��(�輭) �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private EndorseBackBoneService endorseBackBoneService;
	/** ����� ����(RIA) ���� **/
	@Autowired
	private RIABackBoneService riaBackBoneService;
	/** ��ຯ�泻�� sms/email �߼� **/
	@Autowired
	private MyPageService myPageService;
	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	/**
	 * <pre>
	 * ���������� ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/selectCustPopInfo")
	public CustPopInfoWrapperDTO selectCustPopInfo(final HttpSession session) {
		final CustPopInfoWrapperDTO resultList = myEducarServiceBackBoneService.seletCustPopInfo(sessionService.getSSNFromSession(session));
		// ��������
		resultList.getCustInfo().setsCustNo(SsnAsteriskConvert.getSsnAsterisk(resultList.getCustInfo().getsCustNo(), Boolean.TRUE));
		resultList.getTelInfo().setsHomeTel3("****");
		resultList.getTelInfo().setsCellPhone3("****");
		resultList.getTelInfo().setsEtcTel3("****");
		resultList.getTelInfo().setsOfficeTel3("****");
		if(!StringUtil.isNullOrEmpty(resultList.getTelInfo().getsEmail1())){
			resultList.getTelInfo().setsEmail1("***"+ resultList.getTelInfo().getsEmail1().substring(3, resultList.getTelInfo().getsEmail1().length()));
		}
		resultList.getCustInfo().setsCrtorName(sessionService.getSNameFromSession(session));
		return resultList;
	}

	/**
	 * <pre>
	 * ���������� ����
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/setCustomerContChange")
	@Validate(merge = { "com.educar.dto.web.myeducar.CustomerContInfoTelInfoDTO", "sCellPhone1", "sCellPhone2", "sCellPhone3" }, register = CheckHTelNum.class)
	public ModelMap setCustContChange(final HttpSession session, @RequestParam("contractNumber[]") final List<String> contractNumber, @Validate final CustomerContInfoWrapperDTO changedInfo, final String sAdrsType) {
		
		//20140731 ���ǿ��� ��� ����Ʈ ������ �ͼ� ������ ������ ����� ���Ͽ� ����� �����ϱ� ������ �ڵ� ������ üũ�� �� 
		
		// ������� ���� dto
		final CustomerContInfoWrapperDTO customerContInfoWrapperDTO = changedInfo;
		final String sCustNo = sessionService.getSSNFromSession(session);
		final String sUserID = sessionService.getUserID(session);
		customerContInfoWrapperDTO.setPolicyInfo(new ArrayList<CustContInfoListDTO>());
		// �Ѻ��� ����Ʈ ��ȸ
		final List<InsuranceDTO> resultDTOList = insuranceBackBoneService.insuranceList(Boolean.TRUE, sCustNo);
		// �� ���踮��Ʈ���� ������ ����Ʈ�� �߰�
		for (final InsuranceDTO resultDTO : resultDTOList) {
			//for (final String sCrNo : aaa) 
			if (contractNumber.contains(resultDTO.getsCrNo())) {
				/** ������� DTO**/
				final CustContInfoListDTO custContInfoListDTO = new CustContInfoListDTO();
				/**	����ȣ	**/
				custContInfoListDTO.setsCrNo(resultDTO.getsCrNo());
				/**	�ֹι�ȣ	**/
				custContInfoListDTO.setsCrtorCd(resultDTO.getsCrtorCd());
				/**	����ȸ��	**/
				custContInfoListDTO.setnLastEndorseNo(resultDTO.getnLastEndorseNo());
				/**	�ִ�ȸ��	**/
				custContInfoListDTO.setnMaxEndorseNo(resultDTO.getnMaxEndorseNo());
				/**	������ �輭��	**/
				custContInfoListDTO.setsLastEndorseDate(resultDTO.getsLastEndorseDate());
				/**	����ڸ�	**/
				custContInfoListDTO.setsCrtorName(resultDTO.getsCrtorName());
				/**	��Ʈ ���� flag	**/
				custContInfoListDTO.setsInsurFlag(resultDTO.getsInsurFlag());
				/**	��������	**/
				custContInfoListDTO.setsTodt(resultDTO.getsTodt());
				customerContInfoWrapperDTO.getPolicyInfo().add(custContInfoListDTO);
			}
		}
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		final StandardRoadAddrDTO standAddrDto = new StandardRoadAddrDTO();
		standAddrDto.setLoginId(sessionService.getUserID(session));
		standAddrDto.setTableNm("CUSAA02");
		if(customerContInfoWrapperDTO.getFlag().getHomeFlag().equals("I") && customerContInfoWrapperDTO.getHome().getsZipType().equals("3")){
			standAddrDto.setsAddrMgtNo(customerContInfoWrapperDTO.getHome().getsAddrMgtNo());
			standAddrDto.setVarAllAddress(customerContInfoWrapperDTO.getHome().getsDoroAddr() +" "+ customerContInfoWrapperDTO.getHome().getsAdrsAdd());
			standAddrDto.setVarPost(customerContInfoWrapperDTO.getHome().getsZip1()+customerContInfoWrapperDTO.getHome().getsZip2());
			
			StandardRoadAddrDTO resultStandAddr = adresssSearchBackBoneService.selectStandardAddr(standAddrDto);
			
			customerContInfoWrapperDTO.getHome().setsAdrs1(resultStandAddr.getWeb_sCityName());
			customerContInfoWrapperDTO.getHome().setsAdrs2(resultStandAddr.getWeb_sCountyName());
			customerContInfoWrapperDTO.getHome().setsAdrs3(resultStandAddr.getWeb_sTownName());
			customerContInfoWrapperDTO.getHome().setsAdrsAdd(resultStandAddr.getAnlysStndRdNmUndrAddrA());
		}
		if(customerContInfoWrapperDTO.getFlag().getOfficeFlag().equals("I") && customerContInfoWrapperDTO.getOffice().getsZipType().equals("3")){
			standAddrDto.setsAddrMgtNo(customerContInfoWrapperDTO.getOffice().getsAddrMgtNo());
			standAddrDto.setVarAllAddress(customerContInfoWrapperDTO.getOffice().getsDoroAddr() +" "+ customerContInfoWrapperDTO.getOffice().getsAdrsAdd());
			standAddrDto.setVarPost(customerContInfoWrapperDTO.getOffice().getsZip1()+customerContInfoWrapperDTO.getOffice().getsZip2());
			
			StandardRoadAddrDTO resultStandAddr = adresssSearchBackBoneService.selectStandardAddr(standAddrDto);
			
			customerContInfoWrapperDTO.getOffice().setsAdrs1(resultStandAddr.getWeb_sCityName());
			customerContInfoWrapperDTO.getOffice().setsAdrs2(resultStandAddr.getWeb_sCountyName());
			customerContInfoWrapperDTO.getOffice().setsAdrs3(resultStandAddr.getWeb_sTownName());
			customerContInfoWrapperDTO.getOffice().setsAdrsAdd(resultStandAddr.getAnlysStndRdNmUndrAddrA());
		}
		if(customerContInfoWrapperDTO.getFlag().getEtcFlag().equals("I") && customerContInfoWrapperDTO.getEtc().getsZipType().equals("3")){
			standAddrDto.setsAddrMgtNo(customerContInfoWrapperDTO.getEtc().getsAddrMgtNo());
			standAddrDto.setVarAllAddress(customerContInfoWrapperDTO.getEtc().getsDoroAddr() +" "+ customerContInfoWrapperDTO.getEtc().getsAdrsAdd());
			standAddrDto.setVarPost(customerContInfoWrapperDTO.getEtc().getsZip1()+customerContInfoWrapperDTO.getEtc().getsZip2());
			
			StandardRoadAddrDTO resultStandAddr = adresssSearchBackBoneService.selectStandardAddr(standAddrDto);
			
			customerContInfoWrapperDTO.getEtc().setsAdrs1(resultStandAddr.getWeb_sCityName());
			customerContInfoWrapperDTO.getEtc().setsAdrs2(resultStandAddr.getWeb_sCountyName());
			customerContInfoWrapperDTO.getEtc().setsAdrs3(resultStandAddr.getWeb_sTownName());
			customerContInfoWrapperDTO.getEtc().setsAdrsAdd(resultStandAddr.getAnlysStndRdNmUndrAddrA());
		}
		/** ���� �����ּ����� **/
		customerContInfoWrapperDTO.getHome().setsCustNo(sCustNo);
		customerContInfoWrapperDTO.getHome().setsUserID(sUserID);
		/** ���� �����ּ����� **/
		customerContInfoWrapperDTO.getOffice().setsCustNo(sCustNo);
		customerContInfoWrapperDTO.getOffice().setsUserID(sUserID);
		/** ���� ��Ÿ���ּ����� **/
		customerContInfoWrapperDTO.getEtc().setsCustNo(sCustNo);
		customerContInfoWrapperDTO.getEtc().setsUserID(sUserID);
		/** ��ȭ��ȣ���� **/
		customerContInfoWrapperDTO.getTelInfo().setsCustNo(sCustNo);
		customerContInfoWrapperDTO.getTelInfo().setsUserID(sUserID);
		/** �߼��� �ּ����� **/
		final CustomerContInfoSendAdrsDTO send = new CustomerContInfoSendAdrsDTO();
		if ("1".equals(sAdrsType)) {
			BeanUtils.copyProperties(customerContInfoWrapperDTO.getHome(), send);
		} else if ("2".equals(sAdrsType)) {
			BeanUtils.copyProperties(customerContInfoWrapperDTO.getOffice(), send);
		} else {
			BeanUtils.copyProperties(customerContInfoWrapperDTO.getEtc(), send);
		}
		customerContInfoWrapperDTO.setSend(send);
		/** Flag ���� **/
		customerContInfoWrapperDTO.getFlag().setUserID(sUserID);
		// ���� ���� �Ⱓ�� ���
		if (myEducarServiceBackBoneService.setCustomerContractInfoChange(customerContInfoWrapperDTO)) {
			final ModelMap modelMap = new ModelMap();
			return modelMap.addAttribute(Boolean.TRUE);
		} else {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.BackBoneException)).responseCode(ResponseStatusEnum.BACK_BONE_EXCEPTION).build();
		}
	}

	/**
	 * <pre>
	 * ��ü���� �� ������� ���� ����Ʈ ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("contractChange/selectCarInsuranceContractsList")
	public List<InsuranceCarResultDTO> selectCarInsuranceContractsList(final HttpSession session) {
		logger.debug("���������� - �����ȸ/���� - �ڵ��������ຯ�� - ��ü���� �� ������� ���� ����Ʈ ��ȸ");
		// ��ü/���� ��ȸ ����(��ü:false, ����:true(1)) - ����Ǹ� ��ȸ
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		return resultList;
	}

	/**
	 * <pre>
	 * �ڵ�����ȣ ���/����/����
	 * ���� ���� ���� ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/selectEndorsePlateNo")
	public ModelMap selectEndorsePlateNo(final EndorseCarPlateNoDTO request, final HttpSession session) {
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceCarResultDTO dto : resultList){
			if(request.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		final CarEndorseDetailDTO carEndorseDetailDTO = endorseBackBoneService.checkEndorsePlateNo(request.getsPolicyNo(), request.getsEndorseCodeForWeb(), sessionService.getUserID(session));
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("carEndorseDetailDTO", carEndorseDetailDTO);
		modelMap.addAttribute("currentDate", DateTime.now().toString("yyyyMMdd"));
		return modelMap;
	}

	/**
	 * <pre>
	 * �ڵ��� ��ȣ ���/����/����
	 * ������ȣ �� �輭 �����Ͽ� ���� ���� ���� ���� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/selectEndorseFmdtPlateNo")
	public EndorseCarPlateNoResponseDTO selectEndorseFmdtPlateNo(final EndorseCarPlateNoDTO request, final HttpSession session) {
		final EndorseCarPlateNoResponseDTO endorseCarPlateNoResponseDTO = endorseBackBoneService.checkEndorseFmdtPlateNo(request, sessionService.getUserID(session));
		return endorseCarPlateNoResponseDTO;
	}

	/**
	 * <pre>
	 * �ڵ��� ��ȣ ���/����/����
	 * ������ȣ ���� ó��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/updateEndorsePlateNo")
	public ModelMap updateEndorsePlateNo(final EndorseCarPlateNoDTO request, final HttpSession session) {
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceCarResultDTO dto : resultList){
			if(request.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult =false;
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		final boolean isSuccess = endorseBackBoneService.setEndorsePlateNo(request, sessionService.getUserID(session));
		if (isSuccess) {
			final ModelMap modelMap = new ModelMap();
			return modelMap.addAttribute(isSuccess);
		} else {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.EndorseUpdateFail)).build();
		}
	}

	/**
	 * <pre>
	 * ������ ���� ���/Ȯ��/���� ����� Ȯ��
	 * <pre>
	 * @param request
	 * @return 
	 */
	@RequestMapping("contractChange/selectEndorseDriverScope")
	public ModelMap selectEndorseDriverScope(final EndorseCarPlateNoDTO request, final HttpSession session) {
		
		String sInsrdName = new String();
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = true;
		for(final InsuranceCarResultDTO dto : resultList){
			if(request.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult =false;
				sInsrdName = dto.getsInsrdName();
			}
		}
		if(checkResult){
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.DifferenceContractInfoError)).build();
		}
		
		final EndorseDrivingScopeDTO resultDTO = endorseBackBoneService.getDrivingScopeChange(request.getsPolicyNo(), request.getsEndorseCodeForWeb(), sessionService.getUserID(session));
		if (resultDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SelectEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		// �ֹι�ȣ ****** ó��
		resultDTO.getPola001Info().setsInsrdID(SsnAsteriskConvert.getSsnAsterisk(resultDTO.getPola001Info().getsInsrdID(), Boolean.TRUE));
		resultDTO.getPola001Info().setsInsrdName(sInsrdName);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("currentDate", DateTime.now().toString("yyyyMMdd"));
		modelMap.addAttribute("endorseDrivingScopeDTO", resultDTO);
		return modelMap;
	}

	/**
	 * <pre>
	 * ������ ���� ���/Ȯ��/���� ��� - �輭 ������ �� ���� ���� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/selectEndorseDriverScopeCalculation")
	public EditDriverScopeResponseDTO selectEndorseDriverScopeCalculation(final EditDriverScopeRequestDTO request, final HttpSession session) {
		final EditDriverScopeResponseDTO resultDTO = endorseBackBoneService.calcuEndorsePremB1(request);
		return resultDTO;
	}

	/**
	 * <pre>
	 * �輭 ���� ���� ����
	 * <pre>
	 * @return
	 */
	@RequestMapping("contractChange/insertPaymentInfo")
	public ModelMap insertPaymentInfo(final HttpSession session, final PaymentVO request) {
		if (request == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		request.setsUserName(sessionService.getSNameFromSession(session));
		// ��ǰ ���� �߰�
		request.setsInsGrp(InsuranceProductEnum.CAR_INSURANCE.getType());
		session.setAttribute(SessionNameEnum.PAYMENT.name(), request);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute(Boolean.TRUE);
		return modelMap;
	}

	/**
	 * <pre>
	 * �輭 ���� ���� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("contractChange/selectPaymentInfo")
	public ModelMap selectPaymentInfo(final HttpSession session) {
		final PaymentVO vo = this.getPaymentVOSession(session);
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("currentDate", DateTime.now().toString("yyyyMMdd"));
		modelMap.addAttribute("paymentVO", vo);
		return modelMap;
	}
	
	/**
	 * <pre>
	 * ���� �ݾ��� 0�� �ݾ� ���� 
	 * <pre>
	 * @return
	 */
	@RequestMapping("contractChange/insertEndorsePaymentNoChange")
	public ModelMap insertEndorsePaymentNoChange(final HttpSession session) {
		final PaymentVO vo = this.getPaymentVOSession(session);
		final EndorseConfirmDTO inputDTO = new EndorseConfirmDTO();
		// ���� ���� ���� copy
		BeanUtils.copyProperties(vo, inputDTO);
		final boolean demandResult = endorseBackBoneService.demandEndorse(inputDTO);
		final ModelMap modelMap = new ModelMap();
		if (demandResult) {
			modelMap.addAttribute(demandResult);
			// ���� ���� ���� ����
			session.removeAttribute(SessionNameEnum.PAYMENT.name());
			myPageService.contractInfoChangeSend(sessionService.getUserID(session), sessionService.getSSNFromSession(session));
		} else {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.EndorseUpdateFail)).build();
		}
		
		return modelMap;
	}
	

	/**
	 * <pre>
	 * ȯ�� ����� ����
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("contractChange/insertEndorseRefund")
	public ModelMap insertEndorseRefund(final HttpSession session, final EndorseConfirmDTO endorseConfirmDTO) {
		final PaymentVO paymentVO = this.getPaymentVOSession(session);
		/*
		 * ���� ���� ���� ���� Ȯ��
		 * 1. ���ΰ��� ���� ����  
		 * 2. ���������ڵ�� ���������ڵ� Ȯ��
		 * 3. �������¿� �������� Ȯ��
		 */
		if (!paymentVO.isOwnedAccount() || !endorseConfirmDTO.getsReqBankCode().equals(paymentVO.getsOwnedBankCode()) || !endorseConfirmDTO.getsReqAcctNo().equals(paymentVO.getsOwnedAccountNo())) {
			logger.error("���� ���� ������ �ʿ�");
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentOwnedAccountEmpty)).build();
		}
		// ���� ���� ���� copy
		BeanUtils.copyProperties(paymentVO, endorseConfirmDTO);
		// �Ǹ�Ȯ��ID(���� �ֹι�ȣ)
		endorseConfirmDTO.setsRealID(sessionService.getSSNFromSession(session));
		// ������Ȯ�� (Y:Ȯ��, N:��Ȯ��)
		endorseConfirmDTO.setsConfirm("Y");
		// �����ֿ��ǰ��� (1:����, 2:��Ÿ)
		endorseConfirmDTO.setsRel("1");
		// ȯ�ޱ� �ݾ׿� - ��ȣ�� �ٿ��ش�.
		endorseConfirmDTO.setnRefundAmt("-" + endorseConfirmDTO.getnRefundAmt());
		final boolean demandResult = endorseBackBoneService.demandEndorse(endorseConfirmDTO);
		final ModelMap modelMap = new ModelMap();
		if (demandResult) {
			modelMap.addAttribute(demandResult);
			// ���� ���� ���� ����
			session.removeAttribute(SessionNameEnum.PAYMENT.name());
			
			myPageService.contractInfoChangeSend(sessionService.getUserID(session), sessionService.getSSNFromSession(session));
		} else {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.EndorseUpdateFail)).build();
		}
		return modelMap;
	}

	/**
	 * <pre>
	 * �輭 Ȯ���� �̸��� �߼��� ���� ���� �̸��� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("contractChange/selectUserEmail")
	public ModelMap selectUserEmail(final HttpSession session) {
		final ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("email", this.getUserEmail(session));
		return modelMap;
	}

	/**
	 * <pre>
	 * �輭 Ȯ���� �̸��� �߼�
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("contractChange/sendEndorseConfirmation")
	public ModelMap sendEndorseConfirmation(final HttpSession session) {
		final CarSendCertificateDTO inputDTO = sessionService.getAttribute(session, SessionNameEnum.ENDORSE_APPLY_INFO.name(), CarSendCertificateDTO.class);
		if (inputDTO == null) {
			logger.error("�輭 Ȯ���� ���� �߼� : ���� �߼� ���� ������ ����");
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		inputDTO.setsDmCode(SendCertificateDMCodeEnum.ENDORSE_CERTIFICATE.getCode());
		// �߱޹� ���� 1:�¶���,2:�ѽ�,3:�̸���, 5:report => �̸��� �߼۸� ���
		inputDTO.setRmethod("3");
		inputDTO.setsCustNm(sessionService.getSNameFromSession(session));
		inputDTO.setsCustNo(sessionService.getSSNFromSession(session));
		inputDTO.setsEmail(this.getUserEmail(session));

		final ModelMap modelMap = new ModelMap();
		if (riaBackBoneService.sendCertificate(inputDTO)) {
			logger.debug("�輭 Ȯ���� ���� �߼� ����");
			modelMap.addAttribute(Boolean.TRUE);
		} else {
			logger.error("�輭 Ȯ���� ���� �߼� ����");
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		return modelMap;
	}

	/**
	 * <pre>
	 * ���� ���� ���� return 
	 * ���� ������ ������ InvalidException �߻� -> ���� ������ �ε��� �������� �̵�
	 * <pre>
	 * @param session
	 * @return
	 */
	private PaymentVO getPaymentVOSession(final HttpSession session) {
		final PaymentVO vo = sessionService.getAttribute(session, SessionNameEnum.PAYMENT.name()) == null ? null : (PaymentVO) sessionService.getAttribute(session, SessionNameEnum.PAYMENT.name());
		if (vo == null) {
			logger.error("ȯ�� ����� ���� ������ �������� ����.");
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		return vo;
	}

	/**
	 * <pre>
	 * �α��� ������ ���� ��� �̸��� return
	 * ������ empty String return
	 * <pre>
	 * @param session
	 * @return
	 */
	private String getUserEmail(final HttpSession session) {
		final CustPopInfoWrapperDTO resultList = myEducarServiceBackBoneService.seletCustPopInfo(sessionService.getSSNFromSession(session));
		return resultList.getTelInfo().getsEmail1() != null ? StringUtils.defaultString(resultList.getTelInfo().getsEmail1()) : StringUtils.EMPTY;
	}
}
