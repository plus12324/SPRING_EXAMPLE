/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.RegularManagementDisclosureDTO;
import com.educar.dto.web.announcement.AnnouncementDTO;
import com.educar.dto.web.announcement.BalanceSheetDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.ManagementDisclosureService;

/**
 * ����濵���� ��Ʈ�ѷ�
 * @author �ּ�ȯ
 * @since 0.0.10
 */
@Controller
public class ManagementDisclosureController {

	/** �濵���� ����**/
	@Autowired
	private ManagementDisclosureService disclosureService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;

	/**
	 * ����濵 ���� ��ȸ
	 * @param
	 * @return response ����濵���� ����
	 */
	@RequestMapping("/regularManagementDisclosure/list")
	@ResponseBody
	public GenericRestResponse<RegularManagementDisclosureDTO> regularDisclosureList() {
		return this.processDisclureList(null);
	}

	/**
	 * ���ð濵 ���� ��ȸ ��Ʈ�ѷ�
	 * @param request
	 * @return response ���ð濵 ���� ����
	 */
	@RequestMapping("/occasionManagementDisclosure/list")
	@ResponseBody
	public GenericRestResponse<AnnouncementDTO> occasionalDisclosureList(@NotNull @RequestBody final GenericRestRequest<AnnouncementDTO> request) {
		return this.processDisclureList(request.getRequestData().get(BigInteger.ZERO.intValue()));
	}

	/**
	 * ��������ǥ ���� ��ȸ ��Ʈ�ѷ�
	 * @param request
	 * @return response ��������ǥ ���� ����
	 */
	@RequestMapping("/balanceSheet/list")
	@ResponseBody
	public GenericRestResponse<BalanceSheetDTO> balanceSheetList(@NotNull @RequestBody final GenericRestRequest<BalanceSheetDTO> request) {
		return this.processDisclureList(request.getRequestData().get(BigInteger.ZERO.intValue()));
	}

	/**
	 *  ����濵, ���ð濵, ��������ǥ ���� ��ȸ
	 * @param request
	 * @return
	 */
	private <T> GenericRestResponse<T> processDisclureList(final T request) {
		final GenericRestResponse<T> response = new GenericRestResponse<T>();
		List<T> resultList = null;
		resultList = disclosureService.selectDisclosure(request);
		if (resultList == null || resultList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, StringUtils.EMPTY));
			return response;
		}
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
