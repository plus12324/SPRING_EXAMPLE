/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jxl.common.Logger;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FileService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.dto.web.DeskTopDTO;
import com.educar.dto.web.MembershipPlusBoardDTO;
import com.educar.dto.web.MembershipPlusSchoolZoneDTO;
import com.educar.dto.web.myeducar.MyEduCallDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.MembershipPlusBackBoneService;
import com.educar.service.web.MembershipPlusService;

/**
 * <pre>
 * ������÷��� ��Ʈ�ѷ�
 * <pre>
 * @author ��â��
 *
 */
@Controller
@RequestMapping("/membershipPlus")
public class MembershipPlusController {

	/** ������÷��� ���� */
	@Autowired
	private MembershipPlusService membershipPlusService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;
	/** ���ϴٿ�ε� ���� **/
	@Autowired
	private FileService fileService;
	/** logger **/
	private Logger logger = Logger.getLogger(getClass());
	/** ������÷��� back bone service **/
	@Autowired
	private MembershipPlusBackBoneService membershipPlusBackBoneService;
	/**
	 * <pre>
	 * ������÷��� ����/�ʺ����� ��� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <MembershipPlusBoardDTO>
	 */
	@RequestMapping(value = "selectSafetyDrivingList")
	@ResponseBody
	public GenericRestResponse<MembershipPlusBoardDTO> selectSafetyDrivingList(@NotNull @RequestBody final GenericRestRequest<MembershipPlusBoardDTO> request) {
		final List<MembershipPlusBoardDTO> safetyDrivingList = membershipPlusService.selectSafetyDrivingList(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<MembershipPlusBoardDTO> response = new GenericRestResponse<MembershipPlusBoardDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(safetyDrivingList);
		return response;
	}

	/**
	 * <pre>
	 * ������÷��� Ī��������� ��� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <MembershipPlusBoardDTO>
	 */
	@RequestMapping(value = "selectPraiseStoryList")
	@ResponseBody
	public GenericRestResponse<MembershipPlusBoardDTO> selectPraiseStoryList(@NotNull @RequestBody final GenericRestRequest<MembershipPlusBoardDTO> request) {
		final List<MembershipPlusBoardDTO> praiseStoryList = membershipPlusService.selectPraiseStoryList(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<MembershipPlusBoardDTO> response = new GenericRestResponse<MembershipPlusBoardDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(praiseStoryList);
		return response;
	}

	/**
	 * ������÷��� �󼼳��� ��ȸ
	 * @param <MembershipPlusBoardDTO> nSeq 
	 * @return <MembershipPlusBoardDTO> �󼼳���
	 */
	@RequestMapping(value = "selectBoardView")
	@ResponseBody
	public GenericRestResponse<MembershipPlusBoardDTO> selectBoardView(@NotNull @RequestBody final GenericRestRequest<MembershipPlusBoardDTO> request) {
		final MembershipPlusBoardDTO dto = membershipPlusService.selectBoardView(request.getRequestData().get(BigInteger.ZERO.intValue()).getnSeq());

		final GenericRestResponse<MembershipPlusBoardDTO> response = new GenericRestResponse<MembershipPlusBoardDTO>();
		if (dto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "������÷��� �󼼳���"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(dto);
		}
		return response;
	}

	/**
	 * ����� �÷��� ���ȭ�� ��ȸ
	 * @param <String> ��ȸ �⵵
	 * @return
	 */
	@RequestMapping(value = "selectDeskTop")
	@ResponseBody
	public GenericRestResponse<DeskTopDTO> selectDeskTop(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final List<DeskTopDTO> resultList = membershipPlusService.selectDeskTop(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<DeskTopDTO> response = new GenericRestResponse<DeskTopDTO>();
		if (resultList == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "������÷��� ���ȭ��"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(resultList);
		}
		return response;
	}

	/**
	 * ����� �÷��� ���ȭ�� �ٿ�ε�
	 * @param nSeq
	 * @param type 1: 800*600, 2: 1024*768, 3: 1280*1024
	 * @return
	 */
	@RequestMapping(value = "selectDeskTopDownLoad")
	public void selectDeskTopDownLoad(final HttpServletResponse response, @RequestParam(value = "nSeq") final String nSeq, @RequestParam(value = "type") final String type) {
		final DeskTopDTO result = membershipPlusService.selectDeskTopKey(Long.valueOf(nSeq));
 
		if (result != null) {
			String fileName = StringUtils.EMPTY;
			// request�� �ùٸ��� ���� ���ڿ��� �ü��� �ֱ� ������ �ִ��� �������� üũ�ϰ� ���� ���� �̸� �� ��δ� DB���� ��ȸ�� ����� ����
			if ("1".equals(type)) {
				fileName = result.getsImageName800();
			} else if ("2".equals(type)) {
				fileName = result.getsImageName1024();
			} else if ("3".equals(type)) {
				fileName = result.getsImageName1280();
			} else {
				logger.error("�߸��� ��û�Դϴ�. nSeq: " + nSeq);
				throw new InvalidRequestException(message.getMessage(ExceptionMessage.InvalidRequest), ResponseStatusEnum.DEFAULT_ERROR);
			}

			// ���� �ٿ�ε�
			fileService.downloadFile(result.getsImagePath(), fileName, fileName, response);
		} else {
			logger.error("�ش� �����Ͱ� �������� �ʽ��ϴ�. nSeq: " + nSeq);
		}
	}
	
	
	/**
	 * �����ڽ� �������� ��ȸ
	 * @param request  GenericRestRequest<String> ������ȣ
	 * @return response Void
	 */
	@RequestMapping(value = "blackBoxCertNumber") 
	@ResponseBody
	public GenericRestResponse<String> blackBoxCertNumber(@NotNull @RequestBody final GenericRestRequest<String> request) {

		final String resultList = membershipPlusService.getCCCIA06(request.getRequestData().get(BigInteger.ZERO.intValue()));
		
		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		
		if("1".equals(resultList)){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.ContractMember)).forwardUrl(WebServletEnum.BLACKBOX).build();
		}
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(resultList);
		
		return response;
		
	}
	
	/**
	 * <pre>
	 * ������ - �����Ӵ�ȸ ��ǰ��û
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "applySchoolZoneGoods")
	@ResponseBody
	public GenericRestResponse<String> applySchoolZoneGoods(final HttpSession session, @RequestBody final GenericRestRequest<MembershipPlusSchoolZoneDTO> request) {
		final MembershipPlusSchoolZoneDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());

		String result = membershipPlusBackBoneService.applySchoolZoneGoods(dto);
		final GenericRestResponse<String> response =  new GenericRestResponse<String>();
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);
		return response;
	}
	/**
	 * ������ - �����Ӵ�ȸ ��ǰ ��û���� ��ȸ
	 * @param request  GenericRestRequest<String> ������ȣ
	 * @return response Void
	 */
	@RequestMapping(value = "applySchoolZoneGoodsList") 
	@ResponseBody
	public GenericRestResponse<MembershipPlusSchoolZoneDTO> applySchoolZoneGoodsList(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String strSchoolName =  request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<MembershipPlusSchoolZoneDTO> resultList = membershipPlusBackBoneService.selectSchoolZoneGoodsList(strSchoolName);
		
		for (final MembershipPlusSchoolZoneDTO dto : resultList) {
			dto.setsApplicantName(dto.getsApplicantName().substring(0, dto.getsApplicantName().length()-1) + '*');
		}
		
		final GenericRestResponse<MembershipPlusSchoolZoneDTO> response =  new GenericRestResponse<MembershipPlusSchoolZoneDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
		
	}
	
}
