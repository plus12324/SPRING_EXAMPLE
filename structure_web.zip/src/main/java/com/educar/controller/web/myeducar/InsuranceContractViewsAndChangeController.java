/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.myeducar;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.common.vo.LoginInfoVO;
import com.educar.dto.web.AccidentClaimDTO;
import com.educar.dto.web.CarClaimDTO;
import com.educar.dto.web.InsuranceDTO;
import com.educar.dto.web.VOCSearchResultDTO;
import com.educar.dto.web.login.MemberCheckDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailOfInsrdInfoDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailOfInsrdSendAdrsInfoDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailOfPolca01InfoDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailSearchDTO;
import com.educar.dto.web.myeducar.InsuranceCarDetailSearchResultDTO;
import com.educar.dto.web.myeducar.InsuranceCarResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralCoverageSearchDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralCoverageSearchResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetail1892DTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailOfContDetailList02DTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailOfContDetailList05DTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDetailWrapperDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralDivPremResultDTO;
import com.educar.dto.web.myeducar.InsuranceGeneralResultDTO;
import com.educar.dto.web.myeducar.InsuranceLongTermDetailWrapperDTO;
import com.educar.dto.web.myeducar.InsuranceLongTermResultDTO;
import com.educar.dto.web.myeducar.MyEducarInfoWrapperDTO;
import com.educar.dto.web.myeducar.PremRecvWdrcDlSpecResultDTO;
import com.educar.dto.web.myeducar.SalesMonitoringDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlOfLtiea00DtlDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlOfLtiea01PiboDTO;
import com.educar.dto.web.myeducar.SelectCntrDtlResultDTO;
import com.educar.dto.web.myeducar.SelectExptRtnAmtSearchDTO;
import com.educar.dto.web.myeducar.SelectExptRtnAmtSearchResultDTO;
import com.educar.dto.web.myeducar.SelectLoanCsclsInqrSearchDTO;
import com.educar.dto.web.myeducar.SelectLoanCsclsInqrSearchResultDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.VOCWebTypeEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AccidentClaimBackBoneService;
import com.educar.service.backbone.CarClaimBackBoneService;
import com.educar.service.backbone.InsuranceBackBoneService;
import com.educar.service.backbone.VOCBackBoneService;
import com.educar.service.web.MyPageService;

/**
 * <pre>
 * ���������� - �����ȸ/���� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("insuranceContract")
@Controller
public class InsuranceContractViewsAndChangeController {

	/** message ���� */
	@Autowired
	private MessageSourceService message;
	/** ��� ��ȸ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;
	/** ���� �ڵ������� ���� ��Ȳ ��ȸ �Ⱓ�� ���� ���� **/
	@Autowired
	private CarClaimBackBoneService myCarClaimService;
	/** ���� ����/�ǰ����� ������Ȳ ��ȸ �Ⱓ�� ���� ���� **/
	@Autowired
	private AccidentClaimBackBoneService accidentClaimService;
	/** VOC ��ȸ, �߰�, ���� ���� **/
	@Autowired
	private VOCBackBoneService vocService;
	/** ȸ������ ��ȸ/���� ���� **/
	@Autowired
	private MyPageService myPageService;
	/** ���� ���� **/
	@Autowired
	private SessionService sessionService;
	
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	/**
	 * <pre>
	 * ������ Ȯ�� - ��ü ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return 
	 */
	@RequestMapping("selectInsuranceContractsList")
	@ResponseBody
	public GenericRestResponse<InsuranceDTO> selectInsuranceContractsList(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<String> request) {
		// ��ü/���� ��ȸ ����(��ü:false, ����:true(1))
		final List<InsuranceDTO> resultList = insuranceBackBoneService.insuranceList("1".equals(request.getRequestData().get(BigInteger.ZERO.intValue())), this.getSSNFromSession(session));
		//****** ó���ϱ� �� session�� ����
		sessionService.setAttribute(session,  SessionNameEnum.INSCONT_All_INFO.name(), resultList);
		//�ֹε�Ϲ�ȣ ���ڸ� ****** ó��
		for (final InsuranceDTO dto : resultList) {
			dto.setsInrpsCdDp(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCdDp(), Boolean.TRUE));
			dto.setsInrpsCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCd(), Boolean.TRUE));
			dto.setsCrtorCdDp(SsnAsteriskConvert.getSsnAsterisk(dto.getsCrtorCdDp(), Boolean.TRUE));
			dto.setsCrtorCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsCrtorCd(), Boolean.TRUE));
		}
		final GenericRestResponse<InsuranceDTO> response = new GenericRestResponse<InsuranceDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ������ Ȯ�� - �ڵ��� ���� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("selectCarInsuranceContractsList")
	@ResponseBody
	public GenericRestResponse<InsuranceCarResultDTO> selectCarInsuranceContractsList(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<String> request) {
		// ��ü/���� ��ȸ ����(��ü:false, ����:true(1))
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb("1".equals(request.getRequestData().get(BigInteger.ZERO.intValue())),this.getSSNFromSession(session));
		
		final GenericRestResponse<InsuranceCarResultDTO> response = new GenericRestResponse<InsuranceCarResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ������ Ȯ�� - �Ϲ� ���� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("selectGeneralInsuranceContractsList")
	@ResponseBody
	public GenericRestResponse<InsuranceGeneralResultDTO> selectGeneralInsuranceContractsList(final HttpSession session) {
		final List<InsuranceGeneralResultDTO> resultList = insuranceBackBoneService.selectContGenList(StringUtils.EMPTY, this.getSSNFromSession(session), Boolean.FALSE);
		final GenericRestResponse<InsuranceGeneralResultDTO> response = new GenericRestResponse<InsuranceGeneralResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ������ Ȯ�� - ��� ���� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("selectLongTermInsuranceContractsList")
	@ResponseBody
	public GenericRestResponse<InsuranceLongTermResultDTO> selectLongTermInsuranceContractsList(final HttpSession session) {
		final List<InsuranceLongTermResultDTO> resultList = insuranceBackBoneService.selectCntrList(this.getSSNFromSession(session));
		//�ֹε�Ϲ�ȣ ���ڸ� ****** ó��
		for (final InsuranceLongTermResultDTO dto : resultList) {
			dto.setsInrpsCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCd(), Boolean.TRUE));
			dto.setsCrtorCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsCrtorCd(), Boolean.TRUE));
		}
		final GenericRestResponse<InsuranceLongTermResultDTO> response = new GenericRestResponse<InsuranceLongTermResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ������ Ȯ�� - �ڵ��� ���� ����ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectCarInsuranceContractsInfo")
	@ResponseBody
	public GenericRestResponse<InsuranceCarDetailSearchResultDTO> selectCarInsuranceContractsInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<InsuranceCarDetailSearchDTO> request) {
		final InsuranceCarDetailSearchDTO reqDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final String sessionSsn = this.getSSNFromSession(session);
		
		reqDto.setsPolicyType(reqDto.getsCrNo().substring(0, 1));
		reqDto.setsPolicyYM(reqDto.getsCrNo().substring(1, 5));
		reqDto.setsPolicySer(reqDto.getsCrNo().substring(5));
		
		final InsuranceCarDetailSearchResultDTO dto = insuranceBackBoneService.getContractView(reqDto);
		if (dto == null) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.SelectEmpty);
		}
		
		//����ȣ ����
		logger.debug(">>>> sessionssn : " + sessionSsn + "/P : " + dto.getPolca01Info().getsPolHolderID() + "/I : " +  dto.getPolca01Info().getsInsrdID());
		if(!sessionSsn.equals(dto.getPolca01Info().getsPolHolderID()) && !sessionSsn.equals(dto.getPolca01Info().getsInsrdID()) ){
			session.invalidate();
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.UnknownContractInfoError);
		}
		
		// �ֹι�ȣ ****** ó��(010101-1******)
		// ��� ����
		final InsuranceCarDetailOfPolca01InfoDTO insuranceCarDetailOfPolca01InfoDTO = dto.getPolca01Info();
		insuranceCarDetailOfPolca01InfoDTO.setsInsrdID(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsInsrdID(), Boolean.TRUE));
		insuranceCarDetailOfPolca01InfoDTO.setsPolHolderID(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsPolHolderID(), Boolean.TRUE));
		// ����/ī���ȣ * ó��
		insuranceCarDetailOfPolca01InfoDTO.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(insuranceCarDetailOfPolca01InfoDTO.getsAcctNo()));

		// �Ǻ����� ����
		final InsuranceCarDetailOfInsrdInfoDTO insuranceCarDetailOfInsrdInfoDTO = dto.getInsrdInfo();
		insuranceCarDetailOfInsrdInfoDTO.setsCustNo(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfInsrdInfoDTO.getsCustNo(), Boolean.TRUE));
		// �Ǻ����� �߼��� �ּ�
		final InsuranceCarDetailOfInsrdSendAdrsInfoDTO insuranceCarDetailOfInsrdSendAdrsInfoDTO = dto.getInsrdSendAdrsInfo();
		insuranceCarDetailOfInsrdSendAdrsInfoDTO.setsCustNo(SsnAsteriskConvert.getSsnAsterisk(insuranceCarDetailOfInsrdSendAdrsInfoDTO.getsCustNo(), Boolean.TRUE));

		final GenericRestResponse<InsuranceCarDetailSearchResultDTO> response = new GenericRestResponse<InsuranceCarDetailSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ������ Ȯ�� - �Ϲ� ���� ����ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectGeneralInsuranceContractsInfo")
	@ResponseBody
	public GenericRestResponse<InsuranceGeneralDetailWrapperDTO> selectGeneralInsuranceContractsInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sCrNo = request.getRequestData().get(BigInteger.ZERO.intValue());
		final String sessionSsn = this.getSSNFromSession(session);
		
		final InsuranceGeneralCoverageSearchDTO inputDTO = new InsuranceGeneralCoverageSearchDTO();
		// ����ȣ ���� üũ
		if (sCrNo.length() != 12) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.InvalidRequest);
		}
		final String sPolicyType = sCrNo.substring(0, 1);
		final String sPolicyKind = sCrNo.substring(1, 5);
		final String sPolicySer = sCrNo.substring(5);

		// �Ϲ� ���� ����ȸ
		final InsuranceGeneralDetailResultDTO detailResultDTO = insuranceBackBoneService.selectDrvContDetailList(sPolicyType, sPolicyKind, sPolicySer);
		if (detailResultDTO == null) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.SelectEmpty);
		}
		
		//����ȣ ����
		if(!sessionSsn.equals(detailResultDTO.getContDetailList03().getsPlrCsmNum()) 
				&& !sessionSsn.equals(detailResultDTO.getContDetailList02().get(0).getsIsdCsmNum())){
			session.invalidate();
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.UnknownContractInfoError);
		}
		
		// �Ϲ� ���� �㺸���� ��ȸ
		inputDTO.setsBizTyp(sPolicyType);
		inputDTO.setsInsItmCod(sPolicyKind);
		inputDTO.setsSeq(sPolicySer);
		inputDTO.setnEndorseNo(detailResultDTO.getContDetailList01().get(BigInteger.ZERO.intValue()).getnEndorseNo());
		inputDTO.setsInsCtrTpd(detailResultDTO.getContDetailList01().get(BigInteger.ZERO.intValue()).getsInsCtrTpd());
		final List<InsuranceGeneralCoverageSearchResultDTO> coverageList = insuranceBackBoneService.selectCoverage(inputDTO);
		// �Ϲ� ���� ���Գ�����ȸ
		final List<InsuranceGeneralDivPremResultDTO> paymentHistoryList = insuranceBackBoneService.selectDrvDivPremList(sPolicyType, sPolicyKind, sPolicySer);

		// �ֹι�ȣ ****** ó��(010101-1******)
		// �Ǻ�����
		final List<InsuranceGeneralDetailOfContDetailList02DTO> contDetailList02DTOList = detailResultDTO.getContDetailList02();
		for (final InsuranceGeneralDetailOfContDetailList02DTO dto : contDetailList02DTOList) {
			dto.setsIsdCsmNum(SsnAsteriskConvert.getSsnAsterisk(dto.getsIsdCsmNum(), Boolean.TRUE));
		}
		// �����
		detailResultDTO.getContDetailList03().setsPlrCsmNum(SsnAsteriskConvert.getSsnAsterisk(detailResultDTO.getContDetailList03().getsPlrCsmNum(), Boolean.TRUE));
		final List<InsuranceGeneralDetailOfContDetailList05DTO> contDetailList05DTOList = detailResultDTO.getContDetailList05();
		for (final InsuranceGeneralDetailOfContDetailList05DTO dto : contDetailList05DTOList) {
			// �ڵ���ü ����/ī���ȣ
			dto.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(dto.getsAcctNo()));
			// �ڵ���ü ������
			dto.setsDepositerID(SsnAsteriskConvert.getSsnAsterisk(dto.getsDepositerID(), Boolean.TRUE));
		}

		// �Ϲ� ���� ��ȸ ������ wrapperDTO�� ó��
		final InsuranceGeneralDetailWrapperDTO wrapperDTO = new InsuranceGeneralDetailWrapperDTO();
		wrapperDTO.setDetailResult(detailResultDTO);
		wrapperDTO.setCoverageList(coverageList);
		wrapperDTO.setPaymentHistoryList(paymentHistoryList);

		final GenericRestResponse<InsuranceGeneralDetailWrapperDTO> response = new GenericRestResponse<InsuranceGeneralDetailWrapperDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(wrapperDTO);
		return response;
	}
	/**
	 * <pre>
	 * ������ Ȯ�� - �Ϲ� ���� - �����ǿ� �Ǹ�����
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectGeneralInsuranceContractsInfo1892")
	@ResponseBody
	public GenericRestResponse<InsuranceGeneralDetail1892DTO> selectGeneralInsuranceContractsInfo1892(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sCrNo = request.getRequestData().get(BigInteger.ZERO.intValue());
		final String sessionSsn = this.getSSNFromSession(session);
		
		// ����ȣ ���� üũ
		if (sCrNo.length() != 12) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.InvalidRequest);
		}
		final String sPolicyType = sCrNo.substring(0, 1);
		final String sPolicyKind = sCrNo.substring(1, 5);
		final String sPolicySer = sCrNo.substring(5);

		// �Ϲ� ���� ����ȸ
		final List<InsuranceGeneralDetail1892DTO> detailResultDTO = insuranceBackBoneService.selectDrvContDetail1892(sPolicyType, sPolicyKind, sPolicySer);
		if (detailResultDTO == null) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.SelectEmpty);
		}
		
		//����ȣ ����
		if(!sessionSsn.equals(detailResultDTO.get(0).getsPolHolderID())){
			session.invalidate();
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.UnknownContractInfoError);
		}
		// �ֹι�ȣ ****** ó��(010101-1******)
		for (final InsuranceGeneralDetail1892DTO dto : detailResultDTO) {
			dto.setsPolHolderID(SsnAsteriskConvert.getSsnAsterisk(dto.getsPolHolderID(), Boolean.TRUE));
			dto.setsInsrdID(SsnAsteriskConvert.getSsnAsterisk(dto.getsInsrdID(), Boolean.TRUE));
		}
		final GenericRestResponse<InsuranceGeneralDetail1892DTO> response = new GenericRestResponse<InsuranceGeneralDetail1892DTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(detailResultDTO);
		return response;
	}
	/**
	 * <pre>
	 * ������ Ȯ�� - ��� ���� ����ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectLongTermInsuranceContractsInfo")
	@ResponseBody
	public GenericRestResponse<InsuranceLongTermDetailWrapperDTO> selectLongTermInsuranceContractsInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<String> request) {
		
		final String reqParam = request.getRequestData().get(BigInteger.ZERO.intValue());
		final String sCrNo = reqParam.substring(0, 12);
		final String nInrpsSeqno = reqParam.substring(12, reqParam.length());
		
		final String sessionSsn = this.getSSNFromSession(session);
		
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>" + sCrNo + "/" +nInrpsSeqno);
		// ����ȣ ���� üũ
		if (sCrNo.length() != 12) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.InvalidRequest);
		}
		// ��� ���� ����ȸ
		final SelectCntrDtlResultDTO detailResultDTO = insuranceBackBoneService.selectCntrDtl(sCrNo, nInrpsSeqno);
		if (detailResultDTO == null) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.SelectEmpty);
		}
		
		//����ȣ ����
		if(!sessionSsn.equals(detailResultDTO.getCNTR().get(0).getsCrtorCd()) 
				&& !sessionSsn.equals(detailResultDTO.getPIBO().get(0).getsInrpsCd())){
			session.invalidate();
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.UnknownContractInfoError);
		}
		
		// �ֹι�ȣ ****** ó��(010101-1******)
		// �����
		final SelectCntrDtlOfLtiea00DtlDTO cntrDTO = detailResultDTO.getCNTR().get(BigInteger.ZERO.intValue());
		cntrDTO.setsCrtorCd(SsnAsteriskConvert.getSsnAsterisk(cntrDTO.getsCrtorCd(), Boolean.TRUE));
		// �Ǻ�����
		final List<SelectCntrDtlOfLtiea01PiboDTO> piboDTOList = detailResultDTO.getPIBO();
		for (final SelectCntrDtlOfLtiea01PiboDTO dto : piboDTOList) {
			dto.setsInrpsCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCd(), Boolean.TRUE));
		}
		// ���¹�ȣ �Ǵ� ī���ȣ * ó��
		cntrDTO.setsAcctNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(cntrDTO.getsAcctNo()));

		// ��� ���� ����� ���Գ��� ��ȸ
		final List<PremRecvWdrcDlSpecResultDTO> paymentResultList = insuranceBackBoneService.getPremRecvWdrcDlSpec(sCrNo, nInrpsSeqno);

		final String currentDate = DateTime.now().toString("yyyyMMdd");
		// ������ ������� ��ȸ
		final SelectLoanCsclsInqrSearchDTO loanSearchDTO = new SelectLoanCsclsInqrSearchDTO();
		loanSearchDTO.setsInqrTerm(BigInteger.ONE.toString());
		loanSearchDTO.setsCrNo(sCrNo);
		loanSearchDTO.setsDlOccrDate1(cntrDTO.getsInsurStrtdate());
		loanSearchDTO.setsDlOccrDate2(currentDate);
		loanSearchDTO.setsYdate1(cntrDTO.getsInsurStrtdate());
		loanSearchDTO.setsYdate2(currentDate);
		loanSearchDTO.setsTdate(currentDate);

		final List<SelectLoanCsclsInqrSearchResultDTO> loanResultList = insuranceBackBoneService.selectLoanCsclsInqr(loanSearchDTO);

		final InsuranceLongTermDetailWrapperDTO wrapperDTO = new InsuranceLongTermDetailWrapperDTO();
		wrapperDTO.setDetailResult(detailResultDTO);
		wrapperDTO.setPaymentResultList(paymentResultList);
		wrapperDTO.setLoanResultList(loanResultList);

		final GenericRestResponse<InsuranceLongTermDetailWrapperDTO> response = new GenericRestResponse<InsuranceLongTermDetailWrapperDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(wrapperDTO);
		return response;
	}

	/**
	 * <pre>
	 * ���� ����/���� ȯ�ޱ� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectExpectedRefund")
	@ResponseBody
	public GenericRestResponse<SelectExptRtnAmtSearchResultDTO> selectExpectedRefund(@NotNull @RequestBody final GenericRestRequest<SelectExptRtnAmtSearchDTO> request) {
		final SelectExptRtnAmtSearchDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		final SelectExptRtnAmtSearchResultDTO dto = insuranceBackBoneService.selectExptRtnAmt(inputDTO);

		final GenericRestResponse<SelectExptRtnAmtSearchResultDTO> response = new GenericRestResponse<SelectExptRtnAmtSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���̿���ī ������� �������� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectMyEducarInfo")
	@ResponseBody
	public GenericRestResponse<MyEducarInfoWrapperDTO> selectMyEducarInfo(final HttpSession session) {
		// �α��� ���� ��ȸ
		final LoginInfoVO loginInfoVO = sessionService.getAttribute(session, SessionNameEnum.LOGIN_INFO.name(), LoginInfoVO.class);
		final String ssn = loginInfoVO.getSSN();

		// ��ü ���� ��ȸ (����Ǹ� ��ȸ)
		final List<InsuranceDTO> insuranceList = insuranceBackBoneService.insuranceList(Boolean.TRUE, ssn);
		for (final InsuranceDTO dto : insuranceList) {
			dto.setsInrpsCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCd(), Boolean.TRUE));
			dto.setsInrpsCdDp(SsnAsteriskConvert.getSsnAsterisk(dto.getsInrpsCdDp(), Boolean.TRUE));
			dto.setsCrtorCd(SsnAsteriskConvert.getSsnAsterisk(dto.getsCrtorCd(), Boolean.TRUE));
			dto.setsCrtorCdDp(SsnAsteriskConvert.getSsnAsterisk(dto.getsCrtorCdDp(), Boolean.TRUE));
		}
		// �ڵ������� ���󳻿� ��ȸ
		final List<CarClaimDTO> carClaimList = myCarClaimService.carClaimList("1", ssn);
		for (final CarClaimDTO dto : carClaimList) {
			dto.setsVictimSocNo(SsnAsteriskConvert.getSsnAsterisk(dto.getsVictimSocNo(), Boolean.TRUE));
		}
		// ����/�ǰ����� ���󳻿� ��ȸ
		final List<AccidentClaimDTO> accidentClaimList = accidentClaimService.accidentClaimList(ssn, null, null);
		// TODO :������ ������� ��ȸ

		
		
		// ���� ��㳻�� ��ȸ
		final List<VOCSearchResultDTO> counselList = vocService.searchVOC(ssn, VOCWebTypeEnum.COUNSEL);
		
		// ��ȸ�� ������ȸ
		final MemberCheckDTO memberCheckDTO = myPageService.selectMyDetail(loginInfoVO.getID());
		memberCheckDTO.setsCustNo(SsnAsteriskConvert.getSsnAsterisk(memberCheckDTO.getsCustNo(), Boolean.TRUE));
		if (memberCheckDTO == null) {
			// �Ⱓ�� ������ ������ ����ġ
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.WebBackBoneDataInconsistency.getMessage()), ResponseStatusEnum.DEFAULT_ERROR);
		}
		memberCheckDTO.setsName(loginInfoVO.getsName());
		memberCheckDTO.setsSex(loginInfoVO.getsSex());
		memberCheckDTO.setsCustNo(SsnAsteriskConvert.getSsnAsterisk(loginInfoVO.getSSN(), Boolean.FALSE));

		final MyEducarInfoWrapperDTO wrapperDTO = new MyEducarInfoWrapperDTO();
		wrapperDTO.setMemberCheckDTO(memberCheckDTO);
		wrapperDTO.setInsuranceList(insuranceList);
		wrapperDTO.setCarClaimList(carClaimList);
		wrapperDTO.setAccidentClaimList(accidentClaimList);
		wrapperDTO.setCounselList(counselList);

		final GenericRestResponse<MyEducarInfoWrapperDTO> response = new GenericRestResponse<MyEducarInfoWrapperDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(wrapperDTO);
		return response;
	}

	/**
	 * <pre>
	 * ���ǿ� �ִ� �ֹι�ȣ�� ��ȸ�ϰ� �ֹι�ȣ�� ������ �ֹι�ȣ return 
	 * �ֹι�ȣ�� null �̸� InvalidRequestException �� �߻��ϰ� �α��� �������� �̵��Ѵ�.
	 * <pre>
	 * @param session
	 * @return �ֹι�ȣ
	 */
	private String getSSNFromSession(final HttpSession session) {
		final String ssn = sessionService.getSSNFromSession(session);
		// session �ֹι�ȣ�� ������ �α��� �������� �̵��Ѵ�.
		if (ssn == null) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.SessionEmptyLoginInfo)).forwardUrl(WebServletEnum.LOGIN_COMMON).build();
		}
		return ssn;
	}

	/**
	 * <pre>
	 * ����ȣ�� �޾� InsuranceCarDetailSearchDTO�� ����
	 * <pre>
	 * @param sCrNo ����ȣ(12�ڸ�/ ��>L20111234567)
	 * @return
	 */
	private InsuranceCarDetailSearchDTO setInsuranceCarDetailSearchDTO(final String sCrNo) {
		if (sCrNo == null || sCrNo.length() != 12) {
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.InvalidRequest);
		}
		// ����ȣ �и�
		final InsuranceCarDetailSearchDTO dto = new InsuranceCarDetailSearchDTO();
		dto.setsPolicyType(sCrNo.substring(0, 1));
		dto.setsPolicyYM(sCrNo.substring(1, 5));
		dto.setsPolicySer(sCrNo.substring(5));
		return dto;
	}

	/**
	 * <pre>
	 * ���� Ÿ���� �޾� �޼��� ó�� �� ���̿���ī �α��� �������� �̵�
	 * <pre>
	 * @param type ExceptionMessage
	 * @return
	 */
	private boolean throwExcpetionMyPageIndexPage(final ExceptionMessage type) {
		throw new InvalidRequestException.Builder(message.getMessage(type)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
	}
	
	/**
	 * ���� �Ƚ� ���� - �����ȣ ���û 
	 * dto�� editCode�� ������, �Ⱓ�迡�� �Ǵ��Ͽ� �߰�/����/������
	 * See <a href="http://dev-server:8020/browse/EDUCAR-771">Jira(������ ����)</a>
	 * @param servletRequest
	 * @param request
	 */
	@RequestMapping("salesMonitoring")
	@ResponseBody
	public GenericRestResponse<Void> salesMonitoring(final HttpSession session, @RequestBody @NotNull final GenericRestRequest<SalesMonitoringDTO> request) {
		final SalesMonitoringDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());	
		final String strPolicyNo = inputDTO.getsPolicyType() + inputDTO.getsPolicyYM() + inputDTO.getsPolicySer();
		final List<InsuranceDTO> sessionList = (List<InsuranceDTO>) sessionService.getAttribute(session,  SessionNameEnum.INSCONT_All_INFO.name());
		
		//����ȣ üũ(������)
		boolean checkCrNo = Boolean.FALSE;
		for (final InsuranceDTO dto : sessionList) {
			if(dto.getsCrNo().equals(strPolicyNo)){
				checkCrNo = Boolean.TRUE;
			}
		}
		//���� ����Ͽ� �ش� ����ȣ�� ���� ��� ������ 
		if(!checkCrNo){
			session.invalidate();
			this.throwExcpetionMyPageIndexPage(ExceptionMessage.UnknownContractInfoError);
		}
		
		final String rtnValue = insuranceBackBoneService.insertSalesMonitoring(inputDTO);
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if("1".equals(rtnValue)){
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		}else{
			response.setStatus(ResponseStatusEnum.FAIL_INSERT_DATA.getCode());
		}
		
		return response;
	}
}
