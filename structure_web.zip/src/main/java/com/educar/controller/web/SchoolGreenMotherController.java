/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.GreenMotherAuthCheckDTO;
import com.educar.dto.web.GreenMotherCommentDTO;
import com.educar.dto.web.GreenMotherDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.SchoolGreenMotherService;

/**
 * <pre>
 * ������ - �����Ӵ� ��Ʈ�ѷ�
 * <pre>
 * @author ���ѳ�
 *
 */
@Controller
@RequestMapping("/schoolGreenMother")
public class SchoolGreenMotherController {

	/** ������ - �����Ӵ� ���� */
	@Autowired
	private SchoolGreenMotherService schoolGreenMotherService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());

	/**
	 * <pre>
	 * �����Ӵ� �Խñ� ��� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <BidNotificationDTO>
	 */
	@RequestMapping(value = "selectGreenMotherNoticeList")
	@ResponseBody
	public GenericRestResponse<GreenMotherDTO> selectGreenMotherNoticeList(@NotNull @RequestBody final GenericRestRequest<GreenMotherDTO> request) {
		List<GreenMotherDTO> greenMotherNoticeList = schoolGreenMotherService.selectGreenMotherNoticeList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<GreenMotherDTO> response = new GenericRestResponse<GreenMotherDTO>();
		if (greenMotherNoticeList == null) {
			greenMotherNoticeList = new ArrayList<GreenMotherDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(greenMotherNoticeList);
		return response;
	}
	/**
	 * <pre>
	 * �����Ӵ� �Խñ� ����ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <BidNotificationDTO>
	 */
	@RequestMapping(value = "selectGreenMotherNoticeView")
	@ResponseBody
	public GenericRestResponse<GreenMotherDTO> selectGreenMotherNoticeView(@NotNull @RequestBody final GenericRestRequest<GreenMotherDTO> request) {
		final GreenMotherDTO greenMotherNotice = schoolGreenMotherService.selectGreenMotherNoticeView(request.getRequestData().get(BigInteger.ZERO.intValue()));
		
		final GenericRestResponse<GreenMotherDTO> response = new GenericRestResponse<GreenMotherDTO>();
		if (greenMotherNotice == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(greenMotherNotice);
		}
		return response;
	}
	
	/**
	 * <pre>
	 * �����Ӵ� �Խñ� - ���۸�� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <BidNotificationDTO>
	 */
	@RequestMapping(value = "selectGreenMotherCommentList")
	@ResponseBody
	public GenericRestResponse<GreenMotherCommentDTO> selectGreenMotherCommentList(@NotNull @RequestBody final GenericRestRequest<GreenMotherCommentDTO> request) {
		List<GreenMotherCommentDTO> greenMotherCommentList = schoolGreenMotherService.selectGreenMotherCommentList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<GreenMotherCommentDTO> response = new GenericRestResponse<GreenMotherCommentDTO>();
		if (greenMotherCommentList == null) {
			greenMotherCommentList = new ArrayList<GreenMotherCommentDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(greenMotherCommentList);
		return response;
	}
	
	/**
	 * �Խñ�, ���� ������ ��й�ȣ üũ
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "checkPassword")
	@ResponseBody
	public GenericRestResponse<Boolean> checkPassword(@NotNull @RequestBody final GenericRestRequest<GreenMotherAuthCheckDTO> request) {
		boolean chkAuth = schoolGreenMotherService.greenMotherCheckPassword(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<Boolean> response = new GenericRestResponse<Boolean>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(chkAuth);
		return response;
	}
	/**
	 * ���� ���
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "insertGreenMotherComment")
	@ResponseBody
	public GenericRestResponse<Integer> insertGreenMotherComment(@NotNull @RequestBody final GenericRestRequest<GreenMotherCommentDTO> request) {
		int chkAuth = schoolGreenMotherService.insertGreenMotherComment(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<Integer> response = new GenericRestResponse<Integer>();
		if(0 < chkAuth){
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(chkAuth);
		}else{
			response.setStatus(ResponseStatusEnum.FAIL_INSERT_DATA.getCode());
			response.addResponseData(chkAuth);
		}
		return response;
	}
	/**
	 * ���� ����
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "modifyGreenMotherComment")
	@ResponseBody
	public GenericRestResponse<Integer> modifyGreenMotherComment(@NotNull @RequestBody final GenericRestRequest<GreenMotherCommentDTO> request) {
		int chkAuth = schoolGreenMotherService.updateGreenMotherComment(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<Integer> response = new GenericRestResponse<Integer>();
		if(0 < chkAuth){
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(chkAuth);
		}else{
			response.setStatus(ResponseStatusEnum.FAIL_INSERT_DATA.getCode());
			response.addResponseData(chkAuth);
		}
		return response;
	}
	/**
	 * ���� ����
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "deleteGreenMotherComment")
	@ResponseBody
	public GenericRestResponse<Integer> deleteGreenMotherComment(@NotNull @RequestBody final GenericRestRequest<GreenMotherCommentDTO> request) {
		int chkDelete = schoolGreenMotherService.deleteGreenMotherComment(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<Integer> response = new GenericRestResponse<Integer>();
		if(0 < chkDelete){
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(chkDelete);
		}else{
			response.setStatus(ResponseStatusEnum.FAIL_INSERT_DATA.getCode());
			response.addResponseData(chkDelete);
		}
		return response;
	}
	/**
	 * �Խñ� ����
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "deleteGreenMotherNotice")
	@ResponseBody
	public GenericRestResponse<Integer> deleteGreenMotherNotice(@NotNull @RequestBody final GenericRestRequest<GreenMotherDTO> request) {
		int chkDelete = schoolGreenMotherService.deleteGreenMotherNotice(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<Integer> response = new GenericRestResponse<Integer>();
		if(0 < chkDelete){
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(chkDelete);
		}else{
			response.setStatus(ResponseStatusEnum.FAIL_INSERT_DATA.getCode());
			response.addResponseData(chkDelete);
		}
		return response;
	}
	/**
	 * �Խñ� ���
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "insertGreenMotherNotice")
	@ResponseBody
	public GenericRestResponse<Void> insertGreenMotherNotice(@NotNull @RequestBody final GenericRestRequest<GreenMotherDTO> request) {
		final GreenMotherDTO noticeDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if(!"1234".equals(noticeDTO.getsPassword())){
			boolean boResult = schoolGreenMotherService.insertGreenMotherNotice(noticeDTO);
			if (!boResult) {
				// �Ⱓ�� ȣ�� ����� ������ ��� ������ GenericResponse ��ȯ
				response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
				response.setMessage(message.getMessage(ExceptionMessage.ProcessFail, "�����Ӵ� �Խñ� ���"));
				return response;
			}else{
				response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			}
		}else{
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage("�ʱ�ȭ ��й�ȣ�� �ٸ��� �Է��ϼž� �մϴ�.");
			return response;
		}
		return response;
	}
	/**
	 * �Խñ� ���
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "modifyGreenMotherNotice")
	@ResponseBody
	public GenericRestResponse<Void> modifyGreenMotherNotice(@NotNull @RequestBody final GenericRestRequest<GreenMotherDTO> request) {
		final GreenMotherDTO noticeDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GreenMotherAuthCheckDTO passChkDto = new GreenMotherAuthCheckDTO();
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		
		//passChkDto.setnSeq(noticeDTO.getnSeq());
		//passChkDto.setsChkDiv("N");
		//passChkDto.setsPassword(noticeDTO.getsPassword());
		
		//final boolean chkAuth = schoolGreenMotherService.greenMotherCheckPassword(passChkDto);
		boolean boResult = Boolean.FALSE;
		if(!"1234".equals(noticeDTO.getsPassword())){
			boResult = schoolGreenMotherService.modifyGreenMotherNotice(noticeDTO);
			if (!boResult) {
				// �Ⱓ�� ȣ�� ����� ������ ��� ������ GenericResponse ��ȯ
				response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
				response.setMessage("�����Ӵ� �Խñ� ���� ó���� �����Ͽ����ϴ�");
				return response;
			}else{
				response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			}
		}else{
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage("�ʱ�ȭ ��й�ȣ�� �ٸ��� �Է��ϼž� �մϴ�.");
			return response;
		}

		
		return response;
	}
}
