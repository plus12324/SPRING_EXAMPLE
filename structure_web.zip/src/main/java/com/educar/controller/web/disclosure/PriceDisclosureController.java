/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.disclosure;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.dto.web.CalculationOfCarInsuranceParamDTO;
import com.educar.dto.web.CalculationOfCarInsuranceResultDTO;
import com.educar.dto.web.EducarDriverInsurancePawnDTO;
import com.educar.dto.web.HouseFirePremWebDTO;
import com.educar.dto.web.LongAnntCommCodeWrapperDTO;
import com.educar.dto.web.LongTermInsurancePlanSearchDTO;
import com.educar.dto.web.LongTermInsurancePlanSearchResultDTO;
import com.educar.dto.web.OneDayCodeSearchResultDTO;
import com.educar.dto.web.PriceCalculationOfCarInsuranceCareerDTO;
import com.educar.dto.web.PriceCalculationOfCarInsuranceCodeDTO;
import com.educar.dto.web.PriceCalculationOfCarInsuranceDTO;
import com.educar.dto.web.PriceCalculationOfEducarInsuranceSearchDTO;
import com.educar.dto.web.PriceCalculationOfEducarInsuranceSearchResultDTO;
import com.educar.dto.web.PriceCalculationOfLognTermInsuranceSearchDTO;
import com.educar.dto.web.PriceCalculationOfLognTermInsuranceSearchResultDTO;
import com.educar.dto.web.PriceCalculationOfOneDayInsuranceSearchDTO;
import com.educar.dto.web.PriceCalculationOfOneDayInsuranceSearchResultDTO;
import com.educar.dto.web.PriceCalculationOfRtnAmtDtalSearchResultDTO;
import com.educar.enumeration.InsuranceProductEnum;
import com.educar.enumeration.LongTermInsurancePlanEnum;
import com.educar.enumeration.PriceCalculationOfCarInsuranceTypeEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.PriceDisclosureBackBoneService;

/**
 * <pre>
 * ���ý� - ���ݰ���
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("priceDisclosure")
@Controller
public class PriceDisclosureController {

	/** message ���� */
	@Autowired
	private MessageSourceService message;
	/** �ڵ���ȸ ���� */
	@Autowired
	private PriceDisclosureBackBoneService priceDisclosureBackBoneService;
	@Autowired
	private SessionService sessionService;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	private final String currentDate = DateTime.now().toString("yyyyMMdd");
	/**
	 * ����ī �����ں��� �������� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/carDriver/selectEducarDriverInsuranceList")
	@ResponseBody
	public GenericRestResponse<EducarDriverInsurancePawnDTO> selecteducarDriverInsuranceList() {
		final GenericRestResponse<EducarDriverInsurancePawnDTO> response = new GenericRestResponse<EducarDriverInsurancePawnDTO>();
		final List<EducarDriverInsurancePawnDTO> resultDto = priceDisclosureBackBoneService.educarDriverInsurancePawnList();
		if (resultDto == null || resultDto.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "����ī �����ں��� ��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(resultDto);
		}
		return response;
	}

	/**
	 * ����ī �����ں��� ����� �ܼ������ ���
	 */
	@RequestMapping(value = "/carDriver/selectEducarDriverInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfEducarInsuranceSearchResultDTO> selectEducarDriverInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfEducarInsuranceSearchDTO> request) {
		final PriceCalculationOfEducarInsuranceSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		if (requestDto.getBasicInfo() == null || requestDto.getsCovSel() == null || requestDto.getsCovSel().isEmpty()) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.InvalidRequest)).build();
		}

		// ��ǰ�ڵ�
		requestDto.getBasicInfo().setsPrdCod(InsuranceProductEnum.EDUCAR_DRIVER.getCode());

		// ���� ���� ���� ���� ���� ���� �����Ѵ�.
		final String sex = "M".equals(requestDto.getBasicInfo().getsSex()) ? "01" : "02";
		requestDto.getBasicInfo().setsSex(sex);
		requestDto.getBasicInfo().setsMainSexCod(sex);
		// ���������� �κ����� ��� ����/���� ���� ��ݵǵ��� �����Ѵ�.
		if ("20".equals(requestDto.getBasicInfo().getBu_bu_yn())) {
			requestDto.getBasicInfo().setsSeconSexCod("01".equals(sex) ? "02" : "01");
		} else {
			requestDto.getBasicInfo().setsSeconSexCod(sex);
		}

		// ������ �޼� ����
		final String geukSu = requestDto.getBasicInfo().getGeuk_su();
		requestDto.getBasicInfo().setGeuk_su(StringUtils.rightPad(StringUtils.defaultString(geukSu, "10"), 2, "0"));
		requestDto.getBasicInfo().setBu_bu_geuk_su(requestDto.getBasicInfo().getGeuk_su());

		final PriceCalculationOfEducarInsuranceSearchResultDTO dto = priceDisclosureBackBoneService.calculateEducarDriverInsurance(requestDto);
		final GenericRestResponse<PriceCalculationOfEducarInsuranceSearchResultDTO> response = new GenericRestResponse<PriceCalculationOfEducarInsuranceSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);

		return response;
	}

	/**
	 * The-K �����ں��� ���������� ���� �������� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/carDriver/selectTheKCarDriverInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheKCarDriverInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.THEK_DRIVER, LongTermInsurancePlanEnum.DRIVER_FREEDOM);
	}

	/**
	 * The-K �����ں��� ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/carDriver/selectTheKCarDriverInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheKCarDriverInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.THEK_DRIVER, LongTermInsurancePlanEnum.DRIVER_FREEDOM);
	}

	/**
	 * The-K ���غ��� ���������� ���� �������� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheKAccidentInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheKAccidentInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.DETRIMENT, LongTermInsurancePlanEnum.DETRIMENT_SYNTHESIZE);
	}

	/**
	 * The-K ���غ��� ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheKAccidentInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheKAccidentInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.DETRIMENT, LongTermInsurancePlanEnum.DETRIMENT_SYNTHESIZE);
	}

	/**
	 * The ū��� ��Ȱ���庸�� ���������� ���� �������� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheBigLoveLifeInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheBigLoveLifeInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.LIFE_GUARANTEE, LongTermInsurancePlanEnum.LIFE_GUARANTEE_FREEDOM);
	}

	/**
	 * The ū��� ��Ȱ���庸�� ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheBigLoveLifeInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheBigLoveLifeInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.LIFE_GUARANTEE, LongTermInsurancePlanEnum.LIFE_GUARANTEE_FREEDOM);
	}

	/**
	 * The �Ͼ�̼� ġ�ƺ��� ���������� ���� �������� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheWhiteSmileTeethInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheWhiteSmileTeethInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.HEALTH_INSURANCE, LongTermInsurancePlanEnum.HEALTH_INSURANCE_FREEDOM);
	}

	/**
	 * The �Ͼ�̼� ġ�ƺ��� ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheWhiteSmileTeethInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheWhiteSmileTeethInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.HEALTH_INSURANCE, LongTermInsurancePlanEnum.HEALTH_INSURANCE_FREEDOM);
	}

	/**
	 * The ��� ���ຸ�� ���������� ���� �������� �Ⱓ�� ��ȸ
	 *
	 * @param request sResno, sDriveClass
	 * @return List<LongTermInsurancePlanSearchResultDTO>
	 */
	@RequestMapping(value = "/savingsPensions/selectTheMoaSavingsInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheMoaSavingsInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.SAVINGS, LongTermInsurancePlanEnum.SAVINGS_FREEDOM);
	}

	/**
	 * The ��� ���ຸ�� ����� ���/����� �Ⱓ�� ��ȸ
	 *
	 * @param request
	 * @return List<CalculationOfCarInsuranceResultDTO>
	 */
	@RequestMapping(value = "/savingsPensions/selectTheMoaSavingsInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheMoaSavingsInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.SAVINGS, LongTermInsurancePlanEnum.SAVINGS_FREEDOM);
	}
	/**
	 * ��)The-K �츮�� ȭ�纸�� - ���������� ���� �������� �Ⱓ�� ��ȸ
	 *
	 * @param request sResno, sDriveClass
	 * @return List<LongTermInsurancePlanSearchResultDTO>
	 */
	@RequestMapping(value = "/enterpriseWealth/selectHouseFireInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectHouseFireInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		return this.selectLongTermInsurancList(request, InsuranceProductEnum.HOUSEFIRE, LongTermInsurancePlanEnum.HOUSEFIRE_FREEDOM);
	}
	/**
	 *(��)The-K �츮�� ȭ�纸�� - ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/enterpriseWealth/selectHouseFireInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectHouseFireInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		return this.selectLongTermCalculation(request, InsuranceProductEnum.HOUSEFIRE, LongTermInsurancePlanEnum.HOUSEFIRE_FREEDOM);
	}
	/**
	 * The-K ��������ǰ����� - �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheKFamilyLoveInsuranceList")
	@ResponseBody
	public GenericRestResponse<String> selectTheKFamilyLoveInsuranceList(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		
		final LongTermInsurancePlanSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		//�������� - 1�� �񰻽��� �̸� planEnum�� 03
		//             2�� �񰻽��� �̸� planEnum�� 13
		if(requestDto.getsGnrzCd().equals("01")){
			return this.selectLongTermInsurancList(request, InsuranceProductEnum.FAMILY_LOVE, LongTermInsurancePlanEnum.FAMILY_LOVE_ONE);
		}else{
			return this.selectLongTermInsurancList(request, InsuranceProductEnum.FAMILY_LOVE, LongTermInsurancePlanEnum.FAMILY_LOVE_TWO);
		}
	}
	
	/**
	 *  The-K ��������ǰ����� - ����� ���/����� �Ⱓ�� ��ȸ
	 */
	@RequestMapping(value = "/accidentHealth/selectTheKFamilyLoveInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectTheKFamilyLoveInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		final PriceCalculationOfLognTermInsuranceSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//�������� - 1�� �񰻽��� �̸� planEnum�� 03
		//             2�� �񰻽��� �̸� planEnum�� 13
		if(requestDto.getvLTIDA02().get(0).getsGnrzCd().equals("01")){
			return this.selectLongTermCalculation(request, InsuranceProductEnum.FAMILY_LOVE, LongTermInsurancePlanEnum.FAMILY_LOVE_ONE);
		}else{
			return this.selectLongTermCalculation(request, InsuranceProductEnum.FAMILY_LOVE, LongTermInsurancePlanEnum.FAMILY_LOVE_TWO);
		}
	}
	/**
	 * ���������� ��ǰ/�÷� Enumeration ������ ��⺸�� �������� �Ⱓ�踦 ��ȸ�Ѵ�.
	 * @param request ��⺸�� �÷���ȸ DTO
	 * @param goodsEnum ��⺸�� ��ǰ Enumeration
	 * @param planEnum ��⺸�� �÷� Enumeration
	 * @return ��⺸�� �������� ���
	 */
	private GenericRestResponse<String> selectLongTermInsurancList(final GenericRestRequest<LongTermInsurancePlanSearchDTO> request, final InsuranceProductEnum goodsEnum,
			final LongTermInsurancePlanEnum planEnum) {
		final LongTermInsurancePlanSearchDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		requestDTO.setsGdCd(goodsEnum.getCode()); // ��ǰ�ڵ�
		requestDTO.setsPlanCd(planEnum.getCode()); // �÷��ڵ�

		final String insurancePeriod = "1" + requestDTO.getsInsurTermCd();
		requestDTO.setsInsurTermCd(insurancePeriod); // ����Ⱓ
		requestDTO.setsPaymTermCd("99".equals(requestDTO.getsPaymCyclCd()) ? "000" : StringUtils.defaultString(requestDTO.getsPaymTermCd(), insurancePeriod)); // ���ԱⰣ

		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		final String resultDto = priceDisclosureBackBoneService.longTermInsurancePlanList(requestDTO);
		if (resultDto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, goodsEnum.getName() + " ��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(resultDto);
		}
		return response;
	}

	/**
	 * ��⺸��� ���� ������ ��ǰ/�÷� Enumeration ������ ��⺸�� ����Ḧ �����Ѵ�.
	 * @param request ��⺸��� ���� DTO
	 * @param goodsEnum ���� ��ǰ Enumeration
	 * @param planEnum ��⺸�� �÷� Enumeration
	 * @return ��⺸�� �����
	 */
	private GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> selectLongTermCalculation(final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request,
			final InsuranceProductEnum goodsEnum, final LongTermInsurancePlanEnum planEnum) {
		final PriceCalculationOfLognTermInsuranceSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		if (requestDto.getLTIDA00() == null || requestDto.getLTIDA01() == null || requestDto.getvLTIDA02() == null || requestDto.getvLTIDA02().isEmpty()) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.InvalidRequest)).build();
		}
		// ���� ��� ���� - �⺻ �� ����
		requestDto.getLTIDA00().setsApplPlanCd(planEnum.getCode()); // �÷��ڵ�
		requestDto.getLTIDA00().setsBunsMetdDocuClsfCd(planEnum.getCode()); // �������� �з��ڵ�
		requestDto.getLTIDA00().setsGdCd(goodsEnum.getCode()); // ��ǰ�ڵ�
		requestDto.getLTIDA00().setPaymentPeriod(requestDto.getLTIDA00().getsInsurTermCd()); // ���ԱⰣ (����)
		final String insurancePeriod = "1" + requestDto.getLTIDA00().getsInsurTermCd();
		requestDto.getLTIDA00().setsInsurTermCd(insurancePeriod); // ����Ⱓ
		requestDto.getLTIDA00().setsPaymTermCd("99".equals(requestDto.getLTIDA00().getsPaymCyclCd()) ? "000" : StringUtils.defaultString(requestDto.getLTIDA00().getsPaymTermCd(), insurancePeriod)); // ���ԱⰣ
		// �Ǻ����� - �⺻ �� ����
		requestDto.getLTIDA01().setsApplPlanCd(planEnum.getCode()); // �÷��ڵ�
		// ȭ�纸�� - �⺻ �� ���� 
		if(goodsEnum.getCode().equals(InsuranceProductEnum.HOUSEFIRE.getCode())){
			requestDto.getLTIDA00().setsDivCd("W");
			requestDto.getLTIDA00().setsMsgCd("");
			requestDto.getLTIDA00().setsMsg("");
			requestDto.getLTIDA00().setnInrpsPsct("1");
			
			requestDto.getLTIDA01().setnInrpsSeqno("1");
			requestDto.getLTIDA01().setsMinsrRelnCd("10");
			requestDto.getLTIDA01().setsCrtorRelnCd("10");
			
			requestDto.getLTIDA60().setnInsrdObjctSeqno("1");
			requestDto.getLTIDA60().setsSpclBuldgFlagCd("02");
			requestDto.getLTIDA60().setsApplPlanCd(planEnum.getCode());
			requestDto.getLTIDA60().setsRatoBntpCd(requestDto.getLTIDA60().getsInsBntpCd());
			requestDto.getLTIDA60().setsRatoBntpObjtFlagCd("01");
		}
		PriceCalculationOfLognTermInsuranceSearchResultDTO resultDto = null;
		// ��������� ���� ���� ��쿣 ���, ���� ��쿣 �����
		if (StringUtils.isBlank(requestDto.getLTIDA00().getnBussPrem())) {
			resultDto = priceDisclosureBackBoneService.calculateLongTermInsurance(requestDto);
		} else {
			resultDto = priceDisclosureBackBoneService.reCalculateLongTermInsurance(requestDto);
		}
		final GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO> response = new GenericRestResponse<PriceCalculationOfLognTermInsuranceSearchResultDTO>();
		if (resultDto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, goodsEnum.getName() + " ����� ���"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(resultDto);
		}
		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - ����ī �ڵ������迡�� ����ϴ� �⺻ �ڵ� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("/carDriver/selectDisplayCodeCar")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfCarInsuranceDTO> selectDisplayCodeCar(final @NotNull @RequestBody GenericRestRequest<String> request) {
		final String sInsType = request.getRequestData().get(BigInteger.ZERO.intValue());

		final PriceCalculationOfCarInsuranceDTO dto = priceDisclosureBackBoneService.getDisplayCode(this.getPriceCalculationOfCarInsuranceTypeEnum(sInsType));

		if (dto == null) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.SelectEmpty), ResponseStatusEnum.DEFAULT_ERROR);
		}

		final GenericRestResponse<PriceCalculationOfCarInsuranceDTO> response = new GenericRestResponse<PriceCalculationOfCarInsuranceDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(this.setCarCodeUninsured(dto));

		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - ����ī �ڵ������迡�� �����ڵ�� �ڵ��� �ڵ�(sVehicleCode)�� ����Ͽ� ����ڵ带 ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/carDriver/selectDisplayCareerCode")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfCarInsuranceCareerDTO> selectDisplayCareerCode(final @NotNull @RequestBody GenericRestRequest<CalculationOfCarInsuranceParamDTO> request) {
		final CalculationOfCarInsuranceParamDTO calculationOfCarInsuranceParamDTO = request.getRequestData().get(BigInteger.ZERO.intValue());

		final String sInsType = calculationOfCarInsuranceParamDTO.getsInsType();
		final String sVehicleCode = calculationOfCarInsuranceParamDTO.getsVehicleCode();

		if (StringUtils.isBlank(sVehicleCode)) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.InvalidRequest), ResponseStatusEnum.DEFAULT_ERROR);
		}

		final PriceCalculationOfCarInsuranceCareerDTO dto = priceDisclosureBackBoneService.getDisplayCareerCode(this.getPriceCalculationOfCarInsuranceTypeEnum(sInsType), sVehicleCode);

		if (dto == null) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.SelectEmpty), ResponseStatusEnum.DEFAULT_ERROR);
		}

		final GenericRestResponse<PriceCalculationOfCarInsuranceCareerDTO> response = new GenericRestResponse<PriceCalculationOfCarInsuranceCareerDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);

		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - �ڵ�������(���ο�,������,������,�̷�) ����
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/carDriver/selectCalculationCar")
	@ResponseBody
	public GenericRestResponse<CalculationOfCarInsuranceResultDTO> selectCalculationCar(final @NotNull @RequestBody GenericRestRequest<CalculationOfCarInsuranceParamDTO> request) {
		final CalculationOfCarInsuranceResultDTO dto = priceDisclosureBackBoneService.calculateCarInsurance(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<CalculationOfCarInsuranceResultDTO> response = new GenericRestResponse<CalculationOfCarInsuranceResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);

		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - �ε���Ǹ����� ����
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/realEstate/selectCalculationRealEstate")
	@ResponseBody
	public GenericRestResponse<String> selectCalculationRealEstate(final @NotNull @RequestBody GenericRestRequest<String> request) {
		final String result = priceDisclosureBackBoneService.calculateRealEstateInsurance(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);
		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - �������ڵ������� - �ڵ� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("/oneDay/selectOneDayCodeList")
	@ResponseBody
	public GenericRestResponse<OneDayCodeSearchResultDTO> selectOneDayCodeList() {
		final OneDayCodeSearchResultDTO dto = priceDisclosureBackBoneService.oneDayCodeList();
		if (dto == null) {
			logger.error("������(���ý�) �ڵ� ��ȸ ����");
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.SelectEmpty), ResponseStatusEnum.DEFAULT_ERROR);
		}
		final GenericRestResponse<OneDayCodeSearchResultDTO> response = new GenericRestResponse<OneDayCodeSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���ݰ��� - �������ڵ������� - �ܼ������ ���
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/oneDay/selectCalculationOneDayCar")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfOneDayInsuranceSearchResultDTO> selectCalculationOneDayCar(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfOneDayInsuranceSearchDTO> request, final HttpSession session) {
		final PriceCalculationOfOneDayInsuranceSearchResultDTO dto = priceDisclosureBackBoneService.calculateOneDayInsurance(request.getRequestData().get(BigInteger.ZERO.intValue()),
				sessionService.getUserID(session));
		final GenericRestResponse<PriceCalculationOfOneDayInsuranceSearchResultDTO> response = new GenericRestResponse<PriceCalculationOfOneDayInsuranceSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}
	/**
	 * <pre>
	 * ���ݰ��� - ���/�繰 - ����ȭ�纸��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("/realEstate/selectGetFirPremWeb")
	@ResponseBody
	public GenericRestResponse<HouseFirePremWebDTO> selectGetFirPremWeb(@NotNull @RequestBody final GenericRestRequest<HouseFirePremWebDTO> request, final HttpSession session) {
		
		final HouseFirePremWebDTO dto = priceDisclosureBackBoneService.calculateHouseFire(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<HouseFirePremWebDTO> response = new GenericRestResponse<HouseFirePremWebDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}
	/**
	 * <pre>
	 * ������ �̰���/���� �߰�
	 * �������� - �ڱ�δ�� �ִ밪 0 �� ����
	 * <pre>
	 * @param dto
	 * @return
	 */
	private PriceCalculationOfCarInsuranceDTO setCarCodeUninsured(final PriceCalculationOfCarInsuranceDTO dto) {
		List<PriceCalculationOfCarInsuranceCodeDTO> codeList = new ArrayList<PriceCalculationOfCarInsuranceCodeDTO>();
		PriceCalculationOfCarInsuranceCodeDTO codeDTO = new PriceCalculationOfCarInsuranceCodeDTO();

		// ������ �̰���/���� �߰� => ���� �ڵ尪�� �ȳѾ���� ������ �Ѿ���� �κи� üũ
		codeList = dto.getvSpecCode0111();
		if (codeList == null || codeList.isEmpty()) {
			codeList = new ArrayList<PriceCalculationOfCarInsuranceCodeDTO>();
			// �̰��� �ڵ� �߰�
			codeDTO.setsMainCode("00");
			codeDTO.setsShortName("�̰���");
			codeList.add(codeDTO);
			// ���� �ڵ� �߰�

			codeDTO = new PriceCalculationOfCarInsuranceCodeDTO();
			codeDTO.setsMainCode("99");
			codeDTO.setsShortName("����");
			codeList.add(codeDTO);

			dto.setvSpecCode0111(codeList);
		}

		// �������� - �ڱ�δ�� �ִ밪 �̰��� ����
		// (�Ⱓ�迡�� �̰��Կ� ���� �ڵ尡 �Ѿ������ sOptName(selectBox Label ǥ�� ���� ����) ���� ó��)
		codeList = dto.getDeductMaxDoc();
		if (codeList != null && !codeList.isEmpty() && StringUtils.isBlank(codeList.get(BigInteger.ZERO.intValue()).getsOptName())) {
			codeList.remove(BigInteger.ZERO.intValue());
		}

		return dto;
	}

	/**
	 * <pre>
	 * �����ڵ�� PriceCalculationOfCarInsuranceTypeEnum�� ���Ѵ�.
	 * <pre>
	 * @param sInsType
	 * @return
	 */
	private PriceCalculationOfCarInsuranceTypeEnum getPriceCalculationOfCarInsuranceTypeEnum(final String sInsType) {
		final PriceCalculationOfCarInsuranceTypeEnum type = PriceCalculationOfCarInsuranceTypeEnum.getEnumFromCode(sInsType);

		if (type == null) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.InvalidRequest), ResponseStatusEnum.DEFAULT_ERROR);
		}

		return type;
	}
	
	/**
	 * <pre>
	 * Theū�ູ���ݺ��� - �ڵ� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("theBigHappy/selectAnnCommCode")
	@ResponseBody
	public GenericRestResponse<LongAnntCommCodeWrapperDTO> selectAnnCommCode(@RequestBody final GenericRestRequest<LongAnntCommCodeWrapperDTO> request) {
		final LongAnntCommCodeWrapperDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		requestDto.setsGdCd(InsuranceProductEnum.BIGHAPPY.getCode());
		requestDto.setsPlanCd(LongTermInsurancePlanEnum.BIG_HAPPY_BASIC.getCode());
		requestDto.setsStndDate(currentDate);
		final LongAnntCommCodeWrapperDTO codeList = priceDisclosureBackBoneService.getAnntCommCode(requestDto);
	
		final GenericRestResponse<LongAnntCommCodeWrapperDTO> response = new GenericRestResponse<LongAnntCommCodeWrapperDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(codeList);
		return response;
	}
	/**
	 * Theū�ູ���ݺ��� - �÷���ȸ
	 *
	 * @param request sResno, sDriveClass
	 * @return List<LongTermInsurancePlanSearchResultDTO>
	 */
	@RequestMapping(value = "/theBigHappy/selectAnntPlanTrty")
	@ResponseBody
	public GenericRestResponse<LongTermInsurancePlanSearchResultDTO> selectAnntPlanTrty(@NotNull @RequestBody final GenericRestRequest<LongTermInsurancePlanSearchDTO> request) {
		
		final LongTermInsurancePlanSearchDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		requestDTO.setsGdCd( InsuranceProductEnum.BIGHAPPY.getCode()); // ��ǰ�ڵ�
		requestDTO.setsPlanCd(LongTermInsurancePlanEnum.BIG_HAPPY_BASIC.getCode()); // �÷��ڵ�
		requestDTO.setsStndDate(currentDate);

		//final String insurancePeriod = "1" + requestDTO.getsInsurTermCd();
		//requestDTO.setsInsurTermCd(insurancePeriod); // ����Ⱓ
		//requestDTO.setsPaymTermCd("99".equals(requestDTO.getsPaymCyclCd()) ? "000" : StringUtils.defaultString(requestDTO.getsPaymTermCd(), insurancePeriod)); // ���ԱⰣ

		final GenericRestResponse<LongTermInsurancePlanSearchResultDTO> response = new GenericRestResponse<LongTermInsurancePlanSearchResultDTO>();
		final LongTermInsurancePlanSearchResultDTO resultDto = priceDisclosureBackBoneService.getAnntPlanList(requestDTO);
		if (resultDto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty,  InsuranceProductEnum.BIGHAPPY.getName() + " ��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(resultDto);
		}
		return response;
		
	}
	/**
	 * Theū�ູ���ݺ��� ���/����� �Ⱓ�� ��ȸ
	 *
	 * @param request
	 * @return List<CalculationOfCarInsuranceResultDTO>
	 */
	@RequestMapping(value = "/theBigHappy/selectTheBigHappyInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<PriceCalculationOfRtnAmtDtalSearchResultDTO> selectTheBigHappyInsuranceCalculation(
			@NotNull @RequestBody final GenericRestRequest<PriceCalculationOfLognTermInsuranceSearchDTO> request) {
		
		final PriceCalculationOfLognTermInsuranceSearchDTO requestDto = request.getRequestData().get(BigInteger.ZERO.intValue());
		if (requestDto.getLTIDA00() == null || requestDto.getLTIDA01() == null || requestDto.getvLTIDA02() == null || requestDto.getvLTIDA02().isEmpty()) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.InvalidRequest)).build();
		}
		// ���� ��� ���� - �⺻ �� ����
		requestDto.getLTIDA00().setsApplPlanCd(LongTermInsurancePlanEnum.BIG_HAPPY_BASIC.getCode()); // �÷��ڵ�
		requestDto.getLTIDA00().setsGdCd(InsuranceProductEnum.BIGHAPPY.getCode()); // ��ǰ�ڵ�
		requestDto.getLTIDA00().setPaymentPeriod(requestDto.getLTIDA00().getsInsurTermCd()); // ���ԱⰣ (����)
		final String insurancePeriod = requestDto.getLTIDA00().getsInsurTermCd();
		requestDto.getLTIDA00().setsInsurTermCd(insurancePeriod); // ����Ⱓ
		requestDto.getLTIDA00().setsPaymTermCd("99".equals(requestDto.getLTIDA00().getsPaymCyclCd()) ? "000" : StringUtils.defaultString(requestDto.getLTIDA00().getsPaymTermCd(), insurancePeriod)); // ���ԱⰣ
		// �Ǻ����� - �⺻ �� ����
		requestDto.getLTIDA01().setsApplPlanCd(LongTermInsurancePlanEnum.BIG_HAPPY_BASIC.getCode()); // �÷��ڵ�
		//���󸸱�ȯ�ޱ�, ����ȯ�ޱ� ��ȸ
		PriceCalculationOfRtnAmtDtalSearchResultDTO rtnAmtDto = priceDisclosureBackBoneService.selectRtnAmtDtalWeb(requestDto);
		
		final GenericRestResponse<PriceCalculationOfRtnAmtDtalSearchResultDTO> response = new GenericRestResponse<PriceCalculationOfRtnAmtDtalSearchResultDTO>();
		if (rtnAmtDto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, InsuranceProductEnum.BIGHAPPY.getName() + " ����� ���"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(rtnAmtDto);
		}
		return response;
		
	}
}
