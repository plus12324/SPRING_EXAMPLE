/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.claim;

import java.io.IOException;
import java.io.Writer;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.educar.admin.dto.memberMng.AdminMemberInfoListDTO;
import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FTPService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.dto.web.claim.AISCodeDTO;
import com.educar.dto.web.claim.AcctRegiInfoOfBaseInfoDTO;
import com.educar.dto.web.claim.AcctRegiInfoOfVictimInfoDTO;
import com.educar.dto.web.claim.AcctRegiInfoSearchDTO;
import com.educar.dto.web.claim.AcctRegiInfoSearchResultDTO;
import com.educar.dto.web.claim.CarClaimEmailMonitorDTO;
import com.educar.dto.web.claim.CheckAccidentSearchDTO;
import com.educar.dto.web.claim.CheckAccidentSearchResultDTO;
import com.educar.dto.web.claim.ClaimCodeDTO;
import com.educar.dto.web.claim.ClaimCodeListDTO;
import com.educar.dto.web.claim.ClaimPolicyDTO;
import com.educar.dto.web.claim.ClaimSearchOfClmcDTO;
import com.educar.dto.web.claim.ClaimSearchResultDTO;
import com.educar.dto.web.claim.ContractDataSearchDTO;
import com.educar.dto.web.claim.ContractDataSearchResultDTO;
import com.educar.dto.web.claim.InsuredCodeWebResultDTO;
import com.educar.dto.web.claim.SelectAccidentListWebResultDTO;
import com.educar.dto.web.claim.SelectAccidentPhotoListWebResultDTO;
import com.educar.dto.web.claim.StaffInfoWebResultDTO;
import com.educar.enumeration.ClaimCodeTypeEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.ClaimBackBoneService;
import com.educar.service.backbone.LoginBackBoneService;
import com.educar.service.web.CertificationService;
import com.educar.service.web.ClaimService;

/**
 * <pre>
 * 	���󼭺� - �ڵ������� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("carClaim")
@Controller
public class CarClaimController {
	/** logger **/
	private final Logger logger = Logger.getLogger(getClass());
	/** �޽��� ���� **/
	@Autowired
	private MessageSourceService messageService;
	/** ���� ���� **/
	@Autowired
	private SessionService sessionService;
	/** ���󼭺� ���� **/
	@Autowired
	private ClaimBackBoneService claimBackBoneService;
	/** �ڵ��� ���� ������� ����(��������)**/
	@Autowired
	private ClaimService claimService;
	/** �α��� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private LoginBackBoneService loginServiceBackBone;
	/** ftp���� **/
	@Autowired
	private FTPService ftpService;
	/** ���� ���� */
	@Autowired
	private CertificationService certificationService;
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	
	
	/**
	 * <pre>
	 * ���󼭺� - �ڵ������� - ���󳻿���ȸ - ����ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectCarClaimDetail")
	@ResponseBody
	public GenericRestResponse<ClaimSearchResultDTO> selectCarDetail(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final ClaimSearchResultDTO dto = claimBackBoneService.claimSearch(request.getRequestData().get(BigInteger.ZERO.intValue()), Boolean.TRUE);

		// ��ȸ ������ ������ exception ó��
		if (dto == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.INDEX).build();
		}
		// �ֹι�ȣ * ó��
		dto.getClmc001().setsInsuredCode(SsnAsteriskConvert.getSsnAsterisk(dto.getClmc001().getsInsuredCode(), Boolean.TRUE));
		// �㺸 ���� (�� �㺸�� 1, 0 ���� ���� ó��)
		dto.getClmc001().setsAcctPawn();
		final List<ClaimSearchOfClmcDTO> carCompensationList = new ArrayList<ClaimSearchOfClmcDTO>();
		carCompensationList.addAll(dto.getClmcc01());
		carCompensationList.addAll(dto.getClmcd01());
		dto.setCarClaimList(carCompensationList);
		dto.setClmcc01(null);
		dto.setClmcd01(null);
		final GenericRestResponse<ClaimSearchResultDTO> response = new GenericRestResponse<ClaimSearchResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���غ��� �ڵ� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("selectClaimCode")
	@ResponseBody
	public GenericRestResponse<ClaimCodeDTO> selectCarDetail() {
		final List<ClaimCodeDTO> resultList = claimBackBoneService.selectCodeDiv3(ClaimCodeTypeEnum.WOUND_REGION);
		final GenericRestResponse<ClaimCodeDTO> response = new GenericRestResponse<ClaimCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ���ر޼� ã�� : ���غ���, �λ�޼�, ���ܸ����� �ѵ� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectInjuryLimitAmt")
	@ResponseBody
	public GenericRestResponse<AISCodeDTO> selectInjuryLimitAmt(@NotNull @RequestBody final GenericRestRequest<AISCodeDTO> request) {
		final AISCodeDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<AISCodeDTO> resultList = claimBackBoneService.selectAISCode(inputDTO.getsInjrClause(), inputDTO.getsInjrGrade(), inputDTO.getsAisName());
		final GenericRestResponse<AISCodeDTO> response = new GenericRestResponse<AISCodeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * �������Ȯ�μ� �߱� ����Ʈ ��ȸ
	 * @param session
	 * @return
	 */
	@RequestMapping("selectAccidentalDamage")
	@ResponseBody
	public GenericRestResponse<InsuredCodeWebResultDTO> selectAccidentalDamage(final HttpSession session) {
		final String ssn = sessionService.getSSNFromSession(session);
		final List<InsuredCodeWebResultDTO> resultList = claimBackBoneService.selectInsuredCodeWeb(ssn);

		final GenericRestResponse<InsuredCodeWebResultDTO> response = new GenericRestResponse<InsuredCodeWebResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}

	/**
	 * �������Ȯ�μ� �߱� ����Ʈ ��ȸ
	 * @param session
	 * @return
	 */
	@RequestMapping("selectAccidentalDamageStaff")
	@ResponseBody
	public GenericRestResponse<StaffInfoWebResultDTO> selectAccidentalDamageStaff(@NotNull @RequestBody final GenericRestRequest<String> request) {

		final StaffInfoWebResultDTO result = claimBackBoneService.selectStaffInfoWeb(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<StaffInfoWebResultDTO> response = new GenericRestResponse<StaffInfoWebResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}

	/**
	 * ������� ��� ��� ����
	 * @param session
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("getPolicyList")
	@ResponseBody
	public GenericRestResponse<ClaimPolicyDTO> getPolicyList(final HttpSession session) {

		final String ssn = sessionService.getSSNFromSession(session);
		final List<ClaimPolicyDTO> result = claimBackBoneService.getPolicyListForWeb(ssn);

		final GenericRestResponse<ClaimPolicyDTO> response = new GenericRestResponse<ClaimPolicyDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);

		return response;
	}

	/**
	 * ������� ���� ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("checkAccident")
	@ResponseBody
	public GenericRestResponse<CheckAccidentSearchResultDTO> checkAccident(@NotNull @RequestBody final GenericRestRequest<CheckAccidentSearchDTO> request) {

		final List<CheckAccidentSearchResultDTO> result = claimBackBoneService.checkAccident(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<CheckAccidentSearchResultDTO> response = new GenericRestResponse<CheckAccidentSearchResultDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);

		return response;
	}

	/**
	 * ���谡����(�Ǻ�����)�� ������ ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("contractDataSearch")
	@ResponseBody
	public GenericRestResponse<ContractDataSearchResultDTO> contractDataSearch(@NotNull @RequestBody final GenericRestRequest<ContractDataSearchDTO> request) {

		final ContractDataSearchResultDTO result = claimBackBoneService.getContractData(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<ContractDataSearchResultDTO> response = new GenericRestResponse<ContractDataSearchResultDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}

	/**
	 * ���󼭺� step3 �ڵ� ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("selectCodeDiv3")
	@ResponseBody
	public GenericRestResponse<ClaimCodeListDTO> selectCodeDiv3() {

		// �Ǻ����ڿ��� ����
		final List<ClaimCodeDTO> resultRELATION = claimBackBoneService.selectCodeDiv3(ClaimCodeTypeEnum.RELATION);
		// ���������ڵ�
		final List<ClaimCodeDTO> resultLICENSE = claimBackBoneService.selectCodeDiv3(ClaimCodeTypeEnum.LICENSE);
		// �㺸�ڵ�
		final List<ClaimCodeDTO> resultPAWN = claimBackBoneService.selectCodeDiv3(ClaimCodeTypeEnum.PAWN);

		final ClaimCodeListDTO result = new ClaimCodeListDTO();

		result.setRELATION(resultRELATION);
		result.setLICENSE(resultLICENSE);
		result.setPAWN(resultPAWN);

		final GenericRestResponse<ClaimCodeListDTO> response = new GenericRestResponse<ClaimCodeListDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}

	/**
	 * ���󼭺� �������  step3  
	 * @param request
	 * @return
	 * @author �Ž¿�
	 * @throws Exception 
	 */
	@RequestMapping("insertAcctRegiInfo")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.claim.AcctRegiInfoOfVictimInfoDTO", "sVictimCelTel1", "sVictimCelTel2", "sVictimCelTel3" }, register = CheckHTelNum.class)
	public GenericRestResponse<AcctRegiInfoSearchResultDTO> insertAcctRegiInfo(final HttpServletRequest servletRequest, @NotNull @Validate @RequestBody final GenericRestRequest<AcctRegiInfoSearchDTO> request) throws Exception {

		final String sUserID = sessionService.getUserID(servletRequest.getSession());

		final String sSSN = sessionService.getSSNFromSession(servletRequest.getSession());

		final AcctRegiInfoSearchDTO InputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final AcctRegiInfoOfBaseInfoDTO BaseInfoDTO = InputDTO.getBaseInfo();
		
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId(sessionService.getUserID(servletRequest.getSession()));
		//�� ���θ� ǥ���ּ� 
		//����� �ּ�
		if(BaseInfoDTO.getsStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(BaseInfoDTO.getsAddrMgtNo());
			stndAddrDto.setVarPost(BaseInfoDTO.getsAcctZip1()+BaseInfoDTO.getsAcctZip2());
			stndAddrDto.setVarAllAddress(BaseInfoDTO.getsDoroAddr1() + BaseInfoDTO.getsAcctAddr2());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);
			BaseInfoDTO.setsAcctAddr1(resultAdr.getAnlysStndRdNmHighAddrA());
			BaseInfoDTO.setsAcctAddr2(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
		
		final String strDrvSocNo1 = BaseInfoDTO.getsDrvSocNo1();
		final String strDrvSocNo2 = certificationService.touchenKeyDec(BaseInfoDTO.getsHid_key_data(), BaseInfoDTO.getsDrvSocNo2(), servletRequest.getSession());
		
		BaseInfoDTO.setsDrvSocNo(strDrvSocNo1+strDrvSocNo2);
		logger.debug("Ű���� ���� >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> strDrvSocNo2 : " + BaseInfoDTO.getsDrvSocNo());
		
		BaseInfoDTO.setsInsuredCode(sSSN);
		InputDTO.setBaseInfo(BaseInfoDTO);

		final AcctRegiInfoSearchResultDTO result = claimService.insertAcctRegiInfo(InputDTO, sUserID);

		final GenericRestResponse<AcctRegiInfoSearchResultDTO> response = new GenericRestResponse<AcctRegiInfoSearchResultDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);

		return response;
	}

	/**
	 * ��ȭ��ȣ üũ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("checkPhoneNum")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.claim.AcctRegiInfoOfVictimInfoDTO", "sVictimCelTel1", "sVictimCelTel2", "sVictimCelTel3" }, register = CheckHTelNum.class)
	public GenericRestResponse<AcctRegiInfoOfVictimInfoDTO> checkPhoneNum(@NotNull @Validate @RequestBody final GenericRestRequest<AcctRegiInfoOfVictimInfoDTO> request) {

		final GenericRestResponse<AcctRegiInfoOfVictimInfoDTO> response = new GenericRestResponse<AcctRegiInfoOfVictimInfoDTO>();

		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**���󼭺� �ڵ�������(����������) �����ȸ
	 * @param request
	 * @return
	 * @author �Ž¿� 
	 */
	@RequestMapping("selectAccidentListWeb")
	@ResponseBody
	public GenericRestResponse<SelectAccidentListWebResultDTO> selectAccidentListWeb(@NotNull @Validate @RequestBody final GenericRestRequest<SelectAccidentPhotoListWebResultDTO> request) {

		final SelectAccidentPhotoListWebResultDTO InputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<SelectAccidentListWebResultDTO> result = claimBackBoneService.selectAccidentListWeb(InputDTO.getsCarNo(), InputDTO.getsAcctRegiDate());
		final GenericRestResponse<SelectAccidentListWebResultDTO> response = new GenericRestResponse<SelectAccidentListWebResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);

		return response;
	}

	/**���󼭺� �ڵ�������(����������) ������
	 * @param request
	 * @return
	 * @author �Ž¿� 
	 */
	@RequestMapping("carClaimImageRegist")
	@ResponseBody
	public GenericRestResponse<SelectAccidentListWebResultDTO> carClaimImageRegist(@NotNull @Validate @RequestBody final GenericRestRequest<SelectAccidentListWebResultDTO> request) {

		claimService.carClaimImageRegist(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<SelectAccidentListWebResultDTO> response = new GenericRestResponse<SelectAccidentListWebResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());

		return response;
	}

	/**���󼭺� �ڵ������� ������� ���� ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿� 
	 */
	@RequestMapping("selectAccidentPhotoListWeb")
	@ResponseBody
	public GenericRestResponse<SelectAccidentPhotoListWebResultDTO> selectAccidentPhotoListWeb(@NotNull @Validate @RequestBody final GenericRestRequest<SelectAccidentPhotoListWebResultDTO> request) {

		final SelectAccidentPhotoListWebResultDTO InputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<SelectAccidentPhotoListWebResultDTO> result = claimBackBoneService.selectAccidentPhotoListWeb(InputDTO.getsCarNo(), InputDTO.getsAcctRegiDate());
		final GenericRestResponse<SelectAccidentPhotoListWebResultDTO> response = new GenericRestResponse<SelectAccidentPhotoListWebResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);

		return response;
	}

	/**�ڵ������� ������������ �ٿ�ε�
	 * @param request
	 * @return
	 * @author �Ž¿�
	 * @throws IOException 
	 */
	@RequestMapping("/downloadCarAccidentPicture")
	@ResponseBody
	public void downloadCarAccidentPicture(@RequestParam(value = "fileName") final String fileName, @RequestParam(value = "filePath") final String filePath, final HttpServletResponse response) throws IOException {
		
		final String remoteFilePath = filePath + '/' + fileName;
		
		final FTPConnectionInfoVO connectionVO = ftpService.getImageServerConnectionInfo();
		final byte[] file = ftpService.download(connectionVO, remoteFilePath  );
		final int fileLength = file.length;
		response.setBufferSize(fileLength);
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		response.setContentLength(fileLength);
		// output stream�� ������ write�Ѵ�.
		FileCopyUtils.copy(file, response.getOutputStream());
		// bis.close();
		response.getOutputStream().flush();
		response.getOutputStream().close();
	}
	
	/**
	 * �ڵ������� ����ó�� �̸��� ����͸� ȭ��
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("emailMonitor")
	public ModelAndView beginEmailMonitor(final HttpSession session, final String sAccidentNo, final String sEmailID) throws Exception{

		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("survey/carClaimEmailMonitor.jsp");
		mav.addObject("sAccidentNo" , sAccidentNo);
		mav.addObject("sEmailID" , sEmailID);

		return mav;
	}
	/**
	 *  
	 * �ڵ������� ����ó�� �̸��� ����͸� �Է�ó��
	 * �����ʿ����.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping("insertEmailMonitor")
	public void insertEmailMonitor(final HttpServletResponse response, final CarClaimEmailMonitorDTO request) throws Exception {
		
		final String resultValue  = claimBackBoneService.insertEmailMonitor(request);
		
		StringBuffer sb = new StringBuffer();
		response.setCharacterEncoding("euc-kr");
    	response.setHeader("Cache-Control", "no-cache");
    	Writer writer = response.getWriter();
    	sb.append("������ �����ּż� �����մϴ�.");
		writer.write(sb.toString());
    	writer.flush();
		
	}
}