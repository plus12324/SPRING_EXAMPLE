/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dto.web.RecCampInfoDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.OnePageEventService;



/**
 * <pre>
 * ��������õķ����
 * <pre>
 * @author �Ž¿�
 *
 */
@Controller
@RequestMapping("/OnePageEvent")
public class OnePageEventController {
	
	/** ���������̺�Ʈ ����*/
	@Autowired
	private OnePageEventService onePageEventService;
	
	/**
	 * <pre>
	 * ������ȣ ��ȸ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "searchRecCampsPlateNoInfo")
	public ModelMap searchRecCampsPlateNoInfo(final RecCampInfoDTO request) {
		
		final String sPlateNo = onePageEventService.searchRecCampsPlateNoInfo(request);
		
		final ModelMap modelMap = new ModelMap();
		return modelMap;
	}
}
