/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Document;

import com.educar.common.dto.MMSSendDTO;
import com.educar.common.dto.SMSSendDTO;
import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.dao.EventDAO;
import com.educar.dto.web.CertificationPopParamDTO;
import com.educar.dto.web.CustomerCancelPollInputListDTO;
import com.educar.dto.web.CustomerSatisfactionInputDTO;
import com.educar.dto.web.Event10AnniversaryDTO;
import com.educar.dto.web.EventDTO;
import com.educar.dto.web.EventTaskDTO;
import com.educar.dto.web.EventWinnerDTO;
import com.educar.dto.web.TheKFellowInfoDTO;
import com.educar.dto.web.TheKPreferenceInfoDTO;
import com.educar.dto.web.products.ConsultationRequestDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.EventBackBoneService;
import com.educar.service.backbone.SendBackBoneService;
import com.educar.service.web.EventService;
import com.educar.service.web.InsuranceProductsService;
import com.inswave.util.XMLUtil;

/**
 * <pre>
 * �̺�Ʈ ��Ʈ�ѷ�
 * <pre>
 * @author ��â��
 *
 */
@Controller
@RequestMapping("/event")
public class EventController {
	@Autowired
	private EventBackBoneService eventBackBoneService;
	/** �̺�Ʈ ���� */
	@Autowired
	private EventService eventService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;
	/** �Ⱓ�� task ȣ�� */
	@Autowired
	private InsuranceProductsService insuranceProductsService;
	/** ���� ���� **/
	@Autowired
	private SessionService sessionService;
	/** logger **/
	private final Logger logger = Logger.getLogger(getClass());
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	@Autowired
	private EventDAO newEventDAO;
	
	/** SMS / �̸��� �߼� ���� */
	@Autowired
	private SendBackBoneService sendBackBoneService;
	
	/**
	 * �������� �̺�Ʈ ��� ��ȸ
	 * @return <EventDTO> �������� �̺�Ʈ ����Ʈ
	 */
	@RequestMapping("selectEventList")
	@ResponseBody
	public GenericRestResponse<EventDTO> selectEventList(@NotNull @RequestBody final GenericRestRequest<EventDTO> request) {
		final EventDTO eventDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		// Ȩ������ �̺�Ʈ�� ��ȸ AC_CD 05000 ���� ����
		eventDTO.setAC_CD("05000");
		final List<EventDTO> eventList = eventService.selectEventList(eventDTO);
		final GenericRestResponse<EventDTO> response = new GenericRestResponse<EventDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(eventList);
		return response;
	}

	/**
	 * �������� �̺�Ʈ �� ���� ��ȸ
	 * @param <EventDTO> 
	 * @return <EventDTO> �󼼳���
	 */
	@RequestMapping(value = "selectEventView")
	@ResponseBody
	public GenericRestResponse<EventDTO> selectEventView(@RequestBody final GenericRestRequest<EventDTO> request) {
		final EventDTO dto = eventService.selectEventView(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<EventDTO> response = new GenericRestResponse<EventDTO>();
		if (dto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "�������� �̺�Ʈ"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(dto);
		}
		return response;
	}

	/**
	 * ���� �̺�Ʈ ��� ��ȸ
	 * @return <EventDTO> �󼼳���
	 */
	@RequestMapping("selectPastEventList")
	@ResponseBody
	public GenericRestResponse<EventDTO> selectPastEventList(@NotNull @RequestBody final GenericRestRequest<EventDTO> request) {
		final List<EventDTO> pastEventList = eventService.selectPastEventList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<EventDTO> response = new GenericRestResponse<EventDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(pastEventList);
		return response;
	}

	/**
	 * <pre>
	 * �̺�Ʈ ��÷�� ��ȸ(�� DB)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEventWinner")
	@ResponseBody
	public GenericRestResponse<EventWinnerDTO> selectEventWinner(@NotNull @RequestBody final GenericRestRequest<EventWinnerDTO> request) {
		final EventWinnerDTO dto = eventService.selectEventWinner(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<EventWinnerDTO> response = new GenericRestResponse<EventWinnerDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}
	
	/**
	 * <pre>
	 * �̺�Ʈ ��÷�� ��ȸ(���� �������̽�)
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEventWinnerFromCustomer")
	@ResponseBody
	public GenericRestResponse<EventWinnerDTO> selectEventWinnerFromCustomer(@NotNull @RequestBody final GenericRestRequest<EventWinnerDTO> request) {
		
		final EventWinnerDTO eventWinnerDTO = eventBackBoneService.selectWinYn(request.getRequestData().get(BigInteger.ZERO.intValue()));
		if( "Y".equals(eventWinnerDTO.getsWinYn())){
			final EventWinnerDTO outputDTO = newEventDAO.selectEventWinnerProduct(request.getRequestData().get(BigInteger.ZERO.intValue()));
			if("1".equals(eventWinnerDTO.getsWinRank())){
				eventWinnerDTO.setsWinProduct(outputDTO.getPRIZE01());
			}else if("2".equals(eventWinnerDTO.getsWinRank())){
				eventWinnerDTO.setsWinProduct(outputDTO.getPRIZE02());
			}else if("3".equals(eventWinnerDTO.getsWinRank())){
				eventWinnerDTO.setsWinProduct(outputDTO.getPRIZE03());
			}else if("4".equals(eventWinnerDTO.getsWinRank())){
				eventWinnerDTO.setsWinProduct(outputDTO.getPRIZE04());
			}else if("5".equals(eventWinnerDTO.getsWinRank())){
				eventWinnerDTO.setsWinProduct(outputDTO.getPRIZE05());
			}
		}
		
		final GenericRestResponse<EventWinnerDTO> response = new GenericRestResponse<EventWinnerDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(eventWinnerDTO);
		return response;
	}
	
	
	/**
	 * <pre>
	 * ntaskID ȣ�� �̺�Ʈ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("eventInsertCallOutBound")
	@ResponseBody
	public void eventInsertCallOutBound(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EventTaskDTO> request) {
		
		// ���� �ð�
		final DateTime dt = new DateTime();
		final String sUserID = sessionService.getUserID(session);
		final EventTaskDTO eventTaskDTO  = request.getRequestData().get(BigInteger.ZERO.intValue());
		final ConsultationRequestDTO dto = new ConsultationRequestDTO();
		dto.setsName(eventTaskDTO.getsName());
		dto.setsCellPhone1(eventTaskDTO.getsCellPhone1());
		dto.setsCellPhone2(eventTaskDTO.getsCellPhone2());
		dto.setsCellPhone3(eventTaskDTO.getsCellPhone3());
		
		insuranceProductsService.evnetInsertCallOutBound(dto, eventTaskDTO.getsProduct() , sUserID, dt);
		//webbb37 db data ����
		eventTaskDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		eventTaskDTO.setsInputTime(DateTime.now().toString("HHssmm"));
		
		eventService.insertWEBBB37(eventTaskDTO);
	}
	
	/**
	 * <pre>
	 * theKFellow ��û�� ����
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("insertFellowInfo")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.TheKFellowInfoDTO", "sCellPhone1", "sCellPhone2", "sCellPhone3" } , register = CheckHTelNum.class)
	public GenericRestResponse<TheKFellowInfoDTO> insertFellowInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<TheKFellowInfoDTO> request) {
		
		final TheKFellowInfoDTO theKFellowInfoDTO  = request.getRequestData().get(BigInteger.ZERO.intValue());
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId(sessionService.getUserID(session));
		//�� ���θ� ǥ���ּ� 
		//����� �ּ�
		if(theKFellowInfoDTO.getsStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(theKFellowInfoDTO.getsAddrMgtNo());
			stndAddrDto.setVarPost(theKFellowInfoDTO.getsZip1()+theKFellowInfoDTO.getsZip2());
			stndAddrDto.setVarAllAddress(theKFellowInfoDTO.getsDoroAddr() + theKFellowInfoDTO.getsAddrAdd());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);

			theKFellowInfoDTO.setsAdrs1(resultAdr.getWeb_sCityName());
			theKFellowInfoDTO.setsAdrs2(resultAdr.getWeb_sCountyName());
			theKFellowInfoDTO.setsAdrs3(resultAdr.getWeb_sTownName());
			theKFellowInfoDTO.setsAddrAdd(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
				
		theKFellowInfoDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		theKFellowInfoDTO.setsInputTime(DateTime.now().toString("HHssmm"));
		
		eventService.insertWEBBB29(theKFellowInfoDTO);
		
		final GenericRestResponse<TheKFellowInfoDTO> response = new GenericRestResponse<TheKFellowInfoDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * <pre>
	 * ��ȣ������
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("insertPreferenceInfo")
	@ResponseBody
	public GenericRestResponse<TheKPreferenceInfoDTO> insertPreferenceInfo(@NotNull @RequestBody final GenericRestRequest<TheKPreferenceInfoDTO> request) {
		
		final TheKPreferenceInfoDTO theKPreferenceInfoDTO  = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		theKPreferenceInfoDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		theKPreferenceInfoDTO.setsInputTime(DateTime.now().toString("HHssmm"));
		
		eventService.insertWEBBB22(theKPreferenceInfoDTO);
		
		final GenericRestResponse<TheKPreferenceInfoDTO> response = new GenericRestResponse<TheKPreferenceInfoDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * <pre>
	 * ���������� ���� ���� ���
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "customerSatisfactionSurvey")
	@ResponseBody
	public GenericRestResponse<Void> customerSatisfactionSurvey(final HttpSession session, @RequestBody final GenericRestRequest<CustomerSatisfactionInputDTO> request) {
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		final CustomerSatisfactionInputDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId(sessionService.getUserID(session));
		//�� ���θ� ǥ���ּ� 
		//����� �ּ�
		if(dto.getsStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(dto.getsAddrMgtNo());
			stndAddrDto.setVarPost(dto.getsHomeZip1()+dto.getsHomeZip2());
			stndAddrDto.setVarAllAddress(dto.getsDoroAddr() + dto.getsHomeAdrsAdd());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);

			dto.setsHomeAdrs1(resultAdr.getWeb_sCityName());
			dto.setsHomeAdrs2(resultAdr.getWeb_sCountyName());
			dto.setsHomeAdrs3(resultAdr.getWeb_sTownName());
			dto.setsHomeAdrsAdd(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
				
		dto.setsInputDate(DateTime.now().toString("yyyyMMdd"));
		dto.setsInputTime(DateTime.now().toString("HHssmm"));
		
		eventService.insertWEBBB36(dto);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	/**
	 * <pre>
	 * 10�ֳ� �̺�Ʈ
	 * (����) 2014.05.13 ģ����õ �̺�Ʈ
	 * <pre>
	 * @param request     
	 * @return sPlateNo
	 */
	@RequestMapping(value = "insert10thAnniversary")
	@ResponseBody
	public GenericRestResponse<Event10AnniversaryDTO> insert10thAnniversary(final HttpSession session,  @RequestBody final GenericRestRequest<Event10AnniversaryDTO> request) {
	
		final GenericRestResponse<Event10AnniversaryDTO> response = new GenericRestResponse<Event10AnniversaryDTO>();
		final Event10AnniversaryDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		final Calendar cal = Calendar.getInstance();
		final SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmm");//mmssSSSSSS
		final String sKey = df.format(cal.getTime());
		
		final String sUserID = sessionService.getUserID(session);
		logger.debug(">>>>>>>>>>>>>>>"+dto.getsEventDiv()+"<<<");
		dto.setsCreID(sUserID);
		dto.setsCreDate(DateTime.now().toString("yyyyMMdd"));
		dto.setsCreTime(DateTime.now().toString("HHssmm"));
		
		final StringBuffer bfStr = new StringBuffer();
		final Random rdStr = new Random();
		
		final String chars[] = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,1,2,3,4,5,6,7,8,9,0".split(",");
		bfStr.append(sKey);
		for(int i=0; i<6; i++){
			bfStr.append(chars[rdStr.nextInt(chars.length)]);
		}
		dto.setsRecommendUrl(bfStr.toString());
		//WEBDD54 insert
		final Event10AnniversaryDTO chkDto = eventService.selectURLCheck(dto);
		if(chkDto == null){
			eventService.insertWEBDD54(dto);
			dto.setsEtc1("0");
		}else{
			dto.setsRecommendUrl(chkDto.getsRecommendUrl());
			dto.setsEtc1("1");
		}
		
		response.addResponseData(dto);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * 10�ֳ� �̺�Ʈ - �Ұ��� ģ����� ��ȸ
	 * (����) ģ����õ �̺�Ʈ - �Ұ��� ģ�� ��� ��ȸ
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "select10thList")
	@ResponseBody
	public GenericRestResponse<Event10AnniversaryDTO> insert10thAnniversaryList(@RequestBody final GenericRestRequest<Event10AnniversaryDTO> request) {
		
		final GenericRestResponse<Event10AnniversaryDTO> response = new GenericRestResponse<Event10AnniversaryDTO>();
		final Event10AnniversaryDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		//logger.info("[��SBM] getsCellPhone1"+dto.getsCellPhone1());
		//WEBDD55 select
		final List<Event10AnniversaryDTO> dtoList = eventService.select10thList(dto);
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(dtoList);
		
		return response;
	}
	
	
	/**
	 * 10�ֳ� �̺�Ʈ - URL SMS ����
	 * @param request
	 * @return
	*/ 
	@RequestMapping(value = "sentSMS10th")
	@ResponseBody
	public GenericRestResponse<Boolean> sentSMS10th(final HttpSession session, @RequestBody final GenericRestRequest<Event10AnniversaryDTO> request) {
		
		final GenericRestResponse<Boolean> response = new GenericRestResponse<Boolean>();
		final Event10AnniversaryDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		//�߼� Ƚ�� �� ���� ��ȸ
		final Event10AnniversaryDTO resultDTO  = newEventDAO.select10thSMS(dto);
		if(StringUtils.isBlank(resultDTO.getsSendSmsDate()) || !DateTime.now().toString("yyyyMMdd").equals(resultDTO.getsSendSmsDate()) ){
			dto.setsSendSmsDate(DateTime.now().toString("yyyyMMdd"));
			dto.setnSendSmsCnt(0);
			resultDTO.setnSendSmsCnt(0);
			newEventDAO.update10thSMSDate(dto);
		}
		
		//���ڹ߼� 3ȸ�̻��� ��� �߼� ���Ѵ�.
		if( resultDTO.getnSendSmsCnt() < 3){
			
			final MMSSendDTO mmsSendDTO = new MMSSendDTO();
			mmsSendDTO.setsCellPhone1(dto.getsCellPhone1());
			mmsSendDTO.setsCellPhone2(dto.getsCellPhone2());
			mmsSendDTO.setsCellPhone3(dto.getsCellPhone3());
			mmsSendDTO.setSUBJECT("[�����̼��غ��� ģ���Ұ� �̺�Ʈ]");
			mmsSendDTO.setsContents("�ڵ�������� Ȯ���ϸ� ������ ����!\n" + "https://www.educar.co.kr/st/c.html?u=" + dto.getsRecommendUrl());
			sendBackBoneService.sendMMS(mmsSendDTO, sessionService.getUserID(session), "");
			
			//���ڹ߼�Ƚ�� �ϳ� �����ش�.
			dto.setnSendSmsCnt( resultDTO.getnSendSmsCnt() + 1);
			dto.setsSendSmsDate(DateTime.now().toString("yyyyMMdd"));
			newEventDAO.update10thSMSDate(dto);
			response.addResponseData(Boolean.TRUE);
		}else{
			response.addResponseData(Boolean.FALSE);
		}
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * 11�ֳ� ��� �̺�Ʈ ����� insert
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "insert11thEvent")
	@ResponseBody
	public GenericRestResponse<Boolean> insert11thEvent(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EventTaskDTO> request) {
		final EventTaskDTO eventTaskDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<Boolean> response = new GenericRestResponse<Boolean>();
		//���𿩺�üũ
		int cnt = newEventDAO.selectEventDupcheck(eventTaskDTO);
		if(cnt > 0){
			response.addResponseData(Boolean.FALSE);
		}else{
			eventTaskDTO.setsInputDate(DateTime.now().toString("yyyyMMdd"));
			eventTaskDTO.setsInputTime(DateTime.now().toString("HHssmm"));
			newEventDAO.insertWEBBB37(eventTaskDTO);
			response.addResponseData(Boolean.TRUE);
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * <pre>
	 * ��������亯����
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("savePollInfos")
	@ResponseBody
	public GenericRestResponse<Boolean> savePollInfos(final HttpSession session,@RequestBody final GenericRestRequest<CustomerCancelPollInputListDTO> request) {
		final CustomerCancelPollInputListDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//�Ⱓ�� �� �� ����ó��
		eventBackBoneService.setPollInfos(inputDTO);
		
		final GenericRestResponse<Boolean> response = new GenericRestResponse<Boolean>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(Boolean.TRUE);
		return response;
	}
	
	
}