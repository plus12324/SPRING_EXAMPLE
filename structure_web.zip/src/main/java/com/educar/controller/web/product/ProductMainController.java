/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dao.InsuranceProductMainMenuDAO;
import com.educar.dto.web.main.InsuranceProductMainMenuDTO;
import com.educar.enumeration.ResponseStatusEnum;

/**
 * �����ǰ main
 * @author ��â��(slander)
 */
@Controller
public class ProductMainController {

	/** DAO */
	@Autowired
	private InsuranceProductMainMenuDAO insuranceProductMainMenuDAO;

	/**
	 * �����ǰ ùȭ��
	 */
	@RequestMapping("selectProductMainMenuList")
	@ResponseBody
	public GenericRestResponse<InsuranceProductMainMenuDTO> selectProductMainMenuList() {
		final List<InsuranceProductMainMenuDTO> insuranceProductMainMenuList = insuranceProductMainMenuDAO.selectInsuranceProductMainMenuList("");
		final GenericRestResponse<InsuranceProductMainMenuDTO> response = new GenericRestResponse<InsuranceProductMainMenuDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(insuranceProductMainMenuList);
		return response;
	}
}
