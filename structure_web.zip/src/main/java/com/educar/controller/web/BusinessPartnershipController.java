/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.util.CheckHTelNum;
import com.educar.dto.web.BidNotificationDTO;
import com.educar.dto.web.company.AffiliatedRequestDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.AffiliatedService;
import com.educar.service.web.BusinessPartnershipService;

/**
 * <pre>
 * ������� ��Ʈ�ѷ�
 * <pre>
 * @author ��â��
 *
 */
@Controller
@RequestMapping("/businessPartnership")
public class BusinessPartnershipController {

	/** �������� ���� */
	@Autowired
	private BusinessPartnershipService businessPartnershipService;
	/** ���޹��� ���� */
	@Autowired
	private AffiliatedService affiliatedService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());

	/**
	 * <pre>
	 * �������� ��� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <BidNotificationDTO>
	 */
	@RequestMapping(value = "selectBidNotificationList")
	@ResponseBody
	public GenericRestResponse<BidNotificationDTO> selectBidNotificationList(@NotNull @RequestBody final GenericRestRequest<BidNotificationDTO> request) {
		List<BidNotificationDTO> bidNotificationList = businessPartnershipService.selectBidNotificationList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<BidNotificationDTO> response = new GenericRestResponse<BidNotificationDTO>();
		if (bidNotificationList == null) {
			bidNotificationList = new ArrayList<BidNotificationDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(bidNotificationList);
		return response;
	}

	/**
	* ������ �ٿ�ε� �Ѵ�.  ���������� download�� �ް� �ȴ�.
	 * @param request �ٿ�ε� �� ���� ID�� ���� ��ü
	 * @param response HttpServletResponse ������ write�� reponse��ü
	 */
	@RequestMapping(value = "selectBidNotificationList/download")
	public void requestDownload(@NotNull final String xmlValue, final HttpServletResponse response) {
		businessPartnershipService.requestFileDownload(Integer.parseInt(xmlValue), response);
	}

	/**
	 * �������� �� ���� ��ȸ
	 * @param <BidNotificationDTO> nSeq
	 * @return <BidNotificationDTO> �󼼳���
	 */
	@RequestMapping(value = "selectBidNotificationView")
	@ResponseBody
	public GenericRestResponse<BidNotificationDTO> selectBidNotificationView(@RequestBody final GenericRestRequest<BidNotificationDTO> request) {
		final BidNotificationDTO dto = businessPartnershipService.selectBidNotificationView(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<BidNotificationDTO> response = new GenericRestResponse<BidNotificationDTO>();
		if (dto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(dto);
		}
		return response;
	}

	/**
	 * ���޹��� ����
	 * @param request AffiliatedRequestDTO
	 * @return ó�������
	 */
	@RequestMapping(value = "affiliatedRequest/insert")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.company.AffiliatedRequestDTO", "sTel1", "sTel2", "sTel3" }, register = CheckHTelNum.class)
	public GenericRestResponse<Void> insertAffiliatedConcern(@NotNull @Validate @RequestBody final GenericRestRequest<AffiliatedRequestDTO> request) {
		logger.debug("���� ���� ���� Request ó��");
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		final AffiliatedRequestDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���޹��� �߰� ���񽺸� ȣ���Ѵ�, ���н� �ڵ����� exception ó�� �ȴ�.
		affiliatedService.insertAffiliatedRequest(dto);
		logger.debug("���� ���� ���� ���� ó���Ϸ�");
		// ����� ��ȯ
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
