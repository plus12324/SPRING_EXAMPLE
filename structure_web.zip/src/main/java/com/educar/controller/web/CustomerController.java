package com.educar.controller.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.dto.jehu.JehuCounselDTO;
import com.educar.dto.web.CUSAA0441InfoDTO;
import com.educar.dto.web.PersonalInfoConsignDTO;
import com.educar.dto.web.ProductAgreeListDTO;
import com.educar.enumeration.DomainEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.backbone.CustomerBackBoneService;
import com.educar.service.backbone.LoginBackBoneService;

/**
 * <pre>
 * �������� ��Ʈ�ѷ�
 * <pre>
 * @author ���ѳ�
 *
 */
@Controller
@RequestMapping("/customer")
public class CustomerController {
	/** ���� ���� **/
	@Autowired
	private SessionService sessionService;
	/** ����������� ȣ�� ���� **/
	@Autowired
	private CustomerBackBoneService customerBackBoneService;
	
	/** �絿�� ȣ�� ���� **/
	@Autowired
	private LoginBackBoneService loginBackBoneService;
	
	@Autowired
	private MessageSourceService message;
	
	/**
	 * <pre>
	 * �������� ��Ź���� - �������� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "selectAgreeDateList")
	@ResponseBody
	public GenericRestResponse<PersonalInfoConsignDTO> selectAgreeDateList(final HttpSession session) {
		final List<PersonalInfoConsignDTO> resultList = customerBackBoneService.getAgreeDate(sessionService.getSSNFromSession(session));
		
		final GenericRestResponse<PersonalInfoConsignDTO> response = new GenericRestResponse<PersonalInfoConsignDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);

		return response;
	}
	/**
	 * <pre>
	 * �������� ��Ź���� - ��������ó�� ��Źó��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "selectTrustList")
	@ResponseBody
	public GenericRestResponse<PersonalInfoConsignDTO> selectTrustList(@NotNull @RequestBody final GenericRestRequest<PersonalInfoConsignDTO> request) {
		final PersonalInfoConsignDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());

		final List<PersonalInfoConsignDTO> trustList = customerBackBoneService.searchTrustList(dto);

		final GenericRestResponse<PersonalInfoConsignDTO> response = new GenericRestResponse<PersonalInfoConsignDTO>();
		
		if (trustList == null || trustList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "��������ó�� ��Źó"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.setData(trustList);
		}
		return response;
	}
	
	/**
	 * �絿���� - �� ȭ��
	 */
	@RequestMapping(value = "/requestReAgree")
	public void requestReAgree(final HttpServletRequest servletRequest, HttpServletResponse res, final JehuCounselDTO dto) throws IOException {
		final HttpSession session = servletRequest.getSession();
		String CallbackMsg = "true";
		String strName = dto.getsName();
		try{
			try {
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> strName : " + strName);
				strName = URLDecoder.decode( strName, "utf-8");
				dto.setsName(strName);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(StringUtils.isEmpty(dto.getsUserID())){
				dto.setsUserID( sessionService.getUserID(session));
			}
			//��ǰ�Ұ� ����
			final CUSAA0441InfoDTO cusAA0441InfoDTO = new CUSAA0441InfoDTO();
				
			cusAA0441InfoDTO.setsCustNo(dto.getsCustNo());
			cusAA0441InfoDTO.setsCUSAA04AgmYn(DomainEnum.YES.getCode());
			cusAA0441InfoDTO.setsCUSAA41AgmYn("X");
			// �������(Call ��ǰ�Ұ� �����̿� �� ��������)
			loginBackBoneService.setCUSAA0441Info(cusAA0441InfoDTO,dto.getsUserID());
		}catch(Exception e){
			CallbackMsg = "false";
			e.printStackTrace();
		}
		finally{
			//Callback msg
			res.setCharacterEncoding("euc-kr");
			res.setContentType("text/html; charset=euc-kr");
			res.setHeader("pragma", "no-cache");
			res.setHeader("cache-control", "no-cache");
			res.setHeader("expires", "0");
			PrintWriter out = res.getWriter();
			out.println(CallbackMsg);
			out.flush();
			out.close();
		}
	}
	
	/**
	 * �������� �̿�(����) ��ȸ ����
	 * @param servletRequest
	 * @param request
	 */
	@RequestMapping("/productAgreeList")
	@ResponseBody
	public GenericRestResponse<ProductAgreeListDTO> productAgreeList(final HttpServletRequest servletRequest) {
		
		final String sCustNo = sessionService.getSSNFromSession(servletRequest.getSession());
		
		final List<ProductAgreeListDTO> resultList = new ArrayList<ProductAgreeListDTO>();
		final ProductAgreeListDTO outputDTO = customerBackBoneService.selectMaxCUSAA04(sCustNo);
		if(BigInteger.ONE.toString().equals(outputDTO.getResult())){
			resultList.add(outputDTO);
		}
		
		final GenericRestResponse<ProductAgreeListDTO> response = new GenericRestResponse<ProductAgreeListDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * �������� �̿�(����) öȸ ����
	 * @param servletRequest
	 * @param request
	 */
	@RequestMapping("/productAgreeDoNotCall")
	@ResponseBody
	public GenericRestResponse<ProductAgreeListDTO> productAgreeDoNotCall(final HttpServletRequest servletRequest) {
		
		final String sCustNo = sessionService.getSSNFromSession(servletRequest.getSession());
		
		customerBackBoneService.insertWebDoNotCall(sCustNo, sessionService.getUserID(servletRequest.getSession()));
		
		final GenericRestResponse<ProductAgreeListDTO> response = new GenericRestResponse<ProductAgreeListDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
}
