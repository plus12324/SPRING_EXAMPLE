/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dto.web.FaqCategoryDTO;
import com.educar.dto.web.FaqDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.FaqService;

/**
 * <pre>
 * ���ֹ������� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@Controller
@RequestMapping("/faq")
public class FaqController {

	/** ���ֹ������� ���� */
	@Autowired
	private FaqService faqService;

	/**
	 * <pre>
	 * ���ֹ������� ��� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "selectFaqList")
	@ResponseBody
	public GenericRestResponse<FaqDTO> selectFaqList(@RequestBody final GenericRestRequest<FaqDTO> request) {
		final List<FaqDTO> faqList = faqService.selectFaqList(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<FaqDTO> response = new GenericRestResponse<FaqDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(faqList);
		return response;
	}

	/**
	 * <pre>
	 * ���ֹ������� ��ȸ�� ����
	 * ��ȸ�� ������ ������ ����
	 * <pre>
	 * @param request
	 */
	@RequestMapping(value = "updateFaqVisitCnt")
	@ResponseBody
	public GenericRestResponse<Void> updateFaqVisitCnt(@NotNull @RequestBody final GenericRestRequest<String> request) {
		faqService.updateFaqVisitCnt(Integer.parseInt(request.getRequestData().get(BigInteger.ZERO.intValue())));
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * <pre>
	 * ���ֹ������� ī�װ��� ��ȸ(2����)
	 * <pre>
	 * @return
	 */
	@RequestMapping(value = "selectFaqCategoryList")
	@ResponseBody
	public GenericRestResponse<FaqCategoryDTO> selectFaqCategoryList() {
		final List<FaqCategoryDTO> list = faqService.selectFaqCategoryList();
		final GenericRestResponse<FaqCategoryDTO> response = new GenericRestResponse<FaqCategoryDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}
}
