/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.company;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.company.PrintAdDTO;
import com.educar.dto.web.company.TvAdDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.PrDepartmentService;

/**
 * <pre>
 * ȫ���� ��Ʈ�ѷ�
 * <pre>
 * @author ��â��
 *
 */
@Controller
@RequestMapping("/prDepartment")
public class PrDepartmentController {

	/** ȫ���� ���� */
	@Autowired
	private PrDepartmentService prDepartmentService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;

	/**
	 * TV���� ��� ��ȸ
	 * @return <TvAdDTO>
	 */
	@RequestMapping(value = "selectTvAdList")
	@ResponseBody
	public GenericRestResponse<TvAdDTO> selectTvAdList() {
		List<TvAdDTO> tvAdList = prDepartmentService.selectTvAdList();
		final GenericRestResponse<TvAdDTO> response = new GenericRestResponse<TvAdDTO>();
		if (tvAdList == null) {
			tvAdList = new ArrayList<TvAdDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(tvAdList);
		return response;
	}

	/**
	 * <pre>
	 * �μⱤ�� ��� ��ȸ
	 * <pre>
	 * @param pageIndex ������ �ѹ� 
	 * @return <PrintAdDTO>
	 */
	@RequestMapping(value = "selectPrintAdList")
	@ResponseBody
	public GenericRestResponse<PrintAdDTO> selectPrintAdList(@NotNull @RequestBody final GenericRestRequest<PrintAdDTO> request) {
		List<PrintAdDTO> printAdList = prDepartmentService.selectPrintAdList(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<PrintAdDTO> response = new GenericRestResponse<PrintAdDTO>();
		if (printAdList == null) {
			printAdList = new ArrayList<PrintAdDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(printAdList);
		return response;
	}

	/**
	* ������ �ٿ�ε� �Ѵ�.  ���������� download�� �ް� �ȴ�.
	 * @param request �ٿ�ε� �� ���� ID�� ���� ��ü
	 * @param response HttpServletResponse ������ write�� reponse��ü
	 */
	@RequestMapping(value = "selectBidNotificationList/download")
	public void requestDownload(@NotNull final String xmlValue, final HttpServletResponse response) {
		prDepartmentService.requestFileDownload(Integer.parseInt(xmlValue), response);
	}

	/**
	 * �μⱤ�� �� ���� ��ȸ
	 * @param <PrintAdDTO> nSeq
	 * @return <PrintAdDTO> �󼼳���
	 */
	@RequestMapping(value = "selectPrintAdView")
	@ResponseBody
	public GenericRestResponse<PrintAdDTO> selectPrintAdView(@RequestBody final GenericRestRequest<PrintAdDTO> request) {
		final PrintAdDTO dto = prDepartmentService.selectPrintAdView(request.getRequestData().get(BigInteger.ZERO.intValue()));

		final GenericRestResponse<PrintAdDTO> response = new GenericRestResponse<PrintAdDTO>();
		if (dto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(dto);
		}
		return response;
	}
}
