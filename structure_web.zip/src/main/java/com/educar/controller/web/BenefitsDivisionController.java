/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.web.BenefitsDivisionService;

/**
 * ���ð��� ��Ʈ�ѷ�
 * @author ������
 *
 */
@Controller
public class BenefitsDivisionController {

	@Autowired
	private BenefitsDivisionService benefitsDivisionService;
	@Autowired
	private MessageSourceService message;

	/**
	 * ���ð��� �ڵ���ȸ
	 * @param
	 * @return response ���ð��� ȭ��� �ڵ帮��Ʈ xml��Ʈ�� ����
	 */
	@RequestMapping("/benefitsDivision/codelist")
	@ResponseBody
	public GenericRestResponse<String> selectBenefitsDivisionCodeList() {
		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		final String codeList = benefitsDivisionService.selectBenefitsDivisionAllList();
		// �ڵ� ��ȸ����Ʈ�� ���� ��� ������ ����
		if (StringUtils.isBlank(codeList)) {
			throw new InvalidRequestException(message.getMessage(ExceptionMessage.InvalidRequest), WebServletEnum.MEMEBERSHIP_INDEX_WEB, ResponseStatusEnum.DEFAULT_ERROR);
		}
		response.addResponseData(codeList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
