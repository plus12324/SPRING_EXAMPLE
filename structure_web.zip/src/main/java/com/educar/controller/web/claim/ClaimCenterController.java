/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.claim;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dto.web.claim.ClaimCenterDTO;
import com.educar.dto.web.claim.ClaimCenterSearchDTO;
import com.educar.dto.web.claim.NewSearchControlCorrSearchDTO;
import com.educar.dto.web.claim.NewSearchControlCorrSearchResultDTO;
import com.educar.dto.web.claim.SchoolStaffSearchDTO;
import com.educar.dto.web.claim.SchoolStaffSearchResultDTO;
import com.educar.dto.web.claim.SelExcellentCooperationSearchDTO;
import com.educar.service.backbone.ClaimBackBoneService;

/**
 * �����;ȳ� ��Ʈ�ѷ�
 * @author �ּ�ȯ(David SW Choi) 
 * @since 1.0.0
 */
@Controller
public class ClaimCenterController {

	/** ������ �Ⱓ�� �������̽� ���� **/
	@Autowired
	private ClaimBackBoneService claimService;

	/**
	 * ������ ã�� ��Ʈ�ѷ�, ���� ���� ��� ��ü �˻�
	 * @param request ClaimCenterSearchDTO
	 * @return List<ClaimCenterDTO> ������ ����Ʈ (��, �ּ�, ��ȭ��ȣ, �ѽ���ȣ, ������ǥ��ȣ)
	 */
	@RequestMapping("/center/list")
	@ResponseBody
	public GenericRestResponse<ClaimCenterDTO> listCenter(@RequestBody @NotNull final GenericRestRequest<ClaimCenterSearchDTO> request) {
		final ClaimCenterSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<ClaimCenterDTO> resultList = claimService.rewardCenterList(dto);
		final GenericRestResponse<ClaimCenterDTO> response = new GenericRestResponse<ClaimCenterDTO>();
		response.setData(resultList);
		return response;
	}

	/**
	 * �б����������� ã�� ��Ʈ�ѷ�
	 * @param request SchoolStaffSearchDTO
	 * @return List<SchoolStaffSearchResultDTO>
	 */
	@RequestMapping("/school/list")
	@ResponseBody
	public GenericRestResponse<SchoolStaffSearchResultDTO> listSchool(@RequestBody @NotNull final GenericRestRequest<SchoolStaffSearchDTO> request) {
		final SchoolStaffSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<SchoolStaffSearchResultDTO> resultList = claimService.schoolStaffSearchList(dto);
		final GenericRestResponse<SchoolStaffSearchResultDTO> response = new GenericRestResponse<SchoolStaffSearchResultDTO>();
		response.setData(resultList);
		return response;
	}

	/**
	 * ����/�������ȳ�  ��Ʈ�ѷ�
	 * @param request NewSearchControlCorrSearchDTO
	 * @return List<NewSearchControlCorrSearchResultDTO>
	 */
	@RequestMapping("/hospital/list")
	@ResponseBody
	public GenericRestResponse<NewSearchControlCorrSearchResultDTO> listHospital(@RequestBody @NotNull final GenericRestRequest<NewSearchControlCorrSearchDTO> request) {
		final NewSearchControlCorrSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<NewSearchControlCorrSearchResultDTO> resultList = claimService.newSearchControlCorr(dto);
		final GenericRestResponse<NewSearchControlCorrSearchResultDTO> response = new GenericRestResponse<NewSearchControlCorrSearchResultDTO>();
		response.setData(resultList);
		return response;
	}

	/**
	 * ��������ü����  ��Ʈ�ѷ�
	 * @param request SelExcellentCooperationSearchDTO
	 * @return List<NewSearchControlCorrSearchResultDTO>
	 */
	@RequestMapping("/excellentRepairEnterprise/list")
	@ResponseBody
	public GenericRestResponse<NewSearchControlCorrSearchResultDTO> listExcellentRepairEnterprise(@RequestBody @NotNull final GenericRestRequest<SelExcellentCooperationSearchDTO> request) {
		final SelExcellentCooperationSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<NewSearchControlCorrSearchResultDTO> resultList = claimService.selExcellentCooperation(dto);
		final GenericRestResponse<NewSearchControlCorrSearchResultDTO> response = new GenericRestResponse<NewSearchControlCorrSearchResultDTO>();
		response.setData(resultList);
		return response;
	}
}
