/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.myeducar;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dao.MyEducarDAO;
import com.educar.dto.web.myeducar.MileageAfiliatedConcernDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.backbone.ClaimBackBoneService;

/**
 * ���ϸ��� ���޾�ü ��ȸ ��Ʈ�ѷ�
 * @author ������
 * @since 1.0.0
 */
@RequestMapping("mileageAfiliatedConcern")
@Controller
public class MileageAfiliatedConcernController {
	/** ���󼭺� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private ClaimBackBoneService claimBackBoneService;
	/** ���ϸ��� ���޾�ü ��ȸ dao **/
	@Autowired
	private MyEducarDAO myEducarDAO;

	/**
	 * ���ϸ��� ���޾�ü �� ��� ��ȸ
	 * @return List<MileageAfiliatedConcernDTO> sAdrs1
	 */
	@RequestMapping("selectMileageAfiliatedConcernCity")
	@ResponseBody
	public GenericRestResponse<MileageAfiliatedConcernDTO> selectMileageAfiliatedConcernCity() {
		final List<MileageAfiliatedConcernDTO> resultList = myEducarDAO.selectAdrs1List();
		final GenericRestResponse<MileageAfiliatedConcernDTO> response = new GenericRestResponse<MileageAfiliatedConcernDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * ���ϸ��� ���޾�ü ��� ��ȸ
	 * @return List<MileageAfiliatedConcernDTO>
	 */
	@RequestMapping("selectMileageAfiliatedConcernList")
	@ResponseBody
	public GenericRestResponse<MileageAfiliatedConcernDTO> selectMileageAfiliatedConcernList(@NotNull @RequestBody final GenericRestRequest<MileageAfiliatedConcernDTO> request) {

		final MileageAfiliatedConcernDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// �� �Ǽ� ��ȸ
		Integer totalCount = myEducarDAO.selectMileageAfiliatedConcernCount(dto);
		if (totalCount == null) {
			totalCount = BigInteger.ZERO.intValue();
		}
		dto.setTotalCount(totalCount);

		final List<MileageAfiliatedConcernDTO> resultList = myEducarDAO.selectMileageAfiliatedConcernList(dto);
		if (resultList != null) {
			for (final MileageAfiliatedConcernDTO resultDTO : resultList) {
				final String address = resultDTO.getsAdrs1() + " " + resultDTO.getsAdrs2() + " " + resultDTO.getsAdrs3();
				resultDTO.setAddress(address);
				// ��ǥ���� �ִ´�. ������ null�� ����.
				final List<String> cords = claimBackBoneService.getXY(resultDTO.getsAdrs1() + resultDTO.getsAdrs2() + resultDTO.getsAdrs3());
				if (cords != null && cords.size() == 2) {
					resultDTO.setX(cords.get(0));
					resultDTO.setY(cords.get(1));
				}
			}
		}
		final GenericRestResponse<MileageAfiliatedConcernDTO> response = new GenericRestResponse<MileageAfiliatedConcernDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
