/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.myeducar;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.common.vo.PaymentVO;
import com.educar.dto.web.PairDTO;
import com.educar.dto.web.endorse.CarEndorseDetailDTO;
import com.educar.dto.web.endorse.EditDriverScopeRequestDTO;
import com.educar.dto.web.endorse.EditDriverScopeResponseDTO;
import com.educar.dto.web.endorse.EndorseCarPlateNoDTO;
import com.educar.dto.web.endorse.EndorseCarPlateNoResponseDTO;
import com.educar.dto.web.endorse.EndorseConfirmDTO;
import com.educar.dto.web.endorse.EndorseDepreciationDTO;
import com.educar.dto.web.endorse.EndorseDrivingScopeDTO;
import com.educar.dto.web.endorse.EndorseInfoDTO;
import com.educar.dto.web.endorse.EndorseInfoResultDTO;
import com.educar.dto.web.endorse.EndorseModifyPawnResultDTO;
import com.educar.dto.web.endorse.EndorseModifySpecialResultDTO;
import com.educar.dto.web.endorse.EndorsePawnListOfPola001InfoDTO;
import com.educar.dto.web.endorse.EndorsePawnListResultDTO;
import com.educar.dto.web.endorse.EndorseSpecialTermsListResultDTO;
import com.educar.dto.web.endorse.EndorseSpecialTermsOfPola001InfoDTO;
import com.educar.dto.web.myeducar.CustPopInfoWrapperDTO;
import com.educar.dto.web.myeducar.InsuranceCarResultDTO;
import com.educar.dto.web.myeducar.MyEduCallDTO;
import com.educar.dto.web.products.MedicalDuplicateResultDTO;
import com.educar.dto.web.ria.CarSendCertificateDTO;
import com.educar.dto.web.ria.MedicalCoverAgreeDTO;
import com.educar.enumeration.CODAA02CodeTypeEnum;
import com.educar.enumeration.InsuranceProductEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SendCertificateDMCodeEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.BackBoneException;
import com.educar.exception.InvalidRequestException;
import com.educar.mbean.RIABlockListUtil;
import com.educar.service.backbone.EndorseBackBoneService;
import com.educar.service.backbone.InsuranceBackBoneService;
import com.educar.service.backbone.MyEducarServiceBackBoneService;
import com.educar.service.backbone.RIABackBoneService;
import com.educar.service.web.CertificationService;
import com.educar.service.web.CodeService;
import com.educar.service.web.MyPageService;

/**
 * <pre>
 * ���������� - �����ȸ/���� - �ڵ��������ຯ��(�輭)
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("endorseCar")
@Controller
public class EndorseCarController {

	/** �޼��� **/
	@Autowired
	private MessageSourceService message;
	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());
	/** ��� ��ȸ �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private InsuranceBackBoneService insuranceBackBoneService;
	/** �ڵ��������ຯ��(�輭) �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private EndorseBackBoneService endorseBackBoneService;
	/** �ڵ� ��ȸ ���� **/
	@Autowired
	private CodeService codeService;
	/** ����� ����(RIA) ���� **/
	@Autowired
	private RIABackBoneService riaBackBoneService;
	/** ���̿���ī  - �����ȸ/����, ����/ȯ�޳���, ���� **/
	@Autowired
	private MyEducarServiceBackBoneService myEducarServiceBackBoneService;
	/** ��ຯ�泻�� sms/email �߼� **/
	@Autowired
	private MyPageService myPageService;
	/** session ���� **/
	@Autowired
	private SessionService sessionService;
	/** ���� ���� */
	@Autowired
	private CertificationService certificationService;
	@Autowired
	private RIABlockListUtil riaBlockListUtil;

	/**
	 * <pre>
	 * ��ü���� �� ������� ���� ����Ʈ ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("selectCarInsuranceContractsList")
	@ResponseBody
	public GenericRestResponse<InsuranceCarResultDTO> selectCarInsuranceContractsList(final HttpSession session) {
		logger.debug("���������� - �����ȸ/���� - �ڵ��������ຯ�� - ��ü���� �� ������� ���� ����Ʈ ��ȸ");
		// ��ü/���� ��ȸ ����(��ü:false, ����:true(1)) - ����Ǹ� ��ȸ
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		final GenericRestResponse<InsuranceCarResultDTO> response = new GenericRestResponse<InsuranceCarResultDTO>();

		for (final InsuranceCarResultDTO dto : resultList) {
			dto.setsPlateNo(dto.getsPlateNo().substring(0, dto.getsPlateNo().length()-1) + '*');
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * �ڵ�����ȣ ���/����/����
	 * ���� ���� ���� ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorsePlateNo")
	@ResponseBody
	public GenericRestResponse<CarEndorseDetailDTO> selectEndorsePlateNo(@NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request, final HttpSession session) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = false;
		for(final InsuranceCarResultDTO dto : resultList){
			if(inputDTO.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult = true;
			}
		}
		if(!checkResult){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.DifferenceContractInfoError)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		
		this.checkEndorseCar(sessionService.getSSNFromSession(session));
		
		final CarEndorseDetailDTO dto = endorseBackBoneService.checkEndorsePlateNo(inputDTO.getsPolicyNo(), inputDTO.getsEndorseCodeForWeb(), sessionService.getUserID(session));
		final GenericRestResponse<CarEndorseDetailDTO> response = new GenericRestResponse<CarEndorseDetailDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * �ڵ��� ��ȣ ���/����/����
	 * ������ȣ �� �輭 �����Ͽ� ���� ���� ���� ���� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseFmdtPlateNo")
	@ResponseBody
	public GenericRestResponse<EndorseCarPlateNoResponseDTO> selectEndorseFmdtPlateNo(@NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request, final HttpSession session) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		final EndorseCarPlateNoResponseDTO dto = endorseBackBoneService.checkEndorseFmdtPlateNo(inputDTO, sessionService.getUserID(session));
		final GenericRestResponse<EndorseCarPlateNoResponseDTO> response = new GenericRestResponse<EndorseCarPlateNoResponseDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * �ڵ��� ��ȣ ���/����/����
	 * ������ȣ ���� ó��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("updateEndorsePlateNo")
	@ResponseBody
	public GenericRestResponse<Void> updateEndorsePlateNo(@NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request, final HttpSession session) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final boolean isSuccess = endorseBackBoneService.setEndorsePlateNo(inputDTO, sessionService.getUserID(session));
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if (isSuccess) {
			//[��SBM] SMS, Email �߼�
			myPageService.contractInfoChangeSend(sessionService.getUserID(session), sessionService.getSSNFromSession(session));
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		} else {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.EndorseUpdateFail)).build();
		}
		return response;
	}

	/**
	 * <pre>
	 * ������ ���� ���/Ȯ��/���� ����� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseDriverScope")
	@ResponseBody
	public GenericRestResponse<EndorseDrivingScopeDTO> selectEndorseDriverScope(@NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request, final HttpSession session) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		String sInsrdName = new String();
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = false;
		for(final InsuranceCarResultDTO dto : resultList){
			if(inputDTO.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				sInsrdName = dto.getsInsrdName();
				checkResult = true;
			}
		}
		if(!checkResult){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.DifferenceContractInfoError)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		 
		this.checkEndorseCar(sessionService.getSSNFromSession(session));
		
		final EndorseDrivingScopeDTO dto = endorseBackBoneService.getDrivingScopeChange(inputDTO.getsPolicyNo(), inputDTO.getsEndorseCodeForWeb(), sessionService.getUserID(session));
		if (dto == null) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.SelectEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		// �ֹι�ȣ ****** ó��
		dto.getPola001Info().setsInsrdID(SsnAsteriskConvert.getSsnAsterisk(dto.getPola001Info().getsInsrdID(), Boolean.TRUE));
		dto.getPola001Info().setsInsrdName(sInsrdName);
		
		final GenericRestResponse<EndorseDrivingScopeDTO> response = new GenericRestResponse<EndorseDrivingScopeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ������ ���� ���/Ȯ��/���� ��� - �輭 ������ �� ���� ���� Ȯ��
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseDriverScopeCalculation")
	@ResponseBody
	public GenericRestResponse<EditDriverScopeResponseDTO> selectEndorseDriverScopeCalculation(@NotNull @RequestBody final GenericRestRequest<EditDriverScopeRequestDTO> request, final HttpSession session) {
		final EditDriverScopeResponseDTO dto = endorseBackBoneService.calcuEndorsePremB1(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<EditDriverScopeResponseDTO> response = new GenericRestResponse<EditDriverScopeResponseDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * �μ�ǰ �߰�/���� ����� Ȯ�� 
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarAccessories")
	@ResponseBody
	public GenericRestResponse<EndorseInfoDTO> selectEndorseCarAccessories(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = false;
		for(final InsuranceCarResultDTO dto : resultList){
			if(inputDTO.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult = true;
			}
		}
		if(!checkResult){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.DifferenceContractInfoError)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		
		this.checkEndorseCar(sessionService.getSSNFromSession(session));
		
		final EndorseInfoDTO dto = endorseBackBoneService.getEndorseInfo(inputDTO, sessionService.getUserID(session));
		final GenericRestResponse<EndorseInfoDTO> response = new GenericRestResponse<EndorseInfoDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * �μ�ǰ �߰�/���� ���� ���
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarAccessoriesCalculation")
	@ResponseBody
	public GenericRestResponse<EndorseInfoResultDTO> selectEndorseCarAccessoriesCalculation(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EndorseInfoDTO> request) {
		final EndorseInfoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final EndorseInfoResultDTO dto = endorseBackBoneService.calcuEndorsePrem(inputDTO, sessionService.getUserID(session));
		final GenericRestResponse<EndorseInfoResultDTO> response = new GenericRestResponse<EndorseInfoResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * �μ�ǰ �ڵ� ����Ʈ ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("selectCarAccessoriesCodeList")
	@ResponseBody
	public GenericRestResponse<PairDTO> selectCarAccessoriesCodeList() {
		final List<PairDTO> resultList = codeService.selectCodeList(CODAA02CodeTypeEnum.CAR_ACCESSORIES);
		if (!resultList.isEmpty()) {
			// code:28 �������� ����(����) �׸��� �ݼ��Ϳ����� ����ϴ� �μ�ǰ �ڵ忩�� �������� ����ó���Ѵ�.
			for (int i = 0; i < resultList.size(); i++) {
				if ("28".equals(resultList.get(i).getKey())) {
					resultList.remove(i);
				}
			}
		}
		final GenericRestResponse<PairDTO> response = new GenericRestResponse<PairDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * �μ�ǰ ���� �� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping("selectDepreciationList")
	@ResponseBody
	public GenericRestResponse<EndorseDepreciationDTO> selectDepreciationList(@NotNull @RequestBody final GenericRestRequest<EndorseDepreciationDTO> request) {
		final List<EndorseDepreciationDTO> resultList = endorseBackBoneService.getRemainRateByYYMMForEndorse(request.getRequestData());
		final GenericRestResponse<EndorseDepreciationDTO> response = new GenericRestResponse<EndorseDepreciationDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(resultList);
		return response;
	}

	/**
	 * <pre>
	 * ���� �㺸 ����/�߰� ����� ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarPawn")
	@ResponseBody
	public GenericRestResponse<EndorsePawnListResultDTO> selectEndorseCarPawn(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = false;
		for(final InsuranceCarResultDTO dto : resultList){
			if(inputDTO.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult = true;
			}
		}
		if(!checkResult){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.DifferenceContractInfoError)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		
		this.checkEndorseCar(sessionService.getSSNFromSession(session));
		
		final EndorsePawnListResultDTO dto = endorseBackBoneService.endorsePawnList(inputDTO.getsPolicyNo(), sessionService.getUserID(session));
		final GenericRestResponse<EndorsePawnListResultDTO> response = new GenericRestResponse<EndorsePawnListResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���� �㺸 ����/�߰� ���
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarPawnCalculation")
	@ResponseBody
	public GenericRestResponse<EndorseModifyPawnResultDTO> selectEndorseCarPawnCalculation(@NotNull @RequestBody final GenericRestRequest<EndorsePawnListOfPola001InfoDTO> request) {
		final EndorsePawnListOfPola001InfoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final EndorseModifyPawnResultDTO dto = endorseBackBoneService.endorseModifyPawn(inputDTO);
		final GenericRestResponse<EndorseModifyPawnResultDTO> response = new GenericRestResponse<EndorseModifyPawnResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���� Ư�� �߰� ����� ��ȸ
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarSpecialTerms")
	@ResponseBody
	public GenericRestResponse<EndorseSpecialTermsListResultDTO> selectEndorseCarSpecialTerms(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EndorseCarPlateNoDTO> request) {
		final EndorseCarPlateNoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//20140731 ����������
		final List<InsuranceCarResultDTO> resultList = insuranceBackBoneService.getPolicyListForWeb(Boolean.TRUE, sessionService.getSSNFromSession(session));
		boolean checkResult = false;
		for(final InsuranceCarResultDTO dto : resultList){
			if(inputDTO.getsPolicyNo().equals(dto.getsPolicyType() + dto.getsPolicyYM() + dto.getsPolicySer())){
				checkResult = true;
			}
		}
		if(!checkResult){
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.DifferenceContractInfoError)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		
		this.checkEndorseCar(sessionService.getSSNFromSession(session));
		
		final EndorseSpecialTermsListResultDTO dto = endorseBackBoneService.specialTermsList(inputDTO.getsPolicyNo(), sessionService.getUserID(session));
		final GenericRestResponse<EndorseSpecialTermsListResultDTO> response = new GenericRestResponse<EndorseSpecialTermsListResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ���� Ư�� ����/�߰� ���
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEndorseCarSpecialTermsCalculation")
	@ResponseBody
	public GenericRestResponse<EndorseModifySpecialResultDTO> selectEndorseCarSpecialTermsCalculation(@NotNull @RequestBody final GenericRestRequest<EndorseSpecialTermsOfPola001InfoDTO> request) {
		final EndorseSpecialTermsOfPola001InfoDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final EndorseModifySpecialResultDTO dto = endorseBackBoneService.modifySpecialTerms(inputDTO);
		final GenericRestResponse<EndorseModifySpecialResultDTO> response = new GenericRestResponse<EndorseModifySpecialResultDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(dto);
		return response;
	}

	/**
	 * <pre>
	 * ��ʺ��� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("/selectMediCoverList")
	@ResponseBody
	public GenericRestResponse<MedicalDuplicateResultDTO> searchMediCoverList(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<MedicalCoverAgreeDTO> request) {
		final MedicalCoverAgreeDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ��ʺ��� ��ȸ�ϱ�
		final List<MedicalDuplicateResultDTO> result = riaBackBoneService.getMediCoverList(sessionService.getSSNFromSession(session), sessionService.getSNameFromSession(session),
				inputDTO.getsApplyType(), inputDTO.getsApplyYM(), inputDTO.getsApplySer(), sessionService.getUserID(session));
		final GenericRestResponse<MedicalDuplicateResultDTO> response = new GenericRestResponse<MedicalDuplicateResultDTO>();
		response.setData(result);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * <pre>
	 * ��ʺ��� ���� ����
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping("/insertMediAgree")
	@ResponseBody
	public GenericRestResponse<Void> saveMediAgree(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<MedicalCoverAgreeDTO> request) {
		final MedicalCoverAgreeDTO medicalCoverAgreeDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ��ʺ��� �����ϱ�
		riaBackBoneService.insertMediAgree(medicalCoverAgreeDTO);
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * <pre>
	 * �輭 ���� ���� ����
	 * <pre>
	 * @return
	 */
	@RequestMapping("insertPaymentInfo")
	@ResponseBody
	public GenericRestResponse<Void> insertPaymentInfo(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<PaymentVO> request) {
		final PaymentVO vo = request.getRequestData().get(BigInteger.ZERO.intValue());
		if (vo == null) {
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		vo.setsUserName(sessionService.getSNameFromSession(session));
		// ��ǰ ���� �߰�
		vo.setsInsGrp(InsuranceProductEnum.CAR_INSURANCE.getType());
		session.setAttribute(SessionNameEnum.PAYMENT.name(), vo);
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * <pre>
	 * �輭 ���� ���� ��ȸ
	 * <pre>
	 * @return
	 */
	@RequestMapping("selectPaymentInfo")
	@ResponseBody
	public GenericRestResponse<PaymentVO> selectPaymentInfo(final HttpSession session) {
		final PaymentVO vo = this.getPaymentVOSession(session);
		final GenericRestResponse<PaymentVO> response = new GenericRestResponse<PaymentVO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(vo);
		return response;
	}

	/**
	 * <pre>
	 * ���� �ݾ��� 0�� �ݾ� ���� 
	 * <pre>
	 * @return
	 */
	@RequestMapping("insertEndorsePaymentNoChange")
	@ResponseBody
	public GenericRestResponse<Void> insertEndorsePaymentNoChange(final HttpSession session) {
		final PaymentVO vo = this.getPaymentVOSession(session);
		final EndorseConfirmDTO inputDTO = new EndorseConfirmDTO();
		// ���� ���� ���� copy
		BeanUtils.copyProperties(vo, inputDTO);
		final boolean demandResult = endorseBackBoneService.demandEndorse(inputDTO);
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if (demandResult) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			// ���� ���� ���� ����
			session.removeAttribute(SessionNameEnum.PAYMENT.name());
			
			//[��SBM] SMS, Email �߼�
			myPageService.contractInfoChangeSend(sessionService.getUserID(session), sessionService.getSSNFromSession(session));			
		} else {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.EndorseUpdateFail));
		}
		return response;
	}

	/**
	 * <pre>
	 * ȯ�� ����� ����
	 * <pre>
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping("insertEndorseRefund")
	@ResponseBody
	public GenericRestResponse<Void> insertEndorseRefund(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<EndorseConfirmDTO> request) throws Exception {
		final PaymentVO paymentVO = this.getPaymentVOSession(session);
		final EndorseConfirmDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		/*
		 * ���� ���� ���� ���� Ȯ��
		 * 1. ���ΰ��� ���� ����  
		 * 2. ���������ڵ�� ���������ڵ� Ȯ��
		 * 3. �������¿� �������� Ȯ��
		 */
		
		//���¹�ȣ��ȣȭ
		inputDTO.setsReqAcctNo( certificationService.touchenKeyDec(inputDTO.getsHid_key_data() , inputDTO.getsReqAcctNo() , session) );
		logger.info("[��SBM] "+inputDTO.getsReqAcctNo());
		if (!paymentVO.isOwnedAccount() || !inputDTO.getsReqBankCode().equals(paymentVO.getsOwnedBankCode()) || !inputDTO.getsReqAcctNo().equals(paymentVO.getsOwnedAccountNo())) {
			logger.error("���� ���� ������ �ʿ�");
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.PaymentOwnedAccountEmpty)).build();
		}
		// ���� ���� ���� copy
		BeanUtils.copyProperties(paymentVO, inputDTO);
		// �Ǹ�Ȯ��ID(���� �ֹι�ȣ)
		inputDTO.setsRealID(sessionService.getSSNFromSession(session));
		// ������Ȯ�� (Y:Ȯ��, N:��Ȯ��)
		inputDTO.setsConfirm("Y");
		// �����ֿ��ǰ��� (1:����, 2:��Ÿ)
		inputDTO.setsRel("1");
		// ȯ�ޱ� �ݾ׿� - ��ȣ�� �ٿ��ش�.
		inputDTO.setnRefundAmt("-" + inputDTO.getnRefundAmt());
		final boolean demandResult = endorseBackBoneService.demandEndorse(inputDTO);
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if (demandResult) {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			// ���� ���� ���� ����
			session.removeAttribute(SessionNameEnum.PAYMENT.name());
			
			//[��SBM] SMS, Email �߼�
			myPageService.contractInfoChangeSend(sessionService.getUserID(session), sessionService.getSSNFromSession(session));
		} else {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.EndorseUpdateFail));
		}
		return response;
	}

	/**
	 * <pre>
	 * �輭 Ȯ���� �̸��� �߼��� ���� ���� �̸��� ��ȸ
	 * <pre>
	 * @param session
	 * @return
	 */
	@RequestMapping("selectUserEmail")
	@ResponseBody
	public GenericRestResponse<String> selectUserEmail(final HttpSession session) {
		final GenericRestResponse<String> response = new GenericRestResponse<String>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(this.getUserEmail(session));
		return response;
	}

	@RequestMapping("sendEndorseConfirmation")
	@ResponseBody
	public GenericRestResponse<Void> sendEndorseConfirmation(final HttpSession session) {
		final CarSendCertificateDTO inputDTO = sessionService.getAttribute(session, SessionNameEnum.ENDORSE_APPLY_INFO.name(), CarSendCertificateDTO.class);
		if (inputDTO == null) {
			logger.error("�輭 Ȯ���� ���� �߼� : ���� �߼� ���� ������ ����");
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		inputDTO.setsDmCode(SendCertificateDMCodeEnum.ENDORSE_CERTIFICATE.getCode());
		// �߱޹� ���� 1:�¶���,2:�ѽ�,3:�̸���, 5:report => �̸��� �߼۸� ���
		inputDTO.setRmethod("3");
		inputDTO.setsCustNm(sessionService.getSNameFromSession(session));
		inputDTO.setsCustNo(sessionService.getSSNFromSession(session));
		inputDTO.setsEmail(this.getUserEmail(session));

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		if (riaBackBoneService.sendCertificate(inputDTO)) {
			logger.debug("�輭 Ȯ���� ���� �߼� ����");
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		} else {
			logger.error("�輭 Ȯ���� ���� �߼� ����");
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		return response;
	}

	/**
	 * <pre>
	 * ���� ���� ���� return 
	 * ���� ������ ������ InvalidException �߻� -> ���� ������ �ε��� �������� �̵�
	 * <pre>
	 * @param session
	 * @return
	 */
	private PaymentVO getPaymentVOSession(final HttpSession session) {
		final PaymentVO vo = sessionService.getAttribute(session, SessionNameEnum.PAYMENT.name()) == null ? null : (PaymentVO) sessionService.getAttribute(session, SessionNameEnum.PAYMENT.name());
		if (vo == null) {
			logger.error("ȯ�� ����� ���� ������ �������� ����.");
			throw new InvalidRequestException.Builder(message.getMessage(ExceptionMessage.PaymentSessionEmpty)).forwardUrl(WebServletEnum.MYPAGE_LOGIN_INDEX_URL).build();
		}
		return vo;
	}

	/**
	 * <pre>
	 * �ֱٰ���������� �̸��� return
	 * ������ empty String return
	 * <pre>
	 * @param session
	 * @return
	 */
	private String getUserEmail(final HttpSession session) {
		final CustPopInfoWrapperDTO resultList = myEducarServiceBackBoneService.seletCustPopInfo(sessionService.getSSNFromSession(session));
		return StringUtils.defaultString(resultList.getTelInfo().getsEmail1(), StringUtils.EMPTY);
	}
	
	/**
	 * <pre>
	 * ����������� ������ �� �ҷ����� üũ�ؼ� ����ó�� �Ѵ�.
	 * ����,�ű�,�輭 3���� ������� �ؼ� �л�ĳ�ÿ� �ְ� ������ ����. 
	 * <pre>
	 * @param session
	 * @return
	 */
	private void checkEndorseCar(final String sCustNo){
		if(riaBlockListUtil.containsID(sCustNo)){
			throw new BackBoneException(message.getMessage(ExceptionMessage.EndorseSecurityError));
		}
	}
}
