/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.claim;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.dao.ClaimDAO;
import com.educar.dto.web.claim.EmergencyActionDTO;
import com.educar.dto.web.claim.EmergencyActionSearchDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.backbone.ClaimBackBoneService;

/**
 * ���󼭺� ����ī ���� ��Ʈ�ѷ�
 * @author ������ 
 * @since 1.0.0
 */
@RequestMapping("claimEducarService")
@Controller
public class ClaimEducarServiceController {
	/** ���󼭺� �Ⱓ�� ȣ�� ���� **/
	@Autowired
	private ClaimBackBoneService claimBackBoneService;
	/** ����⵿ ��ȸ dao **/
	@Autowired
	private ClaimDAO claimDAO;

	/**
	 * ����⵿ ���� �� ��� ��ȸ
	 * @return List<EmergencyActionDTO> sAdrs1
	 */
	@RequestMapping("selectEmergencyCity")
	@ResponseBody
	public GenericRestResponse<EmergencyActionDTO> selectEmergencyCity() {
		final List<EmergencyActionDTO> resultList = claimDAO.selectAdrs1List();
		final GenericRestResponse<EmergencyActionDTO> response = new GenericRestResponse<EmergencyActionDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * ����⵿ ���� �� ��� ��ȸ
	 * @return List<EmergencyActionDTO> sAdrs2
	 */
	@RequestMapping("selectEmergencyGu")
	@ResponseBody
	public GenericRestResponse<EmergencyActionDTO> selectEmergencyGu(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final List<EmergencyActionDTO> resultList = claimDAO.selectAdrs2List(request.getRequestData().get(BigInteger.ZERO.intValue()));
		final GenericRestResponse<EmergencyActionDTO> response = new GenericRestResponse<EmergencyActionDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * ����⵿ ���� ��� ��ȸ �Ⱓ�� ȣ���
	 * @return List<EmergencyActionDTO>
	 */
	@RequestMapping("selectEmergencyActionList")
	@ResponseBody
	public GenericRestResponse<EmergencyActionDTO> selectEmergencyActionList(@NotNull @RequestBody final GenericRestRequest<EmergencyActionSearchDTO> request) {

		final EmergencyActionSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final List<EmergencyActionDTO> resultList = claimBackBoneService.emergencyActionList(dto);
		final GenericRestResponse<EmergencyActionDTO> response = new GenericRestResponse<EmergencyActionDTO>();
		response.setData(resultList);
		return response;
		
	}
	
	

	/**
	 * ����⵿ ���� ��� ��ȸ ��dbȣ���
	 * @return List<EmergencyActionDTO>
	 */
	@RequestMapping("selectEmergencyActionListDB")
	@ResponseBody
	public GenericRestResponse<EmergencyActionDTO> selectEmergencyActionListDB(@NotNull @RequestBody final GenericRestRequest<EmergencyActionDTO> request) {

		final EmergencyActionDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		// �� �Ǽ� ��ȸ
		Integer totalCount = claimDAO.selectEmergencyActionCount(dto);
		if (totalCount == null) {
			totalCount = BigInteger.ZERO.intValue();
		}
		dto.setTotalCount(totalCount);

		final List<EmergencyActionDTO> resultList = claimDAO.selectEmergencyActionList(dto);
		if (resultList != null) {
			for (final EmergencyActionDTO resultDTO : resultList) {
				final String address = resultDTO.getsAdrs1() + " " + resultDTO.getsAdrs2() + " " + resultDTO.getsAdrs3();
				resultDTO.setAddress(address);
				// ��ǥ���� �ִ´�. ������ null�� ����.
				final List<String> cords = claimBackBoneService.getXY(resultDTO.getsAdrs1() + resultDTO.getsAdrs2() + resultDTO.getsAdrs3());
				if (cords != null && cords.size() == 2) {
					resultDTO.setX(cords.get(0));
					resultDTO.setY(cords.get(1));
				}
			}
		}
		final GenericRestResponse<EmergencyActionDTO> response = new GenericRestResponse<EmergencyActionDTO>();
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
