/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.product;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.DistributedCacheService;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.FTPService;
import com.educar.common.service.FileService;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.PropertyService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.common.vo.BasicCodeVO;
import com.educar.common.vo.FTPConnectionInfoVO;
import com.educar.common.vo.FileVO;
import com.educar.common.vo.JehuCodeVO;
import com.educar.dao.MemberMarketingAgreementDAO;
import com.educar.dto.web.PersonalInformationAgreementDTO;
import com.educar.dto.web.log.WebHistoryDTO;
import com.educar.dto.web.products.CalculationOfTripWrapperDTO;
import com.educar.dto.web.products.OfferDetailResultDTO;
import com.educar.dto.web.products.OfferSearchDTO;
import com.educar.dto.web.products.OfferSearchResultDTO;
import com.educar.dto.web.products.TripCodeDTO;
import com.educar.dto.web.products.TripPlanDTO;
import com.educar.enumeration.BasicCodeHashKeyEnum;
import com.educar.enumeration.DomainEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.enumeration.SystemPropertyEnum;
import com.educar.enumeration.WebHistoryApplyStatEnum;
import com.educar.enumeration.WebHistoryKeyTypeEnum;
import com.educar.enumeration.WebServletEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.InsuranceProductsBackBoneService;
import com.educar.service.backbone.LoginBackBoneService;
import com.educar.service.backbone.WebLogBackBoneService;

/**
 * <pre>
 * �����ǰ - ����/���� ��Ʈ�ѷ�
 * <pre>
 * @author ��â��
 *
 */
@Controller
@RequestMapping("/productTravelLeisure")
public class TravelLeisureController {

	private final static Logger logger = Logger.getLogger(TravelLeisureController.class);

	/** message service */
	@Autowired
	private MessageSourceService messageService;

	/** properties service */
	@Autowired
	private PropertyService propertyService;

	/** ���� ��ǰ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceProductsBackBoneService insuranceProductsBackBoneService;

	/** �л� ĳ�� ���� **/
	@Autowired
	private DistributedCacheService distributedCacheService;

	/** ���� ���� */
	@Autowired
	private FileService fileService;

	/** FTP ���� */
	@Autowired
	private FTPService ftpService;

	/** �� �α� �Ⱓ�� ���� **/
	@Autowired
	private WebLogBackBoneService webLogBackBoneService;

	@Autowired
	private SessionService sessionService;
	/** ��� ������ ����.. **/
	@Autowired
	private LoginBackBoneService loginBackBoneService;
	
	/** �������� ���� DAO **/
	@Autowired
	private MemberMarketingAgreementDAO memberMarketingAgreementDAO;
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	
	/**
	 * ����� ��ȸ/û�� �Է����� �ʱ�ȭ
	 */
	@RequestMapping("insuranceSeekInitStep")
	@ResponseBody
	public GenericRestResponse<Void> insuranceSeekInitStep(final HttpSession session) {
		session.removeAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * ����� ��ȸ/û�� ���� �ܰ�
	 */
	@RequestMapping("insuranceSeekCurrStep")
	@ResponseBody
	public GenericRestResponse<CalculationOfTripWrapperDTO> insuranceSeekCurrStep(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<Integer> request) {
		final Integer requestStep = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<CalculationOfTripWrapperDTO> response = new GenericRestResponse<CalculationOfTripWrapperDTO>();

		final Object sessionObject = session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		// ���� �Է� �ܰ� ����
		if (requestStep == null || requestStep == 1 && sessionObject == null) {
			// 1 �ܰ� ù�湮
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			return response;
		} else if (requestStep > 0 && requestStep < 5 && sessionObject != null) {
			final CalculationOfTripWrapperDTO sessionDTO = (CalculationOfTripWrapperDTO) sessionObject;
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(sessionDTO);
			return response;
		} else {
			// Step1(����� ���� �Է�) ���� �۰ų� Step5(û�೻��Ȯ��) ���� ũ�� ���� ���� �߻�
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyStepOne)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}
	}

	/**
	 * ����� ��ȸ/û�� ���� �ܰ�
	 */
	@RequestMapping("insuranceSeekNextStep")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.products.CalculationOfGENAA11DTO", "sCellPhone1", "sCellPhone2", "sCellPhone3" }, register = CheckHTelNum.class)
	public GenericRestResponse<Void> insuranceSeekNextStep(final HttpServletRequest servletRequest, @NotNull @RequestBody final GenericRestRequest<CalculationOfTripWrapperDTO> request) {
		final CalculationOfTripWrapperDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final HttpSession session = servletRequest.getSession();
		final PersonalInformationAgreementDTO personInfoAgreeDto = new PersonalInformationAgreementDTO();
		
		// ���� �Է� �ܰ� ����
		// Step1(����� ���� �Է�) ���� �۰ų� Step5(û�೻��Ȯ��) ���� ũ�� ���� ���� �߻�
		final Integer requestInputFinalStep = requestDTO.getInputFinalStep();
		
		if (requestInputFinalStep == null || requestInputFinalStep < 1 || requestInputFinalStep > 5) {
			if(StringUtils.isNotEmpty(requestDTO.getGENAA01().getsAffiliatedConcern())){
				throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_JEHU_STEP_ONE_URL).build();
			}else{
				throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
			}
			
		}
		
		//2013.07.30 2�ܰ迡�� 3�ܰ� �Ѿ�� ���� ���ε�
		if(requestInputFinalStep.equals(3)){
			
			logger.debug("insuranceSeekNextStep >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + requestInputFinalStep);
			logger.debug("insuranceSeekNextStep >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + requestInputFinalStep);
			// ���ε� ���� ó�� : GENAA16 - sFileName �ӽ����Ͽ��� �������Ϸ� ����
			final String baseTempURI = propertyService.getProperty(SystemPropertyEnum.FILE_TEMP_BASE_URI.getKey());
			final String filePath = requestDTO.getGENAA16().getsFileName();
			final String fileName = requestDTO.getGENAA16().getsFileNameForScreen();
			logger.debug("���� FTP ���ε�  ##################################### filePath / fileName >" + filePath +"/" + fileName);
			
			final File srcFile = new File(baseTempURI + File.separator + filePath + File.separator + fileName);
			boolean uploadChk = false;
			
			if (srcFile.exists()) {
				// �ӽ����� �������� ��� ��ġ�� �̵� & �ӽõ��丮 ����
				final String[] travelRemoteFilePaths = { "legacy", "gen_travel", DateTime.now().toString("yyyyMM") };
				final StringBuilder remoteFilePath = new StringBuilder();
				final FTPConnectionInfoVO connectionVO = ftpService.getImageServerConnectionInfo();
				remoteFilePath.append(propertyService.getProperty(SystemPropertyEnum.FTP_IMAGE_SERVER_PATH.getKey()));
				ftpService.makeDirectory(connectionVO, remoteFilePath.toString(), travelRemoteFilePaths); // ������ ���ٸ� ����
				for (final String travelRemoteFilePath : travelRemoteFilePaths) {
					remoteFilePath.append(FTPService.FILE_SEPARATOR).append(travelRemoteFilePath);
				}
				// �̹��� ���� FTP ���ε�
				final String destFileName = System.currentTimeMillis() + (fileName.lastIndexOf(".") < 0 ? "" : "." + StringUtils.substringAfterLast(fileName, "."));
				uploadChk = ftpService.upload2(connectionVO, srcFile.getAbsolutePath(), remoteFilePath.toString() + FTPService.FILE_SEPARATOR + destFileName);
				logger.debug("���� FTP ���ε�  #####################################");
				logger.debug("##########################" + uploadChk + "########################");
				requestDTO.getGENAA16().setsFileName(destFileName);
			}
			
			
		}
			
		//2013.04.02 - �������� ����.�̿뿡 ���� ��� ����
		//WEBDD53 - ���� �� �����Ѵ�.
		String strCallNum = "";
		if(requestDTO.getGENAA11().getsCellPhone1() != null){
			strCallNum = requestDTO.getGENAA11().getsCellPhone1() + requestDTO.getGENAA11().getsCellPhone2() + requestDTO.getGENAA11().getsCellPhone3();
		}else{
			strCallNum = requestDTO.getGENAA11().getsHomeTel1() + requestDTO.getGENAA11().getsHomeTel2() + requestDTO.getGENAA11().getsHomeTel3();
		}
		
		personInfoAgreeDto.setsAgreeId("33"); 						//��� ID
		personInfoAgreeDto.setsAgreeYN(requestDTO.getAgree().getJoinAgree().get(0));   //���ǿ��� Y
		personInfoAgreeDto.setsCallNum(strCallNum);					//����ó
		personInfoAgreeDto.setsName(requestDTO.getGENAA11().getsMainConnName());  //����ڸ�
		
		memberMarketingAgreementDAO.insertPersonalInfoAgree(personInfoAgreeDto);
		
		// ���� �Է� �ܰ�� ���ǿ� ����� ���� �Է� �ܰ� ���� ���Ͽ� ������������ ���� �Է� �ܰ� ���� �����Ѵ�.
		if (session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name()) != null) {
			final CalculationOfTripWrapperDTO sessionDTO = (CalculationOfTripWrapperDTO) session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
			if (requestInputFinalStep < sessionDTO.getInputFinalStep()) {
				requestDTO.setInputFinalStep(sessionDTO.getInputFinalStep());
			}
		}
		session.setAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name(), requestDTO);

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * ���� ���� ��� ��ȸ
	 * @param request ���� ���� �ڵ� (������ : "3055", ������� : "3057")
	 */
	@RequestMapping("selectTripCodeList")
	@ResponseBody
	public GenericRestResponse<TripCodeDTO> selectTripCodeList(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String tripInfoCode = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<TripCodeDTO> response = new GenericRestResponse<TripCodeDTO>();
		final List<TripCodeDTO> tripCodeList = insuranceProductsBackBoneService.getTripInfo(tripInfoCode);
		if (tripCodeList == null || tripCodeList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(messageService.getMessage(ExceptionMessage.SelectEmpty, "��������"));
		} else {
			response.setData(tripCodeList);
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		}
		return response;
	}

	/**
	 * ������ ���� �������� ���ε�
	 * �������� ��Ŀ� ���� ��ũ��Ʈ�� ��ȯ�ؾ� �Ѵ� (�ҽ� ����)
	 *
	 * @param file ���� ��ü
	 * @param fileId ���� ���̵�
	 * @param componentId WebSquare UI ������Ʈ ��ü ���̵�
	 * @param fileType ���� ����
	 * @param response HttpServletResponse
	 * @throws IOException
	 */
	@RequestMapping("uploadMemberList")
	public void handleMemberFileUpload(@RequestParam("upload") final MultipartFile file, @RequestParam(value = "fileId", required = false) final String fileId, @RequestParam final String componentId,
			final HttpServletResponse response) throws IOException {
		FileVO fileVO = fileService.handleFileUploadPrepare(file, fileId);
		if (StringUtils.isNotBlank(fileVO.getErrorMessage())) {
			fileService.handleFileUploadResult(componentId, fileVO, response);
			return;
		}

		final byte[] bytes = file.getBytes();
		final String fileName = file.getOriginalFilename();
		fileVO.setName(fileName);

		Workbook workbook = null;
		// ÷������ ���� ��ȿ�� ����
		try {
			workbook = Workbook.getWorkbook(file.getInputStream());
		} catch (final Exception e) {
			logger.debug("Excel file upload Exception : " + e.getMessage());
			fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelExt));
			fileService.handleFileUploadResult(componentId, fileVO, response);
			return;
		}
		// ���� ��Ʈ ���� ����
		if (workbook.getSheets().length > 1) {
			fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelSheet));
			fileService.handleFileUploadResult(componentId, fileVO, response);
			return;
		}

		final Sheet sheet = workbook.getSheet(0); // ù ��° ��Ʈ ����
		final Set<String> memberSet = new HashSet<String>(); // �ֹε�Ϲ�ȣ �ߺ� ������ �ϱ� ���� Set ��ü
		for (int row_idx = 1; row_idx < sheet.getRows(); row_idx++) { // 0 ��° ���� ��� �����̾ 1 ��° ����� for ���� ����
			final Cell nameCell = sheet.getCell(0, row_idx); // ����
			final Cell ssnCell = sheet.getCell(1, row_idx); // �ֹε�Ϲ�ȣ

			// ���� ������ ����
			if (ssnCell.getType() != CellType.LABEL && ssnCell.getType() != CellType.STRING_FORMULA) {
				fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelCellText));
				break;
			}

			final String name = nameCell.getContents();
			final String ssn = StringUtils.trim(StringUtils.remove(ssnCell.getContents(), "-"));

			if ((StringUtils.isBlank(name) && StringUtils.isNotBlank(ssn)) || (StringUtils.isNotBlank(name) && StringUtils.isBlank(ssn))) {
				// ���� �� �ʸ� �����Ͱ� ���� ��� ����
				fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelWrongData, row_idx));
				break;
			} else if (!StringUtils.isNumeric(ssn) || ssn.length() != 13) {
				fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelWrongSSN, row_idx));
				break;
			}

			// �ߺ� ������ �ϱ� ���� Set ��ü�� �ֹι�ȣ�� ����
			memberSet.add(ssn);
			if (memberSet.isEmpty() || memberSet.size() != row_idx) {
				fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.FileUploadValidExcelDuplicateData, row_idx));
				break;
			}
		}

		if (StringUtils.isBlank(fileVO.getErrorMessage())) {
			if (memberSet.size() < 5) {
				// 5�� �̸� ����
				fileVO.setErrorMessage(messageService.getMessage(ExceptionMessage.ProductDomesticTravelMinMemberSize));
			} else {
				// ���� �޽����� ���� ��쿡�� ���� �����̹Ƿ� ���� ���ε带 �����Ѵ�.
				fileVO = fileService.uploadTempFile(bytes, fileVO);
			}
		}
		fileService.handleFileUploadResult(componentId, fileVO, response);
	}

	/**
	 * ���� �÷� ��ȸ
	 */
	@RequestMapping("selectTripPlanList")
	@ResponseBody
	public GenericRestResponse<TripPlanDTO> selectTripPlanList(final HttpSession session) throws IOException {
		final Object sessionObject = session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		if (sessionObject == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyStepOne)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}

		final CalculationOfTripWrapperDTO tripWrapperDTO = (CalculationOfTripWrapperDTO) sessionObject;
		final GenericRestResponse<TripPlanDTO> response = new GenericRestResponse<TripPlanDTO>();
		final List<TripPlanDTO> tripPlanList = insuranceProductsBackBoneService.getPlanTypeList(tripWrapperDTO.getGENAA01().getsFmdt());
		if (tripPlanList == null || tripPlanList.isEmpty()) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(messageService.getMessage(ExceptionMessage.SelectEmpty, "�����÷�"));
		} else {
			response.setData(tripPlanList);
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		}
		return response;
	}

	/**
	 * ����� ��ȸ
	 */
	@RequestMapping("selectInsuranceCalculation")
	@ResponseBody
	public GenericRestResponse<OfferDetailResultDTO> selectInsuranceCalculation(@RequestBody final GenericRestRequest<Void> request, final HttpSession session) throws IOException {
		final Object sessionObject = session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		final GenericRestResponse<OfferDetailResultDTO> response = new GenericRestResponse<OfferDetailResultDTO>();
		
		if (sessionObject == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyStepOne)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}

		final CalculationOfTripWrapperDTO tripWrapperDTO = (CalculationOfTripWrapperDTO) sessionObject;
		if (tripWrapperDTO.getInputFinalStep() != 5) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}
		
		
		// �����ڵ� & �̺�Ʈ ó��
		final String sAffiliatedConcernKey = sessionService.getsAffiliatedConcernKey(session);

		final JehuCodeVO jehuCodeVO = distributedCacheService.getJehuCode(sAffiliatedConcernKey);
		tripWrapperDTO.getGENAA01().setsAffiliatedConcern(jehuCodeVO.getsAffiliatedConcern());
		tripWrapperDTO.getGENAA01().setsEventDiv(jehuCodeVO.getsEventDiv());

		//���Ͼ��ε� �־���.!!!

		// ����Ȱ�� �⺻ �� ����
		tripWrapperDTO.getGENAA36().setsRiskActCd1(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd1(), "0"));
		tripWrapperDTO.getGENAA36().setsRiskActCd2(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd2(), "0"));
		tripWrapperDTO.getGENAA36().setsRiskActCd3(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd3(), "0"));
		tripWrapperDTO.getGENAA36().setsRiskActCd4(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd4(), "0"));
		tripWrapperDTO.getGENAA36().setsRiskActCd5(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd5(), "0"));
		tripWrapperDTO.getGENAA36().setsRiskActCd6(StringUtils.defaultString(tripWrapperDTO.getGENAA36().getsRiskActCd6(), "0"));
		session.setAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name(), tripWrapperDTO);
		
		// N1401-00089 �����θ��ּ� - ǥ���ּ� ��ȯ
		StandardRoadAddrDTO stndAddrDto = new StandardRoadAddrDTO();
		stndAddrDto.setTableNm("CUSAA02");
		stndAddrDto.setLoginId(sessionService.getUserID(session));
		//�� ���θ� ǥ���ּ� 
		if(tripWrapperDTO.getGENAA11().getsStdAddrFlag().equals("Y")){
			stndAddrDto.setsAddrMgtNo(tripWrapperDTO.getGENAA11().getsAddrMgtNo());
			stndAddrDto.setVarPost(tripWrapperDTO.getGENAA11().getsZip1()+tripWrapperDTO.getGENAA11().getsZip2());
			stndAddrDto.setVarAllAddress(tripWrapperDTO.getGENAA11().getsDoroAddr() + tripWrapperDTO.getGENAA11().getsAdrsAdd());
			
			final StandardRoadAddrDTO resultAdr = adresssSearchBackBoneService.selectStandardAddr(stndAddrDto);

			tripWrapperDTO.getGENAA11().setsAdrs1(resultAdr.getWeb_sCityName());
			tripWrapperDTO.getGENAA11().setsAdrs2(resultAdr.getWeb_sCountyName());
			tripWrapperDTO.getGENAA11().setsAdrs3(resultAdr.getWeb_sTownName());
			tripWrapperDTO.getGENAA11().setsAdrsAdd(resultAdr.getAnlysStndRdNmUndrAddrA());
		}
				
		
		
		final OfferDetailResultDTO resultDTO = insuranceProductsBackBoneService.getPrem(tripWrapperDTO, sessionService.getUserID(session));
		
		if (resultDTO == null || resultDTO.getGENAA01() == null || resultDTO.getGENAA41() == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(messageService.getMessage(ExceptionMessage.SelectEmpty));
		} else if (!"0".equals(resultDTO.getGENAA01().getErrCode()) || !"0".equals(resultDTO.getGENAA01().getLmtType()) || "2".equals(resultDTO.getGENAA01().getErrCode())) {
			if(StringUtils.isBlank(sAffiliatedConcernKey)){
				// ����������� ���������� ������ ������ �Ǵ� �μ� ���н�
				response.setStatus(ResponseStatusEnum.BACK_BONE_EXCEPTION.getCode());
				response.setMessage(messageService.getMessage(ExceptionMessage.BackBoneException));
				response.setForwardURL(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL, session);

				if ("".equals(resultDTO.getGENAA01().getErrCode()) || !"0".equals(resultDTO.getGENAA01().getLmtType())) {
					response.setMessage(messageService.getMessage(ExceptionMessage.ProductDomesticTravelUnsupportInternet));
				}
				if ("2".equals(resultDTO.getErrCode())) {	
					response.setForwardURL(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_FOUR_URL, session);
					response.setMessage(messageService.getMessage(ExceptionMessage.ProductDomesticTravelUnsupportInternet));
				}
			}else{  // �������������� �����Ҷ� return url 
				response.setStatus(ResponseStatusEnum.BACK_BONE_EXCEPTION.getCode());
				response.setMessage(messageService.getMessage(ExceptionMessage.BackBoneException));
				response.setForwardURL(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_JEHU_STEP_ONE_URL, session);

				if ("".equals(resultDTO.getGENAA01().getErrCode()) || !"0".equals(resultDTO.getGENAA01().getLmtType())) {
					response.setMessage(messageService.getMessage(ExceptionMessage.ProductDomesticTravelUnsupportNuriwell));
				}
				if ("2".equals(resultDTO.getErrCode())) {	
					response.setForwardURL(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_JEHU_STEP_FOUR_URL, session);
					response.setMessage(messageService.getMessage(ExceptionMessage.ProductDomesticTravelUnsupportNuriwell));
				}
			}
			
		} else {
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 34234 33333  " + resultDTO.getGENAA01().getErrCode());
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(resultDTO);

			// �� �α� �̷� ����
			final WebHistoryDTO webHistoryDTO = new WebHistoryDTO();

			// BasicCode ����
			final BasicCodeVO basicCodeVO = distributedCacheService.getBasicCode(BasicCodeHashKeyEnum.PRODUCT_DOMESTIC_TRAVEL);
			webHistoryDTO.setnTaskID(basicCodeVO.getCCCEA07Task1());
			webHistoryDTO.setsCustNo(tripWrapperDTO.getGENAA11().getsCustNo()); // ����� ��ȣ
			webHistoryDTO.setsKey(resultDTO.getGENAA01().getsApplyNo()); // �����ȣ
			webHistoryDTO.setnKeyType(WebHistoryKeyTypeEnum.PRODUCT_DRIVER_TRAVEL.getCode());
			webHistoryDTO.setsPlateNo(StringUtils.EMPTY);
			webHistoryDTO.setsApplyStat(WebHistoryApplyStatEnum.INSURANCE_CALCULATION.getCode()); // ����� ����
			webHistoryDTO.setsDescription(basicCodeVO.getsDescription1());
			webLogBackBoneService.insertWebHistory(webHistoryDTO, sessionService.getUserID(session));

		}
		
		return response;
	}

	/**
	 * û������ �̸��� �Ǵ� �ѽ� ����<br>
	 * �Է¹��� �̸����ּ� �Ǵ� �ѽ���ȣ�� ���� ��쿡�� ���� �õ��Ѵ�.
	 */
	@RequestMapping("handleSendApplyInfo")
	@ResponseBody
	@Validate
	public GenericRestResponse<Void> handleSendApplyInfo(@NotNull @RequestBody final GenericRestRequest<OfferDetailResultDTO> request, final HttpSession session) {
		final Object sessionObject = session.getAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		if (sessionObject == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.SessionEmptyStepOne)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}

		final CalculationOfTripWrapperDTO tripWrapperDTO = (CalculationOfTripWrapperDTO) sessionObject;
		if (tripWrapperDTO.getInputFinalStep() != 5) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.InvalidRequest)).forwardUrl(WebServletEnum.PRODUCT_DOMESTIC_TRAVEL_STEP_ONE_URL).build();
		}

		final OfferDetailResultDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		// �ѽ� ����
		if (StringUtils.isNotBlank(tripWrapperDTO.getGENAA11().getsFax1()) && StringUtils.isNotBlank(tripWrapperDTO.getGENAA11().getsFax2())
				&& StringUtils.isNotBlank(tripWrapperDTO.getGENAA11().getsFax3())) {
			final String backBoneMessage = insuranceProductsBackBoneService.sendFaxApplyInfoForDom(dto.getGENAA01().getsApplyNo(), sessionService.getUserID(session));
			if (StringUtils.isNotBlank(backBoneMessage)) {
				response.setStatus(ResponseStatusEnum.BACK_BONE_EXCEPTION.getCode());
				response.setMessage(backBoneMessage);
				return response;
			}
		}
		// �̸��� ����
		if (StringUtils.isNotBlank(tripWrapperDTO.getGENAA11().getsEmail1())) {
			final String backBoneMessage = insuranceProductsBackBoneService.sendEmailApplyInfoForDom(dto.getGENAA01().getsApplyNo(), sessionService.getUserID(session));
			if (StringUtils.isNotBlank(backBoneMessage)) {
				response.setStatus(ResponseStatusEnum.BACK_BONE_EXCEPTION.getCode());
				response.setMessage(backBoneMessage);
				return response;
			}
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * <pre>
	 * û�೻�� ��ȸ/Ȯ�� ��� ��ȸ
	 * <pre>
	 * @param <OfferSearchDTO>
	 * @return <OfferSearchResultDTO>
	 */
	@RequestMapping(value = "selectOfferHistoryList")
	@ResponseBody
	public GenericRestResponse<OfferSearchResultDTO> selectBidNotificationList(@NotNull @RequestBody final GenericRestRequest<OfferSearchDTO> request) {
		final OfferSearchDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<OfferSearchResultDTO> response = new GenericRestResponse<OfferSearchResultDTO>();
		final List<OfferSearchResultDTO> resultList = insuranceProductsBackBoneService.getApplyList(dto);
		response.setData(resultList);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}

	/**
	 * û�೻�� �󼼳��� ��ȸ
	 * @param String sApplyNo û���ȣ
	 * @return <OfferDetailResultDTO> �󼼳���
	 */
	@RequestMapping(value = "selectOfferHistoryView")
	@ResponseBody
	public GenericRestResponse<OfferDetailResultDTO> selectOfferHistoryView(@NotNull @RequestBody final GenericRestRequest<String> request) {
		final String sApplyNo = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<OfferDetailResultDTO> response = new GenericRestResponse<OfferDetailResultDTO>();
		final OfferDetailResultDTO resultDto = insuranceProductsBackBoneService.getApplyDataDetail(sApplyNo);
		response.addResponseData(resultDto);
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * ����� ��ȸ/û�� �Է����� �ʱ�ȭ( ���� ���������� ��� )
	 */
	@RequestMapping("insuranceSeekInitInPageStep")
	@ResponseBody
	public GenericRestResponse<Void> insuranceSeekInitInPageStep(final HttpSession session , @RequestBody final GenericRestRequest<Void> request) {
		session.removeAttribute(SessionNameEnum.PRODUCT_DOMESTIC_TRAVEL.name());
		// ���� �ڵ带 ���ǿ� ����
		if (request != null && StringUtils.isNotBlank(request.getsAffiliatedConcernKey())) {
			session.setAttribute(SessionNameEnum.AFFILIATED_CONCERN_KEY.toString(), request.getsAffiliatedConcernKey());
		}
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
}
