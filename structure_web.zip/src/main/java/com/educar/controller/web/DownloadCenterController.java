/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.net.ConnectException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.FTPService;
import com.educar.common.service.PropertyService;
import com.educar.dto.web.DownloadCenterDTO;
import com.educar.enumeration.ResponseContentEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SystemPropertyEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.web.DownloadCenterService;
import com.inswave.system.network.ftp.FTP;
import com.inswave.system.network.ftp.FTPConstants;

/**
 * <pre>
 * �������� - �ٿ�ε弾�� ��Ʈ�ѷ�
 * 
 * <pre>
 * @author ��â��(Chang ju Lee)
 * 
 */
@Controller
@RequestMapping("/downloadCenter")
public class DownloadCenterController {

	@Autowired
	private DownloadCenterService downloadService;
	
	@Autowired
	private FTPService ftpService;
	
	@Autowired
	private PropertyService propService;
	
	/** �ΰ� **/
	private Logger logger = Logger.getLogger(getClass());
	/**
	 * <pre>
	 * �ٿ�ε弾�� ��� ��ȸ
	 * sType ĳ�Ͱ��� ���п� ���� �˻��� �Ѵ�.  null�̸� ��ü �˻�
	 * <pre>
	 * @param request
	 * @return GenericRestResponse<DownloadCenterDTO> �ٿ�ε弾�� ����Ʈ
	 */
	@RequestMapping(value = "downloadCenter/list")
	@ResponseBody
	public GenericRestResponse<DownloadCenterDTO> downloadCenterList(@NotNull @RequestBody final GenericRestRequest<DownloadCenterDTO> request) {
		final DownloadCenterDTO requestDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final GenericRestResponse<DownloadCenterDTO> response = new GenericRestResponse<DownloadCenterDTO>();

		List<DownloadCenterDTO> downloadCenterList = downloadService.listAllDocuments(requestDTO);
		if (downloadCenterList == null) {
			downloadCenterList = new ArrayList<DownloadCenterDTO>();
		}
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(downloadCenterList);
		return response;
	}   

	/**
	 * ������ �ٿ�ε� �Ѵ�.  ���������� download�� �ް� �ȴ�.
	 * @param request �ٿ�ε� �� ���� ID�� ���� ��ü
	 * @param response HttpServletResponse ������ write�� reponse��ü
	 */
	@RequestMapping(value = "downloadCenter/download")
	public void requestDownload(@NotNull final String xmlValue, final HttpServletResponse response) {
		downloadService.requestFileDownload(Integer.parseInt(xmlValue), response);
	}
	
	
	/**
	 * http://localhost/downloadCenter/getdocname.do?nSerial=Ű������.
	 * ftp�ٿ�ε�
	 * @return
	 */
	@RequestMapping(value = "/getdocname")
	public ModelAndView getDocName(final HttpServletRequest request) {
		String sFolder = request.getParameter("sFolder");
		String nSerial_ext = (request.getParameter("nSerial")+".jpg").replace("filenm_", "");
		String nSerial = nSerial_ext.replace(".jpg", "");
		String nFileCnt = request.getParameter("nSeq") != null && !request.getParameter("nSeq").equals("") ?request.getParameter("nSeq"):"0";
		String isNew = request.getParameter("isNew") != null && !request.getParameter("isNew").equals("") ?request.getParameter("isNew"):"0";

		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		String ip = null;
		String userId = null;
		String password = null;
		
		String remoteFilePath = propService.getProperty(SystemPropertyEnum.IMAGE_FTP_FILE_PATH.getKey());		
		if(isNew.equals("1")) remoteFilePath = propService.getProperty(SystemPropertyEnum.IMAGE_FTP_FILE_PATH2.getKey());
				
		final String downFilePath = propService.getProperty(SystemPropertyEnum.IMAGE_FTP_FILE_DOWNPATH.getKey());
		final String urlParam = propService.getProperty(SystemPropertyEnum.IMAGE_FTP_PARAM.getKey());
				
		try {
			final URL url = new URL(propService.getProperty(SystemPropertyEnum.IMAGE_FTP_URL.getKey()));
			final URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(urlParam);
			writer.flush();
			String line;
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				final String[] params = line.split("=");
				if (params.length == 2) {
					if (params[0].trim().equals("ip")) {
						ip = params[1].trim();
					}
					if (params[0].trim().equals("id")) {
						userId = params[1].trim();
					}
					if (params[0].trim().equals("password")) {
						password = params[1].trim();
					}
				}
			}
		} catch (final Exception e) {
			throw new InvalidRequestException.Builder("[ERROR] ���������� �������� ���߽��ϴ�.\n"+e).responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
		} finally {
			try {
				writer.close();
				reader.close();
			} catch (final IOException e) {
				throw new InvalidRequestException.Builder("[ERROR] writer,reader ������ ���� ���߽��ϴ�.\n"+e).responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
			}
		}
		
		File file = null;
		FTP ftp = null;
		try {	//�̹��������͸� ������ �޴´�.
//			System.out.println("[�� SBM] downFilePath : "+downFilePath + nSerial_ext);
//			System.out.println("[�� SBM] remoteFilePath : "+remoteFilePath+ sFolder +nSerial + "/" + nSerial);
			//System.out.println("[�� SBM] ip : " + ip + " / id : " + userId + " / pw : " + password);
			
			ftp = new FTP(ip);
			ftp.login(userId, password);//ddims[dev]
			ftp.setTransferType( FTPConstants.PASV );
			//ftp.cd( remoteFilePath+nSerial+"/", true );
			
			if(nFileCnt.equals("0")){
//				System.out.println("[�� SBM] " + remoteFilePath+nSerial+"/" + nSerial+".jpg");
				
				file = new File(downFilePath + nSerial_ext);
				if(!file.exists())
				{
					ftp.get(downFilePath + nSerial_ext , remoteFilePath + sFolder + nSerial+"/" + nSerial_ext);
				}
			}
			else{
//				System.out.println("[�� SBM] " + remoteFilePath+nSerial+"/" + nSerial+"_"+ nFileCnt +".jpg");
				
				file = new File(downFilePath + nSerial+"_"+ nFileCnt +".jpg");
				if(!file.exists()){
					ftp.get(downFilePath + nSerial+"_"+ nFileCnt +".jpg" , remoteFilePath+ sFolder +nSerial+"/" + nSerial+"_"+ nFileCnt +".jpg");
				}
				nSerial_ext = nSerial+"_"+ nFileCnt +".jpg";
			}

		} catch (Exception e) {
			throw new InvalidRequestException.Builder("[ERROR] FTP("+userId+")�ٿ�ε带 �����߽��ϴ�4.\n"+e).responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
		}
		finally{
			try {
				if(ftp != null)	ftp.quit();
			} catch (Exception e) {
				throw new InvalidRequestException.Builder("[ERROR] FTP ������ ���� ���߽��ϴ�.\n"+e).responseContent(ResponseContentEnum.TEXT_JAVASCRIPT).build();
			}
		}
		
		final ModelAndView mv = new ModelAndView();
		mv.setViewName("getdocname.jsp");
		mv.addObject("nSerial", nSerial_ext);
		mv.addObject("filePath", downFilePath + nSerial_ext);
		return mv;
	}
}
