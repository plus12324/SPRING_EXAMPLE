package com.educar.controller.web.product;

import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;

import jeus.util.StringUtil;

import kr.co.conch.validator.annotation.Validate;
import kr.co.conch.validator.annotation.notnull.NotNull;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.CheckHTelNum;
import com.educar.dto.web.products.ConsultationRequestDTO;
import com.educar.dto.web.products.CallOutBoundTMDTO;
import com.educar.enumeration.BasicCodeHashKeyEnum;
import com.educar.enumeration.InsuranceProductEnum;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.service.web.InsuranceProductsService;

/**
 * <pre>
 * �����ǰ - �繰����
 * <pre>
 * @author �Ž¿�
 *
 */
@Controller
@RequestMapping("/propertyInsuranceController")
public class PropertyInsuranceController {

	/** ���� ��ǰ �Ⱓ�� ȣ�� ���� */
	@Autowired
	private InsuranceProductsService insuranceProductsService;
	/** session ���� */
	@Autowired
	private SessionService sessionService;
	/** �޼��� ���� **/
	@Autowired
	private MessageSourceService message;
	/** �ΰ� **/
	private final Logger logger = Logger.getLogger(getClass());
	
	/**
	 * <pre>
	 * ȭ�纸��(�繰) �ֹι�ȣ ���� - ����û(����������)
	 * <pre>
	 * @param <ConsultationRequestDTO>
	 * @return
	 */
	@RequestMapping(value = "propertyCounselRequestWEBWithoutSSN")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.products.CallOutBoundTMDTO", "sCellPhone1", "sCellPhone2", "sCellPhone3" }, register = CheckHTelNum.class)
	public GenericRestResponse<Void> propertyCounselRequestWEBWithoutSSN(final HttpServletRequest servletRequest, @NotNull @Validate @RequestBody final GenericRestRequest<CallOutBoundTMDTO> request) {
		final CallOutBoundTMDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		//����� �˾ƺ��� Ү ����û �˾����� ���� �� ���
		if(StringUtil.isNullOrEmpty(dto.getsTel1()) && StringUtils.isNotEmpty(dto.getsCellPhone1())){
			dto.setsTel1(dto.getsCellPhone1());
			dto.setsTel2(dto.getsCellPhone2());
			dto.setsTel3(dto.getsCellPhone3());
		}
				
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		final String sUserID = sessionService.getUserID(servletRequest.getSession());
		final InsuranceProductEnum insuranceProductEnum = InsuranceProductEnum.PROPERTY;
		//������û �ڵ尪 ����(sInsType 1 : �����ں��� 2 : ���ຸ�� 3 : ġ�ƺ��� 6 : ȭ�纸�� 7 : �������� 8 : ���ݺ���)
		dto.setsInsType(insuranceProductEnum.getsInsType());
		// ����û
		insuranceProductsService.consultationLong(dto, sUserID, BasicCodeHashKeyEnum.PROPERTY_INSURANCE, insuranceProductEnum, sessionService.getsAffiliatedConcernKey(servletRequest.getSession()),
				servletRequest.getRemoteAddr());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * <pre>
	 * �繰���� �ֹι�ȣ ���� - ����û(�������׿�)
	 * <pre>
	 * @param <ConsultationRequestDTO>
	 * @return
	 */
	@RequestMapping(value = "propertyCounselRequestWithoutSSN")
	@ResponseBody
	@Validate(merge = { "com.educar.dto.web.products.CallOutBoundTMDTO", "sTel1", "sTel2", "sTel3" }, register = CheckHTelNum.class)
	public GenericRestResponse<Void> propertyCounselRequestWithoutSSN(final HttpServletRequest servletRequest, @NotNull @Validate @RequestBody final GenericRestRequest<CallOutBoundTMDTO> request) {
		final CallOutBoundTMDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());

		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		// �繰����
		final InsuranceProductEnum insuranceProductEnum = InsuranceProductEnum.PROPERTY;
		final String sUserID = sessionService.getUserID(servletRequest.getSession());
		
		dto.setsCustNo("0000000000000");
		
		// ����û
		insuranceProductsService.consultationLong(dto, sUserID, BasicCodeHashKeyEnum.PROPERTY_INSURANCE2, insuranceProductEnum, sessionService.getsAffiliatedConcernKey(servletRequest.getSession()),
				servletRequest.getRemoteAddr());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
	/**
	 * <pre>
	 * ��⺸�� ����̺�Ʈ(�ֹι�ȣ, nTaskID ����) 
	 * <pre>
	 * @param <ConsultationRequestDTO>
	 * @return
	 */
	@RequestMapping(value = "propertyCounselRequestEventWithoutSSN")
	@ResponseBody
	public GenericRestResponse<Void> propertyCounselRequestEventWithoutSSN(final HttpServletRequest servletRequest, @NotNull @Validate @RequestBody final GenericRestRequest<CallOutBoundTMDTO> request) {
		final CallOutBoundTMDTO dto = request.getRequestData().get(BigInteger.ZERO.intValue());
 
		final GenericRestResponse<Void> response = new GenericRestResponse<Void>();
		
		final String sUserID = sessionService.getUserID(servletRequest.getSession());
		
		// ����û
		insuranceProductsService.consultationEventTMRequestWithoutSSN(dto, sUserID, sessionService.getsAffiliatedConcernKey(servletRequest.getSession()), servletRequest.getRemoteAddr());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	
}
