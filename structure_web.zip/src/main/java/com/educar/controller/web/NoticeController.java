/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web;

import java.math.BigInteger;
import java.util.List;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.dto.web.NoticeDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.UserAccessEnvironmentEnum;
import com.educar.service.web.NoticeService;

/**
 * <pre>
 * �������� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@Controller
@RequestMapping("/notice")
public class NoticeController {

	/** �������� ���� */  
	@Autowired
	private NoticeService noticeService;
	/** �޼��� */
	@Autowired
	private MessageSourceService message;

	/**
	 * <pre>
	 * �������� ��� ��ȸ
	 * <pre>
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "selectNoiceList")
	@ResponseBody
	public GenericRestResponse<NoticeDTO> selectNoiceList(@NotNull @RequestBody final GenericRestRequest<NoticeDTO> request) {
		final NoticeDTO noticeDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		noticeDTO.setPcMobileViewYN(UserAccessEnvironmentEnum.PC.getDelim());
		final List<NoticeDTO> noticeList = noticeService.selectNoticeList(noticeDTO);

		final GenericRestResponse<NoticeDTO> response = new GenericRestResponse<NoticeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(noticeList);

		return response;
	}

	/**
	 * �������� ���� ���� ��ȸ
	 * @param request NoticeDTO ��ȸ��ȣ�� ����
	 * @return NoticeDTO ���� ����
	 */
	@RequestMapping(value = "selectNoiceInfo")
	@ResponseBody
	public GenericRestResponse<NoticeDTO> selectNoiceInfo(@RequestBody final GenericRestRequest<NoticeDTO> request) {
		final NoticeDTO dto = noticeService.selectNoticeInfo(request.getRequestData().get(BigInteger.ZERO.intValue()).getnSeq());

		final GenericRestResponse<NoticeDTO> response = new GenericRestResponse<NoticeDTO>();
		if (dto == null) {
			response.setStatus(ResponseStatusEnum.DEFAULT_ERROR.getCode());
			response.setMessage(message.getMessage(ExceptionMessage.SelectEmpty, "��������"));
		} else {
			response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
			response.addResponseData(dto);
		}
		return response;
	}

	/**
	 * <pre>
	 * �������� ������ο� �������� ��� ��ȸ
	 * �ֱ� ����� ������ 5��
	 * <pre>
	 * @return
	 */
	@RequestMapping(value = "selectSubMainNoticeList")
	@ResponseBody
	public GenericRestResponse<NoticeDTO> selectSubMainNoticeList() {
		final List<NoticeDTO> list = noticeService.selectSubMainNoticeList(UserAccessEnvironmentEnum.PC);
		final GenericRestResponse<NoticeDTO> response = new GenericRestResponse<NoticeDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(list);
		return response;
	}
}
