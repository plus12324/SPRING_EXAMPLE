/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.controller.web.claim;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.co.conch.validator.annotation.notnull.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.educar.common.dto.StandardRoadAddrDTO;
import com.educar.common.dto.web.GenericRestRequest;
import com.educar.common.dto.web.GenericRestResponse;
import com.educar.common.service.ExceptionMessage;
import com.educar.common.service.MessageSourceService;
import com.educar.common.service.SessionService;
import com.educar.common.util.SsnAsteriskConvert;
import com.educar.common.vo.LoginInfoVO;
import com.educar.dto.web.AccidentClaimStatusDTO;
import com.educar.dto.web.claim.AccidentHealthClaimWrapperDTO;
import com.educar.dto.web.claim.DmgProgDetailResultDTO;
import com.educar.dto.web.claim.GetContData2ndEditionResultDTO;
import com.educar.dto.web.claim.InsertAcdRcpDataDTO;
import com.educar.dto.web.claim.InsertAcdRcpDataOfDs_AccInfoDTO;
import com.educar.dto.web.claim.InsertAcdRcpDataOfDs_AcdDetailDTO;
import com.educar.dto.web.claim.InsertAcdRcpDataOfDs_AcdListDTO;
import com.educar.dto.web.claim.InsertAcdRcpDataResultDTO;
import com.educar.dto.web.claim.GetContDataInputDTO;
import com.educar.dto.web.login.MemberCheckDTO;
import com.educar.enumeration.ResponseStatusEnum;
import com.educar.enumeration.SessionNameEnum;
import com.educar.exception.InvalidRequestException;
import com.educar.service.backbone.AccidentClaimBackBoneService;
import com.educar.service.backbone.AdresssSearchBackBoneService;
import com.educar.service.backbone.ClaimBackBoneService;
import com.educar.service.web.CertificationService;
import com.educar.service.web.ClaimService;
import com.educar.service.web.MyPageService;
import com.educar.dto.web.claim.SelectAcctListInfoResultDTO;
import com.educar.dto.web.claim.SelectNationalResultDTO;
/**
 * <pre>
 * ���󼭺� - ����/�ǰ����� ��Ʈ�ѷ�
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@RequestMapping("accidentHealthClaim")
@Controller
public class AccidentHealthClaimController {

	/** �޽��� ���� **/
	@Autowired
	private MessageSourceService messageService;
	/** ȸ������ ��ȸ/���� ���� **/
	@Autowired
	private MyPageService myPageService;
	/** ���󼭺� ���� **/
	@Autowired
	private ClaimBackBoneService claimBackBoneService;
	/** ���� ����/�ǰ����� ������Ȳ ��ȸ �Ⱓ�� ���� ���� **/
	
	@Autowired
	private AccidentClaimBackBoneService accidentClaimService;
	/** ����/�ǰ����� ���� ���� Ȯ��   copy ���� filed **/
	private static final String[] IGNORED_INSUREDINFO = { "s04AgmYn", "s04CallReject", "s04DMReject", "s04FaxReject", "s04EmailReject"};
	/** ���� ���� ������� ����(��������)**/
	@Autowired
	private ClaimService claimService;
	/** session service */
	@Autowired
	private SessionService sessionService;
	/** ���� ���� */
	@Autowired
	private CertificationService certificationService;
	/** �ּ� �˻� �Ⱓ�� ȣ�� ���� */
	@Autowired
	private AdresssSearchBackBoneService adresssSearchBackBoneService;
	/**
	 * ����/�ǰ����� ����ó����Ȳ �� ��ȸ
	 * @param session
	 * @return
	 * @author �Ž¿�
	 */	
	@RequestMapping("selectAccidentHealthClaimDetail")
	@ResponseBody
	public GenericRestResponse<AccidentHealthClaimWrapperDTO> selectAccidentHealthClaimDetail(@NotNull @RequestBody final GenericRestRequest<DmgProgDetailResultDTO> request) {
		final DmgProgDetailResultDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		// ���ذǰ��������󼼳��� ��ȸ
		final DmgProgDetailResultDTO dmgProgDetailResultDTO = claimBackBoneService.selectsDmgProgDetail(inputDTO.getsAcdNum(), inputDTO.getnDmgSeq());
		// ��ȸ ������ ������ exception ó��
		if (dmgProgDetailResultDTO == null) {
			throw new InvalidRequestException.Builder(messageService.getMessage(ExceptionMessage.PaymentSessionEmpty)).build();
		}

		// ���ذǰ����� ���� �� ������� ��ȸ
		final AccidentClaimStatusDTO accidentClaimStatusDTO = accidentClaimService.accidentClaimStatus(inputDTO.getsAcdNum(), inputDTO.getnDmgSeq());

		// ���¹�ȣ * ó��
		dmgProgDetailResultDTO.setsSupAccountNo(SsnAsteriskConvert.getCardNoAndAccountNoAsterisk(dmgProgDetailResultDTO.getsSupAccountNo()));

		final AccidentHealthClaimWrapperDTO wrapperDTO = new AccidentHealthClaimWrapperDTO();
		wrapperDTO.setDmgProgDetailResult(dmgProgDetailResultDTO);
		wrapperDTO.setAccidentClaimStatus(accidentClaimStatusDTO);

		final GenericRestResponse<AccidentHealthClaimWrapperDTO> response = new GenericRestResponse<AccidentHealthClaimWrapperDTO>();
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(wrapperDTO);
		return response;
	}
	
	/**
	 * ����/�ǰ����� ���� ���� Ȯ��  
	 * @param session
	 * @return
	 * @author �Ž¿�
	 */	
	@RequestMapping("getInsuredInfo")
	@ResponseBody
	public GenericRestResponse<MemberCheckDTO> getInsuredInfo(final HttpSession session) {
		final GenericRestResponse<MemberCheckDTO> response = new GenericRestResponse<MemberCheckDTO>();
		final LoginInfoVO sessionVO = sessionService.getAttribute(session, SessionNameEnum.LOGIN_INFO.name(), LoginInfoVO.class);
		// ���ǿ� ������ �ִ����� ���ͼ��Ϳ��� ó��
		final MemberCheckDTO tempVo = myPageService.selectMyDetail(sessionVO.getID());
		
		if (tempVo == null) {
			// �Ⱓ�� ������ ������ ����ġ
			throw new InvalidRequestException(messageService.getMessage(ExceptionMessage.WebBackBoneDataInconsistency.getMessage()), ResponseStatusEnum.DEFAULT_ERROR);
		}
		tempVo.setsName(SsnAsteriskConvert.getNameAsterisk(sessionVO.getsName()));
		tempVo.setsSex(sessionVO.getsSex());
		tempVo.setsCustNo(SsnAsteriskConvert.getSsnAsterisk(sessionVO.getSSN(), Boolean.TRUE));
		
		tempVo.setsCellPhone3(SsnAsteriskConvert.getStringAsterisk(tempVo.getsCellPhone3()));
		tempVo.setsHomeTel3(SsnAsteriskConvert.getStringAsterisk(tempVo.getsHomeTel3()));
		tempVo.setsHomeAdrsAdd(SsnAsteriskConvert.getAdrsAsterisk(tempVo.getsHomeAdrsAdd()) );
		tempVo.setsEmail(SsnAsteriskConvert.getEmailAsterisk(tempVo.getsEmail()) );
		
		final MemberCheckDTO vo = new MemberCheckDTO();
		
		BeanUtils.copyProperties(tempVo, vo, IGNORED_INSUREDINFO);
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(vo);
		return response;
	}
	

	
	/**
	 * ���غ��� ��� ��ȸ  
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("getContData2ndEdition")
	@ResponseBody
	public GenericRestResponse<GetContData2ndEditionResultDTO> getContData2ndEdition(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<GetContDataInputDTO> request) {

		final LoginInfoVO loginInfoVO = (LoginInfoVO) session.getAttribute(SessionNameEnum.LOGIN_INFO.toString());

		final GetContDataInputDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue()); 
		
		inputDTO.setSearchValue(loginInfoVO.getSSN());
		
		final GenericRestResponse<GetContData2ndEditionResultDTO> response = new GenericRestResponse<GetContData2ndEditionResultDTO>();
		final List<GetContData2ndEditionResultDTO> result = claimBackBoneService.getContData2ndEditionDate(inputDTO );
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);
		return response;
	}
	
	
/*
	@RequestMapping("getContData2ndEdition")
	@ResponseBody
	public GenericRestResponse<GetContData2ndEditionResultDTO> getContData2ndEdition(final HttpSession session, @NotNull @RequestBody final GenericRestRequest<GetContData2ndEditionInputDTO> request) {

		final LoginInfoVO loginInfoVO = (LoginInfoVO) session.getAttribute(SessionNameEnum.LOGIN_INFO.toString());

		final GetContData2ndEditionInputDTO inputDTO = request.getRequestData().get(BigInteger.ZERO.intValue()); 
		
		inputDTO.setSearchValue(loginInfoVO.getSSN());
		
		final GenericRestResponse<GetContData2ndEditionResultDTO> response = new GenericRestResponse<GetContData2ndEditionResultDTO>();
		final List<GetContData2ndEditionResultDTO> result = claimBackBoneService.getContData2ndEditionDate(inputDTO );
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);
		return response;
	}

	


	 */
	
	/**
	 * ������ó�� ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("selectAcctListInfo")
	@ResponseBody
	public GenericRestResponse<SelectAcctListInfoResultDTO> selectAcctListInfo(final HttpSession session) {
		
		final LoginInfoVO loginInfoVO = (LoginInfoVO) session.getAttribute(SessionNameEnum.LOGIN_INFO.toString());
		final GenericRestResponse<SelectAcctListInfoResultDTO> response = new GenericRestResponse<SelectAcctListInfoResultDTO>();
		final List<SelectAcctListInfoResultDTO> result = claimBackBoneService.selectAcctListInfo(loginInfoVO.getSSN()  );
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);
		return response;
	}
	
	/**
	 * �ؿ� ������ ��ȸ
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("selectNationalList")
	@ResponseBody
	public GenericRestResponse<SelectNationalResultDTO> selectNationalList(@NotNull @RequestBody final GenericRestRequest<String> request) {
				
		final GenericRestResponse<SelectNationalResultDTO> response = new GenericRestResponse<SelectNationalResultDTO>();
		final List<SelectNationalResultDTO> result = claimBackBoneService.selectNationalList(request.getRequestData().get(BigInteger.ZERO.intValue()) );
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.setData(result);
		return response;
	}
	
	/**
	 * ���غ��� ������� ��������
	 * @param request
	 * @return
	 * @author �Ž¿�
	 * @throws Exception 
	 */
	@RequestMapping("saveAcdRcpData")
	@ResponseBody
	public GenericRestResponse<InsertAcdRcpDataDTO> saveAcdRcpData(final HttpSession session, @RequestBody final GenericRestRequest<InsertAcdRcpDataDTO> request ) throws Exception {
		
		final InsertAcdRcpDataDTO insertAcdRcpDataDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		final LoginInfoVO sessionVO = sessionService.getAttribute(session, SessionNameEnum.LOGIN_INFO.name(), LoginInfoVO.class);
		
		//ǥ���ּ� ��ȯ
		
		final StandardRoadAddrDTO standAddrDto = new StandardRoadAddrDTO();
		StandardRoadAddrDTO resultStandAddr = null;

		if(insertAcdRcpDataDTO != null && insertAcdRcpDataDTO.getDs_AcdList() != null) {
			for(InsertAcdRcpDataOfDs_AcdListDTO dto : insertAcdRcpDataDTO.getDs_AcdList()) {
				if(dto.getsStdAddrFlag().equals("Y")){
					standAddrDto.setsAddrMgtNo(dto.getsAddrMgtNo());
					standAddrDto.setVarAllAddress(dto.getsDoroAddr()+ dto.getsAcdDtlAddr());
					standAddrDto.setLoginId(sessionService.getUserID(session));
					standAddrDto.setTableNm("CUSAA02");
					standAddrDto.setVarPost(dto.getsAcdZipCode());
					
					resultStandAddr = adresssSearchBackBoneService.selectStandardAddr(standAddrDto);
					dto.setsAcdVilAddr(resultStandAddr.getAnlysStndRdNmHighAddrA());
					dto.setsAcdDtlAddr(resultStandAddr.getAnlysStndRdNmUndrAddrA());
				}
			}
		}
		
		if(insertAcdRcpDataDTO != null && insertAcdRcpDataDTO.getDs_AccInfo() != null) {
			for(InsertAcdRcpDataOfDs_AccInfoDTO dto : insertAcdRcpDataDTO.getDs_AccInfo()) {
				dto.setsSupAccountNo(certificationService.touchenKeyDec(dto.getsHid_key_data() , dto.getsSupAccountNo() , session));
				dto.setsSupDepName(sessionVO.getsName());
			}
		}
		
		session.setAttribute(SessionNameEnum.ACCIDENT_RCP_DATA.toString(), insertAcdRcpDataDTO);
		
		final GenericRestResponse<InsertAcdRcpDataDTO> response = new GenericRestResponse<InsertAcdRcpDataDTO>();
		
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		return response;
	}
	/**
	 * ���غ��� �������
	 * @param session
	 * @param request
	 * @return
	 * @author �Ž¿�
	 */
	@RequestMapping("insertAcdRcpData")
	@ResponseBody
	public GenericRestResponse<InsertAcdRcpDataResultDTO> insertAcdRcpData(final HttpSession session, @RequestBody final GenericRestRequest<InsertAcdRcpDataDTO> request, final HttpServletRequest servletRequest ) {
	
		final LoginInfoVO loginInfoVO = (LoginInfoVO) session.getAttribute(SessionNameEnum.LOGIN_INFO.toString());
		final String sUserID = sessionService.getUserID(servletRequest.getSession());
		
		final InsertAcdRcpDataDTO insertAcdRcpDataDTO = (InsertAcdRcpDataDTO) session.getAttribute(SessionNameEnum.ACCIDENT_RCP_DATA.toString());
		if(insertAcdRcpDataDTO != null && insertAcdRcpDataDTO.getDs_AcdList() != null) {
			for(InsertAcdRcpDataOfDs_AcdListDTO dto : insertAcdRcpDataDTO.getDs_AcdList()) {
				dto.setsInsrdID(loginInfoVO.getSSN() );
				dto.setsPolHolderName(loginInfoVO.getsName());
				dto.setsPolHolderID(loginInfoVO.getSSN());
				dto.setsInsrdName(loginInfoVO.getsName());
			}
		}
		
		if(insertAcdRcpDataDTO != null && insertAcdRcpDataDTO.getDs_AcdDetail() != null) {
			for(InsertAcdRcpDataOfDs_AcdDetailDTO dto : insertAcdRcpDataDTO.getDs_AcdDetail()) {
				dto.setsDmgName(loginInfoVO.getsName());
			}
		}
		
		final InsertAcdRcpDataDTO fileAcdRcpDataDTO = request.getRequestData().get(BigInteger.ZERO.intValue());
		
		insertAcdRcpDataDTO.setFileID( fileAcdRcpDataDTO.getFileID() );
		
		final GenericRestResponse<InsertAcdRcpDataResultDTO> response = new GenericRestResponse<InsertAcdRcpDataResultDTO>();
		final InsertAcdRcpDataResultDTO result = claimService.insertAcdRcpData(insertAcdRcpDataDTO, loginInfoVO, sUserID );
		result.setsName(loginInfoVO.getsName() );
		//�����ʱ�ȭ
		session.removeAttribute(SessionNameEnum.ACCIDENT_RCP_DATA.name());
		response.setStatus(ResponseStatusEnum.SUCCESS.getCode());
		response.addResponseData(result);
		return response;
	}
	
	
}
