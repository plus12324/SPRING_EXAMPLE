package com.educar.dto.mobile;

/**
 * ������ ����üũ input DTO
 * 
 * @author �Ž¿�
 *
 */
public class OnedayCouponCheckInputDTO {

	private String sInsrdName;
	
	private String sHpNo;
	
	private String sCellPhone1;
	
	private String sCellPhone2;
	
	private String sCellPhone3;
	
	private String sCouponNumber;
	
	private String sAffiliatedConcern;

	private String sCouponCode;
	
	private String sEventDiv;
	
	public String getsEventDiv() {
		return sEventDiv;
	}

	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	public String getsCouponCode() {
		return sCouponCode;
	}

	public void setsCouponCode(String sCouponCode) {
		this.sCouponCode = sCouponCode;
	}

	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	public void setsAffiliatedConcern(String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	public String getsHpNo() {
		return sHpNo;
	}

	public void setsHpNo(String sHpNo) {
		this.sHpNo = sHpNo;
	}

	public String getsInsrdName() {
		return sInsrdName;
	}

	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	public String getsCellPhone1() {
		return sCellPhone1;
	}

	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	public String getsCellPhone2() {
		return sCellPhone2;
	}

	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	public String getsCellPhone3() {
		return sCellPhone3;
	}

	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	public String getsCouponNumber() {
		return sCouponNumber;
	}

	public void setsCouponNumber(String sCouponNumber) {
		this.sCouponNumber = sCouponNumber;
	}
	
	
	
}
