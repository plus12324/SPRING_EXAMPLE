package com.educar.dto.mobile;

/**
 * ����Ȯ�� OUTPUT DTO
 * @author �Ž¿�
 * 
 */
public class OnedayReceiptInfoOutputDTO {
	
	/* ����� 1: ������ */
	private String result;
	/* ����ȣ */
	private String sPolicyNo;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	
	

}
