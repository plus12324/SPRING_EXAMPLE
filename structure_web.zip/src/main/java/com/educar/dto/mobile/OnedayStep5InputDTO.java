package com.educar.dto.mobile;

/*
 * ������ STEP5 INPUT DTO
 * 
 */
public class OnedayStep5InputDTO {

	/** û���ȣ **/
	private String sApplyNo;
	/** �޴�����ȣ1  **/
	private String sCellPhone1;
	/** �޴�����ȣ2 **/
	private String sCellPhone2;
	/** �޴�����ȣ3 **/
	private String sCellPhone3;
	/** �̸���  **/
	private String sEmail;
	/** ���� ������ȣ **/
	private String sHomeZip;
	/** �ּ�1  **/
	private String sHomeAdrs1;
	/** �ּ�2 **/
	private String sHomeAdrs2;
	/** �ּ�3 **/
	private String sHomeAdrs3;
	/** �������ּ� **/
	private String sHomeAdd;
	
	public String getsApplyNo() {
		return sApplyNo;
	}
	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public String getsHomeZip() {
		return sHomeZip;
	}
	public void setsHomeZip(String sHomeZip) {
		this.sHomeZip = sHomeZip;
	}
	public String getsHomeAdrs1() {
		return sHomeAdrs1;
	}
	public void setsHomeAdrs1(String sHomeAdrs1) {
		this.sHomeAdrs1 = sHomeAdrs1;
	}
	public String getsHomeAdrs2() {
		return sHomeAdrs2;
	}
	public void setsHomeAdrs2(String sHomeAdrs2) {
		this.sHomeAdrs2 = sHomeAdrs2;
	}
	public String getsHomeAdrs3() {
		return sHomeAdrs3;
	}
	public void setsHomeAdrs3(String sHomeAdrs3) {
		this.sHomeAdrs3 = sHomeAdrs3;
	}
	public String getsHomeAdd() {
		return sHomeAdd;
	}
	public void setsHomeAdd(String sHomeAdd) {
		this.sHomeAdd = sHomeAdd;
	}
	
	
	
}
