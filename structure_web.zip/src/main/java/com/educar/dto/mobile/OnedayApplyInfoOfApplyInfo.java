package com.educar.dto.mobile;

/**
 * ������ ������ ���� û�೻��(û������) DTO
 * @author �Ž¿�
 *
 */
public class OnedayApplyInfoOfApplyInfo {
	/** **/
	private String sMsgCode;
	/** **/
	private String sMsg;
	/** **/
	private String sInsTypeNm;
	/** **/
	private String sInsType;
	/** ���� �����Ⱓ **/
	private String sPeriod;
	/** ������ȣ **/
	private String sPlateNo;
	/** ����� �̸� **/
	private String sRelPerson;
	/** �̸��� **/
	private String sEmail;
	/** ������ȣ **/
	private String sHomeZip;
	/** �� �ּ�1**/
	private String sHomeAdrs1;
	/** �� �ּ�2 **/
	private String sHomeAdrs2;
	/** �� �ּ�3 **/
	private String sHomeAdrs3;
	/** �� �� �ּ� **/
	private String sHomeAdd;
	/** ����� **/
	private String nRectPrem;
	/**  **/
	private String nCoverCnt;
	/** **/
	private String nTKCnt;
	
	public String getsMsgCode() {
		return sMsgCode;
	}
	public void setsMsgCode(String sMsgCode) {
		this.sMsgCode = sMsgCode;
	}
	public String getsMsg() {
		return sMsg;
	}
	public void setsMsg(String sMsg) {
		this.sMsg = sMsg;
	}
	public String getsInsTypeNm() {
		return sInsTypeNm;
	}
	public void setsInsTypeNm(String sInsTypeNm) {
		this.sInsTypeNm = sInsTypeNm;
	}
	public String getsInsType() {
		return sInsType;
	}
	public void setsInsType(String sInsType) {
		this.sInsType = sInsType;
	}
	public String getsPeriod() {
		return sPeriod;
	}
	public void setsPeriod(String sPeriod) {
		this.sPeriod = sPeriod;
	}
	public String getsPlateNo() {
		return sPlateNo;
	}
	public void setsPlateNo(String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}
	public String getsRelPerson() {
		return sRelPerson;
	}
	public void setsRelPerson(String sRelPerson) {
		this.sRelPerson = sRelPerson;
	}
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public String getsHomeZip() {
		return sHomeZip;
	}
	public void setsHomeZip(String sHomeZip) {
		this.sHomeZip = sHomeZip;
	}
	public String getsHomeAdrs1() {
		return sHomeAdrs1;
	}
	public void setsHomeAdrs1(String sHomeAdrs1) {
		this.sHomeAdrs1 = sHomeAdrs1;
	}
	public String getsHomeAdrs2() {
		return sHomeAdrs2;
	}
	public void setsHomeAdrs2(String sHomeAdrs2) {
		this.sHomeAdrs2 = sHomeAdrs2;
	}
	public String getsHomeAdrs3() {
		return sHomeAdrs3;
	}
	public void setsHomeAdrs3(String sHomeAdrs3) {
		this.sHomeAdrs3 = sHomeAdrs3;
	}
	public String getsHomeAdd() {
		return sHomeAdd;
	}
	public void setsHomeAdd(String sHomeAdd) {
		this.sHomeAdd = sHomeAdd;
	}
	public String getnRectPrem() {
		return nRectPrem;
	}
	public void setnRectPrem(String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}
	public String getnCoverCnt() {
		return nCoverCnt;
	}
	public void setnCoverCnt(String nCoverCnt) {
		this.nCoverCnt = nCoverCnt;
	}
	public String getnTKCnt() {
		return nTKCnt;
	}
	public void setnTKCnt(String nTKCnt) {
		this.nTKCnt = nTKCnt;
	}
	
}
