package com.educar.dto.mobile;

/**
 * ������ ������ ���� ���� DTO
 * @author �Ž¿� 
 */
public class OnedayPhoneAdmitDTO {
	
	/**	û���ȣ(����)	**/
	private String sApplyType;
	/**	û���ȣ(���)	**/
	private String sApplyYM;
	/**	û���ȣ(Ser)	**/
	private String sApplySer;
	/**	�޴�����ȣ1	**/
	private String sCellPhoneNo1;
	/**	�޴�����ȣ2	**/
	private String sCellPhoneNo2;
	/**	�޴�����ȣ3	**/
	private String sCellPhoneNo3;
	/**	�޴�����ȣ	**/
	private String sCellPhoneNo;
	/**	��Ż� "SKT", "KT", "LGT" **/
	private String sCustCom;
	/**	����� ����	**/
	private String sCellPhoneOwner;
	/**	������ڵ� �ֹι�ȣ	**/
	private String sCellPhoneOwnerID;
	/**	���αݾ�	**/
	private String nReqAmt;
	/**	����� ���� ex)����Ͼ�	**/
	private String sReqAgntName;
	/**	å�Ӱ����� ��¥(YYYYMMDD)	**/
	private String sBeginDate;
	/** ������� ������ �޴� �Ķ���� 	**/
	private String sPhoneid;
	/**	������� ������ �Ⱓ�迡�� ���� �Ķ����	**/
	private String sCellDealNo;
	
	private String sEmail;
	
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public String getsApplyType() {
		return sApplyType;
	}
	public void setsApplyType(String sApplyType) {
		this.sApplyType = sApplyType;
	}
	public String getsApplyYM() {
		return sApplyYM;
	}
	public void setsApplyYM(String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}
	public String getsApplySer() {
		return sApplySer;
	}
	public void setsApplySer(String sApplySer) {
		this.sApplySer = sApplySer;
	}
	public String getsCellPhoneNo1() {
		return sCellPhoneNo1;
	}
	public void setsCellPhoneNo1(String sCellPhoneNo1) {
		this.sCellPhoneNo1 = sCellPhoneNo1;
	}
	public String getsCellPhoneNo2() {
		return sCellPhoneNo2;
	}
	public void setsCellPhoneNo2(String sCellPhoneNo2) {
		this.sCellPhoneNo2 = sCellPhoneNo2;
	}
	public String getsCellPhoneNo3() {
		return sCellPhoneNo3;
	}
	public void setsCellPhoneNo3(String sCellPhoneNo3) {
		this.sCellPhoneNo3 = sCellPhoneNo3;
	}
	public String getsCellPhoneNo() {
		return sCellPhoneNo;
	}
	public void setsCellPhoneNo(String sCellPhoneNo) {
		this.sCellPhoneNo = sCellPhoneNo;
	}
	public String getsCustCom() {
		return sCustCom;
	}
	public void setsCustCom(String sCustCom) {
		this.sCustCom = sCustCom;
	}
	public String getsCellPhoneOwner() {
		return sCellPhoneOwner;
	}
	public void setsCellPhoneOwner(String sCellPhoneOwner) {
		this.sCellPhoneOwner = sCellPhoneOwner;
	}
	public String getsCellPhoneOwnerID() {
		return sCellPhoneOwnerID;
	}
	public void setsCellPhoneOwnerID(String sCellPhoneOwnerID) {
		this.sCellPhoneOwnerID = sCellPhoneOwnerID;
	}
	public String getnReqAmt() {
		return nReqAmt;
	}
	public void setnReqAmt(String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}
	public String getsReqAgntName() {
		return sReqAgntName;
	}
	public void setsReqAgntName(String sReqAgntName) {
		this.sReqAgntName = sReqAgntName;
	}
	public String getsBeginDate() {
		return sBeginDate;
	}
	public void setsBeginDate(String sBeginDate) {
		this.sBeginDate = sBeginDate;
	}
	public String getsPhoneid() {
		return sPhoneid;
	}
	public void setsPhoneid(String sPhoneid) {
		this.sPhoneid = sPhoneid;
	}
	public String getsCellDealNo() {
		return sCellDealNo;
	}
	public void setsCellDealNo(String sCellDealNo) {
		this.sCellDealNo = sCellDealNo;
	}
}
