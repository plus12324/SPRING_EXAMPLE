package com.educar.dto.mobile;

/**
 * ������ ������뿩�� üũ output DTO
 * @author �Ž¿�
 */ 
public class OnedayCouponCheckOutputDTO {
	
	/** �������� **/
	private String sCouponStartDate;
	/** ��ȿ���� **/
	private String sCouponEndMm;
	/** �������� **/
	private String sCouponGiveDate;
	/** ������볯¥ **/
	private String sCouponUseDate;
	/** ���� �ֱ� ������볯¥ **/
	private String sCouponUseDateMax;
	/** ���԰�� **/
	private String sContactPath;
	
	public String getsCouponStartDate() {
		return sCouponStartDate;
	}
	public void setsCouponStartDate(String sCouponStartDate) {
		this.sCouponStartDate = sCouponStartDate;
	}
	public String getsCouponEndMm() {
		return sCouponEndMm;
	}
	public void setsCouponEndMm(String sCouponEndMm) {
		this.sCouponEndMm = sCouponEndMm;
	}
	public String getsCouponGiveDate() {
		return sCouponGiveDate;
	}
	public void setsCouponGiveDate(String sCouponGiveDate) {
		this.sCouponGiveDate = sCouponGiveDate;
	}
	public String getsCouponUseDate() {
		return sCouponUseDate;
	}
	public void setsCouponUseDate(String sCouponUseDate) {
		this.sCouponUseDate = sCouponUseDate;
	}
	public String getsCouponUseDateMax() {
		return sCouponUseDateMax;
	}
	public void setsCouponUseDateMax(String sCouponUseDateMax) {
		this.sCouponUseDateMax = sCouponUseDateMax;
	}
	public String getsContactPath() {
		return sContactPath;
	}
	public void setsContactPath(String sContactPath) {
		this.sContactPath = sContactPath;
	}
	
	
	
}
