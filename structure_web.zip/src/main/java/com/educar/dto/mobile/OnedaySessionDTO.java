package com.educar.dto.mobile;

/**
 * ������ ��������� DTO
 * @author �Ž¿�
 * 
 */
public class OnedaySessionDTO {

	/** ���� **/
	private String sInsrdName;
	/** �ֹι�ȣ **/
	private String sInsrdID;
	/** �ֹι�ȣ1 **/
	private String sInsrdID1;
	/** �ֹι�ȣ2 **/
	private String sInsrdID2;
	/** �̸���  **/
	private String sEmail;
	/** ���� ������ȣ **/
	private String sHomeZip;
	/** �ּ�1  **/
	private String sHomeAdrs1;
	/** �ּ�2 **/
	private String sHomeAdrs2;
	/** �ּ�3 **/
	private String sHomeAdrs3;
	/** �������ּ� **/
	private String sHomeAdd;
	/** �����**/
	private String sUserID;
	
	public String getsInsrdName() {
		return sInsrdName;
	}
	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}
	public String getsInsrdID() {
		return sInsrdID;
	}
	public void setsInsrdID(String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}
	public String getsInsrdID1() {
		return sInsrdID1;
	}
	public void setsInsrdID1(String sInsrdID1) {
		this.sInsrdID1 = sInsrdID1;
	}
	public String getsInsrdID2() {
		return sInsrdID2;
	}
	public void setsInsrdID2(String sInsrdID2) {
		this.sInsrdID2 = sInsrdID2;
	}
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public String getsHomeZip() {
		return sHomeZip;
	}
	public void setsHomeZip(String sHomeZip) {
		this.sHomeZip = sHomeZip;
	}
	public String getsHomeAdrs1() {
		return sHomeAdrs1;
	}
	public void setsHomeAdrs1(String sHomeAdrs1) {
		this.sHomeAdrs1 = sHomeAdrs1;
	}
	public String getsHomeAdrs2() {
		return sHomeAdrs2;
	}
	public void setsHomeAdrs2(String sHomeAdrs2) {
		this.sHomeAdrs2 = sHomeAdrs2;
	}
	public String getsHomeAdrs3() {
		return sHomeAdrs3;
	}
	public void setsHomeAdrs3(String sHomeAdrs3) {
		this.sHomeAdrs3 = sHomeAdrs3;
	}
	public String getsHomeAdd() {
		return sHomeAdd;
	}
	public void setsHomeAdd(String sHomeAdd) {
		this.sHomeAdd = sHomeAdd;
	}
	public String getsUserID() {
		return sUserID;
	}
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
	
	
}
