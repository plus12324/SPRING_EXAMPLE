package com.educar.dto.mobile;

/**
 * <pre>
 * ������ �������� ��ȸ inputDTO
 * <pre>
 * @author �Ž¿�
 * 
 */
public class OnedayCustomerInputDTO {
	
	private String sInsrdID1;
	
	private String sInsrdID2;

	public String getsInsrdID1() {
		return sInsrdID1;
	}

	public void setsInsrdID1(String sInsrdID1) {
		this.sInsrdID1 = sInsrdID1;
	}

	public String getsInsrdID2() {
		return sInsrdID2;
	}

	public void setsInsrdID2(String sInsrdID2) {
		this.sInsrdID2 = sInsrdID2;
	}
	
}
