package com.educar.dto.mobile;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onedayCalculationCoverVtDTO")
public class OnedayCalculationCoverVtDTO {
 
private String sCover;
	
	private String sCoverTitle;
	
	private String sCoverOpt;
	
	private String sCoverOptAmt;
	
	private String sCoverOptDisplay;
	
	private String sCoverSelfAmt;
	
	private String nCoverPrem;
	
	public String getsCover() {
		return sCover;
	}
	public void setsCover(String sCover) {
		this.sCover = sCover;
	}
	public String getsCoverTitle() {
		return sCoverTitle;
	}
	public void setsCoverTitle(String sCoverTitle) {
		this.sCoverTitle = sCoverTitle;
	}
	public String getsCoverOpt() {
		return sCoverOpt;
	}
	public void setsCoverOpt(String sCoverOpt) {
		this.sCoverOpt = sCoverOpt;
	}
	public String getsCoverOptAmt() {
		return sCoverOptAmt;
	}
	public void setsCoverOptAmt(String sCoverOptAmt) {
		this.sCoverOptAmt = sCoverOptAmt;
	}
	public String getsCoverOptDisplay() {
		return sCoverOptDisplay;
	}
	public void setsCoverOptDisplay(String sCoverOptDisplay) {
		this.sCoverOptDisplay = sCoverOptDisplay;
	}
	public String getsCoverSelfAmt() {
		return sCoverSelfAmt;
	}
	public void setsCoverSelfAmt(String sCoverSelfAmt) {
		this.sCoverSelfAmt = sCoverSelfAmt;
	}
	public String getnCoverPrem() {
		return nCoverPrem;
	}
	public void setnCoverPrem(String nCoverPrem) {
		this.nCoverPrem = nCoverPrem;
	}
	
}
