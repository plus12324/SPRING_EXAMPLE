package com.educar.dto.mobile;

/*
 * ������ STEP2 INPUT DTO
 * 
 */
public class OnedayStep2InputDTO {
	
	/** ���� **/
	private String sInsrdName;
	/** **/
	private String sInsrdID;
	/** **/
	private String sCellPhone1;
	/** **/
	private String sCellPhone2;
	/** **/
	private String sCellPhone3;
	/** **/
	private String sCUSAA04AgmYn;
	/** **/
	private String sCUSAA48AgmYn;
	/** **/
	private String sCUSAA41AgmYn;
	/** �������� ���� ���� **/
	private String sCouponCheck;
	/** ������ȣ **/
	private String sCouponNumber;
	/** **/
	private String sContactPath;
	/** **/
	private String sAffiliatedConcern;
	/** **/
	private String sEventDiv;
	/** **/
	private String sCouponCode;

	public String getsCouponCode() {
		return sCouponCode;
	}
	public void setsCouponCode(String sCouponCode) {
		this.sCouponCode = sCouponCode;
	}
	public String getsEventDiv() {
		return sEventDiv;
	}
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}
	public void setsAffiliatedConcern(String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}
	public String getsInsrdName() {
		return sInsrdName;
	}
	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}
	public String getsInsrdID() {
		return sInsrdID;
	}
	public void setsInsrdID(String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	public String getsCUSAA04AgmYn() {
		return sCUSAA04AgmYn;
	}
	public void setsCUSAA04AgmYn(String sCUSAA04AgmYn) {
		this.sCUSAA04AgmYn = sCUSAA04AgmYn;
	}
	public String getsCUSAA48AgmYn() {
		return sCUSAA48AgmYn;
	}
	public void setsCUSAA48AgmYn(String sCUSAA48AgmYn) {
		this.sCUSAA48AgmYn = sCUSAA48AgmYn;
	}
	public String getsCUSAA41AgmYn() {
		return sCUSAA41AgmYn;
	}
	public void setsCUSAA41AgmYn(String sCUSAA41AgmYn) {
		this.sCUSAA41AgmYn = sCUSAA41AgmYn;
	}
	public String getsCouponCheck() {
		return sCouponCheck;
	}
	public void setsCouponCheck(String sCouponCheck) {
		this.sCouponCheck = sCouponCheck;
	}
	public String getsCouponNumber() {
		return sCouponNumber;
	}
	public void setsCouponNumber(String sCouponNumber) {
		this.sCouponNumber = sCouponNumber;
	}
	public String getsContactPath() {
		return sContactPath;
	}
	public void setsContactPath(String sContactPath) {
		this.sContactPath = sContactPath;
	}
	
	
	
}
