package com.educar.dto.mobile;

import java.util.List;

/**
 * ������ ������ ���� û�೻�� Ȯ�� OUTPUT DTO
 * @author �Ž¿�
 * 
 */
public class OnedayApplyInfoOutputDTO {
	/** ����Ư����� **/
	private List<OnedayApplyInfoOfTkVt> tkVt;
	/** û������ **/
	private OnedayApplyInfoOfApplyInfo applyInfo;
	/**	���Դ㺸����	**/
	private List<OnedayApplyInfoOfCoverVt> coverVt;

	public List<OnedayApplyInfoOfTkVt> getTkVt() {
		return tkVt;
	}

	public OnedayApplyInfoOfApplyInfo getApplyInfo() {
		return applyInfo;
	}

	public void setApplyInfo(OnedayApplyInfoOfApplyInfo applyInfo) {
		this.applyInfo = applyInfo;
	}

	public List<OnedayApplyInfoOfCoverVt> getCoverVt() {
		return coverVt;
	}

	public void setCoverVt(List<OnedayApplyInfoOfCoverVt> coverVt) {
		this.coverVt = coverVt;
	}

	public void setTkVt(List<OnedayApplyInfoOfTkVt> tkVt) {
		this.tkVt = tkVt;
	}

	
	
}
