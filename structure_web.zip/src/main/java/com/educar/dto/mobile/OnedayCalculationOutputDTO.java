package com.educar.dto.mobile;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ������ ���� ����� ���� ��� DTO
 * @author �Ž¿�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onedayCalculationOutputDTO")
public class OnedayCalculationOutputDTO {
	
	/** **/
	private OnedayCalculationOnedayInfoDTO onedayInfo;
	/** **/
	private List<OnedayCalculationCoverVtDTO> coverVt;
	
	public OnedayCalculationOnedayInfoDTO getOnedayInfo() {
		return onedayInfo;
	}
	public void setOnedayInfo(OnedayCalculationOnedayInfoDTO onedayInfo) {
		this.onedayInfo = onedayInfo;
	}
	public List<OnedayCalculationCoverVtDTO> getCoverVt() {
		return coverVt;
	}
	public void setCoverVt(List<OnedayCalculationCoverVtDTO> coverVt) {
		this.coverVt = coverVt;
	}
}
