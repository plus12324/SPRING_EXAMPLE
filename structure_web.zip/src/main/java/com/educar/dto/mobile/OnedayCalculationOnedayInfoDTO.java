package com.educar.dto.mobile;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onedayCalculationOnedayInfoDTO")
public class OnedayCalculationOnedayInfoDTO {
 
	/**�� �����**/
	private String sTotalPrem;
	/** **/
	private String sFmdt;
	/** **/
	private String sTodt;
	/** **/
	private String sApplyNo;
	
	private String sMsgCode;
	
	private String sMsg;
	
	public String getsMsgCode() {
		return sMsgCode;
	}
	public void setsMsgCode(String sMsgCode) {
		this.sMsgCode = sMsgCode;
	}
	public String getsMsg() {
		return sMsg;
	}
	public void setsMsg(String sMsg) {
		this.sMsg = sMsg;
	}
	public String getsTotalPrem() {
		return sTotalPrem;
	}
	public void setsTotalPrem(String sTotalPrem) {
		this.sTotalPrem = sTotalPrem;
	}
	public String getsFmdt() {
		return sFmdt;
	}
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	public String getsTodt() {
		return sTodt;
	}
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	public String getsApplyNo() {
		return sApplyNo;
	}
	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}
	
	
	
	
}
