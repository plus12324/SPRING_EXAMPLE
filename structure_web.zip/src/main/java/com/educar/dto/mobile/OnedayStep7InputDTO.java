package com.educar.dto.mobile;

/*
 * ������ STEP7 INPUT DTO
 * 
 */
public class OnedayStep7InputDTO {

	/** ���� **/
	private String sInsrdName;
	/** ����� **/
	private String sCellPhoneOwner;
	/** ����� �ֹι�ȣ**/
	private String sCellPhoneOwnerID;
	/** û���ȣ **/
	private String sApplyNo;
	/** �޴���1 **/
	private String sCellPhoneNo1; 
	/** �޴���2**/
	private String sCellPhoneNo2;
	/** �޴���3**/
	private String sCellPhoneNo3;
	/** ���� ���� ���� **/
	private String sCouponCheck;
	/** ������ȣ **/
	private String sCouponNumber; 
	/** ���αݾ� **/
	private String nReqAmt;
	/** ����� **/
	private String nCashPrem;
	/** å�Ӱ����� **/
	private String sBeginDate;
	/** ������� �ڵ������� �ĸ�����(������ ������𽺿��� �޾ƿ´�) **/
	private String sPhoneid;
	/** ������� �ڵ������� �ĸ�����(������ �Ⱓ�迡�� �޾ƿ´�) **/
	private String sCellDealNo;
	/** �������� p:�ڵ��� C:ī�� **/
	private String sPayType;
	/** ��������  1:�������Ա�(����), 2:ī��, 9:�޴��� **/
	private String sCollType;
	/** ��Ż� "SKT", "KT", "LGT" �ڵ尪 **/
	private String sCustCom;
	/** **/
	private String sReqAgntName;
	
	private String sEmail;
	
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public String getsReqAgntName() {
		return sReqAgntName;
	}
	public void setsReqAgntName(String sReqAgntName) {
		this.sReqAgntName = sReqAgntName;
	}
	public String getsCustCom() {
		return sCustCom;
	}
	public void setsCustCom(String sCustCom) {
		this.sCustCom = sCustCom;
	}
	public String getsCollType() {
		return sCollType;
	}
	public void setsCollType(String sCollType) {
		this.sCollType = sCollType;
	}
	public String getsPayType() {
		return sPayType;
	}
	public void setsPayType(String sPayType) {
		this.sPayType = sPayType;
	}
	public String getsApplyNo() {
		return sApplyNo;
	}
	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}
	public String getsInsrdName() {
		return sInsrdName;
	}
	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}
	public String getsCellPhoneOwner() {
		return sCellPhoneOwner;
	}
	public void setsCellPhoneOwner(String sCellPhoneOwner) {
		this.sCellPhoneOwner = sCellPhoneOwner;
	}
	public String getsCellPhoneOwnerID() {
		return sCellPhoneOwnerID;
	}
	public void setsCellPhoneOwnerID(String sCellPhoneOwnerID) {
		this.sCellPhoneOwnerID = sCellPhoneOwnerID;
	}
	public String getsCellPhoneNo1() {
		return sCellPhoneNo1;
	}
	public void setsCellPhoneNo1(String sCellPhoneNo1) {
		this.sCellPhoneNo1 = sCellPhoneNo1;
	}
	public String getsCellPhoneNo2() {
		return sCellPhoneNo2;
	}
	public void setsCellPhoneNo2(String sCellPhoneNo2) {
		this.sCellPhoneNo2 = sCellPhoneNo2;
	}
	public String getsCellPhoneNo3() {
		return sCellPhoneNo3;
	}
	public void setsCellPhoneNo3(String sCellPhoneNo3) {
		this.sCellPhoneNo3 = sCellPhoneNo3;
	}
	public String getsCouponCheck() {
		return sCouponCheck;
	}
	public void setsCouponCheck(String sCouponCheck) {
		this.sCouponCheck = sCouponCheck;
	}
	public String getsCouponNumber() {
		return sCouponNumber;
	}
	public void setsCouponNumber(String sCouponNumber) {
		this.sCouponNumber = sCouponNumber;
	}
	public String getnReqAmt() {
		return nReqAmt;
	}
	public void setnReqAmt(String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}
	public String getnCashPrem() {
		return nCashPrem;
	}
	public void setnCashPrem(String nCashPrem) {
		this.nCashPrem = nCashPrem;
	}
	public String getsBeginDate() {
		return sBeginDate;
	}
	public void setsBeginDate(String sBeginDate) {
		this.sBeginDate = sBeginDate;
	}
	public String getsPhoneid() {
		return sPhoneid;
	}
	public void setsPhoneid(String sPhoneid) {
		this.sPhoneid = sPhoneid;
	}
	public String getsCellDealNo() {
		return sCellDealNo;
	}
	public void setsCellDealNo(String sCellDealNo) {
		this.sCellDealNo = sCellDealNo;
	}
	
	
	
}
