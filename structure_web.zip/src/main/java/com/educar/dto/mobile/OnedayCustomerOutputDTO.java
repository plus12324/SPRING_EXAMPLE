package com.educar.dto.mobile;

/**
 * <pre>
 * ������ �������� DB��ȸ outputDTO
 * <pre>
 * @author �Ž¿�
 * 
 */
public class OnedayCustomerOutputDTO {
	
	private String sHomeZip1;
	
	private String sHomeZip2;
	
	private String sHomeAdrs1;
	
	private String sHomeAdrs2;
	
	private String sHomeAdrs3;
	
	private String sHomeAdrsAdd;
	
	private String sHomeAdrsAdd2;
	
	private String sEmail;

	public String getsHomeZip1() {
		return sHomeZip1;
	}

	public void setsHomeZip1(String sHomeZip1) {
		this.sHomeZip1 = sHomeZip1;
	}

	public String getsHomeZip2() {
		return sHomeZip2;
	}

	public void setsHomeZip2(String sHomeZip2) {
		this.sHomeZip2 = sHomeZip2;
	}

	public String getsHomeAdrs1() {
		return sHomeAdrs1;
	}

	public void setsHomeAdrs1(String sHomeAdrs1) {
		this.sHomeAdrs1 = sHomeAdrs1;
	}

	public String getsHomeAdrs2() {
		return sHomeAdrs2;
	}

	public void setsHomeAdrs2(String sHomeAdrs2) {
		this.sHomeAdrs2 = sHomeAdrs2;
	}

	public String getsHomeAdrs3() {
		return sHomeAdrs3;
	}

	public void setsHomeAdrs3(String sHomeAdrs3) {
		this.sHomeAdrs3 = sHomeAdrs3;
	}

	public String getsHomeAdrsAdd() {
		return sHomeAdrsAdd;
	}

	public void setsHomeAdrsAdd(String sHomeAdrsAdd) {
		this.sHomeAdrsAdd = sHomeAdrsAdd;
	}

	public String getsHomeAdrsAdd2() {
		return sHomeAdrsAdd2;
	}

	public void setsHomeAdrsAdd2(String sHomeAdrsAdd2) {
		this.sHomeAdrsAdd2 = sHomeAdrsAdd2;
	}

	public String getsEmail() {
		return sEmail;
	}

	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	
	
}
