/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.mobile;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ������ ������� inputDTO
 * @author �Ž¿�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onedayInsertPhotoDTO")
public class OnedayInsertPhotoDTO {
	
	/** û���ȣ **/
	private String sApplyNo;
	/** IP **/
	private String sIP;
	
	/** ����ID ����Ʈ **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "fileIDList")
	private List<String> fileID;
	
	public String getsIP() {
		return sIP;
	}

	public void setsIP(String sIP) {
		this.sIP = sIP;
	}

	public String getsApplyNo() {
		return sApplyNo;
	}

	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}

	public List<String> getFileID() {
		return fileID;
	}

	public void setFileID(List<String> fileID) {
		this.fileID = fileID;
	}
	
	

	
	
}
