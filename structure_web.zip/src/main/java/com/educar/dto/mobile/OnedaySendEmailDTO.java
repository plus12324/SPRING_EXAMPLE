package com.educar.dto.mobile;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ������ ������ ���� Email �ޱ� input DTO
 * @author �Ž¿�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onedaySendEmailDTO")
public class OnedaySendEmailDTO {
	
	/** û���ȣ **/
	private String sApplyNo;
	/** �̸��� **/
	private String sToEmail;
	/** �̸� **/
	private String sToName;

	public String getsApplyNo() {
		return sApplyNo;
	}

	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}

	public String getsToEmail() {
		return sToEmail;
	}

	public void setsToEmail(String sToEmail) {
		this.sToEmail = sToEmail;
	}

	public String getsToName() {
		return sToName;
	}

	public void setsToName(String sToName) {
		this.sToName = sToName;
	}
	
	
	
	
}
