package com.educar.dto.mobile;

/**
 * ������ ������ ���� ���� Output DTO
 * @author �Ž¿� 
 */
public class OnedayPhoneAdmitOutputDTO {

	private String sResultmsg;
	
	private String sRspCode;
	/** ����Ȯ�ν�(EndorseTask.setPolicyReceiptInfo) ���� �Ķ���� **/
	private String sAdmitNo;
	
	private String sCellDealNo;

	public String getsResultmsg() {
		return sResultmsg;
	}

	public void setsResultmsg(String sResultmsg) {
		this.sResultmsg = sResultmsg;
	}

	public String getsRspCode() {
		return sRspCode;
	}

	public void setsRspCode(String sRspCode) {
		this.sRspCode = sRspCode;
	}

	public String getsAdmitNo() {
		return sAdmitNo;
	}

	public void setsAdmitNo(String sAdmitNo) {
		this.sAdmitNo = sAdmitNo;
	}

	public String getsCellDealNo() {
		return sCellDealNo;
	}

	public void setsCellDealNo(String sCellDealNo) {
		this.sCellDealNo = sCellDealNo;
	}
	
}
