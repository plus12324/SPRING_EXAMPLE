/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲݺ��� �㺸���� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralCoverageSearchResultDTO")
public class InsuranceGeneralCoverageSearchResultDTO {
	/** ���ǹ�ȣŸ�� **/
	private String sBizTyp;
	/** ���ǹ�ȣ�����ڵ� **/
	private String sInsItmCod;
	/** �����Ϸù�ȣ **/
	private String sSeq;
	/** �輭��ȣ **/
	private String nChgNum;
	/** �㺸���� **/
	private String nCovSeq;
	/** �㺸�ڵ� **/
	private String sCovCod;
	/** �⺻Ư�౸�� (1. �⺻ 2. Ư��) **/
	private String sBscTrtTyp;
	/** �⺻Ư�౸�� �ѱ۸� **/
	private String sBscTrtNam;
	/** ���Աݾ� **/
	private String nAcdImt;
	/** ���뺸��� **/
	private String nBscPmi;
	/** �㺸�� **/
	private String sCovNam;
	/** �ѱ۰��Աݾ� **/
	private String nHanEtnAmt;

	/**
	 * @return the sBizTyp
	 */
	public String getsBizTyp() {
		return sBizTyp;
	}

	/**
	 * @param sBizTyp the sBizTyp to set
	 */
	public void setsBizTyp(final String sBizTyp) {
		this.sBizTyp = sBizTyp;
	}

	/**
	 * @return the sInsItmCod
	 */
	public String getsInsItmCod() {
		return sInsItmCod;
	}

	/**
	 * @param sInsItmCod the sInsItmCod to set
	 */
	public void setsInsItmCod(final String sInsItmCod) {
		this.sInsItmCod = sInsItmCod;
	}

	/**
	 * @return the sSeq
	 */
	public String getsSeq() {
		return sSeq;
	}

	/**
	 * @param sSeq the sSeq to set
	 */
	public void setsSeq(final String sSeq) {
		this.sSeq = sSeq;
	}

	/**
	 * @return the nChgNum
	 */
	public String getnChgNum() {
		return nChgNum;
	}

	/**
	 * @param nChgNum the nChgNum to set
	 */
	public void setnChgNum(final String nChgNum) {
		this.nChgNum = nChgNum;
	}

	/**
	 * @return the nCovSeq
	 */
	public String getnCovSeq() {
		return nCovSeq;
	}

	/**
	 * @param nCovSeq the nCovSeq to set
	 */
	public void setnCovSeq(final String nCovSeq) {
		this.nCovSeq = nCovSeq;
	}

	/**
	 * @return the sCovCod
	 */
	public String getsCovCod() {
		return sCovCod;
	}

	/**
	 * @param sCovCod the sCovCod to set
	 */
	public void setsCovCod(final String sCovCod) {
		this.sCovCod = sCovCod;
	}

	/**
	 * @return the sBscTrtTyp
	 */
	public String getsBscTrtTyp() {
		return sBscTrtTyp;
	}

	/**
	 * @param sBscTrtTyp the sBscTrtTyp to set
	 */
	public void setsBscTrtTyp(final String sBscTrtTyp) {
		this.sBscTrtTyp = sBscTrtTyp;
	}

	/**
	 * @return the sBscTrtNam
	 */
	public String getsBscTrtNam() {
		return sBscTrtNam;
	}

	/**
	 * @param sBscTrtNam the sBscTrtNam to set
	 */
	public void setsBscTrtNam(final String sBscTrtNam) {
		this.sBscTrtNam = sBscTrtNam;
	}

	/**
	 * @return the nAcdImt
	 */
	public String getnAcdImt() {
		return nAcdImt;
	}

	/**
	 * @param nAcdImt the nAcdImt to set
	 */
	public void setnAcdImt(final String nAcdImt) {
		this.nAcdImt = nAcdImt;
	}

	/**
	 * @return the nBscPmi
	 */
	public String getnBscPmi() {
		return nBscPmi;
	}

	/**
	 * @param nBscPmi the nBscPmi to set
	 */
	public void setnBscPmi(final String nBscPmi) {
		this.nBscPmi = nBscPmi;
	}

	/**
	 * @return the sCovNam
	 */
	public String getsCovNam() {
		return sCovNam;
	}

	/**
	 * @param sCovNam the sCovNam to set
	 */
	public void setsCovNam(final String sCovNam) {
		this.sCovNam = sCovNam;
	}

	/**
	 * @return the nHanEtnAmt
	 */
	public String getnHanEtnAmt() {
		return nHanEtnAmt;
	}

	/**
	 * @param nHanEtnAmt the nHanEtnAmt to set
	 */
	public void setnHanEtnAmt(final String nHanEtnAmt) {
		this.nHanEtnAmt = nHanEtnAmt;
	}

}
