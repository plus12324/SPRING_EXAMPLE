/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ���������  �ѽ������� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "mobileFaxSendDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class MobileFaxSendDTO {
	/** �����ȣ(custno������ �����ȣ�� �´�) **/
	private String custNo;
	/** �㺸 **/
	private String sHndCover;
	/** ���� **/
	private String sDmgeNo;
	/** �ѽ���ȣ - ���� �Է�**/
	private String faxNo;
	/** �ѽ����� �� : "03" , �� : "05", ���Ȯ�μ� : "06" **/
	private String serviceType;

	/**
	 * @return the custNo
	 */
	public String getCustNo() {
		return custNo;
	}

	/**
	 * @param custNo the custNo to set
	 */
	public void setCustNo(final String custNo) {
		this.custNo = custNo;
	}

	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}

	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(final String sHndCover) {
		this.sHndCover = sHndCover;
	}

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the faxNo
	 */
	public String getFaxNo() {
		return faxNo;
	}

	/**
	 * @param faxNo the faxNo to set
	 */
	public void setFaxNo(final String faxNo) {
		this.faxNo = faxNo;
	}

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(final String serviceType) {
		this.serviceType = serviceType;
	}

}
