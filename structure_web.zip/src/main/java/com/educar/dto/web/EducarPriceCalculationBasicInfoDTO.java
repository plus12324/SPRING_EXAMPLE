/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "educarPriceCalculationBasicInfoDTO")
public class EducarPriceCalculationBasicInfoDTO {
	/** ��ǰ�ڵ� 1605 **/
	private String sPrdCod;
	/** ����Ⱓ (1��:1 , 3��:3) **/
	private String gi_gan;
	/** ���ο����޼� (�����ڱ޼���1�̸� 10, 2�̸� 20) **/
	private String geuk_su;
	/** ����ڿ����޼� (�����ڱ޼���1�̸� 10, 2�̸� 20) **/
	private String bu_bu_geuk_su;
	/** �������� (������:10 �κ���:20) **/
	private String bu_bu_yn;
	/** ���Ա��� (�Ͻó�:01, 12ȸ��:12, 36ȸ��:36) **/
	private String nab_ib;
	/** ��ǰ���� (������:A, �⺻��:B, ������:C) **/
	private String sPlnCod;
	/** ���� (��:01, ��:02) **/
	private String sSex;
	/** ���Ǽ��� (��:01, ��:02) **/
	private String sMainSexCod;
	/** ���Ǽ��� (��:01, ��:02) **/
	private String sSeconSexCod;

	/**
	 * @return the sPrdCod
	 */
	public String getsPrdCod() {
		return sPrdCod;
	}

	/**
	 * @param sPrdCod the sPrdCod to set
	 */
	public void setsPrdCod(final String sPrdCod) {
		this.sPrdCod = sPrdCod;
	}

	/**
	 * @return the gi_gan
	 */
	public String getGi_gan() {
		return gi_gan;
	}

	/**
	 * @param gi_gan the gi_gan to set
	 */
	public void setGi_gan(final String gi_gan) {
		this.gi_gan = gi_gan;
	}

	/**
	 * @return the geuk_su
	 */
	public String getGeuk_su() {
		return geuk_su;
	}

	/**
	 * @param geuk_su the geuk_su to set
	 */
	public void setGeuk_su(final String geuk_su) {
		this.geuk_su = geuk_su;
	}

	/**
	 * @return the bu_bu_geuk_su
	 */
	public String getBu_bu_geuk_su() {
		return bu_bu_geuk_su;
	}

	/**
	 * @param bu_bu_geuk_su the bu_bu_geuk_su to set
	 */
	public void setBu_bu_geuk_su(final String bu_bu_geuk_su) {
		this.bu_bu_geuk_su = bu_bu_geuk_su;
	}

	/**
	 * @return the bu_bu_yn
	 */
	public String getBu_bu_yn() {
		return bu_bu_yn;
	}

	/**
	 * @param bu_bu_yn the bu_bu_yn to set
	 */
	public void setBu_bu_yn(final String bu_bu_yn) {
		this.bu_bu_yn = bu_bu_yn;
	}

	/**
	 * @return the nab_ib
	 */
	public String getNab_ib() {
		return nab_ib;
	}

	/**
	 * @param nab_ib the nab_ib to set
	 */
	public void setNab_ib(final String nab_ib) {
		this.nab_ib = nab_ib;
	}

	/**
	 * @return the sPlnCod
	 */
	public String getsPlnCod() {
		return sPlnCod;
	}

	/**
	 * @param sPlnCod the sPlnCod to set
	 */
	public void setsPlnCod(final String sPlnCod) {
		this.sPlnCod = sPlnCod;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @return the sMainSexCod
	 */
	public String getsMainSexCod() {
		return sMainSexCod;
	}

	/**
	 * @param sMainSexCod the sMainSexCod to set
	 */
	public void setsMainSexCod(final String sMainSexCod) {
		this.sMainSexCod = sMainSexCod;
	}

	/**
	 * @return the sSeconSexCod
	 */
	public String getsSeconSexCod() {
		return sSeconSexCod;
	}

	/**
	 * @param sSeconSexCod the sSeconSexCod to set
	 */
	public void setsSeconSexCod(final String sSeconSexCod) {
		this.sSeconSexCod = sSeconSexCod;
	}

}
