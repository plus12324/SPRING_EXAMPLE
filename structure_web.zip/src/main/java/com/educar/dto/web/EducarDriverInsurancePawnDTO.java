/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ī ������ ���� �㺸 DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "educarDriverInsurancePawnDTO")
public class EducarDriverInsurancePawnDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** �㺸�ڵ� **/
	private String sCover;
	/** �㺸�� **/
	private String sCoverName;
	/** �㺸�󼼼��� **/
	private String sCoverDesc;
	/** ���ñ��� (01 : �ʼ� 00 : ���ð���)**/
	private String sEssentialYN;
	/**
	 * <pre> 
	 * �㺸���Կ��� (�̰��� : 00, ���� : 01)
	 * ��ȸ�� ���
	 * </pre> 
	 **/
	private String sSelYN;
	/** ���� �ݾ� **/
	private String nEtnAmt;

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the sCoverName
	 */
	public String getsCoverName() {
		return sCoverName;
	}

	/**
	 * @param sCoverName the sCoverName to set
	 */
	public void setsCoverName(final String sCoverName) {
		this.sCoverName = sCoverName;
	}

	/**
	 * @return the sCoverDesc
	 */
	public String getsCoverDesc() {
		return sCoverDesc;
	}

	/**
	 * @param sCoverDesc the sCoverDesc to set
	 */
	public void setsCoverDesc(final String sCoverDesc) {
		this.sCoverDesc = sCoverDesc;
	}

	/**
	 * @return the sEssentialYN
	 */
	public String getsEssentialYN() {
		return sEssentialYN;
	}

	/**
	 * @param sEssentialYN the sEssentialYN to set
	 */
	public void setsEssentialYN(final String sEssentialYN) {
		this.sEssentialYN = sEssentialYN;
	}

	/**
	 * @return the sSelYN
	 */
	public String getsSelYN() {
		return sSelYN;
	}

	/**
	 * @param sSelYN the sSelYN to set
	 */
	public void setsSelYN(final String sSelYN) {
		this.sSelYN = sSelYN;
	}

	/**
	 * @return the nEtnAmt
	 */
	public String getnEtnAmt() {
		return nEtnAmt;
	}

	/**
	 * @param nEtnAmt the nEtnAmt to set
	 */
	public void setnEtnAmt(final String nEtnAmt) {
		this.nEtnAmt = nEtnAmt;
	}

}
