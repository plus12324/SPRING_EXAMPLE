/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * Ÿ��ũ ȣ�� �̺�Ʈ
 * <pre>
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "eventTaskDTO")
public class EventTaskDTO {

	/** �̺�Ʈ ������ �̸� **/
	private String sName;
	/** �̺�Ʈ ������ ��ȭ��ȣ1 **/
	private String sCellPhone1;
	/** �̺�Ʈ ������ ��ȭ��ȣ2**/
	private String sCellPhone2;
	/** �̺�Ʈ ������ ��ȭ��ȣ3 **/
	private String sCellPhone3;
	/** ��û ��ǰ�� **/
	private String sProduct;
	/** �̺�Ʈ�ڵ� **/
	private String sEventDiv;
	/** �̺�Ʈȸ�� **/
	private String sEventSeq;
	/** �Է��� **/
	private String sInputDate;
	/** �Է½ð� **/
	private String sInputTime;
	/** �̺�Ʈ ������ **/
	private String sStartDate;
	/** �̺�Ʈ ������ **/
	private String sEndDate;
	
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sEventSeq
	 */
	public String getsEventSeq() {
		return sEventSeq;
	}
	/**
	 * @param sEventSeq the sEventSeq to set
	 */
	public void setsEventSeq(String sEventSeq) {
		this.sEventSeq = sEventSeq;
	}
	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}
	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sProduct
	 */
	public String getsProduct() {
		return sProduct;
	}
	/**
	 * @param sProduct the sProduct to set
	 */
	public void setsProduct(String sProduct) {
		this.sProduct = sProduct;
	}
	/**
	 * @return the sStartDate
	 */
	public String getsStartDate() {
		return sStartDate;
	}
	/**
	 * @param sStartDate the sStartDate to set
	 */
	public void setsStartDate(String sStartDate) {
		this.sStartDate = sStartDate;
	}
	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}
	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(String sEndDate) {
		this.sEndDate = sEndDate;
	}
	
	
}
