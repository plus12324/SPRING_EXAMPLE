/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �Ϲݰ�� - �������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayRectList01DTO")
public class InsDrvPayRectList01DTO {
	/** 	�����ǰ��	 **/ 
	private String 	sInsTypeName;
	/** 	����ȣ	 **/ 
	private String 	sPolicyNo;
	/** 	������ڵ�	 **/
	private String 	sPolHolderID;
	/** 	�����	 **/ 
	private String 	sPolHolderName;
	/** 	����Ⱓ	 **/ 
	private String 	sInsDate;
	/** 	1ȸ �����	 **/ 
	private String 	s1stInsPrem;
	/** 	�ѳ���ȸ��	 **/ 
	private String 	nInstmNo;
	/** 	����ñ�	 **/ 
	private String 	sInsCtrTpd;
	/** 	��������	 **/ 
	private String 	sInsCtrPed;
	/** 	������	 **/ 
	private String 	sApplyStat;
	/** 	�����ֱ�/���	 **/ 
	private String 	sPayMthNam;
	/** 	ī��/��������	 **/ 
	private String 	sBnkActNam;
	/** 	��ü��	 **/ 
	private String 	sBwDate;
	/** 	�ѳ��Ժ����	 **/ 
	private String 	nTotRectPrem;
	/** 	�������Կ�	 **/ 
	private String 	sLastBwDate;

	/** ����ȣ 1 **/
	private String 	sBizTyp;
	/** ����ȣ 2 **/
	private String 	sInsItmCod;
	/** ����ȣ 3 **/
	private String 	sSeq;
	/** ������ ����� **/
	private String nReqAmt;
	/** �輭��ȣ **/
	private String nEndorseNo;

	
	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}
	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the sPolHolderID
	 */
	public String getsPolHolderID() {
		return sPolHolderID;
	}
	/**
	 * @param sPolHolderID the sPolHolderID to set
	 */
	public void setsPolHolderID(String sPolHolderID) {
		this.sPolHolderID = sPolHolderID;
	}
	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}
	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}
	/**
	 * @return the sInsDate
	 */
	public String getsInsDate() {
		return sInsDate;
	}
	/**
	 * @param sInsDate the sInsDate to set
	 */
	public void setsInsDate(String sInsDate) {
		this.sInsDate = sInsDate;
	}
	/**
	 * @return the s1stInsPrem
	 */
	public String getS1stInsPrem() {
		return s1stInsPrem;
	}
	/**
	 * @param s1stInsPrem the s1stInsPrem to set
	 */
	public void setS1stInsPrem(String s1stInsPrem) {
		this.s1stInsPrem = s1stInsPrem;
	}
	/**
	 * @return the nInstmNo
	 */
	public String getnInstmNo() {
		return nInstmNo;
	}
	/**
	 * @param nInstmNo the nInstmNo to set
	 */
	public void setnInstmNo(String nInstmNo) {
		this.nInstmNo = nInstmNo;
	}
	/**
	 * @return the sInsCtrTpd
	 */
	public String getsInsCtrTpd() {
		return sInsCtrTpd;
	}
	/**
	 * @param sInsCtrTpd the sInsCtrTpd to set
	 */
	public void setsInsCtrTpd(String sInsCtrTpd) {
		this.sInsCtrTpd = sInsCtrTpd;
	}
	/**
	 * @return the sInsCtrPed
	 */
	public String getsInsCtrPed() {
		return sInsCtrPed;
	}
	/**
	 * @param sInsCtrPed the sInsCtrPed to set
	 */
	public void setsInsCtrPed(String sInsCtrPed) {
		this.sInsCtrPed = sInsCtrPed;
	}
	/**
	 * @return the sApplyStat
	 */
	public String getsApplyStat() {
		return sApplyStat;
	}
	/**
	 * @param sApplyStat the sApplyStat to set
	 */
	public void setsApplyStat(String sApplyStat) {
		this.sApplyStat = sApplyStat;
	}
	/**
	 * @return the sPayMthNam
	 */
	public String getsPayMthNam() {
		return sPayMthNam;
	}
	/**
	 * @param sPayMthNam the sPayMthNam to set
	 */
	public void setsPayMthNam(String sPayMthNam) {
		this.sPayMthNam = sPayMthNam;
	}
	/**
	 * @return the sBnkActNam
	 */
	public String getsBnkActNam() {
		return sBnkActNam;
	}
	/**
	 * @param sBnkActNam the sBnkActNam to set
	 */
	public void setsBnkActNam(String sBnkActNam) {
		this.sBnkActNam = sBnkActNam;
	}
	/**
	 * @return the sBwDate
	 */
	public String getsBwDate() {
		return sBwDate;
	}
	/**
	 * @param sBwDate the sBwDate to set
	 */
	public void setsBwDate(String sBwDate) {
		this.sBwDate = sBwDate;
	}
	/**
	 * @return the nTotRectPrem
	 */
	public String getnTotRectPrem() {
		return nTotRectPrem;
	}
	/**
	 * @param nTotRectPrem the nTotRectPrem to set
	 */
	public void setnTotRectPrem(String nTotRectPrem) {
		this.nTotRectPrem = nTotRectPrem;
	}
	/**
	 * @return the sLastBwDate
	 */
	public String getsLastBwDate() {
		return sLastBwDate;
	}
	/**
	 * @param sLastBwDate the sLastBwDate to set
	 */
	public void setsLastBwDate(String sLastBwDate) {
		this.sLastBwDate = sLastBwDate;
	}
	/**
	 * @return the sBizTyp
	 */
	public String getsBizTyp() {
		return sBizTyp;
	}
	/**
	 * @param sBizTyp the sBizTyp to set
	 */
	public void setsBizTyp(String sBizTyp) {
		this.sBizTyp = sBizTyp;
	}
	/**
	 * @return the sInsItmCod
	 */
	public String getsInsItmCod() {
		return sInsItmCod;
	}
	/**
	 * @param sInsItmCod the sInsItmCod to set
	 */
	public void setsInsItmCod(String sInsItmCod) {
		this.sInsItmCod = sInsItmCod;
	}
	/**
	 * @return the sSeq
	 */
	public String getsSeq() {
		return sSeq;
	}
	/**
	 * @param sSeq the sSeq to set
	 */
	public void setsSeq(String sSeq) {
		this.sSeq = sSeq;
	}
	/**
	 * @return the nReqAmt
	 */
	public String getnReqAmt() {
		return nReqAmt;
	}
	/**
	 * @param nReqAmt the nReqAmt to set
	 */
	public void setnReqAmt(String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}
	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}
	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}
	
	
	
}
