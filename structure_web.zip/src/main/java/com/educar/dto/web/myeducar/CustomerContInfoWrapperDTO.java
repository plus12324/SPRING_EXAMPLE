/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ���̿���ī - ���������� ���� WrapperDTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "customerContInfoWrapperDTO")
public class CustomerContInfoWrapperDTO {

	/** ���輭�ּ����� **/
	private CustomerContInfoAdrsInfoDTO adrsInfo;
	/** ������� **/
	private List<CustContInfoListDTO> policyInfo;
	
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO home;
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO office;
	/** ���� ��Ÿ���ּ����� **/
	private CustomerContInfoAdrsDTO etc;
	/** ��ȭ��ȣ���� **/
	private CustomerContInfoTelInfoDTO telInfo;
	/** �߼��� �ּ����� **/
	private CustomerContInfoSendAdrsDTO send;
	
	/** Flag ���� **/
	private CustomerContInfoChgFlagDTO flag;

	/**
	 * @return the adrsInfo
	 */
	public CustomerContInfoAdrsInfoDTO getAdrsInfo() {
		return adrsInfo;
	}

	/**
	 * @param adrsInfo the adrsInfo to set
	 */
	public void setAdrsInfo(CustomerContInfoAdrsInfoDTO adrsInfo) {
		this.adrsInfo = adrsInfo;
	}

	/**
	 * @return the policyInfo
	 */
	public List<CustContInfoListDTO> getPolicyInfo() {
		return policyInfo;
	}

	/**
	 * @param policyInfo the policyInfo to set
	 */
	public void setPolicyInfo(List<CustContInfoListDTO> policyInfo) {
		this.policyInfo = policyInfo;
	}

	/**
	 * @return the home
	 */
	public CustomerContInfoAdrsDTO getHome() {
		return home;
	}

	/**
	 * @param home the home to set
	 */
	public void setHome(CustomerContInfoAdrsDTO home) {
		this.home = home;
	}

	/**
	 * @return the office
	 */
	public CustomerContInfoAdrsDTO getOffice() {
		return office;
	}

	/**
	 * @param office the office to set
	 */
	public void setOffice(CustomerContInfoAdrsDTO office) {
		this.office = office;
	}

	/**
	 * @return the etc
	 */
	public CustomerContInfoAdrsDTO getEtc() {
		return etc;
	}

	/**
	 * @param etc the etc to set
	 */
	public void setEtc(CustomerContInfoAdrsDTO etc) {
		this.etc = etc;
	}

	/**
	 * @return the telInfo
	 */
	public CustomerContInfoTelInfoDTO getTelInfo() {
		return telInfo;
	}

	/**
	 * @param telInfo the telInfo to set
	 */
	public void setTelInfo(CustomerContInfoTelInfoDTO telInfo) {
		this.telInfo = telInfo;
	}

	/**
	 * @return the send
	 */
	public CustomerContInfoSendAdrsDTO getSend() {
		return send;
	}

	/**
	 * @param send the send to set
	 */
	public void setSend(CustomerContInfoSendAdrsDTO send) {
		this.send = send;
	}

	/**
	 * @return the flag
	 */
	public CustomerContInfoChgFlagDTO getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(CustomerContInfoChgFlagDTO flag) {
		this.flag = flag;
	}
	
	
}
