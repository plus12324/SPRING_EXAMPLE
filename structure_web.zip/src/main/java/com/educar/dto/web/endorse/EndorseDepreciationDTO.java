/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * �߰��μ�ǰ �����ﰢ�� DTO, Reuqest, Response�� �� ���δ�.
 * Response���� sItemCode�� nRemainAmt�� ����Ѵ�
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement(name = "endorseDepreciationDTO")
public class EndorseDepreciationDTO {

	/** ����ȣ **/
	private String sPolicyNo;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** ���Գ�� **/
	private String sYYYYMM;
	/** ���԰��� **/
	private String nAmt;
	/** �μ�ǰ�ڵ� **/
	private String sItemCode;
	/** �����ݾ� **/
	private String nRemainAmt;

	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @return the sItemCode
	 */
	public String getsItemCode() {
		return sItemCode;
	}

	/**
	 * @return the sYYYYMM
	 */
	public String getsYYYYMM() {
		return sYYYYMM;
	}

	/**
	 * @return the nAmt
	 */
	public String getnAmt() {
		return nAmt;
	}

	/**
	 * @return the nRemainAmt
	 */
	public String getnRemainAmt() {
		return nRemainAmt;
	}

	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(final String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @param sItemCode the sItemCode to set
	 */
	public void setsItemCode(final String sItemCode) {
		this.sItemCode = sItemCode;
	}

	/**
	 * @param sYYYYMM the sYYYYMM to set
	 */
	public void setsYYYYMM(final String sYYYYMM) {
		this.sYYYYMM = sYYYYMM;
	}

	/**
	 * @param nAmt the nAmt to set
	 */
	public void setnAmt(final String nAmt) {
		this.nAmt = nAmt;
	}

	/**
	 * @param nRemainAmt the nRemainAmt to set
	 */
	public void setnRemainAmt(final String nRemainAmt) {
		this.nRemainAmt = nRemainAmt;
	}

}
