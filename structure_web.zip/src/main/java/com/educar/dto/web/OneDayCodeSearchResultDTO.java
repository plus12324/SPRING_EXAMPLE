/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �ڵ� ��ȸ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "oneDayCodeSearchResultDTO")
public class OneDayCodeSearchResultDTO {
	/**
	 * <pre>
	 *  ���� 
	 *  ���������ڵ�: sInsType, �����: sInsTypeName
	 * </pre> 
	 **/
	@XmlElementWrapper(name = "insTypeVtList")
	private List<OneDayCodeDTO> insTypeVt;
	/**
	 * <pre>
	 * ���԰�� 
	 * ���������ڵ�: sInsType, ��Ű�� �ڵ�: sPackAge, ��Ű����: sPackAgeName
	 * </pre>
	 **/
	@XmlElementWrapper(name = "packageVtList")
	private List<OneDayCodeDTO> packageVt;
	/**
	 * <pre>
	 * �㺸
	 * ���������ڵ�: sInsType, ��Ű�� �ڵ�: sPackAge, �㺸�ڵ�: sCover, �㺸��: sCoverName, ���Դ㺸�ڵ�: sOptCode, ���Դ㺸��: sOptName
	 * </pre>
	 **/
	@XmlElementWrapper(name = "coverVtList")
	private List<OneDayCodeDTO> coverVt;
	/**
	 * <pre>
	 * ����
	 * ���������ڵ�: sInsType, �����ڵ�: sVehicleCode, ������: sVehicleName
	 * </pre>
	 **/
	@XmlElementWrapper(name = "vehicleVtList")
	private List<OneDayCodeDTO> vehicleVt;

	/**
	 * @return the insTypeVt
	 */
	public List<OneDayCodeDTO> getInsTypeVt() {
		return insTypeVt;
	}

	/**
	 * @param insTypeVt the insTypeVt to set
	 */
	public void setInsTypeVt(final List<OneDayCodeDTO> insTypeVt) {
		this.insTypeVt = insTypeVt;
	}

	/**
	 * @return the packageVt
	 */
	public List<OneDayCodeDTO> getPackageVt() {
		return packageVt;
	}

	/**
	 * @param packageVt the packageVt to set
	 */
	public void setPackageVt(final List<OneDayCodeDTO> packageVt) {
		this.packageVt = packageVt;
	}

	/**
	 * @return the coverVt
	 */
	public List<OneDayCodeDTO> getCoverVt() {
		return coverVt;
	}

	/**
	 * @param coverVt the coverVt to set
	 */
	public void setCoverVt(final List<OneDayCodeDTO> coverVt) {
		this.coverVt = coverVt;
	}

	/**
	 * @return the vehicleVt
	 */
	public List<OneDayCodeDTO> getVehicleVt() {
		return vehicleVt;
	}

	/**
	 * @param vehicleVt the vehicleVt to set
	 */
	public void setVehicleVt(final List<OneDayCodeDTO> vehicleVt) {
		this.vehicleVt = vehicleVt;
	}

}
