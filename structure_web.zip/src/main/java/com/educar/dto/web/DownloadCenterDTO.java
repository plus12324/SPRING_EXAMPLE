/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * �������� - �ٿ�ε弾�� DTO
 * ���� DB : WEBFF08
 * <pre>
 * @author �ּ�ȯ
 *
 */
@XmlRootElement(name = "downloadCenterDTO")
public class DownloadCenterDTO extends PageDTO {
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Խñ� ��ȣ  */
	private int nSeq;
	/** ���ҽ�Ű **/
	private String sResourceKey;
	/** ĳ�Ͱ��� ���� */
	private String sType;
	/** ���� */
	private String sTitle;
	/** ÷������ ����*/
	private String sFileType;
	/** ���� ���� URI**/
	private String sFileTypeURI;
	/** ���� �̸� **/
	private String sFileName;

	/**
	 * @return the nSeq
	 */
	public int getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final int nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sResourceKey
	 */
	public String getsResourceKey() {
		return sResourceKey;
	}

	/**
	 * @param sResourceKey the sResourceKey to set
	 */
	public void setsResourceKey(final String sResourceKey) {
		this.sResourceKey = sResourceKey;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sAttachFile
	 */
	public String getsFileType() {
		return sFileType;
	}

	/**
	 * @param sAttachFile the sAttachFile to set
	 */
	public void setsFileType(final String sAttachFile) {
		this.sFileType = sAttachFile;
	}

	/**
	 * @return the sFileTypeURI
	 */
	public String getsFileTypeURI() {
		return sFileTypeURI;
	}

	/**
	 * @param sFileTypeURI the sFileTypeURI to set
	 */
	public void setsFileTypeURI(final String sFileTypeURI) {
		this.sFileTypeURI = sFileTypeURI;
	}

	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}

	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(final String sFileName) {
		this.sFileName = sFileName;
	}

	/**
	 * @return the sType
	 */
	public String getsType() {
		return sType;
	}

	/**
	 * @param sType the sType to set
	 */
	public void setsType(final String sType) {
		this.sType = sType;
	}
}
