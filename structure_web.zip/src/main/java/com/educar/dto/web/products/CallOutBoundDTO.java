/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

/**
 * �ݼ��� �ٹ��ð� ��, �� �ƿ��ٿ�� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "callOutBoundDTO")
public class CallOutBoundDTO {
	/** ��Ÿ��ũID (����4�ڸ� ��) 2630)**/
	@ValidateLength(type = TypeEnum.NUMBER, required = true)
	private String nTaskID;
	/** �Է��ڻ�� **/
	private String sInsertUser;
	/** ������ȣ �Ǵ� ����ڹ�ȣ **/
	private String sCustNo;
	/** ���̾��� (P: ������, O: Pregressive �⺻�� : O�� �Է�) **/
	private String sDialMode;
	/** �ݿ������� (20121006 �⺻������ ����)**/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd, required = true)
	private String sCallReserveDate;
	/** ������ **/
	private String sCustName;
	/** ����ó1 **/
	private String sTel1Part1;
	/** ����ó2 **/
	private String sTel1Part2;
	/** ����ó3 **/
	private String sTel1Part3;
	/** ����óŸ�� (0:����, 1:����, 2:�繫, 3:�ڵ���) **/
	private String sTelType1;
	/** �ܺ�Ű **/
	private String sKey;
	/** �ܺ�ŰŸ�� (�ܺ�Ű Ÿ��(1:û��,2:���,3:�ֹι�ȣ,4:����,5:�߱޹�) �ֹι�ȣ�� ��� 3)**/
	private String nKeyType;
	/** �Է����� yyyyMMdd **/
	private String sInsertDate;
	/** �Է½ð� HHmmss **/
	private String sInsertTime;
	/** �ΰ����� **/
	private String sDescription;

	/**
	 * @return the nTaskID
	 */
	public String getnTaskID() {
		return nTaskID;
	}

	/**
	 * @param nTaskID the nTaskID to set
	 */
	public void setnTaskID(final String nTaskID) {
		this.nTaskID = nTaskID;
	}

	/**
	 * @return the sInsertUser
	 */
	public String getsInsertUser() {
		return sInsertUser;
	}

	/**
	 * @param sInsertUser the sInsertUser to set
	 */
	public void setsInsertUser(final String sInsertUser) {
		this.sInsertUser = sInsertUser;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sDialMode
	 */
	public String getsDialMode() {
		return sDialMode;
	}

	/**
	 * @param sDialMode the sDialMode to set
	 */
	public void setsDialMode(final String sDialMode) {
		this.sDialMode = sDialMode;
	}

	/**
	 * @return the sCallReserveDate
	 */
	public String getsCallReserveDate() {
		return sCallReserveDate;
	}

	/**
	 * @param sCallReserveDate the sCallReserveDate to set
	 */
	public void setsCallReserveDate(final String sCallReserveDate) {
		this.sCallReserveDate = sCallReserveDate;
	}

	/**
	 * @return the sCustName
	 */
	public String getsCustName() {
		return sCustName;
	}

	/**
	 * @param sCustName the sCustName to set
	 */
	public void setsCustName(final String sCustName) {
		this.sCustName = sCustName;
	}

	/**
	 * @return the sTel1Part1
	 */
	public String getsTel1Part1() {
		return sTel1Part1;
	}

	/**
	 * @param sTel1Part1 the sTel1Part1 to set
	 */
	public void setsTel1Part1(final String sTel1Part1) {
		this.sTel1Part1 = sTel1Part1;
	}

	/**
	 * @return the sTel1Part2
	 */
	public String getsTel1Part2() {
		return sTel1Part2;
	}

	/**
	 * @param sTel1Part2 the sTel1Part2 to set
	 */
	public void setsTel1Part2(final String sTel1Part2) {
		this.sTel1Part2 = sTel1Part2;
	}

	/**
	 * @return the sTel1Part3
	 */
	public String getsTel1Part3() {
		return sTel1Part3;
	}

	/**
	 * @param sTel1Part3 the sTel1Part3 to set
	 */
	public void setsTel1Part3(final String sTel1Part3) {
		this.sTel1Part3 = sTel1Part3;
	}

	/**
	 * @return the sTelType1
	 */
	public String getsTelType1() {
		return sTelType1;
	}

	/**
	 * @param sTelType1 the sTelType1 to set
	 */
	public void setsTelType1(final String sTelType1) {
		this.sTelType1 = sTelType1;
	}

	/**
	 * @return the sKey
	 */
	public String getsKey() {
		return sKey;
	}

	/**
	 * @param sKey the sKey to set
	 */
	public void setsKey(final String sKey) {
		this.sKey = sKey;
	}

	/**
	 * @return the nKeyType
	 */
	public String getnKeyType() {
		return nKeyType;
	}

	/**
	 * @param nKeyType the nKeyType to set
	 */
	public void setnKeyType(final String nKeyType) {
		this.nKeyType = nKeyType;
	}

	/**
	 * @return the sInsertDate
	 */
	public String getsInsertDate() {
		return sInsertDate;
	}

	/**
	 * @param sInsertDate the sInsertDate to set
	 */
	public void setsInsertDate(final String sInsertDate) {
		this.sInsertDate = sInsertDate;
	}

	/**
	 * @return the sInsertTime
	 */
	public String getsInsertTime() {
		return sInsertTime;
	}

	/**
	 * @param sInsertTime the sInsertTime to set
	 */
	public void setsInsertTime(final String sInsertTime) {
		this.sInsertTime = sInsertTime;
	}

	/**
	 * @return the sDescription
	 */
	public String getsDescription() {
		return sDescription;
	}

	/**
	 * @param sDescription the sDescription to set
	 */
	public void setsDescription(final String sDescription) {
		this.sDescription = sDescription;
	}

}
