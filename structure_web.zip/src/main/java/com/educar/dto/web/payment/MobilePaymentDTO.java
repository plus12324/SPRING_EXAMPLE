/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * �ڵ��� ���� DTO (������, Mobile ��, �� ���)
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "mobilePaymentDTO")
public class MobilePaymentDTO {

	/** û���ȣ : ���� **/
	private String sApplyType;
	/** û���ȣ : ��� **/
	private String sApplyYM;
	/** û���ȣ : Ser **/
	private String sApplySer;
	/** �������� **/
	private String sPayType = "P";
	/** �޴��� ��ȣ ���ڸ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.PhoneNumber, regex = "[0-9]{3}")
	private String sCellPhoneNo1;
	/** �޴��� ��ȣ �߰��ڸ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.PhoneNumber, regex = "[0-9]{3,4}")
	private String sCellPhoneNo2;
	/** �޴��� ��ȣ ������ **/
	@ValidateRegex(predefinedRegex = RegexEnum.PhoneNumber, regex = "[0-9]{4}")
	private String sCellPhoneNo3;
	/** �ڵ��� ��ȣ **/
	@ValidateRegex(predefinedRegex = RegexEnum.PhoneNumber, regex = "[0-9]{10,11}")
	private String sCellPhoneNo;
	/** ��Ż� SKT, KTF, LGT **/
	private String sCustCom;
	/** ����ڸ� **/
	private String sCellPhoneOwner;
	/** ������ڵ� �ֹι�ȣ**/
	private String sCellPhoneOwnerID;
	/**  ���αݾ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String nReqAmt;
	/** ����ڻ�� **/
	private String sReqAgnt;
	/** ����ڸ� ����Ͼ�, �ȵ���̵� ��, ��� UserIDEnum name ���  **/
	private String sReqAgntName;
	/** ������� **/
	private String sSettleStat = "R";
	/** �̸��� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEmail;

	/**
	 * @return the sCustCom
	 */
	public String getsCustCom() {
		return sCustCom;
	}

	/**
	 * @return the sCellPhoneOwner
	 */
	public String getsCellPhoneOwner() {
		return sCellPhoneOwner;
	}

	/**
	 * @return the sCellPhoneOwnerID
	 */
	public String getsCellPhoneOwnerID() {
		return sCellPhoneOwnerID;
	}

	/**
	 * @return the nReqAmt
	 */
	public String getnReqAmt() {
		return nReqAmt;
	}

	/**
	 * @return the sReqAgnt
	 */
	public String getsReqAgnt() {
		return sReqAgnt;
	}

	/**
	 * @return the sReqAgntName
	 */
	public String getsReqAgntName() {
		return sReqAgntName;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sCustCom the sCustCom to set
	 */
	public void setsCustCom(final String sCustCom) {
		this.sCustCom = sCustCom;
	}

	/**
	 * @param sCellPhoneOwner the sCellPhoneOwner to set
	 */
	public void setsCellPhoneOwner(final String sCellPhoneOwner) {
		this.sCellPhoneOwner = sCellPhoneOwner;
	}

	/**
	 * @param sCellPhoneOwnerID the sCellPhoneOwnerID to set
	 */
	public void setsCellPhoneOwnerID(final String sCellPhoneOwnerID) {
		this.sCellPhoneOwnerID = sCellPhoneOwnerID;
	}

	/**
	 * @param nReqAmt the nReqAmt to set
	 */
	public void setnReqAmt(final String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}

	/**
	 * @param sReqAgnt the sReqAgnt to set
	 */
	public void setsReqAgnt(final String sReqAgnt) {
		this.sReqAgnt = sReqAgnt;
	}

	/**
	 * @param sReqAgntName the sReqAgntName to set
	 */
	public void setsReqAgntName(final String sReqAgntName) {
		this.sReqAgntName = sReqAgntName;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sPayType
	 */
	public String getsPayType() {
		return sPayType;
	}

	/**
	 * @param sPayType the sPayType to set
	 */
	public void setsPayType(final String sPayType) {
		this.sPayType = sPayType;
	}

	/**
	 * @return the sCellPhoneNo
	 */
	public String getsCellPhoneNo() {
		return sCellPhoneNo;
	}

	/**
	 * @param sCellPhoneNo the sCellPhoneNo to set
	 */
	public void setsCellPhoneNo(final String sCellPhoneNo) {
		this.sCellPhoneNo = sCellPhoneNo;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sSettleStat
	 */
	public String getsSettleStat() {
		return sSettleStat;
	}

	/**
	 * @param sSettleStat the sSettleStat to set
	 */
	public void setsSettleStat(final String sSettleStat) {
		this.sSettleStat = sSettleStat;
	}

	/**
	 * @return the sCellPhoneNo1
	 */
	public String getsCellPhoneNo1() {
		return sCellPhoneNo1;
	}

	/**
	 * @param sCellPhoneNo1 the sCellPhoneNo1 to set
	 */
	public void setsCellPhoneNo1(final String sCellPhoneNo1) {
		this.sCellPhoneNo1 = sCellPhoneNo1;
	}

	/**
	 * @return the sCellPhoneNo2
	 */
	public String getsCellPhoneNo2() {
		return sCellPhoneNo2;
	}

	/**
	 * @param sCellPhoneNo2 the sCellPhoneNo2 to set
	 */
	public void setsCellPhoneNo2(final String sCellPhoneNo2) {
		this.sCellPhoneNo2 = sCellPhoneNo2;
	}

	/**
	 * @return the sCellPhoneNo3
	 */
	public String getsCellPhoneNo3() {
		return sCellPhoneNo3;
	}

	/**
	 * @param sCellPhoneNo3 the sCellPhoneNo3 to set
	 */
	public void setsCellPhoneNo3(final String sCellPhoneNo3) {
		this.sCellPhoneNo3 = sCellPhoneNo3;
	}

}
