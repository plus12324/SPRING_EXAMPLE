/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ī �����ں��� �㺸����ȸ DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "covgeDTO")
public class CovgeDTO {
	/** �㺸���� (�⺻, Ư��) **/
	private String sCovNm;
	/** �㺸�����ڵ� (1 : �⺻ 2 : Ư��) **/
	private String sCoverType;
	/** �㺸�ڵ� **/
	private String sCovCod;
	/** �㺸�� **/
	private String sCoverName;
	/** ���������Աݾ� **/
	private String nEtnAmta;
	/** �⺻�����Աݾ� **/
	private String nEtnAmtb;
	/** ���������Աݾ� **/
	private String nEtnAmtc;
	/** �������ѱ۰��Աݾ� **/
	private String sHanAmtA;
	/** �⺻���ѱ۰��Աݾ� **/
	private String sHanAmtB;
	/** �������ѱ۰��Աݾ� **/
	private String sHanAmtC;
	/** ���ñ��� (01 : �ʼ� 00 : ���ð���) **/
	private String sEssentialYN;

	/**
	 * @return the sCovNm
	 */
	public String getsCovNm() {
		return sCovNm;
	}

	/**
	 * @param sCovNm the sCovNm to set
	 */
	public void setsCovNm(final String sCovNm) {
		this.sCovNm = sCovNm;
	}

	/**
	 * @return the sCoverType
	 */
	public String getsCoverType() {
		return sCoverType;
	}

	/**
	 * @param sCoverType the sCoverType to set
	 */
	public void setsCoverType(final String sCoverType) {
		this.sCoverType = sCoverType;
	}

	/**
	 * @return the sCovCod
	 */
	public String getsCovCod() {
		return sCovCod;
	}

	/**
	 * @param sCovCod the sCovCod to set
	 */
	public void setsCovCod(final String sCovCod) {
		this.sCovCod = sCovCod;
	}

	/**
	 * @return the sCoverName
	 */
	public String getsCoverName() {
		return sCoverName;
	}

	/**
	 * @param sCoverName the sCoverName to set
	 */
	public void setsCoverName(final String sCoverName) {
		this.sCoverName = sCoverName;
	}

	/**
	 * @return the nEtnAmta
	 */
	public String getnEtnAmta() {
		return nEtnAmta;
	}

	/**
	 * @param nEtnAmta the nEtnAmta to set
	 */
	public void setnEtnAmta(final String nEtnAmta) {
		this.nEtnAmta = nEtnAmta;
	}

	/**
	 * @return the nEtnAmtb
	 */
	public String getnEtnAmtb() {
		return nEtnAmtb;
	}

	/**
	 * @param nEtnAmtb the nEtnAmtb to set
	 */
	public void setnEtnAmtb(final String nEtnAmtb) {
		this.nEtnAmtb = nEtnAmtb;
	}

	/**
	 * @return the nEtnAmtc
	 */
	public String getnEtnAmtc() {
		return nEtnAmtc;
	}

	/**
	 * @param nEtnAmtc the nEtnAmtc to set
	 */
	public void setnEtnAmtc(final String nEtnAmtc) {
		this.nEtnAmtc = nEtnAmtc;
	}

	/**
	 * @return the sHanAmtA
	 */
	public String getsHanAmtA() {
		return sHanAmtA;
	}

	/**
	 * @param sHanAmtA the sHanAmtA to set
	 */
	public void setsHanAmtA(final String sHanAmtA) {
		this.sHanAmtA = sHanAmtA;
	}

	/**
	 * @return the sHanAmtB
	 */
	public String getsHanAmtB() {
		return sHanAmtB;
	}

	/**
	 * @param sHanAmtB the sHanAmtB to set
	 */
	public void setsHanAmtB(final String sHanAmtB) {
		this.sHanAmtB = sHanAmtB;
	}

	/**
	 * @return the sHanAmtC
	 */
	public String getsHanAmtC() {
		return sHanAmtC;
	}

	/**
	 * @param sHanAmtC the sHanAmtC to set
	 */
	public void setsHanAmtC(final String sHanAmtC) {
		this.sHanAmtC = sHanAmtC;
	}

	/**
	 * @return the sEssentialYN
	 */
	public String getsEssentialYN() {
		return sEssentialYN;
	}

	/**
	 * @param sEssentialYN the sEssentialYN to set
	 */
	public void setsEssentialYN(final String sEssentialYN) {
		this.sEssentialYN = sEssentialYN;
	}

}
