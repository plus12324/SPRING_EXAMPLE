/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �ڵ��� - �������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insCarPayListDTO")
public class InsCarPayListDTO {
	/** 	ȸ��	 **/ 
	private String 	nPayNo;
	/** 	�ش��	 **/ 
	private String 	sPayDate;
	/** 	���Ի���	 **/
	private String 	sPayYN;
	/** 	��������	 **/
	private String 	sRectDate;
	/** 	�������	 **/ 
	private String 	sPayType;
	/** 	���Ժ����	 **/ 
	private String 	nRectPrem;
	/**		����		**/ 
	private String nOrder;
	
	public String getnOrder() {
		return nOrder;
	}
	public void setnOrder(String nOrder) {
		this.nOrder = nOrder;
	}
	/**
	 * @return the nPayNo
	 */
	public String getnPayNo() {
		return nPayNo;
	}
	/**
	 * @param nPayNo the nPayNo to set
	 */
	public void setnPayNo(String nPayNo) {
		this.nPayNo = nPayNo;
	}
	/**
	 * @return the sPayDate
	 */
	public String getsPayDate() {
		return sPayDate;
	}
	/**
	 * @param sPayDate the sPayDate to set
	 */
	public void setsPayDate(String sPayDate) {
		this.sPayDate = sPayDate;
	}
	/**
	 * @return the sPayYN
	 */
	public String getsPayYN() {
		return sPayYN;
	}
	/**
	 * @param sPayYN the sPayYN to set
	 */
	public void setsPayYN(String sPayYN) {
		this.sPayYN = sPayYN;
	}
	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}
	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(String sRectDate) {
		this.sRectDate = sRectDate;
	}
	/**
	 * @return the sPayType
	 */
	public String getsPayType() {
		return sPayType;
	}
	/**
	 * @param sPayType the sPayType to set
	 */
	public void setsPayType(String sPayType) {
		this.sPayType = sPayType;
	}
	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}
	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}
	
	
}
