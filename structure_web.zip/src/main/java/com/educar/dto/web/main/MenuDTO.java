/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.main;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

import org.springframework.web.multipart.MultipartFile;

/**
 * �޴��� �Ӽ��� ������ �ִ� DTO
 * �� �޴����� ���ȴ�, Mobile�� ���� ���� �ʿ� �� ��
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "menuDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class MenuDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ **/
	private Long nSeq;
	/** �޴��� ����, A,B,C,D .... **/
	private String sMenuType;
	/** �޴� Ŭ�� ��, �̵� url **/
	private String sForwardURL;
	/** �޴��� ��׶��� �̹��� url link **/
	private String sImageLinkURL;
	/** �޴��� display text **/
	private String sText;
	/** �޴��� alt �޼��� **/
	private String sMessage;
	/** �޴��� display ���� 1 to n **/
	@ValidateLength(type = TypeEnum.NUMBER, required = true)
	private int nOrder;
	/** �������� Y: ����, N: ����� **/
	private String sViewYn;
	/** ������¥ **/
	private String sOpenDate;
	/** ������ **/
	private String sRegId;
	/** ������ **/
	private String sUpId;

	/** �޴� ����Ʈ(�����ڿ��� ���) **/
	@XmlTransient
	private List<MenuDTO> menuList;
	/** �̹��� ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile sImageFile;
	/** üũ�� (�����ڿ��� ������ ���) **/
	@XmlTransient
	private String checkValue;

	/**
	 * @return the nSeq
	 */
	public Long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}

	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(final String sMessage) {
		this.sMessage = sMessage;
	}

	/**
	 * @return the sMenuType
	 */
	public String getsMenuType() {
		return sMenuType;
	}

	/**
	 * @return the sForwardURL
	 */
	public String getsForwardURL() {
		return sForwardURL;
	}

	/**
	 * @return the sImageLinkURL
	 */
	public String getsImageLinkURL() {
		return sImageLinkURL;
	}

	/**
	 * @return the sText
	 */
	public String getsText() {
		return sText;
	}

	/**
	 * @return the nOrder
	 */
	public int getnOrder() {
		return nOrder;
	}

	/**
	 * @param sMenuType the sMenuType to set
	 */
	public void setsMenuType(final String sMenuType) {
		this.sMenuType = sMenuType;
	}

	/**
	 * @param sForwardURL the sForwardURL to set
	 */
	public void setsForwardURL(final String sForwardURL) {
		this.sForwardURL = sForwardURL;
	}

	/**
	 * @param sImageLinkURL the sImageLinkURL to set
	 */
	public void setsImageLinkURL(final String sImageLinkURL) {
		this.sImageLinkURL = sImageLinkURL;
	}

	/**
	 * @param sText the sText to set
	 */
	public void setsText(final String sText) {
		this.sText = sText;
	}

	/**
	 * @param nOrder the nOrder to set
	 */
	public void setnOrder(final int nOrder) {
		this.nOrder = nOrder;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the menuList
	 */
	public List<MenuDTO> getMenuList() {
		return menuList;
	}

	/**
	 * @param menuList the menuList to set
	 */
	public void setMenuList(final List<MenuDTO> menuList) {
		this.menuList = menuList;
	}

	/**
	 * @return the sImageFile
	 */
	public MultipartFile getsImageFile() {
		return sImageFile;
	}

	/**
	 * @param sImageFile the sImageFile to set
	 */
	public void setsImageFile(final MultipartFile sImageFile) {
		this.sImageFile = sImageFile;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the checkValue
	 */
	public String getCheckValue() {
		return checkValue;
	}

	/**
	 * @param checkValue the checkValue to set
	 */
	public void setCheckValue(final String checkValue) {
		this.checkValue = checkValue;
	}

}
