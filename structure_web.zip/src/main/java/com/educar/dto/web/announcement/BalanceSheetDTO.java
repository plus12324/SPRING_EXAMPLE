/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.announcement;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ��������ǥ ��ȸ�� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement(name = "balanceSheetDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class BalanceSheetDTO extends PageDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** ��ϼ��� **/
	private String nSeq;
	/** ������� **/
	private String sCreateDate;
	/** ����ξ��̵� **/
	private String sCreateId;
	/** ��Ͻð� **/
	private String sCreateTime;
	/** ���ϸ� **/
	private String sFileNm;
	/** ���ϰ�� **/
	private String sFilePath;
	/** �������ϰ�� **/
	private String sFileRealPath;
	/** ��ȯ���ϸ� **/
	private String sFileStrNm;
	/** ���� **/
	private String sTitle;
	/** �������� **/
	private String sUpdateDate;
	/** �����ξ��̵� **/
	private String sUpdateId;
	/** �����ð� **/
	private String sUpdateTime;
	/** �������� **/
	private String sViewYn;
	/** �⵵ **/
	private String sYear;

	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}

	/**
	 * @return the sCreateDate
	 */
	public String getsCreateDate() {
		return sCreateDate;
	}

	/**
	 * @return the sCreateId
	 */
	public String getsCreateId() {
		return sCreateId;
	}

	/**
	 * @return the sCreateTime
	 */
	public String getsCreateTime() {
		return sCreateTime;
	}

	/**
	 * @return the sFileNm
	 */
	public String getsFileNm() {
		return sFileNm;
	}

	/**
	 * @return the sFilePath
	 */
	public String getsFilePath() {
		return sFilePath;
	}

	/**
	 * @return the sFileRealPath
	 */
	public String getsFileRealPath() {
		return sFileRealPath;
	}

	/**
	 * @return the sFileStrNm
	 */
	public String getsFileStrNm() {
		return sFileStrNm;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @return the sUpdateDate
	 */
	public String getsUpdateDate() {
		return sUpdateDate;
	}

	/**
	 * @return the sUpdateId
	 */
	public String getsUpdateId() {
		return sUpdateId;
	}

	/**
	 * @return the sUpdateTime
	 */
	public String getsUpdateTime() {
		return sUpdateTime;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final String nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @param sCreateDate the sCreateDate to set
	 */
	public void setsCreateDate(final String sCreateDate) {
		this.sCreateDate = sCreateDate;
	}

	/**
	 * @param sCreateId the sCreateId to set
	 */
	public void setsCreateId(final String sCreateId) {
		this.sCreateId = sCreateId;
	}

	/**
	 * @param sCreateTime the sCreateTime to set
	 */
	public void setsCreateTime(final String sCreateTime) {
		this.sCreateTime = sCreateTime;
	}

	/**
	 * @param sFileNm the sFileNm to set
	 */
	public void setsFileNm(final String sFileNm) {
		this.sFileNm = sFileNm;
	}

	/**
	 * @param sFilePath the sFilePath to set
	 */
	public void setsFilePath(final String sFilePath) {
		this.sFilePath = sFilePath;
	}

	/**
	 * @param sFileRealPath the sFileRealPath to set
	 */
	public void setsFileRealPath(final String sFileRealPath) {
		this.sFileRealPath = sFileRealPath;
	}

	/**
	 * @param sFileStrNm the sFileStrNm to set
	 */
	public void setsFileStrNm(final String sFileStrNm) {
		this.sFileStrNm = sFileStrNm;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @param sUpdateDate the sUpdateDate to set
	 */
	public void setsUpdateDate(final String sUpdateDate) {
		this.sUpdateDate = sUpdateDate;
	}

	/**
	 * @param sUpdateId the sUpdateId to set
	 */
	public void setsUpdateId(final String sUpdateId) {
		this.sUpdateId = sUpdateId;
	}

	/**
	 * @param sUpdateTime the sUpdateTime to set
	 */
	public void setsUpdateTime(final String sUpdateTime) {
		this.sUpdateTime = sUpdateTime;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

}
