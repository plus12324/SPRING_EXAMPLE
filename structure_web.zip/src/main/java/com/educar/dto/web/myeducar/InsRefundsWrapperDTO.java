/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insRefundsWrapperDTO")
public class InsRefundsWrapperDTO {
	private InsRefundsCrDataDTO crData;
	
	private InsRefundsExtRtnAmtDTO extRtnAmtData;
	
	private List<InsRefundsExtRtnAmtDTO> extRtnAmtList;

	/**
	 * @return the crData
	 */
	public InsRefundsCrDataDTO getCrData() {
		return crData;
	}

	/**
	 * @param crData the crData to set
	 */
	public void setCrData(InsRefundsCrDataDTO crData) {
		this.crData = crData;
	}

	/**
	 * @return the extRtnAmtData
	 */
	public InsRefundsExtRtnAmtDTO getExtRtnAmtData() {
		return extRtnAmtData;
	}

	/**
	 * @param extRtnAmtData the extRtnAmtData to set
	 */
	public void setExtRtnAmtData(InsRefundsExtRtnAmtDTO extRtnAmtData) {
		this.extRtnAmtData = extRtnAmtData;
	}

	/**
	 * @return the extRtnAmtList
	 */
	public List<InsRefundsExtRtnAmtDTO> getExtRtnAmtList() {
		return extRtnAmtList;
	}

	/**
	 * @param extRtnAmtList the extRtnAmtList to set
	 */
	public void setExtRtnAmtList(List<InsRefundsExtRtnAmtDTO> extRtnAmtList) {
		this.extRtnAmtList = extRtnAmtList;
	}
	
}
