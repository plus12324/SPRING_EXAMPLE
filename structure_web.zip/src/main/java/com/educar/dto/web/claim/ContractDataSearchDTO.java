/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���谡����(�Ǻ�����)�� ������ ��ȸ DTO
 * @author ������
 * @since 1.1.0
 */
@XmlRootElement(name = "contractDataSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContractDataSearchDTO {
	/** ���Type **/
	private String sPolicyType;
	/** ���⵵ **/
	private String sPolicyYM;
	/** ����ȣ **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ������� �����(yyyyMMdd) **/
	private String sAcctDate;
	/** ����Ͻ� �ú�(HHmm) **/
	private String sAcctTime;

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctTime
	 */
	public String getsAcctTime() {
		return sAcctTime;
	}

	/**
	 * @param sAcctTime the sAcctTime to set
	 */
	public void setsAcctTime(final String sAcctTime) {
		this.sAcctTime = sAcctTime;
	}

}
