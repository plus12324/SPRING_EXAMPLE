/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.AgreeDTO;

/**
 * ������ ���� ��� DTO
 * @author ������
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfTripWrapperDTO")
public class CalculationOfTripWrapperDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** GENAA01 **/
	private CalculationOfGENAA01DTO GENAA01;
	/** GENAA02 **/
	private CalculationOfGENAA02DTO GENAA02;
	/** GENAA16 **/
	private CalculationOfGENAA16DTO GENAA16;
	/** GENAA31 **/
	private CalculationOfGENAA31DTO GENAA31;
	/** GENAA36 **/
	private CalculationOfGENAA36DTO GENAA36;
	/** GENAA11 **/
	private CalculationOfGENAA11DTO GENAA11;
	/** �Է� ���� �ܰ� */
	private Integer inputFinalStep;
	/** ��� ���� ���� **/
	private AgreeDTO Agree;
	/** TODO : ����ó�� �ؾ� ��, ������ǽ� ����ϴ� �ֹι�ȣ **/
	private String sCustNo;

	/**
	 * @return the gENAA01
	 */
	public CalculationOfGENAA01DTO getGENAA01() {
		return GENAA01;
	}

	/**
	 * @param gENAA01 the gENAA01 to set
	 */
	public void setGENAA01(final CalculationOfGENAA01DTO gENAA01) {
		GENAA01 = gENAA01;
	}

	/**
	 * @return the gENAA02
	 */
	public CalculationOfGENAA02DTO getGENAA02() {
		return GENAA02;
	}

	/**
	 * @param gENAA02 the gENAA02 to set
	 */
	public void setGENAA02(final CalculationOfGENAA02DTO gENAA02) {
		GENAA02 = gENAA02;
	}

	/**
	 * @return the gENAA16
	 */
	public CalculationOfGENAA16DTO getGENAA16() {
		return GENAA16;
	}

	/**
	 * @param gENAA16 the gENAA16 to set
	 */
	public void setGENAA16(final CalculationOfGENAA16DTO gENAA16) {
		GENAA16 = gENAA16;
	}

	/**
	 * @return the gENAA31
	 */
	public CalculationOfGENAA31DTO getGENAA31() {
		return GENAA31;
	}

	/**
	 * @param gENAA31 the gENAA31 to set
	 */
	public void setGENAA31(final CalculationOfGENAA31DTO gENAA31) {
		GENAA31 = gENAA31;
	}

	/**
	 * @return the gENAA36
	 */
	public CalculationOfGENAA36DTO getGENAA36() {
		return GENAA36;
	}

	/**
	 * @param gENAA36 the gENAA36 to set
	 */
	public void setGENAA36(final CalculationOfGENAA36DTO gENAA36) {
		GENAA36 = gENAA36;
	}

	/**
	 * @return the gENAA11
	 */
	public CalculationOfGENAA11DTO getGENAA11() {
		return GENAA11;
	}

	/**
	 * @param gENAA11 the gENAA11 to set
	 */
	public void setGENAA11(final CalculationOfGENAA11DTO gENAA11) {
		GENAA11 = gENAA11;
	}

	/**
	 * �Է� ���� �ܰ踦 ��ȯ�Ѵ�.
	 * @return �Է� ���� �ܰ�
	 */
	public Integer getInputFinalStep() {
		return inputFinalStep;
	}

	/**
	 * �Է� ���� �ܰ踦 �����Ѵ�.
	 * @param inputFinalStep �Է� ���� �ܰ�
	 */
	public void setInputFinalStep(final Integer inputFinalStep) {
		this.inputFinalStep = inputFinalStep;
	}

	/**
	 * @return the agree
	 */
	public AgreeDTO getAgree() {
		return Agree;
	}

	/**
	 * @param agree the agree to set
	 */
	public void setAgree(final AgreeDTO agree) {
		Agree = agree;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}
}
