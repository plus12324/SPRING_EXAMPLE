/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �ڵ��� - �������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insCarPoliInfoDTO")
public class InsCarPoliInfoDTO {
	/** 	����ȣ	 **/ 
	private String 	sPolicyNo;
	/** 	�����ǰ��	 **/ 
	private String 	sInsTypeName;
	/** 	����ȣ	 **/
	private String 	sPolicyNoForP;
	/** 	�����	 **/ 
	private String 	sPolHolderName;
	/** 	����ñ�	 **/ 
	private String 	sFmdt;
	/** 	��������	 **/ 
	private String 	sTodt;
	/** 	��ȸ�����	 **/
	private String 	sFirstRectPrem;
	/** 	���Թ��	 **/ 
	private String 	sPayClause;
	/** 	ī��/�������� - �����	 **/ 
	private String 	sBankName;
	/** 	ī��/�������� - ��������	 **/
	private String 	sAcctNo;
	/** 	ī��/�������� - ������	 **/ 
	private String 	sDepositerName;
	/** 	�ѳ��Ժ����	 **/ 
	private String 	nTotRectPrem;
	/** 	�������Կ�	 **/ 
	private String 	sPayInfo;
	/** 	�����輭��ȣ	 **/ 
	private String 	nEndorseNo;
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}
	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}
	/**
	 * @return the sPolicyNoForP
	 */
	public String getsPolicyNoForP() {
		return sPolicyNoForP;
	}
	/**
	 * @param sPolicyNoForP the sPolicyNoForP to set
	 */
	public void setsPolicyNoForP(String sPolicyNoForP) {
		this.sPolicyNoForP = sPolicyNoForP;
	}
	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}
	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}
	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}
	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}
	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	/**
	 * @return the sFirstRectPrem
	 */
	public String getsFirstRectPrem() {
		return sFirstRectPrem;
	}
	/**
	 * @param sFirstRectPrem the sFirstRectPrem to set
	 */
	public void setsFirstRectPrem(String sFirstRectPrem) {
		this.sFirstRectPrem = sFirstRectPrem;
	}
	/**
	 * @return the sPayClause
	 */
	public String getsPayClause() {
		return sPayClause;
	}
	/**
	 * @param sPayClause the sPayClause to set
	 */
	public void setsPayClause(String sPayClause) {
		this.sPayClause = sPayClause;
	}
	/**
	 * @return the sBankName
	 */
	public String getsBankName() {
		return sBankName;
	}
	/**
	 * @param sBankName the sBankName to set
	 */
	public void setsBankName(String sBankName) {
		this.sBankName = sBankName;
	}
	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}
	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}
	/**
	 * @return the sDepositerName
	 */
	public String getsDepositerName() {
		return sDepositerName;
	}
	/**
	 * @param sDepositerName the sDepositerName to set
	 */
	public void setsDepositerName(String sDepositerName) {
		this.sDepositerName = sDepositerName;
	}
	/**
	 * @return the nTotalPrem
	 */
	public String getnTotRectPrem() {
		return nTotRectPrem;
	}
	/**
	 * @param nTotalPrem the nTotalPrem to set
	 */
	public void setnTotRectPrem(String nTotRectPrem) {
		this.nTotRectPrem = nTotRectPrem;
	}
	/**
	 * @return the sPayInfo
	 */
	public String getsPayInfo() {
		return sPayInfo;
	}
	/**
	 * @param sPayInfo the sPayInfo to set
	 */
	public void setsPayInfo(String sPayInfo) {
		this.sPayInfo = sPayInfo;
	}
	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}
	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}
	
}
