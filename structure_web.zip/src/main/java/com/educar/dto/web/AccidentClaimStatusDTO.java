/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ó�� ��Ȳ ��ȸ ����/�ǰ����� ������Ȳ ����DTO
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "accidentClaimStatusDTO")
public class AccidentClaimStatusDTO {
	/** �����ȣ(������ȣ) **/
	private String sAcdNum;
	/** ����������� **/
	private String AcdRcpDate;
	/** �����ɻ����� **/
	private String sAcctInvDate;
	/** ����������� **/
	private String sCheckDate;
	/** ���޽ɻ����� **/
	private String sLossCalcDate;
	/** �Ϸ����� **/
	private String sComDate;
	/** ����ڸ� **/
	private String sStaffName;
	/** ��ȭ��ȣ **/
	private String sCellTel;

	/**
	 * @return the sAcdNum
	 */
	public String getsAcdNum() {
		return sAcdNum;
	}

	/**
	 * @param sAcdNum the sAcdNum to set
	 */
	public void setsAcdNum(final String sAcdNum) {
		this.sAcdNum = sAcdNum;
	}

	/**
	 * @return the acdRcpDate
	 */
	public String getAcdRcpDate() {
		return AcdRcpDate;
	}

	/**
	 * @param acdRcpDate the acdRcpDate to set
	 */
	public void setAcdRcpDate(final String acdRcpDate) {
		AcdRcpDate = acdRcpDate;
	}

	/**
	 * @return the sAcctInvDate
	 */
	public String getsAcctInvDate() {
		return sAcctInvDate;
	}

	/**
	 * @param sAcctInvDate the sAcctInvDate to set
	 */
	public void setsAcctInvDate(final String sAcctInvDate) {
		this.sAcctInvDate = sAcctInvDate;
	}

	/**
	 * @return the sCheckDate
	 */
	public String getsCheckDate() {
		return sCheckDate;
	}

	/**
	 * @param sCheckDate the sCheckDate to set
	 */
	public void setsCheckDate(final String sCheckDate) {
		this.sCheckDate = sCheckDate;
	}

	/**
	 * @return the sLossCalcDate
	 */
	public String getsLossCalcDate() {
		return sLossCalcDate;
	}

	/**
	 * @param sLossCalcDate the sLossCalcDate to set
	 */
	public void setsLossCalcDate(final String sLossCalcDate) {
		this.sLossCalcDate = sLossCalcDate;
	}

	/**
	 * @return the sComDate
	 */
	public String getsComDate() {
		return sComDate;
	}

	/**
	 * @param sComDate the sComDate to set
	 */
	public void setsComDate(final String sComDate) {
		this.sComDate = sComDate;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sCellTel
	 */
	public String getsCellTel() {
		return sCellTel;
	}

	/**
	 * @param sCellTel the sCellTel to set
	 */
	public void setsCellTel(final String sCellTel) {
		this.sCellTel = sCellTel;
	}

}
