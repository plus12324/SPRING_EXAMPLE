/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���/�������� ��ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "autoInfoCommonResultDTO")
public class AutoInfoCommonResultDTO {
	/** �����ڵ� **/
	private String sErrorCode;
	/** �������� **/
	private String sAcctKind;
	/** ���������� **/
	private String sCmMetdNm;
	/** ���Թ�� **/
	private String PaymCyclNm;
	/** �����ָ� / ī������ڸ� **/
	private String sDpsrName;
	/** ���� **/
	private String sBankNm;
	/** ���¹�ȣ / ī���ȣ **/
	private String sAcctNo;
	/** ī����ȿ�Ⱓ **/
	private String sCardValdYearMnth;
	/** ������� **/
	private String sAcctType;
	/** ������ֹι�ȣ **/
	private String sCrtorCd;
	/** ����ڸ� **/
	private String sCrtorName;
	/** �������ֹι�ȣ **/
	private String sDpsrCd;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sAcctKind
	 */
	public String getsAcctKind() {
		return sAcctKind;
	}

	/**
	 * @param sAcctKind the sAcctKind to set
	 */
	public void setsAcctKind(final String sAcctKind) {
		this.sAcctKind = sAcctKind;
	}

	/**
	 * @return the sCmMetdNm
	 */
	public String getsCmMetdNm() {
		return sCmMetdNm;
	}

	/**
	 * @param sCmMetdNm the sCmMetdNm to set
	 */
	public void setsCmMetdNm(final String sCmMetdNm) {
		this.sCmMetdNm = sCmMetdNm;
	}

	/**
	 * @return the paymCyclNm
	 */
	public String getPaymCyclNm() {
		return PaymCyclNm;
	}

	/**
	 * @param paymCyclNm the paymCyclNm to set
	 */
	public void setPaymCyclNm(final String paymCyclNm) {
		PaymCyclNm = paymCyclNm;
	}

	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}

	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(final String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}

	/**
	 * @return the sBankNm
	 */
	public String getsBankNm() {
		return sBankNm;
	}

	/**
	 * @param sBankNm the sBankNm to set
	 */
	public void setsBankNm(final String sBankNm) {
		this.sBankNm = sBankNm;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sCardValdYearMnth
	 */
	public String getsCardValdYearMnth() {
		return sCardValdYearMnth;
	}

	/**
	 * @param sCardValdYearMnth the sCardValdYearMnth to set
	 */
	public void setsCardValdYearMnth(final String sCardValdYearMnth) {
		this.sCardValdYearMnth = sCardValdYearMnth;
	}

	/**
	 * @return the sAcctType
	 */
	public String getsAcctType() {
		return sAcctType;
	}

	/**
	 * @param sAcctType the sAcctType to set
	 */
	public void setsAcctType(final String sAcctType) {
		this.sAcctType = sAcctType;
	}

	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}

	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(final String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}

	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}

	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(final String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}

	/**
	 * @return the sDpsrCd
	 */
	public String getsDpsrCd() {
		return sDpsrCd;
	}

	/**
	 * @param sDpsrCd the sDpsrCd to set
	 */
	public void setsDpsrCd(final String sDpsrCd) {
		this.sDpsrCd = sDpsrCd;
	}

}
