/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.company;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ȫ���� - �μⱤ�� DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "printAdDTO")
public class PrintAdDTO extends PageDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ */
	private int nSeq;
	/** ���� */
	private String sTitle;
	/** ���� */
	private String sContent;
	/** �������� */
	private String sViewYn;
	/** ������¥ */
	private String sOpenDate;
	/** ������ */
	private String sRegId;
	/** ������¥ */
	private String sRegDate;
	/** �����ð� */
	private String sRegTime;
	/** ������ */
	private String sUpId;
	/** ������¥ */
	private String sUpDate;
	/** �����ð� */
	private String sUpTime;
	/** ���� ���� �̸� */
	private String sFileNm;
	/** ���� ��� */
	private String sFilePath;
	/** ���� ������ �̸� */
	private String sFileStrNm;
	/** ���� ���� ���*/
	private String sFileRealPath;

	/**
	 * @return the nSeq
	 */
	public int getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final int nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}

	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(final String sContent) {
		this.sContent = sContent;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}

	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(final String sUpDate) {
		this.sUpDate = sUpDate;
	}

	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}

	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(final String sUpTime) {
		this.sUpTime = sUpTime;
	}

	/**
	 * @return the sFileNm
	 */
	public String getsFileNm() {
		return sFileNm;
	}

	/**
	 * @param sFileNm the sFileNm to set
	 */
	public void setsFileNm(final String sFileNm) {
		this.sFileNm = sFileNm;
	}

	/**
	 * @return the sFilePath
	 */
	public String getsFilePath() {
		return sFilePath;
	}

	/**
	 * @param sFilePath the sFilePath to set
	 */
	public void setsFilePath(final String sFilePath) {
		this.sFilePath = sFilePath;
	}

	/**
	 * @return the sFileStrNm
	 */
	public String getsFileStrNm() {
		return sFileStrNm;
	}

	/**
	 * @param sFileStrNm the sFileStrNm to set
	 */
	public void setsFileStrNm(final String sFileStrNm) {
		this.sFileStrNm = sFileStrNm;
	}

	/**
	 * @return the sFileRealPath
	 */
	public String getsFileRealPath() {
		return sFileRealPath;
	}

	/**
	 * @param sFileRealPath the sFileRealPath to set
	 */
	public void setsFileRealPath(final String sFileRealPath) {
		this.sFileRealPath = sFileRealPath;
	}
}
