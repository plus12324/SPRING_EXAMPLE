/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �Ⱓ�� Call ��ǰ�Ұ� �����̿� �� ��������
 * @author ������
 * @since 0.0.10
 */
public class CUSAA0441InfoDTO {
	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	/** �����̿뵿�� ( "Y:����, N:�ź�) **/
	private String sCUSAA04AgmYn = "N";
	/** �����̿뵿�� ( "Y:����, N:�ź�) **/
	private String sCUSAA41AgmYn = "N";
	/** �������� Ȱ�뵿�� �Է� ����	**/
	private String custUse;
	
	private String sUserID;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sCUSAA04AgmYn
	 */
	public String getsCUSAA04AgmYn() {
		return sCUSAA04AgmYn;
	}

	/**
	 * @param sCUSAA04AgmYn the sCUSAA04AgmYn to set
	 */
	public void setsCUSAA04AgmYn(final String sCUSAA04AgmYn) {
		this.sCUSAA04AgmYn = sCUSAA04AgmYn;
	}

	/**
	 * @return the sCUSAA41AgmYn
	 */
	public String getsCUSAA41AgmYn() {
		return sCUSAA41AgmYn;
	}

	/**
	 * @param sCUSAA41AgmYn the sCUSAA41AgmYn to set
	 */
	public void setsCUSAA41AgmYn(final String sCUSAA41AgmYn) {
		this.sCUSAA41AgmYn = sCUSAA41AgmYn;
	}

	/**
	 * @return the custUse
	 */
	public String getCustUse() {
		return custUse;
	}

	/**
	 * @param custUse the custUse to set
	 */
	public void setCustUse(String custUse) {
		this.custUse = custUse;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
}
