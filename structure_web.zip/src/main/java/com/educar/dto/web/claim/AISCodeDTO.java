/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ���� - ���ܸ� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AISCodeDTO {
	/** ���غ��� **/
	private String sInjrPartNm;
	/** ���ܸ� **/
	private String sAisName;
	/** �λ�޼� **/
	private String sInjrGrade;
	/** �λ��׸� **/
	private String sInjrClause;
	/** AIS-CODE **/
	private String sAisCode;
	/** å���ѵ� **/
	private String nCmLimitAmt;
	/** �ڼ��ѵ� **/
	private String nCiaLimitAmt;

	/**
	 * @return the sInjrPartNm
	 */
	public String getsInjrPartNm() {
		return sInjrPartNm;
	}

	/**
	 * @param sInjrPartNm the sInjrPartNm to set
	 */
	public void setsInjrPartNm(final String sInjrPartNm) {
		this.sInjrPartNm = sInjrPartNm;
	}

	/**
	 * @return the sAisName
	 */
	public String getsAisName() {
		return sAisName;
	}

	/**
	 * @param sAisName the sAisName to set
	 */
	public void setsAisName(final String sAisName) {
		this.sAisName = sAisName;
	}

	/**
	 * @return the sInjrGrade
	 */
	public String getsInjrGrade() {
		return sInjrGrade;
	}

	/**
	 * @param sInjrGrade the sInjrGrade to set
	 */
	public void setsInjrGrade(final String sInjrGrade) {
		this.sInjrGrade = sInjrGrade;
	}

	/**
	 * @return the sInjrClause
	 */
	public String getsInjrClause() {
		return sInjrClause;
	}

	/**
	 * @param sInjrClause the sInjrClause to set
	 */
	public void setsInjrClause(final String sInjrClause) {
		this.sInjrClause = sInjrClause;
	}

	/**
	 * @return the sAisCode
	 */
	public String getsAisCode() {
		return sAisCode;
	}

	/**
	 * @param sAisCode the sAisCode to set
	 */
	public void setsAisCode(final String sAisCode) {
		this.sAisCode = sAisCode;
	}

	/**
	 * @return the nCmLimitAmt
	 */
	public String getnCmLimitAmt() {
		return nCmLimitAmt;
	}

	/**
	 * @param nCmLimitAmt the nCmLimitAmt to set
	 */
	public void setnCmLimitAmt(final String nCmLimitAmt) {
		this.nCmLimitAmt = nCmLimitAmt;
	}

	/**
	 * @return the nCiaLimitAmt
	 */
	public String getnCiaLimitAmt() {
		return nCiaLimitAmt;
	}

	/**
	 * @param nCiaLimitAmt the nCiaLimitAmt to set
	 */
	public void setnCiaLimitAmt(final String nCiaLimitAmt) {
		this.nCiaLimitAmt = nCiaLimitAmt;
	}

}
