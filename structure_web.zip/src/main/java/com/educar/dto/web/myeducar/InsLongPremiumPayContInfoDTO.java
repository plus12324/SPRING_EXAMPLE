/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insLongPremiumPayContInfoDTO")
public class InsLongPremiumPayContInfoDTO {
	/** 	����ȣ	 **/ 
	private String 	sCrNo;
	/** 	��ǰ��	 **/ 
	private String 	sGdCdName;
	/** 	�����	 **/ 
	private String 	sCrtorName;
	/** 	������۱Ⱓ	 **/ 
	private String 	sInsurStrtdate;
	/** 	��������Ⱓ	 **/ 
	private String 	sInsurEndDate;
	/** 	1ȸ�����	 **/ 
	private String 	nApplPrem;
	/** 	�����ֱ�	 **/
	private String 	sPaymCyclCdName;
	/** 	���Թ��	 **/ 
	private String 	sCmMetdName;
	/** 	��ü��	 **/ 
	private String 	sTrnInfo;
	/** 	�������Կ���	 **/ 
	private String 	sFinalPaymMthy;
	/** 	��������Ƚ��	 **/ 
	private String 	nFinalPaymSeq;
	/** 	ī��/��������	 **/ 
	private String 	sAcctNo;
	/** 	ī��/��������	 **/ 
	private String 	sBankCdName;
	/** 	ī��/��������	 **/ 
	private String 	sDpsrName;
	/** 	�ѳ��Ժ����	 **/ 
	private String 	nPaymPremSum;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sGdCdName
	 */
	public String getsGdCdName() {
		return sGdCdName;
	}
	/**
	 * @param sGdCdName the sGdCdName to set
	 */
	public void setsGdCdName(String sGdCdName) {
		this.sGdCdName = sGdCdName;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}
	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}
	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}
	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}
	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}
	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}
	/**
	 * @return the sPaymCyclCdName
	 */
	public String getsPaymCyclCdName() {
		return sPaymCyclCdName;
	}
	/**
	 * @param sPaymCyclCdName the sPaymCyclCdName to set
	 */
	public void setsPaymCyclCdName(String sPaymCyclCdName) {
		this.sPaymCyclCdName = sPaymCyclCdName;
	}
	/**
	 * @return the sCmMetdName
	 */
	public String getsCmMetdName() {
		return sCmMetdName;
	}
	/**
	 * @param sCmMetdName the sCmMetdName to set
	 */
	public void setsCmMetdName(String sCmMetdName) {
		this.sCmMetdName = sCmMetdName;
	}
	/**
	 * @return the sTrnInfo
	 */
	public String getsTrnInfo() {
		return sTrnInfo;
	}
	/**
	 * @param sTrnInfo the sTrnInfo to set
	 */
	public void setsTrnInfo(String sTrnInfo) {
		this.sTrnInfo = sTrnInfo;
	}
	/**
	 * @return the sFinalPaymMthy
	 */
	public String getsFinalPaymMthy() {
		return sFinalPaymMthy;
	}
	/**
	 * @param sFinalPaymMthy the sFinalPaymMthy to set
	 */
	public void setsFinalPaymMthy(String sFinalPaymMthy) {
		this.sFinalPaymMthy = sFinalPaymMthy;
	}
	/**
	 * @return the nFinalPaymSeq
	 */
	public String getnFinalPaymSeq() {
		return nFinalPaymSeq;
	}
	/**
	 * @param nFinalPaymSeq the nFinalPaymSeq to set
	 */
	public void setnFinalPaymSeq(String nFinalPaymSeq) {
		this.nFinalPaymSeq = nFinalPaymSeq;
	}
	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}
	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}
	/**
	 * @return the sBankCdName
	 */
	public String getsBankCdName() {
		return sBankCdName;
	}
	/**
	 * @param sBankCdName the sBankCdName to set
	 */
	public void setsBankCdName(String sBankCdName) {
		this.sBankCdName = sBankCdName;
	}
	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}
	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}
	/**
	 * @return the nPaymPremSum
	 */
	public String getnPaymPremSum() {
		return nPaymPremSum;
	}
	/**
	 * @param nPaymPremSum the nPaymPremSum to set
	 */
	public void setnPaymPremSum(String nPaymPremSum) {
		this.nPaymPremSum = nPaymPremSum;
	}
	
	
	
}
