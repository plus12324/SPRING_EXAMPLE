/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;

/**
 * ī�� ����Ʈ ��ȸ�� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cardPointRequestDTO")
public class CardPointRequestDTO {

	/** ī���ȣ **/
	private String sCardNo;
	/** ��ȿ�Ⱓ **/
	@ValidateDate(dateFormat = DateFormat.yyyyMM)
	private String sValidThru;
	/**
	 * ����Ʈ���� 00:���ƴ�, 10:�Ϲ� BC Toppoint, 11:���BC Topoint,
	 * 20:��ȯ��������Ʈ, 30:��ȯ YES,
	 * 40:���̺�����Ʈ(�Ｚ,��ȯ���̼��̺�, ����)
	 */
	private String sPointCardType;
	/** ī����ڵ� **/
	private String sCardCom;
	/** ���ο�û�ݾ� **/
	private String nReqAmt;
	/** ī�������ID, �ֹι�ȣ �Ǵ� ����ڹ�ȣ **/
	private String sCardOwnerID;
	/** VAN�� �ڵ� N���� ����**/
	private String sVanCode = "N";
	/** ���� ������ ���Ե� SessionNameEnum �� **/
	private String sessionName;
	
	/** ī���ȣ1 **/
	private String sCardNo1;
	/** ī���ȣ2 **/
	private String sCardNo2;
	/** ī���ȣ3 **/
	private String sCardNo3;
	/** ī���ȣ4 **/
	private String sCardNo4;
	/** Ű���庸�� ��ȣȭ Key **/
	private String sHid_key_data;
	/**
	 * @return the sCardNo
	 */
	public String getsCardNo() {
		return sCardNo;
	}

	/**
	 * @return the sValidThru
	 */
	public String getsValidThru() {
		return sValidThru;
	}

	/**
	 * @return the sPointCardType
	 */
	public String getsPointCardType() {
		return sPointCardType;
	}

	/**
	 * @return the sCardCom
	 */
	public String getsCardCom() {
		return sCardCom;
	}

	/**
	 * @return the nReqAmt
	 */
	public String getnReqAmt() {
		return nReqAmt;
	}

	/**
	 * @return the sCardOwnerID
	 */
	public String getsCardOwnerID() {
		return sCardOwnerID;
	}

	/**
	 * @return the sVanCode
	 */
	public String getsVanCode() {
		return sVanCode;
	}

	/**
	 * @param sCardNo the sCardNo to set
	 */
	public void setsCardNo(final String sCardNo) {
		this.sCardNo = sCardNo;
	}

	/**
	 * @param sValidThru the sValidThru to set
	 */
	public void setsValidThru(final String sValidThru) {
		this.sValidThru = sValidThru;
	}

	/**
	 * @param sPointCardType the sPointCardType to set
	 */
	public void setsPointCardType(final String sPointCardType) {
		this.sPointCardType = sPointCardType;
	}

	/**
	 * @param sCardCom the sCardCom to set
	 */
	public void setsCardCom(final String sCardCom) {
		this.sCardCom = sCardCom;
	}

	/**
	 * @param nReqAmt the nReqAmt to set
	 */
	public void setnReqAmt(final String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}

	/**
	 * @param sCardOwnerID the sCardOwnerID to set
	 */
	public void setsCardOwnerID(final String sCardOwnerID) {
		this.sCardOwnerID = sCardOwnerID;
	}

	/**
	 * @param sVanCode the sVanCode to set
	 */
	public void setsVanCode(final String sVanCode) {
		this.sVanCode = sVanCode;
	}

	/**
	 * @return the sessionName
	 */
	public String getSessionName() {
		return sessionName;
	}

	/**
	 * @param sessionName the sessionName to set
	 */
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	/**
	 * @return the sCardNo1
	 */
	public String getsCardNo1() {
		return sCardNo1;
	}

	/**
	 * @param sCardNo1 the sCardNo1 to set
	 */
	public void setsCardNo1(String sCardNo1) {
		this.sCardNo1 = sCardNo1;
	}

	/**
	 * @return the sCardNo2
	 */
	public String getsCardNo2() {
		return sCardNo2;
	}

	/**
	 * @param sCardNo2 the sCardNo2 to set
	 */
	public void setsCardNo2(String sCardNo2) {
		this.sCardNo2 = sCardNo2;
	}

	/**
	 * @return the sCardNo3
	 */
	public String getsCardNo3() {
		return sCardNo3;
	}

	/**
	 * @param sCardNo3 the sCardNo3 to set
	 */
	public void setsCardNo3(String sCardNo3) {
		this.sCardNo3 = sCardNo3;
	}

	/**
	 * @return the sCardNo4
	 */
	public String getsCardNo4() {
		return sCardNo4;
	}

	/**
	 * @param sCardNo4 the sCardNo4 to set
	 */
	public void setsCardNo4(String sCardNo4) {
		this.sCardNo4 = sCardNo4;
	}

	/**
	 * @return the sHid_key_data
	 */
	public String getsHid_key_data() {
		return sHid_key_data;
	}

	/**
	 * @param sHid_key_data the sHid_key_data to set
	 */
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}


	
}
