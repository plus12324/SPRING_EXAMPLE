/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * <pre>
 * ����� ü�ᵿ�� 35�� �Է� DTO
 * ���νſ���������
 * </pre>
 * @author ������
 * @since 0.0.10
 */
public class PriInfoAgreeDTO {
	/** û���ȣ **/
	String sApplyNo;
	/** �ֹε�Ϲ�ȣ **/
	String sCustNo;
	/** �����, �Ǻ����� ���� (01:�����, 02:�Ǻ�����) **/
	String sCustType;
	/** �̸� **/
	String sName;
	/** ���� ����(Y: ����) **/
	String sAgmYn;

	/**
	 * @return the sApplyNo
	 */
	public String getsApplyNo() {
		return sApplyNo;
	}

	/**
	 * @param sApplyNo the sApplyNo to set
	 */
	public void setsApplyNo(final String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}

	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(final String sCustType) {
		this.sCustType = sCustType;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sAgmYn
	 */
	public String getsAgmYn() {
		return sAgmYn;
	}

	/**
	 * @param sAgmYn the sAgmYn to set
	 */
	public void setsAgmYn(final String sAgmYn) {
		this.sAgmYn = sAgmYn;
	}

}
