/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCntrDtlOfLtiea01PiboDTO")
public class SelectCntrDtlOfLtiea01PiboDTO {
	/** �Ǻ������ֹι�ȣ **/
	private String sInrpsCd;
	/** �Ǻ����ڸ� **/
	private String sInrpsName;

	/**
	 * @return the sInrpsCd
	 */
	public String getsInrpsCd() {
		return sInrpsCd;
	}

	/**
	 * @param sInrpsCd the sInrpsCd to set
	 */
	public void setsInrpsCd(final String sInrpsCd) {
		this.sInrpsCd = sInrpsCd;
	}

	/**
	 * @return the sInrpsName
	 */
	public String getsInrpsName() {
		return sInrpsName;
	}

	/**
	 * @param sInrpsName the sInrpsName to set
	 */
	public void setsInrpsName(final String sInrpsName) {
		this.sInrpsName = sInrpsName;
	}

}
