/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����ڹ��� ���/����/���� ���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "editDriverScopeResponseDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class EditDriverScopeResponseDTO {

	/** �����ڵ� **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** �����ڹ�������_���� **/
	private String sBefCodeName1;
	/** �����ڹ�������_���� **/
	private String sAftCodeName1;
	/** �����ڿ�������_���� **/
	private String sBefCodeName2;
	/** �����ڿ�������_���� **/
	private String sAftCodeName2;
	/** �÷���1��_���� **/
	private String sBefCodeName3;
	/** �÷���1��_���� **/
	private String sAftCodeName3;
	/** ���������     **/
	private String befTotPrem;
	/** �߰����κ���� **/
	private String befAddPrem;
	/** ȯ�޺����     **/
	private String befRefundPrem;
	/** ���������     **/
	private String aftTotPrem;
	/** �߰����κ���� **/
	private String aftAddPrem;
	/** ȯ�޺����     **/
	private String aftRefundPrem;

	/**
	 * @return the sError �����ڵ�
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @return the sApplyType �����ڵ�
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @return the sApplyYM û���ȣ����
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @return the sApplySer û���ȣ����
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @return the sEndorseFmdt1 û���ȣ�⵵
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @return the sBefCodeName1 û���ȣ�⵵
	 */
	public String getsBefCodeName1() {
		return sBefCodeName1;
	}

	/**
	 * @return the sAftCodeName1
	 */
	public String getsAftCodeName1() {
		return sAftCodeName1;
	}

	/**
	 * @return the sBefCodeName2
	 */
	public String getsBefCodeName2() {
		return sBefCodeName2;
	}

	/**
	 * @return the sAftCodeName2
	 */
	public String getsAftCodeName2() {
		return sAftCodeName2;
	}

	/**
	 * @return the sBefCodeName3
	 */
	public String getsBefCodeName3() {
		return sBefCodeName3;
	}

	/**
	 * @return the sAftCodeName3
	 */
	public String getsAftCodeName3() {
		return sAftCodeName3;
	}

	/**
	 * @return the befTotPrem
	 */
	public String getBefTotPrem() {
		return befTotPrem;
	}

	/**
	 * @return the befAddPrem
	 */
	public String getBefAddPrem() {
		return befAddPrem;
	}

	/**
	 * @return the befRefundPrem
	 */
	public String getBefRefundPrem() {
		return befRefundPrem;
	}

	/**
	 * @return the aftTotPrem
	 */
	public String getAftTotPrem() {
		return aftTotPrem;
	}

	/**
	 * @return the aftAddPrem
	 */
	public String getAftAddPrem() {
		return aftAddPrem;
	}

	/**
	 * @return the aftRefundPrem
	 */
	public String getAftRefundPrem() {
		return aftRefundPrem;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @param sBefCodeName1 the sBefCodeName1 to set
	 */
	public void setsBefCodeName1(final String sBefCodeName1) {
		this.sBefCodeName1 = sBefCodeName1;
	}

	/**
	 * @param sAftCodeName1 the sAftCodeName1 to set
	 */
	public void setsAftCodeName1(final String sAftCodeName1) {
		this.sAftCodeName1 = sAftCodeName1;
	}

	/**
	 * @param sBefCodeName2 the sBefCodeName2 to set
	 */
	public void setsBefCodeName2(final String sBefCodeName2) {
		this.sBefCodeName2 = sBefCodeName2;
	}

	/**
	 * @param sAftCodeName2 the sAftCodeName2 to set
	 */
	public void setsAftCodeName2(final String sAftCodeName2) {
		this.sAftCodeName2 = sAftCodeName2;
	}

	/**
	 * @param sBefCodeName3 the sBefCodeName3 to set
	 */
	public void setsBefCodeName3(final String sBefCodeName3) {
		this.sBefCodeName3 = sBefCodeName3;
	}

	/**
	 * @param sAftCodeName3 the sAftCodeName3 to set
	 */
	public void setsAftCodeName3(final String sAftCodeName3) {
		this.sAftCodeName3 = sAftCodeName3;
	}

	/**
	 * @param befTotPrem the befTotPrem to set
	 */
	public void setBefTotPrem(final String befTotPrem) {
		this.befTotPrem = befTotPrem;
	}

	/**
	 * @param befAddPrem the befAddPrem to set
	 */
	public void setBefAddPrem(final String befAddPrem) {
		this.befAddPrem = befAddPrem;
	}

	/**
	 * @param befRefundPrem the befRefundPrem to set
	 */
	public void setBefRefundPrem(final String befRefundPrem) {
		this.befRefundPrem = befRefundPrem;
	}

	/**
	 * @param aftTotPrem the aftTotPrem to set
	 */
	public void setAftTotPrem(final String aftTotPrem) {
		this.aftTotPrem = aftTotPrem;
	}

	/**
	 * @param aftAddPrem the aftAddPrem to set
	 */
	public void setAftAddPrem(final String aftAddPrem) {
		this.aftAddPrem = aftAddPrem;
	}

	/**
	 * @param aftRefundPrem the aftRefundPrem to set
	 */
	public void setAftRefundPrem(final String aftRefundPrem) {
		this.aftRefundPrem = aftRefundPrem;
	}
}
