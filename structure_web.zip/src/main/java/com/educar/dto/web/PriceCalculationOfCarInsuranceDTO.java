/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� �ڵ� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfCarInsuranceDTO")
public class PriceCalculationOfCarInsuranceDTO {
	/**
	 * <pre>
	 * ����1
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0101;
	/**
	 * <pre>
	 * ����2
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0102;
	/** 
	 * <pre>
	 * �빰
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0103;
	/** 
	 * <pre>
	 * �ڱ��ü���
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0201;
	/** 
	 * <pre>
	 * �ڵ������� 
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0202;
	/** 
	 * <pre>
	 * ������ 
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0301;
	/** 
	 * <pre>
	 * �ڱ��������� 
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0401;
	/** 
	 * <pre>
	 * �ڱ�δ�� 
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0404;
	/** 
	 * <pre>
	 * ����⵿ 
	 * (sOptCode : �㺸���Աݾ��ڵ�, sLongName : �㺸��, nOptAmt : �㺸���Աݾ�)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vCover0501;
	/** 
	 * <pre>
	 * �������� 
	 * (sMainCode : ��������Ư���ڵ�, sShortName : ��������Ư���)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vFamRange;
	/** 
	 * <pre>
	 * ��������
	 * (sMainCode : ��������Ư���ڵ�, sShortName : ��������Ư���)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vAgeRange;
	/** 
	 * <pre>
	 * ������� 
	 * (sMainCode : ��������ڵ�, sShortName : ���������)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vMac;
	/** 
	 * <pre>
	 * ������
	 * (sMainCode : Ư���ڵ�, sShortName : Ư���)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vSpecCode0111;
	/** 
	 * <pre>
	 * �����������
	 * (sMainCode : ����ڵ�, nDefaultRate : �⺻����)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vApplyCode;
	/** 
	 * <pre>
	 * Ư������
	 * (sMainCode : Ư�������ڵ�, sShortName : Ư��������) 
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vExtraCode;
	/** 
	 * <pre>
	 * ���Թ��
	 * (sMainCode : ���Թ���ڵ�, sShortName : ���Թ����)
	 * </pre>
	 **/
	private List<PriceCalculationOfCarInsuranceCodeDTO> vPayClause;
	/**
	 * <pre>
	 * �ڱ�δ�� 
	 * (nDefaultRate : �ڱ�δ�ݷ�, sLongName :�ڱ�δ�ݸ�)
	 * </pre>
	 */
	private List<PriceCalculationOfCarInsuranceCodeDTO> deductRateDoc;
	/**
	 * <pre>
	 * �ڱ�δ�� ���� �ݾ�
	 * (nOptAmt : �ڱ�δ������ݾ�, sOptName :�ڱ�δ�ݸ�)
	 * </pre>
	 */
	private List<PriceCalculationOfCarInsuranceCodeDTO> deductMinDoc;
	/**
	 * <pre>
	 * �ڱ�δ�� �ִ� �ݾ�
	 * (nOptAmt : �ڱ�δ��ְ��ݾ�, sOptName :�ڱ�δ�ݸ�)
	 * </pre>
	 */
	private List<PriceCalculationOfCarInsuranceCodeDTO> deductMaxDoc;


	/**
	 * @return the vCover0101
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0101() {
		return vCover0101;
	}

	/**
	 * @param vCover0101 the vCover0101 to set
	 */
	public void setvCover0101(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0101) {
		this.vCover0101 = vCover0101;
	}

	/**
	 * @return the vCover0102
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0102() {
		return vCover0102;
	}

	/**
	 * @param vCover0102 the vCover0102 to set
	 */
	public void setvCover0102(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0102) {
		this.vCover0102 = vCover0102;
	}

	/**
	 * @return the vCover0103
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0103() {
		return vCover0103;
	}

	/**
	 * @param vCover0103 the vCover0103 to set
	 */
	public void setvCover0103(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0103) {
		this.vCover0103 = vCover0103;
	}

	/**
	 * @return the vCover0201
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0201() {
		return vCover0201;
	}

	/**
	 * @param vCover0201 the vCover0201 to set
	 */
	public void setvCover0201(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0201) {
		this.vCover0201 = vCover0201;
	}

	/**
	 * @return the vCover0202
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0202() {
		return vCover0202;
	}

	/**
	 * @param vCover0202 the vCover0202 to set
	 */
	public void setvCover0202(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0202) {
		this.vCover0202 = vCover0202;
	}

	/**
	 * @return the vCover0301
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0301() {
		return vCover0301;
	}

	/**
	 * @param vCover0301 the vCover0301 to set
	 */
	public void setvCover0301(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0301) {
		this.vCover0301 = vCover0301;
	}

	/**
	 * @return the vCover0401
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0401() {
		return vCover0401;
	}

	/**
	 * @param vCover0401 the vCover0401 to set
	 */
	public void setvCover0401(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0401) {
		this.vCover0401 = vCover0401;
	}

	/**
	 * @return the vCover0404
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0404() {
		return vCover0404;
	}

	/**
	 * @param vCover0404 the vCover0404 to set
	 */
	public void setvCover0404(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0404) {
		this.vCover0404 = vCover0404;
	}

	/**
	 * @return the vCover0501
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvCover0501() {
		return vCover0501;
	}

	/**
	 * @param vCover0501 the vCover0501 to set
	 */
	public void setvCover0501(final List<PriceCalculationOfCarInsuranceCodeDTO> vCover0501) {
		this.vCover0501 = vCover0501;
	}

	/**
	 * @return the vFamRange
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvFamRange() {
		return vFamRange;
	}

	/**
	 * @param vFamRange the vFamRange to set
	 */
	public void setvFamRange(final List<PriceCalculationOfCarInsuranceCodeDTO> vFamRange) {
		this.vFamRange = vFamRange;
	}

	/**
	 * @return the vAgeRange
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvAgeRange() {
		return vAgeRange;
	}

	/**
	 * @param vAgeRange the vAgeRange to set
	 */
	public void setvAgeRange(final List<PriceCalculationOfCarInsuranceCodeDTO> vAgeRange) {
		this.vAgeRange = vAgeRange;
	}

	/**
	 * @return the vMac
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvMac() {
		return vMac;
	}

	/**
	 * @param vMac the vMac to set
	 */
	public void setvMac(final List<PriceCalculationOfCarInsuranceCodeDTO> vMac) {
		this.vMac = vMac;
	}

	/**
	 * @return the vSpecCode0111
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvSpecCode0111() {
		return vSpecCode0111;
	}

	/**
	 * @param vSpecCode0111 the vSpecCode0111 to set
	 */
	public void setvSpecCode0111(final List<PriceCalculationOfCarInsuranceCodeDTO> vSpecCode0111) {
		this.vSpecCode0111 = vSpecCode0111;
	}

	/**
	 * @return the vApplyCode
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvApplyCode() {
		return vApplyCode;
	}

	/**
	 * @param vApplyCode the vApplyCode to set
	 */
	public void setvApplyCode(final List<PriceCalculationOfCarInsuranceCodeDTO> vApplyCode) {
		this.vApplyCode = vApplyCode;
	}

	/**
	 * @return the vExtraCode
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvExtraCode() {
		return vExtraCode;
	}

	/**
	 * @param vExtraCode the vExtraCode to set
	 */
	public void setvExtraCode(final List<PriceCalculationOfCarInsuranceCodeDTO> vExtraCode) {
		this.vExtraCode = vExtraCode;
	}

	/**
	 * @return the vPayClause
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getvPayClause() {
		return vPayClause;
	}

	/**
	 * @param vPayClause the vPayClause to set
	 */
	public void setvPayClause(final List<PriceCalculationOfCarInsuranceCodeDTO> vPayClause) {
		this.vPayClause = vPayClause;
	}

	/**
	 * @return the deductRateDoc
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getDeductRateDoc() {
		return deductRateDoc;
	}

	/**
	 * @param deductRateDoc the deductRateDoc to set
	 */
	public void setDeductRateDoc(final List<PriceCalculationOfCarInsuranceCodeDTO> deductRateDoc) {
		this.deductRateDoc = deductRateDoc;
	}

	/**
	 * @return the deductMinDoc
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getDeductMinDoc() {
		return deductMinDoc;
	}

	/**
	 * @param deductMinDoc the deductMinDoc to set
	 */
	public void setDeductMinDoc(final List<PriceCalculationOfCarInsuranceCodeDTO> deductMinDoc) {
		this.deductMinDoc = deductMinDoc;
	}

	/**
	 * @return the deductMaxDoc
	 */
	public List<PriceCalculationOfCarInsuranceCodeDTO> getDeductMaxDoc() {
		return deductMaxDoc;
	}

	/**
	 * @param deductMaxDoc the deductMaxDoc to set
	 */
	public void setDeductMaxDoc(final List<PriceCalculationOfCarInsuranceCodeDTO> deductMaxDoc) {
		this.deductMaxDoc = deductMaxDoc;
	}

}
