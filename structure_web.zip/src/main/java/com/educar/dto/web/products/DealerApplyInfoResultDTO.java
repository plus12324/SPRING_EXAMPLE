/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� û�೻�� Ȯ�� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerApplyInfoResultDTO")
public class DealerApplyInfoResultDTO {
	/** applyInfo **/
	private DealerApplyInfoOfApplyInfoDTO applyInfo;
	/** coverVt **/
	private List<DealerApplyInfoOfCoverVtDTO> coverVt;
	/** tkVt **/
	private List<DealerApplyInfoOfTkVtDTO> tkVt;

	/**
	 * @return the applyInfo
	 */
	public DealerApplyInfoOfApplyInfoDTO getApplyInfo() {
		return applyInfo;
	}

	/**
	 * @param applyInfo the applyInfo to set
	 */
	public void setApplyInfo(final DealerApplyInfoOfApplyInfoDTO applyInfo) {
		this.applyInfo = applyInfo;
	}

	/**
	 * @return the coverVt
	 */
	public List<DealerApplyInfoOfCoverVtDTO> getCoverVt() {
		return coverVt;
	}

	/**
	 * @param coverVt the coverVt to set
	 */
	public void setCoverVt(final List<DealerApplyInfoOfCoverVtDTO> coverVt) {
		this.coverVt = coverVt;
	}

	/**
	 * @return the tkVt
	 */
	public List<DealerApplyInfoOfTkVtDTO> getTkVt() {
		return tkVt;
	}

	/**
	 * @param tkVt the tkVt to set
	 */
	public void setTkVt(final List<DealerApplyInfoOfTkVtDTO> tkVt) {
		this.tkVt = tkVt;
	}

}
