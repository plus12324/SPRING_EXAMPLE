/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �б��� �������� ��ȸ
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "schoolStaffSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SchoolStaffSearchDTO {
	/** �б�����("01" : ��ġ��, "02" : �ʵ��б�, "03":���б�, "04":�����б�, "05":��������, "06":���б�, "07":���п�, "08":�������, "09":��Ÿ) **/
	String sSchoolDiv;
	/** ��/�� **/
	String sCityName;
	/** ��/�� **/
	String sCountyName;
	/** �б��� **/
	String sSchoolName;
	/** ������ ��ȣ **/
	String pageIndex;

	/**
	 * @return the sSchoolDiv
	 */
	public String getsSchoolDiv() {
		return sSchoolDiv;
	}

	/**
	 * @param sSchoolDiv the sSchoolDiv to set
	 */
	public void setsSchoolDiv(final String sSchoolDiv) {
		this.sSchoolDiv = sSchoolDiv;
	}

	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}

	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(final String sCityName) {
		this.sCityName = sCityName;
	}

	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}

	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(final String sCountyName) {
		this.sCountyName = sCountyName;
	}

	/**
	 * @return the sSchoolName
	 */
	public String getsSchoolName() {
		return sSchoolName;
	}

	/**
	 * @param sSchoolName the sSchoolName to set
	 */
	public void setsSchoolName(final String sSchoolName) {
		this.sSchoolName = sSchoolName;
	}

	/**
	 * @return the pageIndex
	 */
	public String getPageIndex() {
		return pageIndex;
	}

	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(final String pageIndex) {
		this.pageIndex = pageIndex;
	}

}
