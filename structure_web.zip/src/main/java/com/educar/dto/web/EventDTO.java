/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * �̺�Ʈ - �������� �̺�Ʈ DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "eventDTO")
public class EventDTO extends PageDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �̺�Ʈ �ڵ� **/
	private String EVENT_CD;
	/** ���޻� �ڵ� **/
	private String AC_CD;
	/** ���� **/
	private String TITLE;
	/** ����Ʈ �̹��� **/
	private String LIST_IMG;
	/** ������ Ÿ�� **/
	private String CONTENT_TYPE;
	/** ��ũ **/
	private String URL;
	/** ���� **/
	private String CONTENT;
	/** ���� ���� **/
	private String VIEW_YN;
	/** �ۼ��� EventDTO **/
	private String CRE_DT;
	/** �ۼ��� ID **/
	private String CRE_ID;
	/** ������ **/
	private String UPD_DT;
	/** ������ ID **/
	private String UPD_ID;
	/** ������ȣ **/
	private int SEQ;
	/** ��ǰ�� **/
	private String PRIZE;
	/** �̺�Ʈ ��� **/
	private String PERSON;
	/** ������ **/
	private String START_DATE;
	/** ������ **/
	private String FINISH_DATE;
	/** ��÷�� ���� **/
	private String NOTICE_YN;
	/** �̺�Ʈ �̹��� Thumbnail path **/
	private String IMG_PATH;
	/** ������� �̺�Ʈ ���𿩺� */
	private String ENTRY_YN;

	/**
	 * @return the nOTICE_YN
	 */
	public String getNOTICE_YN() {
		return NOTICE_YN;
	}

	/**
	 * @param nOTICE_YN the nOTICE_YN to set
	 */
	public void setNOTICE_YN(final String nOTICE_YN) {
		NOTICE_YN = nOTICE_YN;
	}

	/**
	 * @return the eVENT_CD
	 */
	public String getEVENT_CD() {
		return EVENT_CD;
	}

	/**
	 * @param eVENT_CD the eVENT_CD to set
	 */
	public void setEVENT_CD(final String eVENT_CD) {
		EVENT_CD = eVENT_CD;
	}

	/**
	 * @return the aC_CD
	 */
	public String getAC_CD() {
		return AC_CD;
	}

	/**
	 * @param aC_CD the aC_CD to set
	 */
	public void setAC_CD(final String aC_CD) {
		AC_CD = aC_CD;
	}

	/**
	 * @return the tITLE
	 */
	public String getTITLE() {
		return TITLE;
	}

	/**
	 * @param tITLE the tITLE to set
	 */
	public void setTITLE(final String tITLE) {
		TITLE = tITLE;
	}

	/**
	 * @return the lIST_IMG
	 */
	public String getLIST_IMG() {
		return LIST_IMG;
	}

	/**
	 * @param lIST_IMG the lIST_IMG to set
	 */
	public void setLIST_IMG(final String lIST_IMG) {
		LIST_IMG = lIST_IMG;
	}

	/**
	 * @return the cONTENT_TYPE
	 */
	public String getCONTENT_TYPE() {
		return CONTENT_TYPE;
	}

	/**
	 * @param cONTENT_TYPE the cONTENT_TYPE to set
	 */
	public void setCONTENT_TYPE(final String cONTENT_TYPE) {
		CONTENT_TYPE = cONTENT_TYPE;
	}

	/**
	 * @return the uRL
	 */
	public String getURL() {
		return URL;
	}

	/**
	 * @param uRL the uRL to set
	 */
	public void setURL(final String uRL) {
		URL = uRL;
	}

	/**
	 * @return the cONTENT
	 */
	public String getCONTENT() {
		return CONTENT;
	}

	/**
	 * @param cONTENT the cONTENT to set
	 */
	public void setCONTENT(final String cONTENT) {
		CONTENT = cONTENT;
	}

	/**
	 * @return the vIEW_YN
	 */
	public String getVIEW_YN() {
		return VIEW_YN;
	}

	/**
	 * @param vIEW_YN the vIEW_YN to set
	 */
	public void setVIEW_YN(final String vIEW_YN) {
		VIEW_YN = vIEW_YN;
	}

	/**
	 * @return the cRE_DT
	 */
	public String getCRE_DT() {
		return CRE_DT;
	}

	/**
	 * @param cRE_DT the cRE_DT to set
	 */
	public void setCRE_DT(final String cRE_DT) {
		CRE_DT = cRE_DT;
	}

	/**
	 * @return the cRE_ID
	 */
	public String getCRE_ID() {
		return CRE_ID;
	}

	/**
	 * @param cRE_ID the cRE_ID to set
	 */
	public void setCRE_ID(final String cRE_ID) {
		CRE_ID = cRE_ID;
	}

	/**
	 * @return the uPD_DT
	 */
	public String getUPD_DT() {
		return UPD_DT;
	}

	/**
	 * @param uPD_DT the uPD_DT to set
	 */
	public void setUPD_DT(final String uPD_DT) {
		UPD_DT = uPD_DT;
	}

	/**
	 * @return the uPD_ID
	 */
	public String getUPD_ID() {
		return UPD_ID;
	}

	/**
	 * @param uPD_ID the uPD_ID to set
	 */
	public void setUPD_ID(final String uPD_ID) {
		UPD_ID = uPD_ID;
	}

	/**
	 * @return the sEQ
	 */
	public int getSEQ() {
		return SEQ;
	}

	/**
	 * @param sEQ the sEQ to set
	 */
	public void setSEQ(final int sEQ) {
		SEQ = sEQ;
	}

	/**
	 * @return the pRIZE
	 */
	public String getPRIZE() {
		return PRIZE;
	}

	/**
	 * @param pRIZE the pRIZE to set
	 */
	public void setPRIZE(final String pRIZE) {
		PRIZE = pRIZE;
	}

	/**
	 * @return the pERSON
	 */
	public String getPERSON() {
		return PERSON;
	}

	/**
	 * @param pERSON the pERSON to set
	 */
	public void setPERSON(final String pERSON) {
		PERSON = pERSON;
	}

	/**
	 * @return the sTART_DATE
	 */
	public String getSTART_DATE() {
		return START_DATE;
	}

	/**
	 * @param sTART_DATE the sTART_DATE to set
	 */
	public void setSTART_DATE(final String sTART_DATE) {
		START_DATE = sTART_DATE;
	}

	/**
	 * @return the fINISH_DATE
	 */
	public String getFINISH_DATE() {
		return FINISH_DATE;
	}

	/**
	 * @param fINISH_DATE the fINISH_DATE to set
	 */
	public void setFINISH_DATE(final String fINISH_DATE) {
		FINISH_DATE = fINISH_DATE;
	}

	/**
	 * @return the iMG_PATH
	 */
	public String getIMG_PATH() {
		return IMG_PATH;
	}

	/**
	 * @param iMG_PATH the iMG_PATH to set
	 */
	public void setIMG_PATH(final String iMG_PATH) {
		IMG_PATH = iMG_PATH;
	}

	/**
	 * ������� �̺�Ʈ ���𿩺θ� ��ȯ�Ѵ�.
	 * @return ������� �̺�Ʈ ���𿩺�
	 */
	public String getENTRY_YN() {
		return ENTRY_YN;
	}

	/**
	 * ������� �̺�Ʈ ���𿩺θ� �����Ѵ�.
	 * @param ENTRY_YN ������� �̺�Ʈ ���𿩺�
	 */
	public void setENTRY_YN(final String eNTRY_YN) {
		ENTRY_YN = eNTRY_YN;
	}
}
