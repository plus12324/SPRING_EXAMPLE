/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (�������, ��������, �ڵ���ü��Ȳ, Ư������)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfPolca01InfoDTO")
public class InsuranceCarDetailOfPolca01InfoDTO {
	/** ����ȣ���� **/
	private String sPolicyType;
	/** ����ȣ��� **/
	private String sPolicyYM;
	/** ����ȣser **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ���� **/
	private String sInsType;
	/** �����ǰ�� **/
	private String sInsTypeName;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** �Ǻ����ڱ����ڵ� **/
	private String sInsrdType;
	/** �Ǻ������ڵ� **/
	private String sInsrdID;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** ����ڱ��� **/
	private String sPolHolderType;
	/** ������ڵ� **/
	private String sPolHolderID;
	/** ����ڸ� **/
	private String sPolHolderName;
	/** ������ (0:����, 1:���㺸����, 2:���Ǵ㺸����, 3:�Ϻδ㺸����, 4:å�Ӵܵ����) **/
	private String sPolicyStat;
	/** ���� **/
	private String sPolicyStatName;
	/** ������ȣ **/
	private String sPlateNo;
	/** ������ **/
	private String sCarName;
	/** ���� **/
	private String sYear;
	/** ���谡�� **/
	private String nVehicleAmtTot;
	/** �������� **/
	private String nVehicleAmt;
	/** �μ�ǰ���� **/
	private String nAttachPrice;
	/** ����� **/
	private String sBankCode;
	/** ����/ī��� **/
	private String sBankCodeName;
	/** ���¹�ȣ **/
	private String sAcctNo;
	/** ������ **/
	private String sDepositerName;
	/** ���Թ�� **/
	private String sPayClauseName;
	/** ���뵵 **/
	private String sUseNameForPrint;
	/** ���Թ�� **/
	private String sPayClauseName2;
	/** ��������ڵ� **/
	private String sCarGradeCode;
	/** ������޿��� **/
	private String nCarGradeRate;
	/** ����⵿���Ƚ�� **/
	private String nEmerCnt;
	/** ����⵿��Ƚ�� **/
	private String nTotalEmerCnt;
	/** �Ѻ���� **/
	private String nTotRealPrem;
	/** �ѿ�������� **/
	private String nTotRectPrem;
	
	/** ü�����ڸ� **/
	private String sRectAgntName;
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}

	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(final String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sInsrdType
	 */
	public String getsInsrdType() {
		return sInsrdType;
	}

	/**
	 * @param sInsrdType the sInsrdType to set
	 */
	public void setsInsrdType(final String sInsrdType) {
		this.sInsrdType = sInsrdType;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sPolHolderType
	 */
	public String getsPolHolderType() {
		return sPolHolderType;
	}

	/**
	 * @param sPolHolderType the sPolHolderType to set
	 */
	public void setsPolHolderType(final String sPolHolderType) {
		this.sPolHolderType = sPolHolderType;
	}

	/**
	 * @return the sPolHolderID
	 */
	public String getsPolHolderID() {
		return sPolHolderID;
	}

	/**
	 * @param sPolHolderID the sPolHolderID to set
	 */
	public void setsPolHolderID(final String sPolHolderID) {
		this.sPolHolderID = sPolHolderID;
	}

	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}

	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(final String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}

	/**
	 * @return the sPolicyStat
	 */
	public String getsPolicyStat() {
		return sPolicyStat;
	}

	/**
	 * @param sPolicyStat the sPolicyStat to set
	 */
	public void setsPolicyStat(final String sPolicyStat) {
		this.sPolicyStat = sPolicyStat;
	}

	/**
	 * @return the sPolicyStatName
	 */
	public String getsPolicyStatName() {
		return sPolicyStatName;
	}

	/**
	 * @param sPolicyStatName the sPolicyStatName to set
	 */
	public void setsPolicyStatName(final String sPolicyStatName) {
		this.sPolicyStatName = sPolicyStatName;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sCarName
	 */
	public String getsCarName() {
		return sCarName;
	}

	/**
	 * @param sCarName the sCarName to set
	 */
	public void setsCarName(final String sCarName) {
		this.sCarName = sCarName;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the nVehicleAmtTot
	 */
	public String getnVehicleAmtTot() {
		return nVehicleAmtTot;
	}

	/**
	 * @param nVehicleAmtTot the nVehicleAmtTot to set
	 */
	public void setnVehicleAmtTot(final String nVehicleAmtTot) {
		this.nVehicleAmtTot = nVehicleAmtTot;
	}

	/**
	 * @return the nVehicleAmt
	 */
	public String getnVehicleAmt() {
		return nVehicleAmt;
	}

	/**
	 * @param nVehicleAmt the nVehicleAmt to set
	 */
	public void setnVehicleAmt(final String nVehicleAmt) {
		this.nVehicleAmt = nVehicleAmt;
	}

	/**
	 * @return the nAttachPrice
	 */
	public String getnAttachPrice() {
		return nAttachPrice;
	}

	/**
	 * @param nAttachPrice the nAttachPrice to set
	 */
	public void setnAttachPrice(final String nAttachPrice) {
		this.nAttachPrice = nAttachPrice;
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sBankCodeName
	 */
	public String getsBankCodeName() {
		return sBankCodeName;
	}

	/**
	 * @param sBankCodeName the sBankCodeName to set
	 */
	public void setsBankCodeName(final String sBankCodeName) {
		this.sBankCodeName = sBankCodeName;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sDepositerName
	 */
	public String getsDepositerName() {
		return sDepositerName;
	}

	/**
	 * @param sDepositerName the sDepositerName to set
	 */
	public void setsDepositerName(final String sDepositerName) {
		this.sDepositerName = sDepositerName;
	}

	/**
	 * @return the sPayClauseName
	 */
	public String getsPayClauseName() {
		return sPayClauseName;
	}

	/**
	 * @param sPayClauseName the sPayClauseName to set
	 */
	public void setsPayClauseName(final String sPayClauseName) {
		this.sPayClauseName = sPayClauseName;
	}

	/**
	 * @return the sUseNameForPrint
	 */
	public String getsUseNameForPrint() {
		return sUseNameForPrint;
	}

	/**
	 * @param sUseNameForPrint the sUseNameForPrint to set
	 */
	public void setsUseNameForPrint(final String sUseNameForPrint) {
		this.sUseNameForPrint = sUseNameForPrint;
	}

	/**
	 * @return the sPayClauseName2
	 */
	public String getsPayClauseName2() {
		return sPayClauseName2;
	}

	/**
	 * @param sPayClauseName2 the sPayClauseName2 to set
	 */
	public void setsPayClauseName2(final String sPayClauseName2) {
		this.sPayClauseName2 = sPayClauseName2;
	}

	/**
	 * @return the sCarGradeCode
	 */
	public String getsCarGradeCode() {
		return sCarGradeCode;
	}

	/**
	 * @param sCarGradeCode the sCarGradeCode to set
	 */
	public void setsCarGradeCode(final String sCarGradeCode) {
		this.sCarGradeCode = sCarGradeCode;
	}

	/**
	 * @return the nCarGradeRate
	 */
	public String getnCarGradeRate() {
		return nCarGradeRate;
	}

	/**
	 * @param nCarGradeRate the nCarGradeRate to set
	 */
	public void setnCarGradeRate(final String nCarGradeRate) {
		this.nCarGradeRate = nCarGradeRate;
	}

	/**
	 * @return the nEmerCnt
	 */
	public String getnEmerCnt() {
		return nEmerCnt;
	}

	/**
	 * @param nEmerCnt the nEmerCnt to set
	 */
	public void setnEmerCnt(final String nEmerCnt) {
		this.nEmerCnt = nEmerCnt;
	}

	/**
	 * @return the nTotalEmerCnt
	 */
	public String getnTotalEmerCnt() {
		return nTotalEmerCnt;
	}

	/**
	 * @param nTotalEmerCnt the nTotalEmerCnt to set
	 */
	public void setnTotalEmerCnt(final String nTotalEmerCnt) {
		this.nTotalEmerCnt = nTotalEmerCnt;
	}

	/**
	 * @return the nTotRealPrem
	 */
	public String getnTotRealPrem() {
		return nTotRealPrem;
	}

	/**
	 * @param nTotRealPrem the nTotRealPrem to set
	 */
	public void setnTotRealPrem(final String nTotRealPrem) {
		this.nTotRealPrem = nTotRealPrem;
	}

	/**
	 * �ѿ�������Ḧ ��ȯ�Ѵ�.
	 * @return �ѿ��������
	 */
	public String getnTotRectPrem() {
		return nTotRectPrem;
	}

	/**
	 * �ѿ�������Ḧ �����Ѵ�.
	 * @param nTotRectPrem �ѿ��������
	 */
	public void setnTotRectPrem(final String nTotRectPrem) {
		this.nTotRectPrem = nTotRectPrem;
	}

	/**
	 * @return the sRectAgntName
	 */
	public String getsRectAgntName() {
		return sRectAgntName;
	}

	/**
	 * @param sRectAgntName the sRectAgntName to set
	 */
	public void setsRectAgntName(String sRectAgntName) {
		this.sRectAgntName = sRectAgntName;
	}
	
}
