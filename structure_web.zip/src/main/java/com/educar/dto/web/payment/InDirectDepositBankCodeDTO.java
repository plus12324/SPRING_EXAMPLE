/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �Ա� ���� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "inDirectDepositBankCodeDTO")
public class InDirectDepositBankCodeDTO {
	/** ������� **/
	private String sAcctNo;
	/** �����ڵ� **/
	private String sBankCode;
	/** ����� **/
	private String sBankCodeName;

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sBankCodeName
	 */
	public String getsBankCodeName() {
		return sBankCodeName;
	}

	/**
	 * @param sBankCodeName the sBankCodeName to set
	 */
	public void setsBankCodeName(final String sBankCodeName) {
		this.sBankCodeName = sBankCodeName;
	}

}
