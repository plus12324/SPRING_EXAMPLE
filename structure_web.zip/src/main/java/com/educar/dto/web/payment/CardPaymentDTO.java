/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * �ڵ������� ����, �ſ�ī����� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.9
 *
 */
@XmlRootElement(name = "cardPaymentDTO")
public class CardPaymentDTO {
	/** û���ȣ **/
	private String sApplyNo;
	/** ī���ȣ **/
	private String sCardNo;
	/** ���αݾ� **/
	private String nReqAmt;
	/** ����ڸ� **/
	private String sCardOwner;
	/** ��ȿ�Ⱓ YYYYMM **/
	@ValidateDate(dateFormat = DateFormat.yyyyMM)
	private String sValidThru;
	/** �Һΰ����� �Һΰ��ƴѰ��:0 **/
	private String nInstall;
	/** ������ڵ� **/
	private String sCardOwnerID;
	/** ����ڻ�� **/
	@ValidateLength(max = 7)
	private String sReqAgnt;
	/** å�Ӱ����� YYYYMM **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sBeginDate;
	/** ����Ʈ ���� 00 : ���ƴ�, 10:�Ϲ�BC Top, 11:���BC, 20:��ȯ��������Ʈ, 30:��ȯYESPOINT, 40:���̺�����Ʈ(�Ｚ,��ȯ���̼��̺�, ����) **/
	private String sPointCardType;
	/** ����Ʈ��������, Y, N(sPointCardType:00�̸� N) **/
	@ValidateRegex(predefinedRegex = RegexEnum.YNString)
	private String sSetPointYN;
	/** ����ī�忩��, Y, N(sPointCardType:00�̸� N) **/
	@ValidateRegex(predefinedRegex = RegexEnum.YNString)
	private String sEducardYN;
	/** ����Ʈ������� (��밡������Ʈ����:����Ʈ> ���αݾ��̸� ���αݾ�, �׷��� ������ ����Ʈ(sPointCardType:00�̸� 0)) **/
	private String sSetPointAmt;
	/**����������	���αݾ� - ����Ʈ������� (sPointCardType:00 �̸� "") **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sSetCardAmt;
	/**�ܿ�����Ʈ	����Ʈ���� - ��밡������Ʈ����(sPointCardType:00�̸� "") **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sRemainPoint;
	/** ī���	4�ڸ� **/
	@ValidateLength(max = 4, min = 4)
	private String sCardCom;
	/** ��ǰ���� 0: �ڵ���, 1:�Ϲ�, 2:��� **/
	@ValidateLength(max = 1, min = 1)
	private String sInsGrp;
	
	/** ī���ȣ1 **/
	private String sCardNo1;
	/** ī���ȣ2 **/
	private String sCardNo2;
	/** ī���ȣ3 **/
	private String sCardNo3;
	/** ī���ȣ4 **/
	private String sCardNo4;
	/** Ű���庸�� ��ȣȭ Key **/
	private String sHid_key_data;

	/**
	 * @return the sApplyNo û���ȣ
	 */
	public String getsApplyNo() {
		return sApplyNo;
	}

	/**
	 * @param sApplyNo the sApplyNo to set û���ȣ
	 */
	public void setsApplyNo(final String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}

	/**
	 * @return the sCardNo ī���ȣ
	 */
	public String getsCardNo() {
		return sCardNo;
	}

	/**
	 * @param sCardNo the sCardNo to set ī���ȣ
	 */
	public void setsCardNo(final String sCardNo) {
		this.sCardNo = sCardNo;
	}

	/**
	 * @return the nReqAmt ���αݾ�
	 */
	public String getnReqAmt() {
		return nReqAmt;
	}

	/**
	 * @param nReqAmt the nReqAmt to set ���αݾ�
	 */
	public void setnReqAmt(final String nReqAmt) {
		this.nReqAmt = nReqAmt;
	}

	/**
	 * @return the sCardOwner ����ڸ�
	 */
	public String getsCardOwner() {
		return sCardOwner;
	}

	/**
	 * @param sCardOwner the sCardOwner to set ����ڸ�
	 */
	public void setsCardOwner(final String sCardOwner) {
		this.sCardOwner = sCardOwner;
	}

	/**
	 * @return the sValidThru ��ȿ�Ⱓ
	 */
	public String getsValidThru() {
		return sValidThru;
	}

	/**
	 * @param sValidThru the sValidThru to set ��ȿ�Ⱓ
	 */
	public void setsValidThru(final String sValidThru) {
		this.sValidThru = sValidThru;
	}

	/**
	 * @return the nInstall �Һΰ�����
	 */
	public String getnInstall() {
		return nInstall;
	}

	/**
	 * @param nInstall the nInstall to set �Һΰ�����
	 */
	public void setnInstall(final String nInstall) {
		this.nInstall = nInstall;
	}

	/**
	 * @return the sCardOwnerID ������ڵ�
	 */
	public String getsCardOwnerID() {
		return sCardOwnerID;
	}

	/**
	 * @param sCardOwnerID the sCardOwnerID to set ������ڵ�
	 */
	public void setsCardOwnerID(final String sCardOwnerID) {
		this.sCardOwnerID = sCardOwnerID;
	}

	/**
	 * @return the sReqAgnt ����ڻ��
	 */
	public String getsReqAgnt() {
		return sReqAgnt;
	}

	/**
	 * @param sReqAgnt the sReqAgnt to set ����ڻ��
	 */
	public void setsReqAgnt(final String sReqAgnt) {
		this.sReqAgnt = sReqAgnt;
	}

	/** 
	 * @return the sBeginDate å�Ӱ�����
	 */
	public String getsBeginDate() {
		return sBeginDate;
	}

	/**
	 * @param sBeginDate the sBeginDate to set å�Ӱ�����
	 */
	public void setsBeginDate(final String sBeginDate) {
		this.sBeginDate = sBeginDate;
	}

	/**
	 * @return the sPointCardType
	 */
	public String getsPointCardType() {
		return sPointCardType;
	}

	/**
	 * @param sPointCardType the sPointCardType to set
	 */
	public void setsPointCardType(final String sPointCardType) {
		this.sPointCardType = sPointCardType;
	}

	/**
	 * @return the sSetPointYN
	 */
	public String getsSetPointYN() {
		return sSetPointYN;
	}

	/**
	 * @param sSetPointYN the sSetPointYN to set
	 */
	public void setsSetPointYN(final String sSetPointYN) {
		this.sSetPointYN = sSetPointYN;
	}

	/**
	 * @return the sEducardYN
	 */
	public String getsEducardYN() {
		return sEducardYN;
	}

	/**
	 * @param sEducardYN the sEducardYN to set
	 */
	public void setsEducardYN(final String sEducardYN) {
		this.sEducardYN = sEducardYN;
	}

	/**
	 * @return the sSetPointAmt
	 */
	public String getsSetPointAmt() {
		return sSetPointAmt;
	}

	/**
	 * @param sSetPointAmt the sSetPointAmt to set
	 */
	public void setsSetPointAmt(final String sSetPointAmt) {
		this.sSetPointAmt = sSetPointAmt;
	}

	/**
	 * @return the sSetCardAmt
	 */
	public String getsSetCardAmt() {
		return sSetCardAmt;
	}

	/**
	 * @param sSetCardAmt the sSetCardAmt to set
	 */
	public void setsSetCardAmt(final String sSetCardAmt) {
		this.sSetCardAmt = sSetCardAmt;
	}

	/**
	 * @return the sRemainPoint
	 */
	public String getsRemainPoint() {
		return sRemainPoint;
	}

	/**
	 * @param sRemainPoint the sRemainPoint to set
	 */
	public void setsRemainPoint(final String sRemainPoint) {
		this.sRemainPoint = sRemainPoint;
	}

	/**
	 * @return the sCardCom
	 */
	public String getsCardCom() {
		return sCardCom;
	}

	/**
	 * @param sCardCom the sCardCom to set
	 */
	public void setsCardCom(final String sCardCom) {
		this.sCardCom = sCardCom;
	}

	/**
	 * @return the sInsGrp
	 */
	public String getsInsGrp() {
		return sInsGrp;
	}

	/**
	 * @param sInsGrp the sInsGrp to set
	 */
	public void setsInsGrp(final String sInsGrp) {
		this.sInsGrp = sInsGrp;
	}

	/**
	 * @return the sCardNo1
	 */
	public String getsCardNo1() {
		return sCardNo1;
	}

	/**
	 * @param sCardNo1 the sCardNo1 to set
	 */
	public void setsCardNo1(String sCardNo1) {
		this.sCardNo1 = sCardNo1;
	}

	/**
	 * @return the sCardNo2
	 */
	public String getsCardNo2() {
		return sCardNo2;
	}

	/**
	 * @param sCardNo2 the sCardNo2 to set
	 */
	public void setsCardNo2(String sCardNo2) {
		this.sCardNo2 = sCardNo2;
	}

	/**
	 * @return the sCardNo3
	 */
	public String getsCardNo3() {
		return sCardNo3;
	}

	/**
	 * @param sCardNo3 the sCardNo3 to set
	 */
	public void setsCardNo3(String sCardNo3) {
		this.sCardNo3 = sCardNo3;
	}

	/**
	 * @return the sCardNo4
	 */
	public String getsCardNo4() {
		return sCardNo4;
	}

	/**
	 * @param sCardNo4 the sCardNo4 to set
	 */
	public void setsCardNo4(String sCardNo4) {
		this.sCardNo4 = sCardNo4;
	}

	/**
	 * @return the hid_key_data
	 */
	public String getsHid_key_data() {
		return sHid_key_data;
	}

	/**
	 * @param hid_key_data the hid_key_data to set
	 */
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}
	
	
}
