/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ���� ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfGENAA01DTO")
public class CalculationOfGENAA01DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ����ñ� (YYYYMMDD(�����������)) **/
	private String sFmdt;
	/** ����ñ�ð� (HH) **/
	private String sApplyTime;
	/** �������� (YYYYMMDD(������������)) **/
	private String sTodt;
	/** ��������ð� (HH) **/
	private String sToTime;
	/** �����ϼ� (D) **/
	private String nDayCnt;
	/** �����ڵ� **/
	private String sJobCode;
	/** ������ **/
	private String sJobName;
	/** �̺�Ʈ�ڵ� **/
	private String sEventDiv;
	/** �����ڵ� **/
	private String sAffiliatedConcern;

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sApplyTime
	 */
	public String getsApplyTime() {
		return sApplyTime;
	}

	/**
	 * @param sApplyTime the sApplyTime to set
	 */
	public void setsApplyTime(final String sApplyTime) {
		this.sApplyTime = sApplyTime;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sToTime
	 */
	public String getsToTime() {
		return sToTime;
	}

	/**
	 * @param sToTime the sToTime to set
	 */
	public void setsToTime(final String sToTime) {
		this.sToTime = sToTime;
	}

	/**
	 * @return the nDayCnt
	 */
	public String getnDayCnt() {
		return nDayCnt;
	}

	/**
	 * @param nDayCnt the nDayCnt to set
	 */
	public void setnDayCnt(final String nDayCnt) {
		this.nDayCnt = nDayCnt;
	}

	/**
	 * @return the sJobCode
	 */
	public String getsJobCode() {
		return sJobCode;
	}

	/**
	 * @param sJobCode the sJobCode to set
	 */
	public void setsJobCode(final String sJobCode) {
		this.sJobCode = sJobCode;
	}

	/**
	 * @return the sJobName
	 */
	public String getsJobName() {
		return sJobName;
	}

	/**
	 * @param sJobName the sJobName to set
	 */
	public void setsJobName(final String sJobName) {
		this.sJobName = sJobName;
	}

	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}

	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(final String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

}
