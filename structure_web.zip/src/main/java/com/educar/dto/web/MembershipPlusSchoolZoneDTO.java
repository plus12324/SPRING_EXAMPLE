/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ����ʼ��� - ������(�����Ӵ�ȸ ��ǰ)
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "membershipPlusSchoolZoneDTO")
public class MembershipPlusSchoolZoneDTO extends PageDTO{
	
	/** default **/
	private static final long serialVersionUID = 1L;
	
	/** 	����		**/ 
	private String 	nSeqNo;
	/** 	��û�б���	��û�б���	**/ 
	private String 	sReqShcoolNm;
	/** 	����� ������ȣ	�����������ȣ	**/ 
	private String 	sDeliveryZip1;
	/** 	����� ������ȣ	�����������ȣ	**/ 
	private String 	sDeliveryZip2;
	/** 	������ּ�1	�õ�	**/ 
	private String 	sDeliveryAdrs1;
	/** 	������ּ�2	�ñ���	**/ 
	private String 	sDeliveryAdrs2;
	/** 	������ּ�3	���鵿	**/ 
	private String 	sDeliveryAdrs3;
	/** 	���������	����� �������ּ�	**/ 
	private String 	sDeliveryAdrsAdd;
	/** 	��û�ڱ���	"1:�����Ӵ�ȸ ��缱����, 2:�����Ӵ�ȸ ȸ��,
	3:�����Ӵ�ȸ ȸ��, 4:��û�б� ������, 
	5:��û�б� �кθ�"	**/ 
	private String 	sApplicantType	;
	/** 	��û����		**/ 
	private String 	nReqQty	;
	/** 	��û�ڼ���	��û�ڸ�	**/ 
	private String 	sApplicantName	;
	/** 	�޴�����ȣ1		**/ 
	private String 	sCellPhone1	;
	/** 	�޴�����ȣ2		**/ 
	private String 	sCellPhone2	;
	/** 	�޴�����ȣ4		**/ 
	private String 	sCellPhone3	;
	/** 	���	���	**/ 
	private String 	sRemarkNote	;
	/** 	������ű��ּұ���	"'or '0' or null:���ּ�, 1:���ּ�
	 		2013.12.27 �ּ�ǥ��ȭ ���� 
				'2' => ǥ�������ּ�
				'3' => ǥ�ص��θ��ּ�"	**/ 
	private String 	sDeliveryZipType	;
	/** 	������ּҰ�����ȣ	
	 		2013.12.27 �ּ�ǥ��ȭ ���� 
			�ּҰ�������Ÿ common..COMAB01 PK ����	**/ 
	private String 	sDeliveryAddrMgtNo	;
	/** 	������ּ�ǥ�ؼ���	"���̺��� ������ �ּ�ǥ�ع�ȣ
			�ּ���ȯ��� common..COMAB20 PK ����"	**/ 
	private String 	nDeliveryAddrStdSeq	;
	/** 	����������ּұ���	
			'0' => �Է������ּ�
			'1' => �Էµ��θ��ּ�	**/ 
	private String 	sDeliveryOrgZipType	;
	/** 	���������������ȣ		**/ 
	private String 	sDeliveryOrgZipCode	;
	/** 	����������ּ�		**/ 
	private String 	sDeliveryOrgAddr	;
	/** 	�Է�����		**/ 
	private String 	sInputDate;
	/** 	�Է½ð�		**/ 
	private String 	sInputTime;
	/** ��� **/
	private String	sResult;
	
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the sReqShcoolNm
	 */
	public String getsReqShcoolNm() {
		return sReqShcoolNm;
	}
	/**
	 * @param sReqShcoolNm the sReqShcoolNm to set
	 */
	public void setsReqShcoolNm(String sReqShcoolNm) {
		this.sReqShcoolNm = sReqShcoolNm;
	}
	/**
	 * @return the sDeliveryZip1
	 */
	public String getsDeliveryZip1() {
		return sDeliveryZip1;
	}
	/**
	 * @param sDeliveryZip1 the sDeliveryZip1 to set
	 */
	public void setsDeliveryZip1(String sDeliveryZip1) {
		this.sDeliveryZip1 = sDeliveryZip1;
	}
	/**
	 * @return the sDeliveryZip2
	 */
	public String getsDeliveryZip2() {
		return sDeliveryZip2;
	}
	/**
	 * @param sDeliveryZip2 the sDeliveryZip2 to set
	 */
	public void setsDeliveryZip2(String sDeliveryZip2) {
		this.sDeliveryZip2 = sDeliveryZip2;
	}
	/**
	 * @return the sDeliveryAdrs1
	 */
	public String getsDeliveryAdrs1() {
		return sDeliveryAdrs1;
	}
	/**
	 * @param sDeliveryAdrs1 the sDeliveryAdrs1 to set
	 */
	public void setsDeliveryAdrs1(String sDeliveryAdrs1) {
		this.sDeliveryAdrs1 = sDeliveryAdrs1;
	}
	/**
	 * @return the sDeliveryAdrs2
	 */
	public String getsDeliveryAdrs2() {
		return sDeliveryAdrs2;
	}
	/**
	 * @param sDeliveryAdrs2 the sDeliveryAdrs2 to set
	 */
	public void setsDeliveryAdrs2(String sDeliveryAdrs2) {
		this.sDeliveryAdrs2 = sDeliveryAdrs2;
	}
	/**
	 * @return the sDeliveryAdrs3
	 */
	public String getsDeliveryAdrs3() {
		return sDeliveryAdrs3;
	}
	/**
	 * @param sDeliveryAdrs3 the sDeliveryAdrs3 to set
	 */
	public void setsDeliveryAdrs3(String sDeliveryAdrs3) {
		this.sDeliveryAdrs3 = sDeliveryAdrs3;
	}
	/**
	 * @return the sDeliveryAdrsAdd
	 */
	public String getsDeliveryAdrsAdd() {
		return sDeliveryAdrsAdd;
	}
	/**
	 * @param sDeliveryAdrsAdd the sDeliveryAdrsAdd to set
	 */
	public void setsDeliveryAdrsAdd(String sDeliveryAdrsAdd) {
		this.sDeliveryAdrsAdd = sDeliveryAdrsAdd;
	}
	/**
	 * @return the sApplicantType
	 */
	public String getsApplicantType() {
		return sApplicantType;
	}
	/**
	 * @param sApplicantType the sApplicantType to set
	 */
	public void setsApplicantType(String sApplicantType) {
		this.sApplicantType = sApplicantType;
	}
	/**
	 * @return the nReqQty
	 */
	public String getnReqQty() {
		return nReqQty;
	}
	/**
	 * @param nReqQty the nReqQty to set
	 */
	public void setnReqQty(String nReqQty) {
		this.nReqQty = nReqQty;
	}
	/**
	 * @return the sApplicantName
	 */
	public String getsApplicantName() {
		return sApplicantName;
	}
	/**
	 * @param sApplicantName the sApplicantName to set
	 */
	public void setsApplicantName(String sApplicantName) {
		this.sApplicantName = sApplicantName;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sRemarkNote
	 */
	public String getsRemarkNote() {
		return sRemarkNote;
	}
	/**
	 * @param sRemarkNote the sRemarkNote to set
	 */
	public void setsRemarkNote(String sRemarkNote) {
		this.sRemarkNote = sRemarkNote;
	}
	/**
	 * @return the sDeliveryZipType
	 */
	public String getsDeliveryZipType() {
		return sDeliveryZipType;
	}
	/**
	 * @param sDeliveryZipType the sDeliveryZipType to set
	 */
	public void setsDeliveryZipType(String sDeliveryZipType) {
		this.sDeliveryZipType = sDeliveryZipType;
	}
	/**
	 * @return the sDeliveryAddrMgtNo
	 */
	public String getsDeliveryAddrMgtNo() {
		return sDeliveryAddrMgtNo;
	}
	/**
	 * @param sDeliveryAddrMgtNo the sDeliveryAddrMgtNo to set
	 */
	public void setsDeliveryAddrMgtNo(String sDeliveryAddrMgtNo) {
		this.sDeliveryAddrMgtNo = sDeliveryAddrMgtNo;
	}
	/**
	 * @return the nDeliveryAddrStdSeq
	 */
	public String getnDeliveryAddrStdSeq() {
		return nDeliveryAddrStdSeq;
	}
	/**
	 * @param nDeliveryAddrStdSeq the nDeliveryAddrStdSeq to set
	 */
	public void setnDeliveryAddrStdSeq(String nDeliveryAddrStdSeq) {
		this.nDeliveryAddrStdSeq = nDeliveryAddrStdSeq;
	}
	/**
	 * @return the sDeliveryOrgZipType
	 */
	public String getsDeliveryOrgZipType() {
		return sDeliveryOrgZipType;
	}
	/**
	 * @param sDeliveryOrgZipType the sDeliveryOrgZipType to set
	 */
	public void setsDeliveryOrgZipType(String sDeliveryOrgZipType) {
		this.sDeliveryOrgZipType = sDeliveryOrgZipType;
	}
	/**
	 * @return the sDeliveryOrgZipCode
	 */
	public String getsDeliveryOrgZipCode() {
		return sDeliveryOrgZipCode;
	}
	/**
	 * @param sDeliveryOrgZipCode the sDeliveryOrgZipCode to set
	 */
	public void setsDeliveryOrgZipCode(String sDeliveryOrgZipCode) {
		this.sDeliveryOrgZipCode = sDeliveryOrgZipCode;
	}
	/**
	 * @return the sDeliveryOrgAddr
	 */
	public String getsDeliveryOrgAddr() {
		return sDeliveryOrgAddr;
	}
	/**
	 * @param sDeliveryOrgAddr the sDeliveryOrgAddr to set
	 */
	public void setsDeliveryOrgAddr(String sDeliveryOrgAddr) {
		this.sDeliveryOrgAddr = sDeliveryOrgAddr;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sResult
	 */
	public String getsResult() {
		return sResult;
	}
	/**
	 * @param sResult the sResult to set
	 */
	public void setsResult(String sResult) {
		this.sResult = sResult;
	}
	
	

}
