/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ����� ���� Wrapper DTO
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insPayPremWrapperDTO")
public class InsPayPremWrapperDTO {
	/** ������� **/
	private List<InsPayCalcPremDTO> PremCalcSpec;
	/** ���Ժ���� **/
	private String nRecpPrem;
	/**����������, ��������ȸ�� **/
	private String nExptFinalSeqMthy;
	/**��������ȸ�� **/
	private String nExptFinalSeq;
	/**
	 * @return the premCalcSpec
	 */
	public List<InsPayCalcPremDTO> getPremCalcSpec() {
		return PremCalcSpec;
	}
	/**
	 * @param premCalcSpec the premCalcSpec to set
	 */
	public void setPremCalcSpec(List<InsPayCalcPremDTO> premCalcSpec) {
		PremCalcSpec = premCalcSpec;
	}
	/**
	 * @return the nRecpPrem
	 */
	public String getnRecpPrem() {
		return nRecpPrem;
	}
	/**
	 * @param nRecpPrem the nRecpPrem to set
	 */
	public void setnRecpPrem(String nRecpPrem) {
		this.nRecpPrem = nRecpPrem;
	}
	/**
	 * @return the nExptFinalSeqMthy
	 */
	public String getnExptFinalSeqMthy() {
		return nExptFinalSeqMthy;
	}
	/**
	 * @param nExptFinalSeqMthy the nExptFinalSeqMthy to set
	 */
	public void setnExptFinalSeqMthy(String nExptFinalSeqMthy) {
		this.nExptFinalSeqMthy = nExptFinalSeqMthy;
	}
	/**
	 * @return the nExptFinalSeq
	 */
	public String getnExptFinalSeq() {
		return nExptFinalSeq;
	}
	/**
	 * @param nExptFinalSeq the nExptFinalSeq to set
	 */
	public void setnExptFinalSeq(String nExptFinalSeq) {
		this.nExptFinalSeq = nExptFinalSeq;
	}

	
	
}
