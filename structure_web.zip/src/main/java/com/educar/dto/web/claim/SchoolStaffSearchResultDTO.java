/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * �б��� �������� ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "schoolStaffSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SchoolStaffSearchResultDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;

	/** �б��� **/
	private String sSchoolName;
	/** �ּ� **/
	private String sAddress;
	/** ������ **/
	private String sStaffName;
	/** ��ȭ��ȣ **/
	private String sOffTel;

	/**
	 * @return the sSchoolName
	 */
	public String getsSchoolName() {
		return sSchoolName;
	}

	/**
	 * @param sSchoolName the sSchoolName to set
	 */
	public void setsSchoolName(final String sSchoolName) {
		this.sSchoolName = sSchoolName;
	}

	/**
	 * @return the sAddress
	 */
	public String getsAddress() {
		return sAddress;
	}

	/**
	 * @param sAddress the sAddress to set
	 */
	public void setsAddress(final String sAddress) {
		this.sAddress = sAddress;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sOffTel
	 */
	public String getsOffTel() {
		return sOffTel;
	}

	/**
	 * @param sOffTel the sOffTel to set
	 */
	public void setsOffTel(final String sOffTel) {
		this.sOffTel = sOffTel;
	}

}
