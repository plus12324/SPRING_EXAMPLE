/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (�г� ���� ����)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfInstallmentInfoDTO")
public class InsuranceCarDetailOfInstallmentInfoDTO {
	/** ����ȣ **/
	private String sPolicyType;
	/** ����ȣ **/
	private String sPolicyYM;
	/** ����ȣ **/
	private String sPolicySer;
	/** �����ڵ� **/
	private String sInsType;
	/** ����ȸ�� **/
	private String nChangeNo;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** �������� (1:��ȸ, 2:�г�, 3:��¡, 4:ȯ��, 0:�Ϲ�, 5: �ؾ�, 6: ���) **/
	private String sCollType;
	/** �������� **/
	private String sLast;
	/** �ڵ���ü���� **/
	private String sBw;
	/** �ѳ����� ȸ�� **/
	private String nInstmNo;
	/** ����ȸ�� **/
	private String nPayNo;
	/** ������ **/
	private String sRectDate;
	/** ���������� (01: ��������, 02:����, 03:�ڵ���ü, 04:����, 05:����, 06:�̼�(���������Ư��))
	 * 02, 03�� ��� �������� '-' ó��
	 */
	private String sRectType;
	/** ��������� **/
	private String nRectPrem;

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}

	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(final String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sCollType
	 */
	public String getsCollType() {
		return sCollType;
	}

	/**
	 * @param sCollType the sCollType to set
	 */
	public void setsCollType(final String sCollType) {
		this.sCollType = sCollType;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @return the sBw
	 */
	public String getsBw() {
		return sBw;
	}

	/**
	 * @param sBw the sBw to set
	 */
	public void setsBw(final String sBw) {
		this.sBw = sBw;
	}

	/**
	 * @return the nInstmNo
	 */
	public String getnInstmNo() {
		return nInstmNo;
	}

	/**
	 * @param nInstmNo the nInstmNo to set
	 */
	public void setnInstmNo(final String nInstmNo) {
		this.nInstmNo = nInstmNo;
	}

	/**
	 * @return the nPayNo
	 */
	public String getnPayNo() {
		return nPayNo;
	}

	/**
	 * @param nPayNo the nPayNo to set
	 */
	public void setnPayNo(final String nPayNo) {
		this.nPayNo = nPayNo;
	}

	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}

	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(final String sRectDate) {
		this.sRectDate = sRectDate;
	}

	/**
	 * @return the sRectType
	 */
	public String getsRectType() {
		return sRectType;
	}

	/**
	 * @param sRectType the sRectType to set
	 */
	public void setsRectType(final String sRectType) {
		this.sRectType = sRectType;
	}

	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}

	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(final String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}

}
