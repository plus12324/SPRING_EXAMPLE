/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCertificationDTO")
public class InsuranceCertificationDTO {
	/** �����ǰ�� **/
	private String sProductName;
	/** ����ȣ **/
	private String sContractNumber;
	/** �Ǻ����� **/
	private String sinsurant;
	/** ����Ⱓ **/
	private String sValidDate;
	/** ���� **/
	private String sProgStat;

	/**
	 * @return the sProductName
	 */
	public String getsProductName() {
		return sProductName;
	}

	/**
	 * @param sProductName the sProductName to set
	 */
	public void setsProductName(String sProductName) {
		this.sProductName = sProductName;
	}

	/**
	 * @return the sContractNumber
	 */
	public String getsContractNumber() {
		return sContractNumber;
	}

	/**
	 * @param sContractNumber the sContractNumber to set
	 */
	public void setsContractNumber(String sContractNumber) {
		this.sContractNumber = sContractNumber;
	}

	/**
	 * @return the sinsurant
	 */
	public String getSinsurant() {
		return sinsurant;
	}

	/**
	 * @param sinsurant the sinsurant to set
	 */
	public void setSinsurant(String sinsurant) {
		this.sinsurant = sinsurant;
	}

	/**
	 * @return the sValidDate
	 */
	public String getsValidDate() {
		return sValidDate;
	}

	/**
	 * @param sValidDate the sValidDate to set
	 */
	public void setsValidDate(String sValidDate) {
		this.sValidDate = sValidDate;
	}

	/**
	 * @return the sProgStat
	 */
	public String getsProgStat() {
		return sProgStat;
	}

	/**
	 * @param sProgStat the sProgStat to set
	 */
	public void setsProgStat(String sProgStat) {
		this.sProgStat = sProgStat;
	}
}
