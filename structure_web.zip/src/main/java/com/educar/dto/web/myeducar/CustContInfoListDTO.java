/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "custContInfoListDTO")
public class CustContInfoListDTO {
	
	/**	����ȣ	**/
	private String sCrNo;
	/**	�ֹι�ȣ	**/
	private String sCrtorCd;
	/**	����ȸ��	**/
	private String nLastEndorseNo;
	/**	�ִ�ȸ��	**/
	private String nMaxEndorseNo;
	/**	������ �輭��	**/
	private String sLastEndorseDate;
	/**	����ڸ�	**/
	private String sCrtorName;
	/**	��Ʈ ���� flag	**/
	private String sInsurFlag;
	/**	��������	**/
	private String sTodt;
	/**	����ڹ�ȣ	**/
	private String sCustNo;
	/** �ּ�Ÿ�� **/
	private String sAdrsType;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}
	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}
	/**
	 * @return the nLastEndorseNo
	 */
	public String getnLastEndorseNo() {
		return nLastEndorseNo;
	}
	/**
	 * @param nLastEndorseNo the nLastEndorseNo to set
	 */
	public void setnLastEndorseNo(String nLastEndorseNo) {
		this.nLastEndorseNo = nLastEndorseNo;
	}
	/**
	 * @return the nMaxEndorseNo
	 */
	public String getnMaxEndorseNo() {
		return nMaxEndorseNo;
	}
	/**
	 * @param nMaxEndorseNo the nMaxEndorseNo to set
	 */
	public void setnMaxEndorseNo(String nMaxEndorseNo) {
		this.nMaxEndorseNo = nMaxEndorseNo;
	}
	/**
	 * @return the sLastEndorseDate
	 */
	public String getsLastEndorseDate() {
		return sLastEndorseDate;
	}
	/**
	 * @param sLastEndorseDate the sLastEndorseDate to set
	 */
	public void setsLastEndorseDate(String sLastEndorseDate) {
		this.sLastEndorseDate = sLastEndorseDate;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sInsurFlag
	 */
	public String getsInsurFlag() {
		return sInsurFlag;
	}
	/**
	 * @param sInsurFlag the sInsurFlag to set
	 */
	public void setsInsurFlag(String sInsurFlag) {
		this.sInsurFlag = sInsurFlag;
	}
	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}
	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}
	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}

}
