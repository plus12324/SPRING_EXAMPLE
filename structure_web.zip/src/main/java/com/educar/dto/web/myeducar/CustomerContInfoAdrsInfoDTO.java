/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���輭�ּ�����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "customerContInfoAdrsEndorseDTO")
public class CustomerContInfoAdrsInfoDTO {
	/**	�ֹι�ȣ	"**/
	private String sCustNo;
	/**	����	"**/
	private String nSeqNo;
	/**	�⺻ �ּ�Ÿ��	"**/
	private String sAdrsType;
	/**	�⺻ ����ȸ��	"**/
	private String nAdrsSeq;
	/**	�߼��� �ּ�Ÿ��	"**/
	private String sSendType;
	/**	�߼��� ����ȸ��	"**/
	private String nSendSeq;
	/**	�⺻ ������ȣ1	"**/
	private String sZip1;
	/**	�⺻ ������ȣ2	"**/
	private String sZip2;
	/** ��߱� ��û����		**/
	private String sPrintDateForWeb;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}
	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}
	/**
	 * @return the nAdrsSeq
	 */
	public String getnAdrsSeq() {
		return nAdrsSeq;
	}
	/**
	 * @param nAdrsSeq the nAdrsSeq to set
	 */
	public void setnAdrsSeq(String nAdrsSeq) {
		this.nAdrsSeq = nAdrsSeq;
	}
	/**
	 * @return the sSendType
	 */
	public String getsSendType() {
		return sSendType;
	}
	/**
	 * @param sSendType the sSendType to set
	 */
	public void setsSendType(String sSendType) {
		this.sSendType = sSendType;
	}
	/**
	 * @return the nSendSeq
	 */
	public String getnSendSeq() {
		return nSendSeq;
	}
	/**
	 * @param nSendSeq the nSendSeq to set
	 */
	public void setnSendSeq(String nSendSeq) {
		this.nSendSeq = nSendSeq;
	}
	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}
	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}
	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}
	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}
	/**
	 * @return the sPrintDateForWeb
	 */
	public String getsPrintDateForWeb() {
		return sPrintDateForWeb;
	}
	/**
	 * @param sPrintDateForWeb the sPrintDateForWeb to set
	 */
	public void setsPrintDateForWeb(String sPrintDateForWeb) {
		this.sPrintDateForWeb = sPrintDateForWeb;
	}

}
