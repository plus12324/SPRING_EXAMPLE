/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * �����ڽ����� ���� > �����ڽ����� ��� DTO
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carBlackBoxReceiptInsertPhotoDTO")
public class CarBlackBoxReceiptInsertPhotoDTO {
	/** ����Ÿ�� 1:�������ڽ����� 2:�˾������ڽ����� **/
	private String sReceiveType;
	/** �����ڽ� �˾����� ����ϴ� û���ȣ**/
	private String sPolicyNo;
	/** ���� Ÿ�� 1: ����, 2: ���� **/
	private String sCustType;
	/** �ֹε�� ��ȣ �Ǵ� ����� ��ȣ **/
	private String sCustNo;
	/** E2E �ֹε�� ��ȣ �Ǵ� ����� ��ȣ **/
	@BeanUtil(ignore = true)
	private String sCustNo1;
	/** E2E �ֹε�� ��ȣ �Ǵ� ����� ��ȣ **/
	@BeanUtil(ignore = true)
	private String sCustNo2;
	/** ��½�ť�� Ű���庸�� ��ȣȭ Ű */
	@BeanUtil(ignore = true)
	private String sHid_key_data;
	/** ���� �̸� **/
	private String sName;
	/** ���� ��ȣ **/
	private String sPlateNo;
	/** �����ڽ� ������� **/
	private String sBlackCompNm;
	/** �����ڽ� ��ǰ�� **/
	private String sBlackProdNm;
	/** �����ڽ� S/N **/
	private String sBlackSer;
	/** �Է���IP **/
	private String sIP;
	/** ����ID ����Ʈ **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "fileIDList")
	private List<String> fileID;
	
	public String getsCustNo1() {
		return sCustNo1;
	}
	public void setsCustNo1(String sCustNo1) {
		this.sCustNo1 = sCustNo1;
	}
	public String getsCustNo2() {
		return sCustNo2;
	}
	public void setsCustNo2(String sCustNo2) {
		this.sCustNo2 = sCustNo2;
	}
	public String getsHid_key_data() {
		return sHid_key_data;
	}
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}
	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}
	/**
	 * @return the sReceiveType
	 */
	public String getsReceiveType() {
		return sReceiveType;
	}
	/**
	 * @param sReceiveType the sReceiveType to set
	 */
	public void setsReceiveType(String sReceiveType) {
		this.sReceiveType = sReceiveType;
	}
	
	public String getsBlackCompNm() {
		return sBlackCompNm;
	}
	public void setsBlackCompNm(String sBlackCompNm) {
		this.sBlackCompNm = sBlackCompNm;
	}
	public String getsBlackProdNm() {
		return sBlackProdNm;
	}
	public void setsBlackProdNm(String sBlackProdNm) {
		this.sBlackProdNm = sBlackProdNm;
	}
	public String getsBlackSer() {
		return sBlackSer;
	}
	public void setsBlackSer(String sBlackSer) {
		this.sBlackSer = sBlackSer;
	}
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(String sCustType) {
		this.sCustType = sCustType;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}
	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}
	/**
	 * @return the sIP
	 */
	public String getsIP() {
		return sIP;
	}
	/**
	 * @param sIP the sIP to set
	 */
	public void setsIP(String sIP) {
		this.sIP = sIP;
	}
	/**
	 * @return the fileID
	 */
	public List<String> getFileID() {
		return fileID;
	}
	/**
	 * @param fileID the fileID to set
	 */
	public void setFileID(List<String> fileID) {
		this.fileID = fileID;
	}
}
