/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetailOfContDetailList01DTO")
public class InsuranceGeneralDetailOfContDetailList01DTO {
	/** ���ǹ�ȣŸ�� **/
	private String sPolicyType;
	/** ���ǹ�ȣ�����ڵ� **/
	private String sPolicyKind;
	/** �����Ϸù�ȣ **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ����Ƚ�� **/
	private String nPayNo;
	/** ����ȣ **/
	private String sContNumber;
	/** �����ǰ�� **/
	private String sInsPdtName;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** ����ñ� **/
	private String sInsCtrTpd;
	/** �������� **/
	private String sInsCtrPed;
	/** ��ǰ���� �ѱ۸� (������, �⺻��, ������) **/
	private String sPdtType;
	/** �������� �ѱ۸� (������, �κ���) **/
	private String sEtnTypNam;
	/** �г���� �ѱ۸� (�Ͻó�, 12�г�, 36�г�) **/
	private String sPytMthNam;
	/** �г���� (01:�Ͻó�, 12:12�г�, 36:36�г�) **/
	private String sPayMth;
	/** ������ �ѱ۸� (����, ��ȿ, ����, ���) **/
	private String sContStaName;
	/** ��ǰ���� (A : ������, B : �⺻��, C : ������) **/
	private String sPlnCod;
	/** �������� (10 : ������, 20 : �κ���) **/
	private String sEtnTyp;
	/** ������ (0 ����, 1 ��ȿ, 2 ����(öȸ����) 3 ���(��ȿ����)) **/
	private String sCtrSta;
	/** ����ڸ� **/
	private String sPolHolderName;
	/** ������� **/
	private String sPolicyDate;
	/** ��� **/
	private String nYearCnt;

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyKind
	 */
	public String getsPolicyKind() {
		return sPolicyKind;
	}

	/**
	 * @param sPolicyKind the sPolicyKind to set
	 */
	public void setsPolicyKind(final String sPolicyKind) {
		this.sPolicyKind = sPolicyKind;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the nPayNo
	 */
	public String getnPayNo() {
		return nPayNo;
	}

	/**
	 * @param nPayNo the nPayNo to set
	 */
	public void setnPayNo(final String nPayNo) {
		this.nPayNo = nPayNo;
	}

	/**
	 * @return the sContNumber
	 */
	public String getsContNumber() {
		return sContNumber;
	}

	/**
	 * @param sContNumber the sContNumber to set
	 */
	public void setsContNumber(final String sContNumber) {
		this.sContNumber = sContNumber;
	}

	/**
	 * @return the sInsPdtName
	 */
	public String getsInsPdtName() {
		return sInsPdtName;
	}

	/**
	 * @param sInsPdtName the sInsPdtName to set
	 */
	public void setsInsPdtName(final String sInsPdtName) {
		this.sInsPdtName = sInsPdtName;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsCtrTpd
	 */
	public String getsInsCtrTpd() {
		return sInsCtrTpd;
	}

	/**
	 * @param sInsCtrTpd the sInsCtrTpd to set
	 */
	public void setsInsCtrTpd(final String sInsCtrTpd) {
		this.sInsCtrTpd = sInsCtrTpd;
	}

	/**
	 * @return the sInsCtrPed
	 */
	public String getsInsCtrPed() {
		return sInsCtrPed;
	}

	/**
	 * @param sInsCtrPed the sInsCtrPed to set
	 */
	public void setsInsCtrPed(final String sInsCtrPed) {
		this.sInsCtrPed = sInsCtrPed;
	}

	/**
	 * @return the sPdtType
	 */
	public String getsPdtType() {
		return sPdtType;
	}

	/**
	 * @param sPdtType the sPdtType to set
	 */
	public void setsPdtType(final String sPdtType) {
		this.sPdtType = sPdtType;
	}

	/**
	 * @return the sEtnTypNam
	 */
	public String getsEtnTypNam() {
		return sEtnTypNam;
	}

	/**
	 * @param sEtnTypNam the sEtnTypNam to set
	 */
	public void setsEtnTypNam(final String sEtnTypNam) {
		this.sEtnTypNam = sEtnTypNam;
	}

	/**
	 * @return the sPytMthNam
	 */
	public String getsPytMthNam() {
		return sPytMthNam;
	}

	/**
	 * @param sPytMthNam the sPytMthNam to set
	 */
	public void setsPytMthNam(final String sPytMthNam) {
		this.sPytMthNam = sPytMthNam;
	}

	/**
	 * @return the sPayMth
	 */
	public String getsPayMth() {
		return sPayMth;
	}

	/**
	 * @param sPayMth the sPayMth to set
	 */
	public void setsPayMth(final String sPayMth) {
		this.sPayMth = sPayMth;
	}

	/**
	 * @return the sContStaName
	 */
	public String getsContStaName() {
		return sContStaName;
	}

	/**
	 * @param sContStaName the sContStaName to set
	 */
	public void setsContStaName(final String sContStaName) {
		this.sContStaName = sContStaName;
	}

	/**
	 * @return the sPlnCod
	 */
	public String getsPlnCod() {
		return sPlnCod;
	}

	/**
	 * @param sPlnCod the sPlnCod to set
	 */
	public void setsPlnCod(final String sPlnCod) {
		this.sPlnCod = sPlnCod;
	}

	/**
	 * @return the sEtnTyp
	 */
	public String getsEtnTyp() {
		return sEtnTyp;
	}

	/**
	 * @param sEtnTyp the sEtnTyp to set
	 */
	public void setsEtnTyp(final String sEtnTyp) {
		this.sEtnTyp = sEtnTyp;
	}

	/**
	 * @return the sCtrSta
	 */
	public String getsCtrSta() {
		return sCtrSta;
	}

	/**
	 * @param sCtrSta the sCtrSta to set
	 */
	public void setsCtrSta(final String sCtrSta) {
		this.sCtrSta = sCtrSta;
	}

	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}

	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(final String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}

	/**
	 * @return the sPolicyDate
	 */
	public String getsPolicyDate() {
		return sPolicyDate;
	}

	/**
	 * @param sPolicyDate the sPolicyDate to set
	 */
	public void setsPolicyDate(final String sPolicyDate) {
		this.sPolicyDate = sPolicyDate;
	}

	/**
	 * @return the nYearCnt
	 */
	public String getnYearCnt() {
		return nYearCnt;
	}

	/**
	 * @param nYearCnt the nYearCnt to set
	 */
	public void setnYearCnt(final String nYearCnt) {
		this.nYearCnt = nYearCnt;
	}

}
