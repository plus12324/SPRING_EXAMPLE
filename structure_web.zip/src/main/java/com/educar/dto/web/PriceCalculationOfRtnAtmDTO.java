/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * @author ���ѳ�
 *
 */
public class PriceCalculationOfRtnAtmDTO {
	/** 	����  	**/ 
	private String 	nSeqno;
	/** 	����ȯ�ް���Ⱓ	**/ 
	private String 	sCnclRtnrtPassPrd;
	/** 	���Ժ����	**/ 
	private String 	nPaymPrem;
	/** 	����ȯ�ޱݾ�	**/ 
	private String 	nLowRtnAmt;
	/** 	����ȯ����	**/ 
	private String 	nLowRtnRato;
	/** 	ǥ��ȯ�ޱݾ�	**/ 
	private String 	nStndRtnAmt;
	/** 	ǥ��ȯ����	**/ 
	private String 	nStndRtnRato;
	/** 	����ȯ�ޱݾ�	**/ 
	private String 	nStndRtnAmt12;
	/** 	����ȯ����	**/
	private String 	nStndRtnRato12;
	/**
	 * @return the nSeqno
	 */
	public String getnSeqno() {
		return nSeqno;
	}
	/**
	 * @param nSeqno the nSeqno to set
	 */
	public void setnSeqno(String nSeqno) {
		this.nSeqno = nSeqno;
	}
	/**
	 * @return the sCnclRtnrtPassPrd
	 */
	public String getsCnclRtnrtPassPrd() {
		return sCnclRtnrtPassPrd;
	}
	/**
	 * @param sCnclRtnrtPassPrd the sCnclRtnrtPassPrd to set
	 */
	public void setsCnclRtnrtPassPrd(String sCnclRtnrtPassPrd) {
		this.sCnclRtnrtPassPrd = sCnclRtnrtPassPrd;
	}
	/**
	 * @return the nPaymPrem
	 */
	public String getnPaymPrem() {
		return nPaymPrem;
	}
	/**
	 * @param nPaymPrem the nPaymPrem to set
	 */
	public void setnPaymPrem(String nPaymPrem) {
		this.nPaymPrem = nPaymPrem;
	}
	/**
	 * @return the nLowRtnAmt
	 */
	public String getnLowRtnAmt() {
		return nLowRtnAmt;
	}
	/**
	 * @param nLowRtnAmt the nLowRtnAmt to set
	 */
	public void setnLowRtnAmt(String nLowRtnAmt) {
		this.nLowRtnAmt = nLowRtnAmt;
	}
	/**
	 * @return the nLowRtnRato
	 */
	public String getnLowRtnRato() {
		return nLowRtnRato;
	}
	/**
	 * @param nLowRtnRato the nLowRtnRato to set
	 */
	public void setnLowRtnRato(String nLowRtnRato) {
		this.nLowRtnRato = nLowRtnRato;
	}
	/**
	 * @return the nStndRtnAmt
	 */
	public String getnStndRtnAmt() {
		return nStndRtnAmt;
	}
	/**
	 * @param nStndRtnAmt the nStndRtnAmt to set
	 */
	public void setnStndRtnAmt(String nStndRtnAmt) {
		this.nStndRtnAmt = nStndRtnAmt;
	}
	/**
	 * @return the nStndRtnRato
	 */
	public String getnStndRtnRato() {
		return nStndRtnRato;
	}
	/**
	 * @param nStndRtnRato the nStndRtnRato to set
	 */
	public void setnStndRtnRato(String nStndRtnRato) {
		this.nStndRtnRato = nStndRtnRato;
	}
	/**
	 * @return the nStndRtnAmt12
	 */
	public String getnStndRtnAmt12() {
		return nStndRtnAmt12;
	}
	/**
	 * @param nStndRtnAmt12 the nStndRtnAmt12 to set
	 */
	public void setnStndRtnAmt12(String nStndRtnAmt12) {
		this.nStndRtnAmt12 = nStndRtnAmt12;
	}
	/**
	 * @return the nStndRtnRato12
	 */
	public String getnStndRtnRato12() {
		return nStndRtnRato12;
	}
	/**
	 * @param nStndRtnRato12 the nStndRtnRato12 to set
	 */
	public void setnStndRtnRato12(String nStndRtnRato12) {
		this.nStndRtnRato12 = nStndRtnRato12;
	}
	
	
	

}
