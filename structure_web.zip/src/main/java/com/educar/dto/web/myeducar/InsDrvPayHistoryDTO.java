/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���Գ��� DTO
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayHistoryDTO")
public class InsDrvPayHistoryDTO {
	private InsDrvPayList01DTO RectList01;
	private List<InsDrvPayList02DTO> RectList02;
	/**
	 * @return the rectList01
	 */
	public InsDrvPayList01DTO getRectList01() {
		return RectList01;
	}
	/**
	 * @param rectList01 the rectList01 to set
	 */
	public void setRectList01(InsDrvPayList01DTO rectList01) {
		RectList01 = rectList01;
	}
	/**
	 * @return the rectList02
	 */
	public List<InsDrvPayList02DTO> getRectList02() {
		return RectList02;
	}
	/**
	 * @param rectList02 the rectList02 to set
	 */
	public void setRectList02(List<InsDrvPayList02DTO> rectList02) {
		RectList02 = rectList02;
	}
	
	
	
}
