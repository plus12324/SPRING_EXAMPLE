/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���Ⱑ�ɱݾ�
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insloansavaliablePayDTO")
public class InsloansavaliablePayDTO {
	/**	�Ӽ������ڵ�	 **/ 
	private String 	sAttrFlagCd	;
	/**	�Ӽ���	 **/ 
	private String 	sAttrName	;
	/**	�������ڵ�	 **/ 
	private String 	sCrStatCd	;
	/**	����ȣ	 **/ 
	private String 	sCrNo	;
	/**	������ڵ�	 **/ 
	private String 	sCrtorCd	;
	/**	Ŭ�����ڵ�	 **/ 
	private String 	sClsfCd	;
	/**	�����	 **/ 
	private String 	sCrtorName;
	/**	�����ǰ��	 **/ 
	private String 	sGdName;
	/**	��������	 **/ 
	private String 	sInsurStdt;
	/**	���������	 **/ 
	private String 	sInsurEddt;
	/**	����	 **/ 
	private String 	sCrStat;
	/**	�����	 **/ 
	private String 	nApplPrem;
	/**	�ѳ��Ժ����	 **/ 
	private String 	nTotPaymPrem;
	/**	������	 **/ 
	private String 	nStmpTaxAmt;
	/**	������ܾ�	 **/ 
	private String 	nPlonBaln;
	/**	�ؾ�ȯ�ޱ�	 **/ 
	private String 	nCnclRtnAmt;
	/**	���Ⱑ�ɾ�	 **/ 
	private String 	nLoanAvaAmt;
	/**	��������	 **/ 
	private String 	sPymLmit;
	/**	��������	 **/ 
	private String 	nLoanRato;
	/**	���δ�ü�����ڵ�	 **/ 
	private String 	sPsnGroupFlgcd;
	/**
	 * @return the sAttrFlagCd
	 */
	public String getsAttrFlagCd() {
		return sAttrFlagCd;
	}
	/**
	 * @param sAttrFlagCd the sAttrFlagCd to set
	 */
	public void setsAttrFlagCd(String sAttrFlagCd) {
		this.sAttrFlagCd = sAttrFlagCd;
	}
	/**
	 * @return the sAttrName
	 */
	public String getsAttrName() {
		return sAttrName;
	}
	/**
	 * @param sAttrName the sAttrName to set
	 */
	public void setsAttrName(String sAttrName) {
		this.sAttrName = sAttrName;
	}
	/**
	 * @return the sCrStatCd
	 */
	public String getsCrStatCd() {
		return sCrStatCd;
	}
	/**
	 * @param sCrStatCd the sCrStatCd to set
	 */
	public void setsCrStatCd(String sCrStatCd) {
		this.sCrStatCd = sCrStatCd;
	}
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}
	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}
	/**
	 * @return the sClsfCd
	 */
	public String getsClsfCd() {
		return sClsfCd;
	}
	/**
	 * @param sClsfCd the sClsfCd to set
	 */
	public void setsClsfCd(String sClsfCd) {
		this.sClsfCd = sClsfCd;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sGdName
	 */
	public String getsGdName() {
		return sGdName;
	}
	/**
	 * @param sGdName the sGdName to set
	 */
	public void setsGdName(String sGdName) {
		this.sGdName = sGdName;
	}
	/**
	 * @return the sInsurStdt
	 */
	public String getsInsurStdt() {
		return sInsurStdt;
	}
	/**
	 * @param sInsurStdt the sInsurStdt to set
	 */
	public void setsInsurStdt(String sInsurStdt) {
		this.sInsurStdt = sInsurStdt;
	}
	/**
	 * @return the sInsurEddt
	 */
	public String getsInsurEddt() {
		return sInsurEddt;
	}
	/**
	 * @param sInsurEddt the sInsurEddt to set
	 */
	public void setsInsurEddt(String sInsurEddt) {
		this.sInsurEddt = sInsurEddt;
	}
	/**
	 * @return the sCrStat
	 */
	public String getsCrStat() {
		return sCrStat;
	}
	/**
	 * @param sCrStat the sCrStat to set
	 */
	public void setsCrStat(String sCrStat) {
		this.sCrStat = sCrStat;
	}
	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}
	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}
	/**
	 * @return the nTotPaymPrem
	 */
	public String getnTotPaymPrem() {
		return nTotPaymPrem;
	}
	/**
	 * @param nTotPaymPrem the nTotPaymPrem to set
	 */
	public void setnTotPaymPrem(String nTotPaymPrem) {
		this.nTotPaymPrem = nTotPaymPrem;
	}
	/**
	 * @return the nStmpTaxAmt
	 */
	public String getnStmpTaxAmt() {
		return nStmpTaxAmt;
	}
	/**
	 * @param nStmpTaxAmt the nStmpTaxAmt to set
	 */
	public void setnStmpTaxAmt(String nStmpTaxAmt) {
		this.nStmpTaxAmt = nStmpTaxAmt;
	}
	/**
	 * @return the nPlonBaln
	 */
	public String getnPlonBaln() {
		return nPlonBaln;
	}
	/**
	 * @param nPlonBaln the nPlonBaln to set
	 */
	public void setnPlonBaln(String nPlonBaln) {
		this.nPlonBaln = nPlonBaln;
	}
	/**
	 * @return the nCnclRtnAmt
	 */
	public String getnCnclRtnAmt() {
		return nCnclRtnAmt;
	}
	/**
	 * @param nCnclRtnAmt the nCnclRtnAmt to set
	 */
	public void setnCnclRtnAmt(String nCnclRtnAmt) {
		this.nCnclRtnAmt = nCnclRtnAmt;
	}
	/**
	 * @return the nLoanAvaAmt
	 */
	public String getnLoanAvaAmt() {
		return nLoanAvaAmt;
	}
	/**
	 * @param nLoanAvaAmt the nLoanAvaAmt to set
	 */
	public void setnLoanAvaAmt(String nLoanAvaAmt) {
		this.nLoanAvaAmt = nLoanAvaAmt;
	}
	/**
	 * @return the sPymLmit
	 */
	public String getsPymLmit() {
		return sPymLmit;
	}
	/**
	 * @param sPymLmit the sPymLmit to set
	 */
	public void setsPymLmit(String sPymLmit) {
		this.sPymLmit = sPymLmit;
	}
	/**
	 * @return the nLoanRato
	 */
	public String getnLoanRato() {
		return nLoanRato;
	}
	/**
	 * @param nLoanRato the nLoanRato to set
	 */
	public void setnLoanRato(String nLoanRato) {
		this.nLoanRato = nLoanRato;
	}
	/**
	 * @return the sPsnGroupFlgcd
	 */
	public String getsPsnGroupFlgcd() {
		return sPsnGroupFlgcd;
	}
	/**
	 * @param sPsnGroupFlgcd the sPsnGroupFlgcd to set
	 */
	public void setsPsnGroupFlgcd(String sPsnGroupFlgcd) {
		this.sPsnGroupFlgcd = sPsnGroupFlgcd;
	}
	
}
