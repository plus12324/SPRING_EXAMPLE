/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Ư��/����������� - ���ϸ���������� - ���꿩��
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mileSpecDistanceDTO")
public class MileSpecDistanceDTO {
	/** ���ϸ��� ��û����	 **/ 
	private String 	sRegMile;
	/** ����Ⱓ	**/ 
	private String 	sTotDay;
	/** ����Ÿ�	**/ 
	private String 	sTotCaseMile;
	/** �Ϻ� ��������Ÿ�	**/ 
	private String 	sTotMile;
	/** �Ϻ� ��������Ÿ�	 **/ 
	private String 	sContractMile;
	/** ���� ���ϸ���	**/ 
	private String 	sApplyMile;
	/** ������	**/ 
	private String 	sApplyResult;
	/** ������Ÿ�	 **/ 
	private String 	sRealMile;
	/** ��������Ÿ�	**/ 
	private String 	sPolicySpecCode;
	/** ��������Ÿ� �ڵ�� **/
	private String  sPolicySpecName;
	/** ���꿩��	**/ 
	private String 	sAcctResult;
	/** ��ü�湮	 **/ 
	private String 	isMaster;
	/** ��ȸ�����	 **/ 
	private String 	result;
	/** �����ڵ�	 **/ 
	private String 	sErrCode;
	/** �����޽���**/ 
	private String 	sErrMsg;
	public String getsRegMile() {
		return sRegMile;
	}
	public void setsRegMile(String sRegMile) {
		this.sRegMile = sRegMile;
	}
	public String getsTotDay() {
		return sTotDay;
	}
	public void setsTotDay(String sTotDay) {
		this.sTotDay = sTotDay;
	}
	public String getsTotCaseMile() {
		return sTotCaseMile;
	}
	public void setsTotCaseMile(String sTotCaseMile) {
		this.sTotCaseMile = sTotCaseMile;
	}
	public String getsTotMile() {
		return sTotMile;
	}
	public void setsTotMile(String sTotMile) {
		this.sTotMile = sTotMile;
	}
	public String getsContractMile() {
		return sContractMile;
	}
	public void setsContractMile(String sContractMile) {
		this.sContractMile = sContractMile;
	}
	public String getsApplyMile() {
		return sApplyMile;
	}
	public void setsApplyMile(String sApplyMile) {
		this.sApplyMile = sApplyMile;
	}
	public String getsApplyResult() {
		return sApplyResult;
	}
	public void setsApplyResult(String sApplyResult) {
		this.sApplyResult = sApplyResult;
	}
	public String getsRealMile() {
		return sRealMile;
	}
	public void setsRealMile(String sRealMile) {
		this.sRealMile = sRealMile;
	}
	public String getsPolicySpecCode() {
		return sPolicySpecCode;
	}
	public void setsPolicySpecCode(String sPolicySpecCode) {
		this.sPolicySpecCode = sPolicySpecCode;
	}
	public String getsPolicySpecName() {
		return sPolicySpecName;
	}
	public void setsPolicySpecName(String sPolicySpecName) {
		this.sPolicySpecName = sPolicySpecName;
	}
	public String getsAcctResult() {
		return sAcctResult;
	}
	public void setsAcctResult(String sAcctResult) {
		this.sAcctResult = sAcctResult;
	}
	public String getIsMaster() {
		return isMaster;
	}
	public void setIsMaster(String isMaster) {
		this.isMaster = isMaster;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getsErrCode() {
		return sErrCode;
	}
	public void setsErrCode(String sErrCode) {
		this.sErrCode = sErrCode;
	}
	public String getsErrMsg() {
		return sErrMsg;
	}
	public void setsErrMsg(String sErrMsg) {
		this.sErrMsg = sErrMsg;
	}
	
	
}
