/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���������� �������� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "paymentListForWEBResultDTO")
public class PaymentListForWEBResultDTO {
	/** ����ȣ(ȭ��ǥ�ÿ�) **/
	private String sPolicyNo;
	/** ����ȣ **/
	private String sPolicyType;
	/** ����ȣ **/
	private String sPolicyYM;
	/** ����ȣ **/
	private String sPolicySer;
	/** �����輭��ȣ **/
	private String nLastEndorseNo;
	/** ���������ڵ� **/
	private String sInsType;
	/** ��������� **/
	private String sInsTypeName;
	/** ������ **/
	private String sPlateNo;
	/** ���� **/
	private String sPolHolderRel;
	/** ����� **/
	private String sPolHolderRelName;
	/** �Ǻ�����ID **/
	private String sInsrdID;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** ����ڸ� **/
	private String sPolHolderName;
	/** ��������� **/
	private String sFmdt;
	/** ���������� **/
	private String sTodt;
	/** ����Ⱓ(ȭ��ǥ�ÿ�) **/
	private String insrPeriod;
	/** ���Թ�� **/
	private String nInstmNo;
	/** ����ȸ�� **/
	private String nAutoPayNo;
	/** ������ **/
	private String sAutoRectDate;
	/** ���Աݾ� **/
	private String nRectPrem;

	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}

	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(final String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nLastEndorseNo
	 */
	public String getnLastEndorseNo() {
		return nLastEndorseNo;
	}

	/**
	 * @param nLastEndorseNo the nLastEndorseNo to set
	 */
	public void setnLastEndorseNo(final String nLastEndorseNo) {
		this.nLastEndorseNo = nLastEndorseNo;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}

	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(final String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sPolHolderRel
	 */
	public String getsPolHolderRel() {
		return sPolHolderRel;
	}

	/**
	 * @param sPolHolderRel the sPolHolderRel to set
	 */
	public void setsPolHolderRel(final String sPolHolderRel) {
		this.sPolHolderRel = sPolHolderRel;
	}

	/**
	 * @return the sPolHolderRelName
	 */
	public String getsPolHolderRelName() {
		return sPolHolderRelName;
	}

	/**
	 * @param sPolHolderRelName the sPolHolderRelName to set
	 */
	public void setsPolHolderRelName(final String sPolHolderRelName) {
		this.sPolHolderRelName = sPolHolderRelName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}

	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(final String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the insrPeriod
	 */
	public String getInsrPeriod() {
		return insrPeriod;
	}

	/**
	 * @param insrPeriod the insrPeriod to set
	 */
	public void setInsrPeriod(final String insrPeriod) {
		this.insrPeriod = insrPeriod;
	}

	/**
	 * @return the nInstmNo
	 */
	public String getnInstmNo() {
		return nInstmNo;
	}

	/**
	 * @param nInstmNo the nInstmNo to set
	 */
	public void setnInstmNo(final String nInstmNo) {
		this.nInstmNo = nInstmNo;
	}

	/**
	 * @return the nAutoPayNo
	 */
	public String getnAutoPayNo() {
		return nAutoPayNo;
	}

	/**
	 * @param nAutoPayNo the nAutoPayNo to set
	 */
	public void setnAutoPayNo(final String nAutoPayNo) {
		this.nAutoPayNo = nAutoPayNo;
	}

	/**
	 * @return the sAutoRectDate
	 */
	public String getsAutoRectDate() {
		return sAutoRectDate;
	}

	/**
	 * @param sAutoRectDate the sAutoRectDate to set
	 */
	public void setsAutoRectDate(final String sAutoRectDate) {
		this.sAutoRectDate = sAutoRectDate;
	}

	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}

	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(final String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}

}
