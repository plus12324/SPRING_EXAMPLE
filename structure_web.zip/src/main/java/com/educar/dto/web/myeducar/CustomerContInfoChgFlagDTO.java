/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���輭�ּ�����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "customerContInfoChgFlagDTO")
public class CustomerContInfoChgFlagDTO {
	/** ���� Flag���� **/
	//�����ּ�
	private String homeFlag;
	//�����ּ�
	private String officeFlag;
	//��Ÿ�ּ�
	private String etcFlag;
	//��ȭ��ȣ
	private String telFlag;
	
	/** ����� **/
	private String userID;

	/**
	 * @return the homeFlag
	 */
	public String getHomeFlag() {
		return homeFlag;
	}

	/**
	 * @param homeFlag the homeFlag to set
	 */
	public void setHomeFlag(String homeFlag) {
		this.homeFlag = homeFlag;
	}

	/**
	 * @return the officeFlag
	 */
	public String getOfficeFlag() {
		return officeFlag;
	}

	/**
	 * @param officeFlag the officeFlag to set
	 */
	public void setOfficeFlag(String officeFlag) {
		this.officeFlag = officeFlag;
	}

	/**
	 * @return the etcFlag
	 */
	public String getEtcFlag() {
		return etcFlag;
	}

	/**
	 * @param etcFlag the etcFlag to set
	 */
	public void setEtcFlag(String etcFlag) {
		this.etcFlag = etcFlag;
	}

	/**
	 * @return the telFlag
	 */
	public String getTelFlag() {
		return telFlag;
	}

	/**
	 * @param telFlag the telFlag to set
	 */
	public void setTelFlag(String telFlag) {
		this.telFlag = telFlag;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	
}
