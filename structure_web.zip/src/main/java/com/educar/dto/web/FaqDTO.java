/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * ���ֹ������� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name="faqDTO")
public class FaqDTO extends PageDTO {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** �Ϸù�ȣ */
	private Integer nSeq; 
	/** ī�װ��� */
	private String sCatCd;
	/** ���� */
	private String sTitle;
	/** ���� */
	private String sContent; 
	/** ��������(Y : ����, N : �̰���) */
	private String sViewYn;
	/** ��ü��������(Y : ���, N : �Ϲ�) */
	private String sTopYn;
	/** �˻��±� */
	private String sTag;
	/** Ŭ���� */
	private String sVisitCnt;
	/** ������ */
	private String sRegId; 
	/** ������¥(YYYYMMDD) */
	private String sRegDate; 
	/** �����ð�(HHMMSS) */
	private String sRegTime; 
	/** ������ */
	private String sUpId; 
	/** ������¥(YYYYMMDD) */
	private String sUpDate; 
	/** �����ð�(HHMMSS) */
	private String sUpTime; 
	/** �˻��� */
	private String searchKey;
	
	/** ��ȸ�� */
	private String nVisitCnt;
	
	/** ī�װ����� */
	private String sCatNm;
	
	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/
	@XmlTransient
	private String kind;
	/** �˻��� (�����ڿ��� ���) **/
	@XmlTransient
	private String searchValue;
	/** ī�װ��� (�����ڿ��� ���) **/
	@XmlTransient
	private String searchCatCd;
	/** �޴� ����Ʈ(�����ڿ��� ���) **/
	@XmlTransient
	private List<FaqDTO> menuList;

	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(Integer nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sCatCd
	 */
	public String getsCatCd() {
		return sCatCd;
	}
	/**
	 * @param sCatCd the sCatCd to set
	 */
	public void setsCatCd(String sCatCd) {
		this.sCatCd = sCatCd;
	}
	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}
	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}
	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(String sContent) {
		this.sContent = sContent;
	}
	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}
	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}
	/**
	 * @return the sTopYn
	 */
	public String getsTopYn() {
		return sTopYn;
	}
	/**
	 * @param sTopYn the sTopYn to set
	 */
	public void setsTopYn(String sTopYn) {
		this.sTopYn = sTopYn;
	}
	/**
	 * @return the sTag
	 */
	public String getsTag() {
		return sTag;
	}
	/**
	 * @param sTag the sTag to set
	 */
	public void setsTag(String sTag) {
		this.sTag = sTag;
	}
	/**
	 * @return the sVisitCnt
	 */
	public String getsVisitCnt() {
		return sVisitCnt;
	}
	/**
	 * @param sVisitCnt the sVisitCnt to set
	 */
	public void setsVisitCnt(String sVisitCnt) {
		this.sVisitCnt = sVisitCnt;
	}
	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}
	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(String sRegId) {
		this.sRegId = sRegId;
	}
	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}
	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(String sRegDate) {
		this.sRegDate = sRegDate;
	}
	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}
	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(String sRegTime) {
		this.sRegTime = sRegTime;
	}
	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}
	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(String sUpId) {
		this.sUpId = sUpId;
	}
	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}
	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(String sUpDate) {
		this.sUpDate = sUpDate;
	}
	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}
	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(String sUpTime) {
		this.sUpTime = sUpTime;
	}
	/**
	 * @return the searchKey
	 */
	public String getSearchKey() {
		return searchKey;
	}
	/**
	 * @param searchKey the searchKey to set
	 */
	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}
	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}
	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}
	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}
	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	/**
	 * @return the searchCatCd
	 */
	public String getSearchCatCd() {
		return searchCatCd;
	}
	/**
	 * @param searchCatCd the searchCatCd to set
	 */
	public void setSearchCatCd(String searchCatCd) {
		this.searchCatCd = searchCatCd;
	}
	/**
	 * @return the nVisitCnt
	 */
	public String getnVisitCnt() {
		return nVisitCnt;
	}
	/**
	 * @param nVisitCnt the nVisitCnt to set
	 */
	public void setnVisitCnt(String nVisitCnt) {
		this.nVisitCnt = nVisitCnt;
	}
	/**
	 * @return the sCatNm
	 */
	public String getsCatNm() {
		return sCatNm;
	}
	/**
	 * @param sCatNm the sCatNm to set
	 */
	public void setsCatNm(String sCatNm) {
		this.sCatNm = sCatNm;
	}
	/**
	 * @return the menuList
	 */
	public List<FaqDTO> getMenuList() {
		return menuList;
	}
	/**
	 * @param menuList the menuList to set
	 */
	public void setMenuList(List<FaqDTO> menuList) {
		this.menuList = menuList;
	}
	
}
