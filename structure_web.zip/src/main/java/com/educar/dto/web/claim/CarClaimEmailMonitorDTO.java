/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���󼭺� ������ ���ϱ� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "carClaimEmailMonitorDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarClaimEmailMonitorDTO {
	/** �����ȣ **/
	private String sAccidentNo;
	/** �̸��� **/
	private String sEmailID;
	
	private String sQ1;
	
	private String sQ2;
	
	private String sQ3;
	
	private String sQ4;
	
	private String sQ5;
	
	private String sQ6;
	
	private String sQ7;
	
	private String sQ8;
	
	private String sQ9;
	
	private String sQ10;
	
	private String sQ11;
	
	private String sQ12;
	
	private String sQ13;
	
	private String sQ14;
	
	private String sQ15;
	
	private String sQ16;
	
	private String sA1;
	
	private String sA2;
	
	private String sA3;
	
	private String sA4;
	
	private String sA5;
	
	private String sA6;
	
	private String sA7;
	
	private String sA8;
	
	private String sA9;
	
	private String sA10;
	
	private String sA11;
	
	private String sA12;
	
	private String sA13;
	
	private String sA14;
	
	private String sA15;
	
	private String sA16;

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sEmailID
	 */
	public String getsEmailID() {
		return sEmailID;
	}

	/**
	 * @param sEmailID the sEmailID to set
	 */
	public void setsEmailID(String sEmailID) {
		this.sEmailID = sEmailID;
	}

	/**
	 * @return the sQ1
	 */
	public String getsQ1() {
		return sQ1;
	}

	/**
	 * @param sQ1 the sQ1 to set
	 */
	public void setsQ1(String sQ1) {
		this.sQ1 = sQ1;
	}

	/**
	 * @return the sQ2
	 */
	public String getsQ2() {
		return sQ2;
	}

	/**
	 * @param sQ2 the sQ2 to set
	 */
	public void setsQ2(String sQ2) {
		this.sQ2 = sQ2;
	}

	/**
	 * @return the sQ3
	 */
	public String getsQ3() {
		return sQ3;
	}

	/**
	 * @param sQ3 the sQ3 to set
	 */
	public void setsQ3(String sQ3) {
		this.sQ3 = sQ3;
	}

	/**
	 * @return the sQ4
	 */
	public String getsQ4() {
		return sQ4;
	}

	/**
	 * @param sQ4 the sQ4 to set
	 */
	public void setsQ4(String sQ4) {
		this.sQ4 = sQ4;
	}

	/**
	 * @return the sQ5
	 */
	public String getsQ5() {
		return sQ5;
	}

	/**
	 * @param sQ5 the sQ5 to set
	 */
	public void setsQ5(String sQ5) {
		this.sQ5 = sQ5;
	}

	/**
	 * @return the sQ6
	 */
	public String getsQ6() {
		return sQ6;
	}

	/**
	 * @param sQ6 the sQ6 to set
	 */
	public void setsQ6(String sQ6) {
		this.sQ6 = sQ6;
	}

	/**
	 * @return the sQ7
	 */
	public String getsQ7() {
		return sQ7;
	}

	/**
	 * @param sQ7 the sQ7 to set
	 */
	public void setsQ7(String sQ7) {
		this.sQ7 = sQ7;
	}

	/**
	 * @return the sQ8
	 */
	public String getsQ8() {
		return sQ8;
	}

	/**
	 * @param sQ8 the sQ8 to set
	 */
	public void setsQ8(String sQ8) {
		this.sQ8 = sQ8;
	}

	/**
	 * @return the sQ9
	 */
	public String getsQ9() {
		return sQ9;
	}

	/**
	 * @param sQ9 the sQ9 to set
	 */
	public void setsQ9(String sQ9) {
		this.sQ9 = sQ9;
	}

	/**
	 * @return the sQ10
	 */
	public String getsQ10() {
		return sQ10;
	}

	/**
	 * @param sQ10 the sQ10 to set
	 */
	public void setsQ10(String sQ10) {
		this.sQ10 = sQ10;
	}

	/**
	 * @return the sQ11
	 */
	public String getsQ11() {
		return sQ11;
	}

	/**
	 * @param sQ11 the sQ11 to set
	 */
	public void setsQ11(String sQ11) {
		this.sQ11 = sQ11;
	}

	/**
	 * @return the sQ12
	 */
	public String getsQ12() {
		return sQ12;
	}

	/**
	 * @param sQ12 the sQ12 to set
	 */
	public void setsQ12(String sQ12) {
		this.sQ12 = sQ12;
	}

	/**
	 * @return the sQ13
	 */
	public String getsQ13() {
		return sQ13;
	}

	/**
	 * @param sQ13 the sQ13 to set
	 */
	public void setsQ13(String sQ13) {
		this.sQ13 = sQ13;
	}

	/**
	 * @return the sQ14
	 */
	public String getsQ14() {
		return sQ14;
	}

	/**
	 * @param sQ14 the sQ14 to set
	 */
	public void setsQ14(String sQ14) {
		this.sQ14 = sQ14;
	}

	/**
	 * @return the sQ15
	 */
	public String getsQ15() {
		return sQ15;
	}

	/**
	 * @param sQ15 the sQ15 to set
	 */
	public void setsQ15(String sQ15) {
		this.sQ15 = sQ15;
	}

	/**
	 * @return the sQ16
	 */
	public String getsQ16() {
		return sQ16;
	}

	/**
	 * @param sQ16 the sQ16 to set
	 */
	public void setsQ16(String sQ16) {
		this.sQ16 = sQ16;
	}

	/**
	 * @return the sA1
	 */
	public String getsA1() {
		return sA1;
	}

	/**
	 * @param sA1 the sA1 to set
	 */
	public void setsA1(String sA1) {
		this.sA1 = sA1;
	}

	/**
	 * @return the sA2
	 */
	public String getsA2() {
		return sA2;
	}

	/**
	 * @param sA2 the sA2 to set
	 */
	public void setsA2(String sA2) {
		this.sA2 = sA2;
	}

	/**
	 * @return the sA3
	 */
	public String getsA3() {
		return sA3;
	}

	/**
	 * @param sA3 the sA3 to set
	 */
	public void setsA3(String sA3) {
		this.sA3 = sA3;
	}

	/**
	 * @return the sA4
	 */
	public String getsA4() {
		return sA4;
	}

	/**
	 * @param sA4 the sA4 to set
	 */
	public void setsA4(String sA4) {
		this.sA4 = sA4;
	}

	/**
	 * @return the sA5
	 */
	public String getsA5() {
		return sA5;
	}

	/**
	 * @param sA5 the sA5 to set
	 */
	public void setsA5(String sA5) {
		this.sA5 = sA5;
	}

	/**
	 * @return the sA6
	 */
	public String getsA6() {
		return sA6;
	}

	/**
	 * @param sA6 the sA6 to set
	 */
	public void setsA6(String sA6) {
		this.sA6 = sA6;
	}

	/**
	 * @return the sA7
	 */
	public String getsA7() {
		return sA7;
	}

	/**
	 * @param sA7 the sA7 to set
	 */
	public void setsA7(String sA7) {
		this.sA7 = sA7;
	}

	/**
	 * @return the sA8
	 */
	public String getsA8() {
		return sA8;
	}

	/**
	 * @param sA8 the sA8 to set
	 */
	public void setsA8(String sA8) {
		this.sA8 = sA8;
	}

	/**
	 * @return the sA9
	 */
	public String getsA9() {
		return sA9;
	}

	/**
	 * @param sA9 the sA9 to set
	 */
	public void setsA9(String sA9) {
		this.sA9 = sA9;
	}

	/**
	 * @return the sA10
	 */
	public String getsA10() {
		return sA10;
	}

	/**
	 * @param sA10 the sA10 to set
	 */
	public void setsA10(String sA10) {
		this.sA10 = sA10;
	}

	/**
	 * @return the sA11
	 */
	public String getsA11() {
		return sA11;
	}

	/**
	 * @param sA11 the sA11 to set
	 */
	public void setsA11(String sA11) {
		this.sA11 = sA11;
	}

	/**
	 * @return the sA12
	 */
	public String getsA12() {
		return sA12;
	}

	/**
	 * @param sA12 the sA12 to set
	 */
	public void setsA12(String sA12) {
		this.sA12 = sA12;
	}

	/**
	 * @return the sA13
	 */
	public String getsA13() {
		return sA13;
	}

	/**
	 * @param sA13 the sA13 to set
	 */
	public void setsA13(String sA13) {
		this.sA13 = sA13;
	}

	/**
	 * @return the sA14
	 */
	public String getsA14() {
		return sA14;
	}

	/**
	 * @param sA14 the sA14 to set
	 */
	public void setsA14(String sA14) {
		this.sA14 = sA14;
	}

	/**
	 * @return the sA15
	 */
	public String getsA15() {
		return sA15;
	}

	/**
	 * @param sA15 the sA15 to set
	 */
	public void setsA15(String sA15) {
		this.sA15 = sA15;
	}

	/**
	 * @return the sA16
	 */
	public String getsA16() {
		return sA16;
	}

	/**
	 * @param sA16 the sA16 to set
	 */
	public void setsA16(String sA16) {
		this.sA16 = sA16;
	}
	
	
}
