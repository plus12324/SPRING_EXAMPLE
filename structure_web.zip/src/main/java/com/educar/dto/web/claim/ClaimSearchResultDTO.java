/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����������ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "compensationSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimSearchResultDTO {
	/** clmc001 **/
	private ClaimSearchOfClmc001DTO clmc001;
	/** clmcc01 **/
	private List<ClaimSearchOfClmcDTO> clmcc01;
	/** clmcd01 **/
	private List<ClaimSearchOfClmcDTO> clmcd01;
	/** clmcc01 + clmcd01 **/
	private List<ClaimSearchOfClmcDTO> carClaimList;

	/**
	 * @return the clmc001
	 */
	public ClaimSearchOfClmc001DTO getClmc001() {
		return clmc001;
	}

	/**
	 * @param clmc001 the clmc001 to set
	 */
	public void setClmc001(final ClaimSearchOfClmc001DTO clmc001) {
		this.clmc001 = clmc001;
	}

	/**
	 * @return the clmcc01
	 */
	public List<ClaimSearchOfClmcDTO> getClmcc01() {
		return clmcc01;
	}

	/**
	 * @param clmcc01 the clmcc01 to set
	 */
	public void setClmcc01(final List<ClaimSearchOfClmcDTO> clmcc01) {
		this.clmcc01 = clmcc01;
	}

	/**
	 * @return the clmcd01
	 */
	public List<ClaimSearchOfClmcDTO> getClmcd01() {
		return clmcd01;
	}

	/**
	 * @param clmcd01 the clmcd01 to set
	 */
	public void setClmcd01(final List<ClaimSearchOfClmcDTO> clmcd01) {
		this.clmcd01 = clmcd01;
	}

	/**
	 * @return the carCompensationList
	 */
	public List<ClaimSearchOfClmcDTO> getCarCompensationList() {
		return carClaimList;
	}

	/**
	 * @param carClaimList the carClaimList to set
	 */
	public void setCarClaimList(final List<ClaimSearchOfClmcDTO> carClaimList) {
		this.carClaimList = carClaimList;
	}

}
