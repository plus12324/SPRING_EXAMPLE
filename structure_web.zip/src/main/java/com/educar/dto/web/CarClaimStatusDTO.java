/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ó�� ��Ȳ ��ȸ �ڵ������� ������Ȳ ����DTO
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carClaimStatusDTO")
public class CarClaimStatusDTO {
	/** �����ȣ(������ȣ) **/
	private String sAccidentNo;
	/** ����������� **/
	private String sAcctDate;
	/** ����������� **/
	private String sAcctInvDate;
	/** ���ػ������� **/
	private String sLossCalcDate;
	/** �Ϸ����� **/
	private String sEndDate;
	/** ����� **/
	private String sStaffName;
	/** ����� ����ó **/
	private String sTelNumber;

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctInvDate
	 */
	public String getsAcctInvDate() {
		return sAcctInvDate;
	}

	/**
	 * @param sAcctInvDate the sAcctInvDate to set
	 */
	public void setsAcctInvDate(final String sAcctInvDate) {
		this.sAcctInvDate = sAcctInvDate;
	}

	/**
	 * @return the sLossCalcDate
	 */
	public String getsLossCalcDate() {
		return sLossCalcDate;
	}

	/**
	 * @param sLossCalcDate the sLossCalcDate to set
	 */
	public void setsLossCalcDate(final String sLossCalcDate) {
		this.sLossCalcDate = sLossCalcDate;
	}

	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}

	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(final String sEndDate) {
		this.sEndDate = sEndDate;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sTelNumber
	 */
	public String getsTelNumber() {
		return sTelNumber;
	}

	/**
	 * @param sTelNumber the sTelNumber to set
	 */
	public void setsTelNumber(final String sTelNumber) {
		this.sTelNumber = sTelNumber;
	}

}
