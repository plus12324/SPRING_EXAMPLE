/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �輭 �㺸 ��ȸ DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorsePawnListOfPola001InfoDTO")
public class EndorsePawnListOfPola001InfoDTO {
	/** �����ڵ� (EE03 ����) **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ����1 (99:���� (�ʼ�)) **/
	private String sCover0101;
	/** ����2 00 �̰���, 05 5õ, 10 1��, 20 2��, 30 3��, 99 ���� **/
	private String sCover0102;
	/** �빰 00 �̰���, 01 1õ����, 02 2õ����, 03 3õ����, 05 5õ����, 07 7õ����, 10 1��, 19 10��, 20 2��, 30 3��, 50 5�� **/
	private String sCover0103;
	/** �ڼ� 00 �̰���, 01 1õ5�鸸��, 03 3õ����, 05 5õ����, 10 1�� **/
	private String sCover0201;
	/** �ڵ������� 00 �̰���, 10 1���, 20 2��� **/
	private String sCover0202;
	/** (�ڼ�)�λ󰡾� 00 �̰���, 01 1õ5��, 02 2õ����, 03 3õ����, 05 5õ���� **/
	private String sCover0203;
	/** (�ڻ�)�λ󰡾� **/
	private String sCover0204;
	/** ������ 00 �̰���, 99 ���� **/
	private String sCover0301;
	/** ���� 00 �̰���, 99 ���� **/
	private String sCover0401;
	/** ���߱���� 00 �̰���, 01 1����, 02 2����, 03 3���� **/
	private String sCover0403;
	/** �ڱ�δ�� ���� 20, 30 **/
	private String sCover0404;
	/** �ڱ�δ���ּҰ� 00 �̰���, 05 5��, 10 10��, 15 15��, 20 20�� **/
	private String nDeductMinAmt;
	/** �ڱ�δ���ִ밪 50 : �ְ� 50����, 100 : �ְ� 100���� **/
	private String nDeductMaxAmt;
	/** ����⵿ 00 �̰���, 99 ���� **/
	private String sCover0501;
	/** ����⵿2 00 �̰���, 99 ���� **/
	private String sCover0523;
	/** ���������� Y / N ('Y'�� ���� ���� �߰� �ȵ�~) **/
	private String sForeignCar;
	/** ����������� �ݾ� 05 50��, 10 100��, 15 150��, 20 200�� : ���� �߰��� �ּұݾ� �����κ�(nDeductMinAmt �� ������ ��Ȱ��ȭ ��Ŵ) **/
	private String sMacAmt;

	/** �輭������ **/
	private String sEndorseFmdt1;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sCover0101
	 */
	public String getsCover0101() {
		return sCover0101;
	}

	/**
	 * @param sCover0101 the sCover0101 to set
	 */
	public void setsCover0101(final String sCover0101) {
		this.sCover0101 = sCover0101;
	}

	/**
	 * @return the sCover0102
	 */
	public String getsCover0102() {
		return sCover0102;
	}

	/**
	 * @param sCover0102 the sCover0102 to set
	 */
	public void setsCover0102(final String sCover0102) {
		this.sCover0102 = sCover0102;
	}

	/**
	 * @return the sCover0103
	 */
	public String getsCover0103() {
		return sCover0103;
	}

	/**
	 * @param sCover0103 the sCover0103 to set
	 */
	public void setsCover0103(final String sCover0103) {
		this.sCover0103 = sCover0103;
	}

	/**
	 * @return the sCover0201
	 */
	public String getsCover0201() {
		return sCover0201;
	}

	/**
	 * @param sCover0201 the sCover0201 to set
	 */
	public void setsCover0201(final String sCover0201) {
		this.sCover0201 = sCover0201;
	}

	/**
	 * @return the sCover0202
	 */
	public String getsCover0202() {
		return sCover0202;
	}

	/**
	 * @param sCover0202 the sCover0202 to set
	 */
	public void setsCover0202(final String sCover0202) {
		this.sCover0202 = sCover0202;
	}

	/**
	 * @return the sCover0203
	 */
	public String getsCover0203() {
		return sCover0203;
	}

	/**
	 * @param sCover0203 the sCover0203 to set
	 */
	public void setsCover0203(final String sCover0203) {
		this.sCover0203 = sCover0203;
	}

	/**
	 * @return the sCover0204
	 */
	public String getsCover0204() {
		return sCover0204;
	}

	/**
	 * @param sCover0204 the sCover0204 to set
	 */
	public void setsCover0204(final String sCover0204) {
		this.sCover0204 = sCover0204;
	}

	/**
	 * @return the sCover0301
	 */
	public String getsCover0301() {
		return sCover0301;
	}

	/**
	 * @param sCover0301 the sCover0301 to set
	 */
	public void setsCover0301(final String sCover0301) {
		this.sCover0301 = sCover0301;
	}

	/**
	 * @return the sCover0401
	 */
	public String getsCover0401() {
		return sCover0401;
	}

	/**
	 * @param sCover0401 the sCover0401 to set
	 */
	public void setsCover0401(final String sCover0401) {
		this.sCover0401 = sCover0401;
	}

	/**
	 * @return the sCover0403
	 */
	public String getsCover0403() {
		return sCover0403;
	}

	/**
	 * @param sCover0403 the sCover0403 to set
	 */
	public void setsCover0403(final String sCover0403) {
		this.sCover0403 = sCover0403;
	}

	/**
	 * @return the sCover0404
	 */
	public String getsCover0404() {
		return sCover0404;
	}

	/**
	 * @param sCover0404 the sCover0404 to set
	 */
	public void setsCover0404(final String sCover0404) {
		this.sCover0404 = sCover0404;
	}

	/**
	 * @return the nDeductMinAmt
	 */
	public String getnDeductMinAmt() {
		return nDeductMinAmt;
	}

	/**
	 * @param nDeductMinAmt the nDeductMinAmt to set
	 */
	public void setnDeductMinAmt(final String nDeductMinAmt) {
		this.nDeductMinAmt = nDeductMinAmt;
	}

	/**
	 * @return the nDeductMaxAmt
	 */
	public String getnDeductMaxAmt() {
		return nDeductMaxAmt;
	}

	/**
	 * @param nDeductMaxAmt the nDeductMaxAmt to set
	 */
	public void setnDeductMaxAmt(final String nDeductMaxAmt) {
		this.nDeductMaxAmt = nDeductMaxAmt;
	}

	/**
	 * @return the sCover0501
	 */
	public String getsCover0501() {
		return sCover0501;
	}

	/**
	 * @param sCover0501 the sCover0501 to set
	 */
	public void setsCover0501(final String sCover0501) {
		this.sCover0501 = sCover0501;
	}
	
	/**
	 * @return the sCover0523
	 */
	public String getsCover0523() {
		return sCover0523;
	}

	/**
	 * @param sCover0523 the sCover0523 to set
	 */
	public void setsCover0523(String sCover0523) {
		this.sCover0523 = sCover0523;
	}

	/**
	 * @return the sForeignCar
	 */
	public String getsForeignCar() {
		return sForeignCar;
	}

	/**
	 * @param sForeignCar the sForeignCar to set
	 */
	public void setsForeignCar(final String sForeignCar) {
		this.sForeignCar = sForeignCar;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @return the sMacAmt
	 */
	public String getsMacAmt() {
		return sMacAmt;
	}

	/**
	 * @param sMacAmt the sMacAmt to set
	 */
	public void setsMacAmt(final String sMacAmt) {
		this.sMacAmt = sMacAmt;
	}

}
