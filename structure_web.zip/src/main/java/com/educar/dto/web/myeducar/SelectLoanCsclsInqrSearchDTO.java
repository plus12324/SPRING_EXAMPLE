/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������Ȯ��	��⺸�� ������� ������������
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCntrDtlOfTrtyDTO")
public class SelectLoanCsclsInqrSearchDTO {
	/** ��ȸ�Ⱓ **/
	private String sInqrTerm;
	/** �߻�����From(����) **/
	private String sDlOccrDate1;
	/** �߻�����To(����) **/
	private String sDlOccrDate2;
	/** ��ȸ��¥From(�Ϻ�) **/
	private String sYdate1;
	/** ��ȸ��¥To(�Ϻ�) **/
	private String sYdate2;
	/** ��ȸ��¥(�ǽð�) **/
	private String sTdate;
	/** ����ȣ **/
	private String sCrNo;

	/**
	 * @return the sInqrTerm
	 */
	public String getsInqrTerm() {
		return sInqrTerm;
	}

	/**
	 * @param sInqrTerm the sInqrTerm to set
	 */
	public void setsInqrTerm(final String sInqrTerm) {
		this.sInqrTerm = sInqrTerm;
	}

	/**
	 * @return the sDlOccrDate1
	 */
	public String getsDlOccrDate1() {
		return sDlOccrDate1;
	}

	/**
	 * @param sDlOccrDate1 the sDlOccrDate1 to set
	 */
	public void setsDlOccrDate1(final String sDlOccrDate1) {
		this.sDlOccrDate1 = sDlOccrDate1;
	}

	/**
	 * @return the sDlOccrDate2
	 */
	public String getsDlOccrDate2() {
		return sDlOccrDate2;
	}

	/**
	 * @param sDlOccrDate2 the sDlOccrDate2 to set
	 */
	public void setsDlOccrDate2(final String sDlOccrDate2) {
		this.sDlOccrDate2 = sDlOccrDate2;
	}

	/**
	 * @return the sYdate1
	 */
	public String getsYdate1() {
		return sYdate1;
	}

	/**
	 * @param sYdate1 the sYdate1 to set
	 */
	public void setsYdate1(final String sYdate1) {
		this.sYdate1 = sYdate1;
	}

	/**
	 * @return the sYdate2
	 */
	public String getsYdate2() {
		return sYdate2;
	}

	/**
	 * @param sYdate2 the sYdate2 to set
	 */
	public void setsYdate2(final String sYdate2) {
		this.sYdate2 = sYdate2;
	}

	/**
	 * @return the sTdate
	 */
	public String getsTdate() {
		return sTdate;
	}

	/**
	 * @param sTdate the sTdate to set
	 */
	public void setsTdate(final String sTdate) {
		this.sTdate = sTdate;
	}

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

}
