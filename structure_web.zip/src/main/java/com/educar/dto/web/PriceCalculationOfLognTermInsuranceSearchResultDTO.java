/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� ����� ��� ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfLognTermInsuranceSearchResultDTO")
public class PriceCalculationOfLognTermInsuranceSearchResultDTO {
	/** Ư�ະ ���庸���, ���������  **/
	@XmlElementWrapper(name = "vLTIDA02List")
	private List<PriceCalculationOfLognTermInsurancePriceDTO> vLTIDA02;
	/** �Ѻ��庸��� **/
	private String nGrntPrem;
	/** ��������� �ּҰ� **/
	private String nMinPrem;
	/** ��������� **/
	private String nAccuPrem;
	/** ���󸸱�ȯ�ޱ� **/
	private String nExptEndRetrnAmt;
	/** ���󸸱�ȯ�޷� **/
	private String nExptEndRtnrt;
	
	private String sMsgCd;
	
	private String sMsg;

	/**
	 * @return the vLTIDA02
	 */
	public List<PriceCalculationOfLognTermInsurancePriceDTO> getvLTIDA02() {
		return vLTIDA02;
	}

	/**
	 * @param vLTIDA02 the vLTIDA02 to set
	 */
	public void setvLTIDA02(final List<PriceCalculationOfLognTermInsurancePriceDTO> vLTIDA02) {
		this.vLTIDA02 = vLTIDA02;
	}

	/**
	 * @return the nGrntPrem
	 */
	public String getnGrntPrem() {
		return nGrntPrem;
	}

	/**
	 * @param nGrntPrem the nGrntPrem to set
	 */
	public void setnGrntPrem(final String nGrntPrem) {
		this.nGrntPrem = nGrntPrem;
	}

	/**
	 * @return the nMinPrem
	 */
	public String getnMinPrem() {
		return nMinPrem;
	}

	/**
	 * @param nMinPrem the nMinPrem to set
	 */
	public void setnMinPrem(final String nMinPrem) {
		this.nMinPrem = nMinPrem;
	}

	/**
	 * @return the nAccuPrem
	 */
	public String getnAccuPrem() {
		return nAccuPrem;
	}

	/**
	 * @param nAccuPrem the nAccuPrem to set
	 */
	public void setnAccuPrem(final String nAccuPrem) {
		this.nAccuPrem = nAccuPrem;
	}

	/**
	 * @return the nExptEndRetrnAmt
	 */
	public String getnExptEndRetrnAmt() {
		return nExptEndRetrnAmt;
	}

	/**
	 * @param nExptEndRetrnAmt the nExptEndRetrnAmt to set
	 */
	public void setnExptEndRetrnAmt(final String nExptEndRetrnAmt) {
		this.nExptEndRetrnAmt = nExptEndRetrnAmt;
	}

	/**
	 * @return the nExptEndRtnrt
	 */
	public String getnExptEndRtnrt() {
		return nExptEndRtnrt;
	}

	/**
	 * @param nExptEndRtnrt the nExptEndRtnrt to set
	 */
	public void setnExptEndRtnrt(final String nExptEndRtnrt) {
		this.nExptEndRtnrt = nExptEndRtnrt;
	}

	/**
	 * @return the sMsgCd
	 */
	public String getsMsgCd() {
		return sMsgCd;
	}

	/**
	 * @param sMsgCd the sMsgCd to set
	 */
	public void setsMsgCd(String sMsgCd) {
		this.sMsgCd = sMsgCd;
	}

	/**
	 * @return the sMsg
	 */
	public String getsMsg() {
		return sMsg;
	}

	/**
	 * @param sMsg the sMsg to set
	 */
	public void setsMsg(String sMsg) {
		this.sMsg = sMsg;
	}
	

}
