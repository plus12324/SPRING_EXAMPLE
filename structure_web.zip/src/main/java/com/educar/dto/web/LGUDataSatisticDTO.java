/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * LGU+������Ȳ
 * @author ���ѳ�
 * @since 0.0.10
 */
public class LGUDataSatisticDTO {
	/** ��ȸ����		 **/
	private String sFmdt;
	/** ��ȸ����		 **/
	private String sTodt;
	/** ���� **/
	private String UserIDtype;
	/** ����Ʈ �����Ǽ� - �ű�		**/
	private String nNewCnt;
	/** ����Ʈ �����Ǽ� - ����		**/
	private String nRenewCnt;
	/** ����Ʈ �����Ǽ� - �հ�		**/
	private String nSumCnt;
	/** ����Ʈ �����ݾ� - �ű�		**/
	private String nNewPointPrem;
	/** ����Ʈ �����ݾ� - ����		**/
	private String nRenewPointPrem;
	/** ����Ʈ �����ݾ� - �հ�		**/
	private String nSumPointPrem;
	/** ��������� - �ű�		**/
	private String nNewRectPrem;
	/** ��������� - ����		**/
	private String nRenewRectPrem;
	/** ��������� - �հ�		**/
	private String nSumRectPrem;
	
	
	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}
	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}
	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	/**
	 * @return the userIDtype
	 */
	public String getUserIDtype() {
		return UserIDtype;
	}
	/**
	 * @param userIDtype the userIDtype to set
	 */
	public void setUserIDtype(String userIDtype) {
		UserIDtype = userIDtype;
	}
	/**
	 * @return the nNewCnt
	 */
	public String getnNewCnt() {
		return nNewCnt;
	}
	/**
	 * @param nNewCnt the nNewCnt to set
	 */
	public void setnNewCnt(String nNewCnt) {
		this.nNewCnt = nNewCnt;
	}
	/**
	 * @return the nRenewCnt
	 */
	public String getnRenewCnt() {
		return nRenewCnt;
	}
	/**
	 * @param nRenewCnt the nRenewCnt to set
	 */
	public void setnRenewCnt(String nRenewCnt) {
		this.nRenewCnt = nRenewCnt;
	}
	/**
	 * @return the nSumCnt
	 */
	public String getnSumCnt() {
		return nSumCnt;
	}
	/**
	 * @param nSumCnt the nSumCnt to set
	 */
	public void setnSumCnt(String nSumCnt) {
		this.nSumCnt = nSumCnt;
	}
	/**
	 * @return the nNewPointPrem
	 */
	public String getnNewPointPrem() {
		return nNewPointPrem;
	}
	/**
	 * @param nNewPointPrem the nNewPointPrem to set
	 */
	public void setnNewPointPrem(String nNewPointPrem) {
		this.nNewPointPrem = nNewPointPrem;
	}
	/**
	 * @return the nRenewPointPrem
	 */
	public String getnRenewPointPrem() {
		return nRenewPointPrem;
	}
	/**
	 * @param nRenewPointPrem the nRenewPointPrem to set
	 */
	public void setnRenewPointPrem(String nRenewPointPrem) {
		this.nRenewPointPrem = nRenewPointPrem;
	}
	/**
	 * @return the nSumPointPrem
	 */
	public String getnSumPointPrem() {
		return nSumPointPrem;
	}
	/**
	 * @param nSumPointPrem the nSumPointPrem to set
	 */
	public void setnSumPointPrem(String nSumPointPrem) {
		this.nSumPointPrem = nSumPointPrem;
	}
	/**
	 * @return the nNewRectPrem
	 */
	public String getnNewRectPrem() {
		return nNewRectPrem;
	}
	/**
	 * @param nNewRectPrem the nNewRectPrem to set
	 */
	public void setnNewRectPrem(String nNewRectPrem) {
		this.nNewRectPrem = nNewRectPrem;
	}
	/**
	 * @return the nRenewRectPrem
	 */
	public String getnRenewRectPrem() {
		return nRenewRectPrem;
	}
	/**
	 * @param nRenewRectPrem the nRenewRectPrem to set
	 */
	public void setnRenewRectPrem(String nRenewRectPrem) {
		this.nRenewRectPrem = nRenewRectPrem;
	}
	/**
	 * @return the nSumRectPrem
	 */
	public String getnSumRectPrem() {
		return nSumRectPrem;
	}
	/**
	 * @param nSumRectPrem the nSumRectPrem to set
	 */
	public void setnSumRectPrem(String nSumRectPrem) {
		this.nSumRectPrem = nSumRectPrem;
	}
	
	
}
