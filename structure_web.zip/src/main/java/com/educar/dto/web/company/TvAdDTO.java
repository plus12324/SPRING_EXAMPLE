/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.company;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ȫ���� - TV���� DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "tvAdDTO")
public class TvAdDTO {

	/** �Ϸù�ȣ */
	private long nSeq;
	/** ���� */
	private String sTitle;
	/** ���� */
	private String sContent;
	/** �̹��� �̸� */
	private String sImgNm;
	/** ������ �̸� */
	private String sVodNm;
	/** �̹��� ���  */
	private String sImgPath;
	/** ������ ��� */
	private String sVodPath;
	/** ������ �ڸ� */
	private String sSubtitle;
	/** �������� */
	private String sViewYn;
	/** ������¥ */
	private String sOpenDate;
	/** ������ */
	private String sRegId;
	/** ������¥ */
	private String sRegDate;
	/** �����ð� */
	private String sRegTime;
	/** ������ */
	private String sUpId;
	/** ������¥ */
	private String sUpDate;
	/** �����ð� */
	private String sUpTime;

	/**
	 * @return the nSeq
	 */
	public long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}

	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(final String sContent) {
		this.sContent = sContent;
	}

	/**
	 * @return the sImgNm
	 */
	public String getsImgNm() {
		return sImgNm;
	}

	/**
	 * @param sImgNm the sImgNm to set
	 */
	public void setsImgNm(final String sImgNm) {
		this.sImgNm = sImgNm;
	}

	/**
	 * @return the sVodNm
	 */
	public String getsVodNm() {
		return sVodNm;
	}

	/**
	 * @param sVodNm the sVodNm to set
	 */
	public void setsVodNm(final String sVodNm) {
		this.sVodNm = sVodNm;
	}

	/**
	 * @return the sImgPath
	 */
	public String getsImgPath() {
		return sImgPath;
	}

	/**
	 * @param sImgPath the sImgPath to set
	 */
	public void setsImgPath(final String sImgPath) {
		this.sImgPath = sImgPath;
	}

	/**
	 * @return the sVodPath
	 */
	public String getsVodPath() {
		return sVodPath;
	}

	/**
	 * @param sVodPath the sVodPath to set
	 */
	public void setsVodPath(final String sVodPath) {
		this.sVodPath = sVodPath;
	}

	/**
	 * @return the sSubtitle
	 */
	public String getsSubtitle() {
		return sSubtitle;
	}

	/**
	 * @param sSubtitle the sSubtitle to set
	 */
	public void setsSubtitle(final String sSubtitle) {
		this.sSubtitle = sSubtitle;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}

	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(final String sUpDate) {
		this.sUpDate = sUpDate;
	}

	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}

	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(final String sUpTime) {
		this.sUpTime = sUpTime;
	}

}
