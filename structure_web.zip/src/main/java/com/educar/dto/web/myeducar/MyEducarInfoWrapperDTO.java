/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.dto.web.AccidentClaimDTO;
import com.educar.dto.web.CarClaimDTO;
import com.educar.dto.web.InsuranceDTO;
import com.educar.dto.web.VOCSearchResultDTO;
import com.educar.dto.web.login.MemberCheckDTO;

/**
 * <pre>
 * ���̿���ī ������� ������(�α��ο�) ���� ���� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "myEducarInfoWrapperDTO")
public class MyEducarInfoWrapperDTO {

	/** ��ȸ�� �������� **/
	private MemberCheckDTO memberCheckDTO;
	/** ������� ���� ��� **/
	private List<InsuranceDTO> insuranceList;
	/** �ڵ������� ���󳻿� **/
	private List<CarClaimDTO> carClaimList;
	/** ����/�ǰ����� ���󳻿� ��ȸ **/
	private List<AccidentClaimDTO> accidentClaimList;
	/** ���� ��㳻�� **/
	private List<VOCSearchResultDTO> counselList;

	/**
	 * @return the counselList
	 */
	public List<VOCSearchResultDTO> getCounselList() {
		return counselList;
	}

	/**
	 * @param counselList the counselList to set
	 */
	public void setCounselList(final List<VOCSearchResultDTO> counselList) {
		this.counselList = counselList;
	}

	/**
	 * @return the memberCheckDTO
	 */
	public MemberCheckDTO getMemberCheckDTO() {
		return memberCheckDTO;
	}

	/**
	 * @param memberCheckDTO the memberCheckDTO to set
	 */
	public void setMemberCheckDTO(final MemberCheckDTO memberCheckDTO) {
		this.memberCheckDTO = memberCheckDTO;
	}

	/**
	 * @return the insuranceList
	 */
	public List<InsuranceDTO> getInsuranceList() {
		return insuranceList;
	}

	/**
	 * @param insuranceList the insuranceList to set
	 */
	public void setInsuranceList(final List<InsuranceDTO> insuranceList) {
		this.insuranceList = insuranceList;
	}

	/**
	 * @return the carClaimList
	 */
	public List<CarClaimDTO> getCarClaimList() {
		return carClaimList;
	}

	/**
	 * @param carClaimList the carClaimList to set
	 */
	public void setCarClaimList(final List<CarClaimDTO> carClaimList) {
		this.carClaimList = carClaimList;
	}

	/**
	 * @return the accidentClaimList
	 */
	public List<AccidentClaimDTO> getAccidentClaimList() {
		return accidentClaimList;
	}

	/**
	 * @param accidentClaimList the accidentClaimList to set
	 */
	public void setAccidentClaimList(final List<AccidentClaimDTO> accidentClaimList) {
		this.accidentClaimList = accidentClaimList;
	}
}
