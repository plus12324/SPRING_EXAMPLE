/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� û�೻�� Ȯ�� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerApplyInfoOfApplyInfoDTO")
public class DealerApplyInfoOfApplyInfoDTO {
	/** �����ڵ� ("00") **/
	private String sMsgCode;
	/** ����޼��� ("00" : "����") **/
	private String sMsg;
	/** �Ǻ����ڼ��� **/
	private String sInsrdName;
	/** �Ǻ����ڹ�ȣ **/
	private String sInsrdID;
	/** ����� (û����) **/
	private String sInputDate;
	/** �����ǰ�ڵ� **/
	private String sInsType;
	/** �����ǰ **/
	private String sInsTypeNm;
	/** ����Ⱓ **/
	private String sPeriod;
	/** �Ѻ���� (������ �����) **/
	private String nRectPrem;
	/** �㺸���� (����) **/
	private String nCoverCnt;
	/** Ư�హ�� (����) **/
	private String nTKCnt;

	/**
	 * @return the sMsgCode
	 */
	public String getsMsgCode() {
		return sMsgCode;
	}

	/**
	 * @param sMsgCode the sMsgCode to set
	 */
	public void setsMsgCode(final String sMsgCode) {
		this.sMsgCode = sMsgCode;
	}

	/**
	 * @return the sMsg
	 */
	public String getsMsg() {
		return sMsg;
	}

	/**
	 * @param sMsg the sMsg to set
	 */
	public void setsMsg(final String sMsg) {
		this.sMsg = sMsg;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}

	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(final String sInputDate) {
		this.sInputDate = sInputDate;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sInsTypeNm
	 */
	public String getsInsTypeNm() {
		return sInsTypeNm;
	}

	/**
	 * @param sInsTypeNm the sInsTypeNm to set
	 */
	public void setsInsTypeNm(final String sInsTypeNm) {
		this.sInsTypeNm = sInsTypeNm;
	}

	/**
	 * @return the sPeriod
	 */
	public String getsPeriod() {
		return sPeriod;
	}

	/**
	 * @param sPeriod the sPeriod to set
	 */
	public void setsPeriod(final String sPeriod) {
		this.sPeriod = sPeriod;
	}

	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}

	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(final String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}

	/**
	 * @return the nCoverCnt
	 */
	public String getnCoverCnt() {
		return nCoverCnt;
	}

	/**
	 * @param nCoverCnt the nCoverCnt to set
	 */
	public void setnCoverCnt(final String nCoverCnt) {
		this.nCoverCnt = nCoverCnt;
	}

	/**
	 * @return the nTKCnt
	 */
	public String getnTKCnt() {
		return nTKCnt;
	}

	/**
	 * @param nTKCnt the nTKCnt to set
	 */
	public void setnTKCnt(final String nTKCnt) {
		this.nTKCnt = nTKCnt;
	}

}
