/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * �������� ��ȸ ��� DTO
 * @author ������
 * TODO: ������ ������� �����ؾ� �ϴ��� Ȯ�� �ʿ�! �켱�� ��ȸ�� �����ϵ��� ����
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carPhotoSearchDTO")
public class CarPhotoSearchResultDTO extends PageDTO {
	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;

	/** ��� **/
	private String sYM;
	/** �Ϸù�ȣ **/
	private String nSerial;
	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	/** ������ȣ **/
	private String sPlateNo;
	/** �������� **/
	private String sAcceptDate;
	/** �����ð� **/
	private String sAcceptTime;

	/**
	 * @return the sYM
	 */
	public String getsYM() {
		return sYM;
	}

	/**
	 * @param sYM the sYM to set
	 */
	public void setsYM(final String sYM) {
		this.sYM = sYM;
	}

	/**
	 * @return the nSerial
	 */
	public String getnSerial() {
		return nSerial;
	}

	/**
	 * @param nSerial the nSerial to set
	 */
	public void setnSerial(final String nSerial) {
		this.nSerial = nSerial;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sAcceptDate
	 */
	public String getsAcceptDate() {
		return sAcceptDate;
	}

	/**
	 * @param sAcceptDate the sAcceptDate to set
	 */
	public void setsAcceptDate(final String sAcceptDate) {
		this.sAcceptDate = sAcceptDate;
	}

	/**
	 * @return the sAcceptTime
	 */
	public String getsAcceptTime() {
		return sAcceptTime;
	}

	/**
	 * @param sAcceptTime the sAcceptTime to set
	 */
	public void setsAcceptTime(final String sAcceptTime) {
		this.sAcceptTime = sAcceptTime;
	}
}
