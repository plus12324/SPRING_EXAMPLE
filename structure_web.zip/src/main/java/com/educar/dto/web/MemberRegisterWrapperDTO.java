/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.dto.web.login.LoginDTO;
import com.educar.vo.web.MemberRegisterCertificationVO;

/**
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "memberRegisterWrapperDTO")
public class MemberRegisterWrapperDTO {
	/** ���������� **/
	private LoginDTO loginDTO;
	/** ȸ���ּ� **/
	private MemberAddressDTO memberAddressDTO;
	/** ȸ�� ����ó **/
	private MemberContactDTO memberContactDTO;
	/** ȸ�� �̸��� **/
	private MemberEmailDTO memberEmailDTO;
	/** ȸ�� ������ ���� **/
	private MemberMarketingAgreementDTO memberMarketingAgreementDTO;
	/** ȸ������ ����**/
	private MemberRegisterCertificationVO memberRegisterSession;

	/**
	 * @return the loginDTO
	 */
	public LoginDTO getLoginDTO() {
		return loginDTO;
	}

	/**
	 * @param loginDTO the loginDTO to set
	 */
	public void setLoginDTO(final LoginDTO loginDTO) {
		this.loginDTO = loginDTO;
	}

	/**
	 * @return the memberAddressDTO
	 */
	public MemberAddressDTO getMemberAddressDTO() {
		return memberAddressDTO;
	}

	/**
	 * @param memberAddressDTO the memberAddressDTO to set
	 */
	public void setMemberAddressDTO(final MemberAddressDTO memberAddressDTO) {
		this.memberAddressDTO = memberAddressDTO;
	}

	/**
	 * @return the memberContactDTO
	 */
	public MemberContactDTO getMemberContactDTO() {
		return memberContactDTO;
	}

	/**
	 * @param memberContactDTO the memberContactDTO to set
	 */
	public void setMemberContactDTO(final MemberContactDTO memberContactDTO) {
		this.memberContactDTO = memberContactDTO;
	}

	/**
	 * @return the memberEmailDTO
	 */
	public MemberEmailDTO getMemberEmailDTO() {
		return memberEmailDTO;
	}

	/**
	 * @param memberEmailDTO the memberEmailDTO to set
	 */
	public void setMemberEmailDTO(final MemberEmailDTO memberEmailDTO) {
		this.memberEmailDTO = memberEmailDTO;
	}

	/**
	 * @return the memberMarketingAgreementDTO
	 */
	public MemberMarketingAgreementDTO getMemberMarketingAgreementDTO() {
		return memberMarketingAgreementDTO;
	}

	/**
	 * @param memberMarketingAgreementDTO the memberMarketingAgreementDTO to set
	 */
	public void setMemberMarketingAgreementDTO(final MemberMarketingAgreementDTO memberMarketingAgreementDTO) {
		this.memberMarketingAgreementDTO = memberMarketingAgreementDTO;
	}

	/**
	 * @return the memberRegisterSession
	 */
	public MemberRegisterCertificationVO getMemberRegisterSession() {
		return memberRegisterSession;
	}

	/**
	 * @param memberRegisterSession the memberRegisterSession to set
	 */
	public void setMemberRegisterSession(final MemberRegisterCertificationVO memberRegisterSession) {
		this.memberRegisterSession = memberRegisterSession;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
