/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� ��� ��� ��ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "claimPolicyDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimPolicyDTO {
	/** �Ǻ����� **/
	private String sInsrdName;
	/** ������ȣ **/
	private String sPlateNo;
	/** ���� **/
	private String sCarName;
	/** ���Ÿ�� **/
	private String sPolicyType;
	/** ���(YYMM) **/
	private String sPolicyYM;
	/** SEQ **/
	private String sPolicySer;
	/** ��� ��ȣ(ȭ�� ǥ�ÿ�) **/
	private String policyNo;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ����Ⱓ(ȭ�� ǥ�ÿ�) **/
	private String period;
	/** ���¸� **/
	private String sPolicyStatName;
	/** �輭��ȣ **/
	private String nLastEndorseNo;
	/** ������ **/	
	private String sRectDate;
	/** �����ð� **/	
	private String sRectTime;

	public String getsRectDate() {
		return sRectDate;
	}

	public void setsRectDate(String sRectDate) {
		this.sRectDate = sRectDate;
	}

	public String getsRectTime() {
		return sRectTime;
	}

	public void setsRectTime(String sRectTime) {
		this.sRectTime = sRectTime;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sCarName
	 */
	public String getsCarName() {
		return sCarName;
	}

	/**
	 * @param sCarName the sCarName to set
	 */
	public void setsCarName(final String sCarName) {
		this.sCarName = sCarName;
	}

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(final String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(final String period) {
		this.period = period;
	}

	/**
	 * @return the sPolicyStatName
	 */
	public String getsPolicyStatName() {
		return sPolicyStatName;
	}

	/**
	 * @param sPolicyStatName the sPolicyStatName to set
	 */
	public void setsPolicyStatName(final String sPolicyStatName) {
		this.sPolicyStatName = sPolicyStatName;
	}

	/**
	 * @return the nLastEndorseNo
	 */
	public String getnLastEndorseNo() {
		return nLastEndorseNo;
	}

	/**
	 * @param nLastEndorseNo the nLastEndorseNo to set
	 */
	public void setnLastEndorseNo(final String nLastEndorseNo) {
		this.nLastEndorseNo = nLastEndorseNo;
	}

}
