/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetailResultDTO")
public class InsuranceGeneralDetailResultDTO {
	/** ContDetailList01 ����Ʈ�� ù��° ��ü ��� **/
	private List<InsuranceGeneralDetailOfContDetailList01DTO> ContDetailList01;
	/** ContDetailList02 ����Ʈ�� ù��° ��ü ��� **/
	private List<InsuranceGeneralDetailOfContDetailList02DTO> ContDetailList02;
	/** ContDetailList03 **/
	private InsuranceGeneralDetailOfContDetailList03DTO ContDetailList03;
	/**
	 * <pre>
	 * ContDetailList04
	 * sDiv �� ���� 4������ �и��Ǹ� 4���� ����Ʈ�� �����ȴ�
	 * 01-���� �Ǻ����� �ּ�
	 * 02-���� ����� �ּ�
	 * 03-�Ǻ����� ���� �ּ�(����,����,��Ÿ)
	 * 04-����� ���� �ּ�(����,����,��Ÿ)
	 * </pre>
	 **/
	private List<InsuranceGeneralDetailOfContDetailList04DTO> ContDetailList04;
	/** ContDetailList05 ����Ʈ�� ù��° ��ü ��� **/
	private List<InsuranceGeneralDetailOfContDetailList05DTO> ContDetailList05;
	/** ContDetailList06 **/
	private InsuranceGeneralDetailOfContDetailList06DTO ContDetailList06;

	/**
	 * @return the contDetailList01
	 */
	public List<InsuranceGeneralDetailOfContDetailList01DTO> getContDetailList01() {
		return ContDetailList01;
	}

	/**
	 * @param contDetailList01 the contDetailList01 to set
	 */
	public void setContDetailList01(final List<InsuranceGeneralDetailOfContDetailList01DTO> contDetailList01) {
		ContDetailList01 = contDetailList01;
	}

	/**
	 * @return the contDetailList02
	 */
	public List<InsuranceGeneralDetailOfContDetailList02DTO> getContDetailList02() {
		return ContDetailList02;
	}

	/**
	 * @param contDetailList02 the contDetailList02 to set
	 */
	public void setContDetailList02(final List<InsuranceGeneralDetailOfContDetailList02DTO> contDetailList02) {
		ContDetailList02 = contDetailList02;
	}

	/**
	 * @return the contDetailList03
	 */
	public InsuranceGeneralDetailOfContDetailList03DTO getContDetailList03() {
		return ContDetailList03;
	}

	/**
	 * @param contDetailList03 the contDetailList03 to set
	 */
	public void setContDetailList03(final InsuranceGeneralDetailOfContDetailList03DTO contDetailList03) {
		ContDetailList03 = contDetailList03;
	}

	/**
	 * @return the contDetailList04
	 */
	public List<InsuranceGeneralDetailOfContDetailList04DTO> getContDetailList04() {
		return ContDetailList04;
	}

	/**
	 * @param contDetailList04 the contDetailList04 to set
	 */
	public void setContDetailList04(final List<InsuranceGeneralDetailOfContDetailList04DTO> contDetailList04) {
		ContDetailList04 = contDetailList04;
	}

	/**
	 * @return the contDetailList05
	 */
	public List<InsuranceGeneralDetailOfContDetailList05DTO> getContDetailList05() {
		return ContDetailList05;
	}

	/**
	 * @param contDetailList05 the contDetailList05 to set
	 */
	public void setContDetailList05(final List<InsuranceGeneralDetailOfContDetailList05DTO> contDetailList05) {
		ContDetailList05 = contDetailList05;
	}

	/**
	 * @return the contDetailList06
	 */
	public InsuranceGeneralDetailOfContDetailList06DTO getContDetailList06() {
		return ContDetailList06;
	}

	/**
	 * @param contDetailList06 the contDetailList06 to set
	 */
	public void setContDetailList06(final InsuranceGeneralDetailOfContDetailList06DTO contDetailList06) {
		ContDetailList06 = contDetailList06;
	}
}
