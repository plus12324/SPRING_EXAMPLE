/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ��� ó�� ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "selectAcctListInfoResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SelectAcctListInfoResultDTO {
	/** �����ȣ **/
	private String sAccidentNo;
	/** ����  1: �Ǻ�����, 2:������, 3: ������ **/
	private String sDivCode;
	/** �㺸 **/
	private String sHndCover;
	/** ���� **/
	private String sDmgeNo;
	/** �����ڹ��� **/
	private String sVictim;
	/** ����Ͻ� **/
	private String sAcctDate;
	/** �Ǻ������� **/
	private String sCarKorName;
	/** �Ǻ����� **/
	private String sInsuredName;
	/** �����ȣ **/
	private String sEndNo;

	/**
	 * @return the sDivCode
	 */
	public String getsDivCode() {
		return sDivCode;
	}

	/**
	 * @param sDivCode the sDivCode to set
	 */
	public void setsDivCode(String sDivCode) {
		this.sDivCode = sDivCode;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}

	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(final String sHndCover) {
		this.sHndCover = sHndCover;
	}

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the sVictim
	 */
	public String getsVictim() {
		return sVictim;
	}

	/**
	 * @param sVictim the sVictim to set
	 */
	public void setsVictim(final String sVictim) {
		this.sVictim = sVictim;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sCarKorName
	 */
	public String getsCarKorName() {
		return sCarKorName;
	}

	/**
	 * @param sCarKorName the sCarKorName to set
	 */
	public void setsCarKorName(final String sCarKorName) {
		this.sCarKorName = sCarKorName;
	}

	/**
	 * @return the sInsuredName
	 */
	public String getsInsuredName() {
		return sInsuredName;
	}

	/**
	 * @param sInsuredName the sInsuredName to set
	 */
	public void setsInsuredName(final String sInsuredName) {
		this.sInsuredName = sInsuredName;
	}

	/**
	 * @return the sEndNo
	 */
	public String getsEndNo() {
		return sEndNo;
	}

	/**
	 * @param sEndNo the sEndNo to set
	 */
	public void setsEndNo(final String sEndNo) {
		this.sEndNo = sEndNo;
	}

}
