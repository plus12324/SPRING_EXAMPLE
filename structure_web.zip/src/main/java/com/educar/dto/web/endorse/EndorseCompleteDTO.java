/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

/**
 * �輭 Ȯ�� ó�� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
public class EndorseCompleteDTO {

	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** �������� **/
	private String sPayType;
	/** ��������� **/
	private String nRectPrem;
	/** ī���ȣ **/
	private String sCardNo1;
	/** ���ι�ȣ **/
	private String sAdmitNo;
	/** �ǽð�������ü�����ڵ� **/
	private String sOutBankCode;
	/** �ǻ簣������ü���¹�ȣ **/
	private String sOutAcctNo;
	/** ��û���� **/
	private String sReqDate;
	/** �����Ϸù�ȣ **/
	private String sSerialNo;
	/** �ڵ������ι�ȣ **/
	private String sCellDealNo;
	/** �ڵ�����ȣ1 **/
	private String sCellPhone1;
	/** �ڵ�����ȣ2 **/
	private String sCellPhone2;
	/** �ڵ�����ȣ3 **/
	private String sCellPhone3;
	/** �����ڵ�(�������� ���) **/
	private String sBankCode;
	/** ���¹�ȣ(�������� ���) 296-05-016004 ȭ�鿡�� ǥ�õǴ� ���¹�ȣ �״�� ���**/
	private String sAcctNo;
	/** �Ա� ������ **/
	private String sExpectDate;
	/** ���� + ���¹�ȣ(���ڹ߼ۿ�) **/
	private String sBankAcctNo;
	/** ���� ����Ʈ �ݾ�(LGU+ ����Ʈ������) **/
	private String nJehuPointPrem;
	/** ���� ����Ʈ ��ȣ (LGU+ ����Ʈ������) **/
	private String sJehuCardNo;
	/** ���޻�(LGU+ ����Ʈ������) **/
	private String sJehuCode;
	/** �ŷ���ȣ(LGU+ ����Ʈ������) **/
	private String  sJehuPointDealNo;

	public String getnJehuPointPrem() {
		return nJehuPointPrem;
	}

	public void setnJehuPointPrem(String nJehuPointPrem) {
		this.nJehuPointPrem = nJehuPointPrem;
	}

	public String getsJehuCardNo() {
		return sJehuCardNo;
	}

	public void setsJehuCardNo(String sJehuCardNo) {
		this.sJehuCardNo = sJehuCardNo;
	}

	public String getsJehuCode() {
		return sJehuCode;
	}

	public void setsJehuCode(String sJehuCode) {
		this.sJehuCode = sJehuCode;
	}

	public String getsJehuPointDealNo() {
		return sJehuPointDealNo;
	}

	public void setsJehuPointDealNo(String sJehuPointDealNo) {
		this.sJehuPointDealNo = sJehuPointDealNo;
	}

	public String getsBankAcctNo() {
		return sBankAcctNo;
	}

	public void setsBankAcctNo(String sBankAcctNo) {
		this.sBankAcctNo = sBankAcctNo;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @return the sPayType
	 */
	public String getsPayType() {
		return sPayType;
	}

	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}

	/**
	 * @return the sCardNo1
	 */
	public String getsCardNo1() {
		return sCardNo1;
	}

	/**
	 * @return the sOutBankCode
	 */
	public String getsOutBankCode() {
		return sOutBankCode;
	}

	/**
	 * @return the sReqDate
	 */
	public String getsReqDate() {
		return sReqDate;
	}

	/**
	 * @param sReqDate the sReqDate to set
	 */
	public void setsReqDate(final String sReqDate) {
		this.sReqDate = sReqDate;
	}

	/**
	 * @return the sSerialNo
	 */
	public String getsSerialNo() {
		return sSerialNo;
	}

	/**
	 * @param sSerialNo the sSerialNo to set
	 */
	public void setsSerialNo(final String sSerialNo) {
		this.sSerialNo = sSerialNo;
	}

	/**
	 * @return the sOutAcctNo
	 */
	public String getsOutAcctNo() {
		return sOutAcctNo;
	}

	/**
	 * @return the sCellDealNo
	 */
	public String getsCellDealNo() {
		return sCellDealNo;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sExpectDate
	 */
	public String getsExpectDate() {
		return sExpectDate;
	}

	/**
	 * @param sExpectDate the sExpectDate to set
	 */
	public void setsExpectDate(final String sExpectDate) {
		this.sExpectDate = sExpectDate;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @param sPayType the sPayType to set
	 */
	public void setsPayType(final String sPayType) {
		this.sPayType = sPayType;
	}

	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(final String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}

	/**
	 * @param sCardNo1 the sCardNo1 to set
	 */
	public void setsCardNo1(final String sCardNo1) {
		this.sCardNo1 = sCardNo1;
	}

	/**
	 * @return the sAdmitNo
	 */
	public String getsAdmitNo() {
		return sAdmitNo;
	}

	/**
	 * @param sAdmitNo the sAdmitNo to set
	 */
	public void setsAdmitNo(final String sAdmitNo) {
		this.sAdmitNo = sAdmitNo;
	}

	/**
	 * @param sOutBankCode the sOutBankCode to set
	 */
	public void setsOutBankCode(final String sOutBankCode) {
		this.sOutBankCode = sOutBankCode;
	}

	/**
	 * @param sOutAcctNo the sOutAcctNo to set
	 */
	public void setsOutAcctNo(final String sOutAcctNo) {
		this.sOutAcctNo = sOutAcctNo;
	}

	/**
	 * @param sCellDealNo the sCellDealNo to set
	 */
	public void setsCellDealNo(final String sCellDealNo) {
		this.sCellDealNo = sCellDealNo;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	public String getApplyNo() {
		return sApplyType + sApplyYM + sApplySer;
	}
}
