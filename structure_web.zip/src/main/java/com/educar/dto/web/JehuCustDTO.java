/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Ư������ �������� �Է� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "jehuCustDTO")
public class JehuCustDTO {
	/** ������ȣ **/
	private String sCustNo;
	/** ���԰�� **/
	private String sContactPath;
	/** �̺�Ʈ�ڵ� **/
	private String sEventDiv;
	/** �����ڵ� **/
	private String sAffiliatedConcern;
	/** �̸� **/
	private String sName;
	/** ��ü�� **/
	private String sInfo;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sContactPath
	 */
	public String getsContactPath() {
		return sContactPath;
	}

	/**
	 * @param sContactPath the sContactPath to set
	 */
	public void setsContactPath(final String sContactPath) {
		this.sContactPath = sContactPath;
	}

	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}

	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(final String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sInfo
	 */
	public String getsInfo() {
		return sInfo;
	}

	/**
	 * @param sInfo the sInfo to set
	 */
	public void setsInfo(final String sInfo) {
		this.sInfo = sInfo;
	}

}
