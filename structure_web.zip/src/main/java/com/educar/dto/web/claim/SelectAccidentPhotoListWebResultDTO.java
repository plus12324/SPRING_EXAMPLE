/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���������� ������������ ��ȸ ���DTO
 * @author ������
 *
 */
@XmlRootElement(name = "selectAccidentPhotoListWebDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SelectAccidentPhotoListWebResultDTO {
	/** �����ȣ **/
	private String sAccidentNo;
	/** ���ȸ�� **/
	private String sRegiNo;
	/** ���ϸ� **/
	private String sFileName;
	/** ��θ� **/
	private String sFilePath;
	/** �Է����� **/
	private String sInputDate;
	/** ����������� **/
	private String sAcctRegiDate;
	/** ������ȣ **/
	private String sCarNo;
	/** �������� A:���������� B:�����ļջ��� **/
	private String sPictGb;

	/**
	 * @return the sPictGb
	 */
	public String getsPictGb() {
		return sPictGb;
	}

	/**
	 * @param sPictGb the sPictGb to set
	 */
	public void setsPictGb(String sPictGb) {
		this.sPictGb = sPictGb;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sRegiNo
	 */
	public String getsRegiNo() {
		return sRegiNo;
	}

	/**
	 * @param sRegiNo the sRegiNo to set
	 */
	public void setsRegiNo(final String sRegiNo) {
		this.sRegiNo = sRegiNo;
	}

	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}

	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(final String sFileName) {
		this.sFileName = sFileName;
	}

	/**
	 * @return the sFilePath
	 */
	public String getsFilePath() {
		return sFilePath;
	}

	/**
	 * @param sFilePath the sFilePath to set
	 */
	public void setsFilePath(final String sFilePath) {
		this.sFilePath = sFilePath;
	}

	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}

	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(final String sInputDate) {
		this.sInputDate = sInputDate;
	}

	/**
	 * @return the sAcctRegiDate
	 */
	public String getsAcctRegiDate() {
		return sAcctRegiDate;
	}

	/**
	 * @param sAcctRegiDate the sAcctRegiDate to set
	 */
	public void setsAcctRegiDate(final String sAcctRegiDate) {
		this.sAcctRegiDate = sAcctRegiDate;
	}

	/**
	 * @return the sCarNo
	 */
	public String getsCarNo() {
		return sCarNo;
	}

	/**
	 * @param sCarNo the sCarNo to set
	 */
	public void setsCarNo(final String sCarNo) {
		this.sCarNo = sCarNo;
	}

}
