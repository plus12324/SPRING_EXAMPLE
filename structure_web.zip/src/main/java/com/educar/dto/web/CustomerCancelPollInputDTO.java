package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * �������� ���� Input DTO
 * @author ������
 * @since 0.0.10
 */
@XmlRootElement(name = "customerCancelPollInputDTO")
public class CustomerCancelPollInputDTO {
	
	/**
	 *����ID 
	 */
	private String	nSurveyNo;
	
	/**
	 *��������ID 
	 */
	private String	nQuestionNo;
	
	/**
	 *�����׸�ID 
	 */
	private String	nExampleNo;
	
	/**
	 *�����������ڵ� 
	 */
	private String	sRspUserCode;
	
	/**
	 *�����������ڵ����� 
	 */
	private String	sRspUserCodeType;
	
	/**
	 *�ְ��Ĵ亯 
	 */
	private String	sTextAnswer;
	
	/**
	 *�Է���ID 
	 */
	private String	sUserID;

	public String getnSurveyNo() {
		return nSurveyNo;
	}

	public void setnSurveyNo(String nSurveyNo) {
		this.nSurveyNo = nSurveyNo;
	}

	public String getnQuestionNo() {
		return nQuestionNo;
	}

	public void setnQuestionNo(String nQuestionNo) {
		this.nQuestionNo = nQuestionNo;
	}

	public String getnExampleNo() {
		return nExampleNo;
	}

	public void setnExampleNo(String nExampleNo) {
		this.nExampleNo = nExampleNo;
	}

	public String getsRspUserCode() {
		return sRspUserCode;
	}

	public void setsRspUserCode(String sRspUserCode) {
		this.sRspUserCode = sRspUserCode;
	}

	public String getsRspUserCodeType() {
		return sRspUserCodeType;
	}

	public void setsRspUserCodeType(String sRspUserCodeType) {
		this.sRspUserCodeType = sRspUserCodeType;
	}

	public String getsTextAnswer() {
		return sTextAnswer;
	}

	public void setsTextAnswer(String sTextAnswer) {
		this.sTextAnswer = sTextAnswer;
	}

	public String getsUserID() {
		return sUserID;
	}

	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
	
}
