/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� Ư�� DTO (vLTIDA02)
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "joinTheRiderDesignDTO")
public class JoinTheRiderDesignDTO {
	/** ���Կ��� (���Խ� 1, �̰��� : '')**/
	private String chk;
	/** ���Աݾ� (hashkey "InsAmt"�� sCd)**/
	private String nTrtyInsAmt;
	/** �⺻���ñ����ڵ� **/
	private String BascSlctFlagCd;
	/** �Ǽպ��豸���ڵ� **/
	private String PmmiInsurFlagCd;
	/** ��ʺ���Ư�࿩�� **/
	private String PronCmpsTrtyYn;
	/** ���ſ��౸���ڵ� **/
	private String RenwlUseCrFlagCd;
	/** ����Ư���ڵ� **/
	private String RenwlTrtyCd;
	/** �������������ڵ� **/
	private String sGrntAccuFlagCd;
	/** ����Ⱓ�ڵ� **/
	private String sInsurTermCd;
	/** ���ԱⰣ�ڵ� **/
	private String sPaymTermCd;
	/** ȭ����¿��� **/
	private String sScrnIndcYn;
	/** Ư���ڵ� **/
	private String sTrtyCd;
	/** Ư�౸���ڵ� **/
	private String TrtyFlagCd;
	/** Ư�������ڵ� **/
	private String TrtyTypeCd;

	// �Ⱓ�迡 ȣ��� ȣ���� RenwlUseCrFlagCd, RenwlTrtyCd���� ������ ����
	// �� �׷����� �𸣰����� �׷��� �ؾ��Ѵٰ� ��..
	// ���� ȭ�鿡�� ����� �ʿ����..
	private String sRenwlUseCrFlgcd;
	private String sRenwlTrtyCd;
	//ȭ�纸��
	/** 	����������	 **/ 
	private String 	TrtyObjtFlag;
	/** 	���غ���ᱸ��1	 **/ 
	private String 	StndPremTablFlag1;
	/** 	���غ���ᱸ��2	 **/ 
	private String 	StndPremTablFlag2;
	/** 	���غ���ᱸ��3	 **/ 
	private String 	StndPremTablFlag3;
	/** 	���غ���ᱸ��4	 **/ 
	private String 	StndPremTablFlag4;
	/** 	���غ���ᱸ��5	 **/ 
	private String 	StndPremTablFlag5;
	/** 	�ι�����	 **/ 
	private String 	sPsnPrprtGroupFlgcd;
	/** 	Ư�����	 **/ 
	private String 	nPsnPrprtGroupSeqno;
	
	/** 	������	 **/ 
	private String 	sGnrzCd;
	
	/**
	 * @return the chk
	 */
	public String getChk() {
		return chk;
	}

	/**
	 * @param chk the chk to set
	 */
	public void setChk(final String chk) {
		this.chk = chk;
	}

	/**
	 * @return the nTrtyInsAmt
	 */
	public String getnTrtyInsAmt() {
		return nTrtyInsAmt;
	}

	/**
	 * @param nTrtyInsAmt the nTrtyInsAmt to set
	 */
	public void setnTrtyInsAmt(final String nTrtyInsAmt) {
		this.nTrtyInsAmt = nTrtyInsAmt;
	}

	/**
	 * @return the bascSlctFlagCd
	 */
	public String getBascSlctFlagCd() {
		return BascSlctFlagCd;
	}

	/**
	 * @param bascSlctFlagCd the bascSlctFlagCd to set
	 */
	public void setBascSlctFlagCd(final String bascSlctFlagCd) {
		BascSlctFlagCd = bascSlctFlagCd;
	}

	/**
	 * @return the pmmiInsurFlagCd
	 */
	public String getPmmiInsurFlagCd() {
		return PmmiInsurFlagCd;
	}

	/**
	 * @param pmmiInsurFlagCd the pmmiInsurFlagCd to set
	 */
	public void setPmmiInsurFlagCd(final String pmmiInsurFlagCd) {
		PmmiInsurFlagCd = pmmiInsurFlagCd;
	}

	/**
	 * @return the pronCmpsTrtyYn
	 */
	public String getPronCmpsTrtyYn() {
		return PronCmpsTrtyYn;
	}

	/**
	 * @param pronCmpsTrtyYn the pronCmpsTrtyYn to set
	 */
	public void setPronCmpsTrtyYn(final String pronCmpsTrtyYn) {
		PronCmpsTrtyYn = pronCmpsTrtyYn;
	}

	/**
	 * @return the renwlUseCrFlagCd
	 */
	public String getRenwlUseCrFlagCd() {
		return RenwlUseCrFlagCd;
	}

	/**
	 * @param renwlUseCrFlagCd the renwlUseCrFlagCd to set
	 */
	public void setRenwlUseCrFlagCd(final String renwlUseCrFlagCd) {
		RenwlUseCrFlagCd = renwlUseCrFlagCd;
	}

	/**
	 * @return the sRenwlTrtyCd
	 */
	public String getsRenwlTrtyCd() {
		return sRenwlTrtyCd;
	}

	/**
	 * @param sRenwlTrtyCd the sRenwlTrtyCd to set
	 */
	public void setsRenwlTrtyCd(final String sRenwlTrtyCd) {
		this.sRenwlTrtyCd = sRenwlTrtyCd;
	}

	/**
	 * @return the sGrntAccuFlagCd
	 */
	public String getsGrntAccuFlagCd() {
		return sGrntAccuFlagCd;
	}

	/**
	 * @param sGrntAccuFlagCd the sGrntAccuFlagCd to set
	 */
	public void setsGrntAccuFlagCd(final String sGrntAccuFlagCd) {
		this.sGrntAccuFlagCd = sGrntAccuFlagCd;
	}

	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}

	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(final String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}

	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}

	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(final String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}

	/**
	 * @return the sScrnIndcYn
	 */
	public String getsScrnIndcYn() {
		return sScrnIndcYn;
	}

	/**
	 * @param sScrnIndcYn the sScrnIndcYn to set
	 */
	public void setsScrnIndcYn(final String sScrnIndcYn) {
		this.sScrnIndcYn = sScrnIndcYn;
	}

	/**
	 * @return the sTrtyCd
	 */
	public String getsTrtyCd() {
		return sTrtyCd;
	}

	/**
	 * @param sTrtyCd the sTrtyCd to set
	 */
	public void setsTrtyCd(final String sTrtyCd) {
		this.sTrtyCd = sTrtyCd;
	}

	/**
	 * @return the trtyFlagCd
	 */
	public String getTrtyFlagCd() {
		return TrtyFlagCd;
	}

	/**
	 * @param trtyFlagCd the trtyFlagCd to set
	 */
	public void setTrtyFlagCd(final String trtyFlagCd) {
		TrtyFlagCd = trtyFlagCd;
	}

	/**
	 * @return the trtyTypeCd
	 */
	public String getTrtyTypeCd() {
		return TrtyTypeCd;
	}

	/**
	 * @param trtyTypeCd the trtyTypeCd to set
	 */
	public void setTrtyTypeCd(final String trtyTypeCd) {
		TrtyTypeCd = trtyTypeCd;
	}

	/**
	 * @return the renwlTrtyCd
	 */
	public String getRenwlTrtyCd() {
		return RenwlTrtyCd;
	}

	/**
	 * @param renwlTrtyCd the renwlTrtyCd to set
	 */
	public void setRenwlTrtyCd(final String renwlTrtyCd) {
		RenwlTrtyCd = renwlTrtyCd;
	}

	/**
	 * @return the sRenwlUseCrFlgcd
	 */
	public String getsRenwlUseCrFlgcd() {
		return sRenwlUseCrFlgcd;
	}

	/**
	 * @param sRenwlUseCrFlgcd the sRenwlUseCrFlgcd to set
	 */
	public void setsRenwlUseCrFlgcd(final String sRenwlUseCrFlgcd) {
		this.sRenwlUseCrFlgcd = sRenwlUseCrFlgcd;
	}

	/**
	 * @return the trtyObjtFlag
	 */
	public String getTrtyObjtFlag() {
		return TrtyObjtFlag;
	}

	/**
	 * @param trtyObjtFlag the trtyObjtFlag to set
	 */
	public void setTrtyObjtFlag(String trtyObjtFlag) {
		TrtyObjtFlag = trtyObjtFlag;
	}

	/**
	 * @return the stndPremTablFlag1
	 */
	public String getStndPremTablFlag1() {
		return StndPremTablFlag1;
	}

	/**
	 * @param stndPremTablFlag1 the stndPremTablFlag1 to set
	 */
	public void setStndPremTablFlag1(String stndPremTablFlag1) {
		StndPremTablFlag1 = stndPremTablFlag1;
	}

	/**
	 * @return the stndPremTablFlag2
	 */
	public String getStndPremTablFlag2() {
		return StndPremTablFlag2;
	}

	/**
	 * @param stndPremTablFlag2 the stndPremTablFlag2 to set
	 */
	public void setStndPremTablFlag2(String stndPremTablFlag2) {
		StndPremTablFlag2 = stndPremTablFlag2;
	}

	/**
	 * @return the stndPremTablFlag3
	 */
	public String getStndPremTablFlag3() {
		return StndPremTablFlag3;
	}

	/**
	 * @param stndPremTablFlag3 the stndPremTablFlag3 to set
	 */
	public void setStndPremTablFlag3(String stndPremTablFlag3) {
		StndPremTablFlag3 = stndPremTablFlag3;
	}

	/**
	 * @return the stndPremTablFlag4
	 */
	public String getStndPremTablFlag4() {
		return StndPremTablFlag4;
	}

	/**
	 * @param stndPremTablFlag4 the stndPremTablFlag4 to set
	 */
	public void setStndPremTablFlag4(String stndPremTablFlag4) {
		StndPremTablFlag4 = stndPremTablFlag4;
	}

	/**
	 * @return the stndPremTablFlag5
	 */
	public String getStndPremTablFlag5() {
		return StndPremTablFlag5;
	}

	/**
	 * @param stndPremTablFlag5 the stndPremTablFlag5 to set
	 */
	public void setStndPremTablFlag5(String stndPremTablFlag5) {
		StndPremTablFlag5 = stndPremTablFlag5;
	}

	/**
	 * @return the sPsnPrprtGroupFlgcd
	 */
	public String getsPsnPrprtGroupFlgcd() {
		return sPsnPrprtGroupFlgcd;
	}

	/**
	 * @param sPsnPrprtGroupFlgcd the sPsnPrprtGroupFlgcd to set
	 */
	public void setsPsnPrprtGroupFlgcd(String sPsnPrprtGroupFlgcd) {
		this.sPsnPrprtGroupFlgcd = sPsnPrprtGroupFlgcd;
	}

	/**
	 * @return the nPsnPrprtGroupSeqno
	 */
	public String getnPsnPrprtGroupSeqno() {
		return nPsnPrprtGroupSeqno;
	}

	/**
	 * @param nPsnPrprtGroupSeqno the nPsnPrprtGroupSeqno to set
	 */
	public void setnPsnPrprtGroupSeqno(String nPsnPrprtGroupSeqno) {
		this.nPsnPrprtGroupSeqno = nPsnPrprtGroupSeqno;
	}

	/**
	 * @return the sGnrzCd
	 */
	public String getsGnrzCd() {
		return sGnrzCd;
	}

	/**
	 * @param sGnrzCd the sGnrzCd to set
	 */
	public void setsGnrzCd(String sGnrzCd) {
		this.sGnrzCd = sGnrzCd;
	}

	

}
