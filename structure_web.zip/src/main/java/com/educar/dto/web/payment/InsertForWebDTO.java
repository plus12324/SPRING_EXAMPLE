/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���/�������� ����
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insertForWebDTO")
public class InsertForWebDTO {
	/** ����ȣ **/
	private String sCrNo;
	/** �������� (01:������ü, 02:ī����ü) **/
	private String sAcctKind;
	/** ��ü������ **/
	private String sTrnfAsmtDate;
	/** �����ڵ� **/
	private String sBankCd;
	/** ���¹�ȣ / ī���ȣ **/
	private String sAcctNo;
	/** ī����ȿ�Ⱓ **/
	private String sCardValdYearMnth;
	/** �����ָ� / ī������ڸ� **/
	private String sDpsrName;
	/** ����ڸ� (1 step ���� ������ �ּ���~!!) **/
	private String sCrtorName;
	/** ������ֹι�ȣ (1 step ���� ������ �ּ���~!!) **/
	private String sCrtorCd;
	/** �������ֹι�ȣ (1 step ���� ������ �ּ���~!!) **/
	private String sDpsrCd;

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

	/**
	 * @return the sAcctKind
	 */
	public String getsAcctKind() {
		return sAcctKind;
	}

	/**
	 * @param sAcctKind the sAcctKind to set
	 */
	public void setsAcctKind(final String sAcctKind) {
		this.sAcctKind = sAcctKind;
	}

	/**
	 * @return the sTrnfAsmtDate
	 */
	public String getsTrnfAsmtDate() {
		return sTrnfAsmtDate;
	}

	/**
	 * @param sTrnfAsmtDate the sTrnfAsmtDate to set
	 */
	public void setsTrnfAsmtDate(final String sTrnfAsmtDate) {
		this.sTrnfAsmtDate = sTrnfAsmtDate;
	}

	/**
	 * @return the sBankCd
	 */
	public String getsBankCd() {
		return sBankCd;
	}

	/**
	 * @param sBankCd the sBankCd to set
	 */
	public void setsBankCd(final String sBankCd) {
		this.sBankCd = sBankCd;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sCardValdYearMnth
	 */
	public String getsCardValdYearMnth() {
		return sCardValdYearMnth;
	}

	/**
	 * @param sCardValdYearMnth the sCardValdYearMnth to set
	 */
	public void setsCardValdYearMnth(final String sCardValdYearMnth) {
		this.sCardValdYearMnth = sCardValdYearMnth;
	}

	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}

	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(final String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}

	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}

	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(final String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}

	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}

	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(final String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}

	/**
	 * @return the sDpsrCd
	 */
	public String getsDpsrCd() {
		return sDpsrCd;
	}

	/**
	 * @param sDpsrCd the sDpsrCd to set
	 */
	public void setsDpsrCd(final String sDpsrCd) {
		this.sDpsrCd = sDpsrCd;
	}

}
