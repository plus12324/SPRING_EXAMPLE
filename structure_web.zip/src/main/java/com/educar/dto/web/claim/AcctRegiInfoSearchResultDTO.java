/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� ��� ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "acctRegiInfoSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AcctRegiInfoSearchResultDTO {
	/** �����ȣ **/
	private String sAccidentNo;
	
	/** ���͸� **/
	private String sCenterName;
	
	/** ����ڸ� **/
	private String sStaffName;
	
	/** ����ڿ���ó1 **/
	private String sCellTel1;
	
	/** ����ڿ���ó2 **/
	private String sCellTel2;
	
	/** ����ڿ���ó3 **/
	private String sCellTel3;
	
	/**
	 * @return the sCenterName
	 */
	public String getsCenterName() {
		return sCenterName;
	}

	/**
	 * @param sCenterName the sCenterName to set
	 */
	public void setsCenterName(String sCenterName) {
		this.sCenterName = sCenterName;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sCellTel1
	 */
	public String getsCellTel1() {
		return sCellTel1;
	}

	/**
	 * @param sCellTel1 the sCellTel1 to set
	 */
	public void setsCellTel1(String sCellTel1) {
		this.sCellTel1 = sCellTel1;
	}

	/**
	 * @return the sCellTel2
	 */
	public String getsCellTel2() {
		return sCellTel2;
	}

	/**
	 * @param sCellTel2 the sCellTel2 to set
	 */
	public void setsCellTel2(String sCellTel2) {
		this.sCellTel2 = sCellTel2;
	}

	/**
	 * @return the sCellTel3
	 */
	public String getsCellTel3() {
		return sCellTel3;
	}

	/**
	 * @param sCellTel3 the sCellTel3 to set
	 */
	public void setsCellTel3(String sCellTel3) {
		this.sCellTel3 = sCellTel3;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

}
