/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���غ��� ������ ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "getContData2ndEditionResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class GetContData2ndEditionResultDTO {
	/** ��ǰ�� **/
	private String sSangpumName;
	/** ����ȣ **/
	private String sContNum;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** �Ǻ���������� **/
	private String nInsAimSeq;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** ����ڸ� **/
	private String sPolHolderName;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ����Ⱓ **/
	private String period;
	/** �������ڵ� **/
	private String sPolStat;
	/** �������ѱ۸� **/
	private String sPolStatName;
	/** ������ **/
	private String sRectDate;
	/** �����ð� **/
	private String sRectTime;
	/** ���ǰ����ڵ� **/
	private String sMajInsrdRel;

	/**
	 * @return the sSangpumName
	 */
	public String getsSangpumName() {
		return sSangpumName;
	}

	/**
	 * @param sSangpumName the sSangpumName to set
	 */
	public void setsSangpumName(final String sSangpumName) {
		this.sSangpumName = sSangpumName;
	}

	/**
	 * @return the sContNum
	 */
	public String getsContNum() {
		return sContNum;
	}

	/**
	 * @param sContNum the sContNum to set
	 */
	public void setsContNum(final String sContNum) {
		this.sContNum = sContNum;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the nInsAimSeq
	 */
	public String getnInsAimSeq() {
		return nInsAimSeq;
	}

	/**
	 * @param nInsAimSeq the nInsAimSeq to set
	 */
	public void setnInsAimSeq(final String nInsAimSeq) {
		this.nInsAimSeq = nInsAimSeq;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}

	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(final String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(final String period) {
		this.period = period;
	}

	/**
	 * @return the sPolStat
	 */
	public String getsPolStat() {
		return sPolStat;
	}

	/**
	 * @param sPolStat the sPolStat to set
	 */
	public void setsPolStat(final String sPolStat) {
		this.sPolStat = sPolStat;
	}

	/**
	 * @return the sPolStatName
	 */
	public String getsPolStatName() {
		return sPolStatName;
	}

	/**
	 * @param sPolStatName the sPolStatName to set
	 */
	public void setsPolStatName(final String sPolStatName) {
		this.sPolStatName = sPolStatName;
	}

	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}

	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(final String sRectDate) {
		this.sRectDate = sRectDate;
	}

	/**
	 * @return the sRectTime
	 */
	public String getsRectTime() {
		return sRectTime;
	}

	/**
	 * @param sRectTime the sRectTime to set
	 */
	public void setsRectTime(final String sRectTime) {
		this.sRectTime = sRectTime;
	}

	/**
	 * @return the sMajInsrdRel
	 */
	public String getsMajInsrdRel() {
		return sMajInsrdRel;
	}

	/**
	 * @param sMajInsrdRel the sMajInsrdRel to set
	 */
	public void setsMajInsrdRel(final String sMajInsrdRel) {
		this.sMajInsrdRel = sMajInsrdRel;
	}

}
