/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �輭 �㺸 ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorsePawnListResultDTO")
public class EndorsePawnListResultDTO {
	/** pola001Info **/
	private EndorsePawnListOfPola001InfoDTO pola001Info;
	/** ����1 **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0101;
	/** ����2 **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0102;
	/** �빰 **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0103;
	/** �ڼ� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0201;
	/** �ڻ� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0202;
	/** �λ� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0203;
	/** ��������� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0301;
	/** �ڱ��������� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0401;
	/** �ڱ�δ���� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404;
	/** �ڱ�δ������ **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404Min;
	/** �ڱ�δ���ִ� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404Max;
	/** ��ü����� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0403;
	/** ����⵿ **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0501;
	/** ����⵿ **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0523;
	

	/**
	 * @return the pola001Info
	 */
	public EndorsePawnListOfPola001InfoDTO getPola001Info() {
		return pola001Info;
	}

	/**
	 * @param pola001Info the pola001Info to set
	 */
	public void setPola001Info(final EndorsePawnListOfPola001InfoDTO pola001Info) {
		this.pola001Info = pola001Info;
	}

	/**
	 * @return the displayCoverOptVt0101
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0101() {
		return displayCoverOptVt0101;
	}

	/**
	 * @param displayCoverOptVt0101 the displayCoverOptVt0101 to set
	 */
	public void setDisplayCoverOptVt0101(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0101) {
		this.displayCoverOptVt0101 = displayCoverOptVt0101;
	}

	/**
	 * @return the displayCoverOptVt0102
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0102() {
		return displayCoverOptVt0102;
	}

	/**
	 * @param displayCoverOptVt0102 the displayCoverOptVt0102 to set
	 */
	public void setDisplayCoverOptVt0102(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0102) {
		this.displayCoverOptVt0102 = displayCoverOptVt0102;
	}

	/**
	 * @return the displayCoverOptVt0103
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0103() {
		return displayCoverOptVt0103;
	}

	/**
	 * @param displayCoverOptVt0103 the displayCoverOptVt0103 to set
	 */
	public void setDisplayCoverOptVt0103(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0103) {
		this.displayCoverOptVt0103 = displayCoverOptVt0103;
	}

	/**
	 * @return the displayCoverOptVt0201
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0201() {
		return displayCoverOptVt0201;
	}

	/**
	 * @param displayCoverOptVt0201 the displayCoverOptVt0201 to set
	 */
	public void setDisplayCoverOptVt0201(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0201) {
		this.displayCoverOptVt0201 = displayCoverOptVt0201;
	}

	/**
	 * @return the displayCoverOptVt0202
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0202() {
		return displayCoverOptVt0202;
	}

	/**
	 * @param displayCoverOptVt0202 the displayCoverOptVt0202 to set
	 */
	public void setDisplayCoverOptVt0202(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0202) {
		this.displayCoverOptVt0202 = displayCoverOptVt0202;
	}

	/**
	 * @return the displayCoverOptVt0203
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0203() {
		return displayCoverOptVt0203;
	}

	/**
	 * @param displayCoverOptVt0203 the displayCoverOptVt0203 to set
	 */
	public void setDisplayCoverOptVt0203(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0203) {
		this.displayCoverOptVt0203 = displayCoverOptVt0203;
	}

	/**
	 * @return the displayCoverOptVt0301
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0301() {
		return displayCoverOptVt0301;
	}

	/**
	 * @param displayCoverOptVt0301 the displayCoverOptVt0301 to set
	 */
	public void setDisplayCoverOptVt0301(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0301) {
		this.displayCoverOptVt0301 = displayCoverOptVt0301;
	}

	/**
	 * @return the displayCoverOptVt0401
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0401() {
		return displayCoverOptVt0401;
	}

	/**
	 * @param displayCoverOptVt0401 the displayCoverOptVt0401 to set
	 */
	public void setDisplayCoverOptVt0401(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0401) {
		this.displayCoverOptVt0401 = displayCoverOptVt0401;
	}

	/**
	 * @return the displayCoverOptVt0404
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0404() {
		return displayCoverOptVt0404;
	}

	/**
	 * @param displayCoverOptVt0404 the displayCoverOptVt0404 to set
	 */
	public void setDisplayCoverOptVt0404(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404) {
		this.displayCoverOptVt0404 = displayCoverOptVt0404;
	}

	/**
	 * @return the displayCoverOptVt0404Min
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0404Min() {
		return displayCoverOptVt0404Min;
	}

	/**
	 * @param displayCoverOptVt0404Min the displayCoverOptVt0404Min to set
	 */
	public void setDisplayCoverOptVt0404Min(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404Min) {
		this.displayCoverOptVt0404Min = displayCoverOptVt0404Min;
	}

	/**
	 * @return the displayCoverOptVt0404Max
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0404Max() {
		return displayCoverOptVt0404Max;
	}

	/**
	 * @param displayCoverOptVt0404Max the displayCoverOptVt0404Max to set
	 */
	public void setDisplayCoverOptVt0404Max(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0404Max) {
		this.displayCoverOptVt0404Max = displayCoverOptVt0404Max;
	}

	/**
	 * @return the displayCoverOptVt0403
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0403() {
		return displayCoverOptVt0403;
	}

	/**
	 * @param displayCoverOptVt0403 the displayCoverOptVt0403 to set
	 */
	public void setDisplayCoverOptVt0403(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0403) {
		this.displayCoverOptVt0403 = displayCoverOptVt0403;
	}

	/**
	 * @return the displayCoverOptVt0501
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0501() {
		return displayCoverOptVt0501;
	}

	/**
	 * @param displayCoverOptVt0501 the displayCoverOptVt0501 to set
	 */
	public void setDisplayCoverOptVt0501(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0501) {
		this.displayCoverOptVt0501 = displayCoverOptVt0501;
	}

	/**
	 * @return the displayCoverOptVt0523
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0523() {
		return displayCoverOptVt0523;
	}

	/**
	 * @param displayCoverOptVt0523 the displayCoverOptVt0523 to set
	 */
	public void setDisplayCoverOptVt0523(
			List<EndorsePawnListOfCoverDTO> displayCoverOptVt0523) {
		this.displayCoverOptVt0523 = displayCoverOptVt0523;
	}
	

}
