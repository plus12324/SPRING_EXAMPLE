/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��ü���, ������� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "comCodeDTO")
public class ComCodeDTO {
	/** �ڵ� **/
	private String sCodeId;
	/** �ڵ� �� **/
	private String sCodeName;

	/**
	 * @return the sCodeId
	 */
	public String getsCodeId() {
		return sCodeId;
	}

	/**
	 * @param sCodeId the sCodeId to set
	 */
	public void setsCodeId(final String sCodeId) {
		this.sCodeId = sCodeId;
	}

	/**
	 * @return the sCodeName
	 */
	public String getsCodeName() {
		return sCodeName;
	}

	/**
	 * @param sCodeName the sCodeName to set
	 */
	public void setsCodeName(final String sCodeName) {
		this.sCodeName = sCodeName;
	}

}
