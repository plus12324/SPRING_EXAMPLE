/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCntrDtlResultDTO")
public class SelectCntrDtlResultDTO {
	/** ��� �� **/
	private List<SelectCntrDtlOfLtiea00DtlDTO> CNTR;
	/** �Ǻ����� **/
	private List<SelectCntrDtlOfLtiea01PiboDTO> PIBO;
	/** ����Ư�� **/
	private List<SelectCntrDtlOfTrtyDTO> TRTY;

	/**
	 * @return the cNTR
	 */
	public List<SelectCntrDtlOfLtiea00DtlDTO> getCNTR() {
		return CNTR;
	}

	/**
	 * @param cNTR the cNTR to set
	 */
	public void setCNTR(final List<SelectCntrDtlOfLtiea00DtlDTO> cNTR) {
		CNTR = cNTR;
	}

	/**
	 * @return the pIBO
	 */
	public List<SelectCntrDtlOfLtiea01PiboDTO> getPIBO() {
		return PIBO;
	}

	/**
	 * @param pIBO the pIBO to set
	 */
	public void setPIBO(final List<SelectCntrDtlOfLtiea01PiboDTO> pIBO) {
		PIBO = pIBO;
	}

	/**
	 * @return the tRTY
	 */
	public List<SelectCntrDtlOfTrtyDTO> getTRTY() {
		return TRTY;
	}

	/**
	 * @param tRTY the tRTY to set
	 */
	public void setTRTY(final List<SelectCntrDtlOfTrtyDTO> tRTY) {
		TRTY = tRTY;
	}
}
