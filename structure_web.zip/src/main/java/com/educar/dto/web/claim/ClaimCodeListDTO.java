/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "claimCodeListDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimCodeListDTO {
	
	/**�Ǻ����ڿ��� ����**/ 
	@XmlElementWrapper(name = "RELATIONLIST")
	private List<ClaimCodeDTO> RELATION; 
	
	/**���������ڵ�**/ 
	@XmlElementWrapper(name = "LICENSELIST")
	private List<ClaimCodeDTO> LICENSE; 
	
	/**�㺸�ڵ�**/ 
	@XmlElementWrapper(name = "PAWNLIST")
	private List<ClaimCodeDTO> PAWN;

	/**
	 * @return the rELATION
	 */
	public List<ClaimCodeDTO> getRELATION() {
		return RELATION;
	}

	/**
	 * @param rELATION the rELATION to set
	 */
	public void setRELATION(List<ClaimCodeDTO> rELATION) {
		RELATION = rELATION;
	}

	/**
	 * @return the lICENSE
	 */
	public List<ClaimCodeDTO> getLICENSE() {
		return LICENSE;
	}

	/**
	 * @param lICENSE the lICENSE to set
	 */
	public void setLICENSE(List<ClaimCodeDTO> lICENSE) {
		LICENSE = lICENSE;
	}

	/**
	 * @return the pAWN
	 */
	public List<ClaimCodeDTO> getPAWN() {
		return PAWN;
	}

	/**
	 * @param pAWN the pAWN to set
	 */
	public void setPAWN(List<ClaimCodeDTO> pAWN) {
		PAWN = pAWN;
	} 
	
	

}
