/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (��������)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfPolca02InfoDTO")
public class InsuranceCarDetailOfPolca02InfoDTO {
	/** ���԰�� **/
	private String nBi1CareerRate;
	/** ǥ�ذ��԰�¿���(����) **/
	private String nCareerRate;
	/** ������������ڵ� **/
	private String sViolateCode;
	/** ������������� **/
	private String nViolateRate;
	/** ���������������� **/
	private String nRangeRate;
	/** �������� **/
	private String nApplyRate;
	/** Ư�������ڵ� **/
	private String sExtraCode;
	/** Ư������ **/
	private String nExtraRate;
	/** ǥ�����������ڵ� **/
	private String sApplyCode;
	/** �г��������� **/
	private String nDefaultRate;
	/** ����������� **/
	private String macTKCDName;
	/** ��������/Ư������ **/
	private String sApplyCodeDisplay;
	/** ������Ư������ **/
	private String sCareerDisplay;

	/**
	 * @return the nBi1CareerRate
	 */
	public String getnBi1CareerRate() {
		return nBi1CareerRate;
	}

	/**
	 * @param nBi1CareerRate the nBi1CareerRate to set
	 */
	public void setnBi1CareerRate(final String nBi1CareerRate) {
		this.nBi1CareerRate = nBi1CareerRate;
	}

	/**
	 * @return the nCareerRate
	 */
	public String getnCareerRate() {
		return nCareerRate;
	}

	/**
	 * @param nCareerRate the nCareerRate to set
	 */
	public void setnCareerRate(final String nCareerRate) {
		this.nCareerRate = nCareerRate;
	}

	/**
	 * @return the sViolateCode
	 */
	public String getsViolateCode() {
		return sViolateCode;
	}

	/**
	 * @param sViolateCode the sViolateCode to set
	 */
	public void setsViolateCode(final String sViolateCode) {
		this.sViolateCode = sViolateCode;
	}

	/**
	 * @return the nViolateRate
	 */
	public String getnViolateRate() {
		return nViolateRate;
	}

	/**
	 * @param nViolateRate the nViolateRate to set
	 */
	public void setnViolateRate(final String nViolateRate) {
		this.nViolateRate = nViolateRate;
	}

	/**
	 * @return the nRangeRate
	 */
	public String getnRangeRate() {
		return nRangeRate;
	}

	/**
	 * @param nRangeRate the nRangeRate to set
	 */
	public void setnRangeRate(final String nRangeRate) {
		this.nRangeRate = nRangeRate;
	}

	/**
	 * @return the nApplyRate
	 */
	public String getnApplyRate() {
		return nApplyRate;
	}

	/**
	 * @param nApplyRate the nApplyRate to set
	 */
	public void setnApplyRate(final String nApplyRate) {
		this.nApplyRate = nApplyRate;
	}

	/**
	 * @return the sExtraCode
	 */
	public String getsExtraCode() {
		return sExtraCode;
	}

	/**
	 * @param sExtraCode the sExtraCode to set
	 */
	public void setsExtraCode(final String sExtraCode) {
		this.sExtraCode = sExtraCode;
	}

	/**
	 * @return the nExtraRate
	 */
	public String getnExtraRate() {
		return nExtraRate;
	}

	/**
	 * @param nExtraRate the nExtraRate to set
	 */
	public void setnExtraRate(final String nExtraRate) {
		this.nExtraRate = nExtraRate;
	}

	/**
	 * @return the sApplyCode
	 */
	public String getsApplyCode() {
		return sApplyCode;
	}

	/**
	 * @param sApplyCode the sApplyCode to set
	 */
	public void setsApplyCode(final String sApplyCode) {
		this.sApplyCode = sApplyCode;
	}

	/**
	 * @return the nDefaultRate
	 */
	public String getnDefaultRate() {
		return nDefaultRate;
	}

	/**
	 * @param nDefaultRate the nDefaultRate to set
	 */
	public void setnDefaultRate(final String nDefaultRate) {
		this.nDefaultRate = nDefaultRate;
	}

	/**
	 * @return the macTKCDName
	 */
	public String getMacTKCDName() {
		return macTKCDName;
	}

	/**
	 * @param macTKCDName the macTKCDName to set
	 */
	public void setMacTKCDName(final String macTKCDName) {
		this.macTKCDName = macTKCDName;
	}

	/**
	 * @return the sApplyCodeDisplay
	 */
	public String getsApplyCodeDisplay() {
		return sApplyCodeDisplay;
	}

	/**
	 * @param sApplyCodeDisplay the sApplyCodeDisplay to set
	 */
	public void setsApplyCodeDisplay(final String sApplyCodeDisplay) {
		this.sApplyCodeDisplay = sApplyCodeDisplay;
	}

	/**
	 * @return the sCareerDisplay
	 */
	public String getsCareerDisplay() {
		return sCareerDisplay;
	}

	/**
	 * @param sCareerDisplay the sCareerDisplay to set
	 */
	public void setsCareerDisplay(final String sCareerDisplay) {
		this.sCareerDisplay = sCareerDisplay;
	}

}
