/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����� ���� - ��� ����� ����
 * @author 
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insLongRecvSpecSaveDTO")
public class InsLongPayResultDTO{
	/** 	�������ڵ�		 **/ 
	private String 	sRecvStnbyStatCd;
	/** 	�����ǰ��	 **/ 
	private String 	sGdCdName;
	/** 	�������		 **/ 
	private String 	sCmMetdName;
	/**		�����ݾ� 		 **/
	private String nPaymPremSum;
	/**
	 * @return the sRecvStnbyStatCd
	 */
	public String getsRecvStnbyStatCd() {
		return sRecvStnbyStatCd;
	}
	/**
	 * @param sRecvStnbyStatCd the sRecvStnbyStatCd to set
	 */
	public void setsRecvStnbyStatCd(String sRecvStnbyStatCd) {
		this.sRecvStnbyStatCd = sRecvStnbyStatCd;
	}
	/**
	 * @return the sGdCdName
	 */
	public String getsGdCdName() {
		return sGdCdName;
	}
	/**
	 * @param sGdCdName the sGdCdName to set
	 */
	public void setsGdCdName(String sGdCdName) {
		this.sGdCdName = sGdCdName;
	}
	/**
	 * @return the sCmMetdName
	 */
	public String getsCmMetdName() {
		return sCmMetdName;
	}
	/**
	 * @param sCmMetdName the sCmMetdName to set
	 */
	public void setsCmMetdName(String sCmMetdName) {
		this.sCmMetdName = sCmMetdName;
	}
	/**
	 * @return the nPaymPremSum
	 */
	public String getnPaymPremSum() {
		return nPaymPremSum;
	}
	/**
	 * @param nPaymPremSum the nPaymPremSum to set
	 */
	public void setnPaymPremSum(String nPaymPremSum) {
		this.nPaymPremSum = nPaymPremSum;
	}
	
	
}
