/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorseModifySpecialResultDTO")
public class EndorseModifySpecialResultDTO {
	/** �����ڵ� **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** û����� (E':�輭�������   ���� Ȯ���� ) **/
	private String sApplyStat;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** �ָ�����Ư��㺸 (�̰���/���� -- ���Խ�.. Ȥ�ó� �ݾ��� ����.. ) **/
	private String sBefCover0509;
	/** ��Ʈ�ڵ��� (�̰���/����) **/
	private String sBefCover0510;
	/** �������� (�̰���/����) **/
	private String sBefCover0512;
	/** ����� (�̰���/����) **/
	private String sBefCover0513;
	/** ���ݺ�� (�̰���/����) **/
	private String sBefCover0514;
	/** ������ (�̰���/����) **/
	private String sBefCover0233;
	/** �ָ�����Ư��㺸 **/
	private String sBefCoverPrem0509;
	/** ��Ʈ�ڵ��� **/
	private String sBefCoverPrem0510;
	/** �������� **/
	private String sBefCoverPrem0512;
	/** ����� **/
	private String sBefCoverPrem0513;
	/** ���ݺ�� **/
	private String sBefCoverPrem0514;
	/** ������ **/
	private String sBefCoverPrem0233;
	/** �Ѱ� **/
	private String nBefTotalPrem;
	/** �ָ�����Ư��㺸 **/
	private String sAftCover0509;
	/** ��Ʈ�ڵ��� **/
	private String sAftCover0510;
	/** �������� **/
	private String sAftCover0512;
	/** ����� **/
	private String sAftCover0513;
	/** ���ݺ�� **/
	private String sAftCover0514;
	/** ������ **/
	private String sAftCover0233;
	/** �ָ�����Ư��㺸 **/
	private String sAftCoverPrem0509;
	/** ��Ʈ�ڵ��� **/
	private String sAftCoverPrem0510;
	/** �������� **/
	private String sAftCoverPrem0512;
	/** ����� **/
	private String sAftCoverPrem0513;
	/** ���ݺ�� **/
	private String sAftCoverPrem0514;
	/** ������ **/
	private String sAftCoverPrem0233;
	/** �Ѱ� **/
	private String nAftTotalPrem;
	/** ��������� **/
	private String befTotPrem;
	/** �߰����κ���� **/
	private String befAddPrem;
	/** ȯ�޺���� **/
	private String befRefundPrem;
	/** ��������� **/
	private String aftTotPrem;
	/** �߰����κ���� **/
	private String aftAddPrem;
	/** ȯ�޺���� **/
	private String aftRefundPrem;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sApplyStat
	 */
	public String getsApplyStat() {
		return sApplyStat;
	}

	/**
	 * @param sApplyStat the sApplyStat to set
	 */
	public void setsApplyStat(final String sApplyStat) {
		this.sApplyStat = sApplyStat;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @return the sBefCover0509
	 */
	public String getsBefCover0509() {
		return sBefCover0509;
	}

	/**
	 * @param sBefCover0509 the sBefCover0509 to set
	 */
	public void setsBefCover0509(final String sBefCover0509) {
		this.sBefCover0509 = sBefCover0509;
	}

	/**
	 * @return the sBefCover0510
	 */
	public String getsBefCover0510() {
		return sBefCover0510;
	}

	/**
	 * @param sBefCover0510 the sBefCover0510 to set
	 */
	public void setsBefCover0510(final String sBefCover0510) {
		this.sBefCover0510 = sBefCover0510;
	}

	/**
	 * @return the sBefCover0512
	 */
	public String getsBefCover0512() {
		return sBefCover0512;
	}

	/**
	 * @param sBefCover0512 the sBefCover0512 to set
	 */
	public void setsBefCover0512(final String sBefCover0512) {
		this.sBefCover0512 = sBefCover0512;
	}

	/**
	 * @return the sBefCover0513
	 */
	public String getsBefCover0513() {
		return sBefCover0513;
	}

	/**
	 * @param sBefCover0513 the sBefCover0513 to set
	 */
	public void setsBefCover0513(final String sBefCover0513) {
		this.sBefCover0513 = sBefCover0513;
	}

	/**
	 * @return the sBefCover0514
	 */
	public String getsBefCover0514() {
		return sBefCover0514;
	}

	/**
	 * @param sBefCover0514 the sBefCover0514 to set
	 */
	public void setsBefCover0514(final String sBefCover0514) {
		this.sBefCover0514 = sBefCover0514;
	}

	/**
	 * @return the sBefCover0233
	 */
	public String getsBefCover0233() {
		return sBefCover0233;
	}

	/**
	 * @param sBefCover0233 the sBefCover0233 to set
	 */
	public void setsBefCover0233(final String sBefCover0233) {
		this.sBefCover0233 = sBefCover0233;
	}

	/**
	 * @return the sBefCoverPrem0509
	 */
	public String getsBefCoverPrem0509() {
		return sBefCoverPrem0509;
	}

	/**
	 * @param sBefCoverPrem0509 the sBefCoverPrem0509 to set
	 */
	public void setsBefCoverPrem0509(final String sBefCoverPrem0509) {
		this.sBefCoverPrem0509 = sBefCoverPrem0509;
	}

	/**
	 * @return the sBefCoverPrem0510
	 */
	public String getsBefCoverPrem0510() {
		return sBefCoverPrem0510;
	}

	/**
	 * @param sBefCoverPrem0510 the sBefCoverPrem0510 to set
	 */
	public void setsBefCoverPrem0510(final String sBefCoverPrem0510) {
		this.sBefCoverPrem0510 = sBefCoverPrem0510;
	}

	/**
	 * @return the sBefCoverPrem0512
	 */
	public String getsBefCoverPrem0512() {
		return sBefCoverPrem0512;
	}

	/**
	 * @param sBefCoverPrem0512 the sBefCoverPrem0512 to set
	 */
	public void setsBefCoverPrem0512(final String sBefCoverPrem0512) {
		this.sBefCoverPrem0512 = sBefCoverPrem0512;
	}

	/**
	 * @return the sBefCoverPrem0513
	 */
	public String getsBefCoverPrem0513() {
		return sBefCoverPrem0513;
	}

	/**
	 * @param sBefCoverPrem0513 the sBefCoverPrem0513 to set
	 */
	public void setsBefCoverPrem0513(final String sBefCoverPrem0513) {
		this.sBefCoverPrem0513 = sBefCoverPrem0513;
	}

	/**
	 * @return the sBefCoverPrem0514
	 */
	public String getsBefCoverPrem0514() {
		return sBefCoverPrem0514;
	}

	/**
	 * @param sBefCoverPrem0514 the sBefCoverPrem0514 to set
	 */
	public void setsBefCoverPrem0514(final String sBefCoverPrem0514) {
		this.sBefCoverPrem0514 = sBefCoverPrem0514;
	}

	/**
	 * @return the sBefCoverPrem0233
	 */
	public String getsBefCoverPrem0233() {
		return sBefCoverPrem0233;
	}

	/**
	 * @param sBefCoverPrem0233 the sBefCoverPrem0233 to set
	 */
	public void setsBefCoverPrem0233(final String sBefCoverPrem0233) {
		this.sBefCoverPrem0233 = sBefCoverPrem0233;
	}

	/**
	 * @return the nBefTotalPrem
	 */
	public String getnBefTotalPrem() {
		return nBefTotalPrem;
	}

	/**
	 * @param nBefTotalPrem the nBefTotalPrem to set
	 */
	public void setnBefTotalPrem(final String nBefTotalPrem) {
		this.nBefTotalPrem = nBefTotalPrem;
	}

	/**
	 * @return the sAftCover0509
	 */
	public String getsAftCover0509() {
		return sAftCover0509;
	}

	/**
	 * @param sAftCover0509 the sAftCover0509 to set
	 */
	public void setsAftCover0509(final String sAftCover0509) {
		this.sAftCover0509 = sAftCover0509;
	}

	/**
	 * @return the sAftCover0510
	 */
	public String getsAftCover0510() {
		return sAftCover0510;
	}

	/**
	 * @param sAftCover0510 the sAftCover0510 to set
	 */
	public void setsAftCover0510(final String sAftCover0510) {
		this.sAftCover0510 = sAftCover0510;
	}

	/**
	 * @return the sAftCover0512
	 */
	public String getsAftCover0512() {
		return sAftCover0512;
	}

	/**
	 * @param sAftCover0512 the sAftCover0512 to set
	 */
	public void setsAftCover0512(final String sAftCover0512) {
		this.sAftCover0512 = sAftCover0512;
	}

	/**
	 * @return the sAftCover0513
	 */
	public String getsAftCover0513() {
		return sAftCover0513;
	}

	/**
	 * @param sAftCover0513 the sAftCover0513 to set
	 */
	public void setsAftCover0513(final String sAftCover0513) {
		this.sAftCover0513 = sAftCover0513;
	}

	/**
	 * @return the sAftCover0514
	 */
	public String getsAftCover0514() {
		return sAftCover0514;
	}

	/**
	 * @param sAftCover0514 the sAftCover0514 to set
	 */
	public void setsAftCover0514(final String sAftCover0514) {
		this.sAftCover0514 = sAftCover0514;
	}

	/**
	 * @return the sAftCover0233
	 */
	public String getsAftCover0233() {
		return sAftCover0233;
	}

	/**
	 * @param sAftCover0233 the sAftCover0233 to set
	 */
	public void setsAftCover0233(final String sAftCover0233) {
		this.sAftCover0233 = sAftCover0233;
	}

	/**
	 * @return the sAftCoverPrem0509
	 */
	public String getsAftCoverPrem0509() {
		return sAftCoverPrem0509;
	}

	/**
	 * @param sAftCoverPrem0509 the sAftCoverPrem0509 to set
	 */
	public void setsAftCoverPrem0509(final String sAftCoverPrem0509) {
		this.sAftCoverPrem0509 = sAftCoverPrem0509;
	}

	/**
	 * @return the sAftCoverPrem0510
	 */
	public String getsAftCoverPrem0510() {
		return sAftCoverPrem0510;
	}

	/**
	 * @param sAftCoverPrem0510 the sAftCoverPrem0510 to set
	 */
	public void setsAftCoverPrem0510(final String sAftCoverPrem0510) {
		this.sAftCoverPrem0510 = sAftCoverPrem0510;
	}

	/**
	 * @return the sAftCoverPrem0512
	 */
	public String getsAftCoverPrem0512() {
		return sAftCoverPrem0512;
	}

	/**
	 * @param sAftCoverPrem0512 the sAftCoverPrem0512 to set
	 */
	public void setsAftCoverPrem0512(final String sAftCoverPrem0512) {
		this.sAftCoverPrem0512 = sAftCoverPrem0512;
	}

	/**
	 * @return the sAftCoverPrem0513
	 */
	public String getsAftCoverPrem0513() {
		return sAftCoverPrem0513;
	}

	/**
	 * @param sAftCoverPrem0513 the sAftCoverPrem0513 to set
	 */
	public void setsAftCoverPrem0513(final String sAftCoverPrem0513) {
		this.sAftCoverPrem0513 = sAftCoverPrem0513;
	}

	/**
	 * @return the sAftCoverPrem0514
	 */
	public String getsAftCoverPrem0514() {
		return sAftCoverPrem0514;
	}

	/**
	 * @param sAftCoverPrem0514 the sAftCoverPrem0514 to set
	 */
	public void setsAftCoverPrem0514(final String sAftCoverPrem0514) {
		this.sAftCoverPrem0514 = sAftCoverPrem0514;
	}

	/**
	 * @return the sAftCoverPrem0233
	 */
	public String getsAftCoverPrem0233() {
		return sAftCoverPrem0233;
	}

	/**
	 * @param sAftCoverPrem0233 the sAftCoverPrem0233 to set
	 */
	public void setsAftCoverPrem0233(final String sAftCoverPrem0233) {
		this.sAftCoverPrem0233 = sAftCoverPrem0233;
	}

	/**
	 * @return the nAftTotalPrem
	 */
	public String getnAftTotalPrem() {
		return nAftTotalPrem;
	}

	/**
	 * @param nAftTotalPrem the nAftTotalPrem to set
	 */
	public void setnAftTotalPrem(final String nAftTotalPrem) {
		this.nAftTotalPrem = nAftTotalPrem;
	}

	/**
	 * @return the befTotPrem
	 */
	public String getBefTotPrem() {
		return befTotPrem;
	}

	/**
	 * @param befTotPrem the befTotPrem to set
	 */
	public void setBefTotPrem(final String befTotPrem) {
		this.befTotPrem = befTotPrem;
	}

	/**
	 * @return the befAddPrem
	 */
	public String getBefAddPrem() {
		return befAddPrem;
	}

	/**
	 * @param befAddPrem the befAddPrem to set
	 */
	public void setBefAddPrem(final String befAddPrem) {
		this.befAddPrem = befAddPrem;
	}

	/**
	 * @return the befRefundPrem
	 */
	public String getBefRefundPrem() {
		return befRefundPrem;
	}

	/**
	 * @param befRefundPrem the befRefundPrem to set
	 */
	public void setBefRefundPrem(final String befRefundPrem) {
		this.befRefundPrem = befRefundPrem;
	}

	/**
	 * @return the aftTotPrem
	 */
	public String getAftTotPrem() {
		return aftTotPrem;
	}

	/**
	 * @param aftTotPrem the aftTotPrem to set
	 */
	public void setAftTotPrem(final String aftTotPrem) {
		this.aftTotPrem = aftTotPrem;
	}

	/**
	 * @return the aftAddPrem
	 */
	public String getAftAddPrem() {
		return aftAddPrem;
	}

	/**
	 * @param aftAddPrem the aftAddPrem to set
	 */
	public void setAftAddPrem(final String aftAddPrem) {
		this.aftAddPrem = aftAddPrem;
	}

	/**
	 * @return the aftRefundPrem
	 */
	public String getAftRefundPrem() {
		return aftRefundPrem;
	}

	/**
	 * @param aftRefundPrem the aftRefundPrem to set
	 */
	public void setAftRefundPrem(final String aftRefundPrem) {
		this.aftRefundPrem = aftRefundPrem;
	}

}
