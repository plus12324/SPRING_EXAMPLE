package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

/**
 * TM�븮�� �ƿ��ٿ�� ����Ÿ �Է�
 * @author �Ž¿�
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "callOutBoundTMDTO")
public class CallOutBoundTMDTO {

	/** ������ȣ �Ǵ� ����ڹ�ȣ **/
	private String sCustNo;
	/** ������ **/
	private String sName;
	
	/** �̸��� **/
	private String sEmail;
	
	/** ����ó1 **/
	private String sTel1;
	/** ����ó2 **/
	private String sTel2;
	/** ����ó3 **/
	private String sTel3;
	
	/** �޴���1 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 3)
	private String sCellPhone1;
	/** �޴���2 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 4)
	private String sCellPhone2;
	/** �޴���3 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 4)
	private String sCellPhone3;
	
	/** ����óŸ�� (0:����, 1:����, 2:�繫, 3:�ڵ���) **/
	private String sTelType;
	
	/**�Է��� ��� 8000001**/
	private String sEmpNo;
	
	/** �ΰ����� **/
	private String sDescription;
	
	/**����û��ǰ�� **/
	private String sInsurGdNm;

	/**�̺�Ʈ �ڵ�**/
	private String sEventDiv;
	
	/** ��ǰ ���� (sInsType 1 : �����ں��� 2 : ���ຸ�� 3 : ġ�ƺ��� 6 : ȭ�纸�� 7 : �������� 8 : ���ݺ���) **/
	private String sInsType;
	
	public String getsInsType() {
		return sInsType;
	}

	public void setsInsType(String sInsType) {
		this.sInsType = sInsType;
	}

	public String getsEventDiv() {
		return sEventDiv;
	}

	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}

	public String getsCustNo() {
		return sCustNo;
	}

	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getsEmail() {
		return sEmail;
	}

	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

	public String getsTel1() {
		return sTel1;
	}

	public void setsTel1(String sTel1) {
		this.sTel1 = sTel1;
	}

	public String getsTel2() {
		return sTel2;
	}

	public void setsTel2(String sTel2) {
		this.sTel2 = sTel2;
	}

	public String getsTel3() {
		return sTel3;
	}

	public void setsTel3(String sTel3) {
		this.sTel3 = sTel3;
	}

	public String getsTelType() {
		return sTelType;
	}

	public void setsTelType(String sTelType) {
		this.sTelType = sTelType;
	}

	public String getsEmpNo() {
		return sEmpNo;
	}

	public void setsEmpNo(String sEmpNo) {
		this.sEmpNo = sEmpNo;
	}

	public String getsDescription() {
		return sDescription;
	}

	public void setsDescription(String sDescription) {
		this.sDescription = sDescription;
	}

	public String getsInsurGdNm() {
		return sInsurGdNm;
	}

	public void setsInsurGdNm(String sInsurGdNm) {
		this.sInsurGdNm = sInsurGdNm;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	
}
