/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailSearchDTO")
public class InsuranceCarDetailSearchDTO {
	/** ����ȣ���� **/
	private String sPolicyType;
	/** ����ȣ��� **/
	private String sPolicyYM;
	/** ����ȣser **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ����ȣ **/
	private String sCrNo;
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	
}
