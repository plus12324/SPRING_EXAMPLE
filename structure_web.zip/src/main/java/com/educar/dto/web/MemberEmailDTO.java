/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * ȸ���̸���(WEBDD04)
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
public class MemberEmailDTO {
	/** ȸ����ȣ(auto increment�� �ǹ̾��� ID) **/
	private long ID;
	/** ����ȸ�� **/
	private int nModiNo;
	/** ��Ʈ **/
	private String sLast;
	/** sEmail **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEmail;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;

	/**
	 * @return the iD
	 */
	public long getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	@XmlTransient
	public void setID(final long iD) {
		ID = iD;
	}

	/**
	 * @return the nModiNo
	 */
	public int getnModiNo() {
		return nModiNo;
	}

	/**
	 * @param nModiNo the nModiNo to set
	 */
	@XmlTransient
	public void setnModiNo(final int nModiNo) {
		this.nModiNo = nModiNo;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
