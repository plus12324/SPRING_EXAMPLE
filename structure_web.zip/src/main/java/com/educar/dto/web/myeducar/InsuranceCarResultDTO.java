/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ��ȸ
 * @author ������
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarResultDTO")
public class InsuranceCarResultDTO {
	/** ����ȣ TYPE **/
	private String sPolicyType;
	/** ���⵵ **/
	private String sPolicyYM;
	/** ����ȣ Ser **/
	private String sPolicySer;
	/** �����ǰ�� **/
	private String sInsTypeName;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** ����Ⱓ From **/
	private String sFmdt;
	/** ����Ⱓ To **/
	private String sTodt;
	/** ������ȣ **/
	private String sPlateNo;
	/** �������� **/
	private String sInsType;
	/** ���� **/
	private String sPolicyStat;
	/** �� **/
	private String sPolicyStatName;
	/** �����輭��ȣ **/
	private String nLastEndorseNo;

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the sInsTypeAttr_display
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}

	/**
	 * @param sInsTypeAttr_display the sInsTypeAttr_display to set
	 */
	public void setsInsTypeName(final String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sPolicyStat
	 */
	public String getsPolicyStat() {
		return sPolicyStat;
	}

	/**
	 * @param sPolicyStat the sPolicyStat to set
	 */
	public void setsPolicyStat(final String sPolicyStat) {
		this.sPolicyStat = sPolicyStat;
	}

	/**
	 * @return the sPolicyStatName
	 */
	public String getsPolicyStatName() {
		return sPolicyStatName;
	}

	/**
	 * @param sPolicyStatName the sPolicyStatName to set
	 */
	public void setsPolicyStatName(final String sPolicyStatName) {
		this.sPolicyStatName = sPolicyStatName;
	}

	/**
	 * @return the nLastEndorseNo
	 */
	public String getnLastEndorseNo() {
		return nLastEndorseNo;
	}

	/**
	 * @param nLastEndorseNo the nLastEndorseNo to set
	 */
	public void setnLastEndorseNo(String nLastEndorseNo) {
		this.nLastEndorseNo = nLastEndorseNo;
	}
	
}
