/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * ȸ������ó(WEBDD03)
 * 
 * @author ������
 * 
 */
public class MemberContactDTO {
	/** ȸ����ȣ **/
	private long ID;
	/** ����ȸ�� **/
	private int nModiNo;
	/** ��Ʈ **/
	private String sLast;
	/** �ڵ���1 (�� 4�ڸ�) **/
	private String sCellPhone1;
	/** �ڵ���2 (�߰� 4�ڸ�) **/
	private String sCellPhone2;
	/** �ڵ���3 (�� 4�ڸ�) **/
	private String sCellPhone3;
	/** �ѽ�1 (�� 4�ڸ�) **/
	private String sFax1;
	/** �ѽ�2 (�߰� 4�ڸ�) **/
	private String sFax2;
	/** �ѽ�3 (�� 4�ڸ�) **/
	private String sFax3;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;

	/**
	 * @return the iD
	 */
	public long getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final long iD) {
		ID = iD;
	}

	/**
	 * @return the nModiNo
	 */
	public int getnModiNo() {
		return nModiNo;
	}

	/**
	 * @param nModiNo the nModiNo to set
	 */
	public void setnModiNo(final int nModiNo) {
		this.nModiNo = nModiNo;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}

	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(final String sFax1) {
		this.sFax1 = sFax1;
	}

	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}

	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(final String sFax2) {
		this.sFax2 = sFax2;
	}

	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}

	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(final String sFax3) {
		this.sFax3 = sFax3;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
