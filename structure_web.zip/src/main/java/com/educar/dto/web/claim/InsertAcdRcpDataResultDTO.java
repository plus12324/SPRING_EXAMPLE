/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ������� ��� DTO
 * @author ������ 
 * @since 1.0.0
 */
@XmlRootElement(name = "insertAcdRcpDataDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAcdRcpDataResultDTO {
	/** �����ȣ(������ȣ) **/
	private String sAcdNum;
	/** ������� **/
	private String sAcdDate;
	/** ����ð� **/
	private String sAcdTime;
	/** ������ �̸� **/
	private String sName;

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sAcdNum
	 */
	public String getsAcdNum() {
		return sAcdNum;
	}

	/**
	 * @param sAcdNum the sAcdNum to set
	 */
	public void setsAcdNum(final String sAcdNum) {
		this.sAcdNum = sAcdNum;
	}

	/**
	 * @return the sAcdDate
	 */
	public String getsAcdDate() {
		return sAcdDate;
	}

	/**
	 * @param sAcdDate the sAcdDate to set
	 */
	public void setsAcdDate(final String sAcdDate) {
		this.sAcdDate = sAcdDate;
	}

	/**
	 * @return the sAcdTime
	 */
	public String getsAcdTime() {
		return sAcdTime;
	}

	/**
	 * @param sAcdTime the sAcdTime to set
	 */
	public void setsAcdTime(final String sAcdTime) {
		this.sAcdTime = sAcdTime;
	}

}
