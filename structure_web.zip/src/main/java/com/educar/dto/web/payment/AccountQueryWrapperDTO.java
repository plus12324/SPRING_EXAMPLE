/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

/**
 * ������ ��ȸ�� ���Ǵ� DTO Wrapper
 * �������� Hashkey�� ���� ��ü�� �����Ҷ� Wrapper�� ����Ѵ�
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
public class AccountQueryWrapperDTO {

	private AccountQueryACCDTO ACCZA31;

	private AccountQueryBANKDTO BANK005;

	/**
	 * @return the aCCZA31
	 */
	public AccountQueryACCDTO getACCZA31() {
		return ACCZA31;
	}

	/**
	 * @return the bANK005
	 */
	public AccountQueryBANKDTO getBANK005() {
		return BANK005;
	}

	/**
	 * @param aCCZA31 the aCCZA31 to set
	 */
	public void setACCZA31(final AccountQueryACCDTO aCCZA31) {
		ACCZA31 = aCCZA31;
	}

	/**
	 * @param bANK005 the bANK005 to set
	 */
	public void setBANK005(final AccountQueryBANKDTO bANK005) {
		BANK005 = bANK005;
	}
}
