/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;

/**
 * ���� �� ����Ʈ ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carDetailSearchDTO")
public class CarDetailSearchDTO {
	/** ��������� YYYYMMDD**/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sApplyFmdt;
	/** ����ȸ�� **/
	private String sMadeComp;
	/** ���� **/
	private String sChnm;
	/** ���� (yyyy)**/
	@ValidateDate(dateFormat = DateFormat.yyyy)
	private String sYear;
	/** ���� ���� **/
	private String sYearType;
	/** �������� (A,B) **/
	private String sNwCarGB;
	/** ���� **/
	private String sInsType;
	/** ���� **/
	private String sVehicleCode;
	/** ��������� YYYYMMDD **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd, required = false)
	private String sCarRegDate;

	/**
	 * @return the sApplyFmdt
	 */
	public String getsApplyFmdt() {
		return sApplyFmdt;
	}

	/**
	 * @param sApplyFmdt the sApplyFmdt to set
	 */
	public void setsApplyFmdt(final String sApplyFmdt) {
		this.sApplyFmdt = sApplyFmdt;
	}

	/**
	 * @return the sMadeComp
	 */
	public String getsMadeComp() {
		return sMadeComp;
	}

	/**
	 * @param sMadeComp the sMadeComp to set
	 */
	public void setsMadeComp(final String sMadeComp) {
		this.sMadeComp = sMadeComp;
	}

	/**
	 * @return the sChnm
	 */
	public String getsChnm() {
		return sChnm;
	}

	/**
	 * @param sChnm the sChnm to set
	 */
	public void setsChnm(final String sChnm) {
		this.sChnm = sChnm;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the sYearType
	 */
	public String getsYearType() {
		return sYearType;
	}

	/**
	 * @param sYearType the sYearType to set
	 */
	public void setsYearType(final String sYearType) {
		this.sYearType = sYearType;
	}

	/**
	 * @return the sNwCarGB
	 */
	public String getsNwCarGB() {
		return sNwCarGB;
	}

	/**
	 * @param sNwCarGB the sNwCarGB to set
	 */
	public void setsNwCarGB(final String sNwCarGB) {
		this.sNwCarGB = sNwCarGB;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sVehicleCode
	 */
	public String getsVehicleCode() {
		return sVehicleCode;
	}

	/**
	 * @param sVehicleCode the sVehicleCode to set
	 */
	public void setsVehicleCode(final String sVehicleCode) {
		this.sVehicleCode = sVehicleCode;
	}

	/**
	 * @return the sCarRegDate
	 */
	public String getsCarRegDate() {
		return sCarRegDate;
	}

	/**
	 * @param sCarRegDate the sCarRegDate to set
	 */
	public void setsCarRegDate(final String sCarRegDate) {
		this.sCarRegDate = sCarRegDate;
	}

}
