/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����� ���� - ��� ����� ����
 * @author 
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insLongRecvSpecSaveDTO")
public class InsLongRecvSpecSaveDTO implements Serializable {
	/** 	����ȣ		 **/ 
	private String 	sCrNo;
	/** 	�α��� �� ������		 **/ 
	private String 	sCustNm;
	/** 	�α��� �� ������ȣ		 **/ 
	private String 	sCustNo;
	/** ����ڸ� **/
	private String sCrtorName;
	
	
	/** 	��������		 **/ 
	private String 	sBizCat;
	/** 	����Ƚ��		 **/ 
	private String 	sPayCnt;
	/**     ��������Ƚ��    **/
	private String  nReqCnt;
	/** 	û���ȣ		 **/ 
	private String 	sPlanNo;
	/** 	ó������		 **/ 
	private String 	sProcCat;
	/** 	���δ�ü�����ڵ�		 **/ 
	private String 	sPsnGroupFlgcd;
	
	/** 	�޴��� ��뿩��		 **/ 
	private String 	phoneFlag;
	/** 	�̸��Ͼ�����ۿ���		 **/ 
	private String 	sEmailClasYn;
	
	/** 	������ �Ա� ��뿩��		 **/ 
	private String 	cashFlag;
	/** 	����������¹�ȣ		 **/ 
	private String 	sNonAcctThcpAcctNo;
	/** 	������������Աݾ�		 **/ 
	private String 	nNonAcctThcpAcctRvamt;
	
	
	/** 	�ſ�ī�� ��뿩��		 **/ 
	private String 	cardFlag;
	/** 	ī���ȣ		 **/ 
	private String 	sCardNo1;
	/** 	ī����ȿ�Ⱓ		 **/		
	private String sCardValdYearMnth;
	/** 	ī��ŷ��ݾ�1		 **/
	private String	nCardDlAmt1;


	/** 	�ǽð� ������ü ��뿩��		 **/ 
	private String 	transFlag;
	/** 	�������ֹι�ȣ		 **/ 
	private String 	sRealDpsrCd;
	/** 	�����ָ�		 **/ 
	private String 	sRealDpsrName;
	/** 	�ǽð�����������¹�ȣ		 **/ 
	private String 	sRealHmsRecvBankAcctNo;
	/** 	�ǽð����������ڵ�		 **/ 
	private String 	sRealHmsRecvBankCd;
	/** 	�ǽð������Աݾ�		 **/ 
	private String 	nRealHmsRecvRvamt;
	/** 	���ݰŷ��ݾ�		 **/ 
	private String 	nCashDlAmt;
	
	
	/** 	��������		 **/ 
	private String 	sRecpDate;
	/** 	�����ݾ�		 **/ 
	private String 	nRecpPrem;
	
	/** 	�����������ڵ�		 **/ 
	private String 	sThcpAcctBankCd;
	/** 	����ھ��̵�		 **/ 
	private String 	sUserID;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	
	/**
	 * @return the sCustNm
	 */
	public String getsCustNm() {
		return sCustNm;
	}
	/**
	 * @param sCustNm the sCustNm to set
	 */
	public void setsCustNm(String sCustNm) {
		this.sCustNm = sCustNm;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sBizCat
	 */
	public String getsBizCat() {
		return sBizCat;
	}
	/**
	 * @param sBizCat the sBizCat to set
	 */
	public void setsBizCat(String sBizCat) {
		this.sBizCat = sBizCat;
	}
	/**
	 * @return the sPayCnt
	 */
	public String getsPayCnt() {
		return sPayCnt;
	}
	/**
	 * @param sPayCnt the sPayCnt to set
	 */
	public void setsPayCnt(String sPayCnt) {
		this.sPayCnt = sPayCnt;
	}
	/**
	 * @return the nReqCnt
	 */
	public String getnReqCnt() {
		return nReqCnt;
	}
	/**
	 * @param nReqCnt the nReqCnt to set
	 */
	public void setnReqCnt(String nReqCnt) {
		this.nReqCnt = nReqCnt;
	}
	/**
	 * @return the sPlanNo
	 */
	public String getsPlanNo() {
		return sPlanNo;
	}
	/**
	 * @param sPlanNo the sPlanNo to set
	 */
	public void setsPlanNo(String sPlanNo) {
		this.sPlanNo = sPlanNo;
	}
	/**
	 * @return the sProcCat
	 */
	public String getsProcCat() {
		return sProcCat;
	}
	/**
	 * @param sProcCat the sProcCat to set
	 */
	public void setsProcCat(String sProcCat) {
		this.sProcCat = sProcCat;
	}
	/**
	 * @return the sPsnGroupFlgcd
	 */
	public String getsPsnGroupFlgcd() {
		return sPsnGroupFlgcd;
	}
	/**
	 * @param sPsnGroupFlgcd the sPsnGroupFlgcd to set
	 */
	public void setsPsnGroupFlgcd(String sPsnGroupFlgcd) {
		this.sPsnGroupFlgcd = sPsnGroupFlgcd;
	}
	/**
	 * @return the phoneFlag
	 */
	public String getPhoneFlag() {
		return phoneFlag;
	}
	/**
	 * @param phoneFlag the phoneFlag to set
	 */
	public void setPhoneFlag(String phoneFlag) {
		this.phoneFlag = phoneFlag;
	}
	/**
	 * @return the sEmailClasYn
	 */
	public String getsEmailClasYn() {
		return sEmailClasYn;
	}
	/**
	 * @param sEmailClasYn the sEmailClasYn to set
	 */
	public void setsEmailClasYn(String sEmailClasYn) {
		this.sEmailClasYn = sEmailClasYn;
	}
	/**
	 * @return the cashFlag
	 */
	public String getCashFlag() {
		return cashFlag;
	}
	/**
	 * @param cashFlag the cashFlag to set
	 */
	public void setCashFlag(String cashFlag) {
		this.cashFlag = cashFlag;
	}
	/**
	 * @return the sNonAcctThcpAcctNo
	 */
	public String getsNonAcctThcpAcctNo() {
		return sNonAcctThcpAcctNo;
	}
	/**
	 * @param sNonAcctThcpAcctNo the sNonAcctThcpAcctNo to set
	 */
	public void setsNonAcctThcpAcctNo(String sNonAcctThcpAcctNo) {
		this.sNonAcctThcpAcctNo = sNonAcctThcpAcctNo;
	}
	/**
	 * @return the nNonAcctThcpAcctRvamt
	 */
	public String getnNonAcctThcpAcctRvamt() {
		return nNonAcctThcpAcctRvamt;
	}
	/**
	 * @param nNonAcctThcpAcctRvamt the nNonAcctThcpAcctRvamt to set
	 */
	public void setnNonAcctThcpAcctRvamt(String nNonAcctThcpAcctRvamt) {
		this.nNonAcctThcpAcctRvamt = nNonAcctThcpAcctRvamt;
	}
	/**
	 * @return the cardFlag
	 */
	public String getCardFlag() {
		return cardFlag;
	}
	/**
	 * @param cardFlag the cardFlag to set
	 */
	public void setCardFlag(String cardFlag) {
		this.cardFlag = cardFlag;
	}
	/**
	 * @return the sCardNo1
	 */
	public String getsCardNo1() {
		return sCardNo1;
	}
	/**
	 * @param sCardNo1 the sCardNo1 to set
	 */
	public void setsCardNo1(String sCardNo1) {
		this.sCardNo1 = sCardNo1;
	}
	/**
	 * @return the sCardValdYearMnth
	 */
	public String getsCardValdYearMnth() {
		return sCardValdYearMnth;
	}
	/**
	 * @param sCardValdYearMnth the sCardValdYearMnth to set
	 */
	public void setsCardValdYearMnth(String sCardValdYearMnth) {
		this.sCardValdYearMnth = sCardValdYearMnth;
	}
	/**
	 * @return the nCardDlAmt1
	 */
	public String getnCardDlAmt1() {
		return nCardDlAmt1;
	}
	/**
	 * @param nCardDlAmt1 the nCardDlAmt1 to set
	 */
	public void setnCardDlAmt1(String nCardDlAmt1) {
		this.nCardDlAmt1 = nCardDlAmt1;
	}
	/**
	 * @return the transFlag
	 */
	public String getTransFlag() {
		return transFlag;
	}
	/**
	 * @param transFlag the transFlag to set
	 */
	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}
	/**
	 * @return the sRealDpsrCd
	 */
	public String getsRealDpsrCd() {
		return sRealDpsrCd;
	}
	/**
	 * @param sRealDpsrCd the sRealDpsrCd to set
	 */
	public void setsRealDpsrCd(String sRealDpsrCd) {
		this.sRealDpsrCd = sRealDpsrCd;
	}
	/**
	 * @return the sRealDpsrName
	 */
	public String getsRealDpsrName() {
		return sRealDpsrName;
	}
	/**
	 * @param sRealDpsrName the sRealDpsrName to set
	 */
	public void setsRealDpsrName(String sRealDpsrName) {
		this.sRealDpsrName = sRealDpsrName;
	}
	/**
	 * @return the sRealHmsRecvBankAcctNo
	 */
	public String getsRealHmsRecvBankAcctNo() {
		return sRealHmsRecvBankAcctNo;
	}
	/**
	 * @param sRealHmsRecvBankAcctNo the sRealHmsRecvBankAcctNo to set
	 */
	public void setsRealHmsRecvBankAcctNo(String sRealHmsRecvBankAcctNo) {
		this.sRealHmsRecvBankAcctNo = sRealHmsRecvBankAcctNo;
	}
	/**
	 * @return the sRealHmsRecvBankCd
	 */
	public String getsRealHmsRecvBankCd() {
		return sRealHmsRecvBankCd;
	}
	/**
	 * @param sRealHmsRecvBankCd the sRealHmsRecvBankCd to set
	 */
	public void setsRealHmsRecvBankCd(String sRealHmsRecvBankCd) {
		this.sRealHmsRecvBankCd = sRealHmsRecvBankCd;
	}
	/**
	 * @return the nRealHmsRecvRvamt
	 */
	public String getnRealHmsRecvRvamt() {
		return nRealHmsRecvRvamt;
	}
	/**
	 * @param nRealHmsRecvRvamt the nRealHmsRecvRvamt to set
	 */
	public void setnRealHmsRecvRvamt(String nRealHmsRecvRvamt) {
		this.nRealHmsRecvRvamt = nRealHmsRecvRvamt;
	}
	/**
	 * @return the nCashDlAmt
	 */
	public String getnCashDlAmt() {
		return nCashDlAmt;
	}
	/**
	 * @param nCashDlAmt the nCashDlAmt to set
	 */
	public void setnCashDlAmt(String nCashDlAmt) {
		this.nCashDlAmt = nCashDlAmt;
	}
	/**
	 * @return the sRecpDate
	 */
	public String getsRecpDate() {
		return sRecpDate;
	}
	/**
	 * @param sRecpDate the sRecpDate to set
	 */
	public void setsRecpDate(String sRecpDate) {
		this.sRecpDate = sRecpDate;
	}
	/**
	 * @return the nRecpPrem
	 */
	public String getnRecpPrem() {
		return nRecpPrem;
	}
	/**
	 * @param nRecpPrem the nRecpPrem to set
	 */
	public void setnRecpPrem(String nRecpPrem) {
		this.nRecpPrem = nRecpPrem;
	}
	/**
	 * @return the sThcpAcctBankCd
	 */
	public String getsThcpAcctBankCd() {
		return sThcpAcctBankCd;
	}
	/**
	 * @param sThcpAcctBankCd the sThcpAcctBankCd to set
	 */
	public void setsThcpAcctBankCd(String sThcpAcctBankCd) {
		this.sThcpAcctBankCd = sThcpAcctBankCd;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
	
}
