/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �ڵ��� �㺸 �� ����� DTO
 * @author ������
 *
 */
public class CalculationOfCarInsuranceTotalDTO {
	/** �Ѻ���� **/
	private String nTotPrem;
	/** ��ȸ����� **/
	private String nExptPrem;

	/**
	 * @return the nTotPrem
	 */
	public String getnTotPrem() {
		return nTotPrem;
	}

	/**
	 * @param nTotPrem the nTotPrem to set
	 */
	public void setnTotPrem(final String nTotPrem) {
		this.nTotPrem = nTotPrem;
	}

	/**
	 * @return the nExptPrem
	 */
	public String getnExptPrem() {
		return nExptPrem;
	}

	/**
	 * @param nExptPrem the nExptPrem to set
	 */
	public void setnExptPrem(final String nExptPrem) {
		this.nExptPrem = nExptPrem;
	}

}
