/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.main;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.dto.web.BidNotificationDTO;
import com.educar.dto.web.NoticeDTO;

/**
 * <pre>
 * ����ȭ�� WrapperDTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "mainWrapperDTO")
public class MainWrapperDTO {

	/** ���� ���� �޴� ���� **/
	private List<MenuDTO> menuList;
	/** �������� ���� **/
	private List<NoticeDTO> noticeList;
	/** �������� ���� **/
	private List<BidNotificationDTO> bidNotificationList;
	/** ��� ���� **/
	private List<BannerDTO> bannerList;
	/** ä�� ���� **/
	private List<RecruitDTO> recruitList;
	/** ���� �޴� ��õ ��ǰ **/
	private List<InsuranceProductMainMenuDTO> productList;

	/**
	 * @return the bannerList
	 */
	public List<BannerDTO> getBannerList() {
		return bannerList;
	}

	/**
	 * @param bannerList the bannerList to set
	 */
	public void setBannerList(final List<BannerDTO> bannerList) {
		this.bannerList = bannerList;
	}

	/**
	 * @return the menuList
	 */
	public List<MenuDTO> getMenuList() {
		return menuList;
	}

	/**
	 * @param menuList the menuList to set
	 */
	public void setMenuList(final List<MenuDTO> menuList) {
		this.menuList = menuList;
	}

	/**
	 * @return the noticeList
	 */
	public List<NoticeDTO> getNoticeList() {
		return noticeList;
	}

	/**
	 * @param noticeList the noticeList to set
	 */
	public void setNoticeList(final List<NoticeDTO> noticeList) {
		this.noticeList = noticeList;
	}

	/**
	 * @return the bidNotificationList
	 */
	public List<BidNotificationDTO> getBidNotificationList() {
		return bidNotificationList;
	}

	/**
	 * @param bidNotificationList the bidNotificationList to set
	 */
	public void setBidNotificationList(final List<BidNotificationDTO> bidNotificationList) {
		this.bidNotificationList = bidNotificationList;
	}

	/**
	 * @return the recruitList
	 */
	public List<RecruitDTO> getRecruitList() {
		return recruitList;
	}

	/**
	 * @param recruitList the recruitList to set
	 */
	public void setRecruitList(final List<RecruitDTO> recruitList) {
		this.recruitList = recruitList;
	}

	/**
	 * @return the productList
	 */
	public List<InsuranceProductMainMenuDTO> getProductList() {
		return productList;
	}

	/**
	 * @param productList the productList to set
	 */
	public void setProductList(final List<InsuranceProductMainMenuDTO> productList) {
		this.productList = productList;
	}
}
