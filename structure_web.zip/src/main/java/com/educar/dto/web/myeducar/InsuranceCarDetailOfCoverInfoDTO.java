/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (�㺸����)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfCoverInfoDTO")
public class InsuranceCarDetailOfCoverInfoDTO {
	/** ����ȣ **/
	private String sPolicyType;
	/** ����ȣ **/
	private String sPolicyYM;
	/** ����ȣ **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** �㺸�ڵ� **/
	private String sCover;
	/** �㺸���� **/
	private String sCoverName;
	/** �����ڵ� **/
	private String sInsType;
	/**
	 * <pre>
	 * �㺸����
	 * 00:����, 01:�߰�, 02:�����Ĵ㺸�߰�, 11:��Ȱ, 12:����Ⱓ�ĺ�Ȱ, 21:�ܱ�����, 22:��������,23:�Ϻδ㺸�̰���24:�ְ�����,25:��������, 26����Ⱓ����31:���
	 * </pre>
	 **/
	private String sCoverStat;
	/** ����ñ� **/
	private String sFmdt;
	/** ������۽ð� **/
	private String sFmtm;
	/** �������� **/
	private String sTodt;
	/** ��������ð� **/
	private String sTotm;
	/** �㺸���Աݾ��ڵ� **/
	private String sOptCode;
	/** �㺸���Աݾ׸� **/
	private String sOptName;
	/** ���Աݾ� **/
	private String nOptAmt;
	/** ��������(�ڱ�δ��) (����) **/
	private String nDeductAmt;
	/** ��ü����� (����) **/
	private String nReplaceAmt;
	/** ���뺸��� **/
	private String nRealPrem;
	/** �㺸�� �� **/
	private String sCoverLongName;
	/** �ڼ�ġ��� ���Աݾ׸� (�ڱ��ü���) **/
	private String mediFeeName;
	/** �ڱ�δ�� ���� (����) **/
	private String nDeductMaxAmt;
	/** �ڱ�δ�� ���� (����) **/
	private String nDeductRate;
	/** �ڱ�δ�� ����,���� (����)���� 5����~�ְ� 50���� **/
	private String sNewDeductAmt;
	/** �ڱ�δ�� ���ؾ׺δ���**/
	private String sNewDeductTit;
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the sCoverName
	 */
	public String getsCoverName() {
		return sCoverName;
	}

	/**
	 * @param sCoverName the sCoverName to set
	 */
	public void setsCoverName(final String sCoverName) {
		this.sCoverName = sCoverName;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sCoverStat
	 */
	public String getsCoverStat() {
		return sCoverStat;
	}

	/**
	 * @param sCoverStat the sCoverStat to set
	 */
	public void setsCoverStat(final String sCoverStat) {
		this.sCoverStat = sCoverStat;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sFmtm
	 */
	public String getsFmtm() {
		return sFmtm;
	}

	/**
	 * @param sFmtm the sFmtm to set
	 */
	public void setsFmtm(final String sFmtm) {
		this.sFmtm = sFmtm;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sTotm
	 */
	public String getsTotm() {
		return sTotm;
	}

	/**
	 * @param sTotm the sTotm to set
	 */
	public void setsTotm(final String sTotm) {
		this.sTotm = sTotm;
	}

	/**
	 * @return the sOptCode
	 */
	public String getsOptCode() {
		return sOptCode;
	}

	/**
	 * @param sOptCode the sOptCode to set
	 */
	public void setsOptCode(final String sOptCode) {
		this.sOptCode = sOptCode;
	}

	/**
	 * @return the sOptName
	 */
	public String getsOptName() {
		return sOptName;
	}

	/**
	 * @param sOptName the sOptName to set
	 */
	public void setsOptName(final String sOptName) {
		this.sOptName = sOptName;
	}

	/**
	 * @return the nOptAmt
	 */
	public String getnOptAmt() {
		return nOptAmt;
	}

	/**
	 * @param nOptAmt the nOptAmt to set
	 */
	public void setnOptAmt(final String nOptAmt) {
		this.nOptAmt = nOptAmt;
	}

	/**
	 * @return the nDeductAmt
	 */
	public String getnDeductAmt() {
		return nDeductAmt;
	}

	/**
	 * @param nDeductAmt the nDeductAmt to set
	 */
	public void setnDeductAmt(final String nDeductAmt) {
		this.nDeductAmt = nDeductAmt;
	}

	/**
	 * @return the nReplaceAmt
	 */
	public String getnReplaceAmt() {
		return nReplaceAmt;
	}

	/**
	 * @param nReplaceAmt the nReplaceAmt to set
	 */
	public void setnReplaceAmt(final String nReplaceAmt) {
		this.nReplaceAmt = nReplaceAmt;
	}

	/**
	 * @return the nRealPrem
	 */
	public String getnRealPrem() {
		return nRealPrem;
	}

	/**
	 * @param nRealPrem the nRealPrem to set
	 */
	public void setnRealPrem(final String nRealPrem) {
		this.nRealPrem = nRealPrem;
	}

	/**
	 * @return the sCoverLongName
	 */
	public String getsCoverLongName() {
		return sCoverLongName;
	}

	/**
	 * @param sCoverLongName the sCoverLongName to set
	 */
	public void setsCoverLongName(final String sCoverLongName) {
		this.sCoverLongName = sCoverLongName;
	}

	/**
	 * @return the mediFeeName
	 */
	public String getMediFeeName() {
		return mediFeeName;
	}

	/**
	 * @param mediFeeName the mediFeeName to set
	 */
	public void setMediFeeName(final String mediFeeName) {
		this.mediFeeName = mediFeeName;
	}

	/**
	 * @return the nDeductMaxAmt
	 */
	public String getnDeductMaxAmt() {
		return nDeductMaxAmt;
	}

	/**
	 * @param nDeductMaxAmt the nDeductMaxAmt to set
	 */
	public void setnDeductMaxAmt(final String nDeductMaxAmt) {
		this.nDeductMaxAmt = nDeductMaxAmt;
	}

	/**
	 * @return the nDeductRate
	 */
	public String getnDeductRate() {
		return nDeductRate;
	}

	/**
	 * @param nDeductRate the nDeductRate to set
	 */
	public void setnDeductRate(final String nDeductRate) {
		this.nDeductRate = nDeductRate;
	}

	/**
	 * @return the sNewDeductAmt
	 */
	public String getsNewDeductAmt() {
		return sNewDeductAmt;
	}

	/**
	 * @param sNewDeductAmt the sNewDeductAmt to set
	 */
	public void setsNewDeductAmt(final String sNewDeductAmt) {
		this.sNewDeductAmt = sNewDeductAmt;
	}

	/**
	 * @return the sNewDeductTit
	 */
	public String getsNewDeductTit() {
		return sNewDeductTit;
	}

	/**
	 * @param sNewDeductTit the sNewDeductTit to set
	 */
	public void setsNewDeductTit(String sNewDeductTit) {
		this.sNewDeductTit = sNewDeductTit;
	}
}
