/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ���� ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfGENAA31DTO")
public class CalculationOfGENAA31DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ������̿��� ("Y","N") **/
	private String sTwoWheelDrvYN;
	/** ����ǰ����� ("Y","N") **/
	private String sCurSickStatus;
	/** ������������ ("Y","N") **/
	private String sPastSickYN;
	/** ��ü�����ֿ��� ("Y","N") **/
	private String sBodyObstclYN;
	/** ������̿��� ("Y","N") **/
	private String sRiskHobbyYN;
	/** ���� ü���� ("1","2") **/
	private String sCurStay;
	/** �Ƿ�� ��ȸ ���� ���� (����� �˷����ϴ»��� ���� "Y","N") **/
	private String sOthMedicalYN;

	/**
	 * @return the sTwoWheelDrvYN
	 */
	public String getsTwoWheelDrvYN() {
		return sTwoWheelDrvYN;
	}

	/**
	 * @param sTwoWheelDrvYN the sTwoWheelDrvYN to set
	 */
	public void setsTwoWheelDrvYN(final String sTwoWheelDrvYN) {
		this.sTwoWheelDrvYN = sTwoWheelDrvYN;
	}

	/**
	 * @return the sCurSickStatus
	 */
	public String getsCurSickStatus() {
		return sCurSickStatus;
	}

	/**
	 * @param sCurSickStatus the sCurSickStatus to set
	 */
	public void setsCurSickStatus(final String sCurSickStatus) {
		this.sCurSickStatus = sCurSickStatus;
	}

	/**
	 * @return the sPastSickYN
	 */
	public String getsPastSickYN() {
		return sPastSickYN;
	}

	/**
	 * @param sPastSickYN the sPastSickYN to set
	 */
	public void setsPastSickYN(final String sPastSickYN) {
		this.sPastSickYN = sPastSickYN;
	}

	/**
	 * @return the sBodyObstclYN
	 */
	public String getsBodyObstclYN() {
		return sBodyObstclYN;
	}

	/**
	 * @param sBodyObstclYN the sBodyObstclYN to set
	 */
	public void setsBodyObstclYN(final String sBodyObstclYN) {
		this.sBodyObstclYN = sBodyObstclYN;
	}

	/**
	 * @return the sRiskHobbyYN
	 */
	public String getsRiskHobbyYN() {
		return sRiskHobbyYN;
	}

	/**
	 * @param sRiskHobbyYN the sRiskHobbyYN to set
	 */
	public void setsRiskHobbyYN(final String sRiskHobbyYN) {
		this.sRiskHobbyYN = sRiskHobbyYN;
	}

	/**
	 * @return the sCurStay
	 */
	public String getsCurStay() {
		return sCurStay;
	}

	/**
	 * @param sCurStay the sCurStay to set
	 */
	public void setsCurStay(final String sCurStay) {
		this.sCurStay = sCurStay;
	}

	/**
	 * @return the sOthMedicalYN
	 */
	public String getsOthMedicalYN() {
		return sOthMedicalYN;
	}

	/**
	 * @param sOthMedicalYN the sOthMedicalYN to set
	 */
	public void setsOthMedicalYN(final String sOthMedicalYN) {
		this.sOthMedicalYN = sOthMedicalYN;
	}

}
