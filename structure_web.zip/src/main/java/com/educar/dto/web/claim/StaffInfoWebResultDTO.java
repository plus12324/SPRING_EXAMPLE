/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������������ ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "staffInfoWebResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class StaffInfoWebResultDTO {
	/** �̸� **/
	private String sName;
	/** ������ **/
	private String sTeamName;
	/** �繫����ȭ��ȣ **/
	private String sOffTel;
	/** �޴�����ȭ��ȣ **/
	private String sCellTel;
	/** �ѽ���ȣ **/
	private String sFax;

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sTeamName
	 */
	public String getsTeamName() {
		return sTeamName;
	}

	/**
	 * @param sTeamName the sTeamName to set
	 */
	public void setsTeamName(final String sTeamName) {
		this.sTeamName = sTeamName;
	}

	/**
	 * @return the sOffTel
	 */
	public String getsOffTel() {
		return sOffTel;
	}

	/**
	 * @param sOffTel the sOffTel to set
	 */
	public void setsOffTel(final String sOffTel) {
		this.sOffTel = sOffTel;
	}

	/**
	 * @return the sCellTel
	 */
	public String getsCellTel() {
		return sCellTel;
	}

	/**
	 * @param sCellTel the sCellTel to set
	 */
	public void setsCellTel(final String sCellTel) {
		this.sCellTel = sCellTel;
	}

	/**
	 * @return the sFax
	 */
	public String getsFax() {
		return sFax;
	}

	/**
	 * @param sFax the sFax to set
	 */
	public void setsFax(final String sFax) {
		this.sFax = sFax;
	}

}
