/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ó�� ��Ȳ ��ȸ ����/�ǰ����� ������ȲDTO
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "accidentClaimDTO")
public class AccidentClaimDTO {
	/** ������ȣ **/
	private String sAcdNum;
	/** �Ǻ����� **/
	private String sDmgName;
	/** ������� **/
	private String sAcdDate;
	/** ������� **/
	private String sAcdType;
	/** ������ **/
	private String VilAddr;
	/** �����Ͻ� **/
	private String AcdRcpDate;
	/** ������� **/
	private String sAcctStatusNm;
	/** ������ ���� **/
	private String nDmgSeq;
	/** ���ް������� **/
	private String nInsDcSeq;

	/**
	 * @return the sAcdNum
	 */
	public String getsAcdNum() {
		return sAcdNum;
	}

	/**
	 * @param sAcdNum the sAcdNum to set
	 */
	public void setsAcdNum(final String sAcdNum) {
		this.sAcdNum = sAcdNum;
	}

	/**
	 * @return the sDmgName
	 */
	public String getsDmgName() {
		return sDmgName;
	}

	/**
	 * @param sDmgName the sDmgName to set
	 */
	public void setsDmgName(final String sDmgName) {
		this.sDmgName = sDmgName;
	}

	/**
	 * @return the sAcdDate
	 */
	public String getsAcdDate() {
		return sAcdDate;
	}

	/**
	 * @param sAcdDate the sAcdDate to set
	 */
	public void setsAcdDate(final String sAcdDate) {
		this.sAcdDate = sAcdDate;
	}

	/**
	 * @return the sAcdType
	 */
	public String getsAcdType() {
		return sAcdType;
	}

	/**
	 * @param sAcdType the sAcdType to set
	 */
	public void setsAcdType(final String sAcdType) {
		this.sAcdType = sAcdType;
	}

	/**
	 * @return the vilAddr
	 */
	public String getVilAddr() {
		return VilAddr;
	}

	/**
	 * @param vilAddr the vilAddr to set
	 */
	public void setVilAddr(final String vilAddr) {
		VilAddr = vilAddr;
	}

	/**
	 * @return the acdRcpDate
	 */
	public String getAcdRcpDate() {
		return AcdRcpDate;
	}

	/**
	 * @param acdRcpDate the acdRcpDate to set
	 */
	public void setAcdRcpDate(final String acdRcpDate) {
		AcdRcpDate = acdRcpDate;
	}

	/**
	 * @return the sAcctStatusNm
	 */
	public String getsAcctStatusNm() {
		return sAcctStatusNm;
	}

	/**
	 * @param sAcctStatusNm the sAcctStatusNm to set
	 */
	public void setsAcctStatusNm(final String sAcctStatusNm) {
		this.sAcctStatusNm = sAcctStatusNm;
	}

	/**
	 * @return the nDmgSeq
	 */
	public String getnDmgSeq() {
		return nDmgSeq;
	}

	/**
	 * @param nDmgSeq the nDmgSeq to set
	 */
	public void setnDmgSeq(final String nDmgSeq) {
		this.nDmgSeq = nDmgSeq;
	}

	/**
	 * @return the nInsDcSeq
	 */
	public String getnInsDcSeq() {
		return nInsDcSeq;
	}

	/**
	 * @param nInsDcSeq the nInsDcSeq to set
	 */
	public void setnInsDcSeq(final String nInsDcSeq) {
		this.nInsDcSeq = nInsDcSeq;
	}

}
