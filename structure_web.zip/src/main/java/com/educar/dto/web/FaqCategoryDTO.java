/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * <pre>
 * ���ֹ������� ī�׷θ� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "faqCategoryDTO")
public class FaqCategoryDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** ī�װ��� �Ϸù�ȣ 4�ڸ� */
	private String sCatCd;
	/** ī�װ��� �� */
	private String sCatNm;
	/** ī�װ��� ���ļ��� */
	private String nSortOrd;
	/** ī�װ��� ��뿩��(Y/N) */
	private String sViewYn;
	
	/** ī�װ��� ����Ʈ (�����ڿ��� ���)**/
	@XmlTransient
	private List<FaqCategoryDTO> catList;
	/** üũ�� (�����ڿ��� ������ ���) **/
	@XmlTransient
	private String checkValue;

	/**
	 * @return the sCatCd
	 */
	public String getsCatCd() {
		return sCatCd;
	}
	/**
	 * @param sCatCd the sCatCd to set
	 */
	public void setsCatCd(String sCatCd) {
		this.sCatCd = sCatCd;
	}
	/**
	 * @return the sCatNm
	 */
	public String getsCatNm() {
		return sCatNm;
	}
	/**
	 * @param sCatNm the sCatNm to set
	 */
	public void setsCatNm(String sCatNm) {
		this.sCatNm = sCatNm;
	}
	/**
	 * @return the nSortOrd
	 */
	public String getnSortOrd() {
		return nSortOrd;
	}
	/**
	 * @param nSortOrd the nSortOrd to set
	 */
	public void setnSortOrd(String nSortOrd) {
		this.nSortOrd = nSortOrd;
	}
	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}
	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}
	/**
	 * @return the catList
	 */
	public List<FaqCategoryDTO> getCatList() {
		return catList;
	}
	/**
	 * @param catList the catList to set
	 */
	public void setCatList(List<FaqCategoryDTO> catList) {
		this.catList = catList;
	}
	/**
	 * @return the checkValue
	 */
	public String getCheckValue() {
		return checkValue;
	}
	/**
	 * @param checkValue the checkValue to set
	 */
	public void setCheckValue(String checkValue) {
		this.checkValue = checkValue;
	}
	
	
}
