/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * �輭 ȯ�޺����� �ٷ� Ȯ���� ���Ǵ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name="endorseConfirmDTO")
public class EndorseConfirmDTO {

	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** �Ǹ�Ȯ�ι�ȣ **/
	private String sRealID;
	/** �����ڵ� **/
	private String sReqBankCode;
	/** ���¹�ȣ **/
	//@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sReqAcctNo;
	/** ������ **/
	private String sReqDepositer;
	/** ������Ȯ��**/
	@ValidateRegex(predefinedRegex = RegexEnum.YNString)
	private String sConfirm;
	/** �����ֿ��ǰ��� 1 ����, 2 ��Ÿ**/
	@ValidateLength(max = 1, min = 1)
	private String sRel;
	/** ȯ�ޱ� **/
	private String nRefundAmt;
	/** ��ȣȭŰ */ 
	private String sHid_key_data;


	public String getsHid_key_data() {
		return sHid_key_data;
	}

	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}

	/**
	 * @return the sApplyType û���ȣ����
	 */
	public String getsApplyType() {
		return sApplyType;  
	}

	/**
	 * @param sApplyType the sApplyType to set û���ȣ����
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM û���ȣ�⵵
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set û���ȣ�⵵
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer û���ȣSER
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set û���ȣSER
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sRealID �Ǹ�Ȯ�ι�ȣ
	 */
	public String getsRealID() {
		return sRealID;
	}

	/**
	 * @param sRealID the sRealID to set �Ǹ�Ȯ�ι�ȣ
	 */
	public void setsRealID(final String sRealID) {
		this.sRealID = sRealID;
	}

	/**
	 * @return the sReqBankCode �����ڵ�
	 */
	public String getsReqBankCode() {
		return sReqBankCode;
	}

	/**
	 * @param sReqBankCode the sReqBankCode to set �����ڵ�
	 */
	public void setsReqBankCode(final String sReqBankCode) {
		this.sReqBankCode = sReqBankCode;
	}

	/**
	 * @return the sReqAcctNo ���¹�ȣ
	 */
	public String getsReqAcctNo() {
		return sReqAcctNo;
	}

	/**
	 * @param sReqAcctNo the sReqAcctNo to set ���¹�ȣ
	 */
	public void setsReqAcctNo(final String sReqAcctNo) {
		this.sReqAcctNo = sReqAcctNo;
	}

	/**
	 * @return the sReqDepositer ������
	 */
	public String getsReqDepositer() {
		return sReqDepositer;
	}

	/**
	 * @param sReqDepositer the sReqDepositer to set ������
	 */
	public void setsReqDepositer(final String sReqDepositer) {
		this.sReqDepositer = sReqDepositer;
	}

	/**
	 * @return the sConfirm ������Ȯ��
	 */
	public String getsConfirm() {
		return sConfirm;
	}

	/**
	 * @param sConfirm the sConfirm to set ������Ȯ��
	 */
	public void setsConfirm(final String sConfirm) {
		this.sConfirm = sConfirm;
	}

	/**
	 * @return the sRel �����ֿ��ǰ��� 1 ����, 2 ��Ÿ
	 */
	public String getsRel() {
		return sRel;
	}

	/**
	 * @param sRel the sRel to set �����ֿ��ǰ��� 1 ����, 2 ��Ÿ
	 */
	public void setsRel(final String sRel) {
		this.sRel = sRel;
	}

	/**
	 * @return the nRefundAmt ȯ�ޱ�
	 */
	public String getnRefundAmt() {
		return nRefundAmt;
	}

	/**
	 * @param nRefundAmt the nRefundAmt to set ȯ�ޱ�
	 */
	public void setnRefundAmt(final String nRefundAmt) {
		this.nRefundAmt = nRefundAmt;
	}

}
