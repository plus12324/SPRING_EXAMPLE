/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���ݺ��� (���������� ����) �����ڵ� ��ȸ
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "longAnntCommCodeDTO")
public class LongAnntCommCodeDTO{
	/**��ǰ�ڵ� **/ 
	private String sGdCd;
	/**�����ֱ� **/ 
	private String sAnntPymCyclCd;
	private String sAnntPymCyclCdName;
	
	/**���ݰ��ó���	 **/ 
    private String sAnntOpnAgeCd;
    private String sAnntOpnAgeCdName;
	
    /**��������	 **/ 
    private String sAnntPymTypeCd;
    private String sAnntPymTypeCdName;
    /**���ޱⰣ	 **/ 
    private String sAnntPymTermCd;
    private String sAnntPymTermCdName;
    /**���ԱⰣ	 **/ 
    private String sPaymTermCd;
    private String sPaymTermName;
    
	/**����Ⱓ	 **/ 
	private String sInsurTermCd;
	private String sInsurTermName;
	/**�����ֱ�	 **/ 
	private String sPaymCyclCd;
	private String sPaymCyclName;
	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}
	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(String sGdCd) {
		this.sGdCd = sGdCd;
	}
	/**
	 * @return the sAnntPymCyclCd
	 */
	public String getsAnntPymCyclCd() {
		return sAnntPymCyclCd;
	}
	/**
	 * @param sAnntPymCyclCd the sAnntPymCyclCd to set
	 */
	public void setsAnntPymCyclCd(String sAnntPymCyclCd) {
		this.sAnntPymCyclCd = sAnntPymCyclCd;
	}
	/**
	 * @return the sAnntPymCyclCdName
	 */
	public String getsAnntPymCyclCdName() {
		return sAnntPymCyclCdName;
	}
	/**
	 * @param sAnntPymCyclCdName the sAnntPymCyclCdName to set
	 */
	public void setsAnntPymCyclCdName(String sAnntPymCyclCdName) {
		this.sAnntPymCyclCdName = sAnntPymCyclCdName;
	}
	/**
	 * @return the sAnntOpnAgeCd
	 */
	public String getsAnntOpnAgeCd() {
		return sAnntOpnAgeCd;
	}
	/**
	 * @param sAnntOpnAgeCd the sAnntOpnAgeCd to set
	 */
	public void setsAnntOpnAgeCd(String sAnntOpnAgeCd) {
		this.sAnntOpnAgeCd = sAnntOpnAgeCd;
	}
	/**
	 * @return the sAnntOpnAgeCdName
	 */
	public String getsAnntOpnAgeCdName() {
		return sAnntOpnAgeCdName;
	}
	/**
	 * @param sAnntOpnAgeCdName the sAnntOpnAgeCdName to set
	 */
	public void setsAnntOpnAgeCdName(String sAnntOpnAgeCdName) {
		this.sAnntOpnAgeCdName = sAnntOpnAgeCdName;
	}
	/**
	 * @return the sAnntPymTypeCd
	 */
	public String getsAnntPymTypeCd() {
		return sAnntPymTypeCd;
	}
	/**
	 * @param sAnntPymTypeCd the sAnntPymTypeCd to set
	 */
	public void setsAnntPymTypeCd(String sAnntPymTypeCd) {
		this.sAnntPymTypeCd = sAnntPymTypeCd;
	}
	/**
	 * @return the sAnntPymTypeCdName
	 */
	public String getsAnntPymTypeCdName() {
		return sAnntPymTypeCdName;
	}
	/**
	 * @param sAnntPymTypeCdName the sAnntPymTypeCdName to set
	 */
	public void setsAnntPymTypeCdName(String sAnntPymTypeCdName) {
		this.sAnntPymTypeCdName = sAnntPymTypeCdName;
	}
	/**
	 * @return the sAnntPymTermCd
	 */
	public String getsAnntPymTermCd() {
		return sAnntPymTermCd;
	}
	/**
	 * @param sAnntPymTermCd the sAnntPymTermCd to set
	 */
	public void setsAnntPymTermCd(String sAnntPymTermCd) {
		this.sAnntPymTermCd = sAnntPymTermCd;
	}
	/**
	 * @return the sAnntPymTermCdName
	 */
	public String getsAnntPymTermCdName() {
		return sAnntPymTermCdName;
	}
	/**
	 * @param sAnntPymTermCdName the sAnntPymTermCdName to set
	 */
	public void setsAnntPymTermCdName(String sAnntPymTermCdName) {
		this.sAnntPymTermCdName = sAnntPymTermCdName;
	}
	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}
	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}
	/**
	 * @return the sPaymTermName
	 */
	public String getsPaymTermName() {
		return sPaymTermName;
	}
	/**
	 * @param sPaymTermName the sPaymTermName to set
	 */
	public void setsPaymTermName(String sPaymTermName) {
		this.sPaymTermName = sPaymTermName;
	}
	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}
	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}
	/**
	 * @return the sInsurTermName
	 */
	public String getsInsurTermName() {
		return sInsurTermName;
	}
	/**
	 * @param sInsurTermName the sInsurTermName to set
	 */
	public void setsInsurTermName(String sInsurTermName) {
		this.sInsurTermName = sInsurTermName;
	}
	/**
	 * @return the sPaymCyclCd
	 */
	public String getsPaymCyclCd() {
		return sPaymCyclCd;
	}
	/**
	 * @param sPaymCyclCd the sPaymCyclCd to set
	 */
	public void setsPaymCyclCd(String sPaymCyclCd) {
		this.sPaymCyclCd = sPaymCyclCd;
	}
	/**
	 * @return the sPaymCyclName
	 */
	public String getsPaymCyclName() {
		return sPaymCyclName;
	}
	/**
	 * @param sPaymCyclName the sPaymCyclName to set
	 */
	public void setsPaymCyclName(String sPaymCyclName) {
		this.sPaymCyclName = sPaymCyclName;
	}

	
}
