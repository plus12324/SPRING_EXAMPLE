/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����ڹ��� ���/Ȯ��/���濡 ���Ǵ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "editDriverScopeRequestDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class EditDriverScopeRequestDTO {

	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** �� �輭 �ڵ� **/
	private String sEndorseCodeForWeb;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** �������� **/
	private String sSpecFAM;
	/** �������� **/
	private String sSpecAGE;
	/** ���������� �ֹι�ȣ **/
	private String sMinPersonID;
	/** ���� ���� **/
	private String sMinPersonName;
	/** �����ڵ� **/
	private String sMinRelCode;
	/** �÷���1�� �ֹι�ȣ **/
	private String sPersonID;
	/** �÷���1�� ���� **/
	private String sPersonName;
	/** �÷���1�� ���� **/
	private String sRelCode;

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @return the sEndorseCodeForWeb
	 */
	public String getsEndorseCodeForWeb() {
		return sEndorseCodeForWeb;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @return the sSpecFAM
	 */
	public String getsSpecFAM() {
		return sSpecFAM;
	}

	/**
	 * @return the sSpecAGE
	 */
	public String getsSpecAGE() {
		return sSpecAGE;
	}

	/**
	 * @return the sMinPersonID
	 */
	public String getsMinPersonID() {
		return sMinPersonID;
	}

	/**
	 * @return the sMinPersonName
	 */
	public String getsMinPersonName() {
		return sMinPersonName;
	}

	/**
	 * @return the sMinRelCode
	 */
	public String getsMinRelCode() {
		return sMinRelCode;
	}

	/**
	 * @return the sPersonID
	 */
	public String getsPersonID() {
		return sPersonID;
	}

	/**
	 * @return the sPersonName
	 */
	public String getsPersonName() {
		return sPersonName;
	}

	/**
	 * @return the sRelCode
	 */
	public String getsRelCode() {
		return sRelCode;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @param sEndorseCodeForWeb the sEndorseCodeForWeb to set
	 */
	public void setsEndorseCodeForWeb(final String sEndorseCodeForWeb) {
		this.sEndorseCodeForWeb = sEndorseCodeForWeb;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @param sSpecFAM the sSpecFAM to set
	 */
	public void setsSpecFAM(final String sSpecFAM) {
		this.sSpecFAM = sSpecFAM;
	}

	/**
	 * @param sSpecAGE the sSpecAGE to set
	 */
	public void setsSpecAGE(final String sSpecAGE) {
		this.sSpecAGE = sSpecAGE;
	}

	/**
	 * @param sMinPersonID the sMinPersonID to set
	 */
	public void setsMinPersonID(final String sMinPersonID) {
		this.sMinPersonID = sMinPersonID;
	}

	/**
	 * @param sMinPersonName the sMinPersonName to set
	 */
	public void setsMinPersonName(final String sMinPersonName) {
		this.sMinPersonName = sMinPersonName;
	}

	/**
	 * @param sMinRelCode the sMinRelCode to set
	 */
	public void setsMinRelCode(final String sMinRelCode) {
		this.sMinRelCode = sMinRelCode;
	}

	/**
	 * @param sPersonID the sPersonID to set
	 */
	public void setsPersonID(final String sPersonID) {
		this.sPersonID = sPersonID;
	}

	/**
	 * @param sPersonName the sPersonName to set
	 */
	public void setsPersonName(final String sPersonName) {
		this.sPersonName = sPersonName;
	}

	/**
	 * @param sRelCode the sRelCode to set
	 */
	public void setsRelCode(final String sRelCode) {
		this.sRelCode = sRelCode;
	}
}
