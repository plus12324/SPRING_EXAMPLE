/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ (�Ϲݺ���) Wrapper DTO
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayWrapperDTO")
public class InsDrvPayWrapperDTO {
	/** ��� ���� **/
	private InsDrvPayRectList01DTO RectList01;
	/** ���� ���� **/
	private List<InsDrvPayRectList02DTO> RectList02;
	/**
	 * @return the rectList01
	 */
	public InsDrvPayRectList01DTO getRectList01() {
		return RectList01;
	}
	/**
	 * @param rectList01 the rectList01 to set
	 */
	public void setRectList01(InsDrvPayRectList01DTO rectList01) {
		RectList01 = rectList01;
	}
	/**
	 * @return the rectList02
	 */
	public List<InsDrvPayRectList02DTO> getRectList02() {
		return RectList02;
	}
	/**
	 * @param rectList02 the rectList02 to set
	 */
	public void setRectList02(List<InsDrvPayRectList02DTO> rectList02) {
		RectList02 = rectList02;
	}
	
}
