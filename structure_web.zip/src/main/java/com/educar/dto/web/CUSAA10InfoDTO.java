/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * ����_PROMOTION �Ϸ� ����
 * @author ���ѳ�
 * @since 0.0.10
 */
public class CUSAA10InfoDTO {
	/**����_PROMOTION �Ϸ� ���� �Է� ���� **/
	private String jehuInfo;
	/**�ֹ�/����ڹ�ȣ	**/
	private String sCustNo;
	/**�̺�Ʈ����	**/
	private String sEventDiv;
	/**�������ϸ� (59Byte ���ǰ�������)	**/
	private String sAgmCheckInfo;
	/**
	 * @return the jehuInfo
	 */
	public String getJehuInfo() {
		return jehuInfo;
	}
	/**
	 * @param jehuInfo the jehuInfo to set
	 */
	public void setJehuInfo(String jehuInfo) {
		this.jehuInfo = jehuInfo;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}
	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	/**
	 * @return the sAgmCheckInfo
	 */
	public String getsAgmCheckInfo() {
		return sAgmCheckInfo;
	}
	/**
	 * @param sAgmCheckInfo the sAgmCheckInfo to set
	 */
	public void setsAgmCheckInfo(String sAgmCheckInfo) {
		this.sAgmCheckInfo = sAgmCheckInfo;
	}

	
}
