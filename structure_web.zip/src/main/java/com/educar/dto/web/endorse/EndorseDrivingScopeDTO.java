/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����ڹ��� ���/Ȯ��/���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "endorseDrivingScopeDTO")
public class EndorseDrivingScopeDTO {
	/** pola001Info **/
	private EndorseDrivingScopeOfPola001InfoDTO pola001Info;

	/** �����ڹ���Ư�� **/
	private List<EndorsePawnListOfCoverDTO> displayFamSpecVt;
	/** ����Ư�� **/
	private List<EndorsePawnListOfCoverDTO> displayAgeSpecVt;

	/**
	 * @return the pola001Info
	 */
	public EndorseDrivingScopeOfPola001InfoDTO getPola001Info() {
		return pola001Info;
	}

	/**
	 * @param pola001Info the pola001Info to set
	 */
	public void setPola001Info(final EndorseDrivingScopeOfPola001InfoDTO pola001Info) {
		this.pola001Info = pola001Info;
	}

	/**
	 * @return the displayFamSpecVt
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayFamSpecVt() {
		return displayFamSpecVt;
	}

	/**
	 * @param displayFamSpecVt the displayFamSpecVt to set
	 */
	public void setDisplayFamSpecVt(final List<EndorsePawnListOfCoverDTO> displayFamSpecVt) {
		this.displayFamSpecVt = displayFamSpecVt;
	}

	/**
	 * @return the displayAgeSpecVt
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayAgeSpecVt() {
		return displayAgeSpecVt;
	}

	/**
	 * @param displayAgeSpecVt the displayAgeSpecVt to set
	 */
	public void setDisplayAgeSpecVt(final List<EndorsePawnListOfCoverDTO> displayAgeSpecVt) {
		this.displayAgeSpecVt = displayAgeSpecVt;
	}

}
