/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ����/������� �ȳ� ��ȸ DTO
 * @author ������
 * @since 0.0.10
 */
@XmlRootElement(name = "newSearchControlCorrSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class NewSearchControlCorrSearchResultDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;

	/** ����/�������� **/
	private String sCompanyKorName;
	/** ������ȣ1 **/
	private String sZip1;
	/** ������ȣ2 **/
	private String sZip2;
	/** �ּ�1 **/
	private String sAddress1;
	/** �ּ�2 **/
	private String sAddress2;
	/** �ּ�(ȭ�鿡�� ���) **/
	private String address;
	/** ��ȭ��ȣ1 **/
	private String sTel1;
	/** ��ȭ��ȣ2 **/
	private String sTel2;
	/** ��ȭ��ȣ3 **/
	private String sTel3;
	/** ��ȭ��ȣ(ȭ�鿡�� ���) **/
	private String tel;
	/** daum map api ��ǥ x (ȭ�鿡�����)**/
	private String x;
	/** daum map api ��ǥ y (ȭ�鿡�����)**/
	private String y;
	/** �ŷ�ó �ڵ� **/
	private String sCorrespondent;
	/** �� ����ġ������ �Ÿ� **/
	private double sdistance;

	public double getSdistance() {
		return sdistance;
	}

	public void setSdistance(final double sdistance) {
		this.sdistance = sdistance;
	}

	/**
	 * @return the sCompanyKorName
	 */
	public String getsCompanyKorName() {
		return sCompanyKorName;
	}

	/**
	 * @param sCompanyKorName the sCompanyKorName to set
	 */
	public void setsCompanyKorName(final String sCompanyKorName) {
		this.sCompanyKorName = sCompanyKorName;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sAddress1
	 */
	public String getsAddress1() {
		return sAddress1;
	}

	/**
	 * @param sAddress1 the sAddress1 to set
	 */
	public void setsAddress1(final String sAddress1) {
		this.sAddress1 = sAddress1;
	}

	/**
	 * @return the sAddress2
	 */
	public String getsAddress2() {
		return sAddress2;
	}

	/**
	 * @param sAddress2 the sAddress2 to set
	 */
	public void setsAddress2(final String sAddress2) {
		this.sAddress2 = sAddress2;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}

	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(final String sTel1) {
		this.sTel1 = sTel1;
	}

	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}

	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(final String sTel2) {
		this.sTel2 = sTel2;
	}

	/**
	 * @return the sTel3
	 */
	public String getsTel3() {
		return sTel3;
	}

	/**
	 * @param sTel3 the sTel3 to set
	 */
	public void setsTel3(final String sTel3) {
		this.sTel3 = sTel3;
	}

	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}

	/**
	 * @param tel the tel to set
	 */
	public void setTel(final String tel) {
		this.tel = tel;
	}

	/**
	 * @return the x
	 */
	public String getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public void setX(final String x) {
		this.x = x;
	}

	/**
	 * @return the y
	 */
	public String getY() {
		return y;
	}

	/**
	 * @param y the y to set
	 */
	public void setY(final String y) {
		this.y = y;
	}

	/**
	 * @return the sCorrespondent
	 */
	public String getsCorrespondent() {
		return sCorrespondent;
	}

	/**
	 * @param sCorrespondent the sCorrespondent to set
	 */
	public void setsCorrespondent(final String sCorrespondent) {
		this.sCorrespondent = sCorrespondent;
	}

}
