/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ���̿���ī - �������� ���� WrapperDTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "custPopInfoWrapperDTO")
public class CustPopInfoWrapperDTO {
	/** �������� **/
	private CustContInfoListDTO custInfo;
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO home;
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO office;
	/** ���� ��Ÿ���ּ����� **/
	private CustomerContInfoAdrsDTO etc;
	/** ��ȭ��ȣ���� **/
	private CustomerContInfoTelInfoDTO telInfo;
	/**
	 * @return the custInfo
	 */
	public CustContInfoListDTO getCustInfo() {
		return custInfo;
	}
	/**
	 * @param custInfo the custInfo to set
	 */
	public void setCustInfo(CustContInfoListDTO custInfo) {
		this.custInfo = custInfo;
	}
	/**
	 * @return the home
	 */
	public CustomerContInfoAdrsDTO getHome() {
		return home;
	}
	/**
	 * @param home the home to set
	 */
	public void setHome(CustomerContInfoAdrsDTO home) {
		this.home = home;
	}
	/**
	 * @return the office
	 */
	public CustomerContInfoAdrsDTO getOffice() {
		return office;
	}
	/**
	 * @param office the office to set
	 */
	public void setOffice(CustomerContInfoAdrsDTO office) {
		this.office = office;
	}
	/**
	 * @return the etc
	 */
	public CustomerContInfoAdrsDTO getEtc() {
		return etc;
	}
	/**
	 * @param etc the etc to set
	 */
	public void setEtc(CustomerContInfoAdrsDTO etc) {
		this.etc = etc;
	}
	/**
	 * @return the telInfo
	 */
	public CustomerContInfoTelInfoDTO getTelInfo() {
		return telInfo;
	}
	/**
	 * @param telInfo the telInfo to set
	 */
	public void setTelInfo(CustomerContInfoTelInfoDTO telInfo) {
		this.telInfo = telInfo;
	}
	
	
}
