/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetailOfContDetailList02DTO")
public class InsuranceGeneralDetailOfContDetailList02DTO {
	/** ���ǹ�ȣŸ�� **/
	private String sPolicyType;
	/** ���ǹ�ȣ�����ڵ� **/
	private String sPolicyKind;
	/** �����Ϸù�ȣ **/
	private String sPolicySer;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** �Ǻ����ڸ� **/
	private String sIsdNam;
	/** �Ǻ������ڵ� **/
	private String sIsdCsmNum;
	/** �Ǻ������̸��� **/
	private String sEml;
	/** ����ڿ��ǰ��� **/
	private String sInsrdRelName;
	/** ����ڿ��ǰ����ڵ� **/
	private String sIsdRelCod;
	/** �Ǻ����ڳ��� **/
	private String nCtrAge;
	/** �Ǻ����ڼ��� (1. �� 2. ��) **/
	private String sSex;
	/** �Ǻ����������ڵ� **/
	private String sJobCod;
	/** �Ǻ����������� **/
	private String sJobNam;
	/** ������ȣ **/
	private String sHomZco;
	/** �⺻�ּ� **/
	private String sHomAdr1;
	/** ���ּ� **/
	private String sHomAdr2;
	/** �ڵ�����ȣ(����) **/
	private String sMno;
	/** �ڵ�����ȣ1 **/
	private String sMobileDDD;
	/** �ڵ�����ȣ2 **/
	private String sMobile1;
	/** �ڵ�����ȣ3 **/
	private String sMobile2;
	/** ����ȭ��ȣ1 **/
	private String sHomTelAreNum;
	/** ����ȭ��ȣ2 **/
	private String sHomTelNum1;
	/** ����ȭ��ȣ3 **/
	private String sHomTelNum2;
	/** ȸ����ȭ��ȣ1 **/
	private String sCrpTelAreNum;
	/** ȸ����ȭ��ȣ2 **/
	private String sCrpTelNum1;
	/** ȸ����ȭ��ȣ3 **/
	private String sCrpTelNum2;
	/** �Ǻ������ּұ��� �ѱ۸� **/
	private String sInsrdAddrTypeNm;
	/** �Ǻ������ּұ��� (1:����, 2:ȸ��, 3:��Ÿ, 4:�ӽ�) **/
	private String sInsrdAddrType;

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyKind
	 */
	public String getsPolicyKind() {
		return sPolicyKind;
	}

	/**
	 * @param sPolicyKind the sPolicyKind to set
	 */
	public void setsPolicyKind(final String sPolicyKind) {
		this.sPolicyKind = sPolicyKind;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sIsdNam
	 */
	public String getsIsdNam() {
		return sIsdNam;
	}

	/**
	 * @param sIsdNam the sIsdNam to set
	 */
	public void setsIsdNam(final String sIsdNam) {
		this.sIsdNam = sIsdNam;
	}

	/**
	 * @return the sIsdCsmNum
	 */
	public String getsIsdCsmNum() {
		return sIsdCsmNum;
	}

	/**
	 * @param sIsdCsmNum the sIsdCsmNum to set
	 */
	public void setsIsdCsmNum(final String sIsdCsmNum) {
		this.sIsdCsmNum = sIsdCsmNum;
	}

	/**
	 * @return the sEml
	 */
	public String getsEml() {
		return sEml;
	}

	/**
	 * @param sEml the sEml to set
	 */
	public void setsEml(final String sEml) {
		this.sEml = sEml;
	}

	/**
	 * @return the sInsrdRelName
	 */
	public String getsInsrdRelName() {
		return sInsrdRelName;
	}

	/**
	 * @param sInsrdRelName the sInsrdRelName to set
	 */
	public void setsInsrdRelName(final String sInsrdRelName) {
		this.sInsrdRelName = sInsrdRelName;
	}

	/**
	 * @return the sIsdRelCod
	 */
	public String getsIsdRelCod() {
		return sIsdRelCod;
	}

	/**
	 * @param sIsdRelCod the sIsdRelCod to set
	 */
	public void setsIsdRelCod(final String sIsdRelCod) {
		this.sIsdRelCod = sIsdRelCod;
	}

	/**
	 * @return the nCtrAge
	 */
	public String getnCtrAge() {
		return nCtrAge;
	}

	/**
	 * @param nCtrAge the nCtrAge to set
	 */
	public void setnCtrAge(final String nCtrAge) {
		this.nCtrAge = nCtrAge;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @return the sJobCod
	 */
	public String getsJobCod() {
		return sJobCod;
	}

	/**
	 * @param sJobCod the sJobCod to set
	 */
	public void setsJobCod(final String sJobCod) {
		this.sJobCod = sJobCod;
	}

	/**
	 * @return the sJobNam
	 */
	public String getsJobNam() {
		return sJobNam;
	}

	/**
	 * @param sJobNam the sJobNam to set
	 */
	public void setsJobNam(final String sJobNam) {
		this.sJobNam = sJobNam;
	}

	/**
	 * @return the sHomZco
	 */
	public String getsHomZco() {
		return sHomZco;
	}

	/**
	 * @param sHomZco the sHomZco to set
	 */
	public void setsHomZco(final String sHomZco) {
		this.sHomZco = sHomZco;
	}

	/**
	 * @return the sHomAdr1
	 */
	public String getsHomAdr1() {
		return sHomAdr1;
	}

	/**
	 * @param sHomAdr1 the sHomAdr1 to set
	 */
	public void setsHomAdr1(final String sHomAdr1) {
		this.sHomAdr1 = sHomAdr1;
	}

	/**
	 * @return the sHomAdr2
	 */
	public String getsHomAdr2() {
		return sHomAdr2;
	}

	/**
	 * @param sHomAdr2 the sHomAdr2 to set
	 */
	public void setsHomAdr2(final String sHomAdr2) {
		this.sHomAdr2 = sHomAdr2;
	}

	/**
	 * @return the sMno
	 */
	public String getsMno() {
		return sMno;
	}

	/**
	 * @param sMno the sMno to set
	 */
	public void setsMno(final String sMno) {
		this.sMno = sMno;
	}

	/**
	 * @return the sMobileDDD
	 */
	public String getsMobileDDD() {
		return sMobileDDD;
	}

	/**
	 * @param sMobileDDD the sMobileDDD to set
	 */
	public void setsMobileDDD(final String sMobileDDD) {
		this.sMobileDDD = sMobileDDD;
	}

	/**
	 * @return the sMobile1
	 */
	public String getsMobile1() {
		return sMobile1;
	}

	/**
	 * @param sMobile1 the sMobile1 to set
	 */
	public void setsMobile1(final String sMobile1) {
		this.sMobile1 = sMobile1;
	}

	/**
	 * @return the sMobile2
	 */
	public String getsMobile2() {
		return sMobile2;
	}

	/**
	 * @param sMobile2 the sMobile2 to set
	 */
	public void setsMobile2(final String sMobile2) {
		this.sMobile2 = sMobile2;
	}

	/**
	 * @return the sHomTelAreNum
	 */
	public String getsHomTelAreNum() {
		return sHomTelAreNum;
	}

	/**
	 * @param sHomTelAreNum the sHomTelAreNum to set
	 */
	public void setsHomTelAreNum(final String sHomTelAreNum) {
		this.sHomTelAreNum = sHomTelAreNum;
	}

	/**
	 * @return the sHomTelNum1
	 */
	public String getsHomTelNum1() {
		return sHomTelNum1;
	}

	/**
	 * @param sHomTelNum1 the sHomTelNum1 to set
	 */
	public void setsHomTelNum1(final String sHomTelNum1) {
		this.sHomTelNum1 = sHomTelNum1;
	}

	/**
	 * @return the sHomTelNum2
	 */
	public String getsHomTelNum2() {
		return sHomTelNum2;
	}

	/**
	 * @param sHomTelNum2 the sHomTelNum2 to set
	 */
	public void setsHomTelNum2(final String sHomTelNum2) {
		this.sHomTelNum2 = sHomTelNum2;
	}

	/**
	 * @return the sCrpTelAreNum
	 */
	public String getsCrpTelAreNum() {
		return sCrpTelAreNum;
	}

	/**
	 * @param sCrpTelAreNum the sCrpTelAreNum to set
	 */
	public void setsCrpTelAreNum(final String sCrpTelAreNum) {
		this.sCrpTelAreNum = sCrpTelAreNum;
	}

	/**
	 * @return the sCrpTelNum1
	 */
	public String getsCrpTelNum1() {
		return sCrpTelNum1;
	}

	/**
	 * @param sCrpTelNum1 the sCrpTelNum1 to set
	 */
	public void setsCrpTelNum1(final String sCrpTelNum1) {
		this.sCrpTelNum1 = sCrpTelNum1;
	}

	/**
	 * @return the sCrpTelNum2
	 */
	public String getsCrpTelNum2() {
		return sCrpTelNum2;
	}

	/**
	 * @param sCrpTelNum2 the sCrpTelNum2 to set
	 */
	public void setsCrpTelNum2(final String sCrpTelNum2) {
		this.sCrpTelNum2 = sCrpTelNum2;
	}

	/**
	 * @return the sInsrdAddrTypeNm
	 */
	public String getsInsrdAddrTypeNm() {
		return sInsrdAddrTypeNm;
	}

	/**
	 * @param sInsrdAddrTypeNm the sInsrdAddrTypeNm to set
	 */
	public void setsInsrdAddrTypeNm(final String sInsrdAddrTypeNm) {
		this.sInsrdAddrTypeNm = sInsrdAddrTypeNm;
	}

	/**
	 * @return the sInsrdAddrType
	 */
	public String getsInsrdAddrType() {
		return sInsrdAddrType;
	}

	/**
	 * @param sInsrdAddrType the sInsrdAddrType to set
	 */
	public void setsInsrdAddrType(final String sInsrdAddrType) {
		this.sInsrdAddrType = sInsrdAddrType;
	}

}
