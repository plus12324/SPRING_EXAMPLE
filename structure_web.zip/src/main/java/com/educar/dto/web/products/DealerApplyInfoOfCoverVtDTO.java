/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� û�೻�� Ȯ�� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerApplyInfoOfCoverVtDTO")
public class DealerApplyInfoOfCoverVtDTO {
	/** �㺸�� **/
	private String sCoverTitle;
	/** ���󳻿� **/
	private String sCoverContent;
	/** ����� **/
	private String sCoverPrem;

	/**
	 * @return the sCoverTitle
	 */
	public String getsCoverTitle() {
		return sCoverTitle;
	}

	/**
	 * @param sCoverTitle the sCoverTitle to set
	 */
	public void setsCoverTitle(final String sCoverTitle) {
		this.sCoverTitle = sCoverTitle;
	}

	/**
	 * @return the sCoverContent
	 */
	public String getsCoverContent() {
		return sCoverContent;
	}

	/**
	 * @param sCoverContent the sCoverContent to set
	 */
	public void setsCoverContent(final String sCoverContent) {
		this.sCoverContent = sCoverContent;
	}

	/**
	 * @return the sCoverPrem
	 */
	public String getsCoverPrem() {
		return sCoverPrem;
	}

	/**
	 * @param sCoverPrem the sCoverPrem to set
	 */
	public void setsCoverPrem(final String sCoverPrem) {
		this.sCoverPrem = sCoverPrem;
	}

}
