/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailSearchResultDTO")
public class InsuranceCarDetailSearchResultDTO {
	/** �������, ��������, �ڵ���ü��Ȳ, Ư������ **/
	private InsuranceCarDetailOfPolca01InfoDTO polca01Info;
	/** �������� **/
	private InsuranceCarDetailOfPolca02InfoDTO polca02Info;
	/** �Ǻ����� ���� **/
	private InsuranceCarDetailOfInsrdInfoDTO insrdInfo;
	/** �Ǻ����� �߼��� �ּ� **/
	private InsuranceCarDetailOfInsrdSendAdrsInfoDTO insrdSendAdrsInfo;
	/** �г� ���� ���� **/
	private List<InsuranceCarDetailOfInstallmentInfoDTO> installmentInfo;
	/** Ư����� ���� **/
	private InsuranceCarDetailOfpolca03Type1DTO polca03Type1;
	/** �㺸���� **/
	private List<InsuranceCarDetailOfCoverInfoDTO> coverInfo;
	/** �߰��㺸 ���� **/
	private List<InsuranceCarDetailOfCoverInfoDTO> coverInfoForSpec;
	
	/**
	 * @return the polca01Info
	 */
	public InsuranceCarDetailOfPolca01InfoDTO getPolca01Info() {
		return polca01Info;
	}

	/**
	 * @param polca01Info the polca01Info to set
	 */
	public void setPolca01Info(final InsuranceCarDetailOfPolca01InfoDTO polca01Info) {
		this.polca01Info = polca01Info;
	}

	/**
	 * @return the polca02Info
	 */
	public InsuranceCarDetailOfPolca02InfoDTO getPolca02Info() {
		return polca02Info;
	}

	/**
	 * @param polca02Info the polca02Info to set
	 */
	public void setPolca02Info(final InsuranceCarDetailOfPolca02InfoDTO polca02Info) {
		this.polca02Info = polca02Info;
	}

	/**
	 * @return the insrdInfo
	 */
	public InsuranceCarDetailOfInsrdInfoDTO getInsrdInfo() {
		return insrdInfo;
	}

	/**
	 * @param insrdInfo the insrdInfo to set
	 */
	public void setInsrdInfo(final InsuranceCarDetailOfInsrdInfoDTO insrdInfo) {
		this.insrdInfo = insrdInfo;
	}

	/**
	 * @return the insrdSendAdrsInfo
	 */
	public InsuranceCarDetailOfInsrdSendAdrsInfoDTO getInsrdSendAdrsInfo() {
		return insrdSendAdrsInfo;
	}

	/**
	 * @param insrdSendAdrsInfo the insrdSendAdrsInfo to set
	 */
	public void setInsrdSendAdrsInfo(final InsuranceCarDetailOfInsrdSendAdrsInfoDTO insrdSendAdrsInfo) {
		this.insrdSendAdrsInfo = insrdSendAdrsInfo;
	}

	/**
	 * @return the installmentInfo
	 */
	public List<InsuranceCarDetailOfInstallmentInfoDTO> getInstallmentInfo() {
		return installmentInfo;
	}

	/**
	 * @param installmentInfo the installmentInfo to set
	 */
	public void setInstallmentInfo(final List<InsuranceCarDetailOfInstallmentInfoDTO> installmentInfo) {
		this.installmentInfo = installmentInfo;
	}

	/**
	 * @return the polca03Type1
	 */
	public InsuranceCarDetailOfpolca03Type1DTO getPolca03Type1() {
		return polca03Type1;
	}

	/**
	 * @param polca03Type1 the polca03Type1 to set
	 */
	public void setPolca03Type1(final InsuranceCarDetailOfpolca03Type1DTO polca03Type1) {
		this.polca03Type1 = polca03Type1;
	}

	/**
	 * @return the coverInfo
	 */
	public List<InsuranceCarDetailOfCoverInfoDTO> getCoverInfo() {
		return coverInfo;
	}

	/**
	 * @param coverInfo the coverInfo to set
	 */
	public void setCoverInfo(final List<InsuranceCarDetailOfCoverInfoDTO> coverInfo) {
		this.coverInfo = coverInfo;
	}

	/**
	 * @return the coverInfoForSpec
	 */
	public List<InsuranceCarDetailOfCoverInfoDTO> getCoverInfoForSpec() {
		return coverInfoForSpec;
	}

	/**
	 * @param coverInfoForSpec the coverInfoForSpec to set
	 */
	public void setCoverInfoForSpec(
			List<InsuranceCarDetailOfCoverInfoDTO> coverInfoForSpec) {
		this.coverInfoForSpec = coverInfoForSpec;
	}

}
