/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ���� ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfGENAA36DTO")
public class CalculationOfGENAA36DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ���迩�� (� �� ������ Ȱ������ ���� : "0", � �� ������ Ȱ���� :"1") **/
	private String sRiskActYN;
	/** ����Ȱ�� A ("0","1") **/
	private String sRiskActCd1;
	/** ����Ȱ�� B ("0","1") **/
	private String sRiskActCd2;
	/** ����Ȱ�� C ("0","1") **/
	private String sRiskActCd3;
	/** ����Ȱ�� D ("0","1") **/
	private String sRiskActCd4;
	/** ����Ȱ�� E ("0","1") **/
	private String sRiskActCd5;
	/** ����Ȱ�� F ("0","1") **/
	private String sRiskActCd6;

	/**
	 * @return the sRiskActYN
	 */
	public String getsRiskActYN() {
		return sRiskActYN;
	}

	/**
	 * @param sRiskActYN the sRiskActYN to set
	 */
	public void setsRiskActYN(final String sRiskActYN) {
		this.sRiskActYN = sRiskActYN;
	}

	/**
	 * @return the sRiskActCd1
	 */
	public String getsRiskActCd1() {
		return sRiskActCd1;
	}

	/**
	 * @param sRiskActCd1 the sRiskActCd1 to set
	 */
	public void setsRiskActCd1(final String sRiskActCd1) {
		this.sRiskActCd1 = sRiskActCd1;
	}

	/**
	 * @return the sRiskActCd2
	 */
	public String getsRiskActCd2() {
		return sRiskActCd2;
	}

	/**
	 * @param sRiskActCd2 the sRiskActCd2 to set
	 */
	public void setsRiskActCd2(final String sRiskActCd2) {
		this.sRiskActCd2 = sRiskActCd2;
	}

	/**
	 * @return the sRiskActCd3
	 */
	public String getsRiskActCd3() {
		return sRiskActCd3;
	}

	/**
	 * @param sRiskActCd3 the sRiskActCd3 to set
	 */
	public void setsRiskActCd3(final String sRiskActCd3) {
		this.sRiskActCd3 = sRiskActCd3;
	}

	/**
	 * @return the sRiskActCd4
	 */
	public String getsRiskActCd4() {
		return sRiskActCd4;
	}

	/**
	 * @param sRiskActCd4 the sRiskActCd4 to set
	 */
	public void setsRiskActCd4(final String sRiskActCd4) {
		this.sRiskActCd4 = sRiskActCd4;
	}

	/**
	 * @return the sRiskActCd5
	 */
	public String getsRiskActCd5() {
		return sRiskActCd5;
	}

	/**
	 * @param sRiskActCd5 the sRiskActCd5 to set
	 */
	public void setsRiskActCd5(final String sRiskActCd5) {
		this.sRiskActCd5 = sRiskActCd5;
	}

	/**
	 * @return the sRiskActCd6
	 */
	public String getsRiskActCd6() {
		return sRiskActCd6;
	}

	/**
	 * @param sRiskActCd6 the sRiskActCd6 to set
	 */
	public void setsRiskActCd6(final String sRiskActCd6) {
		this.sRiskActCd6 = sRiskActCd6;
	}

}
