/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ���ϸ��� ���� ��ȸ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mileageSearchDTO")
public class MileageSearchResultDTO extends PageDTO {
	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	/** ������ȣ **/
	private String sPlateNo;
	/** ��ϱ��� **/
	private String sRegMileText;
	/** ���ϸ��� **/
	private String nGaugeDist;
	/** �������� **/
	private String sAcceptDate;
	/** �����ð� **/
	private String sAcceptTime;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sRegMileText
	 */
	public String getsRegMileText() {
		return sRegMileText;
	}

	/**
	 * @param sRegMileText the sRegMileText to set
	 */
	public void setsRegMileText(final String sRegMileText) {
		this.sRegMileText = sRegMileText;
	}

	/**
	 * @return the nGaugeDist
	 */
	public String getnGaugeDist() {
		return nGaugeDist;
	}

	/**
	 * @param nGaugeDist the nGaugeDist to set
	 */
	public void setnGaugeDist(final String nGaugeDist) {
		this.nGaugeDist = nGaugeDist;
	}

	/**
	 * @return the sAcceptDate
	 */
	public String getsAcceptDate() {
		return sAcceptDate;
	}

	/**
	 * @param sAcceptDate the sAcceptDate to set
	 */
	public void setsAcceptDate(final String sAcceptDate) {
		this.sAcceptDate = sAcceptDate;
	}

	/**
	 * @return the sAcceptTime
	 */
	public String getsAcceptTime() {
		return sAcceptTime;
	}

	/**
	 * @param sAcceptTime the sAcceptTime to set
	 */
	public void setsAcceptTime(final String sAcceptTime) {
		this.sAcceptTime = sAcceptTime;
	}

}
