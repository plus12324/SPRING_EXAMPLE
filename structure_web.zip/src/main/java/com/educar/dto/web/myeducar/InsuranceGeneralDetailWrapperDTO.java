/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * �Ϲݺ��� �� ��ȸ WrapperDTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name="insuranceGeneralDetailWrapperDTO")
public class InsuranceGeneralDetailWrapperDTO {

	/** �Ϲ� ���� �� **/
	private InsuranceGeneralDetailResultDTO detailResult;
	/** �Ϲ� ���� �㺸���� **/
	private List<InsuranceGeneralCoverageSearchResultDTO> coverageList;
	/** �Ϲ� ���� ���Գ��� **/
	private List<InsuranceGeneralDivPremResultDTO> paymentHistoryList;
	/**
	 * @return the detailResult
	 */
	public InsuranceGeneralDetailResultDTO getDetailResult() {
		return detailResult;
	}
	/**
	 * @param detailResult the detailResult to set
	 */
	public void setDetailResult(final InsuranceGeneralDetailResultDTO detailResult) {
		this.detailResult = detailResult;
	}
	/**
	 * @return the coverageList
	 */
	public List<InsuranceGeneralCoverageSearchResultDTO> getCoverageList() {
		return coverageList;
	}
	/**
	 * @param coverageList the coverageList to set
	 */
	public void setCoverageList(final List<InsuranceGeneralCoverageSearchResultDTO> coverageList) {
		this.coverageList = coverageList;
	}
	/**
	 * @return the paymentHistoryList
	 */
	public List<InsuranceGeneralDivPremResultDTO> getPaymentHistoryList() {
		return paymentHistoryList;
	}
	/**
	 * @param paymentHistoryList the paymentHistoryList to set
	 */
	public void setPaymentHistoryList(final List<InsuranceGeneralDivPremResultDTO> paymentHistoryList) {
		this.paymentHistoryList = paymentHistoryList;
	}
}
