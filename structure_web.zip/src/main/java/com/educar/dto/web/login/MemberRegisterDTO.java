/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.login;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * ȸ������ �Ⱓ�� ȣ�� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "memberRegisterDTO")
public class MemberRegisterDTO {
	/** �Ǻ����� �ֹι�ȣ **/
	private String sCustNo;
	/** �����ּ� **/
	private String sHomeZip1;
	/** �����ּҺ��� **/
	private String sHomeAdrsChange;
	/** ȸ���ּ� **/
	private String sCompanyZip1;
	/** ȸ���ּҺ��� **/
	private String sCompanyAdrsChange;
	/**  **/
	private String sCompanyZip2;
	/**  **/
	private String sCompanyAdrs1;
	/**  **/
	private String sCompanyAdrs2;
	/**  **/
	private String sCompanyAdrs3;
	/**  **/
	private String sCompanyAdrsAdd;
	/**  **/
	private String sCompanyAdrsAdd2;
	/**  **/
	private String sAffiliatedConcern;
	/**  **/
	private String agree;
	/**  **/
	private String sEmailCheck;
	/**  **/
	private String sSMSCheck;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sHomeZip1
	 */
	public String getsHomeZip1() {
		return sHomeZip1;
	}

	/**
	 * @param sHomeZip1 the sHomeZip1 to set
	 */
	public void setsHomeZip1(final String sHomeZip1) {
		this.sHomeZip1 = sHomeZip1;
	}

	/**
	 * @return the sHomeAdrsChange
	 */
	public String getsHomeAdrsChange() {
		return sHomeAdrsChange;
	}

	/**
	 * @param sHomeAdrsChange the sHomeAdrsChange to set
	 */
	public void setsHomeAdrsChange(final String sHomeAdrsChange) {
		this.sHomeAdrsChange = sHomeAdrsChange;
	}

	/**
	 * @return the sCompanyZip1
	 */
	public String getsCompanyZip1() {
		return sCompanyZip1;
	}

	/**
	 * @param sCompanyZip1 the sCompanyZip1 to set
	 */
	public void setsCompanyZip1(final String sCompanyZip1) {
		this.sCompanyZip1 = sCompanyZip1;
	}

	/**
	 * @return the sCompanyAdrsChange
	 */
	public String getsCompanyAdrsChange() {
		return sCompanyAdrsChange;
	}

	/**
	 * @param sCompanyAdrsChange the sCompanyAdrsChange to set
	 */
	public void setsCompanyAdrsChange(final String sCompanyAdrsChange) {
		this.sCompanyAdrsChange = sCompanyAdrsChange;
	}

	/**
	 * @return the sCompanyZip2
	 */
	public String getsCompanyZip2() {
		return sCompanyZip2;
	}

	/**
	 * @param sCompanyZip2 the sCompanyZip2 to set
	 */
	public void setsCompanyZip2(final String sCompanyZip2) {
		this.sCompanyZip2 = sCompanyZip2;
	}

	/**
	 * @return the sCompanyAdrs1
	 */
	public String getsCompanyAdrs1() {
		return sCompanyAdrs1;
	}

	/**
	 * @param sCompanyAdrs1 the sCompanyAdrs1 to set
	 */
	public void setsCompanyAdrs1(final String sCompanyAdrs1) {
		this.sCompanyAdrs1 = sCompanyAdrs1;
	}

	/**
	 * @return the sCompanyAdrs2
	 */
	public String getsCompanyAdrs2() {
		return sCompanyAdrs2;
	}

	/**
	 * @param sCompanyAdrs2 the sCompanyAdrs2 to set
	 */
	public void setsCompanyAdrs2(final String sCompanyAdrs2) {
		this.sCompanyAdrs2 = sCompanyAdrs2;
	}

	/**
	 * @return the sCompanyAdrs3
	 */
	public String getsCompanyAdrs3() {
		return sCompanyAdrs3;
	}

	/**
	 * @param sCompanyAdrs3 the sCompanyAdrs3 to set
	 */
	public void setsCompanyAdrs3(final String sCompanyAdrs3) {
		this.sCompanyAdrs3 = sCompanyAdrs3;
	}

	/**
	 * @return the sCompanyAdrsAdd
	 */
	public String getsCompanyAdrsAdd() {
		return sCompanyAdrsAdd;
	}

	/**
	 * @param sCompanyAdrsAdd the sCompanyAdrsAdd to set
	 */
	public void setsCompanyAdrsAdd(final String sCompanyAdrsAdd) {
		this.sCompanyAdrsAdd = sCompanyAdrsAdd;
	}

	/**
	 * @return the sCompanyAdrsAdd2
	 */
	public String getsCompanyAdrsAdd2() {
		return sCompanyAdrsAdd2;
	}

	/**
	 * @param sCompanyAdrsAdd2 the sCompanyAdrsAdd2 to set
	 */
	public void setsCompanyAdrsAdd2(final String sCompanyAdrsAdd2) {
		this.sCompanyAdrsAdd2 = sCompanyAdrsAdd2;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the agree
	 */
	public String getAgree() {
		return agree;
	}

	/**
	 * @param agree the agree to set
	 */
	public void setAgree(final String agree) {
		this.agree = agree;
	}

	/**
	 * @return the sEmailCheck
	 */
	public String getsEmailCheck() {
		return sEmailCheck;
	}

	/**
	 * @param sEmailCheck the sEmailCheck to set
	 */
	public void setsEmailCheck(final String sEmailCheck) {
		this.sEmailCheck = sEmailCheck;
	}

	/**
	 * @return the sSMSCheck
	 */
	public String getsSMSCheck() {
		return sSMSCheck;
	}

	/**
	 * @param sSMSCheck the sSMSCheck to set
	 */
	public void setsSMSCheck(final String sSMSCheck) {
		this.sSMSCheck = sSMSCheck;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
