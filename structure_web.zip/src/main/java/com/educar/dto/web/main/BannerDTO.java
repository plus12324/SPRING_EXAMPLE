/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.main;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

/**
 * <pre>
 * ����ȭ�� Banner DTO
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "bannerDTO")
public class BannerDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �޴��� ����, A,B,C,D .... **/
	private String sMenuType;
	/** �޴� Ŭ�� ��, �̵� url **/
	private String sForwardURL;
	/** �޴��� ��׶��� �̹��� url link **/
	private String sImageLinkURL;
	/** �޴��� display text **/
	private String sText;
	/** �޴��� alt �޼��� **/
	private String sMessage;

	/**
	 * @return the sMenuType
	 */
	public String getsMenuType() {
		return sMenuType;
	}

	/**
	 * @param sMenuType the sMenuType to set
	 */
	public void setsMenuType(final String sMenuType) {
		this.sMenuType = sMenuType;
	}

	/**
	 * @return the sForwardURL
	 */
	public String getsForwardURL() {
		return sForwardURL;
	}

	/**
	 * @param sForwardURL the sForwardURL to set
	 */
	public void setsForwardURL(final String sForwardURL) {
		this.sForwardURL = sForwardURL;
	}

	/**
	 * @return the sImageLinkURL
	 */
	public String getsImageLinkURL() {
		return sImageLinkURL;
	}

	/**
	 * @param sImageLinkURL the sImageLinkURL to set
	 */
	public void setsImageLinkURL(final String sImageLinkURL) {
		this.sImageLinkURL = sImageLinkURL;
	}

	/**
	 * @return the sText
	 */
	public String getsText() {
		return sText;
	}

	/**
	 * @param sText the sText to set
	 */
	public void setsText(final String sText) {
		this.sText = sText;
	}

	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}

	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(final String sMessage) {
		this.sMessage = sMessage;
	}

	/**
	 * @return the nOrder
	 */
	public int getnOrder() {
		return nOrder;
	}

	/**
	 * @param nOrder the nOrder to set
	 */
	public void setnOrder(final int nOrder) {
		this.nOrder = nOrder;
	}

	/** �޴��� display ���� 1 to n **/
	@ValidateLength(type = TypeEnum.NUMBER, required = true)
	private int nOrder;
}
