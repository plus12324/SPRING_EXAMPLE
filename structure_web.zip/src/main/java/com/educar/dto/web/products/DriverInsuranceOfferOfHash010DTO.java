/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;

/**
 * �����ں��� ����ī������ û�� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "driverInsuranceOfferOfHash010DTO")
public class DriverInsuranceOfferOfHash010DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ����Ⱓ ���ϼ� ((int)DateUtils.DateDiff(contract_dte, contract_dte_end, "3") ���ϼ� ���) **/
	private String nCtrDD;
	/** ����Ⱓ �ѿ��� ((int)DateUtils.DateDiff(contract_dte, contract_dte_end, "2") �ѿ��� ���) **/
	private String nCtrMM;
	/** ����Ⱓ �ѳ�� ((int)DateUtils.DateDiff(contract_dte, contract_dte_end, "1") �ѳ�� ���) **/
	private String nCtrYY;
	/** ���ݹ�� (90  : ��Ÿ �Ͻó� ,    01 : �ڵ���ü 12ȸ,36ȸ��) **/
	private String sClcMth;
	/** ��������  (������:10 �κ���:20  hashcalc �� bu_bu_yn��) **/
	private String sEtnTyp;
	/** ����ñ� (YYYYMMDD) **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sInsCtrTpd;
	/** �������� (YYYYMMDD) **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sInsCtrPed;
	/** ������ 8�ڸ�(�����) **/
	private String sFirstDate;
	/** ����ð� 6�ڸ�(�ú���) **/
	private String sFirstTime;
	/** ��������(A,B,C) (������:A, �⺻��:B, ������:C  hashcalc �� sPlnCod��) **/
	private String sPlnCod;
	/** �г���� (01:�Ͻó� 12:12�г� 36:36�г�  hashcalc �� nab_ib��) **/
	private String sPytMth;
	/** û���Է���(�������� 8�ڸ�) **/
	private String sSbcDte;

	/**
	 * @return the nCtrDD
	 */
	public String getnCtrDD() {
		return nCtrDD;
	}

	/**
	 * @param nCtrDD the nCtrDD to set
	 */
	public void setnCtrDD(final String nCtrDD) {
		this.nCtrDD = nCtrDD;
	}

	/**
	 * @return the nCtrMM
	 */
	public String getnCtrMM() {
		return nCtrMM;
	}

	/**
	 * @param nCtrMM the nCtrMM to set
	 */
	public void setnCtrMM(final String nCtrMM) {
		this.nCtrMM = nCtrMM;
	}

	/**
	 * @return the nCtrYY
	 */
	public String getnCtrYY() {
		return nCtrYY;
	}

	/**
	 * @param nCtrYY the nCtrYY to set
	 */
	public void setnCtrYY(final String nCtrYY) {
		this.nCtrYY = nCtrYY;
	}

	/**
	 * @return the sClcMth
	 */
	public String getsClcMth() {
		return sClcMth;
	}

	/**
	 * @param sClcMth the sClcMth to set
	 */
	public void setsClcMth(final String sClcMth) {
		this.sClcMth = sClcMth;
	}

	/**
	 * @return the sEtnTyp
	 */
	public String getsEtnTyp() {
		return sEtnTyp;
	}

	/**
	 * @param sEtnTyp the sEtnTyp to set
	 */
	public void setsEtnTyp(final String sEtnTyp) {
		this.sEtnTyp = sEtnTyp;
	}

	/**
	 * @return the sInsCtrTpd
	 */
	public String getsInsCtrTpd() {
		return sInsCtrTpd;
	}

	/**
	 * @param sInsCtrTpd the sInsCtrTpd to set
	 */
	public void setsInsCtrTpd(final String sInsCtrTpd) {
		this.sInsCtrTpd = sInsCtrTpd;
	}

	/**
	 * @return the sInsCtrPed
	 */
	public String getsInsCtrPed() {
		return sInsCtrPed;
	}

	/**
	 * @param sInsCtrPed the sInsCtrPed to set
	 */
	public void setsInsCtrPed(final String sInsCtrPed) {
		this.sInsCtrPed = sInsCtrPed;
	}

	/**
	 * @return the sFirstDate
	 */
	public String getsFirstDate() {
		return sFirstDate;
	}

	/**
	 * @param sFirstDate the sFirstDate to set
	 */
	public void setsFirstDate(final String sFirstDate) {
		this.sFirstDate = sFirstDate;
	}

	/**
	 * @return the sFirstTime
	 */
	public String getsFirstTime() {
		return sFirstTime;
	}

	/**
	 * @param sFirstTime the sFirstTime to set
	 */
	public void setsFirstTime(final String sFirstTime) {
		this.sFirstTime = sFirstTime;
	}

	/**
	 * @return the sPlnCod
	 */
	public String getsPlnCod() {
		return sPlnCod;
	}

	/**
	 * @param sPlnCod the sPlnCod to set
	 */
	public void setsPlnCod(final String sPlnCod) {
		this.sPlnCod = sPlnCod;
	}

	/**
	 * @return the sPytMth
	 */
	public String getsPytMth() {
		return sPytMth;
	}

	/**
	 * @param sPytMth the sPytMth to set
	 */
	public void setsPytMth(final String sPytMth) {
		this.sPytMth = sPytMth;
	}

	/**
	 * @return the sSbcDte
	 */
	public String getsSbcDte() {
		return sSbcDte;
	}

	/**
	 * @param sSbcDte the sSbcDte to set
	 */
	public void setsSbcDte(final String sSbcDte) {
		this.sSbcDte = sSbcDte;
	}

}
