/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * ����⵿ ���� ��ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "emergencyActionSearchDTO")
public class EmergencyActionSearchDTO {
	
	/** �ּ�1 **/
	private String sCityName;
	/** �ּ�2 **/
	private String sCountyName;
	/** �ּ�3 **/
	private String sTownName;
	/** ������ �ε��� (��ȸ�� ���) **/
	private String pageIndex;
	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}
	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(String sCityName) {
		this.sCityName = sCityName;
	}
	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}
	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(String sCountyName) {
		this.sCountyName = sCountyName;
	}
	/**
	 * @return the sTownName
	 */
	public String getsTownName() {
		return sTownName;
	}
	/**
	 * @param sTownName the sTownName to set
	 */
	public void setsTownName(String sTownName) {
		this.sTownName = sTownName;
	}
	/**
	 * @return the pageIndex
	 */
	public String getPageIndex() {
		return pageIndex;
	}
	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(String pageIndex) {
		this.pageIndex = pageIndex;
	}
	
	


}
