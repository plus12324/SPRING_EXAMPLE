/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� �⺻���� �Է� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerContSaveSalesSearchDTO")
public class DealerContSaveSalesSearchDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/** �Ǻ����� ���� (1:�ֹι�ȣ, 2:������ڵ�) **/
	private String sInsrdType;
	/** �Ǻ����� �̸� **/
	private String sInsrdName;
	/** �Ǻ����� �ֹι�ȣ/����ڹ�ȣ **/
	private String sInsrdID;
	/** �������� (0510 : ��������) **/
	private String sInsType;
	/** ���ұ��� (1:����) **/
	private String sCalcType;
	/** ���Թ�� (1111:�Ͻó�) **/
	private String sPayClause;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** �ڵ���1 **/
	private String sCellPhone1;
	/** �ڵ���2 **/
	private String sCellPhone2;
	/** �ڵ���3 **/
	private String sCellPhone3;
	/** ������ȭ1 **/
	private String sHomeTel1;
	/** ������ȭ2 **/
	private String sHomeTel2;
	/** ������ȭ3 **/
	private String sHomeTel3;
	/** ������ȭ1 **/
	private String sOfficeTel1;
	/** ������ȭ2 **/
	private String sOfficeTel2;
	/** ������ȭ3 **/
	private String sOfficeTel3;
	/** �̸��� **/
	private String sEmail;
	/** �ѽ�1 **/
	private String sFax1;
	/** �ѽ�2 **/
	private String sFax2;
	/** �ѽ�3 **/
	private String sFax3;
	/** ������ **/
	private String sDealFirmName;
	/** ���� **/
	private String sDealFirmAdd;
	/** ����ڵ� **/
	private String sDealFirmCode;
	/** �ŸŻ����ȣ **/
	private String sDealerNo;
	/** ����������ȣ1 **/
	private String sCompanyZip1;
	/** ����������ȣ2 **/
	private String sCompanyZip2;
	/** ������ּ� �ּ�1 **/
	private String sCompanyAdrs1;
	/** ������ּ� �ּ�2 **/
	private String sCompanyAdrs2;
	/** ������ּ� �ּ�3 **/
	private String sCompanyAdrs3;
	/** ������ּ� ������ **/
	private String sCompanyAdrsAdd;
	/** ����������ó 2 : ���� **/
	private String sSendAdrsType;
	
	/** �Ǻ����� �ֹι�ȣ/����ڹ�ȣ 1**/
	private String sInsrdID1;
	/** �Ǻ����� �ֹι�ȣ/����ڹ�ȣ 2**/
	private String sInsrdID2;
	/** Ű���庸�� ��ȣȭ Key **/
	private String hid_key_data;
	/** ������ּ� - �����θ� ������ȣ **/
	private String sCompanyAddrMgtNo;
	/**
	 * @return the sInsrdType
	 */
	public String getsInsrdType() {
		return sInsrdType;
	}

	/**
	 * @param sInsrdType the sInsrdType to set
	 */
	public void setsInsrdType(final String sInsrdType) {
		this.sInsrdType = sInsrdType;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sCalcType
	 */
	public String getsCalcType() {
		return sCalcType;
	}

	/**
	 * @param sCalcType the sCalcType to set
	 */
	public void setsCalcType(final String sCalcType) {
		this.sCalcType = sCalcType;
	}

	/**
	 * @return the sPayClause
	 */
	public String getsPayClause() {
		return sPayClause;
	}

	/**
	 * @param sPayClause the sPayClause to set
	 */
	public void setsPayClause(final String sPayClause) {
		this.sPayClause = sPayClause;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}

	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(final String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}

	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}

	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(final String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}

	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}

	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(final String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}

	/**
	 * @return the sOfficeTel1
	 */
	public String getsOfficeTel1() {
		return sOfficeTel1;
	}

	/**
	 * @param sOfficeTel1 the sOfficeTel1 to set
	 */
	public void setsOfficeTel1(final String sOfficeTel1) {
		this.sOfficeTel1 = sOfficeTel1;
	}

	/**
	 * @return the sOfficeTel2
	 */
	public String getsOfficeTel2() {
		return sOfficeTel2;
	}

	/**
	 * @param sOfficeTel2 the sOfficeTel2 to set
	 */
	public void setsOfficeTel2(final String sOfficeTel2) {
		this.sOfficeTel2 = sOfficeTel2;
	}

	/**
	 * @return the sOfficeTel3
	 */
	public String getsOfficeTel3() {
		return sOfficeTel3;
	}

	/**
	 * @param sOfficeTel3 the sOfficeTel3 to set
	 */
	public void setsOfficeTel3(final String sOfficeTel3) {
		this.sOfficeTel3 = sOfficeTel3;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}

	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(final String sFax1) {
		this.sFax1 = sFax1;
	}

	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}

	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(final String sFax2) {
		this.sFax2 = sFax2;
	}

	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}

	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(final String sFax3) {
		this.sFax3 = sFax3;
	}

	/**
	 * @return the sDealFirmName
	 */
	public String getsDealFirmName() {
		return sDealFirmName;
	}

	/**
	 * @param sDealFirmName the sDealFirmName to set
	 */
	public void setsDealFirmName(final String sDealFirmName) {
		this.sDealFirmName = sDealFirmName;
	}

	/**
	 * @return the sDealFirmAdd
	 */
	public String getsDealFirmAdd() {
		return sDealFirmAdd;
	}

	/**
	 * @param sDealFirmAdd the sDealFirmAdd to set
	 */
	public void setsDealFirmAdd(final String sDealFirmAdd) {
		this.sDealFirmAdd = sDealFirmAdd;
	}

	/**
	 * @return the sDealFirmCode
	 */
	public String getsDealFirmCode() {
		return sDealFirmCode;
	}

	/**
	 * @param sDealFirmCode the sDealFirmCode to set
	 */
	public void setsDealFirmCode(final String sDealFirmCode) {
		this.sDealFirmCode = sDealFirmCode;
	}

	/**
	 * @return the sDealerNo
	 */
	public String getsDealerNo() {
		return sDealerNo;
	}

	/**
	 * @param sDealerNo the sDealerNo to set
	 */
	public void setsDealerNo(final String sDealerNo) {
		this.sDealerNo = sDealerNo;
	}

	/**
	 * @return the sCompanyZip1
	 */
	public String getsCompanyZip1() {
		return sCompanyZip1;
	}

	/**
	 * @param sCompanyZip1 the sCompanyZip1 to set
	 */
	public void setsCompanyZip1(final String sCompanyZip1) {
		this.sCompanyZip1 = sCompanyZip1;
	}

	/**
	 * @return the sCompanyZip2
	 */
	public String getsCompanyZip2() {
		return sCompanyZip2;
	}

	/**
	 * @param sCompanyZip2 the sCompanyZip2 to set
	 */
	public void setsCompanyZip2(final String sCompanyZip2) {
		this.sCompanyZip2 = sCompanyZip2;
	}

	/**
	 * @return the sCompanyAdrs1
	 */
	public String getsCompanyAdrs1() {
		return sCompanyAdrs1;
	}

	/**
	 * @param sCompanyAdrs1 the sCompanyAdrs1 to set
	 */
	public void setsCompanyAdrs1(final String sCompanyAdrs1) {
		this.sCompanyAdrs1 = sCompanyAdrs1;
	}

	/**
	 * @return the sCompanyAdrs2
	 */
	public String getsCompanyAdrs2() {
		return sCompanyAdrs2;
	}

	/**
	 * @param sCompanyAdrs2 the sCompanyAdrs2 to set
	 */
	public void setsCompanyAdrs2(final String sCompanyAdrs2) {
		this.sCompanyAdrs2 = sCompanyAdrs2;
	}

	/**
	 * @return the sCompanyAdrs3
	 */
	public String getsCompanyAdrs3() {
		return sCompanyAdrs3;
	}

	/**
	 * @param sCompanyAdrs3 the sCompanyAdrs3 to set
	 */
	public void setsCompanyAdrs3(final String sCompanyAdrs3) {
		this.sCompanyAdrs3 = sCompanyAdrs3;
	}

	/**
	 * @return the sCompanyAdrsAdd
	 */
	public String getsCompanyAdrsAdd() {
		return sCompanyAdrsAdd;
	}

	/**
	 * @param sCompanyAdrsAdd the sCompanyAdrsAdd to set
	 */
	public void setsCompanyAdrsAdd(final String sCompanyAdrsAdd) {
		this.sCompanyAdrsAdd = sCompanyAdrsAdd;
	}

	/**
	 * @return the sSendAdrsType
	 */
	public String getsSendAdrsType() {
		return sSendAdrsType;
	}

	/**
	 * @param sSendAdrsType the sSendAdrsType to set
	 */
	public void setsSendAdrsType(final String sSendAdrsType) {
		this.sSendAdrsType = sSendAdrsType;
	}

	/**
	 * @return the sInsrdID1
	 */
	public String getsInsrdID1() {
		return sInsrdID1;
	}

	/**
	 * @param sInsrdID1 the sInsrdID1 to set
	 */
	public void setsInsrdID1(String sInsrdID1) {
		this.sInsrdID1 = sInsrdID1;
	}

	/**
	 * @return the sInsrdID2
	 */
	public String getsInsrdID2() {
		return sInsrdID2;
	}

	/**
	 * @param sInsrdID2 the sInsrdID2 to set
	 */
	public void setsInsrdID2(String sInsrdID2) {
		this.sInsrdID2 = sInsrdID2;
	}

	/**
	 * @return the hid_key_data
	 */
	public String getHid_key_data() {
		return hid_key_data;
	}

	/**
	 * @param hid_key_data the hid_key_data to set
	 */
	public void setHid_key_data(String hid_key_data) {
		this.hid_key_data = hid_key_data;
	}

	/**
	 * @return the sCompanyAddrMgtNo
	 */
	public String getsCompanyAddrMgtNo() {
		return sCompanyAddrMgtNo;
	}

	/**
	 * @param sCompanyAddrMgtNo the sCompanyAddrMgtNo to set
	 */
	public void setsCompanyAddrMgtNo(String sCompanyAddrMgtNo) {
		this.sCompanyAddrMgtNo = sCompanyAddrMgtNo;
	}
	
}
