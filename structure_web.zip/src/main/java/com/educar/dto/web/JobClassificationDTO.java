/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ���� ��,��,�� �з� DTO
 * ���� DB : code..CODAA13
 * <pre>
 * @author ��â��
 *
 */
@XmlRootElement(name = "jobClassificationDTO")
public class JobClassificationDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** key ��ȣ  */
	private String key;
	/** ���� �̸� */
	private String value;
	/** ���� ���� sJobClass */
	private String sJobClass;
	/** ���� ���� sDriveClass */
	private String sDriveClass;
	/** ���� ���� sDriveClass */
	private String sStdDate;

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(final String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(final String value) {
		this.value = value;
	}

	/**
	 * @return the sJobClass
	 */
	public String getsJobClass() {
		return sJobClass;
	}

	/**
	 * @param sJobClass the sJobClass to set
	 */
	public void setsJobClass(final String sJobClass) {
		this.sJobClass = sJobClass;
	}

	/**
	 * @return the sDriveClass
	 */
	public String getsDriveClass() {
		return sDriveClass;
	}

	/**
	 * @param sDriveClass the sDriveClass to set
	 */
	public void setsDriveClass(final String sDriveClass) {
		this.sDriveClass = sDriveClass;
	}

	/**
	 * @return the sStdDate
	 */
	public String getsStdDate() {
		return sStdDate;
	}

	/**
	 * @param sStdDate the sStdDate to set
	 */
	public void setsStdDate(String sStdDate) {
		this.sStdDate = sStdDate;
	}
}
