/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ī ������ ���� ����� ���� ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfEducarInsuranceSearchResultDTO")
public class PriceCalculationOfEducarInsuranceSearchResultDTO {
	/** �Ѻ���� : nBasePrm **/
	private List<PriceCalculationOfEducarInsuranceDTO> sum_prm;
	/** �г������ : bun_nab_prm **/
	private List<PriceCalculationOfEducarInsuranceDTO> bun_nab_prm;
	/** �㺸���Աݾ� : sHanAmt(�ѱ۰��Աݾ�), �㺸�� : sCovNam, �㺸�ڵ� : sCovCod **/
	private List<PriceCalculationOfEducarInsuranceDTO> covge;
	/** �㺸����� : nApplyPrm(���뺸���(�㺸�� �����)), �㺸��: sCovNam, �㺸�ڵ� : sCovCod **/
	private List<PriceCalculationOfEducarInsuranceDTO> coverPrm;

	/**
	 * @return the sum_prm
	 */
	public List<PriceCalculationOfEducarInsuranceDTO> getSum_prm() {
		return sum_prm;
	}

	/**
	 * @param sum_prm the sum_prm to set
	 */
	public void setSum_prm(final List<PriceCalculationOfEducarInsuranceDTO> sum_prm) {
		this.sum_prm = sum_prm;
	}

	/**
	 * @return the bun_nab_prm
	 */
	public List<PriceCalculationOfEducarInsuranceDTO> getBun_nab_prm() {
		return bun_nab_prm;
	}

	/**
	 * @param bun_nab_prm the bun_nab_prm to set
	 */
	public void setBun_nab_prm(final List<PriceCalculationOfEducarInsuranceDTO> bun_nab_prm) {
		this.bun_nab_prm = bun_nab_prm;
	}

	/**
	 * @return the covge
	 */
	public List<PriceCalculationOfEducarInsuranceDTO> getCovge() {
		return covge;
	}

	/**
	 * @param covge the covge to set
	 */
	public void setCovge(final List<PriceCalculationOfEducarInsuranceDTO> covge) {
		this.covge = covge;
	}

	/**
	 * @return the coverPrm
	 */
	public List<PriceCalculationOfEducarInsuranceDTO> getCoverPrm() {
		return coverPrm;
	}

	/**
	 * @param coverPrm the coverPrm to set
	 */
	public void setCoverPrm(final List<PriceCalculationOfEducarInsuranceDTO> coverPrm) {
		this.coverPrm = coverPrm;
	}

}
