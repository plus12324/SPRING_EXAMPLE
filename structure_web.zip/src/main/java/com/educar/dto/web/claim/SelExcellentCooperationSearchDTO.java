/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��������ü��ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "selExcellentCooperationSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SelExcellentCooperationSearchDTO {
	/** ��/�� **/
	private String sCityName;
	/** ��/�� **/
	private String sCountyName;
	/** ��ü�� **/
	private String sCompanyKorName;
	/** ������ ��ȣ **/
	private String pageIndex;

	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}

	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(final String sCityName) {
		this.sCityName = sCityName;
	}

	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}

	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(final String sCountyName) {
		this.sCountyName = sCountyName;
	}

	/**
	 * @return the sCompanyKorName
	 */
	public String getsCompanyKorName() {
		return sCompanyKorName;
	}

	/**
	 * @param sCompanyKorName the sCompanyKorName to set
	 */
	public void setsCompanyKorName(final String sCompanyKorName) {
		this.sCompanyKorName = sCompanyKorName;
	}

	/**
	 * @return the pageIndex
	 */
	public String getPageIndex() {
		return pageIndex;
	}

	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(final String pageIndex) {
		this.pageIndex = pageIndex;
	}

}
