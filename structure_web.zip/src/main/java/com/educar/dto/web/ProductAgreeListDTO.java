package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������� �̿�(����) ��ȸ
 * 
 * @author �Ž¿�
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "productAgreeListDTO")
public class ProductAgreeListDTO {
	
	/** ��� **/
	private String result;
	
	/** �������� **/
	private String sAgmDt;

	/** �������� **/
	private String sExpireDate;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getsAgmDt() {
		return sAgmDt;
	}

	public void setsAgmDt(String sAgmDt) {
		this.sAgmDt = sAgmDt;
	}

	public String getsExpireDate() {
		return sExpireDate;
	}

	public void setsExpireDate(String sExpireDate) {
		this.sExpireDate = sExpireDate;
	}

}
