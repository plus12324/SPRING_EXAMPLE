/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

/**
 * PG TX ���� ȣ�� �� ������� �Ⱓ�迡 �����ϴ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
public class DirectTransferUpdateDTO {

	/** ��û���� **/
	private String sReqDate;
	/** �����Ϸù�ȣ **/
	private String sSerialNo;
	/** ������� **/
	private String sPGRcvDate;
	/** ��ݽð� **/
	private String sPGRcvTime;
	/** ��������ڵ� **/
	private String sOutRspCode;
	/** ��������ڵ� **/
	private String sOutBankCode;
	/** ��ݰ��¹�ȣ **/
	private String sOutAcctNo;

	/**
	 * @return the sReqDate
	 */
	public String getsReqDate() {
		return sReqDate;
	}

	/**
	 * @param sReqDate the sReqDate to set
	 */
	public void setsReqDate(final String sReqDate) {
		this.sReqDate = sReqDate;
	}

	/**
	 * @return the sSerialNo
	 */
	public String getsSerialNo() {
		return sSerialNo;
	}

	/**
	 * @param sSerialNo the sSerialNo to set
	 */
	public void setsSerialNo(final String sSerialNo) {
		this.sSerialNo = sSerialNo;
	}

	/**
	 * @return the sPGRcvDate
	 */
	public String getsPGRcvDate() {
		return sPGRcvDate;
	}

	/**
	 * @param sPGRcvDate the sPGRcvDate to set
	 */
	public void setsPGRcvDate(final String sPGRcvDate) {
		this.sPGRcvDate = sPGRcvDate;
	}

	/**
	 * @return the sPGRcvTime
	 */
	public String getsPGRcvTime() {
		return sPGRcvTime;
	}

	/**
	 * @param sPGRcvTime the sPGRcvTime to set
	 */
	public void setsPGRcvTime(final String sPGRcvTime) {
		this.sPGRcvTime = sPGRcvTime;
	}

	/**
	 * @return the sOutRspCode
	 */
	public String getsOutRspCode() {
		return sOutRspCode;
	}

	/**
	 * @param sOutRspCode the sOutRspCode to set
	 */
	public void setsOutRspCode(final String sOutRspCode) {
		this.sOutRspCode = sOutRspCode;
	}

	/**
	 * @return the sOutBankCode
	 */
	public String getsOutBankCode() {
		return sOutBankCode;
	}

	/**
	 * @param sOutBankCode the sOutBankCode to set
	 */
	public void setsOutBankCode(final String sOutBankCode) {
		this.sOutBankCode = sOutBankCode;
	}

	/**
	 * @return the sOutAcctNo
	 */
	public String getsOutAcctNo() {
		return sOutAcctNo;
	}

	/**
	 * @param sOutAcctNo the sOutAcctNo to set
	 */
	public void setsOutAcctNo(final String sOutAcctNo) {
		this.sOutAcctNo = sOutAcctNo;
	}

	/**
	 * @return the nOutAmt
	 */
	public String getnOutAmt() {
		return nOutAmt;
	}

	/**
	 * @param nOutAmt the nOutAmt to set
	 */
	public void setnOutAmt(final String nOutAmt) {
		this.nOutAmt = nOutAmt;
	}

	/**
	 * @return the sDepositorID
	 */
	public String getsDepositorID() {
		return sDepositorID;
	}

	/**
	 * @param sDepositorID the sDepositorID to set
	 */
	public void setsDepositorID(final String sDepositorID) {
		this.sDepositorID = sDepositorID;
	}

	/**
	 * @return the nOutFee
	 */
	public String getnOutFee() {
		return nOutFee;
	}

	/**
	 * @param nOutFee the nOutFee to set
	 */
	public void setnOutFee(final String nOutFee) {
		this.nOutFee = nOutFee;
	}

	/**
	 * @return the nRealInAmt
	 */
	public String getnRealInAmt() {
		return nRealInAmt;
	}

	/**
	 * @param nRealInAmt the nRealInAmt to set
	 */
	public void setnRealInAmt(final String nRealInAmt) {
		this.nRealInAmt = nRealInAmt;
	}

	/**
	 * @return the sInPlanDate
	 */
	public String getsInPlanDate() {
		return sInPlanDate;
	}

	/**
	 * @param sInPlanDate the sInPlanDate to set
	 */
	public void setsInPlanDate(final String sInPlanDate) {
		this.sInPlanDate = sInPlanDate;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/** ��ݱݾ� **/
	private String nOutAmt;
	/** ������ID **/
	private String sDepositorID;
	/** ��ݼ����� **/
	private String nOutFee;
	/** ���Աݾ� **/
	private String nRealInAmt;
	/** �Աݿ����� **/
	private String sInPlanDate;
	/** �����ID **/
	private String sUserID;

}
