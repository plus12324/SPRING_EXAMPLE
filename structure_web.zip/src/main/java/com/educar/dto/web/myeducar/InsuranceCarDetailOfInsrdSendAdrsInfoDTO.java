/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (�Ǻ����� �߼��� �ּ�)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfInsrdSendAdrsInfoDTO")
public class InsuranceCarDetailOfInsrdSendAdrsInfoDTO {
	/** �Ǻ�����ID **/
	private String sCustNo;
	/** �Ǻ�����ID_���� **/
	private String nSeqNo;
	/** �ּұ��� **/
	private String sAdrsType;
	/** �ּ�ȸ�� **/
	private String nChangeNo;
	/** ������ȣ1 **/
	private String sZip1;
	/** ������ȣ2 **/
	private String sZip2;
	/** �ּ�1 **/
	private String sAdrs1;
	/** �ּ�2 **/
	private String sAdrs2;
	/** �ּ�3 **/
	private String sAdrs3;
	/** ���� **/
	private String sAdrsAdd;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}

	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(final String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}

	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}

	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(final String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}

	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}

	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(final String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}

	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(final String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}

}
