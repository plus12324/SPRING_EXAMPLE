/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

import org.joda.time.DateTime;

/**
 * ������ ��ȸ�� ���Ǵ� BANK005 hashkey�� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
public class AccountQueryBANKDTO {

	/** �����ڵ� **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 3, required = true)
	private String sBankCode;
	/** ���������ڵ� **/
	private String sJunmunCode;
	/** ���������ڵ� **/
	private String sDealType;
	/** �������� **/
	private String sSendDate;
	/** ���۽ð� **/
	private String sSendTime;
	/** �ŷ����� **/
	private String sDealDate;
	/** �ŷ������ڵ� **/
	private String sDealBankCode;
	/** �ֹ�/����ڹ�ȣ **/
	private String sBankOwnerID;
	/** �ŷ����¹�ȣ **/
	private String sDealAcctNo;
	/** �Ⱓ�� ������ insert **/
	private String sRowType;

	/**
	 * default constructor
	 * �Ⱓ�� ��������, �ð����� �������ش�
	 */
	public AccountQueryBANKDTO() {
		this.setsSendDate(DateTime.now().toString("yyyyMMdd"));
		this.setsSendTime(DateTime.now().toString("HHmmss"));
		this.setsDealDate(DateTime.now().toString("yyyyMMdd"));
		this.setsRowType("insert");
		this.setsJunmunCode("0600");
		this.setsDealType("600");
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @return the sJunmunCode
	 */
	public String getsJunmunCode() {
		return sJunmunCode;
	}

	/**
	 * @return the sDealType
	 */
	public String getsDealType() {
		return sDealType;
	}

	/**
	 * @return the sSendDate
	 */
	public String getsSendDate() {
		return sSendDate;
	}

	/**
	 * @return the sSendTime
	 */
	public String getsSendTime() {
		return sSendTime;
	}

	/**
	 * @return the sDealDate
	 */
	public String getsDealDate() {
		return sDealDate;
	}

	/**
	 * @return the sDealBankCode
	 */
	public String getsDealBankCode() {
		return sDealBankCode;
	}

	/**
	 * @return the sBankOwnerID
	 */
	public String getsBankOwnerID() {
		return sBankOwnerID;
	}

	/**
	 * @return the sDealAcctNo
	 */
	public String getsDealAcctNo() {
		return sDealAcctNo;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @param sJunmunCode the sJunmunCode to set
	 */
	public void setsJunmunCode(final String sJunmunCode) {
		this.sJunmunCode = sJunmunCode;
	}

	/**
	 * @param sDealType the sDealType to set
	 */
	public void setsDealType(final String sDealType) {
		this.sDealType = sDealType;
	}

	/**
	 * @param sSendDate the sSendDate to set
	 */
	public void setsSendDate(final String sSendDate) {
		this.sSendDate = sSendDate;
	}

	/**
	 * @param sSendTime the sSendTime to set
	 */
	public void setsSendTime(final String sSendTime) {
		this.sSendTime = sSendTime;
	}

	/**
	 * @param sDealDate the sDealDate to set
	 */
	public void setsDealDate(final String sDealDate) {
		this.sDealDate = sDealDate;
	}

	/**
	 * @param sDealBankCode the sDealBankCode to set
	 */
	public void setsDealBankCode(final String sDealBankCode) {
		this.sDealBankCode = sDealBankCode;
	}

	/**
	 * @param sBankOwnerID the sBankOwnerID to set
	 */
	public void setsBankOwnerID(final String sBankOwnerID) {
		this.sBankOwnerID = sBankOwnerID;
	}

	/**
	 * @param sDealAcctNo the sDealAcctNo to set
	 */
	public void setsDealAcctNo(final String sDealAcctNo) {
		this.sDealAcctNo = sDealAcctNo;
	}

	/**
	 * @return the sRowType
	 */
	public String getsRowType() {
		return sRowType;
	}

	/**
	 * @param sRowType the sRowType to set
	 */
	public void setsRowType(final String sRowType) {
		this.sRowType = sRowType;
	}

}
