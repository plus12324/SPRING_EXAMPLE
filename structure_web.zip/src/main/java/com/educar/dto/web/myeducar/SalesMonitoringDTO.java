/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "salesMonitoringDTO")
public class SalesMonitoringDTO {
	/** ����ȣ1 **/
	private String sPolicyType;
	/** ����ȣ2**/
	private String 	sPolicyYM;
	/** ����ȣ3**/
	private String 	sPolicySer;
	/** ��������	**/
	private String sCustType;
	/** ����͸����	**/
	private String sEmpNo;
	/** �亯1	**/
	private String sA1;
	/** �亯2	**/
	private String sA2;
	/** �亯3	**/
	private String sA3;
	/** �亯4	**/
	private String sA4;
	/** �亯5	**/
	private String sA5;
	/** �亯6	**/
	private String sA6;
	/** �亯7	**/
	private String sA7;
	/** �亯8	**/
	private String sA8;
	/** �亯9	**/
	private String sA9;
	/** �亯10	**/
	private String sA10;
	/** �亯11	**/
	private String sA11;
	/** �亯12	**/
	private String sA12;
	/** �亯13	**/
	private String sA13;
	/** �亯14	**/
	private String sA14;
	/** �亯15	**/
	private String sA15;
	/** �亯16	**/
	private String sA16;
	/** �亯17	**/
	private String sA17;
	/** �亯18	**/
	private String sA18;
	/** �亯19	**/
	private String sA19;
	/** �亯20	**/
	private String sA20;
	/** �亯21	**/
	private String sA21;
	/** �亯22	**/
	private String sA22;
	/** �亯23	**/
	private String sA23;
	/** �亯24	**/
	private String sA24;
	/** �亯25	**/
	private String sA25;
	/** �亯26	**/
	private String sA26;
	/** �亯27	**/
	private String sA27;
	/** �亯28	**/
	private String sA28;
	/** �亯29	**/
	private String sA29;
	/** �亯30	**/
	private String sA30;
	/** �亯31	**/
	private String sA31;
	/** �亯32	**/
	private String sA32;
	/** �亯33	**/
	private String sA33;
	/** �亯99	**/
	private String sA99;
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}
	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}
	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}
	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}
	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}
	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}
	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}
	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(String sCustType) {
		this.sCustType = sCustType;
	}
	/**
	 * @return the sEmpNo
	 */
	public String getsEmpNo() {
		return sEmpNo;
	}
	/**
	 * @param sEmpNo the sEmpNo to set
	 */
	public void setsEmpNo(String sEmpNo) {
		this.sEmpNo = sEmpNo;
	}
	/**
	 * @return the sA1
	 */
	public String getsA1() {
		return sA1;
	}
	/**
	 * @param sA1 the sA1 to set
	 */
	public void setsA1(String sA1) {
		this.sA1 = sA1;
	}
	/**
	 * @return the sA2
	 */
	public String getsA2() {
		return sA2;
	}
	/**
	 * @param sA2 the sA2 to set
	 */
	public void setsA2(String sA2) {
		this.sA2 = sA2;
	}
	/**
	 * @return the sA3
	 */
	public String getsA3() {
		return sA3;
	}
	/**
	 * @param sA3 the sA3 to set
	 */
	public void setsA3(String sA3) {
		this.sA3 = sA3;
	}
	/**
	 * @return the sA4
	 */
	public String getsA4() {
		return sA4;
	}
	/**
	 * @param sA4 the sA4 to set
	 */
	public void setsA4(String sA4) {
		this.sA4 = sA4;
	}
	/**
	 * @return the sA5
	 */
	public String getsA5() {
		return sA5;
	}
	/**
	 * @param sA5 the sA5 to set
	 */
	public void setsA5(String sA5) {
		this.sA5 = sA5;
	}
	/**
	 * @return the sA6
	 */
	public String getsA6() {
		return sA6;
	}
	/**
	 * @param sA6 the sA6 to set
	 */
	public void setsA6(String sA6) {
		this.sA6 = sA6;
	}
	/**
	 * @return the sA7
	 */
	public String getsA7() {
		return sA7;
	}
	/**
	 * @param sA7 the sA7 to set
	 */
	public void setsA7(String sA7) {
		this.sA7 = sA7;
	}
	/**
	 * @return the sA8
	 */
	public String getsA8() {
		return sA8;
	}
	/**
	 * @param sA8 the sA8 to set
	 */
	public void setsA8(String sA8) {
		this.sA8 = sA8;
	}
	/**
	 * @return the sA9
	 */
	public String getsA9() {
		return sA9;
	}
	/**
	 * @param sA9 the sA9 to set
	 */
	public void setsA9(String sA9) {
		this.sA9 = sA9;
	}
	/**
	 * @return the sA10
	 */
	public String getsA10() {
		return sA10;
	}
	/**
	 * @param sA10 the sA10 to set
	 */
	public void setsA10(String sA10) {
		this.sA10 = sA10;
	}
	/**
	 * @return the sA11
	 */
	public String getsA11() {
		return sA11;
	}
	/**
	 * @param sA11 the sA11 to set
	 */
	public void setsA11(String sA11) {
		this.sA11 = sA11;
	}
	/**
	 * @return the sA12
	 */
	public String getsA12() {
		return sA12;
	}
	/**
	 * @param sA12 the sA12 to set
	 */
	public void setsA12(String sA12) {
		this.sA12 = sA12;
	}
	/**
	 * @return the sA13
	 */
	public String getsA13() {
		return sA13;
	}
	/**
	 * @param sA13 the sA13 to set
	 */
	public void setsA13(String sA13) {
		this.sA13 = sA13;
	}
	/**
	 * @return the sA14
	 */
	public String getsA14() {
		return sA14;
	}
	/**
	 * @param sA14 the sA14 to set
	 */
	public void setsA14(String sA14) {
		this.sA14 = sA14;
	}
	/**
	 * @return the sA15
	 */
	public String getsA15() {
		return sA15;
	}
	/**
	 * @param sA15 the sA15 to set
	 */
	public void setsA15(String sA15) {
		this.sA15 = sA15;
	}
	/**
	 * @return the sA16
	 */
	public String getsA16() {
		return sA16;
	}
	/**
	 * @param sA16 the sA16 to set
	 */
	public void setsA16(String sA16) {
		this.sA16 = sA16;
	}
	/**
	 * @return the sA17
	 */
	public String getsA17() {
		return sA17;
	}
	/**
	 * @param sA17 the sA17 to set
	 */
	public void setsA17(String sA17) {
		this.sA17 = sA17;
	}
	/**
	 * @return the sA18
	 */
	public String getsA18() {
		return sA18;
	}
	/**
	 * @param sA18 the sA18 to set
	 */
	public void setsA18(String sA18) {
		this.sA18 = sA18;
	}
	/**
	 * @return the sA19
	 */
	public String getsA19() {
		return sA19;
	}
	/**
	 * @param sA19 the sA19 to set
	 */
	public void setsA19(String sA19) {
		this.sA19 = sA19;
	}
	/**
	 * @return the sA20
	 */
	public String getsA20() {
		return sA20;
	}
	/**
	 * @param sA20 the sA20 to set
	 */
	public void setsA20(String sA20) {
		this.sA20 = sA20;
	}
	/**
	 * @return the sA21
	 */
	public String getsA21() {
		return sA21;
	}
	/**
	 * @param sA21 the sA21 to set
	 */
	public void setsA21(String sA21) {
		this.sA21 = sA21;
	}
	/**
	 * @return the sA22
	 */
	public String getsA22() {
		return sA22;
	}
	/**
	 * @param sA22 the sA22 to set
	 */
	public void setsA22(String sA22) {
		this.sA22 = sA22;
	}
	/**
	 * @return the sA23
	 */
	public String getsA23() {
		return sA23;
	}
	/**
	 * @param sA23 the sA23 to set
	 */
	public void setsA23(String sA23) {
		this.sA23 = sA23;
	}
	/**
	 * @return the sA24
	 */
	public String getsA24() {
		return sA24;
	}
	/**
	 * @param sA24 the sA24 to set
	 */
	public void setsA24(String sA24) {
		this.sA24 = sA24;
	}
	/**
	 * @return the sA25
	 */
	public String getsA25() {
		return sA25;
	}
	/**
	 * @param sA25 the sA25 to set
	 */
	public void setsA25(String sA25) {
		this.sA25 = sA25;
	}
	/**
	 * @return the sA26
	 */
	public String getsA26() {
		return sA26;
	}
	/**
	 * @param sA26 the sA26 to set
	 */
	public void setsA26(String sA26) {
		this.sA26 = sA26;
	}
	/**
	 * @return the sA27
	 */
	public String getsA27() {
		return sA27;
	}
	/**
	 * @param sA27 the sA27 to set
	 */
	public void setsA27(String sA27) {
		this.sA27 = sA27;
	}
	/**
	 * @return the sA28
	 */
	public String getsA28() {
		return sA28;
	}
	/**
	 * @param sA28 the sA28 to set
	 */
	public void setsA28(String sA28) {
		this.sA28 = sA28;
	}
	/**
	 * @return the sA29
	 */
	public String getsA29() {
		return sA29;
	}
	/**
	 * @param sA29 the sA29 to set
	 */
	public void setsA29(String sA29) {
		this.sA29 = sA29;
	}
	/**
	 * @return the sA30
	 */
	public String getsA30() {
		return sA30;
	}
	/**
	 * @param sA30 the sA30 to set
	 */
	public void setsA30(String sA30) {
		this.sA30 = sA30;
	}
	/**
	 * @return the sA31
	 */
	public String getsA31() {
		return sA31;
	}
	/**
	 * @param sA31 the sA31 to set
	 */
	public void setsA31(String sA31) {
		this.sA31 = sA31;
	}
	/**
	 * @return the sA32
	 */
	public String getsA32() {
		return sA32;
	}
	/**
	 * @param sA32 the sA32 to set
	 */
	public void setsA32(String sA32) {
		this.sA32 = sA32;
	}
	/**
	 * @return the sA33
	 */
	public String getsA33() {
		return sA33;
	}
	/**
	 * @param sA33 the sA33 to set
	 */
	public void setsA33(String sA33) {
		this.sA33 = sA33;
	}
	/**
	 * @return the sA99
	 */
	public String getsA99() {
		return sA99;
	}
	/**
	 * @param sA99 the sA99 to set
	 */
	public void setsA99(String sA99) {
		this.sA99 = sA99;
	}
	
}
