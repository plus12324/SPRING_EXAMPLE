/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *  �輭 �㺸 ���� ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorseModifyPawnResultDTO")
public class EndorseModifyPawnResultDTO {
	/** �����ڵ� **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** û����� **/
	private String sApplyStat;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** ����1 **/
	private String sBefCover0101;
	/** ����2 **/
	private String sBefCover0102;
	/** �빰 **/
	private String sBefCover0103;
	/** �ڼ� **/
	private String sBefCover0201;
	/** (�ڼ�)�λ󰡾� **/
	private String sBefCover0203;
	/** �ڵ������� **/
	private String sBefCover0202;
	/** (�ڻ�)�λ󰡾� **/
	private String sBefCover0204;
	/** ������ **/
	private String sBefCover0301;
	/** ���� **/
	private String sBefCover0401;
	/** �ڱ�δ�� **/
	private String sBefCover0404_RATE;
	/** �ڱ�δ�� **/
	private String sBefCover0404;
	/** ���߱���� **/
	private String sBefCover0403;
	/** ����⵿1 **/
	private String sBefCover0501;
	/** ����⵿2 **/
	private String sBefCover0523;
	/** ����1 **/
	private String sBefCoverPrem0101;
	/** ����2 **/
	private String sBefCoverPrem0102;
	/** �빰 **/
	private String sBefCoverPrem0103;
	/** �ڼ� **/
	private String sBefCoverPrem0201;
	/** �ڵ������� **/
	private String sBefCoverPrem0202;
	/** ������ **/
	private String sBefCoverPrem0301;
	/** ���� **/
	private String sBefCoverPrem0401;
	/** ����⵿1 **/
	private String sBefCoverPrem0501;
	/** ����⵿2 **/
	private String sBefCoverPrem0523;
	/** �Ѱ� **/
	private String nBefTotalPrem;
	/** ����1 **/
	private String sAftCover0101;
	/** ����2 **/
	private String sAftCover0102;
	/** �빰 **/
	private String sAftCover0103;
	/** �ڼ� **/
	private String sAftCover0201;
	/** (�ڼ�)�λ󰡾� **/
	private String sAftCover0203;
	/** �ڵ������� **/
	private String sAftCover0202;
	/** (�ڻ�)�λ󰡾� **/
	private String sAftCover0204;
	/** ������ **/
	private String sAftCover0301;
	/** ���� **/
	private String sAftCover0401;
	/** �ڱ�δ�� **/
	private String sAftCover0404_RATE;
	/** �ڱ�δ�� **/
	private String sAftCover0404;
	/** ���߱���� **/
	private String sAftCover0403;
	/** ����⵿1 **/
	private String sAftCover0501;
	/** ����⵿2 **/
	private String sAftCover0523;
	/** ����1 **/
	private String sAftCoverPrem0101;
	/** ����2 **/
	private String sAftCoverPrem0102;
	/** �빰 **/
	private String sAftCoverPrem0103;
	/** �ڼ� **/
	private String sAftCoverPrem0201;
	/** �ڵ������� **/
	private String sAftCoverPrem0202;
	/** ������ **/
	private String sAftCoverPrem0301;
	/** ���� **/
	private String sAftCoverPrem0401;
	/** ����⵿1 **/
	private String sAftCoverPrem0501;
	/** ����⵿2 **/
	private String sAftCoverPrem0523;
	/** �Ѱ� **/
	private String nAftTotalPrem;
	/** ���������     **/
	private String befTotPrem;
	/** �߰����κ���� **/
	private String befAddPrem;
	/** ȯ�޺����     **/
	private String befRefundPrem;
	/** ���������     **/
	private String aftTotPrem;
	/** �߰����κ���� **/
	private String aftAddPrem;
	/** ȯ�޺����     **/
	private String aftRefundPrem;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sApplyStat
	 */
	public String getsApplyStat() {
		return sApplyStat;
	}

	/**
	 * @param sApplyStat the sApplyStat to set
	 */
	public void setsApplyStat(final String sApplyStat) {
		this.sApplyStat = sApplyStat;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @return the sBefCover0101
	 */
	public String getsBefCover0101() {
		return sBefCover0101;
	}

	/**
	 * @param sBefCover0101 the sBefCover0101 to set
	 */
	public void setsBefCover0101(final String sBefCover0101) {
		this.sBefCover0101 = sBefCover0101;
	}

	/**
	 * @return the sBefCover0102
	 */
	public String getsBefCover0102() {
		return sBefCover0102;
	}

	/**
	 * @param sBefCover0102 the sBefCover0102 to set
	 */
	public void setsBefCover0102(final String sBefCover0102) {
		this.sBefCover0102 = sBefCover0102;
	}

	/**
	 * @return the sBefCover0103
	 */
	public String getsBefCover0103() {
		return sBefCover0103;
	}

	/**
	 * @param sBefCover0103 the sBefCover0103 to set
	 */
	public void setsBefCover0103(final String sBefCover0103) {
		this.sBefCover0103 = sBefCover0103;
	}

	/**
	 * @return the sBefCover0201
	 */
	public String getsBefCover0201() {
		return sBefCover0201;
	}

	/**
	 * @param sBefCover0201 the sBefCover0201 to set
	 */
	public void setsBefCover0201(final String sBefCover0201) {
		this.sBefCover0201 = sBefCover0201;
	}

	/**
	 * @return the sBefCover0203
	 */
	public String getsBefCover0203() {
		return sBefCover0203;
	}

	/**
	 * @param sBefCover0203 the sBefCover0203 to set
	 */
	public void setsBefCover0203(final String sBefCover0203) {
		this.sBefCover0203 = sBefCover0203;
	}

	/**
	 * @return the sBefCover0202
	 */
	public String getsBefCover0202() {
		return sBefCover0202;
	}

	/**
	 * @param sBefCover0202 the sBefCover0202 to set
	 */
	public void setsBefCover0202(final String sBefCover0202) {
		this.sBefCover0202 = sBefCover0202;
	}

	/**
	 * @return the sBefCover0204
	 */
	public String getsBefCover0204() {
		return sBefCover0204;
	}

	/**
	 * @param sBefCover0204 the sBefCover0204 to set
	 */
	public void setsBefCover0204(final String sBefCover0204) {
		this.sBefCover0204 = sBefCover0204;
	}

	/**
	 * @return the sBefCover0301
	 */
	public String getsBefCover0301() {
		return sBefCover0301;
	}

	/**
	 * @param sBefCover0301 the sBefCover0301 to set
	 */
	public void setsBefCover0301(final String sBefCover0301) {
		this.sBefCover0301 = sBefCover0301;
	}

	/**
	 * @return the sBefCover0401
	 */
	public String getsBefCover0401() {
		return sBefCover0401;
	}

	/**
	 * @param sBefCover0401 the sBefCover0401 to set
	 */
	public void setsBefCover0401(final String sBefCover0401) {
		this.sBefCover0401 = sBefCover0401;
	}

	/**
	 * @return the sBefCover0404_RATE
	 */
	public String getsBefCover0404_RATE() {
		return sBefCover0404_RATE;
	}

	/**
	 * @param sBefCover0404_RATE the sBefCover0404_RATE to set
	 */
	public void setsBefCover0404_RATE(final String sBefCover0404_RATE) {
		this.sBefCover0404_RATE = sBefCover0404_RATE;
	}

	/**
	 * @return the sBefCover0404
	 */
	public String getsBefCover0404() {
		return sBefCover0404;
	}

	/**
	 * @param sBefCover0404 the sBefCover0404 to set
	 */
	public void setsBefCover0404(final String sBefCover0404) {
		this.sBefCover0404 = sBefCover0404;
	}

	/**
	 * @return the sBefCover0403
	 */
	public String getsBefCover0403() {
		return sBefCover0403;
	}

	/**
	 * @param sBefCover0403 the sBefCover0403 to set
	 */
	public void setsBefCover0403(final String sBefCover0403) {
		this.sBefCover0403 = sBefCover0403;
	}

	/**
	 * @return the sBefCover0501
	 */
	public String getsBefCover0501() {
		return sBefCover0501;
	}

	/**
	 * @param sBefCover0501 the sBefCover0501 to set
	 */
	public void setsBefCover0501(final String sBefCover0501) {
		this.sBefCover0501 = sBefCover0501;
	}

	/**
	 * @return the sBefCoverPrem0101
	 */
	public String getsBefCoverPrem0101() {
		return sBefCoverPrem0101;
	}

	/**
	 * @param sBefCoverPrem0101 the sBefCoverPrem0101 to set
	 */
	public void setsBefCoverPrem0101(final String sBefCoverPrem0101) {
		this.sBefCoverPrem0101 = sBefCoverPrem0101;
	}

	/**
	 * @return the sBefCoverPrem0102
	 */
	public String getsBefCoverPrem0102() {
		return sBefCoverPrem0102;
	}

	/**
	 * @param sBefCoverPrem0102 the sBefCoverPrem0102 to set
	 */
	public void setsBefCoverPrem0102(final String sBefCoverPrem0102) {
		this.sBefCoverPrem0102 = sBefCoverPrem0102;
	}

	/**
	 * @return the sBefCoverPrem0103
	 */
	public String getsBefCoverPrem0103() {
		return sBefCoverPrem0103;
	}

	/**
	 * @param sBefCoverPrem0103 the sBefCoverPrem0103 to set
	 */
	public void setsBefCoverPrem0103(final String sBefCoverPrem0103) {
		this.sBefCoverPrem0103 = sBefCoverPrem0103;
	}

	/**
	 * @return the sBefCoverPrem0201
	 */
	public String getsBefCoverPrem0201() {
		return sBefCoverPrem0201;
	}

	/**
	 * @param sBefCoverPrem0201 the sBefCoverPrem0201 to set
	 */
	public void setsBefCoverPrem0201(final String sBefCoverPrem0201) {
		this.sBefCoverPrem0201 = sBefCoverPrem0201;
	}

	/**
	 * @return the sBefCoverPrem0202
	 */
	public String getsBefCoverPrem0202() {
		return sBefCoverPrem0202;
	}

	/**
	 * @param sBefCoverPrem0202 the sBefCoverPrem0202 to set
	 */
	public void setsBefCoverPrem0202(final String sBefCoverPrem0202) {
		this.sBefCoverPrem0202 = sBefCoverPrem0202;
	}

	/**
	 * @return the sBefCoverPrem0301
	 */
	public String getsBefCoverPrem0301() {
		return sBefCoverPrem0301;
	}

	/**
	 * @param sBefCoverPrem0301 the sBefCoverPrem0301 to set
	 */
	public void setsBefCoverPrem0301(final String sBefCoverPrem0301) {
		this.sBefCoverPrem0301 = sBefCoverPrem0301;
	}

	/**
	 * @return the sBefCoverPrem0401
	 */
	public String getsBefCoverPrem0401() {
		return sBefCoverPrem0401;
	}

	/**
	 * @param sBefCoverPrem0401 the sBefCoverPrem0401 to set
	 */
	public void setsBefCoverPrem0401(final String sBefCoverPrem0401) {
		this.sBefCoverPrem0401 = sBefCoverPrem0401;
	}

	/**
	 * @return the sBefCoverPrem0501
	 */
	public String getsBefCoverPrem0501() {
		return sBefCoverPrem0501;
	}

	/**
	 * @param sBefCoverPrem0501 the sBefCoverPrem0501 to set
	 */
	public void setsBefCoverPrem0501(final String sBefCoverPrem0501) {
		this.sBefCoverPrem0501 = sBefCoverPrem0501;
	}

	/**
	 * @return the nBefTotalPrem
	 */
	public String getnBefTotalPrem() {
		return nBefTotalPrem;
	}

	/**
	 * @param nBefTotalPrem the nBefTotalPrem to set
	 */
	public void setnBefTotalPrem(final String nBefTotalPrem) {
		this.nBefTotalPrem = nBefTotalPrem;
	}

	/**
	 * @return the sAftCover0101
	 */
	public String getsAftCover0101() {
		return sAftCover0101;
	}

	/**
	 * @param sAftCover0101 the sAftCover0101 to set
	 */
	public void setsAftCover0101(final String sAftCover0101) {
		this.sAftCover0101 = sAftCover0101;
	}

	/**
	 * @return the sAftCover0102
	 */
	public String getsAftCover0102() {
		return sAftCover0102;
	}

	/**
	 * @param sAftCover0102 the sAftCover0102 to set
	 */
	public void setsAftCover0102(final String sAftCover0102) {
		this.sAftCover0102 = sAftCover0102;
	}

	/**
	 * @return the sAftCover0103
	 */
	public String getsAftCover0103() {
		return sAftCover0103;
	}

	/**
	 * @param sAftCover0103 the sAftCover0103 to set
	 */
	public void setsAftCover0103(final String sAftCover0103) {
		this.sAftCover0103 = sAftCover0103;
	}

	/**
	 * @return the sAftCover0201
	 */
	public String getsAftCover0201() {
		return sAftCover0201;
	}

	/**
	 * @param sAftCover0201 the sAftCover0201 to set
	 */
	public void setsAftCover0201(final String sAftCover0201) {
		this.sAftCover0201 = sAftCover0201;
	}

	/**
	 * @return the sAftCover0203
	 */
	public String getsAftCover0203() {
		return sAftCover0203;
	}

	/**
	 * @param sAftCover0203 the sAftCover0203 to set
	 */
	public void setsAftCover0203(final String sAftCover0203) {
		this.sAftCover0203 = sAftCover0203;
	}

	/**
	 * @return the sAftCover0202
	 */
	public String getsAftCover0202() {
		return sAftCover0202;
	}

	/**
	 * @param sAftCover0202 the sAftCover0202 to set
	 */
	public void setsAftCover0202(final String sAftCover0202) {
		this.sAftCover0202 = sAftCover0202;
	}

	/**
	 * @return the sAftCover0204
	 */
	public String getsAftCover0204() {
		return sAftCover0204;
	}

	/**
	 * @param sAftCover0204 the sAftCover0204 to set
	 */
	public void setsAftCover0204(final String sAftCover0204) {
		this.sAftCover0204 = sAftCover0204;
	}

	/**
	 * @return the sAftCover0301
	 */
	public String getsAftCover0301() {
		return sAftCover0301;
	}

	/**
	 * @param sAftCover0301 the sAftCover0301 to set
	 */
	public void setsAftCover0301(final String sAftCover0301) {
		this.sAftCover0301 = sAftCover0301;
	}

	/**
	 * @return the sAftCover0401
	 */
	public String getsAftCover0401() {
		return sAftCover0401;
	}

	/**
	 * @param sAftCover0401 the sAftCover0401 to set
	 */
	public void setsAftCover0401(final String sAftCover0401) {
		this.sAftCover0401 = sAftCover0401;
	}

	/**
	 * @return the sAftCover0404_RATE
	 */
	public String getsAftCover0404_RATE() {
		return sAftCover0404_RATE;
	}

	/**
	 * @param sAftCover0404_RATE the sAftCover0404_RATE to set
	 */
	public void setsAftCover0404_RATE(final String sAftCover0404_RATE) {
		this.sAftCover0404_RATE = sAftCover0404_RATE;
	}

	/**
	 * @return the sAftCover0404
	 */
	public String getsAftCover0404() {
		return sAftCover0404;
	}

	/**
	 * @param sAftCover0404 the sAftCover0404 to set
	 */
	public void setsAftCover0404(final String sAftCover0404) {
		this.sAftCover0404 = sAftCover0404;
	}

	/**
	 * @return the sAftCover0403
	 */
	public String getsAftCover0403() {
		return sAftCover0403;
	}

	/**
	 * @param sAftCover0403 the sAftCover0403 to set
	 */
	public void setsAftCover0403(final String sAftCover0403) {
		this.sAftCover0403 = sAftCover0403;
	}

	/**
	 * @return the sAftCover0501
	 */
	public String getsAftCover0501() {
		return sAftCover0501;
	}

	/**
	 * @param sAftCover0501 the sAftCover0501 to set
	 */
	public void setsAftCover0501(final String sAftCover0501) {
		this.sAftCover0501 = sAftCover0501;
	}

	/**
	 * @return the sAftCoverPrem0101
	 */
	public String getsAftCoverPrem0101() {
		return sAftCoverPrem0101;
	}

	/**
	 * @param sAftCoverPrem0101 the sAftCoverPrem0101 to set
	 */
	public void setsAftCoverPrem0101(final String sAftCoverPrem0101) {
		this.sAftCoverPrem0101 = sAftCoverPrem0101;
	}

	/**
	 * @return the sAftCoverPrem0102
	 */
	public String getsAftCoverPrem0102() {
		return sAftCoverPrem0102;
	}

	/**
	 * @param sAftCoverPrem0102 the sAftCoverPrem0102 to set
	 */
	public void setsAftCoverPrem0102(final String sAftCoverPrem0102) {
		this.sAftCoverPrem0102 = sAftCoverPrem0102;
	}

	/**
	 * @return the sAftCoverPrem0103
	 */
	public String getsAftCoverPrem0103() {
		return sAftCoverPrem0103;
	}

	/**
	 * @param sAftCoverPrem0103 the sAftCoverPrem0103 to set
	 */
	public void setsAftCoverPrem0103(final String sAftCoverPrem0103) {
		this.sAftCoverPrem0103 = sAftCoverPrem0103;
	}

	/**
	 * @return the sAftCoverPrem0201
	 */
	public String getsAftCoverPrem0201() {
		return sAftCoverPrem0201;
	}

	/**
	 * @param sAftCoverPrem0201 the sAftCoverPrem0201 to set
	 */
	public void setsAftCoverPrem0201(final String sAftCoverPrem0201) {
		this.sAftCoverPrem0201 = sAftCoverPrem0201;
	}

	/**
	 * @return the sAftCoverPrem0202
	 */
	public String getsAftCoverPrem0202() {
		return sAftCoverPrem0202;
	}

	/**
	 * @param sAftCoverPrem0202 the sAftCoverPrem0202 to set
	 */
	public void setsAftCoverPrem0202(final String sAftCoverPrem0202) {
		this.sAftCoverPrem0202 = sAftCoverPrem0202;
	}

	/**
	 * @return the sAftCoverPrem0301
	 */
	public String getsAftCoverPrem0301() {
		return sAftCoverPrem0301;
	}

	/**
	 * @param sAftCoverPrem0301 the sAftCoverPrem0301 to set
	 */
	public void setsAftCoverPrem0301(final String sAftCoverPrem0301) {
		this.sAftCoverPrem0301 = sAftCoverPrem0301;
	}

	/**
	 * @return the sAftCoverPrem0401
	 */
	public String getsAftCoverPrem0401() {
		return sAftCoverPrem0401;
	}

	/**
	 * @param sAftCoverPrem0401 the sAftCoverPrem0401 to set
	 */
	public void setsAftCoverPrem0401(final String sAftCoverPrem0401) {
		this.sAftCoverPrem0401 = sAftCoverPrem0401;
	}

	/**
	 * @return the sAftCoverPrem0501
	 */
	public String getsAftCoverPrem0501() {
		return sAftCoverPrem0501;
	}

	/**
	 * @param sAftCoverPrem0501 the sAftCoverPrem0501 to set
	 */
	public void setsAftCoverPrem0501(final String sAftCoverPrem0501) {
		this.sAftCoverPrem0501 = sAftCoverPrem0501;
	}

	/**
	 * @return the nAftTotalPrem
	 */
	public String getnAftTotalPrem() {
		return nAftTotalPrem;
	}

	/**
	 * @param sTotalPrem the sTotalPrem to set
	 */
	public void setnAftTotalPrem(final String nAftTotalPrem) {
		this.nAftTotalPrem = nAftTotalPrem;
	}

	/**
	 * @return the befTotPrem
	 */
	public String getBefTotPrem() {
		return befTotPrem;
	}

	/**
	 * @param befTotPrem the befTotPrem to set
	 */
	public void setBefTotPrem(final String befTotPrem) {
		this.befTotPrem = befTotPrem;
	}

	/**
	 * @return the befAddPrem
	 */
	public String getBefAddPrem() {
		return befAddPrem;
	}

	/**
	 * @param befAddPrem the befAddPrem to set
	 */
	public void setBefAddPrem(final String befAddPrem) {
		this.befAddPrem = befAddPrem;
	}

	/**
	 * @return the befRefundPrem
	 */
	public String getBefRefundPrem() {
		return befRefundPrem;
	}

	/**
	 * @param befRefundPrem the befRefundPrem to set
	 */
	public void setBefRefundPrem(final String befRefundPrem) {
		this.befRefundPrem = befRefundPrem;
	}

	/**
	 * @return the aftTotPrem
	 */
	public String getAftTotPrem() {
		return aftTotPrem;
	}

	/**
	 * @param aftTotPrem the aftTotPrem to set
	 */
	public void setAftTotPrem(final String aftTotPrem) {
		this.aftTotPrem = aftTotPrem;
	}

	/**
	 * @return the aftAddPrem
	 */
	public String getAftAddPrem() {
		return aftAddPrem;
	}

	/**
	 * @param aftAddPrem the aftAddPrem to set
	 */
	public void setAftAddPrem(final String aftAddPrem) {
		this.aftAddPrem = aftAddPrem;
	}

	/**
	 * @return the aftRefundPrem
	 */
	public String getAftRefundPrem() {
		return aftRefundPrem;
	}

	/**
	 * @param aftRefundPrem the aftRefundPrem to set
	 */
	public void setAftRefundPrem(final String aftRefundPrem) {
		this.aftRefundPrem = aftRefundPrem;
	}

	/**
	 * @return the sBefCover0523
	 */
	public String getsBefCover0523() {
		return sBefCover0523;
	}

	/**
	 * @param sBefCover0523 the sBefCover0523 to set
	 */
	public void setsBefCover0523(String sBefCover0523) {
		this.sBefCover0523 = sBefCover0523;
	}

	/**
	 * @return the sBefCoverPrem0523
	 */
	public String getsBefCoverPrem0523() {
		return sBefCoverPrem0523;
	}

	/**
	 * @param sBefCoverPrem0523 the sBefCoverPrem0523 to set
	 */
	public void setsBefCoverPrem0523(String sBefCoverPrem0523) {
		this.sBefCoverPrem0523 = sBefCoverPrem0523;
	}

	/**
	 * @return the sAftCover05231
	 */
	public String getsAftCover0523() {
		return sAftCover0523;
	}

	/**
	 * @param sAftCover05231 the sAftCover05231 to set
	 */
	public void setsAftCover0523(String sAftCover0523) {
		this.sAftCover0523 = sAftCover0523;
	}

	/**
	 * @return the sAftCoverPrem0523
	 */
	public String getsAftCoverPrem0523() {
		return sAftCoverPrem0523;
	}

	/**
	 * @param sAftCoverPrem0523 the sAftCoverPrem0523 to set
	 */
	public void setsAftCoverPrem0523(String sAftCoverPrem0523) {
		this.sAftCoverPrem0523 = sAftCoverPrem0523;
	}
	
}
