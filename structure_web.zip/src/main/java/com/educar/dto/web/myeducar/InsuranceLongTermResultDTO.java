/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceLongTermResultDTO")
public class InsuranceLongTermResultDTO {
	/** ����ȣ **/
	private String sCrNo;
	/** ��ǰ�ڵ� **/
	private String sGdCd;
	/** ��ǰ�� **/
	private String sGdNm;
	/** �����ڵ� **/
	private String sGnrzCd;
	/** �������ڵ� **/
	private String sCrStatCd;
	/** �����¸� **/
	private String sCrStatNm;
	/** �������Կ� **/
	private String sFinalPaymMthy;
	/** ���ñ� **/
	private String sInsurStrtdate;
	/** ������� **/
	private String sInsurEndDate;
	/** ������ڵ� **/
	private String sCrtorCd;
	/** ����ڸ� **/
	private String sCrtorName;
	/** �Ǻ������ڵ� **/
	private String sInrpsCd;
	/** �Ǻ����ڸ� **/
	private String sInrpsName;
	/** ���뺸��� **/
	private String nApplPrem;
	/** ����Ⱓ **/
	private String sInsurTerm;
	/** �ѳ��Ժ���� **/
	private String nTotPaymPrem;
	/** ����� **/
	private String sDoer;
	/** ����ڸ� **/
	private String sDoerNm;
	/** ����ڻ���� **/
	private String sDoerUser;
	/** ����ڻ���θ� **/
	private String sDoerUserName;
	/** û���ȣ **/
	private String sPlanNo;
	/** ����������� **/
	private String sRecvProgStat;
	/** ���δ�ü�����ڵ� **/
	private String sPsnGroupFlgcd;
	/** ��������ȸ�� **/
	private String nFinalPaymSeq;
	/** �����ֱ�� **/
	private String sPaymCyclCdNm;
	/** ���ԱⰣ�� **/
	private String sPaymTermCdNm;
	/** ���ſ��� **/
	private String sRenwlYn;
	/** �Ǻ����ڼ��� **/
	private String nInrpsSeqno;

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}

	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(final String sGdCd) {
		this.sGdCd = sGdCd;
	}

	/**
	 * @return the sGdNm
	 */
	public String getsGdNm() {
		return sGdNm;
	}

	/**
	 * @param sGdNm the sGdNm to set
	 */
	public void setsGdNm(final String sGdNm) {
		this.sGdNm = sGdNm;
	}

	/**
	 * @return the sGnrzCd
	 */
	public String getsGnrzCd() {
		return sGnrzCd;
	}

	/**
	 * @param sGnrzCd the sGnrzCd to set
	 */
	public void setsGnrzCd(final String sGnrzCd) {
		this.sGnrzCd = sGnrzCd;
	}

	/**
	 * @return the sCrStatCd
	 */
	public String getsCrStatCd() {
		return sCrStatCd;
	}

	/**
	 * @param sCrStatCd the sCrStatCd to set
	 */
	public void setsCrStatCd(final String sCrStatCd) {
		this.sCrStatCd = sCrStatCd;
	}

	/**
	 * @return the sCrStatNm
	 */
	public String getsCrStatNm() {
		return sCrStatNm;
	}

	/**
	 * @param sCrStatNm the sCrStatNm to set
	 */
	public void setsCrStatNm(final String sCrStatNm) {
		this.sCrStatNm = sCrStatNm;
	}

	/**
	 * @return the sFinalPaymMthy
	 */
	public String getsFinalPaymMthy() {
		return sFinalPaymMthy;
	}

	/**
	 * @param sFinalPaymMthy the sFinalPaymMthy to set
	 */
	public void setsFinalPaymMthy(final String sFinalPaymMthy) {
		this.sFinalPaymMthy = sFinalPaymMthy;
	}

	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}

	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(final String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}

	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}

	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(final String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}

	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}

	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(final String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}

	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}

	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(final String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}

	/**
	 * @return the sInrpsCd
	 */
	public String getsInrpsCd() {
		return sInrpsCd;
	}

	/**
	 * @param sInrpsCd the sInrpsCd to set
	 */
	public void setsInrpsCd(final String sInrpsCd) {
		this.sInrpsCd = sInrpsCd;
	}

	/**
	 * @return the sInrpsName
	 */
	public String getsInrpsName() {
		return sInrpsName;
	}

	/**
	 * @param sInrpsName the sInrpsName to set
	 */
	public void setsInrpsName(final String sInrpsName) {
		this.sInrpsName = sInrpsName;
	}

	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}

	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(final String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}

	/**
	 * @return the sInsurTerm
	 */
	public String getsInsurTerm() {
		return sInsurTerm;
	}

	/**
	 * @param sInsurTerm the sInsurTerm to set
	 */
	public void setsInsurTerm(final String sInsurTerm) {
		this.sInsurTerm = sInsurTerm;
	}

	/**
	 * @return the nTotPaymPrem
	 */
	public String getnTotPaymPrem() {
		return nTotPaymPrem;
	}

	/**
	 * @param nTotPaymPrem the nTotPaymPrem to set
	 */
	public void setnTotPaymPrem(final String nTotPaymPrem) {
		this.nTotPaymPrem = nTotPaymPrem;
	}

	/**
	 * @return the sDoer
	 */
	public String getsDoer() {
		return sDoer;
	}

	/**
	 * @param sDoer the sDoer to set
	 */
	public void setsDoer(final String sDoer) {
		this.sDoer = sDoer;
	}

	/**
	 * @return the sDoerNm
	 */
	public String getsDoerNm() {
		return sDoerNm;
	}

	/**
	 * @param sDoerNm the sDoerNm to set
	 */
	public void setsDoerNm(final String sDoerNm) {
		this.sDoerNm = sDoerNm;
	}

	/**
	 * @return the sDoerUser
	 */
	public String getsDoerUser() {
		return sDoerUser;
	}

	/**
	 * @param sDoerUser the sDoerUser to set
	 */
	public void setsDoerUser(final String sDoerUser) {
		this.sDoerUser = sDoerUser;
	}

	/**
	 * @return the sDoerUserName
	 */
	public String getsDoerUserName() {
		return sDoerUserName;
	}

	/**
	 * @param sDoerUserName the sDoerUserName to set
	 */
	public void setsDoerUserName(final String sDoerUserName) {
		this.sDoerUserName = sDoerUserName;
	}

	/**
	 * @return the sPlanNo
	 */
	public String getsPlanNo() {
		return sPlanNo;
	}

	/**
	 * @param sPlanNo the sPlanNo to set
	 */
	public void setsPlanNo(final String sPlanNo) {
		this.sPlanNo = sPlanNo;
	}

	/**
	 * @return the sRecvProgStat
	 */
	public String getsRecvProgStat() {
		return sRecvProgStat;
	}

	/**
	 * @param sRecvProgStat the sRecvProgStat to set
	 */
	public void setsRecvProgStat(final String sRecvProgStat) {
		this.sRecvProgStat = sRecvProgStat;
	}

	/**
	 * @return the sPsnGroupFlgcd
	 */
	public String getsPsnGroupFlgcd() {
		return sPsnGroupFlgcd;
	}

	/**
	 * @param sPsnGroupFlgcd the sPsnGroupFlgcd to set
	 */
	public void setsPsnGroupFlgcd(final String sPsnGroupFlgcd) {
		this.sPsnGroupFlgcd = sPsnGroupFlgcd;
	}

	/**
	 * @return the nFinalPaymSeq
	 */
	public String getnFinalPaymSeq() {
		return nFinalPaymSeq;
	}

	/**
	 * @param nFinalPaymSeq the nFinalPaymSeq to set
	 */
	public void setnFinalPaymSeq(final String nFinalPaymSeq) {
		this.nFinalPaymSeq = nFinalPaymSeq;
	}

	/**
	 * @return the sPaymCyclCdNm
	 */
	public String getsPaymCyclCdNm() {
		return sPaymCyclCdNm;
	}

	/**
	 * @param sPaymCyclCdNm the sPaymCyclCdNm to set
	 */
	public void setsPaymCyclCdNm(final String sPaymCyclCdNm) {
		this.sPaymCyclCdNm = sPaymCyclCdNm;
	}

	/**
	 * @return the sPaymTermCdNm
	 */
	public String getsPaymTermCdNm() {
		return sPaymTermCdNm;
	}

	/**
	 * @param sPaymTermCdNm the sPaymTermCdNm to set
	 */
	public void setsPaymTermCdNm(final String sPaymTermCdNm) {
		this.sPaymTermCdNm = sPaymTermCdNm;
	}

	/**
	 * @return the sRenwlYn
	 */
	public String getsRenwlYn() {
		return sRenwlYn;
	}

	/**
	 * @param sRenwlYn the sRenwlYn to set
	 */
	public void setsRenwlYn(final String sRenwlYn) {
		this.sRenwlYn = sRenwlYn;
	}

	/**
	 * @return the nInrpsSeqno
	 */
	public String getnInrpsSeqno() {
		return nInrpsSeqno;
	}

	/**
	 * @param nInrpsSeqno the nInrpsSeqno to set
	 */
	public void setnInrpsSeqno(final String nInrpsSeqno) {
		this.nInrpsSeqno = nInrpsSeqno;
	}

}
