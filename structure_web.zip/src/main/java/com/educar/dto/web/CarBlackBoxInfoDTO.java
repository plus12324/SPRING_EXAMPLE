/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����ڽ��˾����� ������
 * û���ȣ�� ����data ȣ����  DTO
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carBlackBoxInfoDTO")
public class CarBlackBoxInfoDTO {
	/** ����  **/
	private String sInsrdName;
	/** �ֹι�ȣ  **/
	private String sInsrdID;
	/** ������ȣ  **/
	private String sPlateNo;
	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}
	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}
	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}
	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}
	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}
	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

}
