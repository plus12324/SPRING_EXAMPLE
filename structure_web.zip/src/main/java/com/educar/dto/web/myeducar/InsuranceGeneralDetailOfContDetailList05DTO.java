/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetailOfContDetailList05DTO")
public class InsuranceGeneralDetailOfContDetailList05DTO {
	/** �����ڵ� **/
	private String sBankCode;
	/** ����� **/
	private String sBankCodeName;
	/** ���¹�ȣ **/
	private String sAcctNo;
	/** �������ڵ� **/
	private String sDepositerID;
	/** �����ָ� **/
	private String sDepositerName;

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sBankCodeName
	 */
	public String getsBankCodeName() {
		return sBankCodeName;
	}

	/**
	 * @param sBankCodeName the sBankCodeName to set
	 */
	public void setsBankCodeName(final String sBankCodeName) {
		this.sBankCodeName = sBankCodeName;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sDepositerID
	 */
	public String getsDepositerID() {
		return sDepositerID;
	}

	/**
	 * @param sDepositerID the sDepositerID to set
	 */
	public void setsDepositerID(final String sDepositerID) {
		this.sDepositerID = sDepositerID;
	}

	/**
	 * @return the sDepositerName
	 */
	public String getsDepositerName() {
		return sDepositerName;
	}

	/**
	 * @param sDepositerName the sDepositerName to set
	 */
	public void setsDepositerName(final String sDepositerName) {
		this.sDepositerName = sDepositerName;
	}

}
