/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "acctRegiInfoOfVictimInfoDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AcctRegiInfoOfVictimInfoDTO {
	/** �㺸���� **/
	private String sDmgeNo;
	/** ���ػ��� **/
	private String sDmgeStatus;
	/** �㺸�ڵ� **/
	private String sHndCover;
	/**  **/
	private String sHospital;
	/**  **/
	private String sHospName;
	/**  **/
	private String sHospTel1;
	/**  **/
	private String sHospTel2;
	/**  **/
	private String sHospTel3;
	/** ����ڸ� **/
	private String sName;
	/** �������� **/
	private String sRegiCenter;
	/** ��������� **/
	private String sRegiStaff;
	/** ������ **/
	private String sRegiTeam;
	/** �������� **/
	private String sStaff;
	/** ����� **/
	private String sTeam;
	/** �Է��� (ȭ�鿡�� ��������) **/
	private String sUserID;
	/** �����ڿ���ó1 **/
	private String sVictimCelTel1;
	/** �����ڿ���ó2 **/
	private String sVictimCelTel2;
	/** �����ڿ���ó3 **/
	private String sVictimCelTel3;
	/** �����ڸ� **/
	private String sVictimName;
	/** �Է±����� **/
	private String sRowType;

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the sDmgeStatus
	 */
	public String getsDmgeStatus() {
		return sDmgeStatus;
	}

	/**
	 * @param sDmgeStatus the sDmgeStatus to set
	 */
	public void setsDmgeStatus(final String sDmgeStatus) {
		this.sDmgeStatus = sDmgeStatus;
	}

	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}

	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(final String sHndCover) {
		this.sHndCover = sHndCover;
	}

	/**
	 * @return the sHospital
	 */
	public String getsHospital() {
		return sHospital;
	}

	/**
	 * @param sHospital the sHospital to set
	 */
	public void setsHospital(final String sHospital) {
		this.sHospital = sHospital;
	}

	/**
	 * @return the sHospName
	 */
	public String getsHospName() {
		return sHospName;
	}

	/**
	 * @param sHospName the sHospName to set
	 */
	public void setsHospName(final String sHospName) {
		this.sHospName = sHospName;
	}

	/**
	 * @return the sHospTel1
	 */
	public String getsHospTel1() {
		return sHospTel1;
	}

	/**
	 * @param sHospTel1 the sHospTel1 to set
	 */
	public void setsHospTel1(final String sHospTel1) {
		this.sHospTel1 = sHospTel1;
	}

	/**
	 * @return the sHospTel2
	 */
	public String getsHospTel2() {
		return sHospTel2;
	}

	/**
	 * @param sHospTel2 the sHospTel2 to set
	 */
	public void setsHospTel2(final String sHospTel2) {
		this.sHospTel2 = sHospTel2;
	}

	/**
	 * @return the sHospTel3
	 */
	public String getsHospTel3() {
		return sHospTel3;
	}

	/**
	 * @param sHospTel3 the sHospTel3 to set
	 */
	public void setsHospTel3(final String sHospTel3) {
		this.sHospTel3 = sHospTel3;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sRegiCenter
	 */
	public String getsRegiCenter() {
		return sRegiCenter;
	}

	/**
	 * @param sRegiCenter the sRegiCenter to set
	 */
	public void setsRegiCenter(final String sRegiCenter) {
		this.sRegiCenter = sRegiCenter;
	}

	/**
	 * @return the sRegiStaff
	 */
	public String getsRegiStaff() {
		return sRegiStaff;
	}

	/**
	 * @param sRegiStaff the sRegiStaff to set
	 */
	public void setsRegiStaff(final String sRegiStaff) {
		this.sRegiStaff = sRegiStaff;
	}

	/**
	 * @return the sRegiTeam
	 */
	public String getsRegiTeam() {
		return sRegiTeam;
	}

	/**
	 * @param sRegiTeam the sRegiTeam to set
	 */
	public void setsRegiTeam(final String sRegiTeam) {
		this.sRegiTeam = sRegiTeam;
	}

	/**
	 * @return the sStaff
	 */
	public String getsStaff() {
		return sStaff;
	}

	/**
	 * @param sStaff the sStaff to set
	 */
	public void setsStaff(final String sStaff) {
		this.sStaff = sStaff;
	}

	/**
	 * @return the sTeam
	 */
	public String getsTeam() {
		return sTeam;
	}

	/**
	 * @param sTeam the sTeam to set
	 */
	public void setsTeam(final String sTeam) {
		this.sTeam = sTeam;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the sVictimCelTel1
	 */
	public String getsVictimCelTel1() {
		return sVictimCelTel1;
	}

	/**
	 * @param sVictimCelTel1 the sVictimCelTel1 to set
	 */
	public void setsVictimCelTel1(final String sVictimCelTel1) {
		this.sVictimCelTel1 = sVictimCelTel1;
	}

	/**
	 * @return the sVictimCelTel2
	 */
	public String getsVictimCelTel2() {
		return sVictimCelTel2;
	}

	/**
	 * @param sVictimCelTel2 the sVictimCelTel2 to set
	 */
	public void setsVictimCelTel2(final String sVictimCelTel2) {
		this.sVictimCelTel2 = sVictimCelTel2;
	}

	/**
	 * @return the sVictimCelTel3
	 */
	public String getsVictimCelTel3() {
		return sVictimCelTel3;
	}

	/**
	 * @param sVictimCelTel3 the sVictimCelTel3 to set
	 */
	public void setsVictimCelTel3(final String sVictimCelTel3) {
		this.sVictimCelTel3 = sVictimCelTel3;
	}

	/**
	 * @return the sVictimName
	 */
	public String getsVictimName() {
		return sVictimName;
	}

	/**
	 * @param sVictimName the sVictimName to set
	 */
	public void setsVictimName(final String sVictimName) {
		this.sVictimName = sVictimName;
	}

	/**
	 * @return the sRowType
	 */
	public String getsRowType() {
		return sRowType;
	}

	/**
	 * @param sRowType the sRowType to set
	 */
	public void setsRowType(final String sRowType) {
		this.sRowType = sRowType;
	}

}
