/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * <pre>
 * �̺�Ʈ ��÷�� Ȯ�� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "eventWinnerDTO")
public class EventWinnerDTO {

	/** �̺�Ʈ �ڵ� **/
	private String eventCd;
	/** ���޻� �ڵ� **/
	private String acCd;
	/** ��÷�� �� **/
	private String name;
	/** ��÷�� �ڵ��� ��ȣ **/
	private String hp;
	/** ������ �ڵ��� ��ȣ1 **/
	@BeanUtil(ignore = true)
	private String sCellPhone1;
	/** ������ �ڵ��� ��ȣ2 **/
	@BeanUtil(ignore = true)
	private String sCellPhone2;
	/** ������ �ڵ��� ��ȣ3 **/
	@BeanUtil(ignore = true)
	private String sCellPhone3;
	/** ��÷ �ȳ� ����(��) **/
	private String content;
	/** ��ǰ��(��) **/
	private String prize;
	/** ��÷ ���(��) **/
	private String grade;
	/** ��÷ ����(����) **/
	private String sWinYn;
	/** ��ǰ��(����) **/
	private String sWinProduct;
	/** ��÷ ���(����) **/
	private String sWinRank;
	/** ��÷ ��ǰ1(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE01;
	/** ��÷ ��ǰ2(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE02;
	/** ��÷ ��ǰ3(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE03;
	/** ��÷ ��ǰ4(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE04;
	/** ��÷ ��ǰ5(����) **/
	@BeanUtil(ignore = true)
	private String PRIZE05;

	public String getPRIZE01() {
		return PRIZE01;
	}

	public void setPRIZE01(String pRIZE01) {
		PRIZE01 = pRIZE01;
	}

	public String getPRIZE02() {
		return PRIZE02;
	}

	public void setPRIZE02(String pRIZE02) {
		PRIZE02 = pRIZE02;
	}

	public String getPRIZE03() {
		return PRIZE03;
	}

	public void setPRIZE03(String pRIZE03) {
		PRIZE03 = pRIZE03;
	}

	public String getPRIZE04() {
		return PRIZE04;
	}

	public void setPRIZE04(String pRIZE04) {
		PRIZE04 = pRIZE04;
	}

	public String getPRIZE05() {
		return PRIZE05;
	}

	public void setPRIZE05(String pRIZE05) {
		PRIZE05 = pRIZE05;
	}

	public String getsWinYn() {
		return sWinYn;
	}

	public void setsWinYn(String sWinYn) {
		this.sWinYn = sWinYn;
	}

	public String getsWinProduct() {
		return sWinProduct;
	}

	public void setsWinProduct(String sWinProduct) {
		this.sWinProduct = sWinProduct;
	}

	public String getsWinRank() {
		return sWinRank;
	}

	public void setsWinRank(String sWinRank) {
		this.sWinRank = sWinRank;
	}

	public String getsCellPhone1() {
		return sCellPhone1;
	}

	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	public String getsCellPhone2() {
		return sCellPhone2;
	}

	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	public String getsCellPhone3() {
		return sCellPhone3;
	}

	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the eventCd
	 */
	public String getEventCd() {
		return eventCd;
	}

	/**
	 * @param eventCd the eventCd to set
	 */
	public void setEventCd(final String eventCd) {
		this.eventCd = eventCd;
	}

	/**
	 * @return the acCd
	 */
	public String getAcCd() {
		return acCd;
	}

	/**
	 * @param acCd the acCd to set
	 */
	public void setAcCd(final String acCd) {
		this.acCd = acCd;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * @return the hp
	 */
	public String getHp() {
		return hp;
	}

	/**
	 * @param hp the hp to set
	 */
	public void setHp(final String hp) {
		this.hp = hp;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(final String content) {
		this.content = content;
	}

	/**
	 * @return the prize
	 */
	public String getPrize() {
		return prize;
	}

	/**
	 * @param prize the prize to set
	 */
	public void setPrize(final String prize) {
		this.prize = prize;
	}

	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(final String grade) {
		this.grade = grade;
	}
}