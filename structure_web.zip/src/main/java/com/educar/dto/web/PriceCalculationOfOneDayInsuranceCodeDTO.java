/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �ڵ��� ����� ���� �ڵ� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfOneDayInsuranceCodeDTO")
public class PriceCalculationOfOneDayInsuranceCodeDTO {
	/** �㺸 �ڵ� **/
	private String sCover;
	/** ���� ����� **/
	private String nCoverPrem;

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the nCoverPrem
	 */
	public String getnCoverPrem() {
		return nCoverPrem;
	}

	/**
	 * @param nCoverPrem the nCoverPrem to set
	 */
	public void setnCoverPrem(final String nCoverPrem) {
		this.nCoverPrem = nCoverPrem;
	}

}
