/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �¿��� ������ ����ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "policyKIDIDocDTO")
public class PolicyKIDIDocDTO {
	/** ȸ���ڵ� **/
	private String comp;
	/** ����ȣ **/
	private String cntr_numb;
	/** ����ñ� **/
	private String diin_sdat;
	/** �������� **/
	private String diin_edat;
	/** �����ñ�1 **/
	private String spag1_sdat;
	/** ��������1 **/
	private String spag1_edat;
	/** ������������1 **/
	private String spag1_week_day;
	/** �����ñ�2 **/
	private String spag2_sdat;
	/** ��������2 **/
	private String spag2_edat;
	/** ������������2 **/
	private String spag2_week_day;
	/** �����ñ�3 **/
	private String spag3_sdat;
	/** ��������3 **/
	private String spag3_edat;
	/** ������������3 **/
	private String spag3_week_day;
	/** �����ñ�4 **/
	private String spag4_sdat;
	/** ��������4 **/
	private String spag4_edat;
	/** ������������4 **/
	private String spag4_week_day;
	/** �����ñ�5 **/
	private String spag5_sdat;
	/** ��������5 **/
	private String spag5_edat;
	/** ������������5 **/
	private String spag5_week_day;
	/** ����/��ȣ **/
	private String insu_name;
	/** �ֹε�Ϲ�ȣ **/
	private String inpr_code;
	/** �����Է����� **/
	private String input_date;
	/** ������ü ���汸�� **/
	private String car_endr_clss;
	/** Ư������ ���Խ� ������ȣ **/
	private String car_numb1;
	/** ������ȣ2 **/
	private String car_numb2;
	/** �輭������2 **/
	private String endr_prim_date2;
	/** ������ȣ3 **/
	private String car_numb3;
	/** �輭������3 **/
	private String endr_prim_date3;
	/** ������ȣ4 **/
	private String car_numb4;
	/** �輭������4 **/
	private String endr_prim_date4;
	/** ������ȣ5 **/
	private String car_numb5;
	/** �輭������5 **/
	private String endr_prim_date5;

	/**
	 * @return the comp
	 */
	public String getComp() {
		return comp;
	}

	/**
	 * @param comp the comp to set
	 */
	public void setComp(final String comp) {
		this.comp = comp;
	}

	/**
	 * @return the cntr_numb
	 */
	public String getCntr_numb() {
		return cntr_numb;
	}

	/**
	 * @param cntr_numb the cntr_numb to set
	 */
	public void setCntr_numb(final String cntr_numb) {
		this.cntr_numb = cntr_numb;
	}

	/**
	 * @return the diin_sdat
	 */
	public String getDiin_sdat() {
		return diin_sdat;
	}

	/**
	 * @param diin_sdat the diin_sdat to set
	 */
	public void setDiin_sdat(final String diin_sdat) {
		this.diin_sdat = diin_sdat;
	}

	/**
	 * @return the diin_edat
	 */
	public String getDiin_edat() {
		return diin_edat;
	}

	/**
	 * @param diin_edat the diin_edat to set
	 */
	public void setDiin_edat(final String diin_edat) {
		this.diin_edat = diin_edat;
	}

	/**
	 * @return the spag1_sdat
	 */
	public String getSpag1_sdat() {
		return spag1_sdat;
	}

	/**
	 * @param spag1_sdat the spag1_sdat to set
	 */
	public void setSpag1_sdat(final String spag1_sdat) {
		this.spag1_sdat = spag1_sdat;
	}

	/**
	 * @return the spag1_edat
	 */
	public String getSpag1_edat() {
		return spag1_edat;
	}

	/**
	 * @param spag1_edat the spag1_edat to set
	 */
	public void setSpag1_edat(final String spag1_edat) {
		this.spag1_edat = spag1_edat;
	}

	/**
	 * @return the spag1_week_day
	 */
	public String getSpag1_week_day() {
		return spag1_week_day;
	}

	/**
	 * @param spag1_week_day the spag1_week_day to set
	 */
	public void setSpag1_week_day(final String spag1_week_day) {
		this.spag1_week_day = spag1_week_day;
	}

	/**
	 * @return the spag2_sdat
	 */
	public String getSpag2_sdat() {
		return spag2_sdat;
	}

	/**
	 * @param spag2_sdat the spag2_sdat to set
	 */
	public void setSpag2_sdat(final String spag2_sdat) {
		this.spag2_sdat = spag2_sdat;
	}

	/**
	 * @return the spag2_edat
	 */
	public String getSpag2_edat() {
		return spag2_edat;
	}

	/**
	 * @param spag2_edat the spag2_edat to set
	 */
	public void setSpag2_edat(final String spag2_edat) {
		this.spag2_edat = spag2_edat;
	}

	/**
	 * @return the spag2_week_day
	 */
	public String getSpag2_week_day() {
		return spag2_week_day;
	}

	/**
	 * @param spag2_week_day the spag2_week_day to set
	 */
	public void setSpag2_week_day(final String spag2_week_day) {
		this.spag2_week_day = spag2_week_day;
	}

	/**
	 * @return the spag3_sdat
	 */
	public String getSpag3_sdat() {
		return spag3_sdat;
	}

	/**
	 * @param spag3_sdat the spag3_sdat to set
	 */
	public void setSpag3_sdat(final String spag3_sdat) {
		this.spag3_sdat = spag3_sdat;
	}

	/**
	 * @return the spag3_edat
	 */
	public String getSpag3_edat() {
		return spag3_edat;
	}

	/**
	 * @param spag3_edat the spag3_edat to set
	 */
	public void setSpag3_edat(final String spag3_edat) {
		this.spag3_edat = spag3_edat;
	}

	/**
	 * @return the spag3_week_day
	 */
	public String getSpag3_week_day() {
		return spag3_week_day;
	}

	/**
	 * @param spag3_week_day the spag3_week_day to set
	 */
	public void setSpag3_week_day(final String spag3_week_day) {
		this.spag3_week_day = spag3_week_day;
	}

	/**
	 * @return the spag4_sdat
	 */
	public String getSpag4_sdat() {
		return spag4_sdat;
	}

	/**
	 * @param spag4_sdat the spag4_sdat to set
	 */
	public void setSpag4_sdat(final String spag4_sdat) {
		this.spag4_sdat = spag4_sdat;
	}

	/**
	 * @return the spag4_edat
	 */
	public String getSpag4_edat() {
		return spag4_edat;
	}

	/**
	 * @param spag4_edat the spag4_edat to set
	 */
	public void setSpag4_edat(final String spag4_edat) {
		this.spag4_edat = spag4_edat;
	}

	/**
	 * @return the spag4_week_day
	 */
	public String getSpag4_week_day() {
		return spag4_week_day;
	}

	/**
	 * @param spag4_week_day the spag4_week_day to set
	 */
	public void setSpag4_week_day(final String spag4_week_day) {
		this.spag4_week_day = spag4_week_day;
	}

	/**
	 * @return the spag5_sdat
	 */
	public String getSpag5_sdat() {
		return spag5_sdat;
	}

	/**
	 * @param spag5_sdat the spag5_sdat to set
	 */
	public void setSpag5_sdat(final String spag5_sdat) {
		this.spag5_sdat = spag5_sdat;
	}

	/**
	 * @return the spag5_edat
	 */
	public String getSpag5_edat() {
		return spag5_edat;
	}

	/**
	 * @param spag5_edat the spag5_edat to set
	 */
	public void setSpag5_edat(final String spag5_edat) {
		this.spag5_edat = spag5_edat;
	}

	/**
	 * @return the spag5_week_day
	 */
	public String getSpag5_week_day() {
		return spag5_week_day;
	}

	/**
	 * @param spag5_week_day the spag5_week_day to set
	 */
	public void setSpag5_week_day(final String spag5_week_day) {
		this.spag5_week_day = spag5_week_day;
	}

	/**
	 * @return the insu_name
	 */
	public String getInsu_name() {
		return insu_name;
	}

	/**
	 * @param insu_name the insu_name to set
	 */
	public void setInsu_name(final String insu_name) {
		this.insu_name = insu_name;
	}

	/**
	 * @return the inpr_code
	 */
	public String getInpr_code() {
		return inpr_code;
	}

	/**
	 * @param inpr_code the inpr_code to set
	 */
	public void setInpr_code(final String inpr_code) {
		this.inpr_code = inpr_code;
	}

	/**
	 * @return the input_date
	 */
	public String getInput_date() {
		return input_date;
	}

	/**
	 * @param input_date the input_date to set
	 */
	public void setInput_date(final String input_date) {
		this.input_date = input_date;
	}

	/**
	 * @return the car_endr_clss
	 */
	public String getCar_endr_clss() {
		return car_endr_clss;
	}

	/**
	 * @param car_endr_clss the car_endr_clss to set
	 */
	public void setCar_endr_clss(final String car_endr_clss) {
		this.car_endr_clss = car_endr_clss;
	}

	/**
	 * @return the car_numb1
	 */
	public String getCar_numb1() {
		return car_numb1;
	}

	/**
	 * @param car_numb1 the car_numb1 to set
	 */
	public void setCar_numb1(final String car_numb1) {
		this.car_numb1 = car_numb1;
	}

	/**
	 * @return the car_numb2
	 */
	public String getCar_numb2() {
		return car_numb2;
	}

	/**
	 * @param car_numb2 the car_numb2 to set
	 */
	public void setCar_numb2(final String car_numb2) {
		this.car_numb2 = car_numb2;
	}

	/**
	 * @return the endr_prim_date2
	 */
	public String getEndr_prim_date2() {
		return endr_prim_date2;
	}

	/**
	 * @param endr_prim_date2 the endr_prim_date2 to set
	 */
	public void setEndr_prim_date2(final String endr_prim_date2) {
		this.endr_prim_date2 = endr_prim_date2;
	}

	/**
	 * @return the car_numb3
	 */
	public String getCar_numb3() {
		return car_numb3;
	}

	/**
	 * @param car_numb3 the car_numb3 to set
	 */
	public void setCar_numb3(final String car_numb3) {
		this.car_numb3 = car_numb3;
	}

	/**
	 * @return the endr_prim_date3
	 */
	public String getEndr_prim_date3() {
		return endr_prim_date3;
	}

	/**
	 * @param endr_prim_date3 the endr_prim_date3 to set
	 */
	public void setEndr_prim_date3(final String endr_prim_date3) {
		this.endr_prim_date3 = endr_prim_date3;
	}

	/**
	 * @return the car_numb4
	 */
	public String getCar_numb4() {
		return car_numb4;
	}

	/**
	 * @param car_numb4 the car_numb4 to set
	 */
	public void setCar_numb4(final String car_numb4) {
		this.car_numb4 = car_numb4;
	}

	/**
	 * @return the endr_prim_date4
	 */
	public String getEndr_prim_date4() {
		return endr_prim_date4;
	}

	/**
	 * @param endr_prim_date4 the endr_prim_date4 to set
	 */
	public void setEndr_prim_date4(final String endr_prim_date4) {
		this.endr_prim_date4 = endr_prim_date4;
	}

	/**
	 * @return the car_numb5
	 */
	public String getCar_numb5() {
		return car_numb5;
	}

	/**
	 * @param car_numb5 the car_numb5 to set
	 */
	public void setCar_numb5(final String car_numb5) {
		this.car_numb5 = car_numb5;
	}

	/**
	 * @return the endr_prim_date5
	 */
	public String getEndr_prim_date5() {
		return endr_prim_date5;
	}

	/**
	 * @param endr_prim_date5 the endr_prim_date5 to set
	 */
	public void setEndr_prim_date5(final String endr_prim_date5) {
		this.endr_prim_date5 = endr_prim_date5;
	}

}
