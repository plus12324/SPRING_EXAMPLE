/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ����⵿ ���� ��ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "emergencyActionDTO")
public class EmergencyActionDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;

	/** �Ϸù�ȣ **/
	private long nSeqNo;
	/** ���͸� **/
	private String sShopName;
	/** �ּ�(ȭ�鿡�� ���) **/
	private String address;
	/** �ּ�1 **/
	private String sAdrs1;
	/** �ּ�2 **/
	private String sAdrs2;
	/** �ּ�3 **/
	private String sAdrs3;

	/** daum map api ��ǥ x (ȭ�鿡�����)**/
	private String x;
	/** daum map api ��ǥ y (ȭ�鿡�����)**/
	private String y;

	/**
	 * @return the nSeqNo
	 */
	public long getnSeqNo() {
		return nSeqNo;
	}

	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(final long nSeqNo) {
		this.nSeqNo = nSeqNo;
	}

	/**
	 * @return the sShopName
	 */
	public String getsShopName() {
		return sShopName;
	}

	/**
	 * @param sShopName the sShopName to set
	 */
	public void setsShopName(final String sShopName) {
		this.sShopName = sShopName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the x
	 */
	public String getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public void setX(final String x) {
		this.x = x;
	}

	/**
	 * @return the y
	 */
	public String getY() {
		return y;
	}

	/**
	 * @param y the y to set
	 */
	public void setY(final String y) {
		this.y = y;
	}

}
