/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlRootElement(name = "getContDataInputDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class GetContDataInputDTO {
	/** �ֹε�Ϲ�ȣ **/
	private String searchValue;
	/** ����ñ�(��������) **/
	private String sFmdt;
	/** ��������(��������) **/
	private String sTodt;
	/** �Ͻ�(����ð�) **/
	private String sApplyTime;
	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}
	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}
	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}
	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	/**
	 * @return the sApplyTime
	 */
	public String getsApplyTime() {
		return sApplyTime;
	}
	/**
	 * @param sApplyTime the sApplyTime to set
	 */
	public void setsApplyTime(String sApplyTime) {
		this.sApplyTime = sApplyTime;
	}
	
	
}
