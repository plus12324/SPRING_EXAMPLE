/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.main;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���������� ä�� ���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 1.0.0
 */
@XmlRootElement(name = "recruitDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class RecruitDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** ä���ȣ              **/
	private String sHireNo;
	/** ä���    **/
	private String sHireName;
	/** ������ȣ              **/
	private String sDocNo;
	/** ����������            **/
	private String sRecruitFmdt;
	/** ����������            **/
	private String sRecruitTodt;
	/** �������              **/
	private String sSelWay;
	/** ����������          **/
	private String sSelWayNote;
	/** ���⼭��1             **/
	private String sSubmitDoc1;
	/** ���⼭��2             **/
	private String sSubmitDoc2;
	/** ���⼭��3             **/
	private String sSubmitDoc3;
	/** ���⼭��4             **/
	private String sSubmitDoc4;
	/** ���⼭��5             **/
	private String sSubmitDoc5;
	/** ���⼭��6 **/
	private String sSubmitDoc6;
	/** ���⼭�����          **/
	private String sSubmitDocNote;
	/** �������              **/
	private String sApplyWay;
	/** ����ó                **/
	private String sApplySite;
	/** ��Ÿ����              **/
	private String sEtcAsk;
	/** �������              **/
	private String sCommonItem;
	/** ����������              **/
	private String sWebNoticeYN;
	/** �����ȣ              **/
	private String sApproveNo;
	/** �۾��ڻ��            **/
	private String sUserID;
	/** �۾���                **/
	private String sInputDate;
	/** �۾��ð�              **/
	private String sInputTime;
	/** ä�뱸��        **/
	private String sHireGroup;
	/** �ڰݰ��뱸�� **/
	private String sQualCommType;
	/** ��������         **/
	private String sSelSchedule;
	/** ��������� **/
	private String sWebResultYN;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @return the sHireName
	 */
	public String getsHireName() {
		return sHireName;
	}

	/**
	 * @return the sDocNo
	 */
	public String getsDocNo() {
		return sDocNo;
	}

	/**
	 * @return the sRecruitFmdt
	 */
	public String getsRecruitFmdt() {
		return sRecruitFmdt;
	}

	/**
	 * @return the sRecruitTodt
	 */
	public String getsRecruitTodt() {
		return sRecruitTodt;
	}

	/**
	 * @return the sSelWay
	 */
	public String getsSelWay() {
		return sSelWay;
	}

	/**
	 * @return the sSelWayNote
	 */
	public String getsSelWayNote() {
		return sSelWayNote;
	}

	/**
	 * @return the sSubmitDoc1
	 */
	public String getsSubmitDoc1() {
		return sSubmitDoc1;
	}

	/**
	 * @return the sSubmitDoc2
	 */
	public String getsSubmitDoc2() {
		return sSubmitDoc2;
	}

	/**
	 * @return the sSubmitDoc3
	 */
	public String getsSubmitDoc3() {
		return sSubmitDoc3;
	}

	/**
	 * @return the sSubmitDoc4
	 */
	public String getsSubmitDoc4() {
		return sSubmitDoc4;
	}

	/**
	 * @return the sSubmitDoc5
	 */
	public String getsSubmitDoc5() {
		return sSubmitDoc5;
	}

	/**
	 * @return the sSubmitDoc6
	 */
	public String getsSubmitDoc6() {
		return sSubmitDoc6;
	}

	/**
	 * @return the sSubmitDocNote
	 */
	public String getsSubmitDocNote() {
		return sSubmitDocNote;
	}

	/**
	 * @return the sApplyWay
	 */
	public String getsApplyWay() {
		return sApplyWay;
	}

	/**
	 * @return the sApplySite
	 */
	public String getsApplySite() {
		return sApplySite;
	}

	/**
	 * @return the sEtcAsk
	 */
	public String getsEtcAsk() {
		return sEtcAsk;
	}

	/**
	 * @return the sCommonItem
	 */
	public String getsCommonItem() {
		return sCommonItem;
	}

	/**
	 * @return the sWebNoticeYN
	 */
	public String getsWebNoticeYN() {
		return sWebNoticeYN;
	}

	/**
	 * @return the sApproveNo
	 */
	public String getsApproveNo() {
		return sApproveNo;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}

	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}

	/**
	 * @return the sHireGroup
	 */
	public String getsHireGroup() {
		return sHireGroup;
	}

	/**
	 * @return the sQualCommType
	 */
	public String getsQualCommType() {
		return sQualCommType;
	}

	/**
	 * @return the sSelSchedule
	 */
	public String getsSelSchedule() {
		return sSelSchedule;
	}

	/**
	 * @return the sWebResultYN
	 */
	public String getsWebResultYN() {
		return sWebResultYN;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(final String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @param sHireName the sHireName to set
	 */
	public void setsHireName(final String sHireName) {
		this.sHireName = sHireName;
	}

	/**
	 * @param sDocNo the sDocNo to set
	 */
	public void setsDocNo(final String sDocNo) {
		this.sDocNo = sDocNo;
	}

	/**
	 * @param sRecruitFmdt the sRecruitFmdt to set
	 */
	public void setsRecruitFmdt(final String sRecruitFmdt) {
		this.sRecruitFmdt = sRecruitFmdt;
	}

	/**
	 * @param sRecruitTodt the sRecruitTodt to set
	 */
	public void setsRecruitTodt(final String sRecruitTodt) {
		this.sRecruitTodt = sRecruitTodt;
	}

	/**
	 * @param sSelWay the sSelWay to set
	 */
	public void setsSelWay(final String sSelWay) {
		this.sSelWay = sSelWay;
	}

	/**
	 * @param sSelWayNote the sSelWayNote to set
	 */
	public void setsSelWayNote(final String sSelWayNote) {
		this.sSelWayNote = sSelWayNote;
	}

	/**
	 * @param sSubmitDoc1 the sSubmitDoc1 to set
	 */
	public void setsSubmitDoc1(final String sSubmitDoc1) {
		this.sSubmitDoc1 = sSubmitDoc1;
	}

	/**
	 * @param sSubmitDoc2 the sSubmitDoc2 to set
	 */
	public void setsSubmitDoc2(final String sSubmitDoc2) {
		this.sSubmitDoc2 = sSubmitDoc2;
	}

	/**
	 * @param sSubmitDoc3 the sSubmitDoc3 to set
	 */
	public void setsSubmitDoc3(final String sSubmitDoc3) {
		this.sSubmitDoc3 = sSubmitDoc3;
	}

	/**
	 * @param sSubmitDoc4 the sSubmitDoc4 to set
	 */
	public void setsSubmitDoc4(final String sSubmitDoc4) {
		this.sSubmitDoc4 = sSubmitDoc4;
	}

	/**
	 * @param sSubmitDoc5 the sSubmitDoc5 to set
	 */
	public void setsSubmitDoc5(final String sSubmitDoc5) {
		this.sSubmitDoc5 = sSubmitDoc5;
	}

	/**
	 * @param sSubmitDoc6 the sSubmitDoc6 to set
	 */
	public void setsSubmitDoc6(final String sSubmitDoc6) {
		this.sSubmitDoc6 = sSubmitDoc6;
	}

	/**
	 * @param sSubmitDocNote the sSubmitDocNote to set
	 */
	public void setsSubmitDocNote(final String sSubmitDocNote) {
		this.sSubmitDocNote = sSubmitDocNote;
	}

	/**
	 * @param sApplyWay the sApplyWay to set
	 */
	public void setsApplyWay(final String sApplyWay) {
		this.sApplyWay = sApplyWay;
	}

	/**
	 * @param sApplySite the sApplySite to set
	 */
	public void setsApplySite(final String sApplySite) {
		this.sApplySite = sApplySite;
	}

	/**
	 * @param sEtcAsk the sEtcAsk to set
	 */
	public void setsEtcAsk(final String sEtcAsk) {
		this.sEtcAsk = sEtcAsk;
	}

	/**
	 * @param sCommonItem the sCommonItem to set
	 */
	public void setsCommonItem(final String sCommonItem) {
		this.sCommonItem = sCommonItem;
	}

	/**
	 * @param sWebNoticeYN the sWebNoticeYN to set
	 */
	public void setsWebNoticeYN(final String sWebNoticeYN) {
		this.sWebNoticeYN = sWebNoticeYN;
	}

	/**
	 * @param sApproveNo the sApproveNo to set
	 */
	public void setsApproveNo(final String sApproveNo) {
		this.sApproveNo = sApproveNo;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(final String sInputDate) {
		this.sInputDate = sInputDate;
	}

	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(final String sInputTime) {
		this.sInputTime = sInputTime;
	}

	/**
	 * @param sHireGroup the sHireGroup to set
	 */
	public void setsHireGroup(final String sHireGroup) {
		this.sHireGroup = sHireGroup;
	}

	/**
	 * @param sQualCommType the sQualCommType to set
	 */
	public void setsQualCommType(final String sQualCommType) {
		this.sQualCommType = sQualCommType;
	}

	/**
	 * @param sSelSchedule the sSelSchedule to set
	 */
	public void setsSelSchedule(final String sSelSchedule) {
		this.sSelSchedule = sSelSchedule;
	}

	/**
	 * @param sWebResultYN the sWebResultYN to set
	 */
	public void setsWebResultYN(final String sWebResultYN) {
		this.sWebResultYN = sWebResultYN;
	}

}
