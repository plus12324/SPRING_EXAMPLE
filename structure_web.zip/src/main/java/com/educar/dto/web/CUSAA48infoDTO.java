/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ���ѳ�
 *
 */

@XmlRootElement(name = "CUSAA48infoDTO")
public class CUSAA48infoDTO {
	
	/** ������ȣ**/
	private String sCustNo;
	/** ���ǿ���	**/
	private String sAgmYn;
	/** ��������	**/
	private String sAgmDt;
	/** ���ǽð�	**/
	private String sAgmTime;
	/** �Է�����	**/
	private String sInputDate;
	/** �Է½ú�	**/
	private String sInputTime;
	/** �Է���	**/
	private String sInputID;
	/** ���ǹ��	**/
	private String sAgmMethod;
	/** ���ǰ�������	**/
	private String sAgmCheckType;
	/** ���ǰ�������	**/
	private String sAgmCheckInfo;
	/** ���Ǽ������ڵ�	**/
	private String sAgmRecvCode;
	/** ���Ǽ����ڸ�	**/
	private String sAgmRecvName;
	/** ���� �ʿ俩��	**/
	private String 	sAgmReq;
	/** ���� ���Ῡ��	**/
	private String 	sExpired;
	/** ���� ��ȿ����	**/
	private String sAgreeValid;
	/** ���������� ��ȸ ���� �Է� ����	**/
	private String kidiInfo;
	/** ����� ID	**/
	private String sUserID;
	
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sAgmYn
	 */
	public String getsAgmYn() {
		return sAgmYn;
	}
	/**
	 * @param sAgmYn the sAgmYn to set
	 */
	public void setsAgmYn(String sAgmYn) {
		this.sAgmYn = sAgmYn;
	}
	/**
	 * @return the sAgmDt
	 */
	public String getsAgmDt() {
		return sAgmDt;
	}
	/**
	 * @param sAgmDt the sAgmDt to set
	 */
	public void setsAgmDt(String sAgmDt) {
		this.sAgmDt = sAgmDt;
	}
	/**
	 * @return the sAgmTime
	 */
	public String getsAgmTime() {
		return sAgmTime;
	}
	/**
	 * @param sAgmTime the sAgmTime to set
	 */
	public void setsAgmTime(String sAgmTime) {
		this.sAgmTime = sAgmTime;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sInputID
	 */
	public String getsInputID() {
		return sInputID;
	}
	/**
	 * @param sInputID the sInputID to set
	 */
	public void setsInputID(String sInputID) {
		this.sInputID = sInputID;
	}
	/**
	 * @return the sAgmMethod
	 */
	public String getsAgmMethod() {
		return sAgmMethod;
	}
	/**
	 * @param sAgmMethod the sAgmMethod to set
	 */
	public void setsAgmMethod(String sAgmMethod) {
		this.sAgmMethod = sAgmMethod;
	}
	/**
	 * @return the sAgmCheckType
	 */
	public String getsAgmCheckType() {
		return sAgmCheckType;
	}
	/**
	 * @param sAgmCheckType the sAgmCheckType to set
	 */
	public void setsAgmCheckType(String sAgmCheckType) {
		this.sAgmCheckType = sAgmCheckType;
	}
	/**
	 * @return the sAgmCheckInfo
	 */
	public String getsAgmCheckInfo() {
		return sAgmCheckInfo;
	}
	/**
	 * @param sAgmCheckInfo the sAgmCheckInfo to set
	 */
	public void setsAgmCheckInfo(String sAgmCheckInfo) {
		this.sAgmCheckInfo = sAgmCheckInfo;
	}
	/**
	 * @return the sAgmRecvCode
	 */
	public String getsAgmRecvCode() {
		return sAgmRecvCode;
	}
	/**
	 * @param sAgmRecvCode the sAgmRecvCode to set
	 */
	public void setsAgmRecvCode(String sAgmRecvCode) {
		this.sAgmRecvCode = sAgmRecvCode;
	}
	/**
	 * @return the sAgmRecvName
	 */
	public String getsAgmRecvName() {
		return sAgmRecvName;
	}
	/**
	 * @param sAgmRecvName the sAgmRecvName to set
	 */
	public void setsAgmRecvName(String sAgmRecvName) {
		this.sAgmRecvName = sAgmRecvName;
	}
	/**
	 * @return the sAgmReq
	 */
	public String getsAgmReq() {
		return sAgmReq;
	}
	/**
	 * @param sAgmReq the sAgmReq to set
	 */
	public void setsAgmReq(String sAgmReq) {
		this.sAgmReq = sAgmReq;
	}
	/**
	 * @return the sExpired
	 */
	public String getsExpired() {
		return sExpired;
	}
	/**
	 * @param sExpired the sExpired to set
	 */
	public void setsExpired(String sExpired) {
		this.sExpired = sExpired;
	}
	/**
	 * @return the sAgreeValid
	 */
	public String getsAgreeValid() {
		return sAgreeValid;
	}
	/**
	 * @param sAgreeValid the sAgreeValid to set
	 */
	public void setsAgreeValid(String sAgreeValid) {
		this.sAgreeValid = sAgreeValid;
	}
	/**
	 * @return the kidiInfo
	 */
	public String getKidiInfo() {
		return kidiInfo;
	}
	/**
	 * @param kidiInfo the kidiInfo to set
	 */
	public void setKidiInfo(String kidiInfo) {
		this.kidiInfo = kidiInfo;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
}
