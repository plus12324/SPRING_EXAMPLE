/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Code/Name, Key/Value PAIR DTO
 * @author ��â��(slander)
 */
@SuppressWarnings("serial")
@XmlRootElement(name = "pairDTO")
public class PairDTO implements Serializable {

	/** key */
	private String key;

	/** value */
	private String value;

	/** Contructor */
	public PairDTO() {
	}

	/**
	 * key ��ȯ�Ѵ�.
	 * @return key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * key �����Ѵ�.
	 * @param key key
	 */
	public void setKey(final String key) {
		this.key = key;
	}

	/**
	 * value ��ȯ�Ѵ�.
	 * @return value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * value �����Ѵ�.
	 * @param value value
	 */
	public void setValue(final String value) {
		this.value = value;
	}
}
