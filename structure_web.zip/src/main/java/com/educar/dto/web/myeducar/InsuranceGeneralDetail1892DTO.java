/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� - �����ǿ� �Ǹ����� - ����ȸ ��� DTO
 * @author ���ѳ�
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetail1892DTO")
public class InsuranceGeneralDetail1892DTO {
	/** 	����ڸ�	**/ 
	private String 	sPolHolderName;
	/** 	������ڵ�	**/ 
	private String 	sPolHolderID;
	/** 	�Ǻ����ڸ�	**/ 
	private String 	sInsrdName;
	/** 	�Ǻ������ڵ�	**/ 
	private String 	sInsrdID;
	/** 	����ȣ	**/ 
	private String 	sPolicyNo;
	/** 	�����ǰ��	**/ 
	private String 	sInsPdtName;
	/** 	����ñ�	**/ 
	private String 	sFmdt	;
	/** 	���Թ��	**/ 
	private String 	sPytMthNam;
	/** 	�����ε����ּ�	**/ 
	private String 	sObjAddr	;
	/** 	�ڵ�����ȣ1	**/ 
	private String 	sMobileDDD;
	/** 	�ڵ�����ȣ2	**/ 
	private String 	sMobile1	;
	/** 	�ڵ�����ȣ3	**/ 
	private String 	sMobile2	;
	/** 	����ȭ��ȣ1	**/ 
	private String 	sHomTelDDD;
	/** 	����ȭ��ȣ2	**/ 
	private String 	sHomeTel1;
	/** 	����ȭ��ȣ3	**/ 
	private String 	sHomeTel2;
	/** 	ȸ����ȭ��ȣ1	**/ 
	private String 	sCorpTelDDD;
	/** 	ȸ����ȭ��ȣ2	**/ 
	private String 	sCorpTel1;
	/** 	ȸ����ȭ��ȣ3	**/ 
	private String 	sCorpTel2;
	/** 	����ڿ�����ȣ	**/ 
	private String 	sZipCode	;
	/** 	����ڱ⺻�ּ�	**/ 
	private String 	sVilAddr;
	/** 	����ڻ��ּ�	**/ 
	private String 	sDtlAddr;
	/** 	������̸���	**/ 
	private String 	sPolEmail;
	/** 	������	**/ 
	private String 	sRectDate;
	/** 	���Ժ����	**/ 
	private String 	nRectPrem;
	/** 	�������	**/ 
	private String 	sCashTypeName;
	/** 	���Դ㺸	**/ 
	private String 	sCovName;
	/** 	���Աݾ�	**/ 
	private String 	nTotOptAmt	;
	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}
	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}
	/**
	 * @return the sPolHolderID
	 */
	public String getsPolHolderID() {
		return sPolHolderID;
	}
	/**
	 * @param sPolHolderID the sPolHolderID to set
	 */
	public void setsPolHolderID(String sPolHolderID) {
		this.sPolHolderID = sPolHolderID;
	}
	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}
	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}
	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}
	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the sInsPdtName
	 */
	public String getsInsPdtName() {
		return sInsPdtName;
	}
	/**
	 * @param sInsPdtName the sInsPdtName to set
	 */
	public void setsInsPdtName(String sInsPdtName) {
		this.sInsPdtName = sInsPdtName;
	}
	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}
	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	/**
	 * @return the sPytMthNam
	 */
	public String getsPytMthNam() {
		return sPytMthNam;
	}
	/**
	 * @param sPytMthNam the sPytMthNam to set
	 */
	public void setsPytMthNam(String sPytMthNam) {
		this.sPytMthNam = sPytMthNam;
	}
	/**
	 * @return the sObjAddr
	 */
	public String getsObjAddr() {
		return sObjAddr;
	}
	/**
	 * @param sObjAddr the sObjAddr to set
	 */
	public void setsObjAddr(String sObjAddr) {
		this.sObjAddr = sObjAddr;
	}
	/**
	 * @return the sMobileDDD
	 */
	public String getsMobileDDD() {
		return sMobileDDD;
	}
	/**
	 * @param sMobileDDD the sMobileDDD to set
	 */
	public void setsMobileDDD(String sMobileDDD) {
		this.sMobileDDD = sMobileDDD;
	}
	/**
	 * @return the sMobile1
	 */
	public String getsMobile1() {
		return sMobile1;
	}
	/**
	 * @param sMobile1 the sMobile1 to set
	 */
	public void setsMobile1(String sMobile1) {
		this.sMobile1 = sMobile1;
	}
	/**
	 * @return the sMobile2
	 */
	public String getsMobile2() {
		return sMobile2;
	}
	/**
	 * @param sMobile2 the sMobile2 to set
	 */
	public void setsMobile2(String sMobile2) {
		this.sMobile2 = sMobile2;
	}
	/**
	 * @return the sHomTelDDD
	 */
	public String getsHomTelDDD() {
		return sHomTelDDD;
	}
	/**
	 * @param sHomTelDDD the sHomTelDDD to set
	 */
	public void setsHomTelDDD(String sHomTelDDD) {
		this.sHomTelDDD = sHomTelDDD;
	}
	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}
	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}
	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}
	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}
	/**
	 * @return the sCorpTelDDD
	 */
	public String getsCorpTelDDD() {
		return sCorpTelDDD;
	}
	/**
	 * @param sCorpTelDDD the sCorpTelDDD to set
	 */
	public void setsCorpTelDDD(String sCorpTelDDD) {
		this.sCorpTelDDD = sCorpTelDDD;
	}
	/**
	 * @return the sCorpTel1
	 */
	public String getsCorpTel1() {
		return sCorpTel1;
	}
	/**
	 * @param sCorpTel1 the sCorpTel1 to set
	 */
	public void setsCorpTel1(String sCorpTel1) {
		this.sCorpTel1 = sCorpTel1;
	}
	/**
	 * @return the sCorpTel2
	 */
	public String getsCorpTel2() {
		return sCorpTel2;
	}
	/**
	 * @param sCorpTel2 the sCorpTel2 to set
	 */
	public void setsCorpTel2(String sCorpTel2) {
		this.sCorpTel2 = sCorpTel2;
	}
	/**
	 * @return the sZipCode
	 */
	public String getsZipCode() {
		return sZipCode;
	}
	/**
	 * @param sZipCode the sZipCode to set
	 */
	public void setsZipCode(String sZipCode) {
		this.sZipCode = sZipCode;
	}
	/**
	 * @return the sVilAddr
	 */
	public String getsVilAddr() {
		return sVilAddr;
	}
	/**
	 * @param sVilAddr the sVilAddr to set
	 */
	public void setsVilAddr(String sVilAddr) {
		this.sVilAddr = sVilAddr;
	}
	/**
	 * @return the sDtlAddr
	 */
	public String getsDtlAddr() {
		return sDtlAddr;
	}
	/**
	 * @param sDtlAddr the sDtlAddr to set
	 */
	public void setsDtlAddr(String sDtlAddr) {
		this.sDtlAddr = sDtlAddr;
	}
	/**
	 * @return the sPolEmail
	 */
	public String getsPolEmail() {
		return sPolEmail;
	}
	/**
	 * @param sPolEmail the sPolEmail to set
	 */
	public void setsPolEmail(String sPolEmail) {
		this.sPolEmail = sPolEmail;
	}
	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}
	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(String sRectDate) {
		this.sRectDate = sRectDate;
	}
	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}
	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}
	/**
	 * @return the sCashTypeName
	 */
	public String getsCashTypeName() {
		return sCashTypeName;
	}
	/**
	 * @param sCashTypeName the sCashTypeName to set
	 */
	public void setsCashTypeName(String sCashTypeName) {
		this.sCashTypeName = sCashTypeName;
	}
	/**
	 * @return the sCovName
	 */
	public String getsCovName() {
		return sCovName;
	}
	/**
	 * @param sCovName the sCovName to set
	 */
	public void setsCovName(String sCovName) {
		this.sCovName = sCovName;
	}
	/**
	 * @return the nTotOptAmt
	 */
	public String getnTotOptAmt() {
		return nTotOptAmt;
	}
	/**
	 * @param nTotOptAmt the nTotOptAmt to set
	 */
	public void setnTotOptAmt(String nTotOptAmt) {
		this.nTotOptAmt = nTotOptAmt;
	}
	
	
}
