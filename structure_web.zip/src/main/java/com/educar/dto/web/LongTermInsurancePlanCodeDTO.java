/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * ��⺸�� �÷���ȸ �ڵ� DTO
 * @author ������
 *
 */
public class LongTermInsurancePlanCodeDTO {
	/** �㺸�� **/
	private String TrtyUserDefnName;
	/** �㺸�ڵ� **/
	private String TrtyCd;
	/** �⺻�㺸���� (1:�⺻, 2:����)**/
	private String BascSlctFlagCd;
	/** �⺻�㺸�����ѱ۸� (�⺻, ����)**/
	private String BascSlctFlagCd_H;
	/** �Ǽպ��豸���ڵ� (ZZ:�ش繫 11:�Ƿ������ 12:�Ƿ��)**/
	private String PmmiInsurFlagCd;
	/** ��ʺ���Ư�࿩�� **/
	private String PronCmpsTrtyYn;
	/** ���ſ��౸���ڵ� (01:���о��� 02:�������� 03:���Ű���)**/
	private String RenwlUseCrFlagCd;
	/** ����Ư���ڵ� **/
	private String RenwlTrtyCd;
	/** �������������ڵ� (0:���о��� 1:���� 2:����)**/
	private String sGrntAccuFlagCd;
	/** ȭ��ǥ�ÿ��� **/
	private String sScrnIndcYn;
	/** Ư�౸���ڵ� (01:�ְ�� 02:����Ư�� 03:����Ư�� 04:������Ư��)**/
	private String TrtyFlagCd;
	/**
	 * <pre>
	 * Ư�������ڵ� 
	 * 11 : �⺻��� ����κ� ���ؽ� ������
	 * 12 : �⺻��� ����κ� ���ؽ� �񰻽���
	 * 21 : �⺻��� ����κ� �ڿ��� ������
	 * 22 : �⺻��� ����κ� �ڿ��� �񰻽���
	 * 31 : �⺻��� �����κ� ���������и���
	 * 32 : �⺻��� �����κ� TheK��
	 * 51 : ����Ư�� ����κ� ���ؽ� ������
	 * 52 : ����Ư�� ����κ� ���ؽ� �񰻽���
	 * 61 : ����Ư�� ����κ� �ڿ��� ������
	 * 62 : ����Ư�� ����κ� �ڿ��� �񰻽���
	 * </pre>
	 **/
	private String TrtyTypeCd;
	/** ����Ⱓ�ڵ� **/
	private String sInsurTermCd;
	/** ���ԱⰣ�ڵ� **/
	private String sPaymTermCd;

	/** ��Ű���ڵ� (������Ű���ڵ峢�� ���ÿ� ����ó��) **/
	private String sPkgCd;
	/**
	 * <pre>
	 * �׷��ڵ�
	 * �����Ϸ��� �ϴ� Ư�� A�� �����Ϸ��� �ϴ� Ư�� B üũ�Ѵٰ� �� ��� A�� 
	 * sExcluGroupCd1 ~ sExcluGroupCd5 �� ��ϵǾ� �ִ� �ڵ尡 B�� sGroupCd���� Ȯ���Ͽ� ���ɺҰ�ó��.
	 * </pre>
	 **/
	private String sGroupCd;
	/** ��Ÿ�׷��ڵ�1 **/
	private String sExcluGroupCd1;
	/** ��Ÿ�׷��ڵ�2 **/
	private String sExcluGroupCd2;
	/** ��Ÿ�׷��ڵ�3 **/
	private String sExcluGroupCd3;
	/** ��Ÿ�׷��ڵ�4 **/
	private String sExcluGroupCd4;
	/** ��Ÿ�׷��ڵ�5 **/
	private String sExcluGroupCd5;

	/** ����ݾ׸� **/
	private String sHnglCdName;
	/** ����ݾ� **/
	private String sCd;
	/** Ư���ڵ� **/
	private String sTrtyCd;

	/** ����Ⱓ�� **/
	private String sInsurTermName;
	/** ���ԱⰣ�� **/
	private String sPaymTermName;
	
	//ȭ�纸��
	/** 	����������	 **/ 
	private String 	TrtyObjtFlag;
	/** 	���غ���ᱸ��1	 **/ 
	private String 	StndPremTablFlag1;
	/** 	���غ���ᱸ��2	 **/ 
	private String 	StndPremTablFlag2;
	/** 	���غ���ᱸ��3	 **/ 
	private String 	StndPremTablFlag3;
	/** 	���غ���ᱸ��4	 **/ 
	private String 	StndPremTablFlag4;
	/** 	���غ���ᱸ��5	 **/ 
	private String 	StndPremTablFlag5;
	/** 	�ι�����	 **/ 
	private String 	sPsnPrprtGroupFlgcd;
	/** 	Ư�����	 **/ 
	private String 	nPsnPrprtGroupSeqno;
	
	/**
	 * @return the trtyUserDefnName
	 */
	public String getTrtyUserDefnName() {
		return TrtyUserDefnName;
	}

	/**
	 * @param trtyUserDefnName the trtyUserDefnName to set
	 */
	public void setTrtyUserDefnName(final String trtyUserDefnName) {
		TrtyUserDefnName = trtyUserDefnName;
	}

	/**
	 * @return the trtyCd
	 */
	public String getTrtyCd() {
		return TrtyCd;
	}

	/**
	 * @param trtyCd the trtyCd to set
	 */
	public void setTrtyCd(final String trtyCd) {
		TrtyCd = trtyCd;
	}

	/**
	 * @return the bascSlctFlagCd
	 */
	public String getBascSlctFlagCd() {
		return BascSlctFlagCd;
	}

	/**
	 * @param bascSlctFlagCd the bascSlctFlagCd to set
	 */
	public void setBascSlctFlagCd(final String bascSlctFlagCd) {
		BascSlctFlagCd = bascSlctFlagCd;
	}

	/**
	 * @return the bascSlctFlagCd_H
	 */
	public String getBascSlctFlagCd_H() {
		return BascSlctFlagCd_H;
	}

	/**
	 * @param bascSlctFlagCd_H the bascSlctFlagCd_H to set
	 */
	public void setBascSlctFlagCd_H(final String bascSlctFlagCd_H) {
		BascSlctFlagCd_H = bascSlctFlagCd_H;
	}

	/**
	 * @return the pmmiInsurFlagCd
	 */
	public String getPmmiInsurFlagCd() {
		return PmmiInsurFlagCd;
	}

	/**
	 * @param pmmiInsurFlagCd the pmmiInsurFlagCd to set
	 */
	public void setPmmiInsurFlagCd(final String pmmiInsurFlagCd) {
		PmmiInsurFlagCd = pmmiInsurFlagCd;
	}

	/**
	 * @return the pronCmpsTrtyYn
	 */
	public String getPronCmpsTrtyYn() {
		return PronCmpsTrtyYn;
	}

	/**
	 * @param pronCmpsTrtyYn the pronCmpsTrtyYn to set
	 */
	public void setPronCmpsTrtyYn(final String pronCmpsTrtyYn) {
		PronCmpsTrtyYn = pronCmpsTrtyYn;
	}

	/**
	 * @return the renwlUseCrFlagCd
	 */
	public String getRenwlUseCrFlagCd() {
		return RenwlUseCrFlagCd;
	}

	/**
	 * @param renwlUseCrFlagCd the renwlUseCrFlagCd to set
	 */
	public void setRenwlUseCrFlagCd(final String renwlUseCrFlagCd) {
		RenwlUseCrFlagCd = renwlUseCrFlagCd;
	}

	/**
	 * @return the renwlTrtyCd
	 */
	public String getRenwlTrtyCd() {
		return RenwlTrtyCd;
	}

	/**
	 * @param renwlTrtyCd the renwlTrtyCd to set
	 */
	public void setRenwlTrtyCd(final String renwlTrtyCd) {
		RenwlTrtyCd = renwlTrtyCd;
	}

	/**
	 * @return the sGrntAccuFlagCd
	 */
	public String getsGrntAccuFlagCd() {
		return sGrntAccuFlagCd;
	}

	/**
	 * @param sGrntAccuFlagCd the sGrntAccuFlagCd to set
	 */
	public void setsGrntAccuFlagCd(final String sGrntAccuFlagCd) {
		this.sGrntAccuFlagCd = sGrntAccuFlagCd;
	}

	/**
	 * @return the sScrnIndcYn
	 */
	public String getsScrnIndcYn() {
		return sScrnIndcYn;
	}

	/**
	 * @param sScrnIndcYn the sScrnIndcYn to set
	 */
	public void setsScrnIndcYn(final String sScrnIndcYn) {
		this.sScrnIndcYn = sScrnIndcYn;
	}

	/**
	 * @return the trtyFlagCd
	 */
	public String getTrtyFlagCd() {
		return TrtyFlagCd;
	}

	/**
	 * @param trtyFlagCd the trtyFlagCd to set
	 */
	public void setTrtyFlagCd(final String trtyFlagCd) {
		TrtyFlagCd = trtyFlagCd;
	}

	/**
	 * @return the trtyTypeCd
	 */
	public String getTrtyTypeCd() {
		return TrtyTypeCd;
	}

	/**
	 * @param trtyTypeCd the trtyTypeCd to set
	 */
	public void setTrtyTypeCd(final String trtyTypeCd) {
		TrtyTypeCd = trtyTypeCd;
	}

	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}

	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(final String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}

	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}

	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(final String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}

	/**
	 * @return the sPkgCd
	 */
	public String getsPkgCd() {
		return sPkgCd;
	}

	/**
	 * @param sPkgCd the sPkgCd to set
	 */
	public void setsPkgCd(final String sPkgCd) {
		this.sPkgCd = sPkgCd;
	}

	/**
	 * @return the sGroupCd
	 */
	public String getsGroupCd() {
		return sGroupCd;
	}

	/**
	 * @param sGroupCd the sGroupCd to set
	 */
	public void setsGroupCd(final String sGroupCd) {
		this.sGroupCd = sGroupCd;
	}

	/**
	 * @return the sExcluGroupCd1
	 */
	public String getsExcluGroupCd1() {
		return sExcluGroupCd1;
	}

	/**
	 * @param sExcluGroupCd1 the sExcluGroupCd1 to set
	 */
	public void setsExcluGroupCd1(final String sExcluGroupCd1) {
		this.sExcluGroupCd1 = sExcluGroupCd1;
	}

	/**
	 * @return the sExcluGroupCd2
	 */
	public String getsExcluGroupCd2() {
		return sExcluGroupCd2;
	}

	/**
	 * @param sExcluGroupCd2 the sExcluGroupCd2 to set
	 */
	public void setsExcluGroupCd2(final String sExcluGroupCd2) {
		this.sExcluGroupCd2 = sExcluGroupCd2;
	}

	/**
	 * @return the sExcluGroupCd3
	 */
	public String getsExcluGroupCd3() {
		return sExcluGroupCd3;
	}

	/**
	 * @param sExcluGroupCd3 the sExcluGroupCd3 to set
	 */
	public void setsExcluGroupCd3(final String sExcluGroupCd3) {
		this.sExcluGroupCd3 = sExcluGroupCd3;
	}

	/**
	 * @return the sExcluGroupCd4
	 */
	public String getsExcluGroupCd4() {
		return sExcluGroupCd4;
	}

	/**
	 * @param sExcluGroupCd4 the sExcluGroupCd4 to set
	 */
	public void setsExcluGroupCd4(final String sExcluGroupCd4) {
		this.sExcluGroupCd4 = sExcluGroupCd4;
	}

	/**
	 * @return the sExcluGroupCd5
	 */
	public String getsExcluGroupCd5() {
		return sExcluGroupCd5;
	}

	/**
	 * @param sExcluGroupCd5 the sExcluGroupCd5 to set
	 */
	public void setsExcluGroupCd5(final String sExcluGroupCd5) {
		this.sExcluGroupCd5 = sExcluGroupCd5;
	}

	/**
	 * @return the sHnglCdName
	 */
	public String getsHnglCdName() {
		return sHnglCdName;
	}

	/**
	 * @param sHnglCdName the sHnglCdName to set
	 */
	public void setsHnglCdName(final String sHnglCdName) {
		this.sHnglCdName = sHnglCdName;
	}

	/**
	 * @return the sCd
	 */
	public String getsCd() {
		return sCd;
	}

	/**
	 * @param sCd the sCd to set
	 */
	public void setsCd(final String sCd) {
		this.sCd = sCd;
	}

	/**
	 * @return the sTrtyCd
	 */
	public String getsTrtyCd() {
		return sTrtyCd;
	}

	/**
	 * @param sTrtyCd the sTrtyCd to set
	 */
	public void setsTrtyCd(final String sTrtyCd) {
		this.sTrtyCd = sTrtyCd;
	}

	/**
	 * @return the sInsurTermName
	 */
	public String getsInsurTermName() {
		return sInsurTermName;
	}

	/**
	 * @param sInsurTermName the sInsurTermName to set
	 */
	public void setsInsurTermName(final String sInsurTermName) {
		this.sInsurTermName = sInsurTermName;
	}

	/**
	 * @return the sPaymTermName
	 */
	public String getsPaymTermName() {
		return sPaymTermName;
	}

	/**
	 * @param sPaymTermName the sPaymTermName to set
	 */
	public void setsPaymTermName(final String sPaymTermName) {
		this.sPaymTermName = sPaymTermName;
	}

	/**
	 * @return the trtyObjtFlag
	 */
	public String getTrtyObjtFlag() {
		return TrtyObjtFlag;
	}

	/**
	 * @param trtyObjtFlag the trtyObjtFlag to set
	 */
	public void setTrtyObjtFlag(String trtyObjtFlag) {
		TrtyObjtFlag = trtyObjtFlag;
	}

	/**
	 * @return the stndPremTablFlag1
	 */
	public String getStndPremTablFlag1() {
		return StndPremTablFlag1;
	}

	/**
	 * @param stndPremTablFlag1 the stndPremTablFlag1 to set
	 */
	public void setStndPremTablFlag1(String stndPremTablFlag1) {
		StndPremTablFlag1 = stndPremTablFlag1;
	}

	/**
	 * @return the stndPremTablFlag2
	 */
	public String getStndPremTablFlag2() {
		return StndPremTablFlag2;
	}

	/**
	 * @param stndPremTablFlag2 the stndPremTablFlag2 to set
	 */
	public void setStndPremTablFlag2(String stndPremTablFlag2) {
		StndPremTablFlag2 = stndPremTablFlag2;
	}

	/**
	 * @return the stndPremTablFlag3
	 */
	public String getStndPremTablFlag3() {
		return StndPremTablFlag3;
	}

	/**
	 * @param stndPremTablFlag3 the stndPremTablFlag3 to set
	 */
	public void setStndPremTablFlag3(String stndPremTablFlag3) {
		StndPremTablFlag3 = stndPremTablFlag3;
	}

	/**
	 * @return the stndPremTablFlag4
	 */
	public String getStndPremTablFlag4() {
		return StndPremTablFlag4;
	}

	/**
	 * @param stndPremTablFlag4 the stndPremTablFlag4 to set
	 */
	public void setStndPremTablFlag4(String stndPremTablFlag4) {
		StndPremTablFlag4 = stndPremTablFlag4;
	}

	/**
	 * @return the stndPremTablFlag5
	 */
	public String getStndPremTablFlag5() {
		return StndPremTablFlag5;
	}

	/**
	 * @param stndPremTablFlag5 the stndPremTablFlag5 to set
	 */
	public void setStndPremTablFlag5(String stndPremTablFlag5) {
		StndPremTablFlag5 = stndPremTablFlag5;
	}

	/**
	 * @return the sPsnPrprtGroupFlgcd
	 */
	public String getsPsnPrprtGroupFlgcd() {
		return sPsnPrprtGroupFlgcd;
	}

	/**
	 * @param sPsnPrprtGroupFlgcd the sPsnPrprtGroupFlgcd to set
	 */
	public void setsPsnPrprtGroupFlgcd(String sPsnPrprtGroupFlgcd) {
		this.sPsnPrprtGroupFlgcd = sPsnPrprtGroupFlgcd;
	}

	/**
	 * @return the nPsnPrprtGroupSeqno
	 */
	public String getnPsnPrprtGroupSeqno() {
		return nPsnPrprtGroupSeqno;
	}

	/**
	 * @param nPsnPrprtGroupSeqno the nPsnPrprtGroupSeqno to set
	 */
	public void setnPsnPrprtGroupSeqno(String nPsnPrprtGroupSeqno) {
		this.nPsnPrprtGroupSeqno = nPsnPrprtGroupSeqno;
	}

}
