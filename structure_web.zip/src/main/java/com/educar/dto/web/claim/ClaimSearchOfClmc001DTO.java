/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.StringUtils;

/**
 * �����������ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "compensationSearchOfClmc001DTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimSearchOfClmc001DTO {
	/** ���谡���� **/
	private String sInsuredName;
	/** �ֹε�Ϲ�ȣ **/
	private String sInsuredCode;
	/** ������ȣ **/
	private String sCarKorName;
	/** ������ȣ **/
	private String sAccidentNo;
	/** ������� **/
	private String sAcctDate;
	/** ����ð� **/
	private String sAcctTime;
	/** ������1 **/
	private String sAcctAddr1;
	/** ������2 **/
	private String sAcctAddr2;
	/** ������ **/
	private String sDrvName;
	/** �������� **/
	private String sLicenseRegionName;
	/** �����ȣ **/
	private String sLicenseNo;
	/** ����1 **/
	private String sBI1;
	/** ����2 **/
	private String sBI2;
	/** �빰 **/
	private String sPD;
	/** ���� **/
	private String sOAD;
	/** �ڼ� **/
	private String sSIA;
	/** ������ **/
	private String sMU;
	/** ������ **/
	private String sDRV;
	/** �÷��� **/
	private String sPLUS;
	/** ����㺸 **/
	private String sAcctPawn;

	/**
	 * @return the sBI2
	 */
	public String getsBI2() {
		return sBI2;
	}

	/**
	 * @param sBI2 the sBI2 to set
	 */
	public void setsBI2(final String sBI2) {
		this.sBI2 = sBI2;
	}

	/**
	 * @return the sPD
	 */
	public String getsPD() {
		return sPD;
	}

	/**
	 * @param sPD the sPD to set
	 */
	public void setsPD(final String sPD) {
		this.sPD = sPD;
	}

	/**
	 * @return the sOAD
	 */
	public String getsOAD() {
		return sOAD;
	}

	/**
	 * @param sOAD the sOAD to set
	 */
	public void setsOAD(final String sOAD) {
		this.sOAD = sOAD;
	}

	/**
	 * @return the sSIA
	 */
	public String getsSIA() {
		return sSIA;
	}

	/**
	 * @param sSIA the sSIA to set
	 */
	public void setsSIA(final String sSIA) {
		this.sSIA = sSIA;
	}

	/**
	 * @return the sMU
	 */
	public String getsMU() {
		return sMU;
	}

	/**
	 * @param sMU the sMU to set
	 */
	public void setsMU(final String sMU) {
		this.sMU = sMU;
	}

	/**
	 * @return the sDRV
	 */
	public String getsDRV() {
		return sDRV;
	}

	/**
	 * @param sDRV the sDRV to set
	 */
	public void setsDRV(final String sDRV) {
		this.sDRV = sDRV;
	}

	/**
	 * @return the sPLUS
	 */
	public String getsPLUS() {
		return sPLUS;
	}

	/**
	 * @param sPLUS the sPLUS to set
	 */
	public void setsPLUS(final String sPLUS) {
		this.sPLUS = sPLUS;
	}

	/**
	 * @return the sInsuredName
	 */
	public String getsInsuredName() {
		return sInsuredName;
	}

	/**
	 * @param sInsuredName the sInsuredName to set
	 */
	public void setsInsuredName(final String sInsuredName) {
		this.sInsuredName = sInsuredName;
	}

	/**
	 * @return the sInsuredCode
	 */
	public String getsInsuredCode() {
		return sInsuredCode;
	}

	/**
	 * @param sInsuredCode the sInsuredCode to set
	 */
	public void setsInsuredCode(final String sInsuredCode) {
		this.sInsuredCode = sInsuredCode;
	}

	/**
	 * @return the sCarKorName
	 */
	public String getsCarKorName() {
		return sCarKorName;
	}

	/**
	 * @param sCarKorName the sCarKorName to set
	 */
	public void setsCarKorName(final String sCarKorName) {
		this.sCarKorName = sCarKorName;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctTime
	 */
	public String getsAcctTime() {
		return sAcctTime;
	}

	/**
	 * @param sAcctTime the sAcctTime to set
	 */
	public void setsAcctTime(final String sAcctTime) {
		this.sAcctTime = sAcctTime;
	}

	/**
	 * @return the sAcctAddr1
	 */
	public String getsAcctAddr1() {
		return sAcctAddr1;
	}

	/**
	 * @param sAcctAddr1 the sAcctAddr1 to set
	 */
	public void setsAcctAddr1(final String sAcctAddr1) {
		this.sAcctAddr1 = sAcctAddr1;
	}

	/**
	 * @return the sAcctAddr2
	 */
	public String getsAcctAddr2() {
		return sAcctAddr2;
	}

	/**
	 * @param sAcctAddr2 the sAcctAddr2 to set
	 */
	public void setsAcctAddr2(final String sAcctAddr2) {
		this.sAcctAddr2 = sAcctAddr2;
	}

	/**
	 * @return the sDrvName
	 */
	public String getsDrvName() {
		return sDrvName;
	}

	/**
	 * @param sDrvName the sDrvName to set
	 */
	public void setsDrvName(final String sDrvName) {
		this.sDrvName = sDrvName;
	}

	/**
	 * @return the sLicenseRegionName
	 */
	public String getsLicenseRegionName() {
		return sLicenseRegionName;
	}

	/**
	 * @param sLicenseRegionName the sLicenseRegionName to set
	 */
	public void setsLicenseRegionName(final String sLicenseRegionName) {
		this.sLicenseRegionName = sLicenseRegionName;
	}

	/**
	 * @return the sLicenseNo
	 */
	public String getsLicenseNo() {
		return sLicenseNo;
	}

	/**
	 * @param sLicenseNo the sLicenseNo to set
	 */
	public void setsLicenseNo(final String sLicenseNo) {
		this.sLicenseNo = sLicenseNo;
	}

	/**
	 * @return the sBI1
	 */
	public String getsBI1() {
		return sBI1.equals(BigInteger.ONE.toString()) ? "����" : StringUtils.EMPTY;
	}

	/**
	 * @param sBI1 the sBI1 to set
	 */
	public void setsBI1(final String sBI1) {
		this.sBI1 = sBI1;
	}

	/**
	 * @return the sAcctPawn
	 */
	public String getsAcctPawn() {
		return sAcctPawn;
	}

	/**
	 * �㺸 ���� (�� �㺸�� 1(����), 0(�̰���) ���� ���� ó��)
	 * ���� �㺸�� ���ٷ� ǥ��
	 * @param sAcctPawn the sAcctPawn to set
	 */
	public void setsAcctPawn() {
		final StringBuilder sb = new StringBuilder();
		sb.append(sBI1.equals(BigInteger.ONE.toString()) ? "����1 " : StringUtils.EMPTY).append(sBI2.equals(BigInteger.ONE.toString()) ? "����2 " : StringUtils.EMPTY)
				.append(sPD.equals(BigInteger.ONE.toString()) ? "�빰 " : StringUtils.EMPTY).append(sOAD.equals(BigInteger.ONE.toString()) ? "���� " : StringUtils.EMPTY)
				.append(sSIA.equals(BigInteger.ONE.toString()) ? "�ڼ� " : StringUtils.EMPTY).append(sMU.equals(BigInteger.ONE.toString()) ? "������ " : StringUtils.EMPTY)
				.append(sDRV.equals(BigInteger.ONE.toString()) ? "������ " : StringUtils.EMPTY).append(sPLUS.equals(BigInteger.ONE.toString()) ? "�÷���" : StringUtils.EMPTY);
		this.sAcctPawn = sb.toString();
	}
}
