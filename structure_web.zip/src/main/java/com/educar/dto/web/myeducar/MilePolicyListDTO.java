/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Ư��/����������� - ���ϸ���������� - ��������Ÿ�����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "milePolicyListDTO")
public class MilePolicyListDTO {
	
	
	/** �Ǻ����� �ڵ� **/
	private String sInsrdID;
	/** ����⵵�� ���⳯¥ **/
	private String sLastYear;
	/** ����⵵�� �����س�¥ **/
	private String sNextYear;
	/** ����ȣ **/
	private String sPolicyNo;
	/** ���Ÿ�� **/
	private String sPolicyType;
	/** ����� **/
	private String sPolicyYM;
	/** ���SEQ **/
	private String sPolicySer;
	/** ������ȣ **/
	private String sPlateNo;
	/** ����Ⱓ **/
	private String sPolicyDate;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ��������Ÿ� **/
	private String nFirstDistance;
	public String getsInsrdID() {
		return sInsrdID;
	}
	public void setsInsrdID(String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}
	public String getsLastYear() {
		return sLastYear;
	}
	public void setsLastYear(String sLastYear) {
		this.sLastYear = sLastYear;
	}
	public String getsNextYear() {
		return sNextYear;
	}
	public void setsNextYear(String sNextYear) {
		this.sNextYear = sNextYear;
	}
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	public String getsPolicyType() {
		return sPolicyType;
	}
	public void setsPolicyType(String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}
	public String getsPolicyYM() {
		return sPolicyYM;
	}
	public void setsPolicyYM(String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}
	public String getsPolicySer() {
		return sPolicySer;
	}
	public void setsPolicySer(String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}
	public String getsPlateNo() {
		return sPlateNo;
	}
	public void setsPlateNo(String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}
	public String getsPolicyDate() {
		return sPolicyDate;
	}
	public void setsPolicyDate(String sPolicyDate) {
		this.sPolicyDate = sPolicyDate;
	}
	public String getsFmdt() {
		return sFmdt;
	}
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	public String getsTodt() {
		return sTodt;
	}
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	public String getnFirstDistance() {
		return nFirstDistance;
	}
	public void setnFirstDistance(String nFirstDistance) {
		this.nFirstDistance = nFirstDistance;
	}
	
	
}
