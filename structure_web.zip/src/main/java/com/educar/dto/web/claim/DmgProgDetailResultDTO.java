/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����������ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "dmgProgDetailResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class DmgProgDetailResultDTO {
	/** �����ȣ(������ȣ) **/
	private String sAcdNum;
	/** �����ڼ��� **/
	private String nDmgSeq;
	/** ������� **/
	private String sAcdDate;
	/** ����ð� **/
	private String sAcdTime;
	/** ������� **/
	private String sAcdType;
	/** ������ **/
	private String VilAddr;
	/** ������� **/
	private String sAcdCont;
	/** ����� **/
	private String sBankName;
	/** �����ڵ� **/
	private String sSupBankCd;
	/** ���¹�ȣ **/
	private String sSupAccountNo;

	/**
	 * @return the sAcdNum
	 */
	public String getsAcdNum() {
		return sAcdNum;
	}

	/**
	 * @param sAcdNum the sAcdNum to set
	 */
	public void setsAcdNum(final String sAcdNum) {
		this.sAcdNum = sAcdNum;
	}

	/**
	 * @return the nDmgSeq
	 */
	public String getnDmgSeq() {
		return nDmgSeq;
	}

	/**
	 * @param nDmgSeq the nDmgSeq to set
	 */
	public void setnDmgSeq(final String nDmgSeq) {
		this.nDmgSeq = nDmgSeq;
	}

	/**
	 * @return the sAcdDate
	 */
	public String getsAcdDate() {
		return sAcdDate;
	}

	/**
	 * @param sAcdDate the sAcdDate to set
	 */
	public void setsAcdDate(final String sAcdDate) {
		this.sAcdDate = sAcdDate;
	}

	/**
	 * @return the sAcdTime
	 */
	public String getsAcdTime() {
		return sAcdTime;
	}

	/**
	 * @param sAcdTime the sAcdTime to set
	 */
	public void setsAcdTime(final String sAcdTime) {
		this.sAcdTime = sAcdTime;
	}

	/**
	 * @return the sAcdType
	 */
	public String getsAcdType() {
		return sAcdType;
	}

	/**
	 * @param sAcdType the sAcdType to set
	 */
	public void setsAcdType(final String sAcdType) {
		this.sAcdType = sAcdType;
	}

	/**
	 * @return the vilAddr
	 */
	public String getVilAddr() {
		return VilAddr;
	}

	/**
	 * @param vilAddr the vilAddr to set
	 */
	public void setVilAddr(final String vilAddr) {
		VilAddr = vilAddr;
	}

	/**
	 * @return the sAcdCont
	 */
	public String getsAcdCont() {
		return sAcdCont;
	}

	/**
	 * @param sAcdCont the sAcdCont to set
	 */
	public void setsAcdCont(final String sAcdCont) {
		this.sAcdCont = sAcdCont;
	}

	/**
	 * @return the sBankName
	 */
	public String getsBankName() {
		return sBankName;
	}

	/**
	 * @param sBankName the sBankName to set
	 */
	public void setsBankName(final String sBankName) {
		this.sBankName = sBankName;
	}

	/**
	 * @return the sSupBankCd
	 */
	public String getsSupBankCd() {
		return sSupBankCd;
	}

	/**
	 * @param sSupBankCd the sSupBankCd to set
	 */
	public void setsSupBankCd(final String sSupBankCd) {
		this.sSupBankCd = sSupBankCd;
	}

	/**
	 * @return the sSupAccountNo
	 */
	public String getsSupAccountNo() {
		return sSupAccountNo;
	}

	/**
	 * @param sSupAccountNo the sSupAccountNo to set
	 */
	public void setsSupAccountNo(final String sSupAccountNo) {
		this.sSupAccountNo = sSupAccountNo;
	}

}
