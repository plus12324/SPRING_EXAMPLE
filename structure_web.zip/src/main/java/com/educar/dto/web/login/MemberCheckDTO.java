/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.login;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.bytes.CharacterSet;
import kr.co.conch.validator.annotation.bytes.ValidateByte;
import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.enumeration.LoginStatusEnum;

/**
 * �Ⱓ�� �α��� �������̽��� ���Ǵ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement
public class MemberCheckDTO {

	/** ID(��ȸ�� ID) **/
	private String ID;
	/** �ֹι�ȣ **/
	@ValidateByte(max = 15, charset = CharacterSet.EUCKR)
	private String sCustNo;
	/** �̸� **/
	@ValidateByte(max = 20, charset = CharacterSet.EUCKR)
	private String sName;
	/** ���� **/
	private String sSex;
	/** ���ڱ����ŷ�ȸ�� ���Կ��� **/
	@ValidateLength(max = 1)
	private String sEleYN;
	/** �ڵ������������� **/
	@ValidateLength(max = 1)
	private String sCarPolicyYN;
	/** �Ϲݰ��������� **/
	@ValidateLength(max = 1)
	private String sGenPolicyYN;
	/** ������������ **/
	@ValidateLength(max = 1)
	private String sLongtermPolicyYN;
	/** ������ȭ1 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 2, max = 4)
	private String sHomeTel1;
	/** ������ȭ2 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sHomeTel2;
	/** ������ȭ3 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 4, max = 4)
	private String sHomeTel3;
	/** ������ȭ1 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 2, max = 4)
	private String sOfficeTel1;
	/** ������ȭ2 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sOfficeTel2;
	/** ������ȭ3 **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 4, max = 4)
	private String sOfficeTel3;
	/** �繫�ǳ�����ȣ **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sInnerPhone;
	/** �޴���ȭ ���ڸ� **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 3)
	private String sCellPhone1;
	/** �޴���ȭ �߰��ڸ� **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sCellPhone2;
	/** �޴���ȭ ���ڸ� **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 4, max = 4)
	private String sCellPhone3;
	/** �ѽ���ȣ ���ڸ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sFax1;
	/** �ѽ���ȣ �߰��ڸ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sFax2;
	/** �ѽ���ȣ ���ڸ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Number)
	private String sFax3;
	/** �̸��� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEmail;
	/** ���ÿ�����ȣ ���ڸ�**/
	private String sZip1;
	/** ���ÿ�����ȣ ���ڸ�**/
	private String sZip2;
	/** ���ÿ�����ȣ**/
	private String sHomeZip;
	/** �����ּ� 1, �õ� **/
	private String sHomesAdrs1;
	/** �����ּ� 1, �ñ��� **/
	private String sHomesAdrs2;
	/** �����ּ� 1, ���鵿 **/
	private String sHomesAdrs3;
	/** ���ù���, ������ �ּ� **/
	private String sHomeAdrsAdd;
	/** ���� �ű��ּұ��� 0:���ּ�, 1:���ּ� **/
	@ValidateLength(max = 1)
	private String sHomeZipType;
	/** ���������ȣ eg) 21455 **/
	private String sOfficeZip;
	/** �����ּ�1 **/
	private String sOfficeAdrs1;
	/** �����ּ�2 **/
	private String sOfficeAdrs2;
	/** �����ּ�3 **/
	private String sOfficeAdrs3;
	/** �������, ������ �ּ� **/
	private String sOfficeAdrsAdd;
	/** ����ű��ּұ��� 0:���ּ�, 1:���ּ� **/
	@ValidateLength(max = 1)
	private String sOfficeZipType;
	/** ��ǰ�Ұ�(�����̿�)����, ȸ������ ��ǰ�Ұ� ��� ó�� �ΰ� **/
	@ValidateLength(max = 1)
	private String s04AgmYn;
	/** ��ǰ�Ұ� �����̿� ��ȭ�ź� **/
	private String s04CallReject;
	/** ��ǰ�Ұ� �����̿� DM�ź� **/
	private String s04DMReject;
	/** ��ǰ�Ұ� �����̿� FAX�ź� **/
	private String s04FaxReject;
	/** ��ǰ�Ұ� �����̿� EMAIL�ź� **/
	private String s04EmailReject;
	/** ��ǰ�Ұ� �����̿� SMS�ź� **/
	private String s04SMSReject;
	/** ��ǰ�Ұ�(����)����, ȸ������ ��ǰ�Ұ� ��� 3-4 �ΰ� **/
	@ValidateLength(max = 1)
	private String s41AgmYn;
	/** ��ǰ�Ұ� ���� ��ȭ�ź� **/
	@ValidateLength(max = 1)
	private String s41CallReject;
	/** ��ǰ�Ұ� ���� DM�ź� **/
	@ValidateLength(max = 1)
	private String s41DMReject;
	/** ��ǰ�Ұ� ���� FAX�ź� **/
	@ValidateLength(max = 1)
	private String s41FaxReject;
	/** ��ǰ�Ұ� ���� EMAIL�ź� **/
	@ValidateLength(max = 1)
	private String s41EmailReject;
	/** ��ǰ�Ұ� ���� SMS�ź� **/
	@ValidateLength(max = 1)
	private String s41SMSReject;
	/** ��й�ȣ ����5ȸ ���� flag **/
	@ValidateLength(max = 2)
	private String sPassFlag;
	

	/**
	 * @return the s04CallReject
	 */
	public String getS04CallReject() {
		return s04CallReject;
	}

	/**
	 * @param s04CallReject the s04CallReject to set
	 */
	public void setS04CallReject(final String s04CallReject) {
		this.s04CallReject = s04CallReject;
	}

	/**
	 * @return the s04DMReject
	 */
	public String getS04DMReject() {
		return s04DMReject;
	}

	/**
	 * @param s04dmReject the s04DMReject to set
	 */
	public void setS04DMReject(final String s04dmReject) {
		s04DMReject = s04dmReject;
	}

	/**
	 * @return the s04FaxReject
	 */
	public String getS04FaxReject() {
		return s04FaxReject;
	}

	/**
	 * @param s04FaxReject the s04FaxReject to set
	 */
	public void setS04FaxReject(final String s04FaxReject) {
		this.s04FaxReject = s04FaxReject;
	}

	/**
	 * @return the s04EmailReject
	 */
	public String getS04EmailReject() {
		return s04EmailReject;
	}

	/**
	 * @param s04EmailReject the s04EmailReject to set
	 */
	public void setS04EmailReject(final String s04EmailReject) {
		this.s04EmailReject = s04EmailReject;
	}

	/**
	 * @return the s04SMSReject
	 */
	public String getS04SMSReject() {
		return s04SMSReject;
	}

	/**
	 * @param s04smsReject the s04SMSReject to set
	 */
	public void setS04SMSReject(final String s04smsReject) {
		s04SMSReject = s04smsReject;
	}

	/**
	 * @return the s41CallReject
	 */
	public String getS41CallReject() {
		return s41CallReject;
	}

	/**
	 * @param s41CallReject the s41CallReject to set
	 */
	public void setS41CallReject(final String s41CallReject) {
		this.s41CallReject = s41CallReject;
	}

	/**
	 * @return the s41DMReject
	 */
	public String getS41DMReject() {
		return s41DMReject;
	}

	/**
	 * @param s41dmReject the s41DMReject to set
	 */
	public void setS41DMReject(final String s41dmReject) {
		s41DMReject = s41dmReject;
	}

	/**
	 * @return the s41FaxReject
	 */
	public String getS41FaxReject() {
		return s41FaxReject;
	}

	/**
	 * @param s41FaxReject the s41FaxReject to set
	 */
	public void setS41FaxReject(final String s41FaxReject) {
		this.s41FaxReject = s41FaxReject;
	}

	/**
	 * @return the s41EmailReject
	 */
	public String getS41EmailReject() {
		return s41EmailReject;
	}

	/**
	 * @param s41EmailReject the s41EmailReject to set
	 */
	public void setS41EmailReject(final String s41EmailReject) {
		this.s41EmailReject = s41EmailReject;
	}

	/**
	 * @return the s41SMSReject
	 */
	public String getS41SMSReject() {
		return s41SMSReject;
	}

	/**
	 * @param s41smsReject the s41SMSReject to set
	 */
	public void setS41SMSReject(final String s41smsReject) {
		s41SMSReject = s41smsReject;
	}

	/** �α��� �����ͽ� **/
	private transient LoginStatusEnum loginStatus;

	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final String iD) {
		ID = iD;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sEleYN
	 */
	public String getsEleYN() {
		return sEleYN;
	}

	/**
	 * @param sEleYN the sEleYN to set
	 */
	public void setsEleYN(final String sEleYN) {
		this.sEleYN = sEleYN;
	}

	/**
	 * @return the sCarPolicyYN
	 */
	public String getsCarPolicyYN() {
		return sCarPolicyYN;
	}

	/**
	 * @param sCarPolicyYN the sCarPolicyYN to set
	 */
	public void setsCarPolicyYN(final String sCarPolicyYN) {
		this.sCarPolicyYN = sCarPolicyYN;
	}

	/**
	 * @return the sGenPolicyYN
	 */
	public String getsGenPolicyYN() {
		return sGenPolicyYN;
	}

	/**
	 * @param sGenPolicyYN the sGenPolicyYN to set
	 */
	public void setsGenPolicyYN(final String sGenPolicyYN) {
		this.sGenPolicyYN = sGenPolicyYN;
	}

	/**
	 * @return the sLongtermPolicyYN
	 */
	public String getsLongtermPolicyYN() {
		return sLongtermPolicyYN;
	}

	/**
	 * @param sLongtermPolicyYN the sLongtermPolicyYN to set
	 */
	public void setsLongtermPolicyYN(final String sLongtermPolicyYN) {
		this.sLongtermPolicyYN = sLongtermPolicyYN;
	}

	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}

	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(final String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}

	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}

	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(final String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}

	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}

	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(final String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}

	/**
	 * @return the sOfficeTel1
	 */
	public String getsOfficeTel1() {
		return sOfficeTel1;
	}

	/**
	 * @param sOfficeTel1 the sOfficeTel1 to set
	 */
	public void setsOfficeTel1(final String sOfficeTel1) {
		this.sOfficeTel1 = sOfficeTel1;
	}

	/**
	 * @return the sOfficeTel2
	 */
	public String getsOfficeTel2() {
		return sOfficeTel2;
	}

	/**
	 * @param sOfficeTel2 the sOfficeTel2 to set
	 */
	public void setsOfficeTel2(final String sOfficeTel2) {
		this.sOfficeTel2 = sOfficeTel2;
	}

	/**
	 * @return the sOfficeTel3
	 */
	public String getsOfficeTel3() {
		return sOfficeTel3;
	}

	/**
	 * @param sOfficeTel3 the sOfficeTel3 to set
	 */
	public void setsOfficeTel3(final String sOfficeTel3) {
		this.sOfficeTel3 = sOfficeTel3;
	}

	/**
	 * @return the sInnerPhone
	 */
	public String getsInnerPhone() {
		return sInnerPhone;
	}

	/**
	 * @param sInnerPhone the sInnerPhone to set
	 */
	public void setsInnerPhone(final String sInnerPhone) {
		this.sInnerPhone = sInnerPhone;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sHomesAdrs1
	 */
	public String getsHomesAdrs1() {
		return sHomesAdrs1;
	}

	/**
	 * @param sHomesAdrs1 the sHomesAdrs1 to set
	 */
	public void setsHomesAdrs1(final String sHomesAdrs1) {
		this.sHomesAdrs1 = sHomesAdrs1;
	}

	/**
	 * @return the sHomesAdrs2
	 */
	public String getsHomesAdrs2() {
		return sHomesAdrs2;
	}

	/**
	 * @param sHomesAdrs2 the sHomesAdrs2 to set
	 */
	public void setsHomesAdrs2(final String sHomesAdrs2) {
		this.sHomesAdrs2 = sHomesAdrs2;
	}

	/**
	 * @return the sHomesAdrs3
	 */
	public String getsHomesAdrs3() {
		return sHomesAdrs3;
	}

	/**
	 * @param sHomesAdrs3 the sHomesAdrs3 to set
	 */
	public void setsHomesAdrs3(final String sHomesAdrs3) {
		this.sHomesAdrs3 = sHomesAdrs3;
	}

	/**
	 * @return the sHomeAdrsAdd
	 */
	public String getsHomeAdrsAdd() {
		return sHomeAdrsAdd;
	}

	/**
	 * @param sHomeAdrsAdd the sHomeAdrsAdd to set
	 */
	public void setsHomeAdrsAdd(final String sHomeAdrsAdd) {
		this.sHomeAdrsAdd = sHomeAdrsAdd;
	}

	/**
	 * @return the sHomeZipType
	 */
	public String getsHomeZipType() {
		return sHomeZipType;
	}

	/**
	 * @param sHomeZipType the sHomeZipType to set
	 */
	public void setsHomeZipType(final String sHomeZipType) {
		this.sHomeZipType = sHomeZipType;
	}

	/**
	 * @return the sOfficeZip
	 */
	public String getsOfficeZip() {
		return sOfficeZip;
	}

	/**
	 * @param sOfficeZip the sOfficeZip to set
	 */
	public void setsOfficeZip(final String sOfficeZip) {
		this.sOfficeZip = sOfficeZip;
	}

	/**
	 * @return the sOfficeAdrs1
	 */
	public String getsOfficeAdrs1() {
		return sOfficeAdrs1;
	}

	/**
	 * @param sOfficeAdrs1 the sOfficeAdrs1 to set
	 */
	public void setsOfficeAdrs1(final String sOfficeAdrs1) {
		this.sOfficeAdrs1 = sOfficeAdrs1;
	}

	/**
	 * @return the sOfficeAdrs2
	 */
	public String getsOfficeAdrs2() {
		return sOfficeAdrs2;
	}

	/**
	 * @param sOfficeAdrs2 the sOfficeAdrs2 to set
	 */
	public void setsOfficeAdrs2(final String sOfficeAdrs2) {
		this.sOfficeAdrs2 = sOfficeAdrs2;
	}

	/**
	 * @return the sOfficeAdrs3
	 */
	public String getsOfficeAdrs3() {
		return sOfficeAdrs3;
	}

	/**
	 * @param sOfficeAdrs3 the sOfficeAdrs3 to set
	 */
	public void setsOfficeAdrs3(final String sOfficeAdrs3) {
		this.sOfficeAdrs3 = sOfficeAdrs3;
	}

	/**
	 * @return the sOfficeAdrsAdd
	 */
	public String getsOfficeAdrsAdd() {
		return sOfficeAdrsAdd;
	}

	/**
	 * @param sOfficeAdrsAdd the sOfficeAdrsAdd to set
	 */
	public void setsOfficeAdrsAdd(final String sOfficeAdrsAdd) {
		this.sOfficeAdrsAdd = sOfficeAdrsAdd;
	}

	/**
	 * @return the sOfficeZipType
	 */
	public String getsOfficeZipType() {
		return sOfficeZipType;
	}

	/**
	 * @param sOfficeZipType the sOfficeZipType to set
	 */
	public void setsOfficeZipType(final String sOfficeZipType) {
		this.sOfficeZipType = sOfficeZipType;
	}

	/**
	 * @return the loginStatus
	 */
	public LoginStatusEnum getLoginStatus() {
		return loginStatus;
	}

	/**
	 * @param loginStatus the loginStatus to set
	 */
	public void setLoginStatus(final LoginStatusEnum loginStatus) {
		this.loginStatus = loginStatus;
	}

	/**
	 * @return the s04AgmYn
	 */
	public String getS04AgmYn() {
		return s04AgmYn;
	}

	/**
	 * @param s04AgmYn the s04AgmYn to set
	 */
	public void setS04AgmYn(final String s04AgmYn) {
		this.s04AgmYn = s04AgmYn;
	}

	/**
	 * @return the s41AgmYn
	 */
	public String getS41AgmYn() {
		return s41AgmYn;
	}

	/**
	 * @param s41AgmYn the s41AgmYn to set
	 */
	public void setS41AgmYn(final String s41AgmYn) {
		this.s41AgmYn = s41AgmYn;
	}

	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}

	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(final String sFax1) {
		this.sFax1 = sFax1;
	}

	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}

	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(final String sFax2) {
		this.sFax2 = sFax2;
	}

	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}

	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(final String sFax3) {
		this.sFax3 = sFax3;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @return the sHomeZip
	 */
	public String getsHomeZip() {
		return sHomeZip;
	}

	/**
	 * @param sHomeZip the sHomeZip to set
	 */
	public void setsHomeZip(final String sHomeZip) {
		this.sHomeZip = sHomeZip;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the sPassFlag
	 */
	public String getsPassFlag() {
		return sPassFlag;
	}

	/**
	 * @param sPassFlag the sPassFlag to set
	 */
	public void setsPassFlag(String sPassFlag) {
		this.sPassFlag = sPassFlag;
	}
}
