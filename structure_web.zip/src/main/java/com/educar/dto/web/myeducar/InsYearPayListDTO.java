/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ������ ���Գ���
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insYearPayListDTO")
public class InsYearPayListDTO {
	/** 	����ȣ	 **/ 
	private String 	sCrNo	;
	/** 	����	 **/ 
	private String 	nYearCnt;

	/** 	����ȸ��	 **/ 
	private String 	nPaymSeq	;
	/** 	�ش��	 **/ 
	private String 	sPaymMthy	;
	/** 	��������	 **/ 
	private String 	sRecpDate	;
	/** 	���Ժ����	 **/ 
	private String 	nRecpPrem	;
	/** 	�������	 **/ 
	private String 	sCmMetdName	;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	
	
	/**
	 * @return the nYearCnt
	 */
	public String getnYearCnt() {
		return nYearCnt;
	}
	/**
	 * @param nYearCnt the nYearCnt to set
	 */
	public void setnYearCnt(String nYearCnt) {
		this.nYearCnt = nYearCnt;
	}
	/**
	 * @return the nPaymSeq
	 */
	public String getnPaymSeq() {
		return nPaymSeq;
	}
	/**
	 * @param nPaymSeq the nPaymSeq to set
	 */
	public void setnPaymSeq(String nPaymSeq) {
		this.nPaymSeq = nPaymSeq;
	}
	/**
	 * @return the sPaymMthy
	 */
	public String getsPaymMthy() {
		return sPaymMthy;
	}
	/**
	 * @param sPaymMthy the sPaymMthy to set
	 */
	public void setsPaymMthy(String sPaymMthy) {
		this.sPaymMthy = sPaymMthy;
	}
	/**
	 * @return the sRecpDate
	 */
	public String getsRecpDate() {
		return sRecpDate;
	}
	/**
	 * @param sRecpDate the sRecpDate to set
	 */
	public void setsRecpDate(String sRecpDate) {
		this.sRecpDate = sRecpDate;
	}
	/**
	 * @return the nRecpPrem
	 */
	public String getnRecpPrem() {
		return nRecpPrem;
	}
	/**
	 * @param nRecpPrem the nRecpPrem to set
	 */
	public void setnRecpPrem(String nRecpPrem) {
		this.nRecpPrem = nRecpPrem;
	}
	/**
	 * @return the sCmMetdName
	 */
	public String getsCmMetdName() {
		return sCmMetdName;
	}
	/**
	 * @param sCmMetdName the sCmMetdName to set
	 */
	public void setsCmMetdName(String sCmMetdName) {
		this.sCmMetdName = sCmMetdName;
	}
	
	
}
