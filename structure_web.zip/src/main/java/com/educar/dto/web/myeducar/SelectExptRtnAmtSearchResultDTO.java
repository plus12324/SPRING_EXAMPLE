/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ȯ�޳��� ����ȯ�ޱ���ȸ �����ؾ�ȯ�ޱݻ��⳻�� ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectExptRtnAmtSearchResultDTO")
public class SelectExptRtnAmtSearchResultDTO {
	/** ��������Ŀ���ݾ� **/
	private String nLoanDuctAftrExptAmt;

	/**
	 * @return the nLoanDuctAftrExptAmt
	 */
	public String getnLoanDuctAftrExptAmt() {
		return nLoanDuctAftrExptAmt;
	}

	/**
	 * @param nLoanDuctAftrExptAmt the nLoanDuctAftrExptAmt to set
	 */
	public void setnLoanDuctAftrExptAmt(final String nLoanDuctAftrExptAmt) {
		this.nLoanDuctAftrExptAmt = nLoanDuctAftrExptAmt;
	}

}
