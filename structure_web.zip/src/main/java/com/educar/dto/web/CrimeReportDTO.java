/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "crimeReportDTO")
public class CrimeReportDTO {
	/** �̸� **/
	private String sRepName;
	/** �ڵ�����ȣ1 **/
	private String sCellPhone1;
	/** �ڵ�����ȣ2 **/
	private String sCellPhone2;
	/** �ڵ�����ȣ3 **/
	private String sCellPhone3;
	/** ���� **/
	private String sTitle;
	/** ���� **/
	private String sContents;
	/** �̸��� **/
	private String sEmail;
	/** �����̿뵿�ǿ��� (Y:����, N �Ǵ� �׿� : ����) **/
	private String sAgreeYn;

	/**
	 * @return the sRepName
	 */
	public String getsRepName() {
		return sRepName;
	}

	/**
	 * @param sRepName the sRepName to set
	 */
	public void setsRepName(final String sRepName) {
		this.sRepName = sRepName;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContents
	 */
	public String getsContents() {
		return sContents;
	}

	/**
	 * @param sContents the sContents to set
	 */
	public void setsContents(final String sContents) {
		this.sContents = sContents;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sAgreeYn
	 */
	public String getsAgreeYn() {
		return sAgreeYn;
	}

	/**
	 * @param sAgreeYn the sAgreeYn to set
	 */
	public void setsAgreeYn(final String sAgreeYn) {
		this.sAgreeYn = sAgreeYn;
	}

}
