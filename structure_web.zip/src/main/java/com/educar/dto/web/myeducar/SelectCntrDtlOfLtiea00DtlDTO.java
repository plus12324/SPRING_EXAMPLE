/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCntrDtlOfLtiea00DtlDTO")
public class SelectCntrDtlOfLtiea00DtlDTO {
	/** ����ȣ **/
	private String sCrNo;
	/** ��ǰ�� **/
	private String sGdNm;
	/** ����ڸ� **/
	private String sCrtorName;
	/** ������ֹι�ȣ **/
	private String sCrtorCd;
	/** ���������� **/
	private String sInsurStrtdate;
	/** ����������� **/
	private String sInsurEndDate;
	/** ���ԱⰣ�� **/
	private String sPaymTermCdNm;
	/** �������Կ��� **/
	private String sFinalPaymMthyNm;
	/** �����ֱ�� **/
	private String sPaymCyclCdNm;
	/** �ѳ��Ժ���� **/
	private String nTotPaymPrem;
	/** ���뺸��� **/
	private String nApplPrem;
	/** ���ݹ���� **/
	private String sCmMetdNm;
	/** ����� **/
	private String sBankCdNm;
	/** ���¹�ȣ **/
	private String sAcctNo;
	/** �����ָ� **/
	private String sDpsrName;
	/** �����Email **/
	private String sCrtorEmail;
	/** �����������ȭ��ȣ1 **/
	private String sCrtorHomeTel1;
	/** �����������ȭ��ȣ2 **/
	private String sCrtorHomeTel2;
	/** �����������ȭ��ȣ3 **/
	private String sCrtorHomeTel3;
	/** ����ڻ繫����ȭ��ȣ1 **/
	private String sCrtorOfficeTel1;
	/** ����ڻ繫����ȭ��ȣ2 **/
	private String sCrtorOfficeTel2;
	/** ����ڻ繫����ȭ��ȣ3 **/
	private String sCrtorOfficeTel3;
	/** ������޴���ȭ��ȣ1 **/
	private String sCrtorCellPhone1;
	/** ������޴���ȭ��ȣ2 **/
	private String sCrtorCellPhone2;
	/** ������޴���ȭ��ȣ3 **/
	private String sCrtorCellPhone3;
	/** ������ȣ1 **/
	private String sZip1_Rvad;
	/** ������ȣ2 **/
	private String sZip2_Rvad;
	/** �߼����ּ� **/
	private String RvadAddr;
	/**��ȯ��࿩�� **/
	private String sCmprCrNotcSsrt;
	/** ���� ����� �� **/
	private String sFrstDoerNm;
	

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

	/**
	 * @return the sGdNm
	 */
	public String getsGdNm() {
		return sGdNm;
	}

	/**
	 * @param sGdNm the sGdNm to set
	 */
	public void setsGdNm(final String sGdNm) {
		this.sGdNm = sGdNm;
	}

	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}

	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(final String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}

	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}

	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(final String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}

	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}

	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(final String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}

	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}

	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(final String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}

	/**
	 * @return the sPaymTermCdNm
	 */
	public String getsPaymTermCdNm() {
		return sPaymTermCdNm;
	}

	/**
	 * @param sPaymTermCdNm the sPaymTermCdNm to set
	 */
	public void setsPaymTermCdNm(final String sPaymTermCdNm) {
		this.sPaymTermCdNm = sPaymTermCdNm;
	}

	/**
	 * @return the sPaymCyclCdNm
	 */
	public String getsPaymCyclCdNm() {
		return sPaymCyclCdNm;
	}

	/**
	 * @param sPaymCyclCdNm the sPaymCyclCdNm to set
	 */
	public void setsPaymCyclCdNm(final String sPaymCyclCdNm) {
		this.sPaymCyclCdNm = sPaymCyclCdNm;
	}

	/**
	 * @return the nTotPaymPrem
	 */
	public String getnTotPaymPrem() {
		return nTotPaymPrem;
	}

	/**
	 * @param nTotPaymPrem the nTotPaymPrem to set
	 */
	public void setnTotPaymPrem(final String nTotPaymPrem) {
		this.nTotPaymPrem = nTotPaymPrem;
	}

	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}

	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(final String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}

	/**
	 * @return the sBankCdNm
	 */
	public String getsBankCdNm() {
		return sBankCdNm;
	}

	/**
	 * @param sBankCdNm the sBankCdNm to set
	 */
	public void setsBankCdNm(final String sBankCdNm) {
		this.sBankCdNm = sBankCdNm;
	}

	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}

	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(final String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}

	/**
	 * @return the sCrtorEmail
	 */
	public String getsCrtorEmail() {
		return sCrtorEmail;
	}

	/**
	 * @param sCrtorEmail the sCrtorEmail to set
	 */
	public void setsCrtorEmail(final String sCrtorEmail) {
		this.sCrtorEmail = sCrtorEmail;
	}

	/**
	 * @return the sCrtorHomeTel1
	 */
	public String getsCrtorHomeTel1() {
		return sCrtorHomeTel1;
	}

	/**
	 * @param sCrtorHomeTel1 the sCrtorHomeTel1 to set
	 */
	public void setsCrtorHomeTel1(final String sCrtorHomeTel1) {
		this.sCrtorHomeTel1 = sCrtorHomeTel1;
	}

	/**
	 * @return the sCrtorHomeTel2
	 */
	public String getsCrtorHomeTel2() {
		return sCrtorHomeTel2;
	}

	/**
	 * @param sCrtorHomeTel2 the sCrtorHomeTel2 to set
	 */
	public void setsCrtorHomeTel2(final String sCrtorHomeTel2) {
		this.sCrtorHomeTel2 = sCrtorHomeTel2;
	}

	/**
	 * @return the sCrtorHomeTel3
	 */
	public String getsCrtorHomeTel3() {
		return sCrtorHomeTel3;
	}

	/**
	 * @param sCrtorHomeTel3 the sCrtorHomeTel3 to set
	 */
	public void setsCrtorHomeTel3(final String sCrtorHomeTel3) {
		this.sCrtorHomeTel3 = sCrtorHomeTel3;
	}

	/**
	 * @return the sCrtorOfficeTel1
	 */
	public String getsCrtorOfficeTel1() {
		return sCrtorOfficeTel1;
	}

	/**
	 * @param sCrtorOfficeTel1 the sCrtorOfficeTel1 to set
	 */
	public void setsCrtorOfficeTel1(final String sCrtorOfficeTel1) {
		this.sCrtorOfficeTel1 = sCrtorOfficeTel1;
	}

	/**
	 * @return the sCrtorOfficeTel2
	 */
	public String getsCrtorOfficeTel2() {
		return sCrtorOfficeTel2;
	}

	/**
	 * @param sCrtorOfficeTel2 the sCrtorOfficeTel2 to set
	 */
	public void setsCrtorOfficeTel2(final String sCrtorOfficeTel2) {
		this.sCrtorOfficeTel2 = sCrtorOfficeTel2;
	}

	/**
	 * @return the sCrtorOfficeTel3
	 */
	public String getsCrtorOfficeTel3() {
		return sCrtorOfficeTel3;
	}

	/**
	 * @param sCrtorOfficeTel3 the sCrtorOfficeTel3 to set
	 */
	public void setsCrtorOfficeTel3(final String sCrtorOfficeTel3) {
		this.sCrtorOfficeTel3 = sCrtorOfficeTel3;
	}

	/**
	 * @return the sCrtorCellPhone1
	 */
	public String getsCrtorCellPhone1() {
		return sCrtorCellPhone1;
	}

	/**
	 * @param sCrtorCellPhone1 the sCrtorCellPhone1 to set
	 */
	public void setsCrtorCellPhone1(final String sCrtorCellPhone1) {
		this.sCrtorCellPhone1 = sCrtorCellPhone1;
	}

	/**
	 * @return the sCrtorCellPhone2
	 */
	public String getsCrtorCellPhone2() {
		return sCrtorCellPhone2;
	}

	/**
	 * @param sCrtorCellPhone2 the sCrtorCellPhone2 to set
	 */
	public void setsCrtorCellPhone2(final String sCrtorCellPhone2) {
		this.sCrtorCellPhone2 = sCrtorCellPhone2;
	}

	/**
	 * @return the sCrtorCellPhone3
	 */
	public String getsCrtorCellPhone3() {
		return sCrtorCellPhone3;
	}

	/**
	 * @param sCrtorCellPhone3 the sCrtorCellPhone3 to set
	 */
	public void setsCrtorCellPhone3(final String sCrtorCellPhone3) {
		this.sCrtorCellPhone3 = sCrtorCellPhone3;
	}

	/**
	 * @return the sZip1_Rvad
	 */
	public String getsZip1_Rvad() {
		return sZip1_Rvad;
	}

	/**
	 * @param sZip1_Rvad the sZip1_Rvad to set
	 */
	public void setsZip1_Rvad(final String sZip1_Rvad) {
		this.sZip1_Rvad = sZip1_Rvad;
	}

	/**
	 * @return the sZip2_Rvad
	 */
	public String getsZip2_Rvad() {
		return sZip2_Rvad;
	}

	/**
	 * @param sZip2_Rvad the sZip2_Rvad to set
	 */
	public void setsZip2_Rvad(final String sZip2_Rvad) {
		this.sZip2_Rvad = sZip2_Rvad;
	}

	/**
	 * @return the rvadAddr
	 */
	public String getRvadAddr() {
		return RvadAddr;
	}

	/**
	 * @param rvadAddr the rvadAddr to set
	 */
	public void setRvadAddr(final String rvadAddr) {
		RvadAddr = rvadAddr;
	}

	/**
	 * @return the sFinalPaymMthyNm
	 */
	public String getsFinalPaymMthyNm() {
		return sFinalPaymMthyNm;
	}

	/**
	 * @param sFinalPaymMthyNm the sFinalPaymMthyNm to set
	 */
	public void setsFinalPaymMthyNm(final String sFinalPaymMthyNm) {
		this.sFinalPaymMthyNm = sFinalPaymMthyNm;
	}

	/**
	 * @return the sCmMetdNm
	 */
	public String getsCmMetdNm() {
		return sCmMetdNm;
	}

	/**
	 * @param sCmMetdNm the sCmMetdNm to set
	 */
	public void setsCmMetdNm(final String sCmMetdNm) {
		this.sCmMetdNm = sCmMetdNm;
	}

	/**
	 * @return the sCmprCrNotcSsrt
	 */
	public String getsCmprCrNotcSsrt() {
		return sCmprCrNotcSsrt;
	}

	/**
	 * @param sCmprCrNotcSsrt the sCmprCrNotcSsrt to set
	 */
	public void setsCmprCrNotcSsrt(String sCmprCrNotcSsrt) {
		this.sCmprCrNotcSsrt = sCmprCrNotcSsrt;
	}

	/**
	 * @return the sFrstDoerNm
	 */
	public String getsFrstDoerNm() {
		return sFrstDoerNm;
	}

	/**
	 * @param sFrstDoerNm the sFrstDoerNm to set
	 */
	public void setsFrstDoerNm(String sFrstDoerNm) {
		this.sFrstDoerNm = sFrstDoerNm;
	}
	
	
}
