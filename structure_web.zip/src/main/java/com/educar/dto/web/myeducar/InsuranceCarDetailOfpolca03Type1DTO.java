/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (Ư����� ����)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfpolca03Type1DTO")
public class InsuranceCarDetailOfpolca03Type1DTO {
	/** ���ɹ��� **/
	private String sAgeDisplay;
	/** �����ڹ��� **/
	private String sFamDisplay;
	/** �븮�������� **/
	private String isAgentDrive;
	/** ���ϸ��� **/
	private String sMileDisplay;
	/** �÷���1�� **/
	private String sPersonIDDisplay;
	/** ������ **/
	private String sWeekDisplay;
	/** �����ڽ�  **/
	private String sBlacBoxDisplay;
	/** ����Ư��  **/
	private String sNaumDisplay;
	/** ������������ǹ�  **/
	private String sSilverDisplay;
	

	/**
	 * @return the sAgeDisplay
	 */
	public String getsAgeDisplay() {
		return sAgeDisplay;
	}

	/**
	 * @param sAgeDisplay the sAgeDisplay to set
	 */
	public void setsAgeDisplay(final String sAgeDisplay) {
		this.sAgeDisplay = sAgeDisplay;
	}

	/**
	 * @return the sFamDisplay
	 */
	public String getsFamDisplay() {
		return sFamDisplay;
	}

	/**
	 * @param sFamDisplay the sFamDisplay to set
	 */
	public void setsFamDisplay(final String sFamDisplay) {
		this.sFamDisplay = sFamDisplay;
	}

	/**
	 * @return the isAgentDrive
	 */
	public String getIsAgentDrive() {
		return isAgentDrive;
	}

	/**
	 * @param isAgentDrive the isAgentDrive to set
	 */
	public void setIsAgentDrive(final String isAgentDrive) {
		this.isAgentDrive = isAgentDrive;
	}

	/**
	 * @return the sMileDisplay
	 */
	public String getsMileDisplay() {
		return sMileDisplay;
	}

	/**
	 * @param sMileDisplay the sMileDisplay to set
	 */
	public void setsMileDisplay(final String sMileDisplay) {
		this.sMileDisplay = sMileDisplay;
	}

	/**
	 * @return the sPersonIDDisplay
	 */
	public String getsPersonIDDisplay() {
		return sPersonIDDisplay;
	}

	/**
	 * @param sPersonIDDisplay the sPersonIDDisplay to set
	 */
	public void setsPersonIDDisplay(final String sPersonIDDisplay) {
		this.sPersonIDDisplay = sPersonIDDisplay;
	}

	/**
	 * @return the sWeekDisplay
	 */
	public String getsWeekDisplay() {
		return sWeekDisplay;
	}

	/**
	 * @param sWeekDisplay the sWeekDisplay to set
	 */
	public void setsWeekDisplay(String sWeekDisplay) {
		this.sWeekDisplay = sWeekDisplay;
	}

	/**
	 * @return the sBlacBoxDisplay
	 */
	public String getsBlacBoxDisplay() {
		return sBlacBoxDisplay;
	}

	/**
	 * @param sBlacBoxDisplay the sBlacBoxDisplay to set
	 */
	public void setsBlacBoxDisplay(String sBlacBoxDisplay) {
		this.sBlacBoxDisplay = sBlacBoxDisplay;
	}

	/**
	 * @return the sNaumDisplay
	 */
	public String getsNaumDisplay() {
		return sNaumDisplay;
	}

	/**
	 * @param sNaumDisplay the sNaumDisplay to set
	 */
	public void setsNaumDisplay(String sNaumDisplay) {
		this.sNaumDisplay = sNaumDisplay;
	}

	/**
	 * @return the sSilverDisplay
	 */
	public String getsSilverDisplay() {
		return sSilverDisplay;
	}

	/**
	 * @param sSilverDisplay the sSilverDisplay to set
	 */
	public void setsSilverDisplay(String sSilverDisplay) {
		this.sSilverDisplay = sSilverDisplay;
	}

}
