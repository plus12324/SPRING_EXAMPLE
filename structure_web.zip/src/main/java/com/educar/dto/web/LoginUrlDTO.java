/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * <pre>
 * LOGIN URL DTO
 * <pre>
 * @author �Ž¿�
 *
 */
public class LoginUrlDTO  {
	
	private Integer ID;
	
	private String sMenu;
	
	private String sDescription;
	
	private String sUrl;
	
	private String sAuthority;

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getsMenu() {
		return sMenu;
	}

	public void setsMenu(String sMenu) {
		this.sMenu = sMenu;
	}

	public String getsDescription() {
		return sDescription;
	}

	public void setsDescription(String sDescription) {
		this.sDescription = sDescription;
	}

	public String getsUrl() {
		return sUrl;
	}

	public void setsUrl(String sUrl) {
		this.sUrl = sUrl;
	}

	public String getsAuthority() {
		return sAuthority;
	}

	public void setsAuthority(String sAuthority) {
		this.sAuthority = sAuthority;
	}
	
}
