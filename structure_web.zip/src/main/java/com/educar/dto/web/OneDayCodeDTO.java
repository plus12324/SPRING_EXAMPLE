/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �ڵ� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "oneDayCodeDTO")
public class OneDayCodeDTO {
	/** ���������ڵ� **/
	private String sInsType;
	/** ����� **/
	private String sInsTypeName;
	/** ��Ű���ڵ� **/
	private String sPackAge;
	/** ��Ű���� **/
	private String sPackAgeName;
	/** �㺸�ڵ� **/
	private String sCover;
	/** �㺸�� **/
	private String sCoverName;
	/** �����ڵ� **/
	private String sVehicleCode;
	/** ������ **/
	private String sVehicleName;
	/** ���Դ㺸�ڵ� **/
	private String sOptCode;
	/** ���Դ㺸�� **/
	private String sOptName;

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}

	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(final String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}

	/**
	 * @return the sPackAge
	 */
	public String getsPackAge() {
		return sPackAge;
	}

	/**
	 * @param sPackAge the sPackAge to set
	 */
	public void setsPackAge(final String sPackAge) {
		this.sPackAge = sPackAge;
	}

	/**
	 * @return the sPackAgeName
	 */
	public String getsPackAgeName() {
		return sPackAgeName;
	}

	/**
	 * @param sPackAgeName the sPackAgeName to set
	 */
	public void setsPackAgeName(final String sPackAgeName) {
		this.sPackAgeName = sPackAgeName;
	}

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the sCoverName
	 */
	public String getsCoverName() {
		return sCoverName;
	}

	/**
	 * @param sCoverName the sCoverName to set
	 */
	public void setsCoverName(final String sCoverName) {
		this.sCoverName = sCoverName;
	}

	/**
	 * @return the sVehicleCode
	 */
	public String getsVehicleCode() {
		return sVehicleCode;
	}

	/**
	 * @param sVehicleCode the sVehicleCode to set
	 */
	public void setsVehicleCode(final String sVehicleCode) {
		this.sVehicleCode = sVehicleCode;
	}

	/**
	 * @return the sVehicleName
	 */
	public String getsVehicleName() {
		return sVehicleName;
	}

	/**
	 * @param sVehicleName the sVehicleName to set
	 */
	public void setsVehicleName(final String sVehicleName) {
		this.sVehicleName = sVehicleName;
	}

	/**
	 * @return the sOptCode
	 */
	public String getsOptCode() {
		return sOptCode;
	}

	/**
	 * @param sOptCode the sOptCode to set
	 */
	public void setsOptCode(final String sOptCode) {
		this.sOptCode = sOptCode;
	}

	/**
	 * @return the sOptName
	 */
	public String getsOptName() {
		return sOptName;
	}

	/**
	 * @param sOptName the sOptName to set
	 */
	public void setsOptName(final String sOptName) {
		this.sOptName = sOptName;
	}

}
