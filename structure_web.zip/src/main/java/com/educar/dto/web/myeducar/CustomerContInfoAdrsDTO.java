/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����, ȸ��, ��Ÿ �ּ� ����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "customerContInfoAdrsDTO")
public class CustomerContInfoAdrsDTO {
	/**	�ֹι�ȣ	**/
	private String sCustNo;
	/**	����	**/
	private String nSeqNo;
	/**	�ּ�TYPE	**/
	private String sAdrsType;
	/**	����ȸ��	**/
	private String nChangeNo;
	/**	������ȣ1	**/
	private String sZip1;
	/**	������ȣ2	**/
	private String sZip2;
	/**	�ּ�1	**/
	private String sAdrs1;
	/**	�ּ�2	**/
	private String sAdrs2;
	/**	�ּ�3	**/
	private String sAdrs3;
	/**	����	**/
	private String sAdrsAdd;
	/**	����2	**/
	private String sAdrsAdd2;
	/**	�����ȣ	**/
	private String sUserID;
	/**�Է���	**/
	private String 	sInputDate;
	/**�Է½ð�	**/
	private String 	sInputTime;
	/**�ű��ּұ���	**/
	private String 	sZipType;
	
	//N1401-00089 ���θ��ּ� �߰�
	/** ���λ����ּ� **/
	private String sDoroAddr;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}
	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}
	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}
	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}
	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}
	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}
	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}
	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}
	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}
	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}
	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}
	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}
	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}
	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}
	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}
	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}
	/**
	 * @return the sAdrsAdd2
	 */
	public String getsAdrsAdd2() {
		return sAdrsAdd2;
	}
	/**
	 * @param sAdrsAdd2 the sAdrsAdd2 to set
	 */
	public void setsAdrsAdd2(String sAdrsAdd2) {
		this.sAdrsAdd2 = sAdrsAdd2;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sZipType
	 */
	public String getsZipType() {
		return sZipType;
	}
	/**
	 * @param sZipType the sZipType to set
	 */
	public void setsZipType(String sZipType) {
		this.sZipType = sZipType;
	}
	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr() {
		return sDoroAddr;
	}
	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr(String sDoroAddr) {
		this.sDoroAddr = sDoroAddr;
	}
	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}
	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}
	
	

}
