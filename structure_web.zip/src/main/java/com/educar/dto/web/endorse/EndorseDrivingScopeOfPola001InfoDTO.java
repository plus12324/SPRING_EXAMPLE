/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * �����ڹ��� ���/Ȯ��/���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorseDrivingScopeOfPola001InfoDTO")
public class EndorseDrivingScopeOfPola001InfoDTO {

	/** �����ڵ� **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** �������� **/
	private String sSpecFAM;
	/** �������� **/
	private String sSpecAGE;
	/** �Ǻ����� �ֹι�ȣ(ȭ�鿡���� ����ϱ� ������ ignore ó��)**/
	@BeanUtil(ignore = true)
	private String sInsrdName;
	/** �Ǻ����� �ֹι�ȣ **/
	private String sInsrdID;
	/** ���������� �ֹι�ȣ **/
	private String sMinPersonID;
	/** ���� ���� **/
	private String sMinPersonName;
	/** �����ڵ� **/
	private String sMinRelCode;
	/** �÷���1�� �ֹι�ȣ **/
	private String sPersonID;
	/** �÷���1�� ���� **/
	private String sPersonName;
	/** �÷���1�� ���� **/
	private String sRelCode;

	public String getsInsrdName() {
		return sInsrdName;
	}

	public void setsInsrdName(String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sSpecFAM
	 */
	public String getsSpecFAM() {
		return sSpecFAM;
	}

	/**
	 * @param sSpecFAM the sSpecFAM to set
	 */
	public void setsSpecFAM(final String sSpecFAM) {
		this.sSpecFAM = sSpecFAM;
	}

	/**
	 * @return the sSpecAGE
	 */
	public String getsSpecAGE() {
		return sSpecAGE;
	}

	/**
	 * @param sSpecAGE the sSpecAGE to set
	 */
	public void setsSpecAGE(final String sSpecAGE) {
		this.sSpecAGE = sSpecAGE;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sMinPersonID
	 */
	public String getsMinPersonID() {
		return sMinPersonID;
	}

	/**
	 * @param sMinPersonID the sMinPersonID to set
	 */
	public void setsMinPersonID(final String sMinPersonID) {
		this.sMinPersonID = sMinPersonID;
	}

	/**
	 * @return the sMinPersonName
	 */
	public String getsMinPersonName() {
		return sMinPersonName;
	}

	/**
	 * @param sMinPersonName the sMinPersonName to set
	 */
	public void setsMinPersonName(final String sMinPersonName) {
		this.sMinPersonName = sMinPersonName;
	}

	/**
	 * @return the sMinRelCode
	 */
	public String getsMinRelCode() {
		return sMinRelCode;
	}

	/**
	 * @param sMinRelCode the sMinRelCode to set
	 */
	public void setsMinRelCode(final String sMinRelCode) {
		this.sMinRelCode = sMinRelCode;
	}

	/**
	 * @return the sPersonID
	 */
	public String getsPersonID() {
		return sPersonID;
	}

	/**
	 * @param sPersonID the sPersonID to set
	 */
	public void setsPersonID(final String sPersonID) {
		this.sPersonID = sPersonID;
	}

	/**
	 * @return the sPersonName
	 */
	public String getsPersonName() {
		return sPersonName;
	}

	/**
	 * @param sPersonName the sPersonName to set
	 */
	public void setsPersonName(final String sPersonName) {
		this.sPersonName = sPersonName;
	}

	/**
	 * @return the sRelCode
	 */
	public String getsRelCode() {
		return sRelCode;
	}

	/**
	 * @param sRelCode the sRelCode to set
	 */
	public void setsRelCode(final String sRelCode) {
		this.sRelCode = sRelCode;
	}

}
