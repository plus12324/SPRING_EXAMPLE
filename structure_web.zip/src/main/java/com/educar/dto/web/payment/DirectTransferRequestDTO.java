/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

/**
 * PG ������ü ������ �����Ϸù�ȣ ���� ���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
public class DirectTransferRequestDTO {

	/** ��û���� **/
	private String sReqDate;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ��� **/
	private String sApplyYM;
	/** û���ȣSer **/
	private String sApplySer;
	/** �����ڵ� **/
	private String sInsType;
	/** ��������� **/
	private String sLastAgnt;
	/** ��ݱݾ� **/
	private String nOutAmt;
	/** �������� **/
	private String sMsgType;
	/** �������� **/
	private String sEpType;
	/** �̿������ι�ȣ **/
	private String sApproveNo;
	/** �Աݰ��¹�ȣ **/
	private String sReceiptAcctNo;

	/**
	 * @return the sReqDate
	 */
	public String getsReqDate() {
		return sReqDate;
	}

	/**
	 * @param sReqDate the sReqDate to set
	 */
	public void setsReqDate(final String sReqDate) {
		this.sReqDate = sReqDate;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sLastAgnt
	 */
	public String getsLastAgnt() {
		return sLastAgnt;
	}

	/**
	 * @param sLastAgnt the sLastAgnt to set
	 */
	public void setsLastAgnt(final String sLastAgnt) {
		this.sLastAgnt = sLastAgnt;
	}

	/**
	 * @return the nOutAmt
	 */
	public String getnOutAmt() {
		return nOutAmt;
	}

	/**
	 * @param nOutAmt the nOutAmt to set
	 */
	public void setnOutAmt(final String nOutAmt) {
		this.nOutAmt = nOutAmt;
	}

	/**
	 * @return the sMsgType
	 */
	public String getsMsgType() {
		return sMsgType;
	}

	/**
	 * @param sMsgType the sMsgType to set
	 */
	public void setsMsgType(final String sMsgType) {
		this.sMsgType = sMsgType;
	}

	/**
	 * @return the sEpType
	 */
	public String getsEpType() {
		return sEpType;
	}

	/**
	 * @param sEpType the sEpType to set
	 */
	public void setsEpType(final String sEpType) {
		this.sEpType = sEpType;
	}

	/**
	 * @return the sApproveNo
	 */
	public String getsApproveNo() {
		return sApproveNo;
	}

	/**
	 * @param sApproveNo the sApproveNo to set
	 */
	public void setsApproveNo(final String sApproveNo) {
		this.sApproveNo = sApproveNo;
	}

	/**
	 * @return the sReceiptAcctNo
	 */
	public String getsReceiptAcctNo() {
		return sReceiptAcctNo;
	}

	/**
	 * @param sReceiptAcctNo the sReceiptAcctNo to set
	 */
	public void setsReceiptAcctNo(final String sReceiptAcctNo) {
		this.sReceiptAcctNo = sReceiptAcctNo;
	}
}
