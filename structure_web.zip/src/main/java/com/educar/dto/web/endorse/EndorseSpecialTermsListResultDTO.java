/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �輭 - Ư����� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorseSpecialTermsListResultDTO")
public class EndorseSpecialTermsListResultDTO {
	/** pola001Info **/
	private EndorseSpecialTermsOfPola001InfoDTO pola001Info;

	/** �ָ������� ���α� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0509;
	/** ����ī�뿩 **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0510;
	/** �������� ������ **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0512;
	/** ����� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0513;
	/** ���ݺ�� **/
	private List<EndorsePawnListOfCoverDTO> displayCoverOptVt0514;
	/** �¿��������� **/
	private List<EndorsePawnListOfCoverDTO> displaySpecWeek;
	/** �¿��������� �������� **/
	private List<EndorsePawnListOfCoverDTO> displaySpecWeekDay;

	/**
	 * @return the pola001Info
	 */
	public EndorseSpecialTermsOfPola001InfoDTO getPola001Info() {
		return pola001Info;
	}

	/**
	 * @param pola001Info the pola001Info to set
	 */
	public void setPola001Info(final EndorseSpecialTermsOfPola001InfoDTO pola001Info) {
		this.pola001Info = pola001Info;
	}

	/**
	 * @return the displayCoverOptVt0509
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0509() {
		return displayCoverOptVt0509;
	}

	/**
	 * @param displayCoverOptVt0509 the displayCoverOptVt0509 to set
	 */
	public void setDisplayCoverOptVt0509(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0509) {
		this.displayCoverOptVt0509 = displayCoverOptVt0509;
	}

	/**
	 * @return the displayCoverOptVt0510
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0510() {
		return displayCoverOptVt0510;
	}

	/**
	 * @param displayCoverOptVt0510 the displayCoverOptVt0510 to set
	 */
	public void setDisplayCoverOptVt0510(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0510) {
		this.displayCoverOptVt0510 = displayCoverOptVt0510;
	}

	/**
	 * @return the displayCoverOptVt0512
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0512() {
		return displayCoverOptVt0512;
	}

	/**
	 * @param displayCoverOptVt0512 the displayCoverOptVt0512 to set
	 */
	public void setDisplayCoverOptVt0512(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0512) {
		this.displayCoverOptVt0512 = displayCoverOptVt0512;
	}

	/**
	 * @return the displayCoverOptVt0513
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0513() {
		return displayCoverOptVt0513;
	}

	/**
	 * @param displayCoverOptVt0513 the displayCoverOptVt0513 to set
	 */
	public void setDisplayCoverOptVt0513(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0513) {
		this.displayCoverOptVt0513 = displayCoverOptVt0513;
	}

	/**
	 * @return the displayCoverOptVt0514
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplayCoverOptVt0514() {
		return displayCoverOptVt0514;
	}

	/**
	 * @param displayCoverOptVt0514 the displayCoverOptVt0514 to set
	 */
	public void setDisplayCoverOptVt0514(final List<EndorsePawnListOfCoverDTO> displayCoverOptVt0514) {
		this.displayCoverOptVt0514 = displayCoverOptVt0514;
	}

	/**
	 * @return the displaySpecWeek
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplaySpecWeek() {
		return displaySpecWeek;
	}

	/**
	 * @param displaySpecWeek the displaySpecWeek to set
	 */
	public void setDisplaySpecWeek(final List<EndorsePawnListOfCoverDTO> displaySpecWeek) {
		this.displaySpecWeek = displaySpecWeek;
	}

	/**
	 * @return the displaySpecWeekDay
	 */
	public List<EndorsePawnListOfCoverDTO> getDisplaySpecWeekDay() {
		return displaySpecWeekDay;
	}

	/**
	 * @param displaySpecWeekDay the displaySpecWeekDay to set
	 */
	public void setDisplaySpecWeekDay(final List<EndorsePawnListOfCoverDTO> displaySpecWeekDay) {
		this.displaySpecWeekDay = displaySpecWeekDay;
	}

}
