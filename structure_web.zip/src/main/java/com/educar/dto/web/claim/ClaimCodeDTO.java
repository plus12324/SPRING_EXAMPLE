/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����ڰ��� ���غ��� ��� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "claimCodeDTO")
public class ClaimCodeDTO {

	private String sCodeDiv2;
	private String sCodeDiv2Name;
	/** ��/�� ��ȸ(��/�� ��ȸ �ÿ��� ���� ��) **/
	private String sCountyName;

	/**
	 * @return the sCodeDiv2
	 */
	public String getsCodeDiv2() {
		return sCodeDiv2;
	}

	/**
	 * @param sCodeDiv2 the sCodeDiv2 to set
	 */
	public void setsCodeDiv2(final String sCodeDiv2) {
		this.sCodeDiv2 = sCodeDiv2;
	}

	/**
	 * @return the sCodeDiv2Name
	 */
	public String getsCodeDiv2Name() {
		return sCodeDiv2Name;
	}

	/**
	 * @param sCodeDiv2Name the sCodeDiv2Name to set
	 */
	public void setsCodeDiv2Name(final String sCodeDiv2Name) {
		this.sCodeDiv2Name = sCodeDiv2Name;
	}

	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}

	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(final String sCountyName) {
		this.sCountyName = sCountyName;
	}

}
