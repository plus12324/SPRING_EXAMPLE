/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.dto.web.EducarDriverInsurancePawnDTO;

/**
 * �����ں��� ����ī������ û�� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "driverInsuranceOfferDTO")
public class DriverInsuranceOfferDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/** ���� ���� **/
	private DriverInsuranceOfferOfHashCalcDTO hashCalc;
	/** hash031 (�κ����� ��� List 1��°�� ����, 2��°�� ����) **/
	@XmlElementWrapper(name = "hash031List")
	private List<DriverInsuranceOfferOfHash031DTO> hash031;
	/** hash051 ��ʺ�����ȸ ����� (�κ����� ��� List 1��°�� ����, 2��°�� ����) **/
	@XmlElementWrapper(name = "hash051List")
	private List<DriverInsuranceOfferOfHash051DTO> hash051;
	/** �㺸 ���� sCover, nEtnAmt, sSelYN**/
	@XmlElementWrapper(name = "sCovSelList")
	private List<EducarDriverInsurancePawnDTO> sCovSel;
	/** ��������� **/
	private DriverInsuranceOfferOfHash020DTO hash020;
	/** �Ǻ��������� **/
	@XmlElementWrapper(name = "hash030List")
	private List<DriverInsuranceOfferOfHash030DTO> hash030;
	/** hashBank **/
	private DriverInsuranceOfferOfHashBankDTO hashBank;
	/** hash010 �⺻�������� **/
	private DriverInsuranceOfferOfHash010DTO hash010;
	/** hashAuto �ڵ���ü�������� **/
	private DriverInsuranceOfferOfHashAutoDTO hashAuto;

	/** log�� insert �� step (01 ~ 06)**/
	private String step;
	/** ���� ����� (log insert �� �ʿ�) **/
	private String totPrem;
	/** û���ȣ 12�ڸ� (log insert �� �ʿ�) **/
	private String sBizNo;

	/**
	 * @return the hashCalc
	 */
	public DriverInsuranceOfferOfHashCalcDTO getHashCalc() {
		return hashCalc;
	}

	/**
	 * @param hashCalc the hashCalc to set
	 */
	public void setHashCalc(final DriverInsuranceOfferOfHashCalcDTO hashCalc) {
		this.hashCalc = hashCalc;
	}

	/**
	 * @return the hash031
	 */
	public List<DriverInsuranceOfferOfHash031DTO> getHash031() {
		return hash031;
	}

	/**
	 * @param hash031 the hash031 to set
	 */
	public void setHash031(final List<DriverInsuranceOfferOfHash031DTO> hash031) {
		this.hash031 = hash031;
	}

	/**
	 * @return the hash051
	 */
	public List<DriverInsuranceOfferOfHash051DTO> getHash051() {
		return hash051;
	}

	/**
	 * @param hash051 the hash051 to set
	 */
	public void setHash051(final List<DriverInsuranceOfferOfHash051DTO> hash051) {
		this.hash051 = hash051;
	}

	/**
	 * @return the sCovSel
	 */
	public List<EducarDriverInsurancePawnDTO> getsCovSel() {
		return sCovSel;
	}

	/**
	 * @param sCovSel the sCovSel to set
	 */
	public void setsCovSel(final List<EducarDriverInsurancePawnDTO> sCovSel) {
		this.sCovSel = sCovSel;
	}

	/**
	 * @return the hash020
	 */
	public DriverInsuranceOfferOfHash020DTO getHash020() {
		return hash020;
	}

	/**
	 * @param hash020 the hash020 to set
	 */
	public void setHash020(final DriverInsuranceOfferOfHash020DTO hash020) {
		this.hash020 = hash020;
	}

	/**
	 * @return the hash030
	 */
	public List<DriverInsuranceOfferOfHash030DTO> getHash030() {
		return hash030;
	}

	/**
	 * @param hash030 the hash030 to set
	 */
	public void setHash030(final List<DriverInsuranceOfferOfHash030DTO> hash030) {
		this.hash030 = hash030;
	}

	/**
	 * @return the hashBank
	 */
	public DriverInsuranceOfferOfHashBankDTO getHashBank() {
		return hashBank;
	}

	/**
	 * @param hashBank the hashBank to set
	 */
	public void setHashBank(final DriverInsuranceOfferOfHashBankDTO hashBank) {
		this.hashBank = hashBank;
	}

	/**
	 * @return the hash010
	 */
	public DriverInsuranceOfferOfHash010DTO getHash010() {
		return hash010;
	}

	/**
	 * @param hash010 the hash010 to set
	 */
	public void setHash010(final DriverInsuranceOfferOfHash010DTO hash010) {
		this.hash010 = hash010;
	}

	/**
	 * @return the hashAuto
	 */
	public DriverInsuranceOfferOfHashAutoDTO getHashAuto() {
		return hashAuto;
	}

	/**
	 * @param hashAuto the hashAuto to set
	 */
	public void setHashAuto(final DriverInsuranceOfferOfHashAutoDTO hashAuto) {
		this.hashAuto = hashAuto;
	}

	/**
	 * @return the step
	 */
	public String getStep() {
		return step;
	}

	/**
	 * @param step the step to set
	 */
	public void setStep(final String step) {
		this.step = step;
	}

	/**
	 * @return the totPrem
	 */
	public String getTotPrem() {
		return totPrem;
	}

	/**
	 * @param totPrem the totPrem to set
	 */
	public void setTotPrem(final String totPrem) {
		this.totPrem = totPrem;
	}

	/**
	 * @return the sBizNo
	 */
	public String getsBizNo() {
		return sBizNo;
	}

	/**
	 * @param sBizNo the sBizNo to set
	 */
	public void setsBizNo(final String sBizNo) {
		this.sBizNo = sBizNo;
	}

}
