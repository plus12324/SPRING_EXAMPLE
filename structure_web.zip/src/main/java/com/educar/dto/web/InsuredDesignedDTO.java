/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �Ǻ����� ���� DTO(LTIDA01)
 * @author ������
 *
 */
public class InsuredDesignedDTO {
	/** �Ǻ����ڿ��� (������)**/
	private String nInrpsAge;
	/** �����÷��ڵ� **/
	private String sApplPlanCd;
	/**
	 * <pre> 
	 * �Ǻ������ֹι�ȣ 
	 * ȭ�鿡�� ���� �� �ڿ��� 0000000  ,1984�� 9�� 16�� ���� ���(8409161000000)
	 * </pre> 
	 **/
	private String sInrpsCd;
	/** �����ڵ� **/
	private String sJobCd;
	/** �����޼� **/
	private String sJobGradCd;
	/** ���������ڵ� **/
	private String sDrveFlagCd;
	/** ���� **/	
	private String nInrpsSeqno;
	/** �Ǻ����ڰ����ڵ� **/	
	private String 	sMinsrRelnCd;
	/** ����ڰ����ڵ�**/
	private String 	sCrtorRelnCd;

	/**
	 * @return the nInrpsAge
	 */
	public String getnInrpsAge() {
		return nInrpsAge;
	}

	/**
	 * @param nInrpsAge the nInrpsAge to set
	 */
	public void setnInrpsAge(final String nInrpsAge) {
		this.nInrpsAge = nInrpsAge;
	}

	/**
	 * @return the sApplPlanCd
	 */
	public String getsApplPlanCd() {
		return sApplPlanCd;
	}

	/**
	 * @param sApplPlanCd the sApplPlanCd to set
	 */
	public void setsApplPlanCd(final String sApplPlanCd) {
		this.sApplPlanCd = sApplPlanCd;
	}

	/**
	 * @return the sInrpsCd
	 */
	public String getsInrpsCd() {
		return sInrpsCd;
	}

	/**
	 * @param sInrpsCd the sInrpsCd to set
	 */
	public void setsInrpsCd(final String sInrpsCd) {
		this.sInrpsCd = sInrpsCd;
	}

	/**
	 * @return the sJobCd
	 */
	public String getsJobCd() {
		return sJobCd;
	}

	/**
	 * @param sJobCd the sJobCd to set
	 */
	public void setsJobCd(final String sJobCd) {
		this.sJobCd = sJobCd;
	}

	/**
	 * @return the sJobGradCd
	 */
	public String getsJobGradCd() {
		return sJobGradCd;
	}

	/**
	 * @param sJobGradCd the sJobGradCd to set
	 */
	public void setsJobGradCd(final String sJobGradCd) {
		this.sJobGradCd = sJobGradCd;
	}

	/**
	 * @return the sDrveFlagCd
	 */
	public String getsDrveFlagCd() {
		return sDrveFlagCd;
	}

	/**
	 * @param sDrveFlagCd the sDrveFlagCd to set
	 */
	public void setsDrveFlagCd(final String sDrveFlagCd) {
		this.sDrveFlagCd = sDrveFlagCd;
	}

	/**
	 * @return the nInrpsSeqno
	 */
	public String getnInrpsSeqno() {
		return nInrpsSeqno;
	}

	/**
	 * @param nInrpsSeqno the nInrpsSeqno to set
	 */
	public void setnInrpsSeqno(String nInrpsSeqno) {
		this.nInrpsSeqno = nInrpsSeqno;
	}

	/**
	 * @return the sMinsrRelnCd
	 */
	public String getsMinsrRelnCd() {
		return sMinsrRelnCd;
	}

	/**
	 * @param sMinsrRelnCd the sMinsrRelnCd to set
	 */
	public void setsMinsrRelnCd(String sMinsrRelnCd) {
		this.sMinsrRelnCd = sMinsrRelnCd;
	}

	/**
	 * @return the sCrtorRelnCd
	 */
	public String getsCrtorRelnCd() {
		return sCrtorRelnCd;
	}

	/**
	 * @param sCrtorRelnCd the sCrtorRelnCd to set
	 */
	public void setsCrtorRelnCd(String sCrtorRelnCd) {
		this.sCrtorRelnCd = sCrtorRelnCd;
	}

}
