/*-
 * Copyright (c) 2012, Conch
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

import org.apache.commons.lang.StringUtils;

import com.educar.enumeration.AuthMethodEnum;

/**
 * ������ȣ �߱� ��û
 * email �Ǵ� �ڵ��� ��ȣ�� �´�.  �Ѵ� �ü��� ����
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement
public class IssueAuthNumberDTO {

	/** �ڵ�����ȣ **/
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sCellPhone1;
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sCellPhone2;
	@ValidateLength(type = TypeEnum.NUMBER, min = 3, max = 4)
	private String sCellPhone3;
	/** �̸��� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEmail;
	/** ���� ��� AuthMehtodEnum �� ���**/
	private String sAuthMethod;
	/** �̸� */
	private String sName;
	/** �ڵ������� ���� */
	private boolean isValid = false;
	

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(final String sEmail) {
		this.sEmail = sEmail;
	}

	/** �������� ��� (AuthMethodEnum �� ����)
	 * 
	 * @return certMethod
	 * 1 : �ڵ���
	 * 2 : �̸���
	 */
	public String getsCertMethod() {

		String certMethod = "";

		// �ڵ����� �̸��� ������ ��� ������ ��� null ó��, isInvaildEmailAndCellPhone �Լ��� ���� ó���ؾ��Ѵ�.
		if (this.isInvaildEmailAndCellPhone()) {
			certMethod = null;
		} else if (StringUtils.isNotBlank(this.sEmail)) {
			certMethod = AuthMethodEnum.EMAIL.getCode();
		} else {
			certMethod = AuthMethodEnum.MOBILE_PHONE.getCode();
		}
		return certMethod;
	}

	/**
	 * �ڵ��� ��ȣ ��ȿ�� üũ
	 * @param 
	 * @return true: sCellPhone1,2,3 �� ��� �Էµ�/ false: sCellPhone1,2,3 �� �� �� �̻� null
	 */
	public boolean isVaildCellPhone() {
		if (StringUtils.isNotBlank(this.sCellPhone1) && StringUtils.isNotBlank(this.sCellPhone2) && StringUtils.isNotBlank(this.sCellPhone3)) {
			return true;
		}
		return false;
	}

	/**
	 * �ڵ���, �̸��� ��� �ִ��� Ȥ�� ��� ������ Ȯ��.
	 * @param 
	 * @return true: �ڵ���, �̸��� ��� �ְų� null, false: �̸���, �ڵ��� �� �� �� �ϳ��� ����
	 */
	public boolean isInvaildEmailAndCellPhone() {
		if ((StringUtils.isNotBlank(this.sEmail) && this.isVaildCellPhone()) || (!StringUtils.isNotBlank(this.sEmail) && !this.isVaildCellPhone())) {
			return true;
		}
		return false;
	}

	/**
	 * @return the sAuthMethod
	 */
	public String getsAuthMethod() {
		return sAuthMethod;
	}

	/**
	 * @param sAuthMethod the sAuthMethod to set
	 */
	public void setsAuthMethod(final String sAuthMethod) {
		this.sAuthMethod = sAuthMethod;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the isValid
	 */
	public boolean isValid() {
		return isValid;
	}

	/**
	 * @param isValid the isValid to set
	 */
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	
	
}
