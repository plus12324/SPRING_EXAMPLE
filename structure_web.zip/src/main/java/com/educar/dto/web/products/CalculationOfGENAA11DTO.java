/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * ������ ���� ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfGENAA11DTO")
public class CalculationOfGENAA11DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ����� ��ȣ **/
	private String sCustNo;
	/** ���θ�(�б���) **/
	private String sName;
	/** ������ȣ �չ�ȣ **/
	private String sZip1;
	/** ������ȣ �޹�ȣ **/
	private String sZip2;
	/** �õ� **/
	private String sAdrs1;
	/** �ñ��� **/
	private String sAdrs2;
	/** ���鵿 **/
	private String sAdrs3;
	/** �������ּ� **/
	private String sAdrsAdd;
	/** ��ȭ��ȣ_01 **/
	private String sHomeTel1;
	/** ��ȭ��ȣ_02 **/
	private String sHomeTel2;
	/** ��ȭ��ȣ_03 **/
	private String sHomeTel3;
	/** sCellPhone1 **/
	private String sCellPhone1;
	/** sCellPhone2 **/
	private String sCellPhone2;
	/** sCellPhone3 **/
	private String sCellPhone3;
	/** �ѽ�_01 **/
	private String sFax1;
	/** �ѽ�_02 **/
	private String sFax2;
	/** �ѽ�_03 **/
	private String sFax3;
	/** �̸��� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEmail1;
	/** �б��ڵ� **/
	private String sSchoolCode;
	/** ����ڸ� **/
	private String sMainConnName;
	//N1401-00089 ���θ��ּ� �߰�
	/** ���λ����ּ� **/
	private String sDoroAddr;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	/** ǥ���ּ���ȯ���� */
	private String sStdAddrFlag;
	/** �ּ�Ÿ�� **/
	private String sZipType;
	
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}

	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(final String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}

	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}

	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(final String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}

	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}

	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(final String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}

	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}

	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(final String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}

	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(final String sFax1) {
		this.sFax1 = sFax1;
	}

	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}

	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(final String sFax2) {
		this.sFax2 = sFax2;
	}

	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}

	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(final String sFax3) {
		this.sFax3 = sFax3;
	}

	/**
	 * @return the sEmail1
	 */
	public String getsEmail1() {
		return sEmail1;
	}

	/**
	 * @param sEmail1 the sEmail1 to set
	 */
	public void setsEmail1(final String sEmail1) {
		this.sEmail1 = sEmail1;
	}

	/**
	 * @return the sSchoolCode
	 */
	public String getsSchoolCode() {
		return sSchoolCode;
	}

	/**
	 * @param sSchoolCode the sSchoolCode to set
	 */
	public void setsSchoolCode(final String sSchoolCode) {
		this.sSchoolCode = sSchoolCode;
	}

	/**
	 * @return the sMainConnName
	 */
	public String getsMainConnName() {
		return sMainConnName;
	}

	/**
	 * @param sMainConnName the sMainConnName to set
	 */
	public void setsMainConnName(final String sMainConnName) {
		this.sMainConnName = sMainConnName;
	}

	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr() {
		return sDoroAddr;
	}

	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr(String sDoroAddr) {
		this.sDoroAddr = sDoroAddr;
	}

	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}

	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}

	/**
	 * @return the sStdAddrFlag
	 */
	public String getsStdAddrFlag() {
		return sStdAddrFlag;
	}

	/**
	 * @param sStdAddrFlag the sStdAddrFlag to set
	 */
	public void setsStdAddrFlag(String sStdAddrFlag) {
		this.sStdAddrFlag = sStdAddrFlag;
	}

	/**
	 * @return the sZipType
	 */
	public String getsZipType() {
		return sZipType;
	}

	/**
	 * @param sZipType the sZipType to set
	 */
	public void setsZipType(String sZipType) {
		this.sZipType = sZipType;
	}
	
}
