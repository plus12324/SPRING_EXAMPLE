/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ī������Ʈ ��ȸ ���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cardPointResponseDTO")
public class CardPointResponseDTO {

	/** VAN�� �ڵ� **/
	private String sVanCode;
	/** �߱޻��ڵ� **/
	private String sPublisher;
	/** ���Ի��ڵ� **/
	private String sSupplier;
	/** ī��߱޻�� **/
	private String sCardName;
	/** ���ι�ȣ **/
	private String sAdmitNo;
	/** ����޽���1 **/
	private String sRspMsg1;
	/** ����޽���2 **/
	private String sRspMsg2;
	/** ����Ʈ���� **/
	private String sPointScore;

	/**
	 * @return the sVanCode
	 */
	public String getsVanCode() {
		return sVanCode;
	}

	/**
	 * @return the sPublisher
	 */
	public String getsPublisher() {
		return sPublisher;
	}

	/**
	 * @return the sSupplier
	 */
	public String getsSupplier() {
		return sSupplier;
	}

	/**
	 * @return the sCardName
	 */
	public String getsCardName() {
		return sCardName;
	}

	/**
	 * @return the sAdmitNo
	 */
	public String getsAdmitNo() {
		return sAdmitNo;
	}

	/**
	 * @return the sRspMsg1
	 */
	public String getsRspMsg1() {
		return sRspMsg1;
	}

	/**
	 * @return the sRspMsg2
	 */
	public String getsRspMsg2() {
		return sRspMsg2;
	}

	/**
	 * @return the sPointScore
	 */
	public String getsPointScore() {
		return sPointScore;
	}

	/**
	 * @param sVanCode the sVanCode to set
	 */
	public void setsVanCode(final String sVanCode) {
		this.sVanCode = sVanCode;
	}

	/**
	 * @param sPublisher the sPublisher to set
	 */
	public void setsPublisher(final String sPublisher) {
		this.sPublisher = sPublisher;
	}

	/**
	 * @param sSupplier the sSupplier to set
	 */
	public void setsSupplier(final String sSupplier) {
		this.sSupplier = sSupplier;
	}

	/**
	 * @param sCardName the sCardName to set
	 */
	public void setsCardName(final String sCardName) {
		this.sCardName = sCardName;
	}

	/**
	 * @param sAdmitNo the sAdmitNo to set
	 */
	public void setsAdmitNo(final String sAdmitNo) {
		this.sAdmitNo = sAdmitNo;
	}

	/**
	 * @param sRspMsg1 the sRspMsg1 to set
	 */
	public void setsRspMsg1(final String sRspMsg1) {
		this.sRspMsg1 = sRspMsg1;
	}

	/**
	 * @param sRspMsg2 the sRspMsg2 to set
	 */
	public void setsRspMsg2(final String sRspMsg2) {
		this.sRspMsg2 = sRspMsg2;
	}

	/**
	 * @param sPointScore the sPointScore to set
	 */
	public void setsPointScore(final String sPointScore) {
		this.sPointScore = sPointScore;
	}

}
