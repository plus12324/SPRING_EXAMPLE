/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����������ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "compensationSearchOfClmccDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimSearchOfClmcDTO {
	/** �㺸 (������� M) **/
	private String sHndCoverName;
	/** ���� (������� M) **/
	private String sDmgeNo;
	/** ������(��) (������� M) **/
	private String sVictimName;
	/** �������� (������� M) **/
	private String sDmgeDegree;
	/** ����/������� (������� M) **/
	private String sHospName;
	/** ����� (������� M) **/
	private String sStaffName;
	/** ����ó (������� M) **/
	private String sCellTel;
	/** ��������� (������� M) **/
	private String nDcAmt;
	/** ������� (������� M) **/
	private String sProgStat;
	/** ������� (������� M) **/
	private String sWebProgStat;

	/**
	 * @return the sHndCoverName
	 */
	public String getsHndCoverName() {
		return sHndCoverName;
	}

	/**
	 * @param sHndCoverName the sHndCoverName to set
	 */
	public void setsHndCoverName(final String sHndCoverName) {
		this.sHndCoverName = sHndCoverName;
	}

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the sVictimName
	 */
	public String getsVictimName() {
		return sVictimName;
	}

	/**
	 * @param sVictimName the sVictimName to set
	 */
	public void setsVictimName(final String sVictimName) {
		this.sVictimName = sVictimName;
	}

	/**
	 * @return the sDmgeDegree
	 */
	public String getsDmgeDegree() {
		return sDmgeDegree;
	}

	/**
	 * @param sDmgeDegree the sDmgeDegree to set
	 */
	public void setsDmgeDegree(final String sDmgeDegree) {
		this.sDmgeDegree = sDmgeDegree;
	}

	/**
	 * @return the sHospName
	 */
	public String getsHospName() {
		return sHospName;
	}

	/**
	 * @param sHospName the sHospName to set
	 */
	public void setsHospName(final String sHospName) {
		this.sHospName = sHospName;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sCellTel
	 */
	public String getsCellTel() {
		return sCellTel;
	}

	/**
	 * @param sCellTel the sCellTel to set
	 */
	public void setsCellTel(final String sCellTel) {
		this.sCellTel = sCellTel;
	}

	/**
	 * @return the nDcAmt
	 */
	public String getnDcAmt() {
		return nDcAmt;
	}

	/**
	 * @param nDcAmt the nDcAmt to set
	 */
	public void setnDcAmt(final String nDcAmt) {
		this.nDcAmt = nDcAmt;
	}

	/**
	 * @return the sProgStat
	 */
	public String getsProgStat() {
		return sProgStat;
	}

	/**
	 * @param sProgStat the sProgStat to set
	 */
	public void setsProgStat(final String sProgStat) {
		this.sProgStat = sProgStat;
	}

	/**
	 * @return the sWebProgStat
	 */
	public String getsWebProgStat() {
		return sWebProgStat;
	}

	/**
	 * @param sWebProgStat the sWebProgStat to set
	 */
	public void setsWebProgStat(String sWebProgStat) {
		this.sWebProgStat = sWebProgStat;
	}

}
