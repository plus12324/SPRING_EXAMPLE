/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.login;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.bytes.CharacterSet;
import kr.co.conch.validator.annotation.bytes.ValidateByte;
import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.enumeration.LoginStatusEnum;

/**
 * ���ȸ�� ���Կ��ο� ���Ǵ� DTO
 * @author �Ž¿� 
 *
 */
@XmlRootElement
public class ContractMemberCheckDTO {

	/** �ֹε�Ϲ�ȣ **/
	private String sCustNo;
	
	/** �ֹε�Ϲ�ȣ 1**/
	private String sCustNo1;
	/** �ֹε�Ϲ�ȣ 2**/
	private String sCustNo2;
	/** Ű���庸�� ��ȣȭ Key **/
	private String sHid_key_data;
	/** URL DATA **/
	private String sUrlData; 
	
	public String getsCustNo() {
		return sCustNo;
	}
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	public String getsUrlData() {
		return sUrlData;
	}
	public void setsUrlData(String sUrlData) {
		this.sUrlData = sUrlData;
	}
	public String getsCustNo1() {
		return sCustNo1;
	}
	public void setsCustNo1(String sCustNo1) {
		this.sCustNo1 = sCustNo1;
	}
	public String getsCustNo2() {
		return sCustNo2;
	}
	public void setsCustNo2(String sCustNo2) {
		this.sCustNo2 = sCustNo2;
	}
	public String getsHid_key_data() {
		return sHid_key_data;
	}
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}
	
}
