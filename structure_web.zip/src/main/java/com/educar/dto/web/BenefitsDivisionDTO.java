/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ���� �ڵ� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "benefitsDivisionDTO")
public class BenefitsDivisionDTO {
	/** ���� ���� ���� �� **/
	private String sEnglishName;
	/** ���� ���� �ѱ� �� **/
	private String sKoreanName;
	/** ���� �׸� �� **/
	private String sItemName;
	/** ���� �׸� �� **/
	private String sItemValue;

	/**
	 * @return the sEnglishName
	 */
	public String getsEnglishName() {
		return sEnglishName;
	}

	/**
	 * @param sEnglishName the sEnglishName to set
	 */
	public void setsEnglishName(final String sEnglishName) {
		this.sEnglishName = sEnglishName;
	}

	/**
	 * @return the sKoreanName
	 */
	public String getsKoreanName() {
		return sKoreanName;
	}

	/**
	 * @param sKoreanName the sKoreanName to set
	 */
	public void setsKoreanName(final String sKoreanName) {
		this.sKoreanName = sKoreanName;
	}

	/**
	 * @return the sItemName
	 */
	public String getsItemName() {
		return sItemName;
	}

	/**
	 * @param sItemName the sItemName to set
	 */
	public void setsItemName(final String sItemName) {
		this.sItemName = sItemName;
	}

	/**
	 * @return the sItemValue
	 */
	public String getsItemValue() {
		return sItemValue;
	}

	/**
	 * @param sItemValue the sItemValue to set
	 */
	public void setsItemValue(final String sItemValue) {
		this.sItemValue = sItemValue;
	}

}