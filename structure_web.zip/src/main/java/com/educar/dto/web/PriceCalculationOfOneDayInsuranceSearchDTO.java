/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ������ ���� ����� ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfOneDayInsuranceSearchDTO")
public class PriceCalculationOfOneDayInsuranceSearchDTO {
	/** �������� **/
	private String sInsType;
	/** package **/
	private String sPackage;
	/** ������� **/
	private String sInsrdID;
	/** ������ȣ **/
	private String sPlateNo;
	/** ���� **/
	private String sVehicleCode;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ����ī1�ϱ��ط�Ʈ��� **/
	private String sCover0422RentAmt;

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sPackage
	 */
	public String getsPackage() {
		return sPackage;
	}

	/**
	 * @param sPackage the sPackage to set
	 */
	public void setsPackage(final String sPackage) {
		this.sPackage = sPackage;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sVehicleCode
	 */
	public String getsVehicleCode() {
		return sVehicleCode;
	}

	/**
	 * @param sVehicleCode the sVehicleCode to set
	 */
	public void setsVehicleCode(final String sVehicleCode) {
		this.sVehicleCode = sVehicleCode;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sCover0422RentAmt
	 */
	public String getsCover0422RentAmt() {
		return sCover0422RentAmt;
	}

	/**
	 * @param sCover0422RentAmt the sCover0422RentAmt to set
	 */
	public void setsCover0422RentAmt(final String sCover0422RentAmt) {
		this.sCover0422RentAmt = sCover0422RentAmt;
	}

}
