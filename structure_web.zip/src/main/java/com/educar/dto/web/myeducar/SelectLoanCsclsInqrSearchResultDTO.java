/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectLoanCsclsInqrSearchResultDTO")
public class SelectLoanCsclsInqrSearchResultDTO {
	/** ó������(������) **/
	private String sDlngDate;
	/** �����ܾ� **/
	private String nLoanBaln;
	/** �����ȣ **/
	private String sLoanNo;
	/** �������� **/
	private String nApplRato1;

	/**
	 * @return the sDlngDate
	 */
	public String getsDlngDate() {
		return sDlngDate;
	}

	/**
	 * @param sDlngDate the sDlngDate to set
	 */
	public void setsDlngDate(final String sDlngDate) {
		this.sDlngDate = sDlngDate;
	}

	/**
	 * @return the nLoanBaln
	 */
	public String getnLoanBaln() {
		return nLoanBaln;
	}

	/**
	 * @param nLoanBaln the nLoanBaln to set
	 */
	public void setnLoanBaln(final String nLoanBaln) {
		this.nLoanBaln = nLoanBaln;
	}

	/**
	 * @return the sLoanNo
	 */
	public String getsLoanNo() {
		return sLoanNo;
	}

	/**
	 * @param sLoanNo the sLoanNo to set
	 */
	public void setsLoanNo(final String sLoanNo) {
		this.sLoanNo = sLoanNo;
	}

	/**
	 * @return the nApplRato1
	 */
	public String getnApplRato1() {
		return nApplRato1;
	}

	/**
	 * @param nApplRato1 the nApplRato1 to set
	 */
	public void setnApplRato1(String nApplRato1) {
		this.nApplRato1 = nApplRato1;
	}

}
