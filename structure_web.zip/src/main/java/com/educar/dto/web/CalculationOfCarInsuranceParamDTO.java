/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * �ڵ��� ���� ����� ����ϱ� �Ķ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfCarInsuranceParamDTO")
public class CalculationOfCarInsuranceParamDTO {
	/** �����ڵ� (0130 : ���ο�, 0212 : ������, 0313 : ������, 0418 : �̷�) **/
	private String sInsType;
	/** ���Ǳ��� (ȭ�鿡�� ������, �̷����� 1 �������� 0���� ó��) **/
	@ValidateRegex(predefinedRegex = RegexEnum.OneZeroString)
	private String sSpcType;
	/** ����ñ� (YYYYMMDD) **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sFmdt;
	/** �������� (YYYYMMDD) **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sTodt;
	/** ������� (YYYYMMDD) **/
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd)
	private String sBirth;
	/** ���� (��:M, ��:F) **/
	private String sSex;
	/** ������ȣ **/
	private String sPlateNo;
	/** ���� (sYearType�� task �������� ����) **/
	private String sYear;
	/** ���뵵 (����ٹ� ������ : 1, ���λ�� �� ��Ÿ�뵵 : 2) **/
	private String sUseCode;
	/** ���� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sVehicleCode;
	/** �������� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String nVehicleAmt;
	/** �����ڵ� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sCarCode;
	/** ���� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sCarName;
	/** ���AB (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sYearType;
	/** ���� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sCarType;
	/** ������� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String sCarGradeCode;
	/** ��������� (������ȸ�˾�â(task : "CodeTstk", action : "getCarDetailListPerson" ) ������) **/
	private String nCarGradeRate;
	/** ���ʵ���� (�������ʵ����) **/
	private String sCarRegDate;
	/** �������� (getDisplayCode01 ����) **/
	private String sFamRange;
	/** �������� (getDisplayCode01 ����) **/
	private String sAgeRange;
	/** ���԰�� (getDisplayCode02 ����) **/
	private String sCareerCode;
	/** �������� (getDisplayCode02 ����) **/
	private String sViolateCode;
	/** �������� (getDisplayCode02 ����) sViolateCode �� ���� �� **/
	private String nViolateRate;
	/** ������� (POLAA03�� ����(Ư������)) **/
	private String sMac = "";
	/** ��������ڵ� (��������ڵ�(getDisplayCode01 ����)) **/
	private String sMacCode;
	/** ������ (getDisplayCode01 ����) **/
	private String sSpecCode0111;
	/** ����������� (getDisplayCode01 ����) **/
	private String sApplyCode;
	/** ���������� (getDisplayCode01 ����) **/
	private String nApplyRate;
	/** Ư������ (getDisplayCode01 ����) **/
	private String sExtraCode;
	/** ���Թ�� (getDisplayCode01 ����) **/
	private String sPayClause;
	/** ���ι��1 (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0101;
	/** ���ι��2 (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0102;
	/** �빰��� (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0103;
	/** �ڱ��ü (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0201;
	/** �ڵ������� (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0202;
	/** �������� (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0301;
	/** �������� (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0401;
	/** �ڱ�δ�� ���� �ݾ� **/
	private String sCover0404;
	/** �ڱ�δ�� (�ڵ�(getDisplayCode01 ����)) **/
	private String nDeductRate;
	/** �ڱ�δ�� �ְ� �ݾ� **/
	private String nMaxOptAmt;
	/** ����⵿ (�ڵ�(getDisplayCode01 ����)) **/
	private String sCover0501;

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sSpcType
	 */
	public String getsSpcType() {
		return sSpcType;
	}

	/**
	 * @param sSpcType the sSpcType to set
	 */
	public void setsSpcType(final String sSpcType) {
		this.sSpcType = sSpcType;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sBirth
	 */
	public String getsBirth() {
		return sBirth;
	}

	/**
	 * @param sBirth the sBirth to set
	 */
	public void setsBirth(final String sBirth) {
		this.sBirth = sBirth;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the sUseCode
	 */
	public String getsUseCode() {
		return sUseCode;
	}

	/**
	 * @param sUseCode the sUseCode to set
	 */
	public void setsUseCode(final String sUseCode) {
		this.sUseCode = sUseCode;
	}

	/**
	 * @return the sVehicleCode
	 */
	public String getsVehicleCode() {
		return sVehicleCode;
	}

	/**
	 * @param sVehicleCode the sVehicleCode to set
	 */
	public void setsVehicleCode(final String sVehicleCode) {
		this.sVehicleCode = sVehicleCode;
	}

	/**
	 * @return the nVehicleAmt
	 */
	public String getnVehicleAmt() {
		return nVehicleAmt;
	}

	/**
	 * @param nVehicleAmt the nVehicleAmt to set
	 */
	public void setnVehicleAmt(final String nVehicleAmt) {
		this.nVehicleAmt = nVehicleAmt;
	}

	/**
	 * @return the sCarCode
	 */
	public String getsCarCode() {
		return sCarCode;
	}

	/**
	 * @param sCarCode the sCarCode to set
	 */
	public void setsCarCode(final String sCarCode) {
		this.sCarCode = sCarCode;
	}

	/**
	 * @return the sCarName
	 */
	public String getsCarName() {
		return sCarName;
	}

	/**
	 * @param sCarName the sCarName to set
	 */
	public void setsCarName(final String sCarName) {
		this.sCarName = sCarName;
	}

	/**
	 * @return the sYearType
	 */
	public String getsYearType() {
		return sYearType;
	}

	/**
	 * @param sYearType the sYearType to set
	 */
	public void setsYearType(final String sYearType) {
		this.sYearType = sYearType;
	}

	/**
	 * @return the sCarType
	 */
	public String getsCarType() {
		return sCarType;
	}

	/**
	 * @param sCarType the sCarType to set
	 */
	public void setsCarType(final String sCarType) {
		this.sCarType = sCarType;
	}

	/**
	 * @return the sCarGradeCode
	 */
	public String getsCarGradeCode() {
		return sCarGradeCode;
	}

	/**
	 * @param sCarGradeCode the sCarGradeCode to set
	 */
	public void setsCarGradeCode(final String sCarGradeCode) {
		this.sCarGradeCode = sCarGradeCode;
	}

	/**
	 * @return the nCarGradeRate
	 */
	public String getnCarGradeRate() {
		return nCarGradeRate;
	}

	/**
	 * @param nCarGradeRate the nCarGradeRate to set
	 */
	public void setnCarGradeRate(final String nCarGradeRate) {
		this.nCarGradeRate = nCarGradeRate;
	}

	/**
	 * @return the sCarReqDate
	 */
	public String getsCarRegDate() {
		return sCarRegDate;
	}

	/**
	 * @param sCarReqDate the sCarReqDate to set
	 */
	public void setsCarRegDate(final String sCarRegDate) {
		this.sCarRegDate = sCarRegDate;
	}

	/**
	 * @return the sFamRange
	 */
	public String getsFamRange() {
		return sFamRange;
	}

	/**
	 * @param sFamRange the sFamRange to set
	 */
	public void setsFamRange(final String sFamRange) {
		this.sFamRange = sFamRange;
	}

	/**
	 * @return the sAgeRange
	 */
	public String getsAgeRange() {
		return sAgeRange;
	}

	/**
	 * @param sAgeRange the sAgeRange to set
	 */
	public void setsAgeRange(final String sAgeRange) {
		this.sAgeRange = sAgeRange;
	}

	/**
	 * @return the sCareerCode
	 */
	public String getsCareerCode() {
		return sCareerCode;
	}

	/**
	 * @param sCareerCode the sCareerCode to set
	 */
	public void setsCareerCode(final String sCareerCode) {
		this.sCareerCode = sCareerCode;
	}

	/**
	 * @return the sViolateCode
	 */
	public String getsViolateCode() {
		return sViolateCode;
	}

	/**
	 * @param sViolateCode the sViolateCode to set
	 */
	public void setsViolateCode(final String sViolateCode) {
		this.sViolateCode = sViolateCode;
	}

	/**
	 * @return the sMac
	 */
	public String getsMac() {
		return sMac;
	}

	/**
	 * @param sMac the sMac to set
	 */
	public void setsMac(final String sMac) {
		this.sMac = sMac;
	}

	/**
	 * @return the sMacCode
	 */
	public String getsMacCode() {
		return sMacCode;
	}

	/**
	 * @param sMacCode the sMacCode to set
	 */
	public void setsMacCode(final String sMacCode) {
		this.sMacCode = sMacCode;
	}

	/**
	 * @return the sSpecCode0111
	 */
	public String getsSpecCode0111() {
		return sSpecCode0111;
	}

	/**
	 * @param sSpecCode0111 the sSpecCode0111 to set
	 */
	public void setsSpecCode0111(final String sSpecCode0111) {
		this.sSpecCode0111 = sSpecCode0111;
	}

	/**
	 * @return the sApplyCode
	 */
	public String getsApplyCode() {
		return sApplyCode;
	}

	/**
	 * @param sApplyCode the sApplyCode to set
	 */
	public void setsApplyCode(final String sApplyCode) {
		this.sApplyCode = sApplyCode;
	}

	/**
	 * @return the nApplyRate
	 */
	public String getnApplyRate() {
		return nApplyRate;
	}

	/**
	 * @param nApplyRate the nApplyRate to set
	 */
	public void setnApplyRate(final String nApplyRate) {
		this.nApplyRate = nApplyRate;
	}

	/**
	 * @return the sExtraCode
	 */
	public String getsExtraCode() {
		return sExtraCode;
	}

	/**
	 * @param sExtraCode the sExtraCode to set
	 */
	public void setsExtraCode(final String sExtraCode) {
		this.sExtraCode = sExtraCode;
	}

	/**
	 * @return the sPayClause
	 */
	public String getsPayClause() {
		return sPayClause;
	}

	/**
	 * @param sPayClause the sPayClause to set
	 */
	public void setsPayClause(final String sPayClause) {
		this.sPayClause = sPayClause;
	}

	/**
	 * @return the sCover0101
	 */
	public String getsCover0101() {
		return sCover0101;
	}

	/**
	 * @param sCover0101 the sCover0101 to set
	 */
	public void setsCover0101(final String sCover0101) {
		this.sCover0101 = sCover0101;
	}

	/**
	 * @return the sCover0102
	 */
	public String getsCover0102() {
		return sCover0102;
	}

	/**
	 * @param sCover0102 the sCover0102 to set
	 */
	public void setsCover0102(final String sCover0102) {
		this.sCover0102 = sCover0102;
	}

	/**
	 * @return the sCover0103
	 */
	public String getsCover0103() {
		return sCover0103;
	}

	/**
	 * @param sCover0103 the sCover0103 to set
	 */
	public void setsCover0103(final String sCover0103) {
		this.sCover0103 = sCover0103;
	}

	/**
	 * @return the sCover0201
	 */
	public String getsCover0201() {
		return sCover0201;
	}

	/**
	 * @param sCover0201 the sCover0201 to set
	 */
	public void setsCover0201(final String sCover0201) {
		this.sCover0201 = sCover0201;
	}

	/**
	 * @return the sCover0202
	 */
	public String getsCover0202() {
		return sCover0202;
	}

	/**
	 * @param sCover0202 the sCover0202 to set
	 */
	public void setsCover0202(final String sCover0202) {
		this.sCover0202 = sCover0202;
	}

	/**
	 * @return the sCover0301
	 */
	public String getsCover0301() {
		return sCover0301;
	}

	/**
	 * @param sCover0301 the sCover0301 to set
	 */
	public void setsCover0301(final String sCover0301) {
		this.sCover0301 = sCover0301;
	}

	/**
	 * @return the sCover0401
	 */
	public String getsCover0401() {
		return sCover0401;
	}

	/**
	 * @param sCover0401 the sCover0401 to set
	 */
	public void setsCover0401(final String sCover0401) {
		this.sCover0401 = sCover0401;
	}

	/**
	 * @return the sCover0404
	 */
	public String getsCover0404() {
		return sCover0404;
	}

	/**
	 * @param sCover0404 the sCover0404 to set
	 */
	public void setsCover0404(final String sCover0404) {
		this.sCover0404 = sCover0404;
	}

	/**
	 * @return the sCover0501
	 */
	public String getsCover0501() {
		return sCover0501;
	}

	/**
	 * @param sCover0501 the sCover0501 to set
	 */
	public void setsCover0501(final String sCover0501) {
		this.sCover0501 = sCover0501;
	}

	/**
	 * @return the nDeductRate
	 */
	public String getnDeductRate() {
		return nDeductRate;
	}

	/**
	 * @param nDeductRate the nDeductRate to set
	 */
	public void setnDeductRate(final String nDeductRate) {
		this.nDeductRate = nDeductRate;
	}

	/**
	 * @return the nMaxOptAmt
	 */
	public String getnMaxOptAmt() {
		return nMaxOptAmt;
	}

	/**
	 * @param nMaxOptAmt the nMaxOptAmt to set
	 */
	public void setnMaxOptAmt(final String nMaxOptAmt) {
		this.nMaxOptAmt = nMaxOptAmt;
	}

	/**
	 * @return the nViolateRate
	 */
	public String getnViolateRate() {
		return nViolateRate;
	}

	/**
	 * @param nViolateRate the nViolateRate to set
	 */
	public void setnViolateRate(final String nViolateRate) {
		this.nViolateRate = nViolateRate;
	}
}
