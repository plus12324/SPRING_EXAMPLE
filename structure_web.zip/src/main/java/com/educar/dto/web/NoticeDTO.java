/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * �������� DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "noticeDTO")
public class NoticeDTO extends PageDTO implements Serializable {

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ */
	private Integer nSeq;
	/** ���� */
	private String sTitle;
	/** ���� */
	private String sContent;
	/** �������� */
	private String sViewYn;
	/** ��ܰ������� */
	private String sTopYn;
	/** ��ȸ�� */
	private int nVisitCnt;
	/** ������¥ */
	private String sOpenDate;
	/** PC ���� ���� **/
	private String sPCViewYN;
	/** mobile ���� ���� **/
	private String sMobileViewYN;
	/** mobile ���� **/
	private String sMobileContent;
	/** ������ */
	private String sRegId;
	/** ������¥ */
	private String sRegDate;
	/** �����ð� */
	private String sRegTime;
	/** ������ */
	private String sUpId;
	/** ������¥ */
	private String sUpDate;
	/** �����ð� */
	private String sUpTime;

	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/
	@XmlTransient
	private String kind;
	/** �˻��� **/
	@XmlTransient
	private String searchValue;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	/** PC ����� ���⿩��(�����ڿ��� ���) **/
	@XmlTransient
	private String pcMobileViewYN;

	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final Integer nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}

	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(final String sContent) {
		this.sContent = sContent;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sTopYn
	 */
	public String getsTopYn() {
		return sTopYn;
	}

	/**
	 * @param sTopYn the sTopYn to set
	 */
	public void setsTopYn(final String sTopYn) {
		this.sTopYn = sTopYn;
	}

	/**
	 * @return the nVisitCnt
	 */
	public int getnVisitCnt() {
		return nVisitCnt;
	}

	/**
	 * @param nVisitCnt the nVisitCnt to set
	 */
	public void setnVisitCnt(final int nVisitCnt) {
		this.nVisitCnt = nVisitCnt;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sPCViewYN
	 */
	public String getsPCViewYN() {
		return sPCViewYN;
	}

	/**
	 * @param sPCViewYN the sPCViewYN to set
	 */
	public void setsPCViewYN(final String sPCViewYN) {
		this.sPCViewYN = sPCViewYN;
	}

	/**
	 * @return the sMobileViewYN
	 */
	public String getsMobileViewYN() {
		return sMobileViewYN;
	}

	/**
	 * @param sMobileViewYN the sMobileViewYN to set
	 */
	public void setsMobileViewYN(final String sMobileViewYN) {
		this.sMobileViewYN = sMobileViewYN;
	}

	/**
	 * @return the sMobileContent
	 */
	public String getsMobileContent() {
		return sMobileContent;
	}

	/**
	 * @param sMobileContent the sMobileContent to set
	 */
	public void setsMobileContent(final String sMobileContent) {
		this.sMobileContent = sMobileContent;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}

	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(final String sUpDate) {
		this.sUpDate = sUpDate;
	}

	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}

	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(final String sUpTime) {
		this.sUpTime = sUpTime;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(final String kind) {
		this.kind = kind;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(final String searchValue) {
		this.searchValue = searchValue;
	}

	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}

	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(final String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}

	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}

	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(final String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}

	/**
	 * @return the pcMobileViewYN
	 */
	public String getPcMobileViewYN() {
		return pcMobileViewYN;
	}

	/**
	 * @param pcMobileViewYN the pcMobileViewYN to set
	 */
	public void setPcMobileViewYN(final String pcMobileViewYN) {
		this.pcMobileViewYN = pcMobileViewYN;
	}

}
