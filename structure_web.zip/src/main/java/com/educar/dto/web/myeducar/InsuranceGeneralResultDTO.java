/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲݺ��� ��ȸ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralResultDTO")
public class InsuranceGeneralResultDTO {
	/** ����ȣ **/
	private String sContNumber;
	/** �����ǰ�� **/
	private String sInsPdtName;
	/** �Ǻ����� **/
	private String sInsrdName;
	/** ����ñ� **/
	private String sInsCtrTpd;
	/** ��������**/
	private String sInsCtrPed;
	/** ��ǰ���� **/
	private String sPdtType;
	/** �������� **/
	private String sEtnTypNam;
	/** ���� **/
	private String sContStaName;
	/** �Ǻ����� ���� **/
	private String nInrpsSeqno;

	/**
	 * @return the sContNumber
	 */
	public String getsContNumber() {
		return sContNumber;
	}

	/**
	 * @param sContNumber the sContNumber to set
	 */
	public void setsContNumber(final String sContNumber) {
		this.sContNumber = sContNumber;
	}

	/**
	 * @return the sInsPdtName
	 */
	public String getsInsPdtName() {
		return sInsPdtName;
	}

	/**
	 * @param sInsPdtName the sInsPdtName to set
	 */
	public void setsInsPdtName(final String sInsPdtName) {
		this.sInsPdtName = sInsPdtName;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsCtrTpd
	 */
	public String getsInsCtrTpd() {
		return sInsCtrTpd;
	}

	/**
	 * @param sInsCtrTpd the sInsCtrTpd to set
	 */
	public void setsInsCtrTpd(final String sInsCtrTpd) {
		this.sInsCtrTpd = sInsCtrTpd;
	}

	/**
	 * @return the sPdtType
	 */
	public String getsPdtType() {
		return sPdtType;
	}

	/**
	 * @param sPdtType the sPdtType to set
	 */
	public void setsPdtType(final String sPdtType) {
		this.sPdtType = sPdtType;
	}

	/**
	 * @return the sEtnTypNam
	 */
	public String getsEtnTypNam() {
		return sEtnTypNam;
	}

	/**
	 * @param sEtnTypNam the sEtnTypNam to set
	 */
	public void setsEtnTypNam(final String sEtnTypNam) {
		this.sEtnTypNam = sEtnTypNam;
	}

	/**
	 * @return the sContStaName
	 */
	public String getsContStaName() {
		return sContStaName;
	}

	/**
	 * @param sContStaName the sContStaName to set
	 */
	public void setsContStaName(final String sContStaName) {
		this.sContStaName = sContStaName;
	}

	/**
	 * @return the sInsCtrPed
	 */
	public String getsInsCtrPed() {
		return sInsCtrPed;
	}

	/**
	 * @param sInsCtrPed the sInsCtrPed to set
	 */
	public void setsInsCtrPed(final String sInsCtrPed) {
		this.sInsCtrPed = sInsCtrPed;
	}

	/**
	 * @return the nInrpsSeqno
	 */
	public String getnInrpsSeqno() {
		return nInrpsSeqno;
	}

	/**
	 * @param nInrpsSeqno the nInrpsSeqno to set
	 */
	public void setnInrpsSeqno(final String nInrpsSeqno) {
		this.nInrpsSeqno = nInrpsSeqno;
	}

}
