/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����/���� ȯ�ޱ���ȸ - �⺻��ȸ
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insRefundsCrDataDTO")
public class InsRefundsCrDataDTO {
	/** 	��ũ��ID	**/ 
	private String	sScrnId	;
	/** 	��������	**/ 
	private String	sBizCat	;
	/** 	����ȣ	**/ 
	private String	sCrNo;
	/** 	������ڵ�	**/ 
	private String	sCrtorCd;
	/** 	�����	**/ 
	private String	sCrtorName;
	/** 	�Ǻ������ڵ�	**/ 
	private String	sInrpsCd;
	/** 	�Ǻ����ڸ�	**/ 
	private String	sInrpsName;
	/** 	���ñ�	**/ 
	private String	sInsurStrtdate;
	/** 	�������	**/ 
	private String	sInsurEndDate;
	/** 	�������ڵ�	**/ 
	private String	sCrStatCd;
	/** 	�����¸�	**/ 
	private String	sCrStatCdName;
	/** 	���Թ���ڵ�	**/ 
	private String	sCmMetd;
	/** 	���Թ��	**/ 
	private String	sCmMetdName;
	/** 	�������Ͽ�	**/ 
	private String	sFinalPaymMthy;
	/** 	��������ȸ��	**/ 
	private String	nFinalPaymSeq;
	/** 	�����ֱ��ڵ�	**/ 
	private String	sPaymCyclCd;
	/** 	�����ֱ�	**/ 
	private String	sPaymCyclCdName;
	/** 	1ȸ�����	**/ 
	private String	nApplPrem;
	/** 	�ѳ��Ժ����	**/ 
	private String	nTotPaymPrem;
	/** 	�����ǰ��	**/ 
	private String	sGdCdName;
	/** 	���±���	**/ 
	private String	sAcctKind;
	/** 	�����ڹ�ȣ	**/ 
	private String	sPayrNo;
	/** 	��ü��	**/ 
	private String	sTrnfAsmtDate;
	/** 	�����	**/
	private String	sBankCdName;
	/** 	�����ڵ�	**/ 
	private String	sBankCd;
	/** 	��ü����	**/ 
	private String	sTrnInfo;
	/** 	���¹�ȣ/ī���ȣ	**/ 
	private String	sAcctNo;
	/** 	ī����ȿ�Ⱓ	**/ 
	private String	sCardValdYearMnth;
	/** 	�����ָ�/ī���ָ�	**/ 
	private String	sDpsrName;
	/** 	��������	**/ 
	private String	sApplDclrRato;
	/** 	�����߻��	**/ 
	private String	sCrAccdName;
	/** 	ī���	**/ 
	private String	CardName;
	/** 	û���ȣ	**/ 
	private String	sPlanNo;
	/**
	 * @return the sScrnId
	 */
	public String getsScrnId() {
		return sScrnId;
	}
	/**
	 * @param sScrnId the sScrnId to set
	 */
	public void setsScrnId(String sScrnId) {
		this.sScrnId = sScrnId;
	}
	/**
	 * @return the sBizCat
	 */
	public String getsBizCat() {
		return sBizCat;
	}
	/**
	 * @param sBizCat the sBizCat to set
	 */
	public void setsBizCat(String sBizCat) {
		this.sBizCat = sBizCat;
	}
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}
	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sInrpsCd
	 */
	public String getsInrpsCd() {
		return sInrpsCd;
	}
	/**
	 * @param sInrpsCd the sInrpsCd to set
	 */
	public void setsInrpsCd(String sInrpsCd) {
		this.sInrpsCd = sInrpsCd;
	}
	/**
	 * @return the sInrpsName
	 */
	public String getsInrpsName() {
		return sInrpsName;
	}
	/**
	 * @param sInrpsName the sInrpsName to set
	 */
	public void setsInrpsName(String sInrpsName) {
		this.sInrpsName = sInrpsName;
	}
	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}
	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}
	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}
	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}
	/**
	 * @return the sCrStatCd
	 */
	public String getsCrStatCd() {
		return sCrStatCd;
	}
	/**
	 * @param sCrStatCd the sCrStatCd to set
	 */
	public void setsCrStatCd(String sCrStatCd) {
		this.sCrStatCd = sCrStatCd;
	}
	/**
	 * @return the sCrStatCdName
	 */
	public String getsCrStatCdName() {
		return sCrStatCdName;
	}
	/**
	 * @param sCrStatCdName the sCrStatCdName to set
	 */
	public void setsCrStatCdName(String sCrStatCdName) {
		this.sCrStatCdName = sCrStatCdName;
	}
	/**
	 * @return the sCmMetd
	 */
	public String getsCmMetd() {
		return sCmMetd;
	}
	/**
	 * @param sCmMetd the sCmMetd to set
	 */
	public void setsCmMetd(String sCmMetd) {
		this.sCmMetd = sCmMetd;
	}
	/**
	 * @return the sCmMetdName
	 */
	public String getsCmMetdName() {
		return sCmMetdName;
	}
	/**
	 * @param sCmMetdName the sCmMetdName to set
	 */
	public void setsCmMetdName(String sCmMetdName) {
		this.sCmMetdName = sCmMetdName;
	}
	/**
	 * @return the sFinalPaymMthy
	 */
	public String getsFinalPaymMthy() {
		return sFinalPaymMthy;
	}
	/**
	 * @param sFinalPaymMthy the sFinalPaymMthy to set
	 */
	public void setsFinalPaymMthy(String sFinalPaymMthy) {
		this.sFinalPaymMthy = sFinalPaymMthy;
	}
	/**
	 * @return the nFinalPaymSeq
	 */
	public String getnFinalPaymSeq() {
		return nFinalPaymSeq;
	}
	/**
	 * @param nFinalPaymSeq the nFinalPaymSeq to set
	 */
	public void setnFinalPaymSeq(String nFinalPaymSeq) {
		this.nFinalPaymSeq = nFinalPaymSeq;
	}
	/**
	 * @return the sPaymCyclCd
	 */
	public String getsPaymCyclCd() {
		return sPaymCyclCd;
	}
	/**
	 * @param sPaymCyclCd the sPaymCyclCd to set
	 */
	public void setsPaymCyclCd(String sPaymCyclCd) {
		this.sPaymCyclCd = sPaymCyclCd;
	}
	/**
	 * @return the sPaymCyclCdName
	 */
	public String getsPaymCyclCdName() {
		return sPaymCyclCdName;
	}
	/**
	 * @param sPaymCyclCdName the sPaymCyclCdName to set
	 */
	public void setsPaymCyclCdName(String sPaymCyclCdName) {
		this.sPaymCyclCdName = sPaymCyclCdName;
	}
	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}
	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}
	/**
	 * @return the nTotPaymPrem
	 */
	public String getnTotPaymPrem() {
		return nTotPaymPrem;
	}
	/**
	 * @param nTotPaymPrem the nTotPaymPrem to set
	 */
	public void setnTotPaymPrem(String nTotPaymPrem) {
		this.nTotPaymPrem = nTotPaymPrem;
	}
	/**
	 * @return the sGdCdName
	 */
	public String getsGdCdName() {
		return sGdCdName;
	}
	/**
	 * @param sGdCdName the sGdCdName to set
	 */
	public void setsGdCdName(String sGdCdName) {
		this.sGdCdName = sGdCdName;
	}
	/**
	 * @return the sAcctKind
	 */
	public String getsAcctKind() {
		return sAcctKind;
	}
	/**
	 * @param sAcctKind the sAcctKind to set
	 */
	public void setsAcctKind(String sAcctKind) {
		this.sAcctKind = sAcctKind;
	}
	/**
	 * @return the sPayrNo
	 */
	public String getsPayrNo() {
		return sPayrNo;
	}
	/**
	 * @param sPayrNo the sPayrNo to set
	 */
	public void setsPayrNo(String sPayrNo) {
		this.sPayrNo = sPayrNo;
	}
	/**
	 * @return the sTrnfAsmtDate
	 */
	public String getsTrnfAsmtDate() {
		return sTrnfAsmtDate;
	}
	/**
	 * @param sTrnfAsmtDate the sTrnfAsmtDate to set
	 */
	public void setsTrnfAsmtDate(String sTrnfAsmtDate) {
		this.sTrnfAsmtDate = sTrnfAsmtDate;
	}
	/**
	 * @return the sBankCdName
	 */
	public String getsBankCdName() {
		return sBankCdName;
	}
	/**
	 * @param sBankCdName the sBankCdName to set
	 */
	public void setsBankCdName(String sBankCdName) {
		this.sBankCdName = sBankCdName;
	}
	/**
	 * @return the sBankCd
	 */
	public String getsBankCd() {
		return sBankCd;
	}
	/**
	 * @param sBankCd the sBankCd to set
	 */
	public void setsBankCd(String sBankCd) {
		this.sBankCd = sBankCd;
	}
	/**
	 * @return the sTrnInfo
	 */
	public String getsTrnInfo() {
		return sTrnInfo;
	}
	/**
	 * @param sTrnInfo the sTrnInfo to set
	 */
	public void setsTrnInfo(String sTrnInfo) {
		this.sTrnInfo = sTrnInfo;
	}
	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}
	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}
	/**
	 * @return the sCardValdYearMnth
	 */
	public String getsCardValdYearMnth() {
		return sCardValdYearMnth;
	}
	/**
	 * @param sCardValdYearMnth the sCardValdYearMnth to set
	 */
	public void setsCardValdYearMnth(String sCardValdYearMnth) {
		this.sCardValdYearMnth = sCardValdYearMnth;
	}
	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}
	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}
	/**
	 * @return the sApplDclrRato
	 */
	public String getsApplDclrRato() {
		return sApplDclrRato;
	}
	/**
	 * @param sApplDclrRato the sApplDclrRato to set
	 */
	public void setsApplDclrRato(String sApplDclrRato) {
		this.sApplDclrRato = sApplDclrRato;
	}
	/**
	 * @return the sCrAccdName
	 */
	public String getsCrAccdName() {
		return sCrAccdName;
	}
	/**
	 * @param sCrAccdName the sCrAccdName to set
	 */
	public void setsCrAccdName(String sCrAccdName) {
		this.sCrAccdName = sCrAccdName;
	}
	/**
	 * @return the cardName
	 */
	public String getCardName() {
		return CardName;
	}
	/**
	 * @param cardName the cardName to set
	 */
	public void setCardName(String cardName) {
		CardName = cardName;
	}
	/**
	 * @return the sPlanNo
	 */
	public String getsPlanNo() {
		return sPlanNo;
	}
	/**
	 * @param sPlanNo the sPlanNo to set
	 */
	public void setsPlanNo(String sPlanNo) {
		this.sPlanNo = sPlanNo;
	}

	
	
}
