/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ī ������ ���� ����� ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfEducarInsuranceSearchDTO")
public class PriceCalculationOfEducarInsuranceSearchDTO {
	/** ���� ���� **/
	private EducarPriceCalculationBasicInfoDTO BasicInfo;
	/** ���� �㺸 ����Ʈ **/
	@XmlElementWrapper(name = "sCovSelList")
	private List<EducarDriverInsurancePawnDTO> sCovSel;

	/**
	 * @return the basicInfo
	 */
	public EducarPriceCalculationBasicInfoDTO getBasicInfo() {
		return BasicInfo;
	}

	/**
	 * @param basicInfo the basicInfo to set
	 */
	public void setBasicInfo(final EducarPriceCalculationBasicInfoDTO basicInfo) {
		BasicInfo = basicInfo;
	}

	/**
	 * @return the sCovSel
	 */
	public List<EducarDriverInsurancePawnDTO> getsCovSel() {
		return sCovSel;
	}

	/**
	 * @param sCovSel the sCovSel to set
	 */
	public void setsCovSel(final List<EducarDriverInsurancePawnDTO> sCovSel) {
		this.sCovSel = sCovSel;
	}

}
