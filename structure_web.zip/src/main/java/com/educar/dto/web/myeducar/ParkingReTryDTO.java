/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����Ƚɼ��� - ���û�� ���Ǵ� DTO
 * @since 0.0.10
 */
@XmlRootElement(name = "parkingReTryDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ParkingReTryDTO {

	/** 	������ȣ	**/ 
	private String 	sCustNo;
	/** 	�߱޹��ڵ�	**/ 
	private String 	sDmCode;
	/** 	����ȣ	**/ 
	private String 	sPolicyNo;
	/** 	�߼۹��	**/ 
	private String 	rmethod;
	/** 	�ּ�Ÿ��	**/ 
	private String 	sAdrsType;
	/** 	����ȸ��	**/ 
	private String 	nChangeNo;
	/** 	������ȣ(3 ���θ�)	**/ 
	private String 	sZipType;
	/** 	������ȣ	**/ 
	private String 	sZip1;
	/** 	������ȣ	**/ 
	private String 	sZip2;
	/** 	�ּ�1	**/ 
	private String 	sAdrs1; 
	/** 	�ּ�2	**/ 
	private String 	sAdrs2; 
	/** 	�ּ�3	**/ 
	private String 	sAdrs3; 
	/** 	�߰��ּ�	**/ 
	private String 	sAdrsAdd;
	/** ���λ����ּ� **/
	private String sDoroAddr;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sDmCode
	 */
	public String getsDmCode() {
		return sDmCode;
	}
	/**
	 * @param sDmCode the sDmCode to set
	 */
	public void setsDmCode(String sDmCode) {
		this.sDmCode = sDmCode;
	}
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the rmethod
	 */
	public String getRmethod() {
		return rmethod;
	}
	/**
	 * @param rmethod the rmethod to set
	 */
	public void setRmethod(String rmethod) {
		this.rmethod = rmethod;
	}
	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}
	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}
	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}
	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}
	/**
	 * @return the sZipType
	 */
	public String getsZipType() {
		return sZipType;
	}
	/**
	 * @param sZipType the sZipType to set
	 */
	public void setsZipType(String sZipType) {
		this.sZipType = sZipType;
	}
	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}
	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}
	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}
	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}
	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}
	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}
	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}
	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}
	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}
	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}
	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}
	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}
	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr() {
		return sDoroAddr;
	}
	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr(String sDoroAddr) {
		this.sDoroAddr = sDoroAddr;
	}
	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}
	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}
	
	

}
