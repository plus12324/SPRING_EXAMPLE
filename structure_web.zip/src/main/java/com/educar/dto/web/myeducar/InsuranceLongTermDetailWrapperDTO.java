/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ��⺸�� �� ��ȸ WrapperDTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "insuranceLongTermDetailWrapperDTO")
public class InsuranceLongTermDetailWrapperDTO {

	/** ��⺸�� �� **/
	private SelectCntrDtlResultDTO detailResult;
	/** ��⺸�� ����� ���� ���� **/
	private List<PremRecvWdrcDlSpecResultDTO> paymentResultList;
	/** ������ ������� **/
	private List<SelectLoanCsclsInqrSearchResultDTO> loanResultList;

	/**
	 * @return the detailResult
	 */
	public SelectCntrDtlResultDTO getDetailResult() {
		return detailResult;
	}

	/**
	 * @param detailResult the detailResult to set
	 */
	public void setDetailResult(final SelectCntrDtlResultDTO detailResult) {
		this.detailResult = detailResult;
	}

	/**
	 * @return the paymentResultList
	 */
	public List<PremRecvWdrcDlSpecResultDTO> getPaymentResultList() {
		return paymentResultList;
	}

	/**
	 * @param paymentResultList the paymentResultList to set
	 */
	public void setPaymentResultList(final List<PremRecvWdrcDlSpecResultDTO> paymentResultList) {
		this.paymentResultList = paymentResultList;
	}

	/**
	 * @return the loanResultList
	 */
	public List<SelectLoanCsclsInqrSearchResultDTO> getLoanResultList() {
		return loanResultList;
	}

	/**
	 * @param loanResultList the loanResultList to set
	 */
	public void setLoanResultList(final List<SelectLoanCsclsInqrSearchResultDTO> loanResultList) {
		this.loanResultList = loanResultList;
	}
}
