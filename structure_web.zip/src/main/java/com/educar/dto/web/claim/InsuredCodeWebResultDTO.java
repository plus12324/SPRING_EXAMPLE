/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������Ȯ�μ� ����Ʈ
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "insuredCodeWebResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsuredCodeWebResultDTO {
	/** ���������ȣ **/
	private String sAccidentNo;
	/** �㺸 **/
	private String sHndCover;
	/** ���� **/
	private String sDmgeNo;
	/** ������� **/
	private String sAcctDate;
	/** ������(ȭ��ǥ�ÿ�) **/
	private String acctAddr;
	/** ������1 **/
	private String sAcctAddr1;
	/** ������2 **/
	private String sAcctAddr2;
	/** �����ڸ� **/
	private String sVictimName;
	/** �������� **/
	private String sStaffName;
	/** ���������ڵ� **/
	private String sStaff;

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}

	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(final String sHndCover) {
		this.sHndCover = sHndCover;
	}

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the acctAddr
	 */
	public String getAcctAddr() {
		return acctAddr;
	}

	/**
	 * @param acctAddr the acctAddr to set
	 */
	public void setAcctAddr(final String acctAddr) {
		this.acctAddr = acctAddr;
	}

	/**
	 * @return the sAcctAddr1
	 */
	public String getsAcctAddr1() {
		return sAcctAddr1;
	}

	/**
	 * @param sAcctAddr1 the sAcctAddr1 to set
	 */
	public void setsAcctAddr1(final String sAcctAddr1) {
		this.sAcctAddr1 = sAcctAddr1;
	}

	/**
	 * @return the sAcctAddr2
	 */
	public String getsAcctAddr2() {
		return sAcctAddr2;
	}

	/**
	 * @param sAcctAddr2 the sAcctAddr2 to set
	 */
	public void setsAcctAddr2(final String sAcctAddr2) {
		this.sAcctAddr2 = sAcctAddr2;
	}

	/**
	 * @return the sVictimName
	 */
	public String getsVictimName() {
		return sVictimName;
	}

	/**
	 * @param sVictimName the sVictimName to set
	 */
	public void setsVictimName(final String sVictimName) {
		this.sVictimName = sVictimName;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sStaff
	 */
	public String getsStaff() {
		return sStaff;
	}

	/**
	 * @param sStaff the sStaff to set
	 */
	public void setsStaff(final String sStaff) {
		this.sStaff = sStaff;
	}

}
