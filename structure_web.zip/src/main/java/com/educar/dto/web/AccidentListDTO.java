/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ - ���Ȯ�μ� - ���������ȸ ������� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "accidentListDTO")
public class AccidentListDTO {
	/** ������� **/
	private String sAccidentDate;
	/** ������ȣ **/
	private String sRegiNumber;
	/** ������ **/
	private String sAccidentPlace;
	/** �㺸 **/
	private String sSurety;
	/** ���� **/
	private String sRank;
	/** �ֹι�ȣ **/
	private String sSsn;
	/** �����ڸ� **/
	private String sVictim;
	/** ���ع� **/
	private String sDamagedStuff;
	/** �뺸�� **/
	private String sCaller;
	/** �����Ͻ� **/
	private String sRegiDate;

	/**
	 * @return the sAccidentDate
	 */
	public String getsAccidentDate() {
		return sAccidentDate;
	}

	/**
	 * @param sAccidentDate the sAccidentDate to set
	 */
	public void setsAccidentDate(String sAccidentDate) {
		this.sAccidentDate = sAccidentDate;
	}

	/**
	 * @return the sRegiNumber
	 */
	public String getsRegiNumber() {
		return sRegiNumber;
	}

	/**
	 * @param sRegiNumber the sRegiNumber to set
	 */
	public void setsRegiNumber(String sRegiNumber) {
		this.sRegiNumber = sRegiNumber;
	}

	/**
	 * @return the sAccidentPlace
	 */
	public String getsAccidentPlace() {
		return sAccidentPlace;
	}

	/**
	 * @param sAccidentPlace the sAccidentPlace to set
	 */
	public void setsAccidentPlace(String sAccidentPlace) {
		this.sAccidentPlace = sAccidentPlace;
	}

	/**
	 * @return the sCaller
	 */
	public String getsCaller() {
		return sCaller;
	}

	/**
	 * @param sCaller the sCaller to set
	 */
	public void setsCaller(String sCaller) {
		this.sCaller = sCaller;
	}

	/**
	 * @return the sRegiDate
	 */
	public String getsRegiDate() {
		return sRegiDate;
	}

	/**
	 * @param sRegiDate the sRegiDate to set
	 */
	public void setsRegiDate(String sRegiDate) {
		this.sRegiDate = sRegiDate;
	}

	/**
	 * @return the sSurety
	 */
	public String getsSurety() {
		return sSurety;
	}

	/**
	 * @param sSurety the sSurety to set
	 */
	public void setsSurety(String sSurety) {
		this.sSurety = sSurety;
	}

	/**
	 * @return the sRank
	 */
	public String getsRank() {
		return sRank;
	}

	/**
	 * @param sRank the sRank to set
	 */
	public void setsRank(String sRank) {
		this.sRank = sRank;
	}

	/**
	 * @return the sDamagedStuff
	 */
	public String getsDamagedStuff() {
		return sDamagedStuff;
	}

	/**
	 * @param sDamagedStuff the sDamagedStuff to set
	 */
	public void setsDamagedStuff(String sDamagedStuff) {
		this.sDamagedStuff = sDamagedStuff;
	}

	/**
	 * @return the sVictim
	 */
	public String getsVictim() {
		return sVictim;
	}

	/**
	 * @param sVictim the sVictim to set
	 */
	public void setsVictim(String sVictim) {
		this.sVictim = sVictim;
	}

	/**
	 * @return the sSsn
	 */
	public String getsSsn() {
		return sSsn;
	}

	/**
	 * @param sSsn the sSsn to set
	 */
	public void setsSsn(String sSsn) {
		this.sSsn = sSsn;
	}
}
