/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������ó�� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "inDirectDepositDTO")
public class PolicyReceiptInfoDTO {
	/** û���ȣ **/
	private String sApplyType;
	/** û���ȣ **/
	private String sApplyYM;
	/** û���ȣ **/
	private String sApplySer;
	/** ���� **/
	private String sInsType;
	/** �����ݾ� **/
	private String nRectPrem;
	/** ���� **/
	private String nCashPrem;
	/** �����ڵ� **/
	private String sBankCode;
	/** �Աݿ����� **/
	private String sExpectDate;
	/** ����ñ� **/
	private String sFromDate;
	/** �������� : 2 : ī�� **/
	private String sCollType;

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}

	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(final String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}

	/**
	 * @return the nCashPrem
	 */
	public String getnCashPrem() {
		return nCashPrem;
	}

	/**
	 * @param nCashPrem the nCashPrem to set
	 */
	public void setnCashPrem(final String nCashPrem) {
		this.nCashPrem = nCashPrem;
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sExpectDate
	 */
	public String getsExpectDate() {
		return sExpectDate;
	}

	/**
	 * @param sExpectDate the sExpectDate to set
	 */
	public void setsExpectDate(final String sExpectDate) {
		this.sExpectDate = sExpectDate;
	}

	/**
	 * @return the sFromDate
	 */
	public String getsFromDate() {
		return sFromDate;
	}

	/**
	 * @param sFromDate the sFromDate to set
	 */
	public void setsFromDate(final String sFromDate) {
		this.sFromDate = sFromDate;
	}

	/**
	 * @return the sCollType
	 */
	public String getsCollType() {
		return sCollType;
	}

	/**
	 * @param sCollType the sCollType to set
	 */
	public void setsCollType(final String sCollType) {
		this.sCollType = sCollType;
	}

}
