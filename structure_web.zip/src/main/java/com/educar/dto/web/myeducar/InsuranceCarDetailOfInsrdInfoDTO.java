/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ��� ����ȸ ��� DTO (�Ǻ����� ����)
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceCarDetailOfInsrdInfoDTO")
public class InsuranceCarDetailOfInsrdInfoDTO {
	/** ���ǹ�ȣ **/
	private String sKeyType;
	/** ���ǹ�ȣ **/
	private String sKeyYM;
	/** ���ǹ�ȣ **/
	private String sKeySeq;
	/** �������� **/
	private String sCustType;
	/** �Ǻ�����ID **/
	private String sCustNo;
	/** �Ǻ�����ID_���� **/
	private String nCustSeq;
	/** �Ǻ����ڸ� **/
	private String sCustName;
	/** �Ǻ������ּұ��� **/
	private String sAdrsType;
	/** �ּҼ��� **/
	private String nAdrsSeq;
	/** ��ȭ���� **/
	private String nTelSeq;
	/** �̸��� **/
	private String sEmail1;
	/** �̸���2 **/
	private String sEmail2;
	/** ����ȭ1 **/
	private String sHomeTel1;
	/** ����ȭ2 **/
	private String sHomeTel2;
	/** ����ȭ3 **/
	private String sHomeTel3;
	/** ������ȭ1 **/
	private String sOfficeTel1;
	/** ������ȭ2 **/
	private String sOfficeTel2;
	/** ������ȭ3 **/
	private String sOfficeTel3;
	/** ������ȣ **/
	private String sInnerPhone;
	/** �ڵ���1 **/
	private String sCellPhone1;
	/** �ڵ���2 **/
	private String sCellPhone2;
	/** �ڵ���3 **/
	private String sCellPhone3;

	/**
	 * @return the sKeyType
	 */
	public String getsKeyType() {
		return sKeyType;
	}

	/**
	 * @param sKeyType the sKeyType to set
	 */
	public void setsKeyType(final String sKeyType) {
		this.sKeyType = sKeyType;
	}

	/**
	 * @return the sKeyYM
	 */
	public String getsKeyYM() {
		return sKeyYM;
	}

	/**
	 * @param sKeyYM the sKeyYM to set
	 */
	public void setsKeyYM(final String sKeyYM) {
		this.sKeyYM = sKeyYM;
	}

	/**
	 * @return the sKeySeq
	 */
	public String getsKeySeq() {
		return sKeySeq;
	}

	/**
	 * @param sKeySeq the sKeySeq to set
	 */
	public void setsKeySeq(final String sKeySeq) {
		this.sKeySeq = sKeySeq;
	}

	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}

	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(final String sCustType) {
		this.sCustType = sCustType;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the nCustSeq
	 */
	public String getnCustSeq() {
		return nCustSeq;
	}

	/**
	 * @param nCustSeq the nCustSeq to set
	 */
	public void setnCustSeq(final String nCustSeq) {
		this.nCustSeq = nCustSeq;
	}

	/**
	 * @return the sCustName
	 */
	public String getsCustName() {
		return sCustName;
	}

	/**
	 * @param sCustName the sCustName to set
	 */
	public void setsCustName(final String sCustName) {
		this.sCustName = sCustName;
	}

	/**
	 * @return the sAdrsType
	 */
	public String getsAdrsType() {
		return sAdrsType;
	}

	/**
	 * @param sAdrsType the sAdrsType to set
	 */
	public void setsAdrsType(final String sAdrsType) {
		this.sAdrsType = sAdrsType;
	}

	/**
	 * @return the nAdrsSeq
	 */
	public String getnAdrsSeq() {
		return nAdrsSeq;
	}

	/**
	 * @param nAdrsSeq the nAdrsSeq to set
	 */
	public void setnAdrsSeq(final String nAdrsSeq) {
		this.nAdrsSeq = nAdrsSeq;
	}

	/**
	 * @return the nTelSeq
	 */
	public String getnTelSeq() {
		return nTelSeq;
	}

	/**
	 * @param nTelSeq the nTelSeq to set
	 */
	public void setnTelSeq(final String nTelSeq) {
		this.nTelSeq = nTelSeq;
	}

	/**
	 * @return the sEmail1
	 */
	public String getsEmail1() {
		return sEmail1;
	}

	/**
	 * @param sEmail1 the sEmail1 to set
	 */
	public void setsEmail1(final String sEmail1) {
		this.sEmail1 = sEmail1;
	}

	/**
	 * @return the sEmail2
	 */
	public String getsEmail2() {
		return sEmail2;
	}

	/**
	 * @param sEmail2 the sEmail2 to set
	 */
	public void setsEmail2(final String sEmail2) {
		this.sEmail2 = sEmail2;
	}

	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}

	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(final String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}

	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}

	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(final String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}

	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}

	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(final String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}

	/**
	 * @return the sOfficeTel1
	 */
	public String getsOfficeTel1() {
		return sOfficeTel1;
	}

	/**
	 * @param sOfficeTel1 the sOfficeTel1 to set
	 */
	public void setsOfficeTel1(final String sOfficeTel1) {
		this.sOfficeTel1 = sOfficeTel1;
	}

	/**
	 * @return the sOfficeTel2
	 */
	public String getsOfficeTel2() {
		return sOfficeTel2;
	}

	/**
	 * @param sOfficeTel2 the sOfficeTel2 to set
	 */
	public void setsOfficeTel2(final String sOfficeTel2) {
		this.sOfficeTel2 = sOfficeTel2;
	}

	/**
	 * @return the sOfficeTel3
	 */
	public String getsOfficeTel3() {
		return sOfficeTel3;
	}

	/**
	 * @param sOfficeTel3 the sOfficeTel3 to set
	 */
	public void setsOfficeTel3(final String sOfficeTel3) {
		this.sOfficeTel3 = sOfficeTel3;
	}

	/**
	 * @return the sInnerPhone
	 */
	public String getsInnerPhone() {
		return sInnerPhone;
	}

	/**
	 * @param sInnerPhone the sInnerPhone to set
	 */
	public void setsInnerPhone(final String sInnerPhone) {
		this.sInnerPhone = sInnerPhone;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

}
