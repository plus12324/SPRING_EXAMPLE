/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �������� ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carPhotoInfoDTO")
public class CarPhotoInfoDTO {
	/** ��� **/
	private String sYM;
	/** �Ϸù�ȣ **/
	private String nSerial;
	/** ������ȣ **/
	private String nPictureNum;
	/** �������ϸ� **/
	private String sPictureName;
	/** ����ID **/
	private String fileID;

	/**
	 * @return the fileID
	 */
	public String getFileID() {
		return fileID;
	}

	/**
	 * @param fileID the fileID to set
	 */
	public void setFileID(final String fileID) {
		this.fileID = fileID;
	}

	/**
	 * @return the sYM
	 */
	public String getsYM() {
		return sYM;
	}

	/**
	 * @param sYM the sYM to set
	 */
	public void setsYM(final String sYM) {
		this.sYM = sYM;
	}

	/**
	 * @return the nSerial
	 */
	public String getnSerial() {
		return nSerial;
	}

	/**
	 * @param nSerial the nSerial to set
	 */
	public void setnSerial(final String nSerial) {
		this.nSerial = nSerial;
	}

	/**
	 * @return the nPictureNum
	 */
	public String getnPictureNum() {
		return nPictureNum;
	}

	/**
	 * @param nPictureNum the nPictureNum to set
	 */
	public void setnPictureNum(final String nPictureNum) {
		this.nPictureNum = nPictureNum;
	}

	/**
	 * @return the sPictureName
	 */
	public String getsPictureName() {
		return sPictureName;
	}

	/**
	 * @param sPictureName the sPictureName to set
	 */
	public void setsPictureName(final String sPictureName) {
		this.sPictureName = sPictureName;
	}

}
