/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��ü ���� ��� ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceDTO")
public class InsuranceDTO implements Serializable {
	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** ���豸�� (�ڵ���/�Ϲ�/���) **/
	private String sInsurFlag;
	/** ��ǰ�� **/
	private String sGdCdName;
	/** �Ǻ������ֹι�ȣDisplay ("-" �� ���� ǥ��) **/
	private String sInrpsCdDp;
	/** �Ǻ������ֹι�ȣ **/
	private String sInrpsCd;
	/** �Ǻ����ڸ� **/
	private String sInrpsName;
	/** ����Ⱓ (���� ~ ����) **/
	private String sInsurTerm;
	/** ������� **/
	private String sPolicyDate;
	/** ����ȣ **/
	private String sCrNo;
	/** ������ֹι�ȣDisplay ("-" �� ���� ǥ��) **/
	private String sCrtorCdDp;
	/** ������ֹι�ȣ **/
	private String sCrtorCd;
	/** ����ڸ� **/
	private String sCrtorName;
	/** ����ȸ��Display ("( ) ȸ�� ( )ȸ" �� ǥ��) **/
	private String sPaymCtDp;
	/** ������ **/
	private String sCrStatCdName;
	/** �߼��������ڵ� (1:����, 2:����, 3:��Ÿ, 4:�ӽ�) **/
	private String sSendType;
	/** �߼������и� **/
	private String sSendTypeNm;
	/** �ּ�1 **/
	private String sAdrs1;
	/** �ּ�2 **/
	private String sAdrs2;
	/** �Ǻ������ּұ��� (1:����, 2:����, 3:��Ÿ, 4:�ӽ�) **/
	private String sInrpsAdrsType;
	/** �Ǻ������ּ�1 **/
	private String sInrpsAdrs1;
	/** �Ǻ������ּ�2 **/
	private String sInrpsAdrs2;
	/** �Ǻ����ڹ߼����ּұ��� (1:����, 2:����, 3:��Ÿ, 4:�ӽ�) **/
	private String sInrpsSendType;
	/** �Ǻ����ڹ߼����ּ�1 **/
	private String sInrpsSendAdrs1;
	/** �Ǻ����ڹ߼����ּ�2 **/
	private String sInrpsSendAdrs2;
	/** ������ּұ��� (1:����, 2:����, 3:��Ÿ, 4:�ӽ�) **/
	private String sCrtorAdrsType;
	/** ������ּ�1 **/
	private String sCrtorAdrs1;
	/** ������ּ�2 **/
	private String sCrtorAdrs2;
	/** ����ڹ߼����ּұ��� (1:����, 2:����, 3:��Ÿ, 4:�ӽ�) **/
	private String sCrtorSendType;
	/** ����ڹ߼����ּ�1 **/
	private String sCrtorSendAdrs1;
	/** ����ڹ߼����ּ�2 **/
	private String sCrtorSendAdrs2;
	/** ���Ǳ��� (1: ���� ���� , 0: ���� ����) **/
	private String sCrtorInrpsFlag;
	/** �����ֱ�� (�г�, ����, 2����, �Ͻó� ��) **/
	private String sPaymCyclName;
	/** ���ſ��� (���� or �񰻽�) **/
	private String sRenwlYn;
	/** ������ȣ **/
	private String sPlateNo;
	/** ������� **/
	private String sAccid;
	/** �����輭ȸ�� **/
	private String nLastEndorseNo;
	/** �ִ�輭ȸ�� **/
	private String nMaxEndorseNo;
	/** �����輭�� **/
	private String sLastEndorseDate;
	/** �������� **/
	private String sTodt;
	/** ����ñ� **/
	private String sFmdt;
	/** �Ǻ����ڼ��� **/
	private String nInrpsSeqno;
	/** ���ݹ���� **/
	//�߰� lhn 1220
	private String sCmMetdName;
	/** �������Կ� **/
	private String sFinalPaymMthy;
	/** ��������ȸ�� **/
	private String nFinalPaymSeq;

	/**
	 * @return the sInsurFlag
	 */
	public String getsInsurFlag() {
		return sInsurFlag;
	}

	/**
	 * @param sInsurFlag the sInsurFlag to set
	 */
	public void setsInsurFlag(final String sInsurFlag) {
		this.sInsurFlag = sInsurFlag;
	}

	/**
	 * @return the sGdCdName
	 */
	public String getsGdCdName() {
		return sGdCdName;
	}

	/**
	 * @param sGdCdName the sGdCdName to set
	 */
	public void setsGdCdName(final String sGdCdName) {
		this.sGdCdName = sGdCdName;
	}

	/**
	 * @return the sInrpsCdDp
	 */
	public String getsInrpsCdDp() {
		return sInrpsCdDp;
	}

	/**
	 * @param sInrpsCdDp the sInrpsCdDp to set
	 */
	public void setsInrpsCdDp(final String sInrpsCdDp) {
		this.sInrpsCdDp = sInrpsCdDp;
	}

	/**
	 * @return the sInrpsCd
	 */
	public String getsInrpsCd() {
		return sInrpsCd;
	}

	/**
	 * @param sInrpsCd the sInrpsCd to set
	 */
	public void setsInrpsCd(final String sInrpsCd) {
		this.sInrpsCd = sInrpsCd;
	}

	/**
	 * @return the sInrpsName
	 */
	public String getsInrpsName() {
		return sInrpsName;
	}

	/**
	 * @param sInrpsName the sInrpsName to set
	 */
	public void setsInrpsName(final String sInrpsName) {
		this.sInrpsName = sInrpsName;
	}

	/**
	 * @return the sInsurTerm
	 */
	public String getsInsurTerm() {
		return sInsurTerm;
	}

	/**
	 * @param sInsurTerm the sInsurTerm to set
	 */
	public void setsInsurTerm(final String sInsurTerm) {
		this.sInsurTerm = sInsurTerm;
	}

	/**
	 * @return the sPolicyDate
	 */
	public String getsPolicyDate() {
		return sPolicyDate;
	}

	/**
	 * @param sPolicyDate the sPolicyDate to set
	 */
	public void setsPolicyDate(final String sPolicyDate) {
		this.sPolicyDate = sPolicyDate;
	}

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

	/**
	 * @return the sCrtorCdDp
	 */
	public String getsCrtorCdDp() {
		return sCrtorCdDp;
	}

	/**
	 * @param sCrtorCdDp the sCrtorCdDp to set
	 */
	public void setsCrtorCdDp(final String sCrtorCdDp) {
		this.sCrtorCdDp = sCrtorCdDp;
	}

	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}

	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(final String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}

	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}

	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(final String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}

	/**
	 * @return the sPaymCtDp
	 */
	public String getsPaymCtDp() {
		return sPaymCtDp;
	}

	/**
	 * @param sPaymCtDp the sPaymCtDp to set
	 */
	public void setsPaymCtDp(final String sPaymCtDp) {
		this.sPaymCtDp = sPaymCtDp;
	}

	/**
	 * @return the sCrStatCdName
	 */
	public String getsCrStatCdName() {
		return sCrStatCdName;
	}

	/**
	 * @param sCrStatCdName the sCrStatCdName to set
	 */
	public void setsCrStatCdName(final String sCrStatCdName) {
		this.sCrStatCdName = sCrStatCdName;
	}

	/**
	 * @return the sSendType
	 */
	public String getsSendType() {
		return sSendType;
	}

	/**
	 * @param sSendType the sSendType to set
	 */
	public void setsSendType(final String sSendType) {
		this.sSendType = sSendType;
	}

	/**
	 * @return the sSendTypeNm
	 */
	public String getsSendTypeNm() {
		return sSendTypeNm;
	}

	/**
	 * @param sSendTypeNm the sSendTypeNm to set
	 */
	public void setsSendTypeNm(final String sSendTypeNm) {
		this.sSendTypeNm = sSendTypeNm;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sInrpsAdrsType
	 */
	public String getsInrpsAdrsType() {
		return sInrpsAdrsType;
	}

	/**
	 * @param sInrpsAdrsType the sInrpsAdrsType to set
	 */
	public void setsInrpsAdrsType(final String sInrpsAdrsType) {
		this.sInrpsAdrsType = sInrpsAdrsType;
	}

	/**
	 * @return the sInrpsAdrs1
	 */
	public String getsInrpsAdrs1() {
		return sInrpsAdrs1;
	}

	/**
	 * @param sInrpsAdrs1 the sInrpsAdrs1 to set
	 */
	public void setsInrpsAdrs1(final String sInrpsAdrs1) {
		this.sInrpsAdrs1 = sInrpsAdrs1;
	}

	/**
	 * @return the sInrpsAdrs2
	 */
	public String getsInrpsAdrs2() {
		return sInrpsAdrs2;
	}

	/**
	 * @param sInrpsAdrs2 the sInrpsAdrs2 to set
	 */
	public void setsInrpsAdrs2(final String sInrpsAdrs2) {
		this.sInrpsAdrs2 = sInrpsAdrs2;
	}

	/**
	 * @return the sInrpsSendType
	 */
	public String getsInrpsSendType() {
		return sInrpsSendType;
	}

	/**
	 * @param sInrpsSendType the sInrpsSendType to set
	 */
	public void setsInrpsSendType(final String sInrpsSendType) {
		this.sInrpsSendType = sInrpsSendType;
	}

	/**
	 * @return the sInrpsSendAdrs1
	 */
	public String getsInrpsSendAdrs1() {
		return sInrpsSendAdrs1;
	}

	/**
	 * @param sInrpsSendAdrs1 the sInrpsSendAdrs1 to set
	 */
	public void setsInrpsSendAdrs1(final String sInrpsSendAdrs1) {
		this.sInrpsSendAdrs1 = sInrpsSendAdrs1;
	}

	/**
	 * @return the sInrpsSendAdrs2
	 */
	public String getsInrpsSendAdrs2() {
		return sInrpsSendAdrs2;
	}

	/**
	 * @param sInrpsSendAdrs2 the sInrpsSendAdrs2 to set
	 */
	public void setsInrpsSendAdrs2(final String sInrpsSendAdrs2) {
		this.sInrpsSendAdrs2 = sInrpsSendAdrs2;
	}

	/**
	 * @return the sCrtorAdrsType
	 */
	public String getsCrtorAdrsType() {
		return sCrtorAdrsType;
	}

	/**
	 * @param sCrtorAdrsType the sCrtorAdrsType to set
	 */
	public void setsCrtorAdrsType(final String sCrtorAdrsType) {
		this.sCrtorAdrsType = sCrtorAdrsType;
	}

	/**
	 * @return the sCrtorAdrs1
	 */
	public String getsCrtorAdrs1() {
		return sCrtorAdrs1;
	}

	/**
	 * @param sCrtorAdrs1 the sCrtorAdrs1 to set
	 */
	public void setsCrtorAdrs1(final String sCrtorAdrs1) {
		this.sCrtorAdrs1 = sCrtorAdrs1;
	}

	/**
	 * @return the sCrtorAdrs2
	 */
	public String getsCrtorAdrs2() {
		return sCrtorAdrs2;
	}

	/**
	 * @param sCrtorAdrs2 the sCrtorAdrs2 to set
	 */
	public void setsCrtorAdrs2(final String sCrtorAdrs2) {
		this.sCrtorAdrs2 = sCrtorAdrs2;
	}

	/**
	 * @return the sCrtorSendType
	 */
	public String getsCrtorSendType() {
		return sCrtorSendType;
	}

	/**
	 * @param sCrtorSendType the sCrtorSendType to set
	 */
	public void setsCrtorSendType(final String sCrtorSendType) {
		this.sCrtorSendType = sCrtorSendType;
	}

	/**
	 * @return the sCrtorSendAdrs1
	 */
	public String getsCrtorSendAdrs1() {
		return sCrtorSendAdrs1;
	}

	/**
	 * @param sCrtorSendAdrs1 the sCrtorSendAdrs1 to set
	 */
	public void setsCrtorSendAdrs1(final String sCrtorSendAdrs1) {
		this.sCrtorSendAdrs1 = sCrtorSendAdrs1;
	}

	/**
	 * @return the sCrtorSendAdrs2
	 */
	public String getsCrtorSendAdrs2() {
		return sCrtorSendAdrs2;
	}

	/**
	 * @param sCrtorSendAdrs2 the sCrtorSendAdrs2 to set
	 */
	public void setsCrtorSendAdrs2(final String sCrtorSendAdrs2) {
		this.sCrtorSendAdrs2 = sCrtorSendAdrs2;
	}

	/**
	 * @return the sCrtorInrpsFlag
	 */
	public String getsCrtorInrpsFlag() {
		return sCrtorInrpsFlag;
	}

	/**
	 * @param sCrtorInrpsFlag the sCrtorInrpsFlag to set
	 */
	public void setsCrtorInrpsFlag(final String sCrtorInrpsFlag) {
		this.sCrtorInrpsFlag = sCrtorInrpsFlag;
	}

	/**
	 * @return the sPaymCyclName
	 */
	public String getsPaymCyclName() {
		return sPaymCyclName;
	}

	/**
	 * @param sPaymCyclName the sPaymCyclName to set
	 */
	public void setsPaymCyclName(final String sPaymCyclName) {
		this.sPaymCyclName = sPaymCyclName;
	}

	/**
	 * @return the sRenwlYn
	 */
	public String getsRenwlYn() {
		return sRenwlYn;
	}

	/**
	 * @param sRenwlYn the sRenwlYn to set
	 */
	public void setsRenwlYn(final String sRenwlYn) {
		this.sRenwlYn = sRenwlYn;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sAccid
	 */
	public String getsAccid() {
		return sAccid;
	}

	/**
	 * @param sAccid the sAccid to set
	 */
	public void setsAccid(final String sAccid) {
		this.sAccid = sAccid;
	}

	/**
	 * @return the nLastEndorseNo
	 */
	public String getnLastEndorseNo() {
		return nLastEndorseNo;
	}

	/**
	 * @param nLastEndorseNo the nLastEndorseNo to set
	 */
	public void setnLastEndorseNo(final String nLastEndorseNo) {
		this.nLastEndorseNo = nLastEndorseNo;
	}

	/**
	 * @return the nMaxEndorseNo
	 */
	public String getnMaxEndorseNo() {
		return nMaxEndorseNo;
	}

	/**
	 * @param nMaxEndorseNo the nMaxEndorseNo to set
	 */
	public void setnMaxEndorseNo(final String nMaxEndorseNo) {
		this.nMaxEndorseNo = nMaxEndorseNo;
	}

	/**
	 * @return the sLastEndorseDate
	 */
	public String getsLastEndorseDate() {
		return sLastEndorseDate;
	}

	/**
	 * @param sLastEndorseDate the sLastEndorseDate to set
	 */
	public void setsLastEndorseDate(final String sLastEndorseDate) {
		this.sLastEndorseDate = sLastEndorseDate;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the nInrpsSeqno
	 */
	public String getnInrpsSeqno() {
		return nInrpsSeqno;
	}

	/**
	 * @param nInrpsSeqno the nInrpsSeqno to set
	 */
	public void setnInrpsSeqno(final String nInrpsSeqno) {
		this.nInrpsSeqno = nInrpsSeqno;
	}

	/**
	 * @return the sCmMetdName
	 */
	public String getsCmMetdName() {
		return sCmMetdName;
	}

	/**
	 * @param sCmMetdName the sCmMetdName to set
	 */
	public void setsCmMetdName(final String sCmMetdName) {
		this.sCmMetdName = sCmMetdName;
	}

	/**
	 * @return the sFinalPaymMthy
	 */
	public String getsFinalPaymMthy() {
		return sFinalPaymMthy;
	}

	/**
	 * @param sFinalPaymMthy the sFinalPaymMthy to set
	 */
	public void setsFinalPaymMthy(final String sFinalPaymMthy) {
		this.sFinalPaymMthy = sFinalPaymMthy;
	}

	/**
	 * @return the nFinalPaymSeq
	 */
	public String getnFinalPaymSeq() {
		return nFinalPaymSeq;
	}

	/**
	 * @param nFinalPaymSeq the nFinalPaymSeq to set
	 */
	public void setnFinalPaymSeq(final String nFinalPaymSeq) {
		this.nFinalPaymSeq = nFinalPaymSeq;
	}

}
