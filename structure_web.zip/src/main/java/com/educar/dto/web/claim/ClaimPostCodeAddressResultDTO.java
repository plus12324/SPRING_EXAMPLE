/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �������� ��ȸ ��� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlRootElement(name = "claimPostCodeAddressSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimPostCodeAddressResultDTO {
	/** ������ȣ 1 **/
	private String sRealZip1;
	/** ������ȣ 2 **/
	private String sRealZip2;
	/** ������ȣ(ȭ��ǥ�ÿ�) **/
	private String zip;
	/** �����ּ� **/
	private String sCityName;
	/** �����ּ� **/
	private String sCountyName;
	/** �����ּ� **/
	private String sTownName;
	/** �ּ�(ȭ��ǥ�ÿ�) **/
	private String address;
	/** ��(��ǥ�ǹ�) **/
	private String sBuildingName;
	/** ���θ��ּ� **/
	private String sRoadName;

	/**
	 * @return the sRealZip1
	 */
	public String getsRealZip1() {
		return sRealZip1;
	}

	/**
	 * @param sRealZip1 the sRealZip1 to set
	 */
	public void setsRealZip1(final String sRealZip1) {
		this.sRealZip1 = sRealZip1;
	}

	/**
	 * @return the sRealZip2
	 */
	public String getsRealZip2() {
		return sRealZip2;
	}

	/**
	 * @param sRealZip2 the sRealZip2 to set
	 */
	public void setsRealZip2(final String sRealZip2) {
		this.sRealZip2 = sRealZip2;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(final String zip) {
		this.zip = zip;
	}

	/**
	 * @return the sCityName
	 */
	public String getsCityName() {
		return sCityName;
	}

	/**
	 * @param sCityName the sCityName to set
	 */
	public void setsCityName(final String sCityName) {
		this.sCityName = sCityName;
	}

	/**
	 * @return the sCountyName
	 */
	public String getsCountyName() {
		return sCountyName;
	}

	/**
	 * @param sCountyName the sCountyName to set
	 */
	public void setsCountyName(final String sCountyName) {
		this.sCountyName = sCountyName;
	}

	/**
	 * @return the sTownName
	 */
	public String getsTownName() {
		return sTownName;
	}

	/**
	 * @param sTownName the sTownName to set
	 */
	public void setsTownName(final String sTownName) {
		this.sTownName = sTownName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @return the sBuildingName
	 */
	public String getsBuildingName() {
		return sBuildingName;
	}

	/**
	 * @param sBuildingName the sBuildingName to set
	 */
	public void setsBuildingName(final String sBuildingName) {
		this.sBuildingName = sBuildingName;
	}

	/**
	 * @return the sRoadName
	 */
	public String getsRoadName() {
		return sRoadName;
	}

	/**
	 * @param sRoadName the sRoadName to set
	 */
	public void setsRoadName(final String sRoadName) {
		this.sRoadName = sRoadName;
	}

}
