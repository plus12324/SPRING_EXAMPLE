/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ���� ������� DTO
 * @author ������ 
 * @since 1.0.0
 */
@XmlRootElement(name = "insertAcdRcpDataDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAcdRcpDataDTO {
	/** Ds_AcdList **/
	@XmlElementWrapper(name = "Ds_AcdDataList")
	private List<InsertAcdRcpDataOfDs_AcdListDTO> Ds_AcdList;
	/** Ds_AcdDetail **/
	@XmlElementWrapper(name = "Ds_AcdDetailList")
	private List<InsertAcdRcpDataOfDs_AcdDetailDTO> Ds_AcdDetail;
	/** Ds_AccInfo **/
	@XmlElementWrapper(name = "Ds_AccInfoList")
	private List<InsertAcdRcpDataOfDs_AccInfoDTO> Ds_AccInfo;

	/** ����ID ����Ʈ **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "fileIDList")
	private List<String> fileID;

	/**
	 * @return the ds_AcdList
	 */
	public List<InsertAcdRcpDataOfDs_AcdListDTO> getDs_AcdList() {
		return Ds_AcdList;
	}

	/**
	 * @param ds_AcdList the ds_AcdList to set
	 */
	public void setDs_AcdList(final List<InsertAcdRcpDataOfDs_AcdListDTO> ds_AcdList) {
		Ds_AcdList = ds_AcdList;
	}

	/**
	 * @return the ds_AcdDetail
	 */
	public List<InsertAcdRcpDataOfDs_AcdDetailDTO> getDs_AcdDetail() {
		return Ds_AcdDetail;
	}

	/**
	 * @param ds_AcdDetail the ds_AcdDetail to set
	 */
	public void setDs_AcdDetail(List<InsertAcdRcpDataOfDs_AcdDetailDTO> ds_AcdDetail) {
		Ds_AcdDetail = ds_AcdDetail;
	}

	/**
	 * @return the fileID
	 */
	public List<String> getFileID() {
		return fileID;
	}

	/**
	 * @param fileID the fileID to set
	 */
	public void setFileID(final List<String> fileID) {
		this.fileID = fileID;
	}

	public List<InsertAcdRcpDataOfDs_AccInfoDTO> getDs_AccInfo() {
		return Ds_AccInfo;
	}

	public void setDs_AccInfo(List<InsertAcdRcpDataOfDs_AccInfoDTO> ds_AccInfo) {
		Ds_AccInfo = ds_AccInfo;
	}
	
}
