/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - �г�û���ȣ ��û(�Ϲݺ���) Wrapper DTO
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayReqInsertWrapperDTO")
public class InsDrvPayReqInsertWrapperDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/** ��� ���� **/
	private InsDrvPayRectList01DTO hash00;
	/** ���� ���� (�г�û���ȣ ��û�� ���)**/
	private List<InsDrvPayRectList02DTO> hash01;
	/** ��������(ī��)**/
	private InsDrvPayRectList03DTO hash03;
	
	/**
	 * @return the hash00
	 */
	public InsDrvPayRectList01DTO getHash00() {
		return hash00;
	}
	/**
	 * @param hash00 the hash00 to set
	 */
	public void setHash00(InsDrvPayRectList01DTO hash00) {
		this.hash00 = hash00;
	}
	/**
	 * @return the hash01
	 */
	public List<InsDrvPayRectList02DTO> getHash01() {
		return hash01;
	}
	/**
	 * @param hash01 the hash01 to set
	 */
	public void setHash01(List<InsDrvPayRectList02DTO> hash01) {
		this.hash01 = hash01;
	}
	/**
	 * @return the hash03
	 */
	public InsDrvPayRectList03DTO getHash03() {
		return hash03;
	}
	/**
	 * @param hash03 the hash03 to set
	 */
	public void setHash03(InsDrvPayRectList03DTO hash03) {
		this.hash03 = hash03;
	}

	
}
