/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

/**
 * �����ں��� ����ī������ û�� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "driverInsuranceOfferOfHash051DTO")
public class DriverInsuranceOfferOfHash020DTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** ����ڸ� **/
	private String sPlrNam;
	/** ������ڵ� **/
	private String sPlrCsmNum;
	/** ������ּұ��� (1:����, 2:ȸ��, 3:��Ÿ, 4:�ӽ�  default '1') **/
	private String sPlrAddrTyp;
	/** ���α��� (������ڵ屸��(���� : 1, ���� : 2)  default '1') **/
	private String sPlrCodTyp;
	/** ���ÿ�����ȣ1 **/
	private String sCustHomZip1;
	/** ���ÿ�����ȣ2 **/
	private String sCustHomZip2;
	/** ���ÿ�����ȣ (ex)156032)**/
	private String sHomZco;
	/** �����ּұ��� ('0' : ���ּ�(����) '1' : ���ּ�(���θ�)) **/
	private String sCustHomZipType;
	/** �����ּ�1 **/
	private String sCustHomAdr1;
	/** �����ּ�2 **/
	private String sCustHomAdr2;
	/** �����ּ�3 **/
	private String sCustHomAdr3;
	/** �����ּ� �����κ� **/
	private String sCustHomAdrAdd;
	/** ���������ȣ1 **/
	private String sCustOfficeZip1;
	/** ���������ȣ2 **/
	private String sCustOfficeZip2;
	/** �����ּұ���('0' : ���ּ�(����) '1' : ���ּ�(���θ�)) **/
	private String sCustOfficeZipType;
	/** �����ּ�1 **/
	private String sCustOfficeAdr1;
	/** �����ּ�2 **/
	private String sCustOfficeAdr2;
	/** �����ּ�3 **/
	private String sCustOfficeAdr3;
	/** �����ּ� �����κ� **/
	private String sCustOfficeAdrAdd;
	/** ����ڹ߼����ּұ���(����������ó) (1:����, 2:ȸ��, 3:��Ÿ, 4:�ӽ�) **/
	private String sPlrDMAddrTyp;
	/** ������ȭ������ȣ **/
	private String sHomTelAreNum;
	/** ������ȭ���� **/
	private String sHomTelNum1;
	/** ������ȭ��ȣ **/
	private String sHomTelNum2;
	/** ������ȭ������ȣ **/
	private String sCrpTelAreNum;
	/** ������ȭ���� **/
	private String sCrpTelNum1;
	/** ������ȭ��ȣ **/
	private String sCrpTelNum2;
	/** �ڵ���1(����ó) **/
	private String sMno1;
	/** �ڵ���2(����ó) **/
	private String sMno2;
	/** �ڵ���3(����ó) **/
	private String sMno3;
	/** ����ó (sMno1+sMno2+sMno3) **/
	private String sMno;
	/** �̸��� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String sEml;
	/** ���� ���ּ� **/
	private String sHomAdr1;
	/** ���� �����ּ� **/
	private String sHomAdr2;
	/** ����������� **/
	private String sJobNam;
	/** ����������ڵ� **/
	private String sPlrJobCod;
	/** ����������޼� **/
	private String sPlrJobCls;
	/** �Է³���Ͻ� (�Է� ��/��/��/��/��/�� 12�ڸ�) **/
	private String dUpdateTime;
	/** ������ڵ�1 **/
	private String sPlrCsmNum1;
	/** ������ڵ�2 **/
	private String sPlrCsmNum2;
	/** Ű���庸�� ��ȣȭ KEY **/
	private String hid_key_data;
	
	//N1401-00089 ���θ��ּ� �߰�
		/** �����ּ� ���λ����ּ� **/
		private String sCustHomDoroAddr1;
		/** �����ּ� �ּҰ�����ȣ **/
		private String sCustHomAddrMgtNo;
		/** �����ּ� ���λ����ּ� **/
		private String sCustOfficeDoroAddr1;
		/** �����ּ� �ּҰ�����ȣ **/
		private String sCustOfficeAddrMgtNo;
	/**
	 * @return the sPlrNam
	 */
	public String getsPlrNam() {
		return sPlrNam;
	}

	/**
	 * @param sPlrNam the sPlrNam to set
	 */
	public void setsPlrNam(final String sPlrNam) {
		this.sPlrNam = sPlrNam;
	}

	/**
	 * @return the sPlrCsmNum
	 */
	public String getsPlrCsmNum() {
		return sPlrCsmNum;
	}

	/**
	 * @param sPlrCsmNum the sPlrCsmNum to set
	 */
	public void setsPlrCsmNum(final String sPlrCsmNum) {
		this.sPlrCsmNum = sPlrCsmNum;
	}

	/**
	 * @return the sPlrAddrTyp
	 */
	public String getsPlrAddrTyp() {
		return sPlrAddrTyp;
	}

	/**
	 * @param sPlrAddrTyp the sPlrAddrTyp to set
	 */
	public void setsPlrAddrTyp(final String sPlrAddrTyp) {
		this.sPlrAddrTyp = sPlrAddrTyp;
	}

	/**
	 * @return the sPlrCodTyp
	 */
	public String getsPlrCodTyp() {
		return sPlrCodTyp;
	}

	/**
	 * @param sPlrCodTyp the sPlrCodTyp to set
	 */
	public void setsPlrCodTyp(final String sPlrCodTyp) {
		this.sPlrCodTyp = sPlrCodTyp;
	}

	/**
	 * @return the sCustHomZip1
	 */
	public String getsCustHomZip1() {
		return sCustHomZip1;
	}

	/**
	 * @param sCustHomZip1 the sCustHomZip1 to set
	 */
	public void setsCustHomZip1(final String sCustHomZip1) {
		this.sCustHomZip1 = sCustHomZip1;
	}

	/**
	 * @return the sCustHomZip2
	 */
	public String getsCustHomZip2() {
		return sCustHomZip2;
	}

	/**
	 * @param sCustHomZip2 the sCustHomZip2 to set
	 */
	public void setsCustHomZip2(final String sCustHomZip2) {
		this.sCustHomZip2 = sCustHomZip2;
	}

	/**
	 * @return the sHomZco
	 */
	public String getsHomZco() {
		return sHomZco;
	}

	/**
	 * @param sHomZco the sHomZco to set
	 */
	public void setsHomZco(final String sHomZco) {
		this.sHomZco = sHomZco;
	}

	/**
	 * @return the sCustHomAdr1
	 */
	public String getsCustHomAdr1() {
		return sCustHomAdr1;
	}

	/**
	 * @param sCustHomAdr1 the sCustHomAdr1 to set
	 */
	public void setsCustHomAdr1(final String sCustHomAdr1) {
		this.sCustHomAdr1 = sCustHomAdr1;
	}

	/**
	 * @return the sCustHomAdr2
	 */
	public String getsCustHomAdr2() {
		return sCustHomAdr2;
	}

	/**
	 * @param sCustHomAdr2 the sCustHomAdr2 to set
	 */
	public void setsCustHomAdr2(final String sCustHomAdr2) {
		this.sCustHomAdr2 = sCustHomAdr2;
	}

	/**
	 * @return the sCustHomAdr3
	 */
	public String getsCustHomAdr3() {
		return sCustHomAdr3;
	}

	/**
	 * @param sCustHomAdr3 the sCustHomAdr3 to set
	 */
	public void setsCustHomAdr3(final String sCustHomAdr3) {
		this.sCustHomAdr3 = sCustHomAdr3;
	}

	/**
	 * @return the sCustHomAdrAdd
	 */
	public String getsCustHomAdrAdd() {
		return sCustHomAdrAdd;
	}

	/**
	 * @param sCustHomAdrAdd the sCustHomAdrAdd to set
	 */
	public void setsCustHomAdrAdd(final String sCustHomAdrAdd) {
		this.sCustHomAdrAdd = sCustHomAdrAdd;
	}

	/**
	 * @return the sCustOfficeZip1
	 */
	public String getsCustOfficeZip1() {
		return sCustOfficeZip1;
	}

	/**
	 * @param sCustOfficeZip1 the sCustOfficeZip1 to set
	 */
	public void setsCustOfficeZip1(final String sCustOfficeZip1) {
		this.sCustOfficeZip1 = sCustOfficeZip1;
	}

	/**
	 * @return the sCustOfficeZip2
	 */
	public String getsCustOfficeZip2() {
		return sCustOfficeZip2;
	}

	/**
	 * @param sCustOfficeZip2 the sCustOfficeZip2 to set
	 */
	public void setsCustOfficeZip2(final String sCustOfficeZip2) {
		this.sCustOfficeZip2 = sCustOfficeZip2;
	}

	/**
	 * @return the sCustOfficeAdr1
	 */
	public String getsCustOfficeAdr1() {
		return sCustOfficeAdr1;
	}

	/**
	 * @param sCustOfficeAdr1 the sCustOfficeAdr1 to set
	 */
	public void setsCustOfficeAdr1(final String sCustOfficeAdr1) {
		this.sCustOfficeAdr1 = sCustOfficeAdr1;
	}

	/**
	 * @return the sCustOfficeAdr2
	 */
	public String getsCustOfficeAdr2() {
		return sCustOfficeAdr2;
	}

	/**
	 * @param sCustOfficeAdr2 the sCustOfficeAdr2 to set
	 */
	public void setsCustOfficeAdr2(final String sCustOfficeAdr2) {
		this.sCustOfficeAdr2 = sCustOfficeAdr2;
	}

	/**
	 * @return the sCustOfficeAdr3
	 */
	public String getsCustOfficeAdr3() {
		return sCustOfficeAdr3;
	}

	/**
	 * @param sCustOfficeAdr3 the sCustOfficeAdr3 to set
	 */
	public void setsCustOfficeAdr3(final String sCustOfficeAdr3) {
		this.sCustOfficeAdr3 = sCustOfficeAdr3;
	}

	/**
	 * @return the sCustOfficeAdrAdd
	 */
	public String getsCustOfficeAdrAdd() {
		return sCustOfficeAdrAdd;
	}

	/**
	 * @param sCustOfficeAdrAdd the sCustOfficeAdrAdd to set
	 */
	public void setsCustOfficeAdrAdd(final String sCustOfficeAdrAdd) {
		this.sCustOfficeAdrAdd = sCustOfficeAdrAdd;
	}

	/**
	 * @return the sPlrDMAddrTyp
	 */
	public String getsPlrDMAddrTyp() {
		return sPlrDMAddrTyp;
	}

	/**
	 * @param sPlrDMAddrTyp the sPlrDMAddrTyp to set
	 */
	public void setsPlrDMAddrTyp(final String sPlrDMAddrTyp) {
		this.sPlrDMAddrTyp = sPlrDMAddrTyp;
	}

	/**
	 * @return the sHomTelAreNum
	 */
	public String getsHomTelAreNum() {
		return sHomTelAreNum;
	}

	/**
	 * @param sHomTelAreNum the sHomTelAreNum to set
	 */
	public void setsHomTelAreNum(final String sHomTelAreNum) {
		this.sHomTelAreNum = sHomTelAreNum;
	}

	/**
	 * @return the sHomTelNum1
	 */
	public String getsHomTelNum1() {
		return sHomTelNum1;
	}

	/**
	 * @param sHomTelNum1 the sHomTelNum1 to set
	 */
	public void setsHomTelNum1(final String sHomTelNum1) {
		this.sHomTelNum1 = sHomTelNum1;
	}

	/**
	 * @return the sHomTelNum2
	 */
	public String getsHomTelNum2() {
		return sHomTelNum2;
	}

	/**
	 * @param sHomTelNum2 the sHomTelNum2 to set
	 */
	public void setsHomTelNum2(final String sHomTelNum2) {
		this.sHomTelNum2 = sHomTelNum2;
	}

	/**
	 * @return the sCrpTelAreNum
	 */
	public String getsCrpTelAreNum() {
		return sCrpTelAreNum;
	}

	/**
	 * @param sCrpTelAreNum the sCrpTelAreNum to set
	 */
	public void setsCrpTelAreNum(final String sCrpTelAreNum) {
		this.sCrpTelAreNum = sCrpTelAreNum;
	}

	/**
	 * @return the sCrpTelNum1
	 */
	public String getsCrpTelNum1() {
		return sCrpTelNum1;
	}

	/**
	 * @param sCrpTelNum1 the sCrpTelNum1 to set
	 */
	public void setsCrpTelNum1(final String sCrpTelNum1) {
		this.sCrpTelNum1 = sCrpTelNum1;
	}

	/**
	 * @return the sCrpTelNum2
	 */
	public String getsCrpTelNum2() {
		return sCrpTelNum2;
	}

	/**
	 * @param sCrpTelNum2 the sCrpTelNum2 to set
	 */
	public void setsCrpTelNum2(final String sCrpTelNum2) {
		this.sCrpTelNum2 = sCrpTelNum2;
	}

	/**
	 * @return the sMno1
	 */
	public String getsMno1() {
		return sMno1;
	}

	/**
	 * @param sMno1 the sMno1 to set
	 */
	public void setsMno1(final String sMno1) {
		this.sMno1 = sMno1;
	}

	/**
	 * @return the sMno2
	 */
	public String getsMno2() {
		return sMno2;
	}

	/**
	 * @param sMno2 the sMno2 to set
	 */
	public void setsMno2(final String sMno2) {
		this.sMno2 = sMno2;
	}

	/**
	 * @return the sMno3
	 */
	public String getsMno3() {
		return sMno3;
	}

	/**
	 * @param sMno3 the sMno3 to set
	 */
	public void setsMno3(final String sMno3) {
		this.sMno3 = sMno3;
	}

	/**
	 * @return the sMno
	 */
	public String getsMno() {
		return sMno;
	}

	/**
	 * @param sMno the sMno to set
	 */
	public void setsMno(final String sMno) {
		this.sMno = sMno;
	}

	/**
	 * @return the sEml
	 */
	public String getsEml() {
		return sEml;
	}

	/**
	 * @param sEml the sEml to set
	 */
	public void setsEml(final String sEml) {
		this.sEml = sEml;
	}

	/**
	 * @return the sHomAdr1
	 */
	public String getsHomAdr1() {
		return sHomAdr1;
	}

	/**
	 * @param sHomAdr1 the sHomAdr1 to set
	 */
	public void setsHomAdr1(final String sHomAdr1) {
		this.sHomAdr1 = sHomAdr1;
	}

	/**
	 * @return the sHomAdr2
	 */
	public String getsHomAdr2() {
		return sHomAdr2;
	}

	/**
	 * @param sHomAdr2 the sHomAdr2 to set
	 */
	public void setsHomAdr2(final String sHomAdr2) {
		this.sHomAdr2 = sHomAdr2;
	}

	/**
	 * @return the sJobNam
	 */
	public String getsJobNam() {
		return sJobNam;
	}

	/**
	 * @param sJobNam the sJobNam to set
	 */
	public void setsJobNam(final String sJobNam) {
		this.sJobNam = sJobNam;
	}

	/**
	 * @return the sPlrJobCod
	 */
	public String getsPlrJobCod() {
		return sPlrJobCod;
	}

	/**
	 * @param sPlrJobCod the sPlrJobCod to set
	 */
	public void setsPlrJobCod(final String sPlrJobCod) {
		this.sPlrJobCod = sPlrJobCod;
	}

	/**
	 * @return the sPlrJobCls
	 */
	public String getsPlrJobCls() {
		return sPlrJobCls;
	}

	/**
	 * @param sPlrJobCls the sPlrJobCls to set
	 */
	public void setsPlrJobCls(final String sPlrJobCls) {
		this.sPlrJobCls = sPlrJobCls;
	}

	/**
	 * @return the dUpdateTime
	 */
	public String getdUpdateTime() {
		return dUpdateTime;
	}

	/**
	 * @param dUpdateTime the dUpdateTime to set
	 */
	public void setdUpdateTime(final String dUpdateTime) {
		this.dUpdateTime = dUpdateTime;
	}

	/**
	 * @return the sCustHomZipType
	 */
	public String getsCustHomZipType() {
		return sCustHomZipType;
	}

	/**
	 * @param sCustHomZipType the sCustHomZipType to set
	 */
	public void setsCustHomZipType(final String sCustHomZipType) {
		this.sCustHomZipType = sCustHomZipType;
	}

	/**
	 * @return the sCustOfficeZipType
	 */
	public String getsCustOfficeZipType() {
		return sCustOfficeZipType;
	}

	/**
	 * @param sCustOfficeZipType the sCustOfficeZipType to set
	 */
	public void setsCustOfficeZipType(final String sCustOfficeZipType) {
		this.sCustOfficeZipType = sCustOfficeZipType;
	}

	/**
	 * @return the sPlrCsmNum1
	 */
	public String getsPlrCsmNum1() {
		return sPlrCsmNum1;
	}

	/**
	 * @param sPlrCsmNum1 the sPlrCsmNum1 to set
	 */
	public void setsPlrCsmNum1(String sPlrCsmNum1) {
		this.sPlrCsmNum1 = sPlrCsmNum1;
	}

	/**
	 * @return the sPlrCsmNum2
	 */
	public String getsPlrCsmNum2() {
		return sPlrCsmNum2;
	}

	/**
	 * @param sPlrCsmNum2 the sPlrCsmNum2 to set
	 */
	public void setsPlrCsmNum2(String sPlrCsmNum2) {
		this.sPlrCsmNum2 = sPlrCsmNum2;
	}

	/**
	 * @return the hid_key_data
	 */
	public String getHid_key_data() {
		return hid_key_data;
	}

	/**
	 * @param hid_key_data the hid_key_data to set
	 */
	public void setHid_key_data(String hid_key_data) {
		this.hid_key_data = hid_key_data;
	}

	/**
	 * @return the sCustHomDoroAddr1
	 */
	public String getsCustHomDoroAddr1() {
		return sCustHomDoroAddr1;
	}

	/**
	 * @param sCustHomDoroAddr1 the sCustHomDoroAddr1 to set
	 */
	public void setsCustHomDoroAddr1(String sCustHomDoroAddr1) {
		this.sCustHomDoroAddr1 = sCustHomDoroAddr1;
	}

	/**
	 * @return the sCustHomAddMgtNo
	 */
	public String getsCustHomAddrMgtNo() {
		return sCustHomAddrMgtNo;
	}

	/**
	 * @param sCustHomAddMgtNo the sCustHomAddMgtNo to set
	 */
	public void setsCustHomAddMgtNo(String sCustHomAddrMgtNo) {
		this.sCustHomAddrMgtNo = sCustHomAddrMgtNo;
	}

	/**
	 * @return the sCustOfficeDoroAddr1
	 */
	public String getsCustOfficeDoroAddr1() {
		return sCustOfficeDoroAddr1;
	}

	/**
	 * @param sCustOfficeDoroAddr1 the sCustOfficeDoroAddr1 to set
	 */
	public void setsCustOfficeDoroAddr1(String sCustOfficeDoroAddr1) {
		this.sCustOfficeDoroAddr1 = sCustOfficeDoroAddr1;
	}

	/**
	 * @return the sCustOfficeAddMgtNo
	 */
	public String getsCustOfficeAddrMgtNo() {
		return sCustOfficeAddrMgtNo;
	}

	/**
	 * @param sCustOfficeAddMgtNo the sCustOfficeAddMgtNo to set
	 */
	public void setsCustOfficeAddMgtNo(String sCustOfficeAddrMgtNo) {
		this.sCustOfficeAddrMgtNo = sCustOfficeAddrMgtNo;
	}

}
