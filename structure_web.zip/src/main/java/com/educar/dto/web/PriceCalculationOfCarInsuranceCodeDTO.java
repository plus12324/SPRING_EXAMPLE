/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �ڵ��� ���� �ڵ� DTO
 * @author ������
 *
 */
public class PriceCalculationOfCarInsuranceCodeDTO {
	/** sOptCode **/
	private String sOptCode;
	/** sLongName **/
	private String sLongName;
	/** nOptAmt **/
	private String nOptAmt;
	/** sOptName **/
	private String sOptName;
	/** sMainCode **/
	private String sMainCode;
	/** sShortName **/
	private String sShortName;
	/** nDefaultRate **/
	private String nDefaultRate;
	/** nOrder **/
	private String nOrder;
	/** ���԰���ڵ� **/
	private String sCareerCode;
	/** ���԰����(�ӽ�) **/
	private String nCareerRate;
	/** ���԰����(å��) **/
	private String nBi1CareerRate;
	/** ���԰�»󼼸� **/
	private String sCareerName;
	/** ���������������� **/
	private String nRangeRate;
	/** ���������ڵ� **/
	private String sViolateCode;
	/** ���������� **/
	private String DnViolateRate;

	/**
	 * @return the sOptCode
	 */
	public String getsOptCode() {
		return sOptCode;
	}

	/**
	 * @param sOptCode the sOptCode to set
	 */
	public void setsOptCode(final String sOptCode) {
		this.sOptCode = sOptCode;
	}

	/**
	 * @return the sLongName
	 */
	public String getsLongName() {
		return sLongName;
	}

	/**
	 * @param sLongName the sLongName to set
	 */
	public void setsLongName(final String sLongName) {
		this.sLongName = sLongName;
	}

	/**
	 * @return the nOptAmt
	 */
	public String getnOptAmt() {
		return nOptAmt;
	}

	/**
	 * @param nOptAmt the nOptAmt to set
	 */
	public void setnOptAmt(final String nOptAmt) {
		this.nOptAmt = nOptAmt;
	}

	/**
	 * @return the sMainCode
	 */
	public String getsMainCode() {
		return sMainCode;
	}

	/**
	 * @param sMainCode the sMainCode to set
	 */
	public void setsMainCode(final String sMainCode) {
		this.sMainCode = sMainCode;
	}

	/**
	 * @return the sShortName
	 */
	public String getsShortName() {
		return sShortName;
	}

	/**
	 * @param sShortName the sShortName to set
	 */
	public void setsShortName(final String sShortName) {
		this.sShortName = sShortName;
	}

	/**
	 * @return the nDefaultRate
	 */
	public String getnDefaultRate() {
		return nDefaultRate;
	}

	/**
	 * @param nDefaultRate the nDefaultRate to set
	 */
	public void setnDefaultRate(final String nDefaultRate) {
		this.nDefaultRate = nDefaultRate;
	}

	/**
	 * @return the nOrder
	 */
	public String getnOrder() {
		return nOrder;
	}

	/**
	 * @param nOrder the nOrder to set
	 */
	public void setnOrder(final String nOrder) {
		this.nOrder = nOrder;
	}

	/**
	 * @return the sCareerCode
	 */
	public String getsCareerCode() {
		return sCareerCode;
	}

	/**
	 * @param sCareerCode the sCareerCode to set
	 */
	public void setsCareerCode(final String sCareerCode) {
		this.sCareerCode = sCareerCode;
	}

	/**
	 * @return the nCareerRate
	 */
	public String getnCareerRate() {
		return nCareerRate;
	}

	/**
	 * @param nCareerRate the nCareerRate to set
	 */
	public void setnCareerRate(final String nCareerRate) {
		this.nCareerRate = nCareerRate;
	}

	/**
	 * @return the nBi1CareerRate
	 */
	public String getnBi1CareerRate() {
		return nBi1CareerRate;
	}

	/**
	 * @param nBi1CareerRate the nBi1CareerRate to set
	 */
	public void setnBi1CareerRate(final String nBi1CareerRate) {
		this.nBi1CareerRate = nBi1CareerRate;
	}

	/**
	 * @return the sCareerName
	 */
	public String getsCareerName() {
		return sCareerName;
	}

	/**
	 * @param sCareerName the sCareerName to set
	 */
	public void setsCareerName(final String sCareerName) {
		this.sCareerName = sCareerName;
	}

	/**
	 * @return the nRangeRate
	 */
	public String getnRangeRate() {
		return nRangeRate;
	}

	/**
	 * @param nRangeRate the nRangeRate to set
	 */
	public void setnRangeRate(final String nRangeRate) {
		this.nRangeRate = nRangeRate;
	}

	/**
	 * @return the sViolateCode
	 */
	public String getsViolateCode() {
		return sViolateCode;
	}

	/**
	 * @param sViolateCode the sViolateCode to set
	 */
	public void setsViolateCode(final String sViolateCode) {
		this.sViolateCode = sViolateCode;
	}

	/**
	 * @return the nViolateRate
	 */
	public String getDnViolateRate() {
		return DnViolateRate;
	}

	/**
	 * @param nViolateRate the nViolateRate to set
	 */
	public void setDnViolateRate(final String DnViolateRate) {
		this.DnViolateRate = DnViolateRate;
	}

	/**
	 * @return the sOptName
	 */
	public String getsOptName() {
		return sOptName;
	}

	/**
	 * @param sOptName the sOptName to set
	 */
	public void setsOptName(final String sOptName) {
		this.sOptName = sOptName;
	}
}
