/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �輭 �㺸 ��ȸ DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorsePawnListOfCoverDTO")
public class EndorsePawnListOfCoverDTO implements Serializable {
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;

	/** �㺸�����ڵ� **/
	private String sOptCode;
	/** �㺸���Ը� **/
	private String sOptName;

	/**
	 * @return the sOptCode
	 */
	public String getsOptCode() {
		return sOptCode;
	}

	/**
	 * @param sOptCode the sOptCode to set
	 */
	public void setsOptCode(final String sOptCode) {
		this.sOptCode = sOptCode;
	}

	/**
	 * @return the sOptName
	 */
	public String getsOptName() {
		return sOptName;
	}

	/**
	 * @param sOptName the sOptName to set
	 */
	public void setsOptName(final String sOptName) {
		this.sOptName = sOptName;
	}

}
