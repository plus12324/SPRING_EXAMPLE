/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲݺ��� - ���⺻ ��ȸ DTO
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayList01DTO")
public class InsDrvPayList01DTO {
	/** 	�����ǰ��	**/ 
	private String	sInsTypeName;
	/** 	����ȣ	**/ 
	private String	sPolicyNo;
	/** 	�����	**/ 
	private String	sPolHolderName;
	/** 	����Ⱓ	**/ 
	private String	sInsDate;
	/** 	1ȸ �����	**/ 
	private String	s1stInsPrem;
	/** 	�����ֱ�/���	**/ 
	private String	sPayMthNam;
	/** 	ī��/��������	**/ 
	private String	sBnkActNam;
	/** 	��ü��	**/ 
	private String	sBwDate;
	/** 	�ѳ��Ժ����	**/ 
	private String	nTotRectPrem;
	/** 	�������Կ�	**/ 
	private String	sLastBwDate;
	/**
	 * @return the sInsTypeName
	 */
	public String getsInsTypeName() {
		return sInsTypeName;
	}
	/**
	 * @param sInsTypeName the sInsTypeName to set
	 */
	public void setsInsTypeName(String sInsTypeName) {
		this.sInsTypeName = sInsTypeName;
	}
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}
	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}
	/**
	 * @return the sInsDate
	 */
	public String getsInsDate() {
		return sInsDate;
	}
	/**
	 * @param sInsDate the sInsDate to set
	 */
	public void setsInsDate(String sInsDate) {
		this.sInsDate = sInsDate;
	}
	/**
	 * @return the s1stInsPrem
	 */
	public String getS1stInsPrem() {
		return s1stInsPrem;
	}
	/**
	 * @param s1stInsPrem the s1stInsPrem to set
	 */
	public void setS1stInsPrem(String s1stInsPrem) {
		this.s1stInsPrem = s1stInsPrem;
	}
	/**
	 * @return the sPayMthNam
	 */
	public String getsPayMthNam() {
		return sPayMthNam;
	}
	/**
	 * @param sPayMthNam the sPayMthNam to set
	 */
	public void setsPayMthNam(String sPayMthNam) {
		this.sPayMthNam = sPayMthNam;
	}
	/**
	 * @return the sBnkActNam
	 */
	public String getsBnkActNam() {
		return sBnkActNam;
	}
	/**
	 * @param sBnkActNam the sBnkActNam to set
	 */
	public void setsBnkActNam(String sBnkActNam) {
		this.sBnkActNam = sBnkActNam;
	}
	/**
	 * @return the sBwDate
	 */
	public String getsBwDate() {
		return sBwDate;
	}
	/**
	 * @param sBwDate the sBwDate to set
	 */
	public void setsBwDate(String sBwDate) {
		this.sBwDate = sBwDate;
	}
	/**
	 * @return the nTotRectPrem
	 */
	public String getnTotRectPrem() {
		return nTotRectPrem;
	}
	/**
	 * @param nTotRectPrem the nTotRectPrem to set
	 */
	public void setnTotRectPrem(String nTotRectPrem) {
		this.nTotRectPrem = nTotRectPrem;
	}
	/**
	 * @return the sLastBwDate
	 */
	public String getsLastBwDate() {
		return sLastBwDate;
	}
	/**
	 * @param sLastBwDate the sLastBwDate to set
	 */
	public void setsLastBwDate(String sLastBwDate) {
		this.sLastBwDate = sLastBwDate;
	}
	
	
}
