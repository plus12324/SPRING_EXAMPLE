/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.regex.RegexEnum;
import kr.co.conch.validator.annotation.regex.ValidateRegex;

import com.educar.common.annotation.BeanUtil;

/**
 * ����û DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "consultationRequestDTO")
public class ConsultationRequestDTO {
	/** �̸� or ���θ�  **/
	private String sName;
	/** �ֹι�ȣ or ����� ��ȣ **/
	private String sCustNo;
	/** ����óŸ�� 0:����, 1:����, 2:�繫, 3:�ڵ��� **/
	private String sTelType;
	/** �޴���1 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 3)
	private String sCellPhone1;
	/** �޴���2 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 4)
	private String sCellPhone2;
	/** �޴���3 **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 4)
	private String sCellPhone3;
	/** ��ȭ1 **/
	private String sCellNum1;
	/** ��ȭ2 **/
	private String sCellNum2;
	/** ��ȭ3 **/
	private String sCellNum3;
	/** ����û ���� **/
	@BeanUtil(ignore = true)
	private String sCounselType;

	public String getsCounselType() {
		return sCounselType;
	}

	public void setsCounselType(String sCounselType) {
		this.sCounselType = sCounselType;
	}

	/**
	 * @return the sCellNum1
	 */
	public String getsCellNum1() {
		return sCellNum1;
	}

	/**
	 * @param sCellNum1 the sCellNum1 to set
	 */
	public void setsCellNum1(String sCellNum1) {
		this.sCellNum1 = sCellNum1;
	}

	/**
	 * @return the sCellNum2
	 */
	public String getsCellNum2() {
		return sCellNum2;
	}

	/**
	 * @param sCellNum2 the sCellNum2 to set
	 */
	public void setsCellNum2(String sCellNum2) {
		this.sCellNum2 = sCellNum2;
	}

	/**
	 * @return the sCellNum3
	 */
	public String getsCellNum3() {
		return sCellNum3;
	}

	/**
	 * @param sCellNum3 the sCellNum3 to set
	 */
	public void setsCellNum3(String sCellNum3) {
		this.sCellNum3 = sCellNum3;
	}

	/** �̸��� �ּ� **/
	@ValidateRegex(predefinedRegex = RegexEnum.Email)
	private String email;
	/** ����, ���� ���а� 1:���� 2:����**/
	private String sCustType;
	/** �������(���Լ��� ����) ������� ���Ǵ� Y, ���� N**/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "joinAgreeList")
	private List<String> joinAgree;
	/** �������(Call ��ǰ�Ұ� �����̿� �� ��������) ������� ���Ǵ� Y, ���� N **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "callAgreeList")
	private List<String> callAgree;

	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}

	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(final String sCustType) {
		this.sCustType = sCustType;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(final String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(final String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(final String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(final String email) {
		this.email = email;
	}

	/**
	 * @return the sTelType
	 */
	public String getsTelType() {
		return sTelType;
	}

	/**
	 * @param sTelType the sTelType to set
	 */
	public void setsTelType(final String sTelType) {
		this.sTelType = sTelType;
	}

	/**
	 * @return the joinAgree
	 */
	public List<String> getJoinAgree() {
		return joinAgree;
	}

	/**
	 * @param joinAgree the joinAgree to set
	 */
	public void setJoinAgree(final List<String> joinAgree) {
		this.joinAgree = joinAgree;
	}

	/**
	 * @return the callAgree
	 */
	public List<String> getCallAgree() {
		return callAgree;
	}

	/**
	 * @param callAgree the callAgree to set
	 */
	public void setCallAgree(final List<String> callAgree) {
		this.callAgree = callAgree;
	}

}
