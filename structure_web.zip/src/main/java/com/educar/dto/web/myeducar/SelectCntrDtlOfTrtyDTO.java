/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ��⺸���(�����ȸ/����)- ��� ����ȸ DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCntrDtlOfTrtyDTO")
public class SelectCntrDtlOfTrtyDTO {
	/** ���谡�Աݾ׸� **/
	private String nTrtyInsAmtName;
	/** Ư�ຸ��� **/
	private String nTrtyPrem;
	/** ���ſ��� **/
	private String sRenwlYn;
	/** ������ñ� **/
	private String sInsurStrtdate;
	/** ���������� **/
	private String sInsurEndDate;
	/** �⺻���ñ��и� **/
	private String sBascSlctFlagNm;
	/** Ư��� **/
	private String sTrtyNm;

	/**
	 * @return the nTrtyInsAmtName
	 */
	public String getnTrtyInsAmtName() {
		return nTrtyInsAmtName;
	}

	/**
	 * @param nTrtyInsAmtName the nTrtyInsAmtName to set
	 */
	public void setnTrtyInsAmtName(final String nTrtyInsAmtName) {
		this.nTrtyInsAmtName = nTrtyInsAmtName;
	}

	/**
	 * @return the nTrtyPrem
	 */
	public String getnTrtyPrem() {
		return nTrtyPrem;
	}

	/**
	 * @param nTrtyPrem the nTrtyPrem to set
	 */
	public void setnTrtyPrem(final String nTrtyPrem) {
		this.nTrtyPrem = nTrtyPrem;
	}

	/**
	 * @return the sRenwlYn
	 */
	public String getsRenwlYn() {
		return sRenwlYn;
	}

	/**
	 * @param sRenwlYn the sRenwlYn to set
	 */
	public void setsRenwlYn(final String sRenwlYn) {
		this.sRenwlYn = sRenwlYn;
	}

	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}

	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(final String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}

	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}

	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(final String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}

	/**
	 * @return the sBascSlctFlagNm
	 */
	public String getsBascSlctFlagNm() {
		return sBascSlctFlagNm;
	}

	/**
	 * @param sBascSlctFlagNm the sBascSlctFlagNm to set
	 */
	public void setsBascSlctFlagNm(final String sBascSlctFlagNm) {
		this.sBascSlctFlagNm = sBascSlctFlagNm;
	}

	/**
	 * @return the sTrtyNm
	 */
	public String getsTrtyNm() {
		return sTrtyNm;
	}

	/**
	 * @param sTrtyNm the sTrtyNm to set
	 */
	public void setsTrtyNm(final String sTrtyNm) {
		this.sTrtyNm = sTrtyNm;
	}

}
