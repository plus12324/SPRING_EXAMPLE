/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �����Ƚɼ��� - ���û�� ���Ǵ� DTO
 * @since 0.0.10
 */
@XmlRootElement(name = "parkingReTryAddrDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ParkingReTryAddrDTO {

	/** 	����ȣ	**/ 
	private String 	sPolicyType;
	/** 	����ȣ	**/ 
	private String 	sPolicyYM;
	/** 	����ȣ	**/ 
	private String 	sPolicySer;
	private CustomerContInfoAdrsInfoDTO custInfo;
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO home;
	/** ���� �����ּ����� **/
	private CustomerContInfoAdrsDTO office;
	/** ���� ��Ÿ���ּ����� **/
	private CustomerContInfoAdrsDTO etc;
	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}
	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}
	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}
	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}
	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}
	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}
	
	/**
	 * @return the custInfo
	 */
	public CustomerContInfoAdrsInfoDTO getCustInfo() {
		return custInfo;
	}
	/**
	 * @param custInfo the custInfo to set
	 */
	public void setCustInfo(CustomerContInfoAdrsInfoDTO custInfo) {
		this.custInfo = custInfo;
	}
	/**
	 * @return the home
	 */
	public CustomerContInfoAdrsDTO getHome() {
		return home;
	}
	/**
	 * @param home the home to set
	 */
	public void setHome(CustomerContInfoAdrsDTO home) {
		this.home = home;
	}
	/**
	 * @return the office
	 */
	public CustomerContInfoAdrsDTO getOffice() {
		return office;
	}
	/**
	 * @param office the office to set
	 */
	public void setOffice(CustomerContInfoAdrsDTO office) {
		this.office = office;
	}
	/**
	 * @return the etc
	 */
	public CustomerContInfoAdrsDTO getEtc() {
		return etc;
	}
	/**
	 * @param etc the etc to set
	 */
	public void setEtc(CustomerContInfoAdrsDTO etc) {
		this.etc = etc;
	}
	
	
}
