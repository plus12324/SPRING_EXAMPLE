/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� - ���� �������޾� ���
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfRtnAmtDtalSearchResultDTO")
public class PriceCalculationOfRtnAmtDtalSearchResultDTO {
	/** ����ȯ�ޱ�  **/
	@XmlElementWrapper(name = "vLTIDA20List")
	private List<PriceCalculationOfRtnAtmDTO> vLTIDA20;
	/** ���󸸱�ȯ�ޱ� **/
	private String nExptEndRetrnAmt;
	/** ���󸸱�ȯ���� **/
	private String nExptEndRtnrt;
	/** �� 1ȸ ���󿬱����޾� **/
	private String nStndRtnAmt20;
	/**
	 * @return the vLTIDA20
	 */
	public List<PriceCalculationOfRtnAtmDTO> getvLTIDA20() {
		return vLTIDA20;
	}
	/**
	 * @param vLTIDA20 the vLTIDA20 to set
	 */
	public void setvLTIDA20(List<PriceCalculationOfRtnAtmDTO> vLTIDA20) {
		this.vLTIDA20 = vLTIDA20;
	}
	/**
	 * @return the nStndRtnAmt20
	 */
	public String getnStndRtnAmt20() {
		return nStndRtnAmt20;
	}
	/**
	 * @param nStndRtnAmt20 the nStndRtnAmt20 to set
	 */
	public void setnStndRtnAmt20(String nStndRtnAmt20) {
		this.nStndRtnAmt20 = nStndRtnAmt20;
	}
	/**
	 * @return the nExptEndRetrnAmt
	 */
	public String getnExptEndRetrnAmt() {
		return nExptEndRetrnAmt;
	}
	/**
	 * @param nExptEndRetrnAmt the nExptEndRetrnAmt to set
	 */
	public void setnExptEndRetrnAmt(String nExptEndRetrnAmt) {
		this.nExptEndRetrnAmt = nExptEndRetrnAmt;
	}
	/**
	 * @return the nExptEndRtnrt
	 */
	public String getnExptEndRtnrt() {
		return nExptEndRtnrt;
	}
	/**
	 * @param nExptEndRtnrt the nExptEndRtnrt to set
	 */
	public void setnExptEndRtnrt(String nExptEndRtnrt) {
		this.nExptEndRtnrt = nExptEndRtnrt;
	}
	
	
}
