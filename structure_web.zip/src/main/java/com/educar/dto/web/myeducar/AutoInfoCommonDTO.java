/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���/��������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "autoInfoCommonDTO")
public class AutoInfoCommonDTO {
	/** 	�����ڵ�	 **/
	private String	sErrorCode;
	/** 	��������	 **/ 
	private String	sAcctKind;
	/** 	����������	 **/ 
	private String	sCmMetdNm;
	/** 	���Թ��	 **/ 
	private String	PaymCyclNm;
	/** 	�����ָ� / ī������ڸ�	 **/ 
	private String	sDpsrName;
	/** 	����	 **/ 
	private String	sBankNm;
	/** 	���¹�ȣ / ī���ȣ	 **/ 
	private String	sAcctNo;
	/** 	ī���ȣ1	 **/ 
	private String	sAcctNo1;
	/** 	ī���ȣ2	 **/ 
	private String	sAcctNo2;
	/** 	ī���ȣ3	 **/ 
	private String	sAcctNo3;
	/** 	ī���ȣ4	 **/ 
	private String	sAcctNo4;	
	/** 	ī����ȿ�Ⱓ	 **/ 
	private String	sCardValdYearMnth;
	/** 	�������	 **/ 
	private String	sAcctType;
	/** 	������ֹι�ȣ	 **/ 
	private String	sCrtorCd;
	/** 	����ڸ�	 **/ 
	private String	sCrtorName;
	/** 	�������ֹι�ȣ	 **/ 
	private String	sDpsrCd;
	/** ��ü������ **/
	private String sTrnfAsmtDate;
	/** �����ڵ� **/
	private String sBankCd;
	/** �Է�ó���� **/
	private String sUserID;
	/** ����ȣ **/
	private String sCrNo;
	/** û���ȣ**/
	private String sApplyNo;
	/** ��ȣȭŰ */
	private String sHid_key_data;
	
	public String getsHid_key_data() {
		return sHid_key_data;
	}
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}
	
	public String getsAcctNo1() {
		return sAcctNo1;
	}
	public void setsAcctNo1(String sAcctNo1) {
		this.sAcctNo1 = sAcctNo1;
	}
	public String getsAcctNo2() {
		return sAcctNo2;
	}
	public void setsAcctNo2(String sAcctNo2) {
		this.sAcctNo2 = sAcctNo2;
	}
	public String getsAcctNo3() {
		return sAcctNo3;
	}
	public void setsAcctNo3(String sAcctNo3) {
		this.sAcctNo3 = sAcctNo3;
	}
	public String getsAcctNo4() {
		return sAcctNo4;
	}
	public void setsAcctNo4(String sAcctNo4) {
		this.sAcctNo4 = sAcctNo4;
	}
	
	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}
	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}
	/**
	 * @return the sAcctKind
	 */
	public String getsAcctKind() {
		return sAcctKind;
	}
	/**
	 * @param sAcctKind the sAcctKind to set
	 */
	public void setsAcctKind(String sAcctKind) {
		this.sAcctKind = sAcctKind;
	}
	/**
	 * @return the sCmMetdNm
	 */
	public String getsCmMetdNm() {
		return sCmMetdNm;
	}
	/**
	 * @param sCmMetdNm the sCmMetdNm to set
	 */
	public void setsCmMetdNm(String sCmMetdNm) {
		this.sCmMetdNm = sCmMetdNm;
	}
	/**
	 * @return the paymCyclNm
	 */
	public String getPaymCyclNm() {
		return PaymCyclNm;
	}
	/**
	 * @param paymCyclNm the paymCyclNm to set
	 */
	public void setPaymCyclNm(String paymCyclNm) {
		PaymCyclNm = paymCyclNm;
	}
	/**
	 * @return the sDpsrName
	 */
	public String getsDpsrName() {
		return sDpsrName;
	}
	/**
	 * @param sDpsrName the sDpsrName to set
	 */
	public void setsDpsrName(String sDpsrName) {
		this.sDpsrName = sDpsrName;
	}
	/**
	 * @return the sBankNm
	 */
	public String getsBankNm() {
		return sBankNm;
	}
	/**
	 * @param sBankNm the sBankNm to set
	 */
	public void setsBankNm(String sBankNm) {
		this.sBankNm = sBankNm;
	}
	/**
	 * @return the sAcctNo
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}
	/**
	 * @param sAcctNo the sAcctNo to set
	 */
	public void setsAcctNo(String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}
	/**
	 * @return the sCardValdYearMnth
	 */
	public String getsCardValdYearMnth() {
		return sCardValdYearMnth;
	}
	/**
	 * @param sCardValdYearMnth the sCardValdYearMnth to set
	 */
	public void setsCardValdYearMnth(String sCardValdYearMnth) {
		this.sCardValdYearMnth = sCardValdYearMnth;
	}
	/**
	 * @return the sAcctType
	 */
	public String getsAcctType() {
		return sAcctType;
	}
	/**
	 * @param sAcctType the sAcctType to set
	 */
	public void setsAcctType(String sAcctType) {
		this.sAcctType = sAcctType;
	}
	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}
	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sDpsrCd
	 */
	public String getsDpsrCd() {
		return sDpsrCd;
	}
	/**
	 * @param sDpsrCd the sDpsrCd to set
	 */
	public void setsDpsrCd(String sDpsrCd) {
		this.sDpsrCd = sDpsrCd;
	}
	/**
	 * @return the sTrnfAsmtDate
	 */
	public String getsTrnfAsmtDate() {
		return sTrnfAsmtDate;
	}
	/**
	 * @param sTrnfAsmtDate the sTrnfAsmtDate to set
	 */
	public void setsTrnfAsmtDate(String sTrnfAsmtDate) {
		this.sTrnfAsmtDate = sTrnfAsmtDate;
	}
	/**
	 * @return the sBankCd
	 */
	public String getsBankCd() {
		return sBankCd;
	}
	/**
	 * @param sBankCd the sBankCd to set
	 */
	public void setsBankCd(String sBankCd) {
		this.sBankCd = sBankCd;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sApplyNo
	 */
	public String getsApplyNo() {
		return sApplyNo;
	}
	/**
	 * @param sApplyNo the sApplyNo to set
	 */
	public void setsApplyNo(String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}
	
	
}
