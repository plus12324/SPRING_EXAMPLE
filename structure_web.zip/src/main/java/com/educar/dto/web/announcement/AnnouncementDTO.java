/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.announcement;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ���ý� ���ð濵���� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "announcementDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AnnouncementDTO extends PageDTO implements Serializable {

	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;

	/** ��ȣ **/
	private String SEQ;
	/** ���� **/
	private String TITLE;
	/** �������� **/
	private String VIEW_YN;
	/** ������ **/
	private String CRE_ID;
	/** ������ **/
	private String UPD_ID;
	/** ������¥ **/
	private String CRE_DT;
	/** �����ð� **/
	private String CRE_TIME;
	/** ������¥ **/
	private String UPD_DT;
	/** �����ð� **/
	private String UPD_TIME;
	/** �����̸� **/
	private String FILE_NM;
	/** ���ϰ�� **/
	private String FILE_PATH;
	/** �������ڵ��̸� **/
	private String FILE_STR_NM;
	/** ���ϰ�� **/
	private String FILE_REAL_PATH;
	/** ���ð濵 1, ��������ǥ2 **/
	private String sType;

	/**
	 * @return the sEQ
	 */
	public String getSEQ() {
		return SEQ;
	}

	/**
	 * @return the tITLE
	 */
	public String getTITLE() {
		return TITLE;
	}

	/**
	 * @return the vIEW_YN
	 */
	public String getVIEW_YN() {
		return VIEW_YN;
	}

	/**
	 * @return the cRE_ID
	 */
	public String getCRE_ID() {
		return CRE_ID;
	}

	/**
	 * @return the uPD_ID
	 */
	public String getUPD_ID() {
		return UPD_ID;
	}

	/**
	 * @return the cRE_DT
	 */
	public String getCRE_DT() {
		return CRE_DT;
	}

	/**
	 * @return the cRE_TIME
	 */
	public String getCRE_TIME() {
		return CRE_TIME;
	}

	/**
	 * @return the uPD_DT
	 */
	public String getUPD_DT() {
		return UPD_DT;
	}

	/**
	 * @return the uPD_TIME
	 */
	public String getUPD_TIME() {
		return UPD_TIME;
	}

	/**
	 * @return the fILE_NM
	 */
	public String getFILE_NM() {
		return FILE_NM;
	}

	/**
	 * @return the fILE_PATH
	 */
	public String getFILE_PATH() {
		return FILE_PATH;
	}

	/**
	 * @return the fILE_STR_NM
	 */
	public String getFILE_STR_NM() {
		return FILE_STR_NM;
	}

	/**
	 * @return the fILE_REAL_PATH
	 */
	public String getFILE_REAL_PATH() {
		return FILE_REAL_PATH;
	}

	/**
	 * @param sEQ the sEQ to set
	 */
	public void setSEQ(final String sEQ) {
		SEQ = sEQ;
	}

	/**
	 * @param tITLE the tITLE to set
	 */
	public void setTITLE(final String tITLE) {
		TITLE = tITLE;
	}

	/**
	 * @param vIEW_YN the vIEW_YN to set
	 */
	public void setVIEW_YN(final String vIEW_YN) {
		VIEW_YN = vIEW_YN;
	}

	/**
	 * @param cRE_ID the cRE_ID to set
	 */
	public void setCRE_ID(final String cRE_ID) {
		CRE_ID = cRE_ID;
	}

	/**
	 * @param uPD_ID the uPD_ID to set
	 */
	public void setUPD_ID(final String uPD_ID) {
		UPD_ID = uPD_ID;
	}

	/**
	 * @param cRE_DT the cRE_DT to set
	 */
	public void setCRE_DT(final String cRE_DT) {
		CRE_DT = cRE_DT;
	}

	/**
	 * @param cRE_TIME the cRE_TIME to set
	 */
	public void setCRE_TIME(final String cRE_TIME) {
		CRE_TIME = cRE_TIME;
	}

	/**
	 * @param uPD_DT the uPD_DT to set
	 */
	public void setUPD_DT(final String uPD_DT) {
		UPD_DT = uPD_DT;
	}

	/**
	 * @param uPD_TIME the uPD_TIME to set
	 */
	public void setUPD_TIME(final String uPD_TIME) {
		UPD_TIME = uPD_TIME;
	}

	/**
	 * @param fILE_NM the fILE_NM to set
	 */
	public void setFILE_NM(final String fILE_NM) {
		FILE_NM = fILE_NM;
	}

	/**
	 * @param fILE_PATH the fILE_PATH to set
	 */
	public void setFILE_PATH(final String fILE_PATH) {
		FILE_PATH = fILE_PATH;
	}

	/**
	 * @param fILE_STR_NM the fILE_STR_NM to set
	 */
	public void setFILE_STR_NM(final String fILE_STR_NM) {
		FILE_STR_NM = fILE_STR_NM;
	}

	/**
	 * @param fILE_REAL_PATH the fILE_REAL_PATH to set
	 */
	public void setFILE_REAL_PATH(final String fILE_REAL_PATH) {
		FILE_REAL_PATH = fILE_REAL_PATH;
	}

	/**
	 * @return the sType
	 */
	public String getsType() {
		return sType;
	}

	/**
	 * @param sType the sType to set
	 */
	public void setsType(final String sType) {
		this.sType = sType;
	}

}
