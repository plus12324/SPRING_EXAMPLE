/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * ���ä�� DTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "cusaa62DTO")
public class Cusaa62DTO{
	/** ������ȣ		**/ 
	private String sCustNo;
	/** ����			**/ 
	private String sName;
	/** �Է���ID			**/ 
	private String sEmpNo;
	/** ���ǹ�ȣ **/
	private String sInputNo;
	
	public String getsInputNo() {
		return sInputNo;
	}
	public void setsInputNo(String sInputNo) {
		this.sInputNo = sInputNo;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sEmpNo
	 */
	public String getsEmpNo() {
		return sEmpNo;
	}
	/**
	 * @param sEmpNo the sEmpNo to set
	 */
	public void setsEmpNo(String sEmpNo) {
		this.sEmpNo = sEmpNo;
	}
	
	
}
