/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.dto.web.AccidentClaimStatusDTO;

/**
 * <pre>
 * ���󼭺� - ����/�ǰ����� - ���󳻿���ȸ - ����������� �� wrapper DTO
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "accidentHealthClaimWrapperDTO")
public class AccidentHealthClaimWrapperDTO {

	/** ���ذǰ��������󼼳��� **/
	private DmgProgDetailResultDTO dmgProgDetailResult;
	/** ���ذǰ����� ���� �� ������� **/
	private AccidentClaimStatusDTO accidentClaimStatus;

	/**
	 * @return the dmgProgDetailResult
	 */
	public DmgProgDetailResultDTO getDmgProgDetailResult() {
		return dmgProgDetailResult;
	}

	/**
	 * @param dmgProgDetailResult the dmgProgDetailResult to set
	 */
	public void setDmgProgDetailResult(final DmgProgDetailResultDTO dmgProgDetailResult) {
		this.dmgProgDetailResult = dmgProgDetailResult;
	}

	/**
	 * @return the accidentClaimStatus
	 */
	public AccidentClaimStatusDTO getAccidentClaimStatus() {
		return accidentClaimStatus;
	}

	/**
	 * @param accidentClaimStatus the accidentClaimStatus to set
	 */
	public void setAccidentClaimStatus(final AccidentClaimStatusDTO accidentClaimStatus) {
		this.accidentClaimStatus = accidentClaimStatus;
	}
}
