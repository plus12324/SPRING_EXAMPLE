/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ����� ����� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calculationOfCarInsuranceResultDTO")
public class CalculationOfCarInsuranceResultDTO {
	/** �ڵ��� �Ѻ����, ��ȸ ����� **/
	private CalculationOfCarInsuranceTotalDTO polaa02Info;
	/** ���� ����� List **/
	private List<CalculationOfCarInsuranceApplyDTO> coverVt;
	/** �����޼��� (������ ��� �޼����� ������) **/
	private String sErrorMsg;

	/**
	 * @return the polaa02Info
	 */
	public CalculationOfCarInsuranceTotalDTO getPolaa02Info() {
		return polaa02Info;
	}

	/**
	 * @param polaa02Info the polaa02Info to set
	 */
	public void setPolaa02Info(final CalculationOfCarInsuranceTotalDTO polaa02Info) {
		this.polaa02Info = polaa02Info;
	}

	/**
	 * @return the coverVt
	 */
	public List<CalculationOfCarInsuranceApplyDTO> getCoverVt() {
		return coverVt;
	}

	/**
	 * @param coverVt the coverVt to set
	 */
	public void setCoverVt(final List<CalculationOfCarInsuranceApplyDTO> coverVt) {
		this.coverVt = coverVt;
	}

	/**
	 * @return the sErrorMsg
	 */
	public String getsErrorMsg() {
		return sErrorMsg;
	}

	/**
	 * @param sErrorMsg the sErrorMsg to set
	 */
	public void setsErrorMsg(final String sErrorMsg) {
		this.sErrorMsg = sErrorMsg;
	}

}
