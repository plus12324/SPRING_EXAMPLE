/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���ݺ��� (���������� ����) �����ڵ� ��ȸ
 * @author ���ѳ�
 *
 */

@XmlRootElement(name = "longAnntCommCodeWrapperDTO")
public class LongAnntCommCodeWrapperDTO{
	/** ��ǰ�ڵ� **/ 
	private String	sGdCd;
	/** �����ڵ� **/ 
	private String	sGnrzCd;
	/** û���� **/ 
	private String	sStndDate;
	/** �÷��ڵ� **/ 
	private String	sPlanCd;
	/** �Ǻ������ֹι�ȣ **/ 
	private String	sResno;
	/** ���������ڵ� **/ 
	private String	sDrivFlagCd;
	/** ���δ�ü�����ڵ� **/ 
	private String	sPlanPsnGroupCd;
	/** �����з��ڵ� **/ 
	private String	sBunsMetdDocuClsfCd;
	
	/** �����ֱ� **/
	private List<LongAnntCommCodeDTO> AnntyPymCyclList;
	/** ���ݰ��ó��� **/
	private List<LongAnntCommCodeDTO> AnntyOpnAgeList;
	/** �������� **/
	private List<LongAnntCommCodeDTO> AnntyPymTypeList;
	/** ���ޱⰣ **/
	private List<LongAnntCommCodeDTO> AnntyPymTermList;
	/** ���ԱⰣ **/
	private List<LongAnntCommCodeDTO> InsurTermPaymTerm;
	/** �����ֱ� **/
	private List<LongAnntCommCodeDTO> paymCyclCdList;
	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}
	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(String sGdCd) {
		this.sGdCd = sGdCd;
	}
	/**
	 * @return the sGnrzCd
	 */
	public String getsGnrzCd() {
		return sGnrzCd;
	}
	/**
	 * @param sGnrzCd the sGnrzCd to set
	 */
	public void setsGnrzCd(String sGnrzCd) {
		this.sGnrzCd = sGnrzCd;
	}
	/**
	 * @return the sStndDate
	 */
	public String getsStndDate() {
		return sStndDate;
	}
	/**
	 * @param sStndDate the sStndDate to set
	 */
	public void setsStndDate(String sStndDate) {
		this.sStndDate = sStndDate;
	}
	/**
	 * @return the sPlanCd
	 */
	public String getsPlanCd() {
		return sPlanCd;
	}
	/**
	 * @param sPlanCd the sPlanCd to set
	 */
	public void setsPlanCd(String sPlanCd) {
		this.sPlanCd = sPlanCd;
	}
	/**
	 * @return the sResno
	 */
	public String getsResno() {
		return sResno;
	}
	/**
	 * @param sResno the sResno to set
	 */
	public void setsResno(String sResno) {
		this.sResno = sResno;
	}
	/**
	 * @return the sDrivFlagCd
	 */
	public String getsDrivFlagCd() {
		return sDrivFlagCd;
	}
	/**
	 * @param sDrivFlagCd the sDrivFlagCd to set
	 */
	public void setsDrivFlagCd(String sDrivFlagCd) {
		this.sDrivFlagCd = sDrivFlagCd;
	}
	/**
	 * @return the sPlanPsnGroupCd
	 */
	public String getsPlanPsnGroupCd() {
		return sPlanPsnGroupCd;
	}
	/**
	 * @param sPlanPsnGroupCd the sPlanPsnGroupCd to set
	 */
	public void setsPlanPsnGroupCd(String sPlanPsnGroupCd) {
		this.sPlanPsnGroupCd = sPlanPsnGroupCd;
	}
	/**
	 * @return the sBunsMetdDocuClsfCd
	 */
	public String getsBunsMetdDocuClsfCd() {
		return sBunsMetdDocuClsfCd;
	}
	/**
	 * @param sBunsMetdDocuClsfCd the sBunsMetdDocuClsfCd to set
	 */
	public void setsBunsMetdDocuClsfCd(String sBunsMetdDocuClsfCd) {
		this.sBunsMetdDocuClsfCd = sBunsMetdDocuClsfCd;
	}
	/**
	 * @return the anntyPymCyclList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymCyclList() {
		return AnntyPymCyclList;
	}
	/**
	 * @param anntyPymCyclList the anntyPymCyclList to set
	 */
	public void setAnntyPymCyclList(List<LongAnntCommCodeDTO> anntyPymCyclList) {
		AnntyPymCyclList = anntyPymCyclList;
	}
	/**
	 * @return the anntyOpnAgeList
	 */
	public List<LongAnntCommCodeDTO> getAnntyOpnAgeList() {
		return AnntyOpnAgeList;
	}
	/**
	 * @param anntyOpnAgeList the anntyOpnAgeList to set
	 */
	public void setAnntyOpnAgeList(List<LongAnntCommCodeDTO> anntyOpnAgeList) {
		AnntyOpnAgeList = anntyOpnAgeList;
	}
	/**
	 * @return the anntyPymTypeList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymTypeList() {
		return AnntyPymTypeList;
	}
	/**
	 * @param anntyPymTypeList the anntyPymTypeList to set
	 */
	public void setAnntyPymTypeList(List<LongAnntCommCodeDTO> anntyPymTypeList) {
		AnntyPymTypeList = anntyPymTypeList;
	}
	/**
	 * @return the anntyPymTermList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymTermList() {
		return AnntyPymTermList;
	}
	/**
	 * @param anntyPymTermList the anntyPymTermList to set
	 */
	public void setAnntyPymTermList(List<LongAnntCommCodeDTO> anntyPymTermList) {
		AnntyPymTermList = anntyPymTermList;
	}
	/**
	 * @return the insurTermPaymTerm
	 */
	public List<LongAnntCommCodeDTO> getInsurTermPaymTerm() {
		return InsurTermPaymTerm;
	}
	/**
	 * @param insurTermPaymTerm the insurTermPaymTerm to set
	 */
	public void setInsurTermPaymTerm(List<LongAnntCommCodeDTO> insurTermPaymTerm) {
		InsurTermPaymTerm = insurTermPaymTerm;
	}
	/**
	 * @return the paymCyclCdList
	 */
	public List<LongAnntCommCodeDTO> getPaymCyclCdList() {
		return paymCyclCdList;
	}
	/**
	 * @param paymCyclCdList the paymCyclCdList to set
	 */
	public void setPaymCyclCdList(List<LongAnntCommCodeDTO> paymCyclCdList) {
		this.paymCyclCdList = paymCyclCdList;
	}
}
