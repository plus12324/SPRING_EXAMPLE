/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;
import kr.co.conch.validator.annotation.registration.RegistrationType;
import kr.co.conch.validator.annotation.registration.ValidateRegistration;

/**
 * �����Ƚɼ��񽺿� ���Ǵ� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "myEduCallDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyEduCallDTO {

	private String sPolicyNo; // ����ȣ
	private String sPlateNo; // ������ȣ
	private String sRectDate; // ���ü������
	private String sServiceNo; // �����ȣ
	private String sReceiptNo1; // �ڵ�����ȣ
	private String nChangeNo; // ����ȸ��
	private String sLast; // ��������
	@ValidateRegistration(type = RegistrationType.RRN)
	private String sCustNo; // �ֹι�ȣ
	@ValidateDate(dateFormat = DateFormat.yyyyMMdd, required = true)
	private String sStartDate; // ��������
	private String sEndDate; // ��������
	private String sMdfcDler; // �����ID
	private String sSendYN; // ��뿩��
	private String sSendDate; // ��������
	private String sTodt; // ��� ���� �Ⱓ
	private String sMdfcDlerIP; // ȭ�鿡�� ������
	private String sUseYN; // ���� (��뿩��)
	private String sDate; // ȭ�鿡�� ����ϴ� ������Ⱓ sRectDate ~ sTodt
	// operation ����, i = insert, m= ����, d= ����. ������ �Ѱ���� �Ѵ�
	@ValidateLength(type = TypeEnum.STRING, min = 1, max = 1, required = true)
	private String editCode;
	private String sCancel; // ��ҿ���

	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}

	/**
	 * @return the sServiceNo
	 */
	public String getsServiceNo() {
		return sServiceNo;
	}

	/**
	 * @return the sReceiptNo1
	 */
	public String getsReceiptNo1() {
		return sReceiptNo1;
	}

	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @return the sStartDate
	 */
	public String getsStartDate() {
		return sStartDate;
	}

	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}

	/**
	 * @return the sMdfcDler
	 */
	public String getsMdfcDler() {
		return sMdfcDler;
	}

	/**
	 * @return the sSendYN
	 */
	public String getsSendYN() {
		return sSendYN;
	}

	/**
	 * @return the sSendDate
	 */
	public String getsSendDate() {
		return sSendDate;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @return the sMdfcDlerIP
	 */
	public String getsMdfcDlerIP() {
		return sMdfcDlerIP;
	}

	/**
	 * @return the editCode
	 */
	public String getEditCode() {
		return editCode;
	}

	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(final String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(final String sRectDate) {
		this.sRectDate = sRectDate;
	}

	/**
	 * @param sServiceNo the sServiceNo to set
	 */
	public void setsServiceNo(final String sServiceNo) {
		this.sServiceNo = sServiceNo;
	}

	/**
	 * @param sReceiptNo1 the sReceiptNo1 to set
	 */
	public void setsReceiptNo1(final String sReceiptNo1) {
		this.sReceiptNo1 = sReceiptNo1;
	}

	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(final String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @param sStartDate the sStartDate to set
	 */
	public void setsStartDate(final String sStartDate) {
		this.sStartDate = sStartDate;
	}

	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(final String sEndDate) {
		this.sEndDate = sEndDate;
	}

	/**
	 * @param sMdfcDler the sMdfcDler to set
	 */
	public void setsMdfcDler(final String sMdfcDler) {
		this.sMdfcDler = sMdfcDler;
	}

	/**
	 * @param sSendYN the sSendYN to set
	 */
	public void setsSendYN(final String sSendYN) {
		this.sSendYN = sSendYN;
	}

	/**
	 * @param sSendDate the sSendDate to set
	 */
	public void setsSendDate(final String sSendDate) {
		this.sSendDate = sSendDate;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @param sMdfcDlerIP the sMdfcDlerIP to set
	 */
	public void setsMdfcDlerIP(final String sMdfcDlerIP) {
		this.sMdfcDlerIP = sMdfcDlerIP;
	}

	/**
	 * @param editCode the editCode to set
	 */
	public void setEditCode(final String editCode) {
		this.editCode = editCode;
	}

	/**
	 * @return the sUseYN
	 */
	public String getsUseYN() {
		return sUseYN;
	}

	/**
	 * @param sUseYN the sUseYN to set
	 */
	public void setsUseYN(final String sUseYN) {
		this.sUseYN = sUseYN;
	}

	/**
	 * @return the sDate
	 */
	public String getsDate() {
		return sDate;
	}

	/**
	 * @param sDate the sDate to set
	 */
	public void setsDate(final String sDate) {
		this.sDate = sDate;
	}

	/**
	 * @return the sCancel
	 */
	public String getsCancel() {
		return sCancel;
	}

	/**
	 * @param sCancel the sCancel to set
	 */
	public void setsCancel(final String sCancel) {
		this.sCancel = sCancel;
	}

}
