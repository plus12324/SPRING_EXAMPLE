/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� �⺻���� �Է� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerContSaveSalesOfDealerInfoDTO")
public class DealerContSaveSalesOfDealerInfoDTO {
	/** �����ڵ� **/
	private String sMsgCode;
	/** ����޼��� **/
	private String sMsg;
	/** �������� **/
	private String sInsType;
	/** �����ȣ **/
	private String sApplyNo;
	/** �Ǻ����ڱ��� **/
	private String sInsrdType;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** �Ǻ������ڵ� **/
	private String sInsrdID;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ���ұ��� **/
	private String sCalcType;
	/** ����� �ڵ� **/
	private String sUserID;
	/** �㺸���� **/
	private String nCoverCnt;
	/** �Ѻ���� **/
	private String sTotalPrem;
	/** ����߼� ���� **/
	private String sEmail;

	/**
	 * @return the sMsgCode
	 */
	public String getsMsgCode() {
		return sMsgCode;
	}

	/**
	 * @param sMsgCode the sMsgCode to set
	 */
	public void setsMsgCode(final String sMsgCode) {
		this.sMsgCode = sMsgCode;
	}

	/**
	 * @return the sMsg
	 */
	public String getsMsg() {
		return sMsg;
	}

	/**
	 * @param sMsg the sMsg to set
	 */
	public void setsMsg(final String sMsg) {
		this.sMsg = sMsg;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sApplyNo
	 */
	public String getsApplyNo() {
		return sApplyNo;
	}

	/**
	 * @param sApplyNo the sApplyNo to set
	 */
	public void setsApplyNo(final String sApplyNo) {
		this.sApplyNo = sApplyNo;
	}

	/**
	 * @return the sInsrdType
	 */
	public String getsInsrdType() {
		return sInsrdType;
	}

	/**
	 * @param sInsrdType the sInsrdType to set
	 */
	public void setsInsrdType(final String sInsrdType) {
		this.sInsrdType = sInsrdType;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sCalcType
	 */
	public String getsCalcType() {
		return sCalcType;
	}

	/**
	 * @param sCalcType the sCalcType to set
	 */
	public void setsCalcType(final String sCalcType) {
		this.sCalcType = sCalcType;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the nCoverCnt
	 */
	public String getnCoverCnt() {
		return nCoverCnt;
	}

	/**
	 * @param nCoverCnt the nCoverCnt to set
	 */
	public void setnCoverCnt(final String nCoverCnt) {
		this.nCoverCnt = nCoverCnt;
	}

	/**
	 * @return the sTotalPrem
	 */
	public String getsTotalPrem() {
		return sTotalPrem;
	}

	/**
	 * @param sTotalPrem the sTotalPrem to set
	 */
	public void setsTotalPrem(final String sTotalPrem) {
		this.sTotalPrem = sTotalPrem;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

}
