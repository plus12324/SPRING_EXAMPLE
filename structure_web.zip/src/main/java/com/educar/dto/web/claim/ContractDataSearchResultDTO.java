/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���谡����(�Ǻ�����)�� ������ ��ȸ ��� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlRootElement(name = "contractDataSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContractDataSearchResultDTO {
	/** �Ǻ����� **/
	private String sInsrdName;
	/** �ֹε�Ϲ�ȣ **/
	private String sInsrdID;
	/** ������ȣ **/
	private String sPlateNo;
	/** ����ȣ **/
	private String sPolicyType;
	/** ����ȣ **/
	private String sPolicyYM;
	/** ����ȣ **/
	private String sPolicySer;
	/** ����ȣ(ȭ�� ǥ�ÿ�) **/
	private String policyNo;
	/** ����Ⱓ **/
	private String sFmdt;
	/** ����Ⱓ **/
	private String sTodt;
	/** ����Ⱓ(ȭ�� ǥ�ÿ�) **/
	private String period;
	/** ���Դ㺸 **/
	private String coverNM;
	/** ���Դ㺸 �ڵ� **/
	private String coverCodes;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ��� ���� **/
	private String sInsType;
	/** �����Ͻ� **/
	private String sRectTime;
	/** ����� �ڵ�����ȣ 1 **/
	private String sCellPhone1;
	/** ����� �ڵ�����ȣ 2 **/
	private String sCellPhone2;
	/** ����� �ڵ�����ȣ 3 **/
	private String sCellPhone3;
	
	/**
	 * @return the coverCodes
	 */
	public String getCoverCodes() {
		return coverCodes;
	}

	/**
	 * @param coverCodes the coverCodes to set
	 */
	public void setCoverCodes(String coverCodes) {
		this.coverCodes = coverCodes;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sRectTime
	 */
	public String getsRectTime() {
		return sRectTime;
	}

	/**
	 * @param sRectTime the sRectTime to set
	 */
	public void setsRectTime(String sRectTime) {
		this.sRectTime = sRectTime;
	}

	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}

	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(String sInsType) {
		this.sInsType = sInsType;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sPolicyType
	 */
	public String getsPolicyType() {
		return sPolicyType;
	}

	/**
	 * @param sPolicyType the sPolicyType to set
	 */
	public void setsPolicyType(final String sPolicyType) {
		this.sPolicyType = sPolicyType;
	}

	/**
	 * @return the sPolicyYM
	 */
	public String getsPolicyYM() {
		return sPolicyYM;
	}

	/**
	 * @param sPolicyYM the sPolicyYM to set
	 */
	public void setsPolicyYM(final String sPolicyYM) {
		this.sPolicyYM = sPolicyYM;
	}

	/**
	 * @return the sPolicySer
	 */
	public String getsPolicySer() {
		return sPolicySer;
	}

	/**
	 * @param sPolicySer the sPolicySer to set
	 */
	public void setsPolicySer(final String sPolicySer) {
		this.sPolicySer = sPolicySer;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(final String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(final String period) {
		this.period = period;
	}

	/**
	 * @return the coverNM
	 */
	public String getCoverNM() {
		return coverNM;
	}

	/**
	 * @param coverNM the coverNM to set
	 */
	public void setCoverNM(final String coverNM) {
		this.coverNM = coverNM;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

}
