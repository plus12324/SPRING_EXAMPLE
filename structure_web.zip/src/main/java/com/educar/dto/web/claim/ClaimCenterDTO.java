/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ������ �� ã�� ��� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "claimCenterDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimCenterDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;

	/** ������/�� �� (ȭ�鿡�����) **/
	private String sShortName;
	/** �ּ� sZip1+sZip2+sAddr1+sAddr2(ȭ�鿡�����) **/
	private String address;
	/** ��ȭ��ȣsTel1+sTel2+sTel3(ȭ�鿡�����) **/
	private String tel;
	/** �ѽ���ȣ sFax1+sFax2+sFax3 (ȭ�鿡�����) **/
	private String fax;
	/** daum map api ��ǥ x (ȭ�鿡�����)**/
	private String x;
	/** daum map api ��ǥ y (ȭ�鿡�����)**/
	private String y;
	/** �Ⱓ�� zip1 (ȭ��̻��) **/
	private String sZip1;
	/** �Ⱓ�� zip2 (ȭ��̻��) **/
	private String sZip2;
	/** �Ⱓ�� �ּ�1 (ȭ��̻��) **/
	private String sAddr1;
	/** �Ⱓ�� �ּ�2 (ȭ��̻��) **/
	private String sAddr2;
	/** �Ⱓ�� ��ȭ 1 (ȭ��̻��) **/
	private String sTel1;
	/** �Ⱓ�� ��ȭ 2 (ȭ��̻��) **/
	private String sTel2;
	/** �Ⱓ�� ��ȭ 3 (ȭ��̻��) **/
	private String sTel3;
	/** �Ⱓ�� �ѽ� 1 (ȭ��̻��) **/
	private String sFax1;
	/** �Ⱓ�� �ѽ� 2 (ȭ��̻��) **/
	private String sFax2;
	/** �Ⱓ�� �ѽ� 3 (ȭ��̻��) **/
	private String sFax3;

	/**
	 * @return the sShortName
	 */
	public String getsShortName() {
		return sShortName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}

	/**
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @return the sAddr1
	 */
	public String getsAddr1() {
		return sAddr1;
	}

	/**
	 * @return the sAddr2
	 */
	public String getsAddr2() {
		return sAddr2;
	}

	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}

	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}

	/**
	 * @return the sTel3
	 */
	public String getsTel3() {
		return sTel3;
	}

	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}

	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}

	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}

	/**
	 * @param sShortName the sShortName to set
	 */
	public void setsShortName(final String sShortName) {
		this.sShortName = sShortName;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @param tel the tel to set
	 */
	public void setTel(final String tel) {
		this.tel = tel;
	}

	/**
	 * @param fax the fax to set
	 */
	public void setFax(final String fax) {
		this.fax = fax;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @param sAddr1 the sAddr1 to set
	 */
	public void setsAddr1(final String sAddr1) {
		this.sAddr1 = sAddr1;
	}

	/**
	 * @param sAddr2 the sAddr2 to set
	 */
	public void setsAddr2(final String sAddr2) {
		this.sAddr2 = sAddr2;
	}

	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(final String sTel1) {
		this.sTel1 = sTel1;
	}

	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(final String sTel2) {
		this.sTel2 = sTel2;
	}

	/**
	 * @param sTel3 the sTel3 to set
	 */
	public void setsTel3(final String sTel3) {
		this.sTel3 = sTel3;
	}

	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(final String sFax1) {
		this.sFax1 = sFax1;
	}

	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(final String sFax2) {
		this.sFax2 = sFax2;
	}

	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(final String sFax3) {
		this.sFax3 = sFax3;
	}

	/**
	 * @return the x
	 */
	public String getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public void setX(final String x) {
		this.x = x;
	}

	/**
	 * @return the y
	 */
	public String getY() {
		return y;
	}

	/**
	 * @param y the y to set
	 */
	public void setY(final String y) {
		this.y = y;
	}
}
