/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ������� ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "acctRegiInfoOfBaseInfoDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AcctRegiInfoOfBaseInfoDTO {
	/** ����������� **/
	private String sFmdt;
	/** ������������ **/
	private String sTodt;
	/** ����ȣ **/
	private String sContractNo;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ������ ������ȣ1 **/
	private String sAcctZip1;
	/** ������ ������ȣ2 **/
	private String sAcctZip2;
	/** ������ �ּ�1 **/
	private String sAcctAddr1;
	/** ������ �ּ�2 **/
	private String sAcctAddr2;
	/** �뺸�� **/
	private String sInformerName;
	/** ������ȣ **/
	private String sCarKorName;
	/** �������̸� **/
	private String sDrvName;
	/** �����ڿͰ��� **/
	private String sDrvCode;
	/** �������� **/
	private String sLicenseKind;
	/** �������� **/
	private String sLicenseRegion;
	/** �����ȣ **/
	private String sLicenseNo;
	/** ����� **/
	private String sAcctDate;
	/** ����ð� **/
	private String sAcctTime;
	/** ������ �Ű����� **/
	private String sPoliceReportYn;
	/** �������̸� **/
	private String sPoliceName;
	/** ������ �ֹε�Ϲ�ȣ **/
	private String sDrvSocNo;
	/** �Ǻ����� **/
	private String sInsuredCode;
	/** �Ǻ����� �̸� **/
	private String sInsuredName;
	/** �������޴�����ȣ1 **/
	private String sDrvCelTel1;
	/** �������޴�����ȣ2 **/
	private String sDrvCelTel2;
	/** �������޴�����ȣ3 **/
	private String sDrvCelTel3;
	/** �Ǻ����� �޴����ȣ1 **/
	private String sInformerCelTel1;
	/** �Ǻ����� �޴����ȣ2 **/
	private String sInformerCelTel2;
	/** �Ǻ����� �޴����ȣ3 **/
	private String sInformerCelTel3;
	/** �Ǻ����� �޴����ȣ1 **/
	private String sInsuredCelTel1;
	/** �Ǻ����� �޴����ȣ2 **/
	private String sInsuredCelTel2;
	/** �Ǻ����� �޴����ȣ3 **/
	private String sInsuredCelTel3;
	/** ������� **/
	private String sAcctContents;
	/** ��Ÿ���� **/
	private String sAcctSpec;
	/** ������ **/	
	private String sRectDate;
	/** �����ð� **/	
	private String sRectTime;
	
	/** ������ �ֹε�Ϲ�ȣ1 **/
	@BeanUtil(ignore = true)
	private String sDrvSocNo1;
	/** ������ �ֹε�Ϲ�ȣ2 **/
	@BeanUtil(ignore = true)
	private String sDrvSocNo2;
	/** Ű���庸�� ��ȣȭ Key **/
	@BeanUtil(ignore = true)
	private String sHid_key_data;
	
	//N1401-00089 ���θ��ּ� �߰�
	/** ���λ����ּ� **/
	private String sDoroAddr1;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	/** ǥ���ּ���ȯ���� */
	private String sStdAddrFlag;
	
	public String getsRectDate() {
		return sRectDate;
	}

	public void setsRectDate(String sRectDate) {
		this.sRectDate = sRectDate;
	}

	public String getsRectTime() {
		return sRectTime;
	}

	public void setsRectTime(String sRectTime) {
		this.sRectTime = sRectTime;
	}

	/**
	 * @return the sInsuredCelTel1
	 */
	public String getsInsuredCelTel1() {
		return sInsuredCelTel1;
	}

	/**
	 * @param sInsuredCelTel1 the sInsuredCelTel1 to set
	 */
	public void setsInsuredCelTel1(String sInsuredCelTel1) {
		this.sInsuredCelTel1 = sInsuredCelTel1;
	}

	/**
	 * @return the sInsuredCelTel2
	 */
	public String getsInsuredCelTel2() {
		return sInsuredCelTel2;
	}

	/**
	 * @param sInsuredCelTel2 the sInsuredCelTel2 to set
	 */
	public void setsInsuredCelTel2(String sInsuredCelTel2) {
		this.sInsuredCelTel2 = sInsuredCelTel2;
	}

	/**
	 * @return the sInsuredCelTel3
	 */
	public String getsInsuredCelTel3() {
		return sInsuredCelTel3;
	}

	/**
	 * @param sInsuredCelTel3 the sInsuredCelTel3 to set
	 */
	public void setsInsuredCelTel3(String sInsuredCelTel3) {
		this.sInsuredCelTel3 = sInsuredCelTel3;
	}

	/**
	 * @return the sAcctSpec
	 */
	public String getsAcctSpec() {
		return sAcctSpec;
	}

	/**
	 * @param sAcctSpec the sAcctSpec to set
	 */
	public void setsAcctSpec(String sAcctSpec) {
		this.sAcctSpec = sAcctSpec;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sContractNo
	 */
	public String getsContractNo() {
		return sContractNo;
	}

	/**
	 * @param sContractNo the sContractNo to set
	 */
	public void setsContractNo(final String sContractNo) {
		this.sContractNo = sContractNo;
	}

	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sAcctZip1
	 */
	public String getsAcctZip1() {
		return sAcctZip1;
	}

	/**
	 * @param sAcctZip1 the sAcctZip1 to set
	 */
	public void setsAcctZip1(final String sAcctZip1) {
		this.sAcctZip1 = sAcctZip1;
	}

	/**
	 * @return the sAcctZip2
	 */
	public String getsAcctZip2() {
		return sAcctZip2;
	}

	/**
	 * @param sAcctZip2 the sAcctZip2 to set
	 */
	public void setsAcctZip2(final String sAcctZip2) {
		this.sAcctZip2 = sAcctZip2;
	}

	/**
	 * @return the sAcctAddr1
	 */
	public String getsAcctAddr1() {
		return sAcctAddr1;
	}

	/**
	 * @param sAcctAddr1 the sAcctAddr1 to set
	 */
	public void setsAcctAddr1(final String sAcctAddr1) {
		this.sAcctAddr1 = sAcctAddr1;
	}

	/**
	 * @return the sAcctAddr2
	 */
	public String getsAcctAddr2() {
		return sAcctAddr2;
	}

	/**
	 * @param sAcctAddr2 the sAcctAddr2 to set
	 */
	public void setsAcctAddr2(final String sAcctAddr2) {
		this.sAcctAddr2 = sAcctAddr2;
	}

	/**
	 * @return the sInformerName
	 */
	public String getsInformerName() {
		return sInformerName;
	}

	/**
	 * @param sInformerName the sInformerName to set
	 */
	public void setsInformerName(final String sInformerName) {
		this.sInformerName = sInformerName;
	}

	/**
	 * @return the sCarKorName
	 */
	public String getsCarKorName() {
		return sCarKorName;
	}

	/**
	 * @param sCarKorName the sCarKorName to set
	 */
	public void setsCarKorName(final String sCarKorName) {
		this.sCarKorName = sCarKorName;
	}

	/**
	 * @return the sDrvName
	 */
	public String getsDrvName() {
		return sDrvName;
	}

	/**
	 * @param sDrvName the sDrvName to set
	 */
	public void setsDrvName(final String sDrvName) {
		this.sDrvName = sDrvName;
	}

	/**
	 * @return the sDrvCode
	 */
	public String getsDrvCode() {
		return sDrvCode;
	}

	/**
	 * @param sDrvCode the sDrvCode to set
	 */
	public void setsDrvCode(final String sDrvCode) {
		this.sDrvCode = sDrvCode;
	}

	/**
	 * @return the sLicenseKind
	 */
	public String getsLicenseKind() {
		return sLicenseKind;
	}

	/**
	 * @param sLicenseKind the sLicenseKind to set
	 */
	public void setsLicenseKind(final String sLicenseKind) {
		this.sLicenseKind = sLicenseKind;
	}

	/**
	 * @return the sLicenseRegion
	 */
	public String getsLicenseRegion() {
		return sLicenseRegion;
	}

	/**
	 * @param sLicenseRegion the sLicenseRegion to set
	 */
	public void setsLicenseRegion(final String sLicenseRegion) {
		this.sLicenseRegion = sLicenseRegion;
	}

	/**
	 * @return the sLicenseNo
	 */
	public String getsLicenseNo() {
		return sLicenseNo;
	}

	/**
	 * @param sLicenseNo the sLicenseNo to set
	 */
	public void setsLicenseNo(final String sLicenseNo) {
		this.sLicenseNo = sLicenseNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctTime
	 */
	public String getsAcctTime() {
		return sAcctTime;
	}

	/**
	 * @param sAcctTime the sAcctTime to set
	 */
	public void setsAcctTime(final String sAcctTime) {
		this.sAcctTime = sAcctTime;
	}

	/**
	 * @return the sPoliceReportYn
	 */
	public String getsPoliceReportYn() {
		return sPoliceReportYn;
	}

	/**
	 * @param sPoliceReportYn the sPoliceReportYn to set
	 */
	public void setsPoliceReportYn(final String sPoliceReportYn) {
		this.sPoliceReportYn = sPoliceReportYn;
	}

	/**
	 * @return the sPoliceName
	 */
	public String getsPoliceName() {
		return sPoliceName;
	}

	/**
	 * @param sPoliceName the sPoliceName to set
	 */
	public void setsPoliceName(final String sPoliceName) {
		this.sPoliceName = sPoliceName;
	}

	/**
	 * @return the sDrvSocNo
	 */
	public String getsDrvSocNo() {
		return sDrvSocNo;
	}

	/**
	 * @param sDrvSocNo the sDrvSocNo to set
	 */
	public void setsDrvSocNo(final String sDrvSocNo) {
		this.sDrvSocNo = sDrvSocNo;
	}

	/**
	 * @return the sInsuredCode
	 */
	public String getsInsuredCode() {
		return sInsuredCode;
	}

	/**
	 * @param sInsuredCode the sInsuredCode to set
	 */
	public void setsInsuredCode(final String sInsuredCode) {
		this.sInsuredCode = sInsuredCode;
	}

	/**
	 * @return the sInsuredName
	 */
	public String getsInsuredName() {
		return sInsuredName;
	}

	/**
	 * @param sInsuredName the sInsuredName to set
	 */
	public void setsInsuredName(final String sInsuredName) {
		this.sInsuredName = sInsuredName;
	}

	/**
	 * @return the sDrvCelTel1
	 */
	public String getsDrvCelTel1() {
		return sDrvCelTel1;
	}

	/**
	 * @param sDrvCelTel1 the sDrvCelTel1 to set
	 */
	public void setsDrvCelTel1(final String sDrvCelTel1) {
		this.sDrvCelTel1 = sDrvCelTel1;
	}

	/**
	 * @return the sDrvCelTel2
	 */
	public String getsDrvCelTel2() {
		return sDrvCelTel2;
	}

	/**
	 * @param sDrvCelTel2 the sDrvCelTel2 to set
	 */
	public void setsDrvCelTel2(final String sDrvCelTel2) {
		this.sDrvCelTel2 = sDrvCelTel2;
	}

	/**
	 * @return the sDrvCelTel3
	 */
	public String getsDrvCelTel3() {
		return sDrvCelTel3;
	}

	/**
	 * @param sDrvCelTel3 the sDrvCelTel3 to set
	 */
	public void setsDrvCelTel3(final String sDrvCelTel3) {
		this.sDrvCelTel3 = sDrvCelTel3;
	}

	/**
	 * @return the sInformerCelTel1
	 */
	public String getsInformerCelTel1() {
		return sInformerCelTel1;
	}

	/**
	 * @param sInformerCelTel1 the sInformerCelTel1 to set
	 */
	public void setsInformerCelTel1(final String sInformerCelTel1) {
		this.sInformerCelTel1 = sInformerCelTel1;
	}

	/**
	 * @return the sInformerCelTel2
	 */
	public String getsInformerCelTel2() {
		return sInformerCelTel2;
	}

	/**
	 * @param sInformerCelTel2 the sInformerCelTel2 to set
	 */
	public void setsInformerCelTel2(final String sInformerCelTel2) {
		this.sInformerCelTel2 = sInformerCelTel2;
	}

	/**
	 * @return the sInformerCelTel3
	 */
	public String getsInformerCelTel3() {
		return sInformerCelTel3;
	}

	/**
	 * @param sInformerCelTel3 the sInformerCelTel3 to set
	 */
	public void setsInformerCelTel3(final String sInformerCelTel3) {
		this.sInformerCelTel3 = sInformerCelTel3;
	}

	/**
	 * @return the sAcctContents
	 */
	public String getsAcctContents() {
		return sAcctContents;
	}

	/**
	 * @param sAcctContents the sAcctContents to set
	 */
	public void setsAcctContents(final String sAcctContents) {
		this.sAcctContents = sAcctContents;
	}

	/**
	 * @return the sDrvSocNo1
	 */
	public String getsDrvSocNo1() {
		return sDrvSocNo1;
	}

	/**
	 * @param sDrvSocNo1 the sDrvSocNo1 to set
	 */
	public void setsDrvSocNo1(String sDrvSocNo1) {
		this.sDrvSocNo1 = sDrvSocNo1;
	}

	/**
	 * @return the sDrvSocNo2
	 */
	public String getsDrvSocNo2() {
		return sDrvSocNo2;
	}

	/**
	 * @param sDrvSocNo2 the sDrvSocNo2 to set
	 */
	public void setsDrvSocNo2(String sDrvSocNo2) {
		this.sDrvSocNo2 = sDrvSocNo2;
	}

	/**
	 * @return the sHid_key_data
	 */
	public String getsHid_key_data() {
		return sHid_key_data;
	}

	/**
	 * @param sHid_key_data the sHid_key_data to set
	 */
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}

	/**
	 * @return the sDoroAddr1
	 */
	public String getsDoroAddr1() {
		return sDoroAddr1;
	}

	/**
	 * @param sDoroAddr1 the sDoroAddr1 to set
	 */
	public void setsDoroAddr1(String sDoroAddr1) {
		this.sDoroAddr1 = sDoroAddr1;
	}

	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}

	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}

	/**
	 * @return the sStdAddrFlag
	 */
	public String getsStdAddrFlag() {
		return sStdAddrFlag;
	}

	/**
	 * @param sStdAddrFlag the sStdAddrFlag to set
	 */
	public void setsStdAddrFlag(String sStdAddrFlag) {
		this.sStdAddrFlag = sStdAddrFlag;
	}

}
