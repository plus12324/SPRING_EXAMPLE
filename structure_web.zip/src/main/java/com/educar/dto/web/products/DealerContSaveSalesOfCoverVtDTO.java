/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� �⺻���� �Է� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerContSaveSalesOfCoverVtDTO")
public class DealerContSaveSalesOfCoverVtDTO {
	/** �㺸�ڵ� **/
	private String sCover;
	/** �㺸�� **/
	private String sCoverTitle;
	/** ���Աݾ��ڵ� **/
	private String sCoverOpt;
	/** ���Աݾ� **/
	private String sCoverOptAmt;
	/** ���Աݾ���� **/
	private String sCoverOptDisplay;
	/** ���뺸��� **/
	private String nCoverPrem;

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the sCoverTitle
	 */
	public String getsCoverTitle() {
		return sCoverTitle;
	}

	/**
	 * @param sCoverTitle the sCoverTitle to set
	 */
	public void setsCoverTitle(final String sCoverTitle) {
		this.sCoverTitle = sCoverTitle;
	}

	/**
	 * @return the sCoverOpt
	 */
	public String getsCoverOpt() {
		return sCoverOpt;
	}

	/**
	 * @param sCoverOpt the sCoverOpt to set
	 */
	public void setsCoverOpt(final String sCoverOpt) {
		this.sCoverOpt = sCoverOpt;
	}

	/**
	 * @return the sCoverOptAmt
	 */
	public String getsCoverOptAmt() {
		return sCoverOptAmt;
	}

	/**
	 * @param sCoverOptAmt the sCoverOptAmt to set
	 */
	public void setsCoverOptAmt(final String sCoverOptAmt) {
		this.sCoverOptAmt = sCoverOptAmt;
	}

	/**
	 * @return the sCoverOptDisplay
	 */
	public String getsCoverOptDisplay() {
		return sCoverOptDisplay;
	}

	/**
	 * @param sCoverOptDisplay the sCoverOptDisplay to set
	 */
	public void setsCoverOptDisplay(final String sCoverOptDisplay) {
		this.sCoverOptDisplay = sCoverOptDisplay;
	}

	/**
	 * @return the nCoverPrem
	 */
	public String getnCoverPrem() {
		return nCoverPrem;
	}

	/**
	 * @param nCoverPrem the nCoverPrem to set
	 */
	public void setnCoverPrem(final String nCoverPrem) {
		this.nCoverPrem = nCoverPrem;
	}

}
