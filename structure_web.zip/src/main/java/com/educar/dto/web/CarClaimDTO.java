/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ó�� ��Ȳ ��ȸ �ڵ������� ������ȲDTO
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carClaimDTO")
public class CarClaimDTO {
	/** ������ȣ **/
	private String sAccidentNo;
	/** �㺸 **/
	private String sHndCover;
	/** �㺸�� **/
	private String sHndCoverName;
	/** ���� **/
	private String sDmgeNo;
	/** ������ **/
	private String sAcctPlace;
	/** �����ڸ�/���ع��� **/
	private String sVictimName;
	/** �ֹε�Ϲ�ȣ **/
	private String sVictimSocNo;
	/** �뺸�� **/
	private String sInformerName;
	/** ������� **/
	private String sAcctDate;
	/** ����ð� **/
	private String sAcctTime;
	/** �����Ͻ� **/
	private String sAcctRegiDate;
	/** ������� **/
	private String sAcctStatus;

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sAcctPlace
	 */
	public String getsAcctPlace() {
		return sAcctPlace;
	}

	/**
	 * @param sAcctPlace the sAcctPlace to set
	 */
	public void setsAcctPlace(final String sAcctPlace) {
		this.sAcctPlace = sAcctPlace;
	}

	/**
	 * @return the sInformerName
	 */
	public String getsInformerName() {
		return sInformerName;
	}

	/**
	 * @param sInformerName the sInformerName to set
	 */
	public void setsInformerName(final String sInformerName) {
		this.sInformerName = sInformerName;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctTime
	 */
	public String getsAcctTime() {
		return sAcctTime;
	}

	/**
	 * @param sAcctTime the sAcctTime to set
	 */
	public void setsAcctTime(final String sAcctTime) {
		this.sAcctTime = sAcctTime;
	}

	/**
	 * @return the sAcctRegiDate
	 */
	public String getsAcctRegiDate() {
		return sAcctRegiDate;
	}

	/**
	 * @param sAcctRegiDate the sAcctRegiDate to set
	 */
	public void setsAcctRegiDate(final String sAcctRegiDate) {
		this.sAcctRegiDate = sAcctRegiDate;
	}

	/**
	 * @return the sAcctStatus
	 */
	public String getsAcctStatus() {
		return this.sAcctStatus;
	}

	/**
	 * @param sAcctStatus the sAcctStatus to set
	 */
	public void setsAcctStatus(final String sAcctStatus) {
		this.sAcctStatus = sAcctStatus;
	}

	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}

	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(final String sHndCover) {
		this.sHndCover = sHndCover;
	}

	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}

	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(final String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}

	/**
	 * @return the sVictimName
	 */
	public String getsVictimName() {
		return sVictimName;
	}

	/**
	 * @param sVictimName the sVictimName to set
	 */
	public void setsVictimName(final String sVictimName) {
		this.sVictimName = sVictimName;
	}

	/**
	 * @return the sVictimSocNo
	 */
	public String getsVictimSocNo() {
		return sVictimSocNo;
	}

	/**
	 * @param sVictimSocNo the sVictimSocNo to set
	 */
	public void setsVictimSocNo(final String sVictimSocNo) {
		this.sVictimSocNo = sVictimSocNo;
	}

	/**
	 * @return the sHndCoverName
	 */
	public String getsHndCoverName() {
		return sHndCoverName;
	}

	/**
	 * @param sHndCoverName the sHndCoverName to set
	 */
	public void setsHndCoverName(String sHndCoverName) {
		this.sHndCoverName = sHndCoverName;
	}

}
