/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.main;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

/**
 * �����ǰ ���θ޴� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "insuranceProductMainMenuDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsuranceProductMainMenuDTO implements Serializable {
	/**
	 * default
	 */
	private static final long serialVersionUID = 1L;
	/** �Ϸù�ȣ **/
	private long nSeq;
	/** �޴����� (A=��õ��ǰ,B=�űԻ�ǰ) **/
	private String sMenuType;
	/** �󼼺��� forward URL **/
	private String sForwardDetailURL;
	/** ������� forward URL **/
	private String sForwardCalcURL;
	/** ���Թ��/���� forward URL **/
	private String sForwardRegiURL;
	/** ����� ��ȸ/û�� forward URL **/
	private String sForwardOfferURL;
	/** �����˾ƺ���  **/
	private String sForwardSearchURL;
	/** �̹��� ������ URL **/
	private String sImageThumbLinkURL;
	/** �̹��� URL **/
	private String sImageLinkURL;
	/** �޴� �ؽ�Ʈ **/
	private String sText;
	/** �޴� �޽��� **/
	private String sMessage;
	/** �޴� ���� **/
	private String nOrder;
	/** �������� **/
	private String sViewYn;
	/** ������¥ **/
	private String sOpenDate;
	/** ������ **/
	private String sRegId;
	/** ������¥ **/
	private String sRegDate;
	/** �����ð� **/
	private String sRegTime;
	/** ������ **/
	private String sUpId;
	/** ������¥ **/
	private String sUpDate;
	/** �����ð� **/
	private String sUpTime;

	/** �����ǰ ���θ޴� ����Ʈ(�����ڿ��� ���) **/
	@XmlTransient
	private List<InsuranceProductMainMenuDTO> productMainMenuList;
	/** üũ�� (�����ڿ��� ������ ���) **/
	@XmlTransient
	private String checkValue;
	/** ī�װ���(�����ڿ��� ���) **/
	@XmlTransient
	private String sCategory;
	/** �⺻ �̹��� ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile sThumbImageFile;
	/** Ȯ�� �̹��� ����(�����ڿ��� ��Ͻ� ���) **/
	@XmlTransient
	private MultipartFile sImageFile;

	/**
	 * @return the nSeq
	 */
	public long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sMenuType
	 */
	public String getsMenuType() {
		return sMenuType;
	}

	/**
	 * @param sMenuType the sMenuType to set
	 */
	public void setsMenuType(final String sMenuType) {
		this.sMenuType = sMenuType;
	}

	/**
	 * @return the sForwardDetailURL
	 */
	public String getsForwardDetailURL() {
		return sForwardDetailURL;
	}

	/**
	 * @param sForwardDetailURL the sForwardDetailURL to set
	 */
	public void setsForwardDetailURL(final String sForwardDetailURL) {
		this.sForwardDetailURL = sForwardDetailURL;
	}

	/**
	 * @return the sForwardCalcURL
	 */
	public String getsForwardCalcURL() {
		return sForwardCalcURL;
	}

	/**
	 * @param sForwardCalcURL the sForwardCalcURL to set
	 */
	public void setsForwardCalcURL(final String sForwardCalcURL) {
		this.sForwardCalcURL = sForwardCalcURL;
	}

	/**
	 * @return the sForwardRegiURL
	 */
	public String getsForwardRegiURL() {
		return sForwardRegiURL;
	}

	/**
	 * @param sForwardRegiURL the sForwardRegiURL to set
	 */
	public void setsForwardRegiURL(final String sForwardRegiURL) {
		this.sForwardRegiURL = sForwardRegiURL;
	}

	/**
	 * @return the sForwardOfferURL
	 */
	public String getsForwardOfferURL() {
		return sForwardOfferURL;
	}

	/**
	 * @param sForwardOfferURL the sForwardOfferURL to set
	 */
	public void setsForwardOfferURL(final String sForwardOfferURL) {
		this.sForwardOfferURL = sForwardOfferURL;
	}

	/**
	 * @return the sForwardSearchURL
	 */
	public String getsForwardSearchURL() {
		return sForwardSearchURL;
	}

	/**
	 * @param sForwardSearchURL the sForwardSearchURL to set
	 */
	public void setsForwardSearchURL(final String sForwardSearchURL) {
		this.sForwardSearchURL = sForwardSearchURL;
	}

	/**
	 * @return the sImageThumbLinkURL
	 */
	public String getsImageThumbLinkURL() {
		return sImageThumbLinkURL;
	}

	/**
	 * @param sImageThumbLinkURL the sImageThumbLinkURL to set
	 */
	public void setsImageThumbLinkURL(final String sImageThumbLinkURL) {
		this.sImageThumbLinkURL = sImageThumbLinkURL;
	}

	/**
	 * @return the sImageLinkURL
	 */
	public String getsImageLinkURL() {
		return sImageLinkURL;
	}

	/**
	 * @param sImageLinkURL the sImageLinkURL to set
	 */
	public void setsImageLinkURL(final String sImageLinkURL) {
		this.sImageLinkURL = sImageLinkURL;
	}

	/**
	 * @return the sText
	 */
	public String getsText() {
		return sText;
	}

	/**
	 * @param sText the sText to set
	 */
	public void setsText(final String sText) {
		this.sText = sText;
	}

	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}

	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(final String sMessage) {
		this.sMessage = sMessage;
	}

	/**
	 * @return the nOrder
	 */
	public String getnOrder() {
		return nOrder;
	}

	/**
	 * @param nOrder the nOrder to set
	 */
	public void setnOrder(final String nOrder) {
		this.nOrder = nOrder;
	}

	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}

	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(final String sViewYn) {
		this.sViewYn = sViewYn;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}

	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(final String sRegId) {
		this.sRegId = sRegId;
	}

	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}

	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(final String sRegDate) {
		this.sRegDate = sRegDate;
	}

	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}

	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(final String sRegTime) {
		this.sRegTime = sRegTime;
	}

	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}

	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(final String sUpId) {
		this.sUpId = sUpId;
	}

	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}

	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(final String sUpDate) {
		this.sUpDate = sUpDate;
	}

	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}

	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(final String sUpTime) {
		this.sUpTime = sUpTime;
	}

	/**
	 * @return the productMainMenuList
	 */
	public List<InsuranceProductMainMenuDTO> getProductMainMenuList() {
		return productMainMenuList;
	}

	/**
	 * @param productMainMenuList the productMainMenuList to set
	 */
	public void setProductMainMenuList(final List<InsuranceProductMainMenuDTO> productMainMenuList) {
		this.productMainMenuList = productMainMenuList;
	}

	/**
	 * @return the checkValue
	 */
	public String getCheckValue() {
		return checkValue;
	}

	/**
	 * @param checkValue the checkValue to set
	 */
	public void setCheckValue(final String checkValue) {
		this.checkValue = checkValue;
	}

	/**
	 * @return the sCategory
	 */
	public String getsCategory() {
		return sCategory;
	}

	/**
	 * @param sCategory the sCategory to set
	 */
	public void setsCategory(final String sCategory) {
		this.sCategory = sCategory;
	}

	/**
	 * @return the sThumbImageFile
	 */
	public MultipartFile getsThumbImageFile() {
		return sThumbImageFile;
	}

	/**
	 * @param sThumbImageFile the sThumbImageFile to set
	 */
	public void setsThumbImageFile(final MultipartFile sThumbImageFile) {
		this.sThumbImageFile = sThumbImageFile;
	}

	/**
	 * @return the sImageFile
	 */
	public MultipartFile getsImageFile() {
		return sImageFile;
	}

	/**
	 * @param sImageFile the sImageFile to set
	 */
	public void setsImageFile(final MultipartFile sImageFile) {
		this.sImageFile = sImageFile;
	}

}
