/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ������� ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "acctRegiInfoSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AcctRegiInfoSearchDTO {
	/** baseInfo **/
	private AcctRegiInfoOfBaseInfoDTO baseInfo;
	/** �㺸 **/
	@XmlElementWrapper(name = "victimInfoList")
	private List<AcctRegiInfoOfVictimInfoDTO> victimInfo;

	/** ����ID **/
	@BeanUtil(ignore = true)
	private String fileID;

	/**
	 * @return the baseInfo
	 */
	public AcctRegiInfoOfBaseInfoDTO getBaseInfo() {
		return baseInfo;
	}

	/**
	 * @param baseInfo the baseInfo to set
	 */
	public void setBaseInfo(final AcctRegiInfoOfBaseInfoDTO baseInfo) {
		this.baseInfo = baseInfo;
	}

	/**
	 * @return the victimInfo
	 */
	public List<AcctRegiInfoOfVictimInfoDTO> getVictimInfo() {
		return victimInfo;
	}

	/**
	 * @param victimInfo the victimInfo to set
	 */
	public void setVictimInfo(final List<AcctRegiInfoOfVictimInfoDTO> victimInfo) {
		this.victimInfo = victimInfo;
	}

	/**
	 * @return the fileID
	 */
	public String getFileID() {
		return fileID;
	}

	/**
	 * @param fileID the fileID to set
	 */
	public void setFileID(final String fileID) {
		this.fileID = fileID;
	}

}
