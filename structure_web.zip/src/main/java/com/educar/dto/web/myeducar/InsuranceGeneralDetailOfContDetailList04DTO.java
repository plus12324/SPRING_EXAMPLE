/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ����ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDetailOfContDetailList04DTO")
public class InsuranceGeneralDetailOfContDetailList04DTO {
	/**
	 * <pre>
	 * ����
	 * 01-���� �Ǻ�����  �ּ�                
	 * 02-���� ����� �ּ�                   
	 * 03-�Ǻ����� ���� �ּ�(����,����,��Ÿ)   
	 * 04-����� ���� �ּ�(����,����,��Ÿ) 
	 * </pre>
	 **/
	private String sDiv;
	/** �߼������� (1 - ����, 2 - ����, 3 - ��Ÿ) **/
	private String sSendType;
	/** ������ȣ **/
	private String sZipCode;
	/** �⺻�ּ�(����) **/
	private String sAddr;
	/** ���ּ�(����) **/
	private String sAddrDetail;
	/** �⺻�ּ�1 **/
	private String sAdrs1;
	/** �⺻�ּ�2 **/
	private String sAdrs2;
	/** �⺻�ּ�3 **/
	private String sAdrs3;
	/** ���ּ�1 **/
	private String sAdrs4;
	/** ���ּ�2 **/
	private String sAdrs5;

	/**
	 * @return the sDiv
	 */
	public String getsDiv() {
		return sDiv;
	}

	/**
	 * @param sDiv the sDiv to set
	 */
	public void setsDiv(final String sDiv) {
		this.sDiv = sDiv;
	}

	/**
	 * @return the sSendType
	 */
	public String getsSendType() {
		return sSendType;
	}

	/**
	 * @param sSendType the sSendType to set
	 */
	public void setsSendType(final String sSendType) {
		this.sSendType = sSendType;
	}

	/**
	 * @return the sZipCode
	 */
	public String getsZipCode() {
		return sZipCode;
	}

	/**
	 * @param sZipCode the sZipCode to set
	 */
	public void setsZipCode(final String sZipCode) {
		this.sZipCode = sZipCode;
	}

	/**
	 * @return the sAddr
	 */
	public String getsAddr() {
		return sAddr;
	}

	/**
	 * @param sAddr the sAddr to set
	 */
	public void setsAddr(final String sAddr) {
		this.sAddr = sAddr;
	}

	/**
	 * @return the sAddrDetail
	 */
	public String getsAddrDetail() {
		return sAddrDetail;
	}

	/**
	 * @param sAddrDetail the sAddrDetail to set
	 */
	public void setsAddrDetail(final String sAddrDetail) {
		this.sAddrDetail = sAddrDetail;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sAdrs4
	 */
	public String getsAdrs4() {
		return sAdrs4;
	}

	/**
	 * @param sAdrs4 the sAdrs4 to set
	 */
	public void setsAdrs4(final String sAdrs4) {
		this.sAdrs4 = sAdrs4;
	}

	/**
	 * @return the sAdrs5
	 */
	public String getsAdrs5() {
		return sAdrs5;
	}

	/**
	 * @param sAdrs5 the sAdrs5 to set
	 */
	public void setsAdrs5(final String sAdrs5) {
		this.sAdrs5 = sAdrs5;
	}

}
