/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * �������� ��Ź���� ��ȸ  DTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "personalInfoConsignDTO")
public class PersonalInfoConsignDTO{

	/** 	������ȣ	**/ 
	private String 	sCustNo;
	/** 	������	**/ 
	private String 	sAgmDt;
	/** 	��������	**/ 
	private String 	parmBaseDt;
	/** 	�븮��	**/ 
	private String 	sAgency;
	/** 	�븮�� ��������	**/ 
	private String 	sAgencyFdt;
	/** 	�븮�� ��������	**/ 
	private String 	sAgencyTdt;
	/** 	�����	**/ 
	private String 	sPlanner;
	/** 	����� ��������	**/ 
	private String 	sPlannerFdt;
	/** 	����� ��������	**/ 
	private String 	sPlannerTdt;
	/** 	��Źó	**/ 
	private String 	sTrust	;
	/** 	��Źó ��������	**/ 
	private String 	sTrustFdt	;
	/** 	��Źó ��������	**/ 
	private String 	sTrustTdt	;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sAgmDt
	 */
	public String getsAgmDt() {
		return sAgmDt;
	}
	/**
	 * @param sAgmDt the sAgmDt to set
	 */
	public void setsAgmDt(String sAgmDt) {
		this.sAgmDt = sAgmDt;
	}
	/**
	 * @return the parmBaseDt
	 */
	public String getParmBaseDt() {
		return parmBaseDt;
	}
	/**
	 * @param parmBaseDt the parmBaseDt to set
	 */
	public void setParmBaseDt(String parmBaseDt) {
		this.parmBaseDt = parmBaseDt;
	}
	/**
	 * @return the sAgency
	 */
	public String getsAgency() {
		return sAgency;
	}
	/**
	 * @param sAgency the sAgency to set
	 */
	public void setsAgency(String sAgency) {
		this.sAgency = sAgency;
	}
	/**
	 * @return the sAgencyFdt
	 */
	public String getsAgencyFdt() {
		return sAgencyFdt;
	}
	/**
	 * @param sAgencyFdt the sAgencyFdt to set
	 */
	public void setsAgencyFdt(String sAgencyFdt) {
		this.sAgencyFdt = sAgencyFdt;
	}
	/**
	 * @return the sAgencyTdt
	 */
	public String getsAgencyTdt() {
		return sAgencyTdt;
	}
	/**
	 * @param sAgencyTdt the sAgencyTdt to set
	 */
	public void setsAgencyTdt(String sAgencyTdt) {
		this.sAgencyTdt = sAgencyTdt;
	}
	/**
	 * @return the sPlanner
	 */
	public String getsPlanner() {
		return sPlanner;
	}
	/**
	 * @param sPlanner the sPlanner to set
	 */
	public void setsPlanner(String sPlanner) {
		this.sPlanner = sPlanner;
	}
	/**
	 * @return the sPlannerFdt
	 */
	public String getsPlannerFdt() {
		return sPlannerFdt;
	}
	/**
	 * @param sPlannerFdt the sPlannerFdt to set
	 */
	public void setsPlannerFdt(String sPlannerFdt) {
		this.sPlannerFdt = sPlannerFdt;
	}
	/**
	 * @return the sPlannerTdt
	 */
	public String getsPlannerTdt() {
		return sPlannerTdt;
	}
	/**
	 * @param sPlannerTdt the sPlannerTdt to set
	 */
	public void setsPlannerTdt(String sPlannerTdt) {
		this.sPlannerTdt = sPlannerTdt;
	}
	/**
	 * @return the sTrust
	 */
	public String getsTrust() {
		return sTrust;
	}
	/**
	 * @param sTrust the sTrust to set
	 */
	public void setsTrust(String sTrust) {
		this.sTrust = sTrust;
	}
	/**
	 * @return the sTrustFdt
	 */
	public String getsTrustFdt() {
		return sTrustFdt;
	}
	/**
	 * @param sTrustFdt the sTrustFdt to set
	 */
	public void setsTrustFdt(String sTrustFdt) {
		this.sTrustFdt = sTrustFdt;
	}
	/**
	 * @return the sTrustTdt
	 */
	public String getsTrustTdt() {
		return sTrustTdt;
	}
	/**
	 * @param sTrustTdt the sTrustTdt to set
	 */
	public void setsTrustTdt(String sTrustTdt) {
		this.sTrustTdt = sTrustTdt;
	}
	
}
