/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ���θ� ��ȸ ��� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlRootElement(name = "claimRoadNameAddressResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimRoadNameAddressResultDTO {
	/** ������ȣ 1 **/
	private String sRealZip1;
	/** ������ȣ 2 **/
	private String sRealZip2;
	/** ������ȣ(ȭ��ǥ�ÿ�) **/
	private String zip;
	/** ���θ� �ּ� **/
	private String sAdrs1;
	/** ���θ� �ּ� **/
	private String sAdrs2;
	/** ���θ� �ּ� **/
	private String sAdrs3;
	/** ���θ� �ּ� **/
	private String sRoadName;
	/** �ּ�(ȭ��ǥ�ÿ�) **/
	private String address;
	/** �ǹ���ȣ(�ǹ���) **/
	private String nBuildingMainNo;
	/** �ǹ���ȣ(�ǹ���) **/
	private String nBuildingSubNo;
	/** �ǹ���ȣ(�ǹ���) **/
	private String sBuildingName;

	/**
	 * @return the sRealZip1
	 */
	public String getsRealZip1() {
		return sRealZip1;
	}

	/**
	 * @param sRealZip1 the sRealZip1 to set
	 */
	public void setsRealZip1(final String sRealZip1) {
		this.sRealZip1 = sRealZip1;
	}

	/**
	 * @return the sRealZip2
	 */
	public String getsRealZip2() {
		return sRealZip2;
	}

	/**
	 * @param sRealZip2 the sRealZip2 to set
	 */
	public void setsRealZip2(final String sRealZip2) {
		this.sRealZip2 = sRealZip2;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(final String zip) {
		this.zip = zip;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sRoadName
	 */
	public String getsRoadName() {
		return sRoadName;
	}

	/**
	 * @param sRoadName the sRoadName to set
	 */
	public void setsRoadName(final String sRoadName) {
		this.sRoadName = sRoadName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @return the nBuildingMainNo
	 */
	public String getnBuildingMainNo() {
		return nBuildingMainNo;
	}

	/**
	 * @param nBuildingMainNo the nBuildingMainNo to set
	 */
	public void setnBuildingMainNo(final String nBuildingMainNo) {
		this.nBuildingMainNo = nBuildingMainNo;
	}

	/**
	 * @return the nBuildingSubNo
	 */
	public String getnBuildingSubNo() {
		return nBuildingSubNo;
	}

	/**
	 * @param nBuildingSubNo the nBuildingSubNo to set
	 */
	public void setnBuildingSubNo(final String nBuildingSubNo) {
		this.nBuildingSubNo = nBuildingSubNo;
	}

	/**
	 * @return the sBuildingName
	 */
	public String getsBuildingName() {
		return sBuildingName;
	}

	/**
	 * @param sBuildingName the sBuildingName to set
	 */
	public void setsBuildingName(final String sBuildingName) {
		this.sBuildingName = sBuildingName;
	}

}
