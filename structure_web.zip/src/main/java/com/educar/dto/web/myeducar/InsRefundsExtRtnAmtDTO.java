/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����/���� ȯ�ޱ���ȸ - ����/���� ȯ�ޱݻ��⳻��
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insRefundsExtRtnAmtDTO")
public class InsRefundsExtRtnAmtDTO {
	/** 	����ȣ	**/ 
	private String	sCrNo;
	/** 	������	**/ 
	private String	sStndDate;
	/** 	����ȯ����	**/ 
	private String	sExptRtnDate;
	/** 	��ȸ����	**/ 
	private String	sInqrUnit;
	/** 	ȯ����	**/ 
	private String	nExptRato;
	/** 	����ȯ�ް��ȸ��	**/ 
	private String	nIdx;
	/** 	ȸ��	**/ 
	private String	nSeq;
	/** 	���޿�������	**/ 
	private String	sPymExptDate;
	/** 	����Ⱓ	**/ 
	private String	sElapsTerm;
	/** 	���Ժ����	**/ 
	private String	nPaymPrem;
	/** 	��������ȯ�ޱݾ�	**/ 
	private String	nLowtExptRtnAmt;
	/** 	����ȯ����	**/ 
	private String	nLowtRtnrt;
	/** 	���뿹��ȯ�ޱݾ�	**/ 
	private String	nApplExptRtnAmt;
	/** 	����ȯ����	**/ 
	private String	nApplRtnrt;
	/** 	��������Ŀ���ݾ�	**/ 
	private String	nLoanDuctAftrExptAmt;
	/** 	�ߵ����ɱݾ�	**/ 
	private String	nMwayAvaAmt;
	/** 	����	**/ 
	private String	sFlag;
	/** 	�����庸���	**/ 
	private String	nExptGrntPrem;
	/** 	�������뺸���	**/ 
	private String	nExptAccuPrem;
	/** 	�����û��	**/ 
	private String	sPreDmndDate;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sStndDate
	 */
	public String getsStndDate() {
		return sStndDate;
	}
	/**
	 * @param sStndDate the sStndDate to set
	 */
	public void setsStndDate(String sStndDate) {
		this.sStndDate = sStndDate;
	}
	/**
	 * @return the sExptRtnDate
	 */
	public String getsExptRtnDate() {
		return sExptRtnDate;
	}
	/**
	 * @param sExptRtnDate the sExptRtnDate to set
	 */
	public void setsExptRtnDate(String sExptRtnDate) {
		this.sExptRtnDate = sExptRtnDate;
	}
	/**
	 * @return the sInqrUnit
	 */
	public String getsInqrUnit() {
		return sInqrUnit;
	}
	/**
	 * @param sInqrUnit the sInqrUnit to set
	 */
	public void setsInqrUnit(String sInqrUnit) {
		this.sInqrUnit = sInqrUnit;
	}
	/**
	 * @return the nExptRato
	 */
	public String getnExptRato() {
		return nExptRato;
	}
	/**
	 * @param nExptRato the nExptRato to set
	 */
	public void setnExptRato(String nExptRato) {
		this.nExptRato = nExptRato;
	}
	/**
	 * @return the nIdx
	 */
	public String getnIdx() {
		return nIdx;
	}
	/**
	 * @param nIdx the nIdx to set
	 */
	public void setnIdx(String nIdx) {
		this.nIdx = nIdx;
	}
	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sPymExptDate
	 */
	public String getsPymExptDate() {
		return sPymExptDate;
	}
	/**
	 * @param sPymExptDate the sPymExptDate to set
	 */
	public void setsPymExptDate(String sPymExptDate) {
		this.sPymExptDate = sPymExptDate;
	}
	/**
	 * @return the sElapsTerm
	 */
	public String getsElapsTerm() {
		return sElapsTerm;
	}
	/**
	 * @param sElapsTerm the sElapsTerm to set
	 */
	public void setsElapsTerm(String sElapsTerm) {
		this.sElapsTerm = sElapsTerm;
	}
	/**
	 * @return the nPaymPrem
	 */
	public String getnPaymPrem() {
		return nPaymPrem;
	}
	/**
	 * @param nPaymPrem the nPaymPrem to set
	 */
	public void setnPaymPrem(String nPaymPrem) {
		this.nPaymPrem = nPaymPrem;
	}
	/**
	 * @return the nLowtExptRtnAmt
	 */
	public String getnLowtExptRtnAmt() {
		return nLowtExptRtnAmt;
	}
	/**
	 * @param nLowtExptRtnAmt the nLowtExptRtnAmt to set
	 */
	public void setnLowtExptRtnAmt(String nLowtExptRtnAmt) {
		this.nLowtExptRtnAmt = nLowtExptRtnAmt;
	}
	/**
	 * @return the nLowtRtnrt
	 */
	public String getnLowtRtnrt() {
		return nLowtRtnrt;
	}
	/**
	 * @param nLowtRtnrt the nLowtRtnrt to set
	 */
	public void setnLowtRtnrt(String nLowtRtnrt) {
		this.nLowtRtnrt = nLowtRtnrt;
	}
	/**
	 * @return the nApplExptRtnAmt
	 */
	public String getnApplExptRtnAmt() {
		return nApplExptRtnAmt;
	}
	/**
	 * @param nApplExptRtnAmt the nApplExptRtnAmt to set
	 */
	public void setnApplExptRtnAmt(String nApplExptRtnAmt) {
		this.nApplExptRtnAmt = nApplExptRtnAmt;
	}
	/**
	 * @return the nApplRtnrt
	 */
	public String getnApplRtnrt() {
		return nApplRtnrt;
	}
	/**
	 * @param nApplRtnrt the nApplRtnrt to set
	 */
	public void setnApplRtnrt(String nApplRtnrt) {
		this.nApplRtnrt = nApplRtnrt;
	}
	/**
	 * @return the nLoanDuctAftrExptAmt
	 */
	public String getnLoanDuctAftrExptAmt() {
		return nLoanDuctAftrExptAmt;
	}
	/**
	 * @param nLoanDuctAftrExptAmt the nLoanDuctAftrExptAmt to set
	 */
	public void setnLoanDuctAftrExptAmt(String nLoanDuctAftrExptAmt) {
		this.nLoanDuctAftrExptAmt = nLoanDuctAftrExptAmt;
	}
	/**
	 * @return the nMwayAvaAmt
	 */
	public String getnMwayAvaAmt() {
		return nMwayAvaAmt;
	}
	/**
	 * @param nMwayAvaAmt the nMwayAvaAmt to set
	 */
	public void setnMwayAvaAmt(String nMwayAvaAmt) {
		this.nMwayAvaAmt = nMwayAvaAmt;
	}
	/**
	 * @return the sFlag
	 */
	public String getsFlag() {
		return sFlag;
	}
	/**
	 * @param sFlag the sFlag to set
	 */
	public void setsFlag(String sFlag) {
		this.sFlag = sFlag;
	}
	/**
	 * @return the nExptGrntPrem
	 */
	public String getnExptGrntPrem() {
		return nExptGrntPrem;
	}
	/**
	 * @param nExptGrntPrem the nExptGrntPrem to set
	 */
	public void setnExptGrntPrem(String nExptGrntPrem) {
		this.nExptGrntPrem = nExptGrntPrem;
	}
	/**
	 * @return the nExptAccuPrem
	 */
	public String getnExptAccuPrem() {
		return nExptAccuPrem;
	}
	/**
	 * @param nExptAccuPrem the nExptAccuPrem to set
	 */
	public void setnExptAccuPrem(String nExptAccuPrem) {
		this.nExptAccuPrem = nExptAccuPrem;
	}
	/**
	 * @return the sPreDmndDate
	 */
	public String getsPreDmndDate() {
		return sPreDmndDate;
	}
	/**
	 * @param sPreDmndDate the sPreDmndDate to set
	 */
	public void setsPreDmndDate(String sPreDmndDate) {
		this.sPreDmndDate = sPreDmndDate;
	}
	
}
