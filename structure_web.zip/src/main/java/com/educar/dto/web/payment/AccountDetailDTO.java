/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.educar.common.annotation.BeanUtil;

/**
 * �����ּ�����ȸ DTO
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement(name = "accountDetailDTO")
public class AccountDetailDTO {

	/** �����ڵ� ,  ��ȸ�� ��� **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 3, required = true)
	private String sBankCode;
	/** ���¹�ȣ , ��ȸ�� ��� **/
	//@ValidateLength(type = TypeEnum.NUMBER, required = true)
	private String sAcctNo;
	/** �ֹ�/����ڹ�ȣ ��ȸ�� ��� **/
	private String sDepoOwnerID;
	/** �����ָ� **/
	private String sDepoName;
	/** ���������ڵ� **/
	private String sBankRspCode;
	/** ���� ��� ���� �޼��� **/
	private String sBankRspMsg;
	/** ���� ������ ���Ե� SessionNameEnum �� **/
	private String sessionName;
	/** ���� ���� Ȯ�� �� �� ���� ��ȣ **/
	private String sDealAcctNo;
	/** ��ȣȭŰ */
	@BeanUtil(ignore = true)
	private String sHid_key_data;

	
	public String getsHid_key_data() {
		return sHid_key_data;
	}

	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}

	/**
	 * @return the sBankCode �����ڵ�
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @param sBankCode the sBankCode to set �����ڵ�
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @return the sAcctNo ���¹�ȣ
	 */
	public String getsAcctNo() {
		return sAcctNo;
	}

	/**
	 * @param sAcctNo the sAcctNo to set ���¹�ȣ
	 */
	public void setsAcctNo(final String sAcctNo) {
		this.sAcctNo = sAcctNo;
	}

	/**
	 * @return the sDepoOwnerId �ֹ�/����ڹ�ȣ
	 */
	public String getsDepoOwnerID() {
		return sDepoOwnerID;
	}

	/**
	 * @param sDepoOwnerId the sDepoOwnerId to set �ֹ�/����ڹ�ȣ
	 */
	public void setsDepoOwnerID(final String sDepoOwnerId) {
		this.sDepoOwnerID = sDepoOwnerId;
	}

	/**
	 * @return the sDepoName �����ָ�
	 */
	public String getsDepoName() {
		return sDepoName;
	}

	/**
	 * @param sDepoName the sDepoName to set �����ָ�
	 */
	public void setsDepoName(final String sDepoName) {
		this.sDepoName = sDepoName;
	}

	/**
	 * @return the sBankRspCode ���������ڵ�
	 */
	public String getsBankRspCode() {
		return sBankRspCode;
	}

	/**
	 * @param sBankRspCode the sBankRspCode to set ���������ڵ�
	 */
	public void setsBankRspCode(final String sBankRspCode) {
		this.sBankRspCode = sBankRspCode;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the sBankRspMsg
	 */
	public String getsBankRspMsg() {
		return sBankRspMsg;
	}

	/**
	 * @param sBankRspMsg the sBankRspMsg to set
	 */
	public void setsBankRspMsg(final String sBankRspMsg) {
		this.sBankRspMsg = sBankRspMsg;
	}

	/**
	 * @return the sessionName
	 */
	public String getSessionName() {
		return sessionName;
	}

	/**
	 * @param sessionName the sessionName to set
	 */
	public void setSessionName(final String sessionName) {
		this.sessionName = sessionName;
	}

	/**
	 * @return the sDealAcctNo
	 */
	public String getsDealAcctNo() {
		return sDealAcctNo;
	}

	/**
	 * @param sDealAcctNo the sDealAcctNo to set
	 */
	public void setsDealAcctNo(final String sDealAcctNo) {
		this.sDealAcctNo = sDealAcctNo;
	}
}
