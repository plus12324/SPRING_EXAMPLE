/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �޸麸���
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insHumanInsuranceDTO")
public class InsHumanInsuranceDTO {
	/** 	����ȣ	 **/ 
	private String	sCrNo;
	/** 	������ڵ�	 **/ 
	private String	sCrtorCd;
	/** 	�����	 **/ 
	private String	sCrtorName;
	/** 	���ñ�	 **/ 
	private String	sInsurStrtdate;
	/** 	�������	 **/ 
	private String	sInsurEndDate;
	/** 	��ǰ�ڵ�	 **/ 
	private String	sGdCd;
	/** 	�����ǰ��	 **/ 
	private String	GdNm;
	/** 	�������ڵ�	 **/ 
	private String	sCrStatCd;
	/** 	�����¸�	 **/ 
	private String	CrStatNm;
	/** 	�޸鱸���ڵ�	 **/ 
	private String	sNpayFlagCd;
	/** 	�޸鱸�и�	 **/ 
	private String	sNpayFlagNm;
	/** 	���޻����ڵ�	 **/ 
	private String	sPymStatCd;
	/** 	���޻��¸�	 **/ 
	private String	sPymStatNm;
	/** 	����⿬�����ڵ�	 **/ 
	private String	sSmilemicrobankDntYn;
	/** 	����⿬���θ�	 **/ 
	private String	sSmilemicrobankDntNm;
	/** 	�޸�߻���	 **/ 
	private String	sOccrDate;
	/** 	�޸麸���	 **/ 
	private String	nMwayRtnAmt;
	/** 	���Ⱓ	 **/ 
	private String	sInsurdate;
	
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sCrtorCd
	 */
	public String getsCrtorCd() {
		return sCrtorCd;
	}
	/**
	 * @param sCrtorCd the sCrtorCd to set
	 */
	public void setsCrtorCd(String sCrtorCd) {
		this.sCrtorCd = sCrtorCd;
	}
	/**
	 * @return the sCrtorName
	 */
	public String getsCrtorName() {
		return sCrtorName;
	}
	/**
	 * @param sCrtorName the sCrtorName to set
	 */
	public void setsCrtorName(String sCrtorName) {
		this.sCrtorName = sCrtorName;
	}
	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}
	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}
	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}
	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}
	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}
	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(String sGdCd) {
		this.sGdCd = sGdCd;
	}
	/**
	 * @return the gdNm
	 */
	public String getGdNm() {
		return GdNm;
	}
	/**
	 * @param gdNm the gdNm to set
	 */
	public void setGdNm(String gdNm) {
		GdNm = gdNm;
	}
	/**
	 * @return the sCrStatCd
	 */
	public String getsCrStatCd() {
		return sCrStatCd;
	}
	/**
	 * @param sCrStatCd the sCrStatCd to set
	 */
	public void setsCrStatCd(String sCrStatCd) {
		this.sCrStatCd = sCrStatCd;
	}
	/**
	 * @return the crStatNm
	 */
	public String getCrStatNm() {
		return CrStatNm;
	}
	/**
	 * @param crStatNm the crStatNm to set
	 */
	public void setCrStatNm(String crStatNm) {
		CrStatNm = crStatNm;
	}
	/**
	 * @return the sNpayFlagCd
	 */
	public String getsNpayFlagCd() {
		return sNpayFlagCd;
	}
	/**
	 * @param sNpayFlagCd the sNpayFlagCd to set
	 */
	public void setsNpayFlagCd(String sNpayFlagCd) {
		this.sNpayFlagCd = sNpayFlagCd;
	}
	/**
	 * @return the sNpayFlagNm
	 */
	public String getsNpayFlagNm() {
		return sNpayFlagNm;
	}
	/**
	 * @param sNpayFlagNm the sNpayFlagNm to set
	 */
	public void setsNpayFlagNm(String sNpayFlagNm) {
		this.sNpayFlagNm = sNpayFlagNm;
	}
	/**
	 * @return the sPymStatCd
	 */
	public String getsPymStatCd() {
		return sPymStatCd;
	}
	/**
	 * @param sPymStatCd the sPymStatCd to set
	 */
	public void setsPymStatCd(String sPymStatCd) {
		this.sPymStatCd = sPymStatCd;
	}
	/**
	 * @return the sPymStatNm
	 */
	public String getsPymStatNm() {
		return sPymStatNm;
	}
	/**
	 * @param sPymStatNm the sPymStatNm to set
	 */
	public void setsPymStatNm(String sPymStatNm) {
		this.sPymStatNm = sPymStatNm;
	}
	/**
	 * @return the sSmilemicrobankDntYn
	 */
	public String getsSmilemicrobankDntYn() {
		return sSmilemicrobankDntYn;
	}
	/**
	 * @param sSmilemicrobankDntYn the sSmilemicrobankDntYn to set
	 */
	public void setsSmilemicrobankDntYn(String sSmilemicrobankDntYn) {
		this.sSmilemicrobankDntYn = sSmilemicrobankDntYn;
	}
	/**
	 * @return the sSmilemicrobankDntNm
	 */
	public String getsSmilemicrobankDntNm() {
		return sSmilemicrobankDntNm;
	}
	/**
	 * @param sSmilemicrobankDntNm the sSmilemicrobankDntNm to set
	 */
	public void setsSmilemicrobankDntNm(String sSmilemicrobankDntNm) {
		this.sSmilemicrobankDntNm = sSmilemicrobankDntNm;
	}
	/**
	 * @return the sOccrDate
	 */
	public String getsOccrDate() {
		return sOccrDate;
	}
	/**
	 * @param sOccrDate the sOccrDate to set
	 */
	public void setsOccrDate(String sOccrDate) {
		this.sOccrDate = sOccrDate;
	}
	/**
	 * @return the nMwayRtnAmt
	 */
	public String getnMwayRtnAmt() {
		return nMwayRtnAmt;
	}
	/**
	 * @param nMwayRtnAmt the nMwayRtnAmt to set
	 */
	public void setnMwayRtnAmt(String nMwayRtnAmt) {
		this.nMwayRtnAmt = nMwayRtnAmt;
	}
	/**
	 * @return the sInsurdate
	 */
	public String getsInsurdate() {
		return sInsurdate;
	}
	/**
	 * @param sInsurdate the sInsurdate to set
	 */
	public void setsInsurdate(String sInsurdate) {
		this.sInsurdate = sInsurdate;
	}
	
	
	
}
