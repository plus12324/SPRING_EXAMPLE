/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ī�� E2E �к�ȣȭ�� DTO
 * @author �Ž¿�
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cardE2EDTO")
public class CardE2EDTO {
	
	/** E2E ī���ȣ1 **/
	private String sCardNo1; 
	/** E2E ī���ȣ2 **/
	private String sCardNo2;
	/** E2E ī���ȣ3 **/
	private String sCardNo3;
	/** E2E ī���ȣ4 **/
	private String sCardNo4;
	/** ��½�ť�� Ű���庸�� ��ȣȭ Ű */
	private String sHid_key_data;
	
	public String getsCardNo1() {
		return sCardNo1;
	}
	public void setsCardNo1(String sCardNo1) {
		this.sCardNo1 = sCardNo1;
	}
	public String getsCardNo2() {
		return sCardNo2;
	}
	public void setsCardNo2(String sCardNo2) {
		this.sCardNo2 = sCardNo2;
	}
	public String getsCardNo3() {
		return sCardNo3;
	}
	public void setsCardNo3(String sCardNo3) {
		this.sCardNo3 = sCardNo3;
	}
	public String getsCardNo4() {
		return sCardNo4;
	}
	public void setsCardNo4(String sCardNo4) {
		this.sCardNo4 = sCardNo4;
	}
	public String getsHid_key_data() {
		return sHid_key_data;
	}
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}

}
