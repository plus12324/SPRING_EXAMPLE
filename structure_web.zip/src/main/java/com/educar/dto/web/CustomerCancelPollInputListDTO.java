package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.dto.web.myeducar.CustContInfoListDTO;


/**
 * �������� ���� Input list DTO
 * @author ������
 * @since 0.0.10
 */
@XmlRootElement(name = "customerCancelPollInputListDTO")
public class CustomerCancelPollInputListDTO {
	
	/** ������� **/
	private List<CustomerCancelPollInputDTO> pollInfo;

	public List<CustomerCancelPollInputDTO> getPollInfo() {
		return pollInfo;
	}

	public void setPollInfo(List<CustomerCancelPollInputDTO> pollInfo) {
		this.pollInfo = pollInfo;
	}

}
