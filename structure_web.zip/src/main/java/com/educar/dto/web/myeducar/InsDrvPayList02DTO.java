/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲݺ��� - ���⺻ ��ȸ DTO
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayList02DTO")
public class InsDrvPayList02DTO {
	/** 	ȸ��	**/ 
	private String	nPayNo;
	/** 	���Գ��	**/ 
	private String	sRectYM;
	/** 	��������	**/ 
	private String	sRectDate;
	/** 	���Ժ����	**/ 
	private String	nRectPrem;
	/** 	�������	**/ 
	private String	sCashTypeNam;
	/**
	 * @return the nPayNo
	 */
	public String getnPayNo() {
		return nPayNo;
	}
	/**
	 * @param nPayNo the nPayNo to set
	 */
	public void setnPayNo(String nPayNo) {
		this.nPayNo = nPayNo;
	}
	/**
	 * @return the sRectYM
	 */
	public String getsRectYM() {
		return sRectYM;
	}
	/**
	 * @param sRectYM the sRectYM to set
	 */
	public void setsRectYM(String sRectYM) {
		this.sRectYM = sRectYM;
	}
	/**
	 * @return the sRectDate
	 */
	public String getsRectDate() {
		return sRectDate;
	}
	/**
	 * @param sRectDate the sRectDate to set
	 */
	public void setsRectDate(String sRectDate) {
		this.sRectDate = sRectDate;
	}
	/**
	 * @return the nRectPrem
	 */
	public String getnRectPrem() {
		return nRectPrem;
	}
	/**
	 * @param nRectPrem the nRectPrem to set
	 */
	public void setnRectPrem(String nRectPrem) {
		this.nRectPrem = nRectPrem;
	}
	/**
	 * @return the sCashTypeNam
	 */
	public String getsCashTypeNam() {
		return sCashTypeNam;
	}
	/**
	 * @param sCashTypeNam the sCashTypeNam to set
	 */
	public void setsCashTypeNam(String sCashTypeNam) {
		this.sCashTypeNam = sCashTypeNam;
	}
	
	
}
