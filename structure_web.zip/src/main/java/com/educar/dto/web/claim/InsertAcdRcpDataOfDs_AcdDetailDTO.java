/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ������� DTO
 * @author ������ 
 * @since 1.0.0
 */
@XmlRootElement(name = "insertAcdRcpDataOfDs_AcdListDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAcdRcpDataOfDs_AcdDetailDTO {
	/** �������ֹι�ȣ **/
	private String sDmgID;
	/** ��������ȭ ������ȣ **/
	private String sDmgTelDDD;
	/** ��������ȭ ���� **/
	private String sDmgTel1;
	/** ��������ȭ �ĺ���ȣ **/
	private String sDmgTel2;
	/** ����� **/
	private String sStaff;
	/** ����� **/
	private String sTeam;
	/** ��缾�� **/
	private String sCenter;
	/** �Ա����� **/
	private String sSupBankCd;
	/** ���¹�ȣ **/
	private String sSupAccountNo;
	/** ������ **/
	private String sSupDepName;
	/** ���LIST���� �����۾��� ���� ��������� Key�÷�(�űԶ��� ����ȣ��, ��������ȸ�ÿ� �����ȣ�� ����) ������ ��������ȸ�� ���⶧���� ����ȣ�� �ִ´�. **/
	private String caseClsNumber;
	/** ����㺸����
	 * 1605, 2304, 2300, 2301, 2302, 2303 ->01
	 * 1601, 1603, 1613, 2200, 2201, 2202, 2101, 2800, 2801, 2802, 2100 -> 02
	 * **/
	private String sDmgKind;
	/** �����ڸ�**/
	private String sDmgName;
	/** �Ǻ���������� 1�μ��� **/
	private String nInsAimSeq;
	/** �Ǻ���������� 11�� ����**/
	private String sInsAimType;
	
	/**
	 * @return the nInsAimSeq
	 */
	public String getnInsAimSeq() {
		return nInsAimSeq;
	}

	/**
	 * @param nInsAimSeq the nInsAimSeq to set
	 */
	public void setnInsAimSeq(String nInsAimSeq) {
		this.nInsAimSeq = nInsAimSeq;
	}

	/**
	 * @return the sInsAimType
	 */
	public String getsInsAimType() {
		return sInsAimType;
	}

	/**
	 * @param sInsAimType the sInsAimType to set
	 */
	public void setsInsAimType(String sInsAimType) {
		this.sInsAimType = sInsAimType;
	}

	/**
	 * @return the sDmgName
	 */
	public String getsDmgName() {
		return sDmgName;
	}

	/**
	 * @param sDmgName the sDmgName to set
	 */
	public void setsDmgName(String sDmgName) {
		this.sDmgName = sDmgName;
	}

	/**
	 * @return the sDmgKind
	 */
	public String getsDmgKind() {
		return sDmgKind;
	}

	/**
	 * @param sDmgKind the sDmgKind to set
	 */
	public void setsDmgKind(String sDmgKind) {
		this.sDmgKind = sDmgKind;
	}

	/**
	 * @return the caseClsNumber
	 */
	public String getCaseClsNumber() {
		return caseClsNumber;
	}

	/**
	 * @param caseClsNumber the caseClsNumber to set
	 */
	public void setCaseClsNumber(String caseClsNumber) {
		this.caseClsNumber = caseClsNumber;
	}

	/**
	 * @return the sDmgID
	 */
	public String getsDmgID() {
		return sDmgID;
	}

	/**
	 * @param sDmgID the sDmgID to set
	 */
	public void setsDmgID(final String sDmgID) {
		this.sDmgID = sDmgID;
	}

	/**
	 * @return the sDmgTelDDD
	 */
	public String getsDmgTelDDD() {
		return sDmgTelDDD;
	}

	/**
	 * @param sDmgTelDDD the sDmgTelDDD to set
	 */
	public void setsDmgTelDDD(final String sDmgTelDDD) {
		this.sDmgTelDDD = sDmgTelDDD;
	}

	/**
	 * @return the sDmgTel1
	 */
	public String getsDmgTel1() {
		return sDmgTel1;
	}

	/**
	 * @param sDmgTel1 the sDmgTel1 to set
	 */
	public void setsDmgTel1(final String sDmgTel1) {
		this.sDmgTel1 = sDmgTel1;
	}

	/**
	 * @return the sDmgTel2
	 */
	public String getsDmgTel2() {
		return sDmgTel2;
	}

	/**
	 * @param sDmgTel2 the sDmgTel2 to set
	 */
	public void setsDmgTel2(final String sDmgTel2) {
		this.sDmgTel2 = sDmgTel2;
	}

	/**
	 * @return the sStaff
	 */
	public String getsStaff() {
		return sStaff;
	}

	/**
	 * @param sStaff the sStaff to set
	 */
	public void setsStaff(final String sStaff) {
		this.sStaff = sStaff;
	}

	/**
	 * @return the sTeam
	 */
	public String getsTeam() {
		return sTeam;
	}

	/**
	 * @param sTeam the sTeam to set
	 */
	public void setsTeam(final String sTeam) {
		this.sTeam = sTeam;
	}

	/**
	 * @return the sCenter
	 */
	public String getsCenter() {
		return sCenter;
	}

	/**
	 * @param sCenter the sCenter to set
	 */
	public void setsCenter(final String sCenter) {
		this.sCenter = sCenter;
	}

	/**
	 * @return the sSupBankCd
	 */
	public String getsSupBankCd() {
		return sSupBankCd;
	}

	/**
	 * @param sSupBankCd the sSupBankCd to set
	 */
	public void setsSupBankCd(final String sSupBankCd) {
		this.sSupBankCd = sSupBankCd;
	}

	/**
	 * @return the sSupAccountNo
	 */
	public String getsSupAccountNo() {
		return sSupAccountNo;
	}

	/**
	 * @param sSupAccountNo the sSupAccountNo to set
	 */
	public void setsSupAccountNo(final String sSupAccountNo) {
		this.sSupAccountNo = sSupAccountNo;
	}

	/**
	 * @return the sSupDepName
	 */
	public String getsSupDepName() {
		return sSupDepName;
	}

	/**
	 * @param sSupDepName the sSupDepName to set
	 */
	public void setsSupDepName(final String sSupDepName) {
		this.sSupDepName = sSupDepName;
	}

}
