/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.date.DateFormat;
import kr.co.conch.validator.annotation.date.ValidateDate;
import kr.co.conch.validator.annotation.length.ValidateLength;

import com.educar.enumeration.CODAA02CodeTypeEnum;

/**
 * <pre>
 * �ڵ��� ��ȸ DTO
 * TODO : �� ������ ���� �ʵ� ���� �ʿ� -> �������̽� Ȯ�� �� ó��
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="carSelectListDTO")
public class CarSelectListDTO {

	/** ���� */
	@ValidateDate(required = true, dateFormat = DateFormat.yyyy)
	private String sYear;
	/** code..CODAA02 ���� ����ϴ� �ڵ� ���� */
	private String sCodeType = CODAA02CodeTypeEnum.CAR.getsCodeType();
	/** ������ �ڵ� */
	@ValidateLength(required = true, min = 1)
	private String sMadeComp;
	/** �ڵ�����(��ǥ��) */
	private String sShortName;
	/** �������� : ������ */
	@ValidateDate(required = true, dateFormat = DateFormat.yyyyMMdd)
	private String sApplyFmdt;
	/** �����ڵ� PriceCalculationOfCarInsuranceTypeEnum */
	private String sInsType;
	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}
	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}
	/**
	 * @return the sCodeType
	 */
	public String getsCodeType() {
		return sCodeType;
	}
	/**
	 * @param sCodeType the sCodeType to set
	 */
	public void setsCodeType(final String sCodeType) {
		this.sCodeType = sCodeType;
	}
	/**
	 * @return the sMadeComp
	 */
	public String getsMadeComp() {
		return sMadeComp;
	}
	/**
	 * @param sMadeComp the sMadeComp to set
	 */
	public void setsMadeComp(final String sMadeComp) {
		this.sMadeComp = sMadeComp;
	}
	/**
	 * @return the sShortName
	 */
	public String getsShortName() {
		return sShortName;
	}
	/**
	 * @param sShortName the sShortName to set
	 */
	public void setsShortName(final String sShortName) {
		this.sShortName = sShortName;
	}
	/**
	 * @return the sApplyFmdt
	 */
	public String getsApplyFmdt() {
		return sApplyFmdt;
	}
	/**
	 * @param sApplyFmdt the sApplyFmdt to set
	 */
	public void setsApplyFmdt(final String sApplyFmdt) {
		this.sApplyFmdt = sApplyFmdt;
	}
	/**
	 * @return the sInsType
	 */
	public String getsInsType() {
		return sInsType;
	}
	/**
	 * @param sInsType the sInsType to set
	 */
	public void setsInsType(final String sInsType) {
		this.sInsType = sInsType;
	}
}
