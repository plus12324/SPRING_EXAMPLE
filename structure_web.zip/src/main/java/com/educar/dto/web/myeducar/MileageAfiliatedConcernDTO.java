/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * ���ϸ��� ���޾�ü DTO (WEBDD34)
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mileageAfiliatedConcernDTO")
public class MileageAfiliatedConcernDTO extends PageDTO {
	/** default **/
	private static final long serialVersionUID = 1L;

	/** ������ **/
	private long nSeqNo;
	/** �������� **/
	private String sCenterName;
	/** ��ȣ�� **/
	private String sName;
	/** �ּ�(ȭ��ǥ�ÿ�) **/
	private String address;
	/** �ּ�1(�����õ�) **/
	private String sAdrs1;
	/** �ּ�2(�ñ���) **/
	private String sAdrs2;
	/** �ּ�3(�����ּ�) **/
	private String sAdrs3;
	/** ��ȭ��ȣ **/
	private String sTel;
	/** ��뿩�� **/
	private String sDealYN;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;

	/** daum map api ��ǥ x (ȭ�鿡�����)**/
	private String x;
	/** daum map api ��ǥ y (ȭ�鿡�����)**/
	private String y;

	/**
	 * @return the nSeqNo
	 */
	public long getnSeqNo() {
		return nSeqNo;
	}

	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(final long nSeqNo) {
		this.nSeqNo = nSeqNo;
	}

	/**
	 * @return the sCenterName
	 */
	public String getsCenterName() {
		return sCenterName;
	}

	/**
	 * @param sCenterName the sCenterName to set
	 */
	public void setsCenterName(final String sCenterName) {
		this.sCenterName = sCenterName;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(final String address) {
		this.address = address;
	}

	/**
	 * @return the sAdrs1
	 */
	public String getsAdrs1() {
		return sAdrs1;
	}

	/**
	 * @param sAdrs1 the sAdrs1 to set
	 */
	public void setsAdrs1(final String sAdrs1) {
		this.sAdrs1 = sAdrs1;
	}

	/**
	 * @return the sAdrs2
	 */
	public String getsAdrs2() {
		return sAdrs2;
	}

	/**
	 * @param sAdrs2 the sAdrs2 to set
	 */
	public void setsAdrs2(final String sAdrs2) {
		this.sAdrs2 = sAdrs2;
	}

	/**
	 * @return the sAdrs3
	 */
	public String getsAdrs3() {
		return sAdrs3;
	}

	/**
	 * @param sAdrs3 the sAdrs3 to set
	 */
	public void setsAdrs3(final String sAdrs3) {
		this.sAdrs3 = sAdrs3;
	}

	/**
	 * @return the sTel
	 */
	public String getsTel() {
		return sTel;
	}

	/**
	 * @param sTel the sTel to set
	 */
	public void setsTel(final String sTel) {
		this.sTel = sTel;
	}

	/**
	 * @return the sDealYN
	 */
	public String getsDealYN() {
		return sDealYN;
	}

	/**
	 * @param sDealYN the sDealYN to set
	 */
	public void setsDealYN(final String sDealYN) {
		this.sDealYN = sDealYN;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the x
	 */
	public String getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public void setX(final String x) {
		this.x = x;
	}

	/**
	 * @return the y
	 */
	public String getY() {
		return y;
	}

	/**
	 * @param y the y to set
	 */
	public void setY(final String y) {
		this.y = y;
	}

}
