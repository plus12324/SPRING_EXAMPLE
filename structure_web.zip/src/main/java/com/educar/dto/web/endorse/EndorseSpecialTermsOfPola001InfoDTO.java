/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �輭 - Ư����� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "endorseSpecialTermsOfPola001InfoDTO")
public class EndorseSpecialTermsOfPola001InfoDTO {
	/** �����ڵ� (EE03 ����) **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** û����� (E':�輭����������� Ȯ���� ) **/
	private String sApplyStat;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** �ָ�����Ư��㺸 00 �̰���, 01 1���߰�����, 02 2���߰����� **/
	private String sCover0509;
	/** ��Ʈ�ڵ��� 00 �̰���, 99 ���� (�����㺸�߰��Ȱ�츸 ����) **/
	private String sCover0510;
	/** �������� 00 �̰���, 99 ���� **/
	private String sCover0512;
	/** ����� 00 �̰���, 99 ���� **/
	private String sCover0513;
	/** ���ݺ�� 00 �̰���, 99 ���� **/
	private String sCover0514;
	/** ������ 00 �̰���, 99 ���� **/
	private String sCover0233;
	/** ������ - ���� 1: ��, 2: ȭ, 3:�� , 4: ��, 5: �� ( ��¥ ����� �輭�������� �ش��� �Ͽ���) **/
	private String specWeekDay;

	/** �輭������ **/
	private String sEndorseFmdt1;
	/** �������Կ��� Y / N    **/
	private String sOAD;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sApplyStat
	 */
	public String getsApplyStat() {
		return sApplyStat;
	}

	/**
	 * @param sApplyStat the sApplyStat to set
	 */
	public void setsApplyStat(final String sApplyStat) {
		this.sApplyStat = sApplyStat;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sCover0509
	 */
	public String getsCover0509() {
		return sCover0509;
	}

	/**
	 * @param sCover0509 the sCover0509 to set
	 */
	public void setsCover0509(final String sCover0509) {
		this.sCover0509 = sCover0509;
	}

	/**
	 * @return the sCover0510
	 */
	public String getsCover0510() {
		return sCover0510;
	}

	/**
	 * @param sCover0510 the sCover0510 to set
	 */
	public void setsCover0510(final String sCover0510) {
		this.sCover0510 = sCover0510;
	}

	/**
	 * @return the sCover0512
	 */
	public String getsCover0512() {
		return sCover0512;
	}

	/**
	 * @param sCover0512 the sCover0512 to set
	 */
	public void setsCover0512(final String sCover0512) {
		this.sCover0512 = sCover0512;
	}

	/**
	 * @return the sCover0513
	 */
	public String getsCover0513() {
		return sCover0513;
	}

	/**
	 * @param sCover0513 the sCover0513 to set
	 */
	public void setsCover0513(final String sCover0513) {
		this.sCover0513 = sCover0513;
	}

	/**
	 * @return the sCover0514
	 */
	public String getsCover0514() {
		return sCover0514;
	}

	/**
	 * @param sCover0514 the sCover0514 to set
	 */
	public void setsCover0514(final String sCover0514) {
		this.sCover0514 = sCover0514;
	}

	/**
	 * @return the sCover0233
	 */
	public String getsCover0233() {
		return sCover0233;
	}

	/**
	 * @param sCover0233 the sCover0233 to set
	 */
	public void setsCover0233(final String sCover0233) {
		this.sCover0233 = sCover0233;
	}

	/**
	 * @return the specWeekDay
	 */
	public String getSpecWeekDay() {
		return specWeekDay;
	}

	/**
	 * @param specWeekDay the specWeekDay to set
	 */
	public void setSpecWeekDay(final String specWeekDay) {
		this.specWeekDay = specWeekDay;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @return the sOAD
	 */
	public String getsOAD() {
		return sOAD;
	}

	/**
	 * @param sOAD the sOAD to set
	 */
	public void setsOAD(final String sOAD) {
		this.sOAD = sOAD;
	}

}
