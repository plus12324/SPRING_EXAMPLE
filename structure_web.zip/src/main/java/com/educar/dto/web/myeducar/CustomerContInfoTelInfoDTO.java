/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��ȭ��ȣ ����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "customerContInfoTelInfoDTO")
public class CustomerContInfoTelInfoDTO {
	/**	�ֹι�ȣ	**/ 
	private String 	sCustNo;
	/**	����	**/ 
	private String 	nSeqNo;
	/**	����ȸ��	**/ 
	private String 	nChangeNo;
	/**	������ȭ��ȣ(����)	**/ 
	private String 	sHomeTel1;
	/**	������ȭ��ȣ1	**/ 
	private String 	sHomeTel2;
	/**	������ȭ��ȣ2	**/ 
	private String 	sHomeTel3;
	/**	�繫����ȭ��ȣ(����)	**/ 
	private String 	sOfficeTel1;
	/**	�繫����ȭ��ȣ1	**/ 
	private String 	sOfficeTel2;
	/**	�繫����ȭ��ȣ2	**/ 
	private String 	sOfficeTel3;
	/**	�繫�ǳ�����ȣ	**/
	private String 	sInnerPhone;
	/**	�ڵ�����ȣ(ȸ��)	**/ 
	private String 	sCellPhone1;
	/**	�ڵ�����ȣ1	**/ 
	private String 	sCellPhone2;
	/**	�ڵ�����ȣ2	**/ 
	private String 	sCellPhone3;
	/**	�ѽ���ȣ(����)	**/ 
	private String 	sFax1;
	/**	�ѽ���ȣ1	**/ 
	private String 	sFax2;
	/**	�ѽ���ȣ2	**/ 
	private String 	sFax3;
	/**	��Ÿ��ȣ1	**/ 
	private String 	sEtcTel1;
	/**	��Ÿ��ȣ2	**/ 
	private String 	sEtcTel2;
	/**	��Ÿ��ȣ3	**/ 
	private String 	sEtcTel3;
	/**	��Ÿ��ȣŸ��	**/ 
	private String 	sEtcType;
	/**	e-mail1	**/ 
	private String 	sEmail1;
	/**	e-mail2	**/ 
	private String 	sEmail2;
	/**	�����	**/ 
	private String 	sUserID;
	/**	Ȩ�������ּ�	**/ 
	private String 	sHomepageUrl;
	/**	�Է���	**/ 
	private String 	sInputDate;
	/**	�Է½ð�	**/ 
	private String 	sInputTime;

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the nSeqNo
	 */
	public String getnSeqNo() {
		return nSeqNo;
	}
	/**
	 * @param nSeqNo the nSeqNo to set
	 */
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	/**
	 * @return the nChangeNo
	 */
	public String getnChangeNo() {
		return nChangeNo;
	}
	/**
	 * @param nChangeNo the nChangeNo to set
	 */
	public void setnChangeNo(String nChangeNo) {
		this.nChangeNo = nChangeNo;
	}
	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}
	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}
	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}
	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}
	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}
	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}
	/**
	 * @return the sOfficeTel1
	 */
	public String getsOfficeTel1() {
		return sOfficeTel1;
	}
	/**
	 * @param sOfficeTel1 the sOfficeTel1 to set
	 */
	public void setsOfficeTel1(String sOfficeTel1) {
		this.sOfficeTel1 = sOfficeTel1;
	}
	/**
	 * @return the sOfficeTel2
	 */
	public String getsOfficeTel2() {
		return sOfficeTel2;
	}
	/**
	 * @param sOfficeTel2 the sOfficeTel2 to set
	 */
	public void setsOfficeTel2(String sOfficeTel2) {
		this.sOfficeTel2 = sOfficeTel2;
	}
	/**
	 * @return the sOfficeTel3
	 */
	public String getsOfficeTel3() {
		return sOfficeTel3;
	}
	/**
	 * @param sOfficeTel3 the sOfficeTel3 to set
	 */
	public void setsOfficeTel3(String sOfficeTel3) {
		this.sOfficeTel3 = sOfficeTel3;
	}
	/**
	 * @return the sInnerPhone
	 */
	public String getsInnerPhone() {
		return sInnerPhone;
	}
	/**
	 * @param sInnerPhone the sInnerPhone to set
	 */
	public void setsInnerPhone(String sInnerPhone) {
		this.sInnerPhone = sInnerPhone;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sFax1
	 */
	public String getsFax1() {
		return sFax1;
	}
	/**
	 * @param sFax1 the sFax1 to set
	 */
	public void setsFax1(String sFax1) {
		this.sFax1 = sFax1;
	}
	/**
	 * @return the sFax2
	 */
	public String getsFax2() {
		return sFax2;
	}
	/**
	 * @param sFax2 the sFax2 to set
	 */
	public void setsFax2(String sFax2) {
		this.sFax2 = sFax2;
	}
	/**
	 * @return the sFax3
	 */
	public String getsFax3() {
		return sFax3;
	}
	/**
	 * @param sFax3 the sFax3 to set
	 */
	public void setsFax3(String sFax3) {
		this.sFax3 = sFax3;
	}
	/**
	 * @return the sEtcTel1
	 */
	public String getsEtcTel1() {
		return sEtcTel1;
	}
	/**
	 * @param sEtcTel1 the sEtcTel1 to set
	 */
	public void setsEtcTel1(String sEtcTel1) {
		this.sEtcTel1 = sEtcTel1;
	}
	/**
	 * @return the sEtcTel2
	 */
	public String getsEtcTel2() {
		return sEtcTel2;
	}
	/**
	 * @param sEtcTel2 the sEtcTel2 to set
	 */
	public void setsEtcTel2(String sEtcTel2) {
		this.sEtcTel2 = sEtcTel2;
	}
	/**
	 * @return the sEtcTel3
	 */
	public String getsEtcTel3() {
		return sEtcTel3;
	}
	/**
	 * @param sEtcTel3 the sEtcTel3 to set
	 */
	public void setsEtcTel3(String sEtcTel3) {
		this.sEtcTel3 = sEtcTel3;
	}
	/**
	 * @return the sEtcType
	 */
	public String getsEtcType() {
		return sEtcType;
	}
	/**
	 * @param sEtcType the sEtcType to set
	 */
	public void setsEtcType(String sEtcType) {
		this.sEtcType = sEtcType;
	}
	/**
	 * @return the sEmail1
	 */
	public String getsEmail1() {
		return sEmail1;
	}
	/**
	 * @param sEmail1 the sEmail1 to set
	 */
	public void setsEmail1(String sEmail1) {
		this.sEmail1 = sEmail1;
	}
	/**
	 * @return the sEmail2
	 */
	public String getsEmail2() {
		return sEmail2;
	}
	/**
	 * @param sEmail2 the sEmail2 to set
	 */
	public void setsEmail2(String sEmail2) {
		this.sEmail2 = sEmail2;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sHomepageUrl
	 */
	public String getsHomepageUrl() {
		return sHomepageUrl;
	}
	/**
	 * @param sHomepageUrl the sHomepageUrl to set
	 */
	public void setsHomepageUrl(String sHomepageUrl) {
		this.sHomepageUrl = sHomepageUrl;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}

}
