/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �������� ����,�̿� ����(WEBDD53)
 * 
 * @author ���ѳ�
 * 
 */
public class PersonalInformationAgreementDTO {
	/**		����	**/	
	private Integer	nSeq; 
	/**		����	**/	
	private String 	sName;
	/**		����ó	**/	
	private String 	sCallNum;
	/**		���ID	**/	
	private String 	sAgreeId;
	/**		���ǿ���	**/	
	private String 	sAgreeYN;
	/**		���ǰ��	**/	
	private String 	sUrl;
	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(Integer nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCallNum
	 */
	public String getsCallNum() {
		return sCallNum;
	}
	/**
	 * @param sCallNum the sCallNum to set
	 */
	public void setsCallNum(String sCallNum) {
		this.sCallNum = sCallNum;
	}
	/**
	 * @return the sAgreeId
	 */
	public String getsAgreeId() {
		return sAgreeId;
	}
	/**
	 * @param sAgreeId the sAgreeId to set
	 */
	public void setsAgreeId(String sAgreeId) {
		this.sAgreeId = sAgreeId;
	}
	/**
	 * @return the sAgreeYN
	 */
	public String getsAgreeYN() {
		return sAgreeYN;
	}
	/**
	 * @param sAgreeYN the sAgreeYN to set
	 */
	public void setsAgreeYN(String sAgreeYN) {
		this.sAgreeYN = sAgreeYN;
	}
	/**
	 * @return the sUrl
	 */
	public String getsUrl() {
		return sUrl;
	}
	/**
	 * @param sUrl the sUrl to set
	 */
	public void setsUrl(String sUrl) {
		this.sUrl = sUrl;
	}
	
	
	
}
