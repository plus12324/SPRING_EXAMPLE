/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲ� ���� ���Գ��� ��ȸ ��� DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralDivPremResultDTO")
public class InsuranceGeneralDivPremResultDTO {
	/** �������� (ex)20120924) **/
	private String sPytDte;
	/** ��������(���) (ex)2012��09��24��) **/
	private String sPytYM;
	/** ������ȣ **/
	private String sRctNum;
	/** �����ݾ� **/
	private String nRctAmt;
	/**
	 * <pre>
	 * ��������
	 * 1. ���� 2. ī�� 3. ���ձ��� 4. ������ü 
	 * 5. ����,�ڵ���ü 6. ���� 7. ���� 
	 * 8. �ܻ�(���������Ư��)
	 * </pre>
	 **/
	private String sCrn;
	/** �������� �ѱ۸� **/
	private String sCashTypeName;
	/** ���� ȸ�� **/
	private String nPaySeq;

	/**
	 * @return the sPytDte
	 */
	public String getsPytDte() {
		return sPytDte;
	}

	/**
	 * @param sPytDte the sPytDte to set
	 */
	public void setsPytDte(final String sPytDte) {
		this.sPytDte = sPytDte;
	}

	/**
	 * @return the sPytYM
	 */
	public String getsPytYM() {
		return sPytYM;
	}

	/**
	 * @param sPytYM the sPytYM to set
	 */
	public void setsPytYM(final String sPytYM) {
		this.sPytYM = sPytYM;
	}

	/**
	 * @return the sRctNum
	 */
	public String getsRctNum() {
		return sRctNum;
	}

	/**
	 * @param sRctNum the sRctNum to set
	 */
	public void setsRctNum(final String sRctNum) {
		this.sRctNum = sRctNum;
	}

	/**
	 * @return the nRctAmt
	 */
	public String getnRctAmt() {
		return nRctAmt;
	}

	/**
	 * @param nRctAmt the nRctAmt to set
	 */
	public void setnRctAmt(final String nRctAmt) {
		this.nRctAmt = nRctAmt;
	}

	/**
	 * @return the sCrn
	 */
	public String getsCrn() {
		return sCrn;
	}

	/**
	 * @param sCrn the sCrn to set
	 */
	public void setsCrn(final String sCrn) {
		this.sCrn = sCrn;
	}

	/**
	 * @return the sCashTypeName
	 */
	public String getsCashTypeName() {
		return sCashTypeName;
	}

	/**
	 * @param sCashTypeName the sCashTypeName to set
	 */
	public void setsCashTypeName(final String sCashTypeName) {
		this.sCashTypeName = sCashTypeName;
	}

	/**
	 * @return the nPaySeq
	 */
	public String getnPaySeq() {
		return nPaySeq;
	}

	/**
	 * @param nPaySeq the nPaySeq to set
	 */
	public void setnPaySeq(final String nPaySeq) {
		this.nPaySeq = nPaySeq;
	}

}
