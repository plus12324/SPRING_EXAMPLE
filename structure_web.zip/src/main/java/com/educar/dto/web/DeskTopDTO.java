/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���ȭ�� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "deskTopDTO")
public class DeskTopDTO {
	/** �Ϸù�ȣ **/
	private long nSeq;
	/** �⵵ **/
	private String sYear;
	/** �� **/
	private String sMonth;
	/** ���� **/
	private String sTitle;
	/** ���ϰ�� **/
	private String sImagePath;
	/** �����̸� **/
	private String sMainImageName;
	/** �����̸�800*600 **/
	private String sImageName800;
	/** �����̸�1024*768 **/
	private String sImageName1024;
	/** �����̸�1280*1024 **/
	private String sImageName1280;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;

	/**
	 * @return the nSeq
	 */
	public long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the sMonth
	 */
	public String getsMonth() {
		return sMonth;
	}

	/**
	 * @param sMonth the sMonth to set
	 */
	public void setsMonth(final String sMonth) {
		this.sMonth = sMonth;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sImagePath
	 */
	public String getsImagePath() {
		return sImagePath;
	}

	/**
	 * @param sImagePath the sImagePath to set
	 */
	public void setsImagePath(final String sImagePath) {
		this.sImagePath = sImagePath;
	}

	/**
	 * @return the sMainImageName
	 */
	public String getsMainImageName() {
		return sMainImageName;
	}

	/**
	 * @param sMainImageName the sMainImageName to set
	 */
	public void setsMainImageName(final String sMainImageName) {
		this.sMainImageName = sMainImageName;
	}

	/**
	 * @return the sImageName800
	 */
	public String getsImageName800() {
		return sImageName800;
	}

	/**
	 * @param sImageName800 the sImageName800 to set
	 */
	public void setsImageName800(final String sImageName800) {
		this.sImageName800 = sImageName800;
	}

	/**
	 * @return the sImageName1024
	 */
	public String getsImageName1024() {
		return sImageName1024;
	}

	/**
	 * @param sImageName1024 the sImageName1024 to set
	 */
	public void setsImageName1024(final String sImageName1024) {
		this.sImageName1024 = sImageName1024;
	}

	/**
	 * @return the sImageName1280
	 */
	public String getsImageName1280() {
		return sImageName1280;
	}

	/**
	 * @param sImageName1280 the sImageName1280 to set
	 */
	public void setsImageName1280(final String sImageName1280) {
		this.sImageName1280 = sImageName1280;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

}
