/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �Ϲݰ�� - �������
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayRectList02DTO")
public class InsDrvPayRectList02DTO {
	/** 	ȸ��	 **/ 
	private String 	nIstPytTms;
	/** 	�輭��ȣ	 **/ 
	private String 	nChgNum;
	/** 	�ش��	 **/ 
	private String 	sIstPytEptDte;
	/** 	���Ժ����	 **/ 
	private String 	nIstPytKrwPmi;
	/** 	��������	 **/ 
	private String 	sPytDte;
	/** 	�������	 **/ 
	private String 	sCashTypeNam;
	/** 	���Ի���	 **/ 
	private String 	sPrsStaName;
	/** 	�����	 **/ 
	private String 	sRegister;
	/**
	 * @return the nIstPytTms
	 */
	public String getnIstPytTms() {
		return nIstPytTms;
	}
	/**
	 * @param nIstPytTms the nIstPytTms to set
	 */
	public void setnIstPytTms(String nIstPytTms) {
		this.nIstPytTms = nIstPytTms;
	}
	/**
	 * @return the nChgNum
	 */
	public String getnChgNum() {
		return nChgNum;
	}
	/**
	 * @param nChgNum the nChgNum to set
	 */
	public void setnChgNum(String nChgNum) {
		this.nChgNum = nChgNum;
	}
	/**
	 * @return the sIstPytEptDte
	 */
	public String getsIstPytEptDte() {
		return sIstPytEptDte;
	}
	/**
	 * @param sIstPytEptDte the sIstPytEptDte to set
	 */
	public void setsIstPytEptDte(String sIstPytEptDte) {
		this.sIstPytEptDte = sIstPytEptDte;
	}
	/**
	 * @return the nIstPytKrwPmi
	 */
	public String getnIstPytKrwPmi() {
		return nIstPytKrwPmi;
	}
	/**
	 * @param nIstPytKrwPmi the nIstPytKrwPmi to set
	 */
	public void setnIstPytKrwPmi(String nIstPytKrwPmi) {
		this.nIstPytKrwPmi = nIstPytKrwPmi;
	}
	/**
	 * @return the sPytDte
	 */
	public String getsPytDte() {
		return sPytDte;
	}
	/**
	 * @param sPytDte the sPytDte to set
	 */
	public void setsPytDte(String sPytDte) {
		this.sPytDte = sPytDte;
	}
	/**
	 * @return the sCashTypeNam
	 */
	public String getsCashTypeNam() {
		return sCashTypeNam;
	}
	/**
	 * @param sCashTypeNam the sCashTypeNam to set
	 */
	public void setsCashTypeNam(String sCashTypeNam) {
		this.sCashTypeNam = sCashTypeNam;
	}
	/**
	 * @return the sPrsStaName
	 */
	public String getsPrsStaName() {
		return sPrsStaName;
	}
	/**
	 * @param sPrsStaName the sPrsStaName to set
	 */
	public void setsPrsStaName(String sPrsStaName) {
		this.sPrsStaName = sPrsStaName;
	}
	/**
	 * @return the sRegister
	 */
	public String getsRegister() {
		return sRegister;
	}
	/**
	 * @param sRegister the sRegister to set
	 */
	public void setsRegister(String sRegister) {
		this.sRegister = sRegister;
	}
	
}
