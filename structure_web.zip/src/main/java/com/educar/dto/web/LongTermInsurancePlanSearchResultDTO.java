/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� �÷���ȸ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "longTermInsurancePlanSearchResultDTO")
public class LongTermInsurancePlanSearchResultDTO {
	/** multi **/
	private List<LongTermInsurancePlanCodeDTO> multi;
	/** InsAmt(����ݾ׸� : sHnglCdName, Ư���ڵ� : sTrtyCd) **/
	private List<LongTermInsurancePlanCodeDTO> InsAmt;
	/** InsurTerm(Ư���ڵ� : sTrtyCd, ����Ⱓ�� : sInsurTermName, ���ԱⰣ �� : sPaymTermName) **/
	private List<LongTermInsurancePlanCodeDTO> InsurTerm;
	
	/** ���ޱⰣ **/
	private List<LongAnntCommCodeDTO> AnntyPymTermList;
	/** ���ԱⰣ **/
	private List<LongAnntCommCodeDTO> InsurTermPaymTerm;
	/** �����ֱ� **/
	private List<LongAnntCommCodeDTO> AnntyPymCyclList;
	/** ���ݰ��ó��� **/
	private List<LongAnntCommCodeDTO> AnntyOpnAgeList;
	/** �������� **/
	private List<LongAnntCommCodeDTO> AnntyPymTypeList;
	/** �����ֱ� **/
	private List<LongAnntCommCodeDTO> paymCyclCdList;
	/**
	 * @return the multi
	 */
	public List<LongTermInsurancePlanCodeDTO> getMulti() {
		return multi;
	}
	/**
	 * @param multi the multi to set
	 */
	public void setMulti(List<LongTermInsurancePlanCodeDTO> multi) {
		this.multi = multi;
	}
	/**
	 * @return the insAmt
	 */
	public List<LongTermInsurancePlanCodeDTO> getInsAmt() {
		return InsAmt;
	}
	/**
	 * @param insAmt the insAmt to set
	 */
	public void setInsAmt(List<LongTermInsurancePlanCodeDTO> insAmt) {
		InsAmt = insAmt;
	}
	/**
	 * @return the insurTerm
	 */
	public List<LongTermInsurancePlanCodeDTO> getInsurTerm() {
		return InsurTerm;
	}
	/**
	 * @param insurTerm the insurTerm to set
	 */
	public void setInsurTerm(List<LongTermInsurancePlanCodeDTO> insurTerm) {
		InsurTerm = insurTerm;
	}
	/**
	 * @return the anntyPymTermList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymTermList() {
		return AnntyPymTermList;
	}
	/**
	 * @param anntyPymTermList the anntyPymTermList to set
	 */
	public void setAnntyPymTermList(List<LongAnntCommCodeDTO> anntyPymTermList) {
		AnntyPymTermList = anntyPymTermList;
	}
	/**
	 * @return the insurTermPaymTerm
	 */
	public List<LongAnntCommCodeDTO> getInsurTermPaymTerm() {
		return InsurTermPaymTerm;
	}
	/**
	 * @param insurTermPaymTerm the insurTermPaymTerm to set
	 */
	public void setInsurTermPaymTerm(List<LongAnntCommCodeDTO> insurTermPaymTerm) {
		InsurTermPaymTerm = insurTermPaymTerm;
	}
	/**
	 * @return the anntyPymCyclList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymCyclList() {
		return AnntyPymCyclList;
	}
	/**
	 * @param anntyPymCyclList the anntyPymCyclList to set
	 */
	public void setAnntyPymCyclList(List<LongAnntCommCodeDTO> anntyPymCyclList) {
		AnntyPymCyclList = anntyPymCyclList;
	}
	/**
	 * @return the anntyOpnAgeList
	 */
	public List<LongAnntCommCodeDTO> getAnntyOpnAgeList() {
		return AnntyOpnAgeList;
	}
	/**
	 * @param anntyOpnAgeList the anntyOpnAgeList to set
	 */
	public void setAnntyOpnAgeList(List<LongAnntCommCodeDTO> anntyOpnAgeList) {
		AnntyOpnAgeList = anntyOpnAgeList;
	}
	/**
	 * @return the anntyPymTypeList
	 */
	public List<LongAnntCommCodeDTO> getAnntyPymTypeList() {
		return AnntyPymTypeList;
	}
	/**
	 * @param anntyPymTypeList the anntyPymTypeList to set
	 */
	public void setAnntyPymTypeList(List<LongAnntCommCodeDTO> anntyPymTypeList) {
		AnntyPymTypeList = anntyPymTypeList;
	}
	/**
	 * @return the paymCyclCdList
	 */
	public List<LongAnntCommCodeDTO> getPaymCyclCdList() {
		return paymCyclCdList;
	}
	/**
	 * @param paymCyclCdList the paymCyclCdList to set
	 */
	public void setPaymCyclCdList(List<LongAnntCommCodeDTO> paymCyclCdList) {
		this.paymCyclCdList = paymCyclCdList;
	}
	
	
}
