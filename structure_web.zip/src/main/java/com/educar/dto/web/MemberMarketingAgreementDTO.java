/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �����õ���(WEBDD36)
 * 
 * @author ������
 * 
 */
public class MemberMarketingAgreementDTO {
	/** ȸ����ȣ(auto increment�� �ǹ̾��� ID) **/
	private long ID;
	/** ����ȸ�� **/
	private int nModiNo;
	/** ��Ʈ **/
	private String sLast;
	/** ���� ���� ����, s04AgmYn �� s41AgmYn �� �Ѵ� Y�϶��� Y **/
	private String sAgmYn;
	/** ��ǰ�Ұ� �����̿� ���� **/
	private String s04AgmYn;
	/** ��ǰ�Ұ� �����̿� ��ȭ�ź� **/
	private String s04CallReject;
	/** ��ǰ�Ұ� �����̿� DM�ź� **/
	private String s04DMReject;
	/** ��ǰ�Ұ� �����̿� FAX�ź� **/
	private String s04FaxReject;
	/** ��ǰ�Ұ� �����̿� EMAIL�ź� **/
	private String s04EmailReject;
	/** ��ǰ�Ұ� �����̿� SMS�ź� **/
	private String s04SMSReject;
	/** �̿븸���� **/
	private String s04UseEndDate;
	/** ��ǰ�Ұ� ���� ���� **/
	private String s41AgmYn;
	/** ��ǰ�Ұ� ���� ��ȭ�ź� **/
	private String s41CallReject;
	/** ��ǰ�Ұ� ���� DM�ź� **/
	private String s41DMReject;
	/** ��ǰ�Ұ� ���� FAX�ź� **/
	private String s41FaxReject;
	/** ��ǰ�Ұ� ���� EMAIL�ź� **/
	private String s41EmailReject;
	/** ��ǰ�Ұ� ���� SMS�ź� **/
	private String s41SMSReject;
	/** �̿븸���� **/
	private String s41UseEndDate;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;

	/**
	 * @return the iD
	 */
	public long getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final long iD) {
		ID = iD;
	}

	/**
	 * @return the nModiNo
	 */
	public int getnModiNo() {
		return nModiNo;
	}

	/**
	 * @param nModiNo the nModiNo to set
	 */
	public void setnModiNo(final int nModiNo) {
		this.nModiNo = nModiNo;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @return the s04AgmYn
	 */
	public String getS04AgmYn() {
		return s04AgmYn;
	}

	/**
	 * @param s04AgmYn the s04AgmYn to set
	 */
	public void setS04AgmYn(final String s04AgmYn) {
		this.s04AgmYn = s04AgmYn;
	}

	/**
	 * @return the s04CallReject
	 */
	public String getS04CallReject() {
		return s04CallReject;
	}

	/**
	 * @param s04CallReject the s04CallReject to set
	 */
	public void setS04CallReject(final String s04CallReject) {
		this.s04CallReject = s04CallReject;
	}

	/**
	 * @return the s04DMReject
	 */
	public String getS04DMReject() {
		return s04DMReject;
	}

	/**
	 * @param s04dmReject the s04DMReject to set
	 */
	public void setS04DMReject(final String s04dmReject) {
		s04DMReject = s04dmReject;
	}

	/**
	 * @return the s04FaxReject
	 */
	public String getS04FaxReject() {
		return s04FaxReject;
	}

	/**
	 * @param s04FaxReject the s04FaxReject to set
	 */
	public void setS04FaxReject(final String s04FaxReject) {
		this.s04FaxReject = s04FaxReject;
	}

	/**
	 * @return the s04EmailReject
	 */
	public String getS04EmailReject() {
		return s04EmailReject;
	}

	/**
	 * @param s04EmailReject the s04EmailReject to set
	 */
	public void setS04EmailReject(final String s04EmailReject) {
		this.s04EmailReject = s04EmailReject;
	}

	/**
	 * @return the s04SMSReject
	 */
	public String getS04SMSReject() {
		return s04SMSReject;
	}

	/**
	 * @param s04smsReject the s04SMSReject to set
	 */
	public void setS04SMSReject(final String s04smsReject) {
		s04SMSReject = s04smsReject;
	}

	/**
	 * @return the s41AgmYn
	 */
	public String getS41AgmYn() {
		return s41AgmYn;
	}

	/**
	 * @param s41AgmYn the s41AgmYn to set
	 */
	public void setS41AgmYn(final String s41AgmYn) {
		this.s41AgmYn = s41AgmYn;
	}

	/**
	 * @return the s41CallReject
	 */
	public String getS41CallReject() {
		return s41CallReject;
	}

	/**
	 * @param s41CallReject the s41CallReject to set
	 */
	public void setS41CallReject(final String s41CallReject) {
		this.s41CallReject = s41CallReject;
	}

	/**
	 * @return the s41DMReject
	 */
	public String getS41DMReject() {
		return s41DMReject;
	}

	/**
	 * @param s41dmReject the s41DMReject to set
	 */
	public void setS41DMReject(final String s41dmReject) {
		s41DMReject = s41dmReject;
	}

	/**
	 * @return the s41FaxReject
	 */
	public String getS41FaxReject() {
		return s41FaxReject;
	}

	/**
	 * @param s41FaxReject the s41FaxReject to set
	 */
	public void setS41FaxReject(final String s41FaxReject) {
		this.s41FaxReject = s41FaxReject;
	}

	/**
	 * @return the s41EmailReject
	 */
	public String getS41EmailReject() {
		return s41EmailReject;
	}

	/**
	 * @param s41EmailReject the s41EmailReject to set
	 */
	public void setS41EmailReject(final String s41EmailReject) {
		this.s41EmailReject = s41EmailReject;
	}

	/**
	 * @return the s41SMSReject
	 */
	public String getS41SMSReject() {
		return s41SMSReject;
	}

	/**
	 * @param s41smsReject the s41SMSReject to set
	 */
	public void setS41SMSReject(final String s41smsReject) {
		s41SMSReject = s41smsReject;
	}

	/**
	 * @return the s04UseEndDate
	 */
	public String getS04UseEndDate() {
		return s04UseEndDate;
	}

	/**
	 * @param s04UseEndDate the s04UseEndDate to set
	 */
	public void setS04UseEndDate(final String s04UseEndDate) {
		this.s04UseEndDate = s04UseEndDate;
	}

	/**
	 * @return the s41UseEndDate
	 */
	public String getS41UseEndDate() {
		return s41UseEndDate;
	}

	/**
	 * @param s41UseEndDate the s41UseEndDate to set
	 */
	public void setS41UseEndDate(final String s41UseEndDate) {
		this.s41UseEndDate = s41UseEndDate;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the sAgmYn
	 */
	public String getsAgmYn() {
		return sAgmYn;
	}

	/**
	 * @param sAgmYn the sAgmYn to set
	 */
	public void setsAgmYn(final String sAgmYn) {
		this.sAgmYn = sAgmYn;
	}

}
