/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.payment;

import kr.co.conch.validator.annotation.length.TypeEnum;
import kr.co.conch.validator.annotation.length.ValidateLength;

import org.joda.time.DateTime;

/**
 * ������ ��ȸ�� ���Ǵ� ACCZA31 hashkey�� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
public class AccountQueryACCDTO {

	/** �������� **/
	private String sSendDate;
	/** �����ڵ� **/
	@ValidateLength(type = TypeEnum.NUMBER, max = 3, required = true)
	private String sBankCode;
	/** ���������ڵ� **/
	private String sMainDealType;
	/** ���������ڵ� **/
	private String sSubDealType;
	/** ���۽ð� **/
	private String sInputTime;
	/** �����ID **/
	private String sUserID;
	/** �Ⱓ�� ������ insert **/
	private String sRowType;

	/**
	 * default constructor
	 * �Ⱓ�� �⺻ ����, �ð����� �������ش�
	 */
	public AccountQueryACCDTO() {
		this.setsSendDate(DateTime.now().toString("yyyyMMdd"));
		this.setsInputTime(DateTime.now().toString("HHmmss"));
		// �Ⱓ�� ������
		this.setsMainDealType("0600");
		this.setsSubDealType("600");
		this.setsRowType("insert");
	}

	/**
	 * @return the sSendDate
	 */
	public String getsSendDate() {
		return sSendDate;
	}

	/**
	 * @return the sBankCode
	 */
	public String getsBankCode() {
		return sBankCode;
	}

	/**
	 * @return the sMainDealType
	 */
	public String getsMainDealType() {
		return sMainDealType;
	}

	/**
	 * @return the sSubDealType
	 */
	public String getsSubDealType() {
		return sSubDealType;
	}

	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sSendDate the sSendDate to set
	 */
	public void setsSendDate(final String sSendDate) {
		this.sSendDate = sSendDate;
	}

	/**
	 * @param sBankCode the sBankCode to set
	 */
	public void setsBankCode(final String sBankCode) {
		this.sBankCode = sBankCode;
	}

	/**
	 * @param sMainDealType the sMainDealType to set
	 */
	public void setsMainDealType(final String sMainDealType) {
		this.sMainDealType = sMainDealType;
	}

	/**
	 * @param sSubDealType the sSubDealType to set
	 */
	public void setsSubDealType(final String sSubDealType) {
		this.sSubDealType = sSubDealType;
	}

	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(final String sInputTime) {
		this.sInputTime = sInputTime;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(final String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the sRowType
	 */
	public String getsRowType() {
		return sRowType;
	}

	/**
	 * @param sRowType the sRowType to set
	 */
	public void setsRowType(final String sRowType) {
		this.sRowType = sRowType;
	}

}
