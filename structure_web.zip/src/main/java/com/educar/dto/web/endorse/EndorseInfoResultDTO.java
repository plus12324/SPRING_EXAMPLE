/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �ּ�ȯ(David SW Choi) 
 *
 */
@XmlRootElement(name = "endorseInfoResultDTO")
public class EndorseInfoResultDTO {
	/** �����ڵ� ('00' �� �ƴϸ� �輭�Ұ���) **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** û����� **/
	private String sApplyStat;
	/** �輭������ **/
	private String sEndorseFmdt1;
	/** ���� �������� **/
	private String sBefCarInfo;
	/** ���� �������� **/
	private String sAftCarInfo;
	/** ���и�1 **/
	private String sColumnName1;
	/** ����1 **/
	private String sBefCodeName1;
	/** ����1 **/
	private String sAftCodeName1;
	/** ���и�2 **/
	private String sColumnName2;
	/** ����2 **/
	private String sBefCodeName2;
	/** ����2 **/
	private String sAftCodeName2;
	/** ���и�3 **/
	private String sColumnName3;
	/** ����3 **/
	private String sBefCodeName3;
	/** ����3 **/
	private String sAftCodeName3;
	/** ���и�4 **/
	private String sColumnName4;
	/** ����4 **/
	private String sBefCodeName4;
	/** ����4 **/
	private String sAftCodeName4;
	/** ���и�5 **/
	private String sColumnName5;
	/** ����5 **/
	private String sBefCodeName5;
	/** ����5 **/
	private String sAftCodeName5;
	/** ���и�6 **/
	private String sColumnName6;
	/** ����6 **/
	private String sBefCodeName6;
	/** ����6 **/
	private String sAftCodeName6;
	/** ���и�7 **/
	private String sColumnName7;
	/** ����7 **/
	private String sBefCodeName7;
	/** ����7 **/
	private String sAftCodeName7;
	/** ���и�8 **/
	private String sColumnName8;
	/** ����8 **/
	private String sBefCodeName8;
	/** ����8 **/
	private String sAftCodeName8;
	/** ���и�9 **/
	private String sColumnName9;
	/** ����9 **/
	private String sBefCodeName9;
	/** ����9 **/
	private String sAftCodeName9;
	/** ���и�10 **/
	private String sColumnName10;
	/** ����10 **/
	private String sBefCodeName10;
	/** ����10 **/
	private String sAftCodeName10;
	/** ���и�11 **/
	private String sColumnName11;
	/** ����11 **/
	private String sBefCodeName11;
	/** ����11 **/
	private String sAftCodeName11;
	/** ���и�12 **/
	private String sColumnName12;
	/** ����12 **/
	private String sBefCodeName12;
	/** ����12 **/
	private String sAftCodeName12;
	/** ���и�13 **/
	private String sColumnName13;
	/** ����13 **/
	private String sBefCodeName13;
	/** ����13 **/
	private String sAftCodeName13;
	/** ���и�14 **/
	private String sColumnName14;
	/** ����14 **/
	private String sBefCodeName14;
	/** ����14 **/
	private String sAftCodeName14;
	/** ���и�15 **/
	private String sColumnName15;
	/** ����15 **/
	private String sBefCodeName15;
	/** ����15 **/
	private String sAftCodeName15;
	/** ���и�16 **/
	private String sColumnName16;
	/** ����16 **/
	private String sBefCodeName16;
	/** ����16 **/
	private String sAftCodeName16;
	/** ���и�17 **/
	private String sColumnName17;
	/** ����17 **/
	private String sBefCodeName17;
	/** ����17 **/
	private String sAftCodeName17;
	/** ��������� (���纸����) **/
	private String befTotPrem;
	/** �߰����κ���� **/
	private String befAddPrem;
	/** ȯ�޺���� **/
	private String befRefundPrem;
	/** ��������� (���纸����) **/
	private String aftTotPrem;
	/** �߰����κ���� **/
	private String aftAddPrem;
	/** ȯ�޺���� **/
	private String aftRefundPrem;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sApplyStat
	 */
	public String getsApplyStat() {
		return sApplyStat;
	}

	/**
	 * @param sApplyStat the sApplyStat to set
	 */
	public void setsApplyStat(final String sApplyStat) {
		this.sApplyStat = sApplyStat;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	/**
	 * @return the sBefCarInfo
	 */
	public String getsBefCarInfo() {
		return sBefCarInfo;
	}

	/**
	 * @param sBefCarInfo the sBefCarInfo to set
	 */
	public void setsBefCarInfo(final String sBefCarInfo) {
		this.sBefCarInfo = sBefCarInfo;
	}

	/**
	 * @return the sAftCarInfo
	 */
	public String getsAftCarInfo() {
		return sAftCarInfo;
	}

	/**
	 * @param sAftCarInfo the sAftCarInfo to set
	 */
	public void setsAftCarInfo(final String sAftCarInfo) {
		this.sAftCarInfo = sAftCarInfo;
	}

	/**
	 * @return the sColumnName1
	 */
	public String getsColumnName1() {
		return sColumnName1;
	}

	/**
	 * @param sColumnName1 the sColumnName1 to set
	 */
	public void setsColumnName1(final String sColumnName1) {
		this.sColumnName1 = sColumnName1;
	}

	/**
	 * @return the sBefCodeName1
	 */
	public String getsBefCodeName1() {
		return sBefCodeName1;
	}

	/**
	 * @param sBefCodeName1 the sBefCodeName1 to set
	 */
	public void setsBefCodeName1(final String sBefCodeName1) {
		this.sBefCodeName1 = sBefCodeName1;
	}

	/**
	 * @return the sAftCodeName1
	 */
	public String getsAftCodeName1() {
		return sAftCodeName1;
	}

	/**
	 * @param sAftCodeName1 the sAftCodeName1 to set
	 */
	public void setsAftCodeName1(final String sAftCodeName1) {
		this.sAftCodeName1 = sAftCodeName1;
	}

	/**
	 * @return the sColumnName2
	 */
	public String getsColumnName2() {
		return sColumnName2;
	}

	/**
	 * @param sColumnName2 the sColumnName2 to set
	 */
	public void setsColumnName2(final String sColumnName2) {
		this.sColumnName2 = sColumnName2;
	}

	/**
	 * @return the sBefCodeName2
	 */
	public String getsBefCodeName2() {
		return sBefCodeName2;
	}

	/**
	 * @param sBefCodeName2 the sBefCodeName2 to set
	 */
	public void setsBefCodeName2(final String sBefCodeName2) {
		this.sBefCodeName2 = sBefCodeName2;
	}

	/**
	 * @return the sAftCodeName2
	 */
	public String getsAftCodeName2() {
		return sAftCodeName2;
	}

	/**
	 * @param sAftCodeName2 the sAftCodeName2 to set
	 */
	public void setsAftCodeName2(final String sAftCodeName2) {
		this.sAftCodeName2 = sAftCodeName2;
	}

	/**
	 * @return the sColumnName3
	 */
	public String getsColumnName3() {
		return sColumnName3;
	}

	/**
	 * @param sColumnName3 the sColumnName3 to set
	 */
	public void setsColumnName3(final String sColumnName3) {
		this.sColumnName3 = sColumnName3;
	}

	/**
	 * @return the sBefCodeName3
	 */
	public String getsBefCodeName3() {
		return sBefCodeName3;
	}

	/**
	 * @param sBefCodeName3 the sBefCodeName3 to set
	 */
	public void setsBefCodeName3(final String sBefCodeName3) {
		this.sBefCodeName3 = sBefCodeName3;
	}

	/**
	 * @return the sAftCodeName3
	 */
	public String getsAftCodeName3() {
		return sAftCodeName3;
	}

	/**
	 * @param sAftCodeName3 the sAftCodeName3 to set
	 */
	public void setsAftCodeName3(final String sAftCodeName3) {
		this.sAftCodeName3 = sAftCodeName3;
	}

	/**
	 * @return the sColumnName4
	 */
	public String getsColumnName4() {
		return sColumnName4;
	}

	/**
	 * @param sColumnName4 the sColumnName4 to set
	 */
	public void setsColumnName4(final String sColumnName4) {
		this.sColumnName4 = sColumnName4;
	}

	/**
	 * @return the sBefCodeName4
	 */
	public String getsBefCodeName4() {
		return sBefCodeName4;
	}

	/**
	 * @param sBefCodeName4 the sBefCodeName4 to set
	 */
	public void setsBefCodeName4(final String sBefCodeName4) {
		this.sBefCodeName4 = sBefCodeName4;
	}

	/**
	 * @return the sAftCodeName4
	 */
	public String getsAftCodeName4() {
		return sAftCodeName4;
	}

	/**
	 * @param sAftCodeName4 the sAftCodeName4 to set
	 */
	public void setsAftCodeName4(final String sAftCodeName4) {
		this.sAftCodeName4 = sAftCodeName4;
	}

	/**
	 * @return the sColumnName5
	 */
	public String getsColumnName5() {
		return sColumnName5;
	}

	/**
	 * @param sColumnName5 the sColumnName5 to set
	 */
	public void setsColumnName5(final String sColumnName5) {
		this.sColumnName5 = sColumnName5;
	}

	/**
	 * @return the sBefCodeName5
	 */
	public String getsBefCodeName5() {
		return sBefCodeName5;
	}

	/**
	 * @param sBefCodeName5 the sBefCodeName5 to set
	 */
	public void setsBefCodeName5(final String sBefCodeName5) {
		this.sBefCodeName5 = sBefCodeName5;
	}

	/**
	 * @return the sAftCodeName5
	 */
	public String getsAftCodeName5() {
		return sAftCodeName5;
	}

	/**
	 * @param sAftCodeName5 the sAftCodeName5 to set
	 */
	public void setsAftCodeName5(final String sAftCodeName5) {
		this.sAftCodeName5 = sAftCodeName5;
	}

	/**
	 * @return the sColumnName6
	 */
	public String getsColumnName6() {
		return sColumnName6;
	}

	/**
	 * @param sColumnName6 the sColumnName6 to set
	 */
	public void setsColumnName6(final String sColumnName6) {
		this.sColumnName6 = sColumnName6;
	}

	/**
	 * @return the sBefCodeName6
	 */
	public String getsBefCodeName6() {
		return sBefCodeName6;
	}

	/**
	 * @param sBefCodeName6 the sBefCodeName6 to set
	 */
	public void setsBefCodeName6(final String sBefCodeName6) {
		this.sBefCodeName6 = sBefCodeName6;
	}

	/**
	 * @return the sAftCodeName6
	 */
	public String getsAftCodeName6() {
		return sAftCodeName6;
	}

	/**
	 * @param sAftCodeName6 the sAftCodeName6 to set
	 */
	public void setsAftCodeName6(final String sAftCodeName6) {
		this.sAftCodeName6 = sAftCodeName6;
	}

	/**
	 * @return the sColumnName7
	 */
	public String getsColumnName7() {
		return sColumnName7;
	}

	/**
	 * @param sColumnName7 the sColumnName7 to set
	 */
	public void setsColumnName7(final String sColumnName7) {
		this.sColumnName7 = sColumnName7;
	}

	/**
	 * @return the sBefCodeName7
	 */
	public String getsBefCodeName7() {
		return sBefCodeName7;
	}

	/**
	 * @param sBefCodeName7 the sBefCodeName7 to set
	 */
	public void setsBefCodeName7(final String sBefCodeName7) {
		this.sBefCodeName7 = sBefCodeName7;
	}

	/**
	 * @return the sAftCodeName7
	 */
	public String getsAftCodeName7() {
		return sAftCodeName7;
	}

	/**
	 * @param sAftCodeName7 the sAftCodeName7 to set
	 */
	public void setsAftCodeName7(final String sAftCodeName7) {
		this.sAftCodeName7 = sAftCodeName7;
	}

	/**
	 * @return the sColumnName8
	 */
	public String getsColumnName8() {
		return sColumnName8;
	}

	/**
	 * @param sColumnName8 the sColumnName8 to set
	 */
	public void setsColumnName8(final String sColumnName8) {
		this.sColumnName8 = sColumnName8;
	}

	/**
	 * @return the sBefCodeName8
	 */
	public String getsBefCodeName8() {
		return sBefCodeName8;
	}

	/**
	 * @param sBefCodeName8 the sBefCodeName8 to set
	 */
	public void setsBefCodeName8(final String sBefCodeName8) {
		this.sBefCodeName8 = sBefCodeName8;
	}

	/**
	 * @return the sAftCodeName8
	 */
	public String getsAftCodeName8() {
		return sAftCodeName8;
	}

	/**
	 * @param sAftCodeName8 the sAftCodeName8 to set
	 */
	public void setsAftCodeName8(final String sAftCodeName8) {
		this.sAftCodeName8 = sAftCodeName8;
	}

	/**
	 * @return the sColumnName9
	 */
	public String getsColumnName9() {
		return sColumnName9;
	}

	/**
	 * @param sColumnName9 the sColumnName9 to set
	 */
	public void setsColumnName9(final String sColumnName9) {
		this.sColumnName9 = sColumnName9;
	}

	/**
	 * @return the sBefCodeName9
	 */
	public String getsBefCodeName9() {
		return sBefCodeName9;
	}

	/**
	 * @param sBefCodeName9 the sBefCodeName9 to set
	 */
	public void setsBefCodeName9(final String sBefCodeName9) {
		this.sBefCodeName9 = sBefCodeName9;
	}

	/**
	 * @return the sAftCodeName9
	 */
	public String getsAftCodeName9() {
		return sAftCodeName9;
	}

	/**
	 * @param sAftCodeName9 the sAftCodeName9 to set
	 */
	public void setsAftCodeName9(final String sAftCodeName9) {
		this.sAftCodeName9 = sAftCodeName9;
	}

	/**
	 * @return the sColumnName10
	 */
	public String getsColumnName10() {
		return sColumnName10;
	}

	/**
	 * @param sColumnName10 the sColumnName10 to set
	 */
	public void setsColumnName10(final String sColumnName10) {
		this.sColumnName10 = sColumnName10;
	}

	/**
	 * @return the sBefCodeName10
	 */
	public String getsBefCodeName10() {
		return sBefCodeName10;
	}

	/**
	 * @param sBefCodeName10 the sBefCodeName10 to set
	 */
	public void setsBefCodeName10(final String sBefCodeName10) {
		this.sBefCodeName10 = sBefCodeName10;
	}

	/**
	 * @return the sAftCodeName10
	 */
	public String getsAftCodeName10() {
		return sAftCodeName10;
	}

	/**
	 * @param sAftCodeName10 the sAftCodeName10 to set
	 */
	public void setsAftCodeName10(final String sAftCodeName10) {
		this.sAftCodeName10 = sAftCodeName10;
	}

	/**
	 * @return the sColumnName11
	 */
	public String getsColumnName11() {
		return sColumnName11;
	}

	/**
	 * @param sColumnName11 the sColumnName11 to set
	 */
	public void setsColumnName11(final String sColumnName11) {
		this.sColumnName11 = sColumnName11;
	}

	/**
	 * @return the sBefCodeName11
	 */
	public String getsBefCodeName11() {
		return sBefCodeName11;
	}

	/**
	 * @param sBefCodeName11 the sBefCodeName11 to set
	 */
	public void setsBefCodeName11(final String sBefCodeName11) {
		this.sBefCodeName11 = sBefCodeName11;
	}

	/**
	 * @return the sAftCodeName11
	 */
	public String getsAftCodeName11() {
		return sAftCodeName11;
	}

	/**
	 * @param sAftCodeName11 the sAftCodeName11 to set
	 */
	public void setsAftCodeName11(final String sAftCodeName11) {
		this.sAftCodeName11 = sAftCodeName11;
	}

	/**
	 * @return the sColumnName12
	 */
	public String getsColumnName12() {
		return sColumnName12;
	}

	/**
	 * @param sColumnName12 the sColumnName12 to set
	 */
	public void setsColumnName12(final String sColumnName12) {
		this.sColumnName12 = sColumnName12;
	}

	/**
	 * @return the sBefCodeName12
	 */
	public String getsBefCodeName12() {
		return sBefCodeName12;
	}

	/**
	 * @param sBefCodeName12 the sBefCodeName12 to set
	 */
	public void setsBefCodeName12(final String sBefCodeName12) {
		this.sBefCodeName12 = sBefCodeName12;
	}

	/**
	 * @return the sAftCodeName12
	 */
	public String getsAftCodeName12() {
		return sAftCodeName12;
	}

	/**
	 * @param sAftCodeName12 the sAftCodeName12 to set
	 */
	public void setsAftCodeName12(final String sAftCodeName12) {
		this.sAftCodeName12 = sAftCodeName12;
	}

	/**
	 * @return the sColumnName13
	 */
	public String getsColumnName13() {
		return sColumnName13;
	}

	/**
	 * @param sColumnName13 the sColumnName13 to set
	 */
	public void setsColumnName13(final String sColumnName13) {
		this.sColumnName13 = sColumnName13;
	}

	/**
	 * @return the sBefCodeName13
	 */
	public String getsBefCodeName13() {
		return sBefCodeName13;
	}

	/**
	 * @param sBefCodeName13 the sBefCodeName13 to set
	 */
	public void setsBefCodeName13(final String sBefCodeName13) {
		this.sBefCodeName13 = sBefCodeName13;
	}

	/**
	 * @return the sAftCodeName13
	 */
	public String getsAftCodeName13() {
		return sAftCodeName13;
	}

	/**
	 * @param sAftCodeName13 the sAftCodeName13 to set
	 */
	public void setsAftCodeName13(final String sAftCodeName13) {
		this.sAftCodeName13 = sAftCodeName13;
	}

	/**
	 * @return the sColumnName14
	 */
	public String getsColumnName14() {
		return sColumnName14;
	}

	/**
	 * @param sColumnName14 the sColumnName14 to set
	 */
	public void setsColumnName14(final String sColumnName14) {
		this.sColumnName14 = sColumnName14;
	}

	/**
	 * @return the sBefCodeName14
	 */
	public String getsBefCodeName14() {
		return sBefCodeName14;
	}

	/**
	 * @param sBefCodeName14 the sBefCodeName14 to set
	 */
	public void setsBefCodeName14(final String sBefCodeName14) {
		this.sBefCodeName14 = sBefCodeName14;
	}

	/**
	 * @return the sAftCodeName14
	 */
	public String getsAftCodeName14() {
		return sAftCodeName14;
	}

	/**
	 * @param sAftCodeName14 the sAftCodeName14 to set
	 */
	public void setsAftCodeName14(final String sAftCodeName14) {
		this.sAftCodeName14 = sAftCodeName14;
	}

	/**
	 * @return the sColumnName15
	 */
	public String getsColumnName15() {
		return sColumnName15;
	}

	/**
	 * @param sColumnName15 the sColumnName15 to set
	 */
	public void setsColumnName15(final String sColumnName15) {
		this.sColumnName15 = sColumnName15;
	}

	/**
	 * @return the sBefCodeName15
	 */
	public String getsBefCodeName15() {
		return sBefCodeName15;
	}

	/**
	 * @param sBefCodeName15 the sBefCodeName15 to set
	 */
	public void setsBefCodeName15(final String sBefCodeName15) {
		this.sBefCodeName15 = sBefCodeName15;
	}

	/**
	 * @return the sAftCodeName15
	 */
	public String getsAftCodeName15() {
		return sAftCodeName15;
	}

	/**
	 * @param sAftCodeName15 the sAftCodeName15 to set
	 */
	public void setsAftCodeName15(final String sAftCodeName15) {
		this.sAftCodeName15 = sAftCodeName15;
	}

	/**
	 * @return the sColumnName16
	 */
	public String getsColumnName16() {
		return sColumnName16;
	}

	/**
	 * @param sColumnName16 the sColumnName16 to set
	 */
	public void setsColumnName16(final String sColumnName16) {
		this.sColumnName16 = sColumnName16;
	}

	/**
	 * @return the sBefCodeName16
	 */
	public String getsBefCodeName16() {
		return sBefCodeName16;
	}

	/**
	 * @param sBefCodeName16 the sBefCodeName16 to set
	 */
	public void setsBefCodeName16(final String sBefCodeName16) {
		this.sBefCodeName16 = sBefCodeName16;
	}

	/**
	 * @return the sAftCodeName16
	 */
	public String getsAftCodeName16() {
		return sAftCodeName16;
	}

	/**
	 * @param sAftCodeName16 the sAftCodeName16 to set
	 */
	public void setsAftCodeName16(final String sAftCodeName16) {
		this.sAftCodeName16 = sAftCodeName16;
	}

	/**
	 * @return the sColumnName17
	 */
	public String getsColumnName17() {
		return sColumnName17;
	}

	/**
	 * @param sColumnName17 the sColumnName17 to set
	 */
	public void setsColumnName17(final String sColumnName17) {
		this.sColumnName17 = sColumnName17;
	}

	/**
	 * @return the sBefCodeName17
	 */
	public String getsBefCodeName17() {
		return sBefCodeName17;
	}

	/**
	 * @param sBefCodeName17 the sBefCodeName17 to set
	 */
	public void setsBefCodeName17(final String sBefCodeName17) {
		this.sBefCodeName17 = sBefCodeName17;
	}

	/**
	 * @return the sAftCodeName17
	 */
	public String getsAftCodeName17() {
		return sAftCodeName17;
	}

	/**
	 * @param sAftCodeName17 the sAftCodeName17 to set
	 */
	public void setsAftCodeName17(final String sAftCodeName17) {
		this.sAftCodeName17 = sAftCodeName17;
	}

	/**
	 * @return the befTotPrem
	 */
	public String getBefTotPrem() {
		return befTotPrem;
	}

	/**
	 * @param befTotPrem the befTotPrem to set
	 */
	public void setBefTotPrem(final String befTotPrem) {
		this.befTotPrem = befTotPrem;
	}

	/**
	 * @return the befAddPrem
	 */
	public String getBefAddPrem() {
		return befAddPrem;
	}

	/**
	 * @param befAddPrem the befAddPrem to set
	 */
	public void setBefAddPrem(final String befAddPrem) {
		this.befAddPrem = befAddPrem;
	}

	/**
	 * @return the befRefundPrem
	 */
	public String getBefRefundPrem() {
		return befRefundPrem;
	}

	/**
	 * @param befRefundPrem the befRefundPrem to set
	 */
	public void setBefRefundPrem(final String befRefundPrem) {
		this.befRefundPrem = befRefundPrem;
	}

	/**
	 * @return the aftTotPrem
	 */
	public String getAftTotPrem() {
		return aftTotPrem;
	}

	/**
	 * @param aftTotPrem the aftTotPrem to set
	 */
	public void setAftTotPrem(final String aftTotPrem) {
		this.aftTotPrem = aftTotPrem;
	}

	/**
	 * @return the aftAddPrem
	 */
	public String getAftAddPrem() {
		return aftAddPrem;
	}

	/**
	 * @param aftAddPrem the aftAddPrem to set
	 */
	public void setAftAddPrem(final String aftAddPrem) {
		this.aftAddPrem = aftAddPrem;
	}

	/**
	 * @return the aftRefundPrem
	 */
	public String getAftRefundPrem() {
		return aftRefundPrem;
	}

	/**
	 * @param aftRefundPrem the aftRefundPrem to set
	 */
	public void setAftRefundPrem(final String aftRefundPrem) {
		this.aftRefundPrem = aftRefundPrem;
	}

}
