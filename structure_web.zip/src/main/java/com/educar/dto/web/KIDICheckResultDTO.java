/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��&Car������ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "kIDICheckResultDTO")
public class KIDICheckResultDTO {
	/** ������ **/
	private String sFmdt;
	/** ������ **/
	private String sTodt;
	/** ����,����,����,���üũ ���� (Y,N) **/
	private String KidiCheck;
	/** ���� (���ɿ���:988) **/
	private String nAge;
	/** ����üũ (Y,N) **/
	private String nAgeCheck;
	/** ������������ **/
	private String sViolateCode;
	/** ������������ (Y,N) **/
	private String sViolateCodeCheck;
	/** ����Ǽ� **/
	private String reNewAccidCnt;
	/** ������� (Y,N) **/
	private String reNewAccidCntCheck;

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the kidiCheck
	 */
	public String getKidiCheck() {
		return KidiCheck;
	}

	/**
	 * @param kidiCheck the kidiCheck to set
	 */
	public void setKidiCheck(final String kidiCheck) {
		KidiCheck = kidiCheck;
	}

	/**
	 * @return the nAge
	 */
	public String getnAge() {
		return nAge;
	}

	/**
	 * @param nAge the nAge to set
	 */
	public void setnAge(final String nAge) {
		this.nAge = nAge;
	}

	/**
	 * @return the nAgeCheck
	 */
	public String getnAgeCheck() {
		return nAgeCheck;
	}

	/**
	 * @param nAgeCheck the nAgeCheck to set
	 */
	public void setnAgeCheck(final String nAgeCheck) {
		this.nAgeCheck = nAgeCheck;
	}

	/**
	 * @return the sViolateCode
	 */
	public String getsViolateCode() {
		return sViolateCode;
	}

	/**
	 * @param sViolateCode the sViolateCode to set
	 */
	public void setsViolateCode(final String sViolateCode) {
		this.sViolateCode = sViolateCode;
	}

	/**
	 * @return the sViolateCodeCheck
	 */
	public String getsViolateCodeCheck() {
		return sViolateCodeCheck;
	}

	/**
	 * @param sViolateCodeCheck the sViolateCodeCheck to set
	 */
	public void setsViolateCodeCheck(final String sViolateCodeCheck) {
		this.sViolateCodeCheck = sViolateCodeCheck;
	}

	/**
	 * @return the reNewAccidCnt
	 */
	public String getReNewAccidCnt() {
		return reNewAccidCnt;
	}

	/**
	 * @param reNewAccidCnt the reNewAccidCnt to set
	 */
	public void setReNewAccidCnt(final String reNewAccidCnt) {
		this.reNewAccidCnt = reNewAccidCnt;
	}

	/**
	 * @return the reNewAccidCntCheck
	 */
	public String getReNewAccidCntCheck() {
		return reNewAccidCntCheck;
	}

	/**
	 * @param reNewAccidCntCheck the reNewAccidCntCheck to set
	 */
	public void setReNewAccidCntCheck(final String reNewAccidCntCheck) {
		this.reNewAccidCntCheck = reNewAccidCntCheck;
	}

}
