/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.endorse;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * ����ī ���� : �輭 - ��ǰ���� ����
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "endorseInfoDTO")
public class EndorseInfoDTO {

	/** �����ڵ� **/
	private String sErrorCode;
	/** û���ȣ���� **/
	private String sApplyType;
	/** û���ȣ�⵵ **/
	private String sApplyYM;
	/** û���ȣSER **/
	private String sApplySer;
	/** �� �輭 �ڵ� **/
	private String sEndorseCodeForWeb;
	/** �輭 ������ **/
	private String sEndorseFmdt1;
	/** ����ñ� **/
	private String sFmdt;
	/** �������� **/
	private String sTodt;
	/** ������ **/
	private String sMadeComp;
	/** ��ǥ���� **/
	private String sCarName;
	/** �����⵵ **/
	private String sYear;
	/** �������� **/
	private String sCarName2;
	/** �ڵ������� **/
	private String nVehicleAmt;
	/** ���� �� �������� **/
	private String sCarInfo;
	/** ������ **/
	private String aircon;
	/** ī���׷��� **/
	private String stereo;
	/** ���� **/
	private String robbery;
	/** ������ġ **/
	private String abs;
	/** �ڵ����ӱ� **/
	private String trans;
	/** ����� **/
	private String airbag;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode1;
	/** �μ�ǰ �� **/
	private String sItemName1;
	/** �μ�ǰ ���� **/
	private String nItemAmt1;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode2;
	/** �μ�ǰ �� **/
	private String sItemName2;
	/** �μ�ǰ ���� **/
	private String nItemAmt2;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode3;
	/** �μ�ǰ �� **/
	private String sItemName3;
	/** �μ�ǰ ���� **/
	private String nItemAmt3;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode4;
	/** �μ�ǰ �� **/
	private String sItemName4;
	/** �μ�ǰ ���� **/
	private String nItemAmt4;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode5;
	/** �μ�ǰ �� **/
	private String sItemName5;
	/** �μ�ǰ ���� **/
	private String nItemAmt5;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode6;
	/** �μ�ǰ �� **/
	private String sItemName6;
	/** �μ�ǰ ���� **/
	private String nItemAmt6;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode7;
	/** �μ�ǰ �� **/
	private String sItemName7;
	/** �μ�ǰ ���� **/
	private String nItemAmt7;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode8;
	/** �μ�ǰ �� **/
	private String sItemName8;
	/** �μ�ǰ ���� **/
	private String nItemAmt8;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode9;
	/** �μ�ǰ �� **/
	private String sItemName9;
	/** �μ�ǰ ���� **/
	private String nItemAmt9;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode10;
	/** �μ�ǰ �� **/
	private String sItemName10;
	/** �μ�ǰ ���� **/
	private String nItemAmt10;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode11;
	/** �μ�ǰ �� **/
	private String sItemName11;
	/** �μ�ǰ ���� **/
	private String nItemAmt11;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode12;
	/** �μ�ǰ �� **/
	private String sItemName12;
	/** �μ�ǰ ���� **/
	private String nItemAmt12;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode13;
	/** �μ�ǰ �� **/
	private String sItemName13;
	/** �μ�ǰ ���� **/
	private String nItemAmt13;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode14;
	/** �μ�ǰ �� **/
	private String sItemName14;
	/** �μ�ǰ ���� **/
	private String nItemAmt14;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode15;
	/** �μ�ǰ �� **/
	private String sItemName15;
	/** �μ�ǰ ���� **/
	private String nItemAmt15;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode16;
	/** �μ�ǰ �� **/
	private String sItemName16;
	/** �μ�ǰ ���� **/
	private String nItemAmt16;
	/** �μ�ǰ �ڵ� **/
	private String sItemCode17;
	/** �μ�ǰ �� **/
	private String sItemName17;
	/** �μ�ǰ ���� **/
	private String nItemAmt17;
	/** �����ڽ� - ������ **/
	private String sBlackBoxMemo1;
	/** �����ڽ� - ��ǰ��ȣ **/
	private String sBlackBoxMemo2;
	/** �����ڽ� - ���θ𵨸� **/
	private String sBlackBoxMemo3;

	/**
	 * @return the sErrorCode
	 */
	public String getsErrorCode() {
		return sErrorCode;
	}

	/**
	 * @param sErrorCode the sErrorCode to set
	 */
	public void setsErrorCode(final String sErrorCode) {
		this.sErrorCode = sErrorCode;
	}

	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}

	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(final String sApplyType) {
		this.sApplyType = sApplyType;
	}

	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}

	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(final String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}

	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}

	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(final String sApplySer) {
		this.sApplySer = sApplySer;
	}

	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}

	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(final String sFmdt) {
		this.sFmdt = sFmdt;
	}

	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}

	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(final String sTodt) {
		this.sTodt = sTodt;
	}

	/**
	 * @return the sMadeComp
	 */
	public String getsMadeComp() {
		return sMadeComp;
	}

	/**
	 * @param sMadeComp the sMadeComp to set
	 */
	public void setsMadeComp(final String sMadeComp) {
		this.sMadeComp = sMadeComp;
	}

	/**
	 * @return the sCarName
	 */
	public String getsCarName() {
		return sCarName;
	}

	/**
	 * @param sCarName the sCarName to set
	 */
	public void setsCarName(final String sCarName) {
		this.sCarName = sCarName;
	}

	/**
	 * @return the sYear
	 */
	public String getsYear() {
		return sYear;
	}

	/**
	 * @param sYear the sYear to set
	 */
	public void setsYear(final String sYear) {
		this.sYear = sYear;
	}

	/**
	 * @return the sCarName2
	 */
	public String getsCarName2() {
		return sCarName2;
	}

	/**
	 * @param sCarName2 the sCarName2 to set
	 */
	public void setsCarName2(final String sCarName2) {
		this.sCarName2 = sCarName2;
	}

	/**
	 * @return the nVehicleAmt
	 */
	public String getnVehicleAmt() {
		return nVehicleAmt;
	}

	/**
	 * @param nVehicleAmt the nVehicleAmt to set
	 */
	public void setnVehicleAmt(final String nVehicleAmt) {
		this.nVehicleAmt = nVehicleAmt;
	}

	/**
	 * @return the sCarInfo
	 */
	public String getsCarInfo() {
		return sCarInfo;
	}

	/**
	 * @param sCarInfo the sCarInfo to set
	 */
	public void setsCarInfo(final String sCarInfo) {
		this.sCarInfo = sCarInfo;
	}

	/**
	 * @return the aircon
	 */
	public String getAircon() {
		return aircon;
	}

	/**
	 * @param aircon the aircon to set
	 */
	public void setAircon(final String aircon) {
		this.aircon = aircon;
	}

	/**
	 * @return the stereo
	 */
	public String getStereo() {
		return stereo;
	}

	/**
	 * @param stereo the stereo to set
	 */
	public void setStereo(final String stereo) {
		this.stereo = stereo;
	}

	/**
	 * @return the robbery
	 */
	public String getRobbery() {
		return robbery;
	}

	/**
	 * @param robbery the robbery to set
	 */
	public void setRobbery(final String robbery) {
		this.robbery = robbery;
	}

	/**
	 * @return the abs
	 */
	public String getAbs() {
		return abs;
	}

	/**
	 * @param abs the abs to set
	 */
	public void setAbs(final String abs) {
		this.abs = abs;
	}

	/**
	 * @return the trans
	 */
	public String getTrans() {
		return trans;
	}

	/**
	 * @param trans the trans to set
	 */
	public void setTrans(final String trans) {
		this.trans = trans;
	}

	/**
	 * @return the sItemCode1
	 */
	public String getsItemCode1() {
		return sItemCode1;
	}

	/**
	 * @param sItemCode1 the sItemCode1 to set
	 */
	public void setsItemCode1(final String sItemCode1) {
		this.sItemCode1 = sItemCode1;
	}

	/**
	 * @return the sItemName1
	 */
	public String getsItemName1() {
		return sItemName1;
	}

	/**
	 * @param sItemName1 the sItemName1 to set
	 */
	public void setsItemName1(final String sItemName1) {
		this.sItemName1 = sItemName1;
	}

	/**
	 * @return the nItemAmt1
	 */
	public String getnItemAmt1() {
		return nItemAmt1;
	}

	/**
	 * @param nItemAmt1 the nItemAmt1 to set
	 */
	public void setnItemAmt1(final String nItemAmt1) {
		this.nItemAmt1 = nItemAmt1;
	}

	/**
	 * @return the sItemCode2
	 */
	public String getsItemCode2() {
		return sItemCode2;
	}

	/**
	 * @param sItemCode2 the sItemCode2 to set
	 */
	public void setsItemCode2(final String sItemCode2) {
		this.sItemCode2 = sItemCode2;
	}

	/**
	 * @return the sItemName2
	 */
	public String getsItemName2() {
		return sItemName2;
	}

	/**
	 * @param sItemName2 the sItemName2 to set
	 */
	public void setsItemName2(final String sItemName2) {
		this.sItemName2 = sItemName2;
	}

	/**
	 * @return the nItemAmt2
	 */
	public String getnItemAmt2() {
		return nItemAmt2;
	}

	/**
	 * @param nItemAmt2 the nItemAmt2 to set
	 */
	public void setnItemAmt2(final String nItemAmt2) {
		this.nItemAmt2 = nItemAmt2;
	}

	/**
	 * @return the sItemCode3
	 */
	public String getsItemCode3() {
		return sItemCode3;
	}

	/**
	 * @param sItemCode3 the sItemCode3 to set
	 */
	public void setsItemCode3(final String sItemCode3) {
		this.sItemCode3 = sItemCode3;
	}

	/**
	 * @return the sItemName3
	 */
	public String getsItemName3() {
		return sItemName3;
	}

	/**
	 * @param sItemName3 the sItemName3 to set
	 */
	public void setsItemName3(final String sItemName3) {
		this.sItemName3 = sItemName3;
	}

	/**
	 * @return the nItemAmt3
	 */
	public String getnItemAmt3() {
		return nItemAmt3;
	}

	/**
	 * @param nItemAmt3 the nItemAmt3 to set
	 */
	public void setnItemAmt3(final String nItemAmt3) {
		this.nItemAmt3 = nItemAmt3;
	}

	/**
	 * @return the sItemCode4
	 */
	public String getsItemCode4() {
		return sItemCode4;
	}

	/**
	 * @param sItemCode4 the sItemCode4 to set
	 */
	public void setsItemCode4(final String sItemCode4) {
		this.sItemCode4 = sItemCode4;
	}

	/**
	 * @return the sItemName4
	 */
	public String getsItemName4() {
		return sItemName4;
	}

	/**
	 * @param sItemName4 the sItemName4 to set
	 */
	public void setsItemName4(final String sItemName4) {
		this.sItemName4 = sItemName4;
	}

	/**
	 * @return the nItemAmt4
	 */
	public String getnItemAmt4() {
		return nItemAmt4;
	}

	/**
	 * @param nItemAmt4 the nItemAmt4 to set
	 */
	public void setnItemAmt4(final String nItemAmt4) {
		this.nItemAmt4 = nItemAmt4;
	}

	/**
	 * @return the sItemCode5
	 */
	public String getsItemCode5() {
		return sItemCode5;
	}

	/**
	 * @param sItemCode5 the sItemCode5 to set
	 */
	public void setsItemCode5(final String sItemCode5) {
		this.sItemCode5 = sItemCode5;
	}

	/**
	 * @return the sItemName5
	 */
	public String getsItemName5() {
		return sItemName5;
	}

	/**
	 * @param sItemName5 the sItemName5 to set
	 */
	public void setsItemName5(final String sItemName5) {
		this.sItemName5 = sItemName5;
	}

	/**
	 * @return the nItemAmt5
	 */
	public String getnItemAmt5() {
		return nItemAmt5;
	}

	/**
	 * @param nItemAmt5 the nItemAmt5 to set
	 */
	public void setnItemAmt5(final String nItemAmt5) {
		this.nItemAmt5 = nItemAmt5;
	}

	/**
	 * @return the sItemCode6
	 */
	public String getsItemCode6() {
		return sItemCode6;
	}

	/**
	 * @param sItemCode6 the sItemCode6 to set
	 */
	public void setsItemCode6(final String sItemCode6) {
		this.sItemCode6 = sItemCode6;
	}

	/**
	 * @return the sItemName6
	 */
	public String getsItemName6() {
		return sItemName6;
	}

	/**
	 * @param sItemName6 the sItemName6 to set
	 */
	public void setsItemName6(final String sItemName6) {
		this.sItemName6 = sItemName6;
	}

	/**
	 * @return the nItemAmt6
	 */
	public String getnItemAmt6() {
		return nItemAmt6;
	}

	/**
	 * @param nItemAmt6 the nItemAmt6 to set
	 */
	public void setnItemAmt6(final String nItemAmt6) {
		this.nItemAmt6 = nItemAmt6;
	}

	/**
	 * @return the sItemCode7
	 */
	public String getsItemCode7() {
		return sItemCode7;
	}

	/**
	 * @param sItemCode7 the sItemCode7 to set
	 */
	public void setsItemCode7(final String sItemCode7) {
		this.sItemCode7 = sItemCode7;
	}

	/**
	 * @return the sItemName7
	 */
	public String getsItemName7() {
		return sItemName7;
	}

	/**
	 * @param sItemName7 the sItemName7 to set
	 */
	public void setsItemName7(final String sItemName7) {
		this.sItemName7 = sItemName7;
	}

	/**
	 * @return the nItemAmt7
	 */
	public String getnItemAmt7() {
		return nItemAmt7;
	}

	/**
	 * @param nItemAmt7 the nItemAmt7 to set
	 */
	public void setnItemAmt7(final String nItemAmt7) {
		this.nItemAmt7 = nItemAmt7;
	}

	/**
	 * @return the sItemCode8
	 */
	public String getsItemCode8() {
		return sItemCode8;
	}

	/**
	 * @param sItemCode8 the sItemCode8 to set
	 */
	public void setsItemCode8(final String sItemCode8) {
		this.sItemCode8 = sItemCode8;
	}

	/**
	 * @return the sItemName8
	 */
	public String getsItemName8() {
		return sItemName8;
	}

	/**
	 * @param sItemName8 the sItemName8 to set
	 */
	public void setsItemName8(final String sItemName8) {
		this.sItemName8 = sItemName8;
	}

	/**
	 * @return the nItemAmt8
	 */
	public String getnItemAmt8() {
		return nItemAmt8;
	}

	/**
	 * @param nItemAmt8 the nItemAmt8 to set
	 */
	public void setnItemAmt8(final String nItemAmt8) {
		this.nItemAmt8 = nItemAmt8;
	}

	/**
	 * @return the sItemCode9
	 */
	public String getsItemCode9() {
		return sItemCode9;
	}

	/**
	 * @param sItemCode9 the sItemCode9 to set
	 */
	public void setsItemCode9(final String sItemCode9) {
		this.sItemCode9 = sItemCode9;
	}

	/**
	 * @return the sItemName9
	 */
	public String getsItemName9() {
		return sItemName9;
	}

	/**
	 * @param sItemName9 the sItemName9 to set
	 */
	public void setsItemName9(final String sItemName9) {
		this.sItemName9 = sItemName9;
	}

	/**
	 * @return the nItemAmt9
	 */
	public String getnItemAmt9() {
		return nItemAmt9;
	}

	/**
	 * @param nItemAmt9 the nItemAmt9 to set
	 */
	public void setnItemAmt9(final String nItemAmt9) {
		this.nItemAmt9 = nItemAmt9;
	}

	/**
	 * @return the sItemCode10
	 */
	public String getsItemCode10() {
		return sItemCode10;
	}

	/**
	 * @param sItemCode10 the sItemCode10 to set
	 */
	public void setsItemCode10(final String sItemCode10) {
		this.sItemCode10 = sItemCode10;
	}

	/**
	 * @return the sItemName10
	 */
	public String getsItemName10() {
		return sItemName10;
	}

	/**
	 * @param sItemName10 the sItemName10 to set
	 */
	public void setsItemName10(final String sItemName10) {
		this.sItemName10 = sItemName10;
	}

	/**
	 * @return the nItemAmt10
	 */
	public String getnItemAmt10() {
		return nItemAmt10;
	}

	/**
	 * @param nItemAmt10 the nItemAmt10 to set
	 */
	public void setnItemAmt10(final String nItemAmt10) {
		this.nItemAmt10 = nItemAmt10;
	}

	/**
	 * @return the sItemCode11
	 */
	public String getsItemCode11() {
		return sItemCode11;
	}

	/**
	 * @param sItemCode11 the sItemCode11 to set
	 */
	public void setsItemCode11(final String sItemCode11) {
		this.sItemCode11 = sItemCode11;
	}

	/**
	 * @return the sItemName11
	 */
	public String getsItemName11() {
		return sItemName11;
	}

	/**
	 * @param sItemName11 the sItemName11 to set
	 */
	public void setsItemName11(final String sItemName11) {
		this.sItemName11 = sItemName11;
	}

	/**
	 * @return the nItemAmt11
	 */
	public String getnItemAmt11() {
		return nItemAmt11;
	}

	/**
	 * @param nItemAmt11 the nItemAmt11 to set
	 */
	public void setnItemAmt11(final String nItemAmt11) {
		this.nItemAmt11 = nItemAmt11;
	}

	/**
	 * @return the sItemCode12
	 */
	public String getsItemCode12() {
		return sItemCode12;
	}

	/**
	 * @param sItemCode12 the sItemCode12 to set
	 */
	public void setsItemCode12(final String sItemCode12) {
		this.sItemCode12 = sItemCode12;
	}

	/**
	 * @return the sItemName12
	 */
	public String getsItemName12() {
		return sItemName12;
	}

	/**
	 * @param sItemName12 the sItemName12 to set
	 */
	public void setsItemName12(final String sItemName12) {
		this.sItemName12 = sItemName12;
	}

	/**
	 * @return the nItemAmt12
	 */
	public String getnItemAmt12() {
		return nItemAmt12;
	}

	/**
	 * @param nItemAmt12 the nItemAmt12 to set
	 */
	public void setnItemAmt12(final String nItemAmt12) {
		this.nItemAmt12 = nItemAmt12;
	}

	/**
	 * @return the sItemCode13
	 */
	public String getsItemCode13() {
		return sItemCode13;
	}

	/**
	 * @param sItemCode13 the sItemCode13 to set
	 */
	public void setsItemCode13(final String sItemCode13) {
		this.sItemCode13 = sItemCode13;
	}

	/**
	 * @return the sItemName13
	 */
	public String getsItemName13() {
		return sItemName13;
	}

	/**
	 * @param sItemName13 the sItemName13 to set
	 */
	public void setsItemName13(final String sItemName13) {
		this.sItemName13 = sItemName13;
	}

	/**
	 * @return the nItemAmt13
	 */
	public String getnItemAmt13() {
		return nItemAmt13;
	}

	/**
	 * @param nItemAmt13 the nItemAmt13 to set
	 */
	public void setnItemAmt13(final String nItemAmt13) {
		this.nItemAmt13 = nItemAmt13;
	}

	/**
	 * @return the sItemCode14
	 */
	public String getsItemCode14() {
		return sItemCode14;
	}

	/**
	 * @param sItemCode14 the sItemCode14 to set
	 */
	public void setsItemCode14(final String sItemCode14) {
		this.sItemCode14 = sItemCode14;
	}

	/**
	 * @return the sItemName14
	 */
	public String getsItemName14() {
		return sItemName14;
	}

	/**
	 * @param sItemName14 the sItemName14 to set
	 */
	public void setsItemName14(final String sItemName14) {
		this.sItemName14 = sItemName14;
	}

	/**
	 * @return the nItemAmt14
	 */
	public String getnItemAmt14() {
		return nItemAmt14;
	}

	/**
	 * @param nItemAmt14 the nItemAmt14 to set
	 */
	public void setnItemAmt14(final String nItemAmt14) {
		this.nItemAmt14 = nItemAmt14;
	}

	/**
	 * @return the sItemCode15
	 */
	public String getsItemCode15() {
		return sItemCode15;
	}

	/**
	 * @param sItemCode15 the sItemCode15 to set
	 */
	public void setsItemCode15(final String sItemCode15) {
		this.sItemCode15 = sItemCode15;
	}

	/**
	 * @return the sItemName15
	 */
	public String getsItemName15() {
		return sItemName15;
	}

	/**
	 * @param sItemName15 the sItemName15 to set
	 */
	public void setsItemName15(final String sItemName15) {
		this.sItemName15 = sItemName15;
	}

	/**
	 * @return the nItemAmt15
	 */
	public String getnItemAmt15() {
		return nItemAmt15;
	}

	/**
	 * @param nItemAmt15 the nItemAmt15 to set
	 */
	public void setnItemAmt15(final String nItemAmt15) {
		this.nItemAmt15 = nItemAmt15;
	}

	/**
	 * @return the sItemCode16
	 */
	public String getsItemCode16() {
		return sItemCode16;
	}

	/**
	 * @param sItemCode16 the sItemCode16 to set
	 */
	public void setsItemCode16(final String sItemCode16) {
		this.sItemCode16 = sItemCode16;
	}

	/**
	 * @return the sItemName16
	 */
	public String getsItemName16() {
		return sItemName16;
	}

	/**
	 * @param sItemName16 the sItemName16 to set
	 */
	public void setsItemName16(final String sItemName16) {
		this.sItemName16 = sItemName16;
	}

	/**
	 * @return the nItemAmt16
	 */
	public String getnItemAmt16() {
		return nItemAmt16;
	}

	/**
	 * @param nItemAmt16 the nItemAmt16 to set
	 */
	public void setnItemAmt16(final String nItemAmt16) {
		this.nItemAmt16 = nItemAmt16;
	}

	/**
	 * @return the sItemCode17
	 */
	public String getsItemCode17() {
		return sItemCode17;
	}

	/**
	 * @param sItemCode17 the sItemCode17 to set
	 */
	public void setsItemCode17(final String sItemCode17) {
		this.sItemCode17 = sItemCode17;
	}

	/**
	 * @return the sItemName17
	 */
	public String getsItemName17() {
		return sItemName17;
	}

	/**
	 * @param sItemName17 the sItemName17 to set
	 */
	public void setsItemName17(final String sItemName17) {
		this.sItemName17 = sItemName17;
	}

	/**
	 * @return the nItemAmt17
	 */
	public String getnItemAmt17() {
		return nItemAmt17;
	}

	/**
	 * @param nItemAmt17 the nItemAmt17 to set
	 */
	public void setnItemAmt17(final String nItemAmt17) {
		this.nItemAmt17 = nItemAmt17;
	}

	/**
	 * @return the sBlackBoxMemo1
	 */
	public String getsBlackBoxMemo1() {
		return sBlackBoxMemo1;
	}

	/**
	 * @param sBlackBoxMemo1 the sBlackBoxMemo1 to set
	 */
	public void setsBlackBoxMemo1(final String sBlackBoxMemo1) {
		this.sBlackBoxMemo1 = sBlackBoxMemo1;
	}

	/**
	 * @return the sBlackBoxMemo2
	 */
	public String getsBlackBoxMemo2() {
		return sBlackBoxMemo2;
	}

	/**
	 * @param sBlackBoxMemo2 the sBlackBoxMemo2 to set
	 */
	public void setsBlackBoxMemo2(final String sBlackBoxMemo2) {
		this.sBlackBoxMemo2 = sBlackBoxMemo2;
	}

	/**
	 * @return the sBlackBoxMemo3
	 */
	public String getsBlackBoxMemo3() {
		return sBlackBoxMemo3;
	}

	/**
	 * @param sBlackBoxMemo3 the sBlackBoxMemo3 to set
	 */
	public void setsBlackBoxMemo3(final String sBlackBoxMemo3) {
		this.sBlackBoxMemo3 = sBlackBoxMemo3;
	}

	/**
	 * @return the sEndorseCodeForWeb
	 */
	public String getsEndorseCodeForWeb() {
		return sEndorseCodeForWeb;
	}

	/**
	 * @param sEndorseCodeForWeb the sEndorseCodeForWeb to set
	 */
	public void setsEndorseCodeForWeb(final String sEndorseCodeForWeb) {
		this.sEndorseCodeForWeb = sEndorseCodeForWeb;
	}

	/**
	 * @return the sEndorseFmdt1
	 */
	public String getsEndorseFmdt1() {
		return sEndorseFmdt1;
	}

	/**
	 * @param sEndorseFmdt1 the sEndorseFmdt1 to set
	 */
	public void setsEndorseFmdt1(final String sEndorseFmdt1) {
		this.sEndorseFmdt1 = sEndorseFmdt1;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the airbag
	 */
	public String getAirbag() {
		return airbag;
	}

	/**
	 * @param airbag the airbag to set
	 */
	public void setAirbag(final String airbag) {
		this.airbag = airbag;
	}
}
