/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ���������� ����������� ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "selectAccidentListWebResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SelectAccidentListWebResultDTO {
	/** �����ȣ **/
	private String sAccidentNo;
	/** ����Ͻ� **/
	private String sAcctDate;
	/** �����ҿ�����ȣ1 **/
	private String sAcctZip1;
	/** �����ҿ�����ȣ2 **/
	private String sAcctZip2;
	/** �����ҿ�����ȣ ȭ��ǥ�ÿ� **/
	private String acctZip;
	/** �뺸�ڸ� **/
	private String sInformerName;
	/** ��������Ͻ� **/
	private String sAcctRegiDate;
	/** �������ּ�1 **/
	private String sAcctAddr1;
	/** �������ּ�2 **/
	private String sAcctAddr2;
	/** �������ּ� ȭ��ǥ�ÿ� **/
	private String acctAddress;
	/** ����� �̹����� ��Ʈ ȸ��+1 **/
	private String maxRegiNo;
	/** ������� */
	private String sAcctStatus;
	/** �������, �����ļջ��� file ID ����Ʈ **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "fileIDList")
	private List<String> fileID;
	/** ��ϵ� file ID ����Ʈ **/
	@BeanUtil(ignore = true)
	@XmlElementWrapper(name = "sPictGbList")
	private List<String> sPictGb;

	/**
	 * @return the sPictGb
	 */
	public List<String> getsPictGb() {
		return sPictGb;
	}

	/**
	 * @param sPictGb the sPictGb to set
	 */
	public void setsPictGb(final List<String> sPictGb) {
		this.sPictGb = sPictGb;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctZip1
	 */
	public String getsAcctZip1() {
		return sAcctZip1;
	}

	/**
	 * @param sAcctZip1 the sAcctZip1 to set
	 */
	public void setsAcctZip1(final String sAcctZip1) {
		this.sAcctZip1 = sAcctZip1;
	}

	/**
	 * @return the sAcctZip2
	 */
	public String getsAcctZip2() {
		return sAcctZip2;
	}

	/**
	 * @param sAcctZip2 the sAcctZip2 to set
	 */
	public void setsAcctZip2(final String sAcctZip2) {
		this.sAcctZip2 = sAcctZip2;
	}

	/**
	 * @return the acctZip
	 */
	public String getAcctZip() {
		return acctZip;
	}

	/**
	 * @param acctZip the acctZip to set
	 */
	public void setAcctZip(final String acctZip) {
		this.acctZip = acctZip;
	}

	/**
	 * @return the sInformerName
	 */
	public String getsInformerName() {
		return sInformerName;
	}

	/**
	 * @param sInformerName the sInformerName to set
	 */
	public void setsInformerName(final String sInformerName) {
		this.sInformerName = sInformerName;
	}

	/**
	 * @return the sAcctRegiDate
	 */
	public String getsAcctRegiDate() {
		return sAcctRegiDate;
	}

	/**
	 * @param sAcctRegiDate the sAcctRegiDate to set
	 */
	public void setsAcctRegiDate(final String sAcctRegiDate) {
		this.sAcctRegiDate = sAcctRegiDate;
	}

	/**
	 * @return the sAcctAddr1
	 */
	public String getsAcctAddr1() {
		return sAcctAddr1;
	}

	/**
	 * @param sAcctAddr1 the sAcctAddr1 to set
	 */
	public void setsAcctAddr1(final String sAcctAddr1) {
		this.sAcctAddr1 = sAcctAddr1;
	}

	/**
	 * @return the sAcctAddr2
	 */
	public String getsAcctAddr2() {
		return sAcctAddr2;
	}

	/**
	 * @param sAcctAddr2 the sAcctAddr2 to set
	 */
	public void setsAcctAddr2(final String sAcctAddr2) {
		this.sAcctAddr2 = sAcctAddr2;
	}

	/**
	 * @return the acctAddress
	 */
	public String getAcctAddress() {
		return acctAddress;
	}

	/**
	 * @param acctAddress the acctAddress to set
	 */
	public void setAcctAddress(final String acctAddress) {
		this.acctAddress = acctAddress;
	}

	/**
	 * @return the maxRegiNo
	 */
	public String getMaxRegiNo() {
		return maxRegiNo;
	}

	/**
	 * @param maxRegiNo the maxRegiNo to set
	 */
	public void setMaxRegiNo(final String maxRegiNo) {
		this.maxRegiNo = maxRegiNo;
	}

	/**
	 * ������¸� ��ȯ�Ѵ�.
	 * @return �������
	 */
	public String getsAcctStatus() {
		return sAcctStatus;
	}

	/**
	 * ������¸� �����Ѵ�.
	 * @param sAcctStatus �������
	 */
	public void setsAcctStatus(final String sAcctStatus) {
		this.sAcctStatus = sAcctStatus;
	}

	/**
	 * @return the fileID
	 */
	public List<String> getFileID() {
		return fileID;
	}

	/**
	 * @param fileID the fileID to set
	 */
	public void setFileID(final List<String> fileID) {
		this.fileID = fileID;
	}

}
