/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * OBD DTO
 * 
 * @author ������
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "oDBResultDTO")
public class OBDResultDTO {
	/** ����ȣ **/
	private String sPolicyNo;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** �ڵ�(�ֹε�Ϲ�ȣ) **/
	private String sInsrdID;
	/** ������ȣ **/
	private String sPlateNo;
	/** ���� **/
	private String sCarName;
	/** ����ñ� **/
	private String sSpecFmdt;
	/** �������� **/
	private String sSpecTodt;
	/** �������� **/
	private String sWeelDay;
	/** ������ **/
	private String sPolicyStat;

	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}

	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(final String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sCarName
	 */
	public String getsCarName() {
		return sCarName;
	}

	/**
	 * @param sCarName the sCarName to set
	 */
	public void setsCarName(final String sCarName) {
		this.sCarName = sCarName;
	}

	/**
	 * @return the sSpecFmdt
	 */
	public String getsSpecFmdt() {
		return sSpecFmdt;
	}

	/**
	 * @param sSpecFmdt the sSpecFmdt to set
	 */
	public void setsSpecFmdt(final String sSpecFmdt) {
		this.sSpecFmdt = sSpecFmdt;
	}

	/**
	 * @return the sSpecTodt
	 */
	public String getsSpecTodt() {
		return sSpecTodt;
	}

	/**
	 * @param sSpecTodt the sSpecTodt to set
	 */
	public void setsSpecTodt(final String sSpecTodt) {
		this.sSpecTodt = sSpecTodt;
	}

	/**
	 * @return the sWeelDay
	 */
	public String getsWeelDay() {
		return sWeelDay;
	}

	/**
	 * @param sWeelDay the sWeelDay to set
	 */
	public void setsWeelDay(final String sWeelDay) {
		this.sWeelDay = sWeelDay;
	}

	/**
	 * @return the sPolicyStat
	 */
	public String getsPolicyStat() {
		return sPolicyStat;
	}

	/**
	 * @param sPolicyStat the sPolicyStat to set
	 */
	public void setsPolicyStat(final String sPolicyStat) {
		this.sPolicyStat = sPolicyStat;
	}

}
