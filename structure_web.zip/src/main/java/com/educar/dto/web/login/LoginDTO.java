/*-
 * Copyright (c) 2012, Conch
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.educar.dto.web.login;

import javax.xml.bind.annotation.XmlRootElement;

import kr.co.conch.validator.annotation.bytes.CharacterSet;
import kr.co.conch.validator.annotation.bytes.ValidateByte;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * @author �ּ�ȯ(David SW Choi)
 * 
 */
@XmlRootElement(name = "loginDTO")
public class LoginDTO {
	/** ID(auto increment�� �ǹ̾��� ID) **/
	private long ID;
	/** �ֹι�ȣ **/
	@ValidateByte(max = 15, charset = CharacterSet.EUCKR)
	private String sCustNo;
	/** �̸� **/
	@ValidateByte(max = 20, charset = CharacterSet.EUCKR)
	private String sName;
	/** ������� **/
	@ValidateByte(max = 8, charset = CharacterSet.EUCKR)
	private String sBirthDate;
	/** ���� **/
	@ValidateByte(max = 1, charset = CharacterSet.EUCKR)
	private String sSex;
	/** �������� 0 �Ϲ�, 9 Ż��**/
	@ValidateByte(max = 1, charset = CharacterSet.EUCKR)
	private String sClass;
	/** �Ǹ��������� **/
	@ValidateByte(max = 1, charset = CharacterSet.EUCKR)
	private String sReal;
	/** ���޻��ڵ� **/
	@ValidateByte(max = 5, charset = CharacterSet.EUCKR)
	private String sAffiliatedConcern;
	/** ���ڱ����ŷ� ȸ�� ���� (Y: ���ڱ����ŷ� ȸ��, �׿� ���ڱ����ŷ� ȸ�� �ƴ�) **/
	@ValidateByte(max = 1, charset = CharacterSet.EUCKR)
	private String sEleYN;
	/** �������� **/
	private String sCreDate;
	/** �����ð� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	
	/** �������� ��ȣ ���� Ƚ�� **/
	private String nPasswordFailureCount;
	/** ��ȣ �÷��� (0:����, 1:���, 2:�������) **/
	private String sPassFlag;
	/** ��ȣ���� ���� **/
	private String sPassFailDate;
	/** ��ȣ��� �������� **/
	private String sFailClearDate;
	/** ��ȣ��� ������ **/
	private String sFailClearID;

	/**
	 * @return the iD
	 */
	public long getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final long iD) {
		ID = iD;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sClass
	 */
	public String getsClass() {
		return sClass;
	}

	/**
	 * @param sClass the sClass to set
	 */
	public void setsClass(final String sClass) {
		this.sClass = sClass;
	}

	/**
	 * @return the sReal
	 */
	public String getsReal() {
		return sReal;
	}

	/**
	 * @param sReal the sReal to set
	 */
	public void setsReal(final String sReal) {
		this.sReal = sReal;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the sEleYN
	 */
	public String getsEleYN() {
		return sEleYN;
	}

	/**
	 * @param sEleYN the sEleYN to set
	 */
	public void setsEleYN(final String sEleYN) {
		this.sEleYN = sEleYN;
	}

	/**
	 * @return the sBirthDate
	 */
	public String getsBirthDate() {
		return sBirthDate;
	}

	/**
	 * @param sBirthDate the sBirthDate to set
	 */
	public void setsBirthDate(final String sBirthDate) {
		this.sBirthDate = sBirthDate;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(final String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the nPasswordFailureCount
	 */
	public String getnPasswordFailureCount() {
		return nPasswordFailureCount;
	}

	/**
	 * @param nPasswordFailureCount the nPasswordFailureCount to set
	 */
	public void setnPasswordFailureCount(String nPasswordFailureCount) {
		this.nPasswordFailureCount = nPasswordFailureCount;
	}

	/**
	 * @return the sPassFlag
	 */
	public String getsPassFlag() {
		return sPassFlag;
	}

	/**
	 * @param sPassFlag the sPassFlag to set
	 */
	public void setsPassFlag(String sPassFlag) {
		this.sPassFlag = sPassFlag;
	}

	/**
	 * @return the sPassFailDate
	 */
	public String getsPassFailDate() {
		return sPassFailDate;
	}

	/**
	 * @param sPassFailDate the sPassFailDate to set
	 */
	public void setsPassFailDate(String sPassFailDate) {
		this.sPassFailDate = sPassFailDate;
	}

	/**
	 * @return the sFailClearDate
	 */
	public String getsFailClearDate() {
		return sFailClearDate;
	}

	/**
	 * @param sFailClearDate the sFailClearDate to set
	 */
	public void setsFailClearDate(String sFailClearDate) {
		this.sFailClearDate = sFailClearDate;
	}

	/**
	 * @return the sFailClearID
	 */
	public String getsFailClearID() {
		return sFailClearID;
	}

	/**
	 * @param sFailClearID the sFailClearID to set
	 */
	public void setsFailClearID(String sFailClearID) {
		this.sFailClearID = sFailClearID;
	}
	
}
