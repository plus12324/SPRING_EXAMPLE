/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * ���� ��� ����(LTIDA00) DTO
 * @author ������
 *
 */
public class InsuranceContractDesignDTO {
	/** ��������� **/
	private String nBussPrem;
	/** ���������� **/
	private String sApplDclrRato;
	/** �÷��ڵ� **/
	private String sApplPlanCd;
	/** ���������з��ڵ� **/
	private String sBunsMetdDocuClsfCd;
	/** ��ǰ�ڵ� **/
	private String sGdCd;
	/** ���ԱⰣ (���� �� : yy)**/
	private String paymentPeriod;
	/** ����Ⱓ�ڵ� (7��:107, 10��:110, 20��:120 )**/
	private String sInsurTermCd;
	/** ���ԱⰣ�ڵ� (7��:107, 10��:110, 20��:120, �Ͻó�:000, �����ֱⰡ �Ͻó��� ��� : 000)**/
	private String sPaymTermCd;
	/** �����ֱ�  (����:12, 2����:06, 3����:04, 6����:02, �ⳳ:01, �Ͻó�:99)**/
	private String sPaymCyclCd;
	/** ���庸��� (����� �� ���) **/
	private String nGrntPrem;
	/** �Ǻ����ڼ�**/
	private String nInrpsPsct;
	
	private String sDivCd;
	
	private String sMsgCd;
	
	private String sMsg;
	/** ���ݰ��ó���**/
	private String sAnntOpnAgeCd;
	/** �����ֱ�**/
	private String sAnntPymCyclCd;
	/** ��������**/
	private String sAnntPymTypeCd;
	/** ���ޱⰣ**/
	private String sAnntPymTermCd;
	/** �������迩��**/
	private String sSimpleYn;
	
	/**
	 * @return the nBussPrem
	 */
	public String getnBussPrem() {
		return nBussPrem;
	}

	/**
	 * @param nBussPrem the nBussPrem to set
	 */
	public void setnBussPrem(final String nBussPrem) {
		this.nBussPrem = nBussPrem;
	}

	/**
	 * @return the sApplDclrRato
	 */
	public String getsApplDclrRato() {
		return sApplDclrRato;
	}

	/**
	 * @param sApplDclrRato the sApplDclrRato to set
	 */
	public void setsApplDclrRato(final String sApplDclrRato) {
		this.sApplDclrRato = sApplDclrRato;
	}

	/**
	 * @return the sApplPlanCd
	 */
	public String getsApplPlanCd() {
		return sApplPlanCd;
	}

	/**
	 * @param sApplPlanCd the sApplPlanCd to set
	 */
	public void setsApplPlanCd(final String sApplPlanCd) {
		this.sApplPlanCd = sApplPlanCd;
	}

	/**
	 * @return the sBunsMetdDocuClsfCd
	 */
	public String getsBunsMetdDocuClsfCd() {
		return sBunsMetdDocuClsfCd;
	}

	/**
	 * @param sBunsMetdDocuClsfCd the sBunsMetdDocuClsfCd to set
	 */
	public void setsBunsMetdDocuClsfCd(final String sBunsMetdDocuClsfCd) {
		this.sBunsMetdDocuClsfCd = sBunsMetdDocuClsfCd;
	}

	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}

	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(final String sGdCd) {
		this.sGdCd = sGdCd;
	}

	/**
	 * @return the paymentPeriod
	 */
	public String getPaymentPeriod() {
		return paymentPeriod;
	}

	/**
	 * @param paymentPeriod the paymentPeriod to set
	 */
	public void setPaymentPeriod(final String paymentPeriod) {
		this.paymentPeriod = paymentPeriod;
	}

	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}

	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(final String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}

	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}

	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(final String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}

	/**
	 * @return the sPaymCyclCd
	 */
	public String getsPaymCyclCd() {
		return sPaymCyclCd;
	}

	/**
	 * @param sPaymCyclCd the sPaymCyclCd to set
	 */
	public void setsPaymCyclCd(final String sPaymCyclCd) {
		this.sPaymCyclCd = sPaymCyclCd;
	}

	/**
	 * @return the nGrntPrem
	 */
	public String getnGrntPrem() {
		return nGrntPrem;
	}

	/**
	 * @param nGrntPrem the nGrntPrem to set
	 */
	public void setnGrntPrem(final String nGrntPrem) {
		this.nGrntPrem = nGrntPrem;
	}

	/**
	 * @return the nInrpsPsct
	 */
	public String getnInrpsPsct() {
		return nInrpsPsct;
	}

	/**
	 * @param nInrpsPsct the nInrpsPsct to set
	 */
	public void setnInrpsPsct(String nInrpsPsct) {
		this.nInrpsPsct = nInrpsPsct;
	}

	/**
	 * @return the sDivCd
	 */
	public String getsDivCd() {
		return sDivCd;
	}

	/**
	 * @param sDivCd the sDivCd to set
	 */
	public void setsDivCd(String sDivCd) {
		this.sDivCd = sDivCd;
	}

	/**
	 * @return the sMsgCd
	 */
	public String getsMsgCd() {
		return sMsgCd;
	}

	/**
	 * @param sMsgCd the sMsgCd to set
	 */
	public void setsMsgCd(String sMsgCd) {
		this.sMsgCd = sMsgCd;
	}

	/**
	 * @return the sMsg
	 */
	public String getsMsg() {
		return sMsg;
	}

	/**
	 * @param sMsg the sMsg to set
	 */
	public void setsMsg(String sMsg) {
		this.sMsg = sMsg;
	}

	/**
	 * @return the sAnntOpnAgeCd
	 */
	public String getsAnntOpnAgeCd() {
		return sAnntOpnAgeCd;
	}

	/**
	 * @param sAnntOpnAgeCd the sAnntOpnAgeCd to set
	 */
	public void setsAnntOpnAgeCd(String sAnntOpnAgeCd) {
		this.sAnntOpnAgeCd = sAnntOpnAgeCd;
	}

	/**
	 * @return the sAnntPymCyclCd
	 */
	public String getsAnntPymCyclCd() {
		return sAnntPymCyclCd;
	}

	/**
	 * @param sAnntPymCyclCd the sAnntPymCyclCd to set
	 */
	public void setsAnntPymCyclCd(String sAnntPymCyclCd) {
		this.sAnntPymCyclCd = sAnntPymCyclCd;
	}

	/**
	 * @return the sAnntPymTypeCd
	 */
	public String getsAnntPymTypeCd() {
		return sAnntPymTypeCd;
	}

	/**
	 * @param sAnntPymTypeCd the sAnntPymTypeCd to set
	 */
	public void setsAnntPymTypeCd(String sAnntPymTypeCd) {
		this.sAnntPymTypeCd = sAnntPymTypeCd;
	}

	/**
	 * @return the sAnntPymTermCd
	 */
	public String getsAnntPymTermCd() {
		return sAnntPymTermCd;
	}

	/**
	 * @param sAnntPymTermCd the sAnntPymTermCd to set
	 */
	public void setsAnntPymTermCd(String sAnntPymTermCd) {
		this.sAnntPymTermCd = sAnntPymTermCd;
	}

	/**
	 * @return the sSimpleYn
	 */
	public String getsSimpleYn() {
		return sSimpleYn;
	}

	/**
	 * @param sSimpleYn the sSimpleYn to set
	 */
	public void setsSimpleYn(String sSimpleYn) {
		this.sSimpleYn = sSimpleYn;
	}

}
