/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �ڵ��� ����� ���� ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfOneDayInsuranceSearchResultDTO")
public class PriceCalculationOfOneDayInsuranceSearchResultDTO {
	/** �� ����� **/
	private String sTotalPrem;
	/** �㺸�� ���� ����� **/
	private List<PriceCalculationOfOneDayInsuranceCodeDTO> coverVt;
	/** ���� �޼��� */
	private String sMsg;

	/**
	 * @return the sTotalPrem
	 */
	public String getsTotalPrem() {
		return sTotalPrem;
	}

	/**
	 * @param sTotalPrem the sTotalPrem to set
	 */
	public void setsTotalPrem(final String sTotalPrem) {
		this.sTotalPrem = sTotalPrem;
	}

	/**
	 * @return the coverVt
	 */
	public List<PriceCalculationOfOneDayInsuranceCodeDTO> getCoverVt() {
		return coverVt;
	}

	/**
	 * @param coverVt the coverVt to set
	 */
	public void setCoverVt(final List<PriceCalculationOfOneDayInsuranceCodeDTO> coverVt) {
		this.coverVt = coverVt;
	}

	/**
	 * @return the sMsg
	 */
	public String getsMsg() {
		return sMsg;
	}

	/**
	 * @param sMsg the sMsg to set
	 */
	public void setsMsg(final String sMsg) {
		this.sMsg = sMsg;
	}

}
