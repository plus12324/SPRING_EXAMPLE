/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������� ���� ��ȸ ��� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlRootElement(name = "checkAccidentSearchResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class CheckAccidentSearchResultDTO {
	/** ������ȣ **/
	private String sAccidentNo;
	/** ����Ͻ� **/
	private String sAcctDate;
	/** ������1 **/
	private String sAcctAddr1;
	/** ������2 **/
	private String sAcctAddr2;
	/** ������(ȭ�� ǥ�ÿ�) **/
	private String acctAddr;
	/** �뺸�� **/
	private String sInformerName;
	/** �����Ͻ� **/
	private String sAcctRegiDate;

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sAcctDate
	 */
	public String getsAcctDate() {
		return sAcctDate;
	}

	/**
	 * @param sAcctDate the sAcctDate to set
	 */
	public void setsAcctDate(final String sAcctDate) {
		this.sAcctDate = sAcctDate;
	}

	/**
	 * @return the sAcctAddr1
	 */
	public String getsAcctAddr1() {
		return sAcctAddr1;
	}

	/**
	 * @param sAcctAddr1 the sAcctAddr1 to set
	 */
	public void setsAcctAddr1(final String sAcctAddr1) {
		this.sAcctAddr1 = sAcctAddr1;
	}

	/**
	 * @return the sAcctAddr2
	 */
	public String getsAcctAddr2() {
		return sAcctAddr2;
	}

	/**
	 * @param sAcctAddr2 the sAcctAddr2 to set
	 */
	public void setsAcctAddr2(final String sAcctAddr2) {
		this.sAcctAddr2 = sAcctAddr2;
	}

	/**
	 * @return the acctAddr
	 */
	public String getAcctAddr() {
		return acctAddr;
	}

	/**
	 * @param acctAddr the acctAddr to set
	 */
	public void setAcctAddr(final String acctAddr) {
		this.acctAddr = acctAddr;
	}

	/**
	 * @return the sInformerName
	 */
	public String getsInformerName() {
		return sInformerName;
	}

	/**
	 * @param sInformerName the sInformerName to set
	 */
	public void setsInformerName(final String sInformerName) {
		this.sInformerName = sInformerName;
	}

	/**
	 * @return the sAcctRegiDate
	 */
	public String getsAcctRegiDate() {
		return sAcctRegiDate;
	}

	/**
	 * @param sAcctRegiDate the sAcctRegiDate to set
	 */
	public void setsAcctRegiDate(final String sAcctRegiDate) {
		this.sAcctRegiDate = sAcctRegiDate;
	}

}
