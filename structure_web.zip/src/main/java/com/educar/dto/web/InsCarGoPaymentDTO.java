/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����� ���� - �ڵ��� ����� (��Ǳ⺻��ȸ / ��������)
 * @author 
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insCarGoPaymentDTO")
public class InsCarGoPaymentDTO{
	/**	����ȣ	 **/ 
	private String   	sPolicyNo;
	/**	�輭��ȣ	 **/ 
	private String   	nEndorseNo;
	/**	ȸ�� ���۹�ȣ	 **/ 
	private String   	nFmPayNo;
	/**	ȸ�� ����ȣ	 **/ 
	private String   	nToPayNo;
	/**	���������	 **/ 
	private String   	nInstmPrem;
	/**	�Է���	 **/ 
	private String   	sUserID;
	/**	û���ȣ	 **/ 
	private String   	sApplyType;
	/**	û���ȣ	 **/ 
	private String   	sApplyYM;
	/**	û���ȣ	 **/ 
	private String   	sApplySer;
	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}
	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}
	/**
	 * @return the nEndorseNo
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}
	/**
	 * @param nEndorseNo the nEndorseNo to set
	 */
	public void setnEndorseNo(String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}
	/**
	 * @return the nFmPayNo
	 */
	public String getnFmPayNo() {
		return nFmPayNo;
	}
	/**
	 * @param nFmPayNo the nFmPayNo to set
	 */
	public void setnFmPayNo(String nFmPayNo) {
		this.nFmPayNo = nFmPayNo;
	}
	/**
	 * @return the nToPayNo
	 */
	public String getnToPayNo() {
		return nToPayNo;
	}
	/**
	 * @param nToPayNo the nToPayNo to set
	 */
	public void setnToPayNo(String nToPayNo) {
		this.nToPayNo = nToPayNo;
	}
	/**
	 * @return the nInstmPrem
	 */
	public String getnInstmPrem() {
		return nInstmPrem;
	}
	/**
	 * @param nInstmPrem the nInstmPrem to set
	 */
	public void setnInstmPrem(String nInstmPrem) {
		this.nInstmPrem = nInstmPrem;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sApplyType
	 */
	public String getsApplyType() {
		return sApplyType;
	}
	/**
	 * @param sApplyType the sApplyType to set
	 */
	public void setsApplyType(String sApplyType) {
		this.sApplyType = sApplyType;
	}
	/**
	 * @return the sApplyYM
	 */
	public String getsApplyYM() {
		return sApplyYM;
	}
	/**
	 * @param sApplyYM the sApplyYM to set
	 */
	public void setsApplyYM(String sApplyYM) {
		this.sApplyYM = sApplyYM;
	}
	/**
	 * @return the sApplySer
	 */
	public String getsApplySer() {
		return sApplySer;
	}
	/**
	 * @param sApplySer the sApplySer to set
	 */
	public void setsApplySer(String sApplySer) {
		this.sApplySer = sApplySer;
	}

	
}
