/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * @author ������
 *
 */
public class PriceCalculationOfLognTermInsurancePriceDTO {
	/** Ư���ڵ� **/
	private String sTrtyCd;
	/** Ư�ະ ���庸��� **/
	private String nTrtyPrem;

	/**
	 * @return the sTrtyCd
	 */
	public String getsTrtyCd() {
		return sTrtyCd;
	}

	/**
	 * @param sTrtyCd the sTrtyCd to set
	 */
	public void setsTrtyCd(final String sTrtyCd) {
		this.sTrtyCd = sTrtyCd;
	}

	/**
	 * @return the nTrtyPrem
	 */
	public String getnTrtyPrem() {
		return nTrtyPrem;
	}

	/**
	 * @param nTrtyPrem the nTrtyPrem to set
	 */
	public void setnTrtyPrem(final String nTrtyPrem) {
		this.nTrtyPrem = nTrtyPrem;
	}

}
