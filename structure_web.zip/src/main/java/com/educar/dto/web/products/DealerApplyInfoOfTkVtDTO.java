/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� û�೻�� Ȯ�� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerApplyInfoOfTkVtDTO")
public class DealerApplyInfoOfTkVtDTO {
	/** Ư�� **/
	private String sTkNm;

	/**
	 * @return the sTkNm
	 */
	public String getsTkNm() {
		return sTkNm;
	}

	/**
	 * @param sTkNm the sTkNm to set
	 */
	public void setsTkNm(final String sTkNm) {
		this.sTkNm = sTkNm;
	}

}
