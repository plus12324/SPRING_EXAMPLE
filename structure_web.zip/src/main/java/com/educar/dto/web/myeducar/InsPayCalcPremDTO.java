/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ����� ���� ����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insPayCalcPremDTO")
public class InsPayCalcPremDTO {
	/** 	����ȣ	 **/ 
	private String 	sCrNo;
	/** 	�Է°Ǽ�	 **/ 
	private String 	sPayCnt;
	/** 	ȭ��ID	 **/ 
	private String 	sScrnId;
	/** 	��ȸ����	 **/ 
	private String 	sSchCat;
	/** 	����(����/����)	 **/ 
	private String 	sRecvStatFlagNM;
	/** 	�����	 **/ 
	private String 	nBussPrem;
	/** 	���뺸���	 **/ 
	private String 	nApplPrem;
	/** 	����Ƚ��	 **/ 
	private String 	nPaymCt;
	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}
	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(String sCrNo) {
		this.sCrNo = sCrNo;
	}
	/**
	 * @return the sPayCnt
	 */
	public String getsPayCnt() {
		return sPayCnt;
	}
	/**
	 * @param sPayCnt the sPayCnt to set
	 */
	public void setsPayCnt(String sPayCnt) {
		this.sPayCnt = sPayCnt;
	}
	/**
	 * @return the sScrnId
	 */
	public String getsScrnId() {
		return sScrnId;
	}
	/**
	 * @param sScrnId the sScrnId to set
	 */
	public void setsScrnId(String sScrnId) {
		this.sScrnId = sScrnId;
	}
	/**
	 * @return the sSchCat
	 */
	public String getsSchCat() {
		return sSchCat;
	}
	/**
	 * @param sSchCat the sSchCat to set
	 */
	public void setsSchCat(String sSchCat) {
		this.sSchCat = sSchCat;
	}
	/**
	 * @return the sRecvStatFlagNM
	 */
	public String getsRecvStatFlagNM() {
		return sRecvStatFlagNM;
	}
	/**
	 * @param sRecvStatFlagNM the sRecvStatFlagNM to set
	 */
	public void setsRecvStatFlagNM(String sRecvStatFlagNM) {
		this.sRecvStatFlagNM = sRecvStatFlagNM;
	}
	/**
	 * @return the nBussPrem
	 */
	public String getnBussPrem() {
		return nBussPrem;
	}
	/**
	 * @param nBussPrem the nBussPrem to set
	 */
	public void setnBussPrem(String nBussPrem) {
		this.nBussPrem = nBussPrem;
	}
	/**
	 * @return the nApplPrem
	 */
	public String getnApplPrem() {
		return nApplPrem;
	}
	/**
	 * @param nApplPrem the nApplPrem to set
	 */
	public void setnApplPrem(String nApplPrem) {
		this.nApplPrem = nApplPrem;
	}
	/**
	 * @return the nPaymCt
	 */
	public String getnPaymCt() {
		return nPaymCt;
	}
	/**
	 * @param nPaymCt the nPaymCt to set
	 */
	public void setnPaymCt(String nPaymCt) {
		this.nPaymCt = nPaymCt;
	}
	
	
	
}
