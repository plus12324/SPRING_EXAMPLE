/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Event10AnniversaryDTO DTO
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "event10AnniversaryDTO")
public class Event10AnniversaryDTO {
	/**	seq	**/ 
	private String 	nSeq;
	/** �̺�Ʈ �ڵ� **/
	private String sEventDiv;
	/**	��õ URL	**/ 
	private String 	sRecommendUrl;
	/**	��õ�� �̸�	**/ 
	private String 	sRecommenderName;
	/**	������ �̸�	**/ 
	private String 	sJoinerName;
	/**	�޴��ȣ All	**/ 
	private String 	sCellPhone;
	/**	�޴��ȣ1	**/ 
	private String 	sCellPhone1;
	/**	�޴��ȣ2	**/ 
	private String 	sCellPhone2;
	/**	�޴��ȣ3	**/ 
	private String 	sCellPhone3;
	/**	��Ÿ	**/ 
	private String 	sEtc1;
	/**	�����ڻ��	**/ 
	private String 	sCreID;
	/**	�����ڻ��	**/ 
	private String 	sModiID;
	/**	��������	**/ 
	private String 	sCreDate;
	/**	�����ð�	**/ 
	private String 	sCreTime;
	/**	��������	**/ 
	private String 	sModiDate;
	/**	�����ð�	**/ 
	private String 	sModiTime;
	/**	�ߺ� count	**/ 
	private int 	sCellPhoneCnt;
	/**	URL count	**/ 
	private int 	sRecommendUrlCnt;
	/**	�����޴��� ���翩�� count	**/ 
	private int 	sSelfCellPhoneCnt;
	/**	��ȸ���۳�¥(�̺�Ʈ����õ�� �� ��ȸ ������ ���) **/ 
	private String 	sEventStartDate;
	/**	��ȸ���ᳯ¥(�̺�Ʈ����õ�� �� ��ȸ ������ ���) **/ 
	private String 	sEventEndDate;
	/** SMS���ڹ߼۰Ǽ�	**/
	private int nSendSmsCnt;
	/** SMS���ڹ߼�����	**/
	private String sSendSmsDate;
	
	public int getnSendSmsCnt() {
		return nSendSmsCnt;
	}
	public void setnSendSmsCnt(int nSendSmsCnt) {
		this.nSendSmsCnt = nSendSmsCnt;
	}
	public String getsSendSmsDate() {
		return sSendSmsDate;
	}
	public void setsSendSmsDate(String sSendSmsDate) {
		this.sSendSmsDate = sSendSmsDate;
	}
	public String getsEventStartDate() {
		return sEventStartDate;
	}
	public void setsEventStartDate(String sEventStartDate) {
		this.sEventStartDate = sEventStartDate;
	}
	public String getsEventEndDate() {
		return sEventEndDate;
	}
	public void setsEventEndDate(String sEventEndDate) {
		this.sEventEndDate = sEventEndDate;
	}
	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}
	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	/**
	 * @return
	 */
	public int getsSelfCellPhoneCnt() {
		return sSelfCellPhoneCnt;
	}
	/**
	 * @param sSelfCellPhoneCnt
	 */
	public void setsSelfCellPhoneCnt(int sSelfCellPhoneCnt) {
		this.sSelfCellPhoneCnt = sSelfCellPhoneCnt;
	}
	/**
	 * @return
	 */
	public int getsCellPhoneCnt() {
		return sCellPhoneCnt;
	}
	/**
	 * @param sCellPhoneCnt
	 */
	public void setsCellPhoneCnt(int sCellPhoneCnt) {
		this.sCellPhoneCnt = sCellPhoneCnt;
	}
	/**
	 * @return
	 */
	public int getsRecommendUrlCnt() {
		return sRecommendUrlCnt;
	}
	/**
	 * @param sRecommendUrlCnt
	 */
	public void setsRecommendUrlCnt(int sRecommendUrlCnt) {
		this.sRecommendUrlCnt = sRecommendUrlCnt;
	}
	/**
	 * @return
	 */
	public String getsCellPhone() {
		return sCellPhone;
	}
	/**
	 * @param sCellPhone
	 */
	public void setsCellPhone(String sCellPhone) {
		this.sCellPhone = sCellPhone;
	}	
	/**
	 * @return
	 */
	public String getsJoinerName() {
		return sJoinerName;
	}
	/**
	 * @param sJoinerName
	 */
	public void setsJoinerName(String sJoinerName) {
		this.sJoinerName = sJoinerName;
	}
	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sRecommendUrl
	 */
	public String getsRecommendUrl() {
		return sRecommendUrl;
	}
	/**
	 * @param sRecommendUrl the sRecommendUrl to set
	 */
	public void setsRecommendUrl(String sRecommendUrl) {
		this.sRecommendUrl = sRecommendUrl;
	}
	/**
	 * @return the sRecommenderName
	 */
	public String getsRecommenderName() {
		return sRecommenderName;
	}
	/**
	 * @param sRecommenderName the sRecommenderName to set
	 */
	public void setsRecommenderName(String sRecommenderName) {
		this.sRecommenderName = sRecommenderName;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sEtc1
	 */
	public String getsEtc1() {
		return sEtc1;
	}
	/**
	 * @param sEtc1 the sEtc1 to set
	 */
	public void setsEtc1(String sEtc1) {
		this.sEtc1 = sEtc1;
	}
	/**
	 * @return the sCreID
	 */
	public String getsCreID() {
		return sCreID;
	}
	/**
	 * @param sCreID the sCreID to set
	 */
	public void setsCreID(String sCreID) {
		this.sCreID = sCreID;
	}
	/**
	 * @return the sModiID
	 */
	public String getsModiID() {
		return sModiID;
	}
	/**
	 * @param sModiID the sModiID to set
	 */
	public void setsModiID(String sModiID) {
		this.sModiID = sModiID;
	}
	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}
	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(String sCreDate) {
		this.sCreDate = sCreDate;
	}
	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}
	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(String sCreTime) {
		this.sCreTime = sCreTime;
	}
	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}
	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(String sModiDate) {
		this.sModiDate = sModiDate;
	}
	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}
	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(String sModiTime) {
		this.sModiTime = sModiTime;
	}
	
	
}
