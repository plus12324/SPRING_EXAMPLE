/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� �� ����Ʈ ��ȸ ��� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carDetailSearchResultDTO")
public class CarDetailSearchResultDTO {
	/** ��������(A,B) **/
	private String sYearType;
	/** �����ڵ� **/
	private String CHCD;
	/** ������������ **/
	private String APPL_TODT;
	/** ���� **/
	private String CHNM;
	/** ���� **/
	private String CHTP;
	/** ���� **/
	private String SEVN;
	/** ����ȸ�� **/
	private String MADE_COMP;
	/** ���۱��� **/
	private String MADE_NATN;
	/** �����뵵 **/
	private String YONG_GB;
	/** ��ⷮ **/
	private String BEGI;
	/** ���� **/
	private String PERS;
	/** ���籸���ڵ� **/
	private String TON_GB;
	/** ����1 **/
	private String CHAJONG;
	/** ����2 **/
	private String CHAJONG2;
	/** ���׷��� **/
	private String STEREO;
	/** Į������ **/
	private String GLASS;
	/** ������ **/
	private String AIRCON;
	/** ����� **/
	private String AIRBAG;
	/** ������ġ **/
	private String ROBBERY;
	/** ABS�������� **/
	private String ABS;
	/** �ڵ����ӱ���ġ **/
	private String TRANS;
	/** ���� **/
	private String CHYR1;
	/** ��������(A,B) **/
	private String NWCAR_GB1;
	/** ���� **/
	private String sCarType;
	/** ����ڵ� **/
	private String sCarGradeCode;
	/** ����ڵ�(��) **/
	private String nCarGradeRate;
	/** ���ᱸ�� **/
	private String sFuelType;
	/** �������� (����: ����) **/
	private String nVehicleAmt;

	/** ���� (���� ��ȸ�� ���) **/
	private String sShortName;

	/**
	 * @return the sYearType
	 */
	public String getsYearType() {
		return sYearType;
	}

	/**
	 * @param sYearType the sYearType to set
	 */
	public void setsYearType(final String sYearType) {
		this.sYearType = sYearType;
	}

	/**
	 * @return the cHCD
	 */
	public String getCHCD() {
		return CHCD;
	}

	/**
	 * @param cHCD the cHCD to set
	 */
	public void setCHCD(final String cHCD) {
		CHCD = cHCD;
	}

	/**
	 * @return the aPPL_TODT
	 */
	public String getAPPL_TODT() {
		return APPL_TODT;
	}

	/**
	 * @param aPPL_TODT the aPPL_TODT to set
	 */
	public void setAPPL_TODT(final String aPPL_TODT) {
		APPL_TODT = aPPL_TODT;
	}

	/**
	 * @return the cHNM
	 */
	public String getCHNM() {
		return CHNM;
	}

	/**
	 * @param cHNM the cHNM to set
	 */
	public void setCHNM(final String cHNM) {
		CHNM = cHNM;
	}

	/**
	 * @return the cHTP
	 */
	public String getCHTP() {
		return CHTP;
	}

	/**
	 * @param cHTP the cHTP to set
	 */
	public void setCHTP(final String cHTP) {
		CHTP = cHTP;
	}

	/**
	 * @return the sEVN
	 */
	public String getSEVN() {
		return SEVN;
	}

	/**
	 * @param sEVN the sEVN to set
	 */
	public void setSEVN(final String sEVN) {
		SEVN = sEVN;
	}

	/**
	 * @return the mADE_COMP
	 */
	public String getMADE_COMP() {
		return MADE_COMP;
	}

	/**
	 * @param mADE_COMP the mADE_COMP to set
	 */
	public void setMADE_COMP(final String mADE_COMP) {
		MADE_COMP = mADE_COMP;
	}

	/**
	 * @return the mADE_NATN
	 */
	public String getMADE_NATN() {
		return MADE_NATN;
	}

	/**
	 * @param mADE_NATN the mADE_NATN to set
	 */
	public void setMADE_NATN(final String mADE_NATN) {
		MADE_NATN = mADE_NATN;
	}

	/**
	 * @return the yONG_GB
	 */
	public String getYONG_GB() {
		return YONG_GB;
	}

	/**
	 * @param yONG_GB the yONG_GB to set
	 */
	public void setYONG_GB(final String yONG_GB) {
		YONG_GB = yONG_GB;
	}

	/**
	 * @return the bEGI
	 */
	public String getBEGI() {
		return BEGI;
	}

	/**
	 * @param bEGI the bEGI to set
	 */
	public void setBEGI(final String bEGI) {
		BEGI = bEGI;
	}

	/**
	 * @return the pERS
	 */
	public String getPERS() {
		return PERS;
	}

	/**
	 * @param pERS the pERS to set
	 */
	public void setPERS(final String pERS) {
		PERS = pERS;
	}

	/**
	 * @return the tON_GB
	 */
	public String getTON_GB() {
		return TON_GB;
	}

	/**
	 * @param tON_GB the tON_GB to set
	 */
	public void setTON_GB(final String tON_GB) {
		TON_GB = tON_GB;
	}

	/**
	 * @return the cHAJONG
	 */
	public String getCHAJONG() {
		return CHAJONG;
	}

	/**
	 * @param cHAJONG the cHAJONG to set
	 */
	public void setCHAJONG(final String cHAJONG) {
		CHAJONG = cHAJONG;
	}

	/**
	 * @return the cHAJONG2
	 */
	public String getCHAJONG2() {
		return CHAJONG2;
	}

	/**
	 * @param cHAJONG2 the cHAJONG2 to set
	 */
	public void setCHAJONG2(final String cHAJONG2) {
		CHAJONG2 = cHAJONG2;
	}

	/**
	 * @return the sTEREO
	 */
	public String getSTEREO() {
		return STEREO;
	}

	/**
	 * @param sTEREO the sTEREO to set
	 */
	public void setSTEREO(final String sTEREO) {
		STEREO = sTEREO;
	}

	/**
	 * @return the gLASS
	 */
	public String getGLASS() {
		return GLASS;
	}

	/**
	 * @param gLASS the gLASS to set
	 */
	public void setGLASS(final String gLASS) {
		GLASS = gLASS;
	}

	/**
	 * @return the aIRCON
	 */
	public String getAIRCON() {
		return AIRCON;
	}

	/**
	 * @param aIRCON the aIRCON to set
	 */
	public void setAIRCON(final String aIRCON) {
		AIRCON = aIRCON;
	}

	/**
	 * @return the aIRBAG
	 */
	public String getAIRBAG() {
		return AIRBAG;
	}

	/**
	 * @param aIRBAG the aIRBAG to set
	 */
	public void setAIRBAG(final String aIRBAG) {
		AIRBAG = aIRBAG;
	}

	/**
	 * @return the rOBBERY
	 */
	public String getROBBERY() {
		return ROBBERY;
	}

	/**
	 * @param rOBBERY the rOBBERY to set
	 */
	public void setROBBERY(final String rOBBERY) {
		ROBBERY = rOBBERY;
	}

	/**
	 * @return the aBS
	 */
	public String getABS() {
		return ABS;
	}

	/**
	 * @param aBS the aBS to set
	 */
	public void setABS(final String aBS) {
		ABS = aBS;
	}

	/**
	 * @return the tRANS
	 */
	public String getTRANS() {
		return TRANS;
	}

	/**
	 * @param tRANS the tRANS to set
	 */
	public void setTRANS(final String tRANS) {
		TRANS = tRANS;
	}

	/**
	 * @return the cHYR1
	 */
	public String getCHYR1() {
		return CHYR1;
	}

	/**
	 * @param cHYR1 the cHYR1 to set
	 */
	public void setCHYR1(final String cHYR1) {
		CHYR1 = cHYR1;
	}

	/**
	 * @return the nWCAR_GB1
	 */
	public String getNWCAR_GB1() {
		return NWCAR_GB1;
	}

	/**
	 * @param nWCAR_GB1 the nWCAR_GB1 to set
	 */
	public void setNWCAR_GB1(final String nWCAR_GB1) {
		NWCAR_GB1 = nWCAR_GB1;
	}

	/**
	 * @return the sCarType
	 */
	public String getsCarType() {
		return sCarType;
	}

	/**
	 * @param sCarType the sCarType to set
	 */
	public void setsCarType(final String sCarType) {
		this.sCarType = sCarType;
	}

	/**
	 * @return the sCarGradeCode
	 */
	public String getsCarGradeCode() {
		return sCarGradeCode;
	}

	/**
	 * @param sCarGradeCode the sCarGradeCode to set
	 */
	public void setsCarGradeCode(final String sCarGradeCode) {
		this.sCarGradeCode = sCarGradeCode;
	}

	/**
	 * @return the nCarGradeRate
	 */
	public String getnCarGradeRate() {
		return nCarGradeRate;
	}

	/**
	 * @param nCarGradeRate the nCarGradeRate to set
	 */
	public void setnCarGradeRate(final String nCarGradeRate) {
		this.nCarGradeRate = nCarGradeRate;
	}

	/**
	 * @return the sFuelType
	 */
	public String getsFuelType() {
		return sFuelType;
	}

	/**
	 * @param sFuelType the sFuelType to set
	 */
	public void setsFuelType(final String sFuelType) {
		this.sFuelType = sFuelType;
	}

	/**
	 * @return the nVehicleAmt
	 */
	public String getnVehicleAmt() {
		return nVehicleAmt;
	}

	/**
	 * @param nVehicleAmt the nVehicleAmt to set
	 */
	public void setnVehicleAmt(final String nVehicleAmt) {
		this.nVehicleAmt = nVehicleAmt;
	}

	/**
	 * @return the sShortName
	 */
	public String getsShortName() {
		return sShortName;
	}

	/**
	 * @param sShortName the sShortName to set
	 */
	public void setsShortName(final String sShortName) {
		this.sShortName = sShortName;
	}

}
