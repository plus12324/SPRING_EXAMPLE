package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * ���� ������� DTO
 * @author �Ž¿�
 * @since 1.0.0
 */
@XmlRootElement(name = "insertAcdRcpDataOfDs_AccInfoDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAcdRcpDataOfDs_AccInfoDTO {

	/** �Ա����� **/
	private String sSupBankCd;
	/** ���¹�ȣ **/
	private String sSupAccountNo;
	/** ������ **/
	private String sSupDepName;
	/** E2E ��ȣȭ Ű **/
	@BeanUtil(ignore = true)
	private String sHid_key_data;
	
	public String getsHid_key_data() {
		return sHid_key_data;
	}
	public void setsHid_key_data(String sHid_key_data) {
		this.sHid_key_data = sHid_key_data;
	}
	public String getsSupBankCd() {
		return sSupBankCd;
	}
	public void setsSupBankCd(String sSupBankCd) {
		this.sSupBankCd = sSupBankCd;
	}
	public String getsSupAccountNo() {
		return sSupAccountNo;
	}
	public void setsSupAccountNo(String sSupAccountNo) {
		this.sSupAccountNo = sSupAccountNo;
	}
	public String getsSupDepName() {
		return sSupDepName;
	}
	public void setsSupDepName(String sSupDepName) {
		this.sSupDepName = sSupDepName;
	}
	
	
	
}
