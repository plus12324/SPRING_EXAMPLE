/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� ������� DTO
 * @author ������ 
 * @since 1.0.0
 */
@XmlRootElement(name = "insertAcdRcpDataOfDs_AcdListDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAcdRcpDataOfDs_AcdListDTO {
	/** ���ǹ�ȣ **/
	private String sPolicyNo;
	/** �Ǻ������ڵ� **/
	private String sInsrdID;
	/** �Ǻ����ڸ� **/
	private String sInsrdName;
	/** �����ұ��� ("1":���� "2":����) **/
	private String sAcdAddrType;
	/** �����ҿ�����ȣ ("1" : ������ ��� ������ȣ / "2" : �����ϰ�� �����ڵ�) **/
	private String sAcdZipCode;
	/** �����ҵ��ּ� **/
	private String sAcdVilAddr;
	/** �����Ҽ����ּ� **/
	private String sAcdDtlAddr;
	/** ������� **/
	private String sAcdDate;
	/** ����ð� **/
	private String sAcdTime;
	/** ��� ���� **/
	private String sAcdCont;
	/** ������� (����, ����, ����, ��Ÿ("01", "02", "03", "04")) **/
	private String sAcdType11;
	/** ������� (������ �ϰ�쿡�� �Է¹���) **/
	private String sAcdType22;
	/** �ڵ��������ȣ (���� ���ó��(33p) ��Ʈ�� sAccidentNo) **/
	private String sAutoAcdNum;
	/** �ڵ������Ῡ�� (���� ���ó��(33p) ��Ʈ�� sEndNo) **/
	private String sAutoEndYn;
	/** ����ڸ� **/
	private String sPolHolderName;
	/** ������ֹι�ȣ **/
	private String sPolHolderID;
	/** ������ID **/
	private String sRcpID;
	/** �����ID **/
	private String sUserID;
	/** ������ ���� 1:���� 2:���� **/
	private String sAccdPlacType;
	//N1401-00089 ���θ��ּ� �߰�
	/** ���λ����ּ� **/
	private String sDoroAddr;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	/** ǥ���ּ���ȯ���� */
	private String sStdAddrFlag;
	/**
	 * @return the sPolHolderID
	 */
	public String getsPolHolderID() {
		return sPolHolderID;
	}

	/**
	 * @param sPolHolderID the sPolHolderID to set
	 */
	public void setsPolHolderID(String sPolHolderID) {
		this.sPolHolderID = sPolHolderID;
	}

	/**
	 * @return the sPolHolderName
	 */
	public String getsPolHolderName() {
		return sPolHolderName;
	}

	/**
	 * @param sPolHolderName the sPolHolderName to set
	 */
	public void setsPolHolderName(String sPolHolderName) {
		this.sPolHolderName = sPolHolderName;
	}

	/**
	 * @return the sRcpID
	 */
	public String getsRcpID() {
		return sRcpID;
	}

	/**
	 * @param sRcpID the sRcpID to set
	 */
	public void setsRcpID(String sRcpID) {
		this.sRcpID = sRcpID;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the sAccdPlacType
	 */
	public String getsAccdPlacType() {
		return sAccdPlacType;
	}

	/**
	 * @param sAccdPlacType the sAccdPlacType to set
	 */
	public void setsAccdPlacType(String sAccdPlacType) {
		this.sAccdPlacType = sAccdPlacType;
	}

	/**
	 * @return the sAcdCont
	 */
	public String getsAcdCont() {
		return sAcdCont;
	}

	/**
	 * @param sAcdCont the sAcdCont to set
	 */
	public void setsAcdCont(String sAcdCont) {
		this.sAcdCont = sAcdCont;
	}

	/**
	 * @return the sPolicyNo
	 */
	public String getsPolicyNo() {
		return sPolicyNo;
	}

	/**
	 * @param sPolicyNo the sPolicyNo to set
	 */
	public void setsPolicyNo(final String sPolicyNo) {
		this.sPolicyNo = sPolicyNo;
	}

	/**
	 * @return the sInsrdID
	 */
	public String getsInsrdID() {
		return sInsrdID;
	}

	/**
	 * @param sInsrdID the sInsrdID to set
	 */
	public void setsInsrdID(final String sInsrdID) {
		this.sInsrdID = sInsrdID;
	}

	/**
	 * @return the sInsrdName
	 */
	public String getsInsrdName() {
		return sInsrdName;
	}

	/**
	 * @param sInsrdName the sInsrdName to set
	 */
	public void setsInsrdName(final String sInsrdName) {
		this.sInsrdName = sInsrdName;
	}

	/**
	 * @return the sAcdAddrType
	 */
	public String getsAcdAddrType() {
		return sAcdAddrType;
	}

	/**
	 * @param sAcdAddrType the sAcdAddrType to set
	 */
	public void setsAcdAddrType(final String sAcdAddrType) {
		this.sAcdAddrType = sAcdAddrType;
	}

	/**
	 * @return the sAcdZipCode
	 */
	public String getsAcdZipCode() {
		return sAcdZipCode;
	}

	/**
	 * @param sAcdZipCode the sAcdZipCode to set
	 */
	public void setsAcdZipCode(final String sAcdZipCode) {
		this.sAcdZipCode = sAcdZipCode;
	}

	/**
	 * @return the sAcdVilAddr
	 */
	public String getsAcdVilAddr() {
		return sAcdVilAddr;
	}

	/**
	 * @param sAcdVilAddr the sAcdVilAddr to set
	 */
	public void setsAcdVilAddr(final String sAcdVilAddr) {
		this.sAcdVilAddr = sAcdVilAddr;
	}

	/**
	 * @return the sAcdDtlAddr
	 */
	public String getsAcdDtlAddr() {
		return sAcdDtlAddr;
	}

	/**
	 * @param sAcdDtlAddr the sAcdDtlAddr to set
	 */
	public void setsAcdDtlAddr(final String sAcdDtlAddr) {
		this.sAcdDtlAddr = sAcdDtlAddr;
	}

	/**
	 * @return the sAcdDate
	 */
	public String getsAcdDate() {
		return sAcdDate;
	}

	/**
	 * @param sAcdDate the sAcdDate to set
	 */
	public void setsAcdDate(final String sAcdDate) {
		this.sAcdDate = sAcdDate;
	}

	/**
	 * @return the sAcdTime
	 */
	public String getsAcdTime() {
		return sAcdTime;
	}

	/**
	 * @param sAcdTime the sAcdTime to set
	 */
	public void setsAcdTime(final String sAcdTime) {
		this.sAcdTime = sAcdTime;
	}

	/**
	 * @return the sAcdType11
	 */
	public String getsAcdType11() {
		return sAcdType11;
	}

	/**
	 * @param sAcdType11 the sAcdType11 to set
	 */
	public void setsAcdType11(final String sAcdType11) {
		this.sAcdType11 = sAcdType11;
	}

	/**
	 * @return the sAcdType22
	 */
	public String getsAcdType22() {
		return sAcdType22;
	}

	/**
	 * @param sAcdType22 the sAcdType22 to set
	 */
	public void setsAcdType22(final String sAcdType22) {
		this.sAcdType22 = sAcdType22;
	}

	/**
	 * @return the sAutoAcdNum
	 */
	public String getsAutoAcdNum() {
		return sAutoAcdNum;
	}

	/**
	 * @param sAutoAcdNum the sAutoAcdNum to set
	 */
	public void setsAutoAcdNum(final String sAutoAcdNum) {
		this.sAutoAcdNum = sAutoAcdNum;
	}

	/**
	 * @return the sAutoEndYn
	 */
	public String getsAutoEndYn() {
		return sAutoEndYn;
	}

	/**
	 * @param sAutoEndYn the sAutoEndYn to set
	 */
	public void setsAutoEndYn(final String sAutoEndYn) {
		this.sAutoEndYn = sAutoEndYn;
	}

	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr() {
		return sDoroAddr;
	}

	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr(String sDoroAddr) {
		this.sDoroAddr = sDoroAddr;
	}

	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}

	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}

	/**
	 * @return the sStdAddrFlag
	 */
	public String getsStdAddrFlag() {
		return sStdAddrFlag;
	}

	/**
	 * @param sStdAddrFlag the sStdAddrFlag to set
	 */
	public void setsStdAddrFlag(String sStdAddrFlag) {
		this.sStdAddrFlag = sStdAddrFlag;
	}

}
