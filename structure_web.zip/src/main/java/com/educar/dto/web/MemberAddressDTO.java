/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.web;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * ȸ���ּ�(WEBDD02)
 * 
 * @author ������
 * 
 */
public class MemberAddressDTO {
	/** ȸ����ȣ(auto increment�� �ǹ̾��� ID) **/
	private long ID;
	/** ����ȸ�� **/
	private int nModiNo;
	/** ��Ʈ **/
	private String sLast;
	/** �ű��ּ�Ÿ�� **/
	private String sZipType;
	/** ������ȣ1 **/
	private String sZip1;
	/** ������ȣ2 **/
	private String sZip2;
	/** �ּ�1 **/
	private String sADrs1;
	/** �ּ�2 **/
	private String sADrs2;
	/** �ּ�3 **/
	private String sADrs3;
	/** �������ּ�1 **/
	private String sAdrsAdd;
	/** �������ּ�2 **/
	private String sAdrsAdd2;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	//N1401-00089 ���θ��ּ� �߰�
	/** ���λ����ּ� **/
	private String sDoroAddr1;
	/** �ּҰ�����ȣ **/
	private String sAddrMgtNo;
	/** ǥ���ּ���ȯ���� */
	private String sStdAddrFlag;
	/**
	 * @return the iD
	 */
	public long getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(final long iD) {
		ID = iD;
	}

	/**
	 * @return the nModiNo
	 */
	public int getnModiNo() {
		return nModiNo;
	}

	/**
	 * @param nModiNo the nModiNo to set
	 */
	public void setnModiNo(final int nModiNo) {
		this.nModiNo = nModiNo;
	}

	/**
	 * @return the sLast
	 */
	public String getsLast() {
		return sLast;
	}

	/**
	 * @param sLast the sLast to set
	 */
	public void setsLast(final String sLast) {
		this.sLast = sLast;
	}

	/**
	 * @return the sZipType
	 */
	public String getsZipType() {
		return sZipType;
	}

	/**
	 * @param sZipType the sZipType to set
	 */
	public void setsZipType(final String sZipType) {
		this.sZipType = sZipType;
	}

	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}

	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(final String sZip1) {
		this.sZip1 = sZip1;
	}

	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}

	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(final String sZip2) {
		this.sZip2 = sZip2;
	}

	/**
	 * @return the sADrs1
	 */
	public String getsADrs1() {
		return sADrs1;
	}

	/**
	 * @param sADrs1 the sADrs1 to set
	 */
	public void setsADrs1(final String sADrs1) {
		this.sADrs1 = sADrs1;
	}

	/**
	 * @return the sADrs2
	 */
	public String getsADrs2() {
		return sADrs2;
	}

	/**
	 * @param sADrs2 the sADrs2 to set
	 */
	public void setsADrs2(final String sADrs2) {
		this.sADrs2 = sADrs2;
	}

	/**
	 * @return the sADrs3
	 */
	public String getsADrs3() {
		return sADrs3;
	}

	/**
	 * @param sADrs3 the sADrs3 to set
	 */
	public void setsADrs3(final String sADrs3) {
		this.sADrs3 = sADrs3;
	}

	/**
	 * @return the sAdrsAdd
	 */
	public String getsAdrsAdd() {
		return sAdrsAdd;
	}

	/**
	 * @param sAdrsAdd the sAdrsAdd to set
	 */
	public void setsAdrsAdd(final String sAdrsAdd) {
		this.sAdrsAdd = sAdrsAdd;
	}

	/**
	 * @return the sAdrsAdd2
	 */
	public String getsAdrsAdd2() {
		return sAdrsAdd2;
	}

	/**
	 * @param sAdrsAdd2 the sAdrsAdd2 to set
	 */
	public void setsAdrsAdd2(final String sAdrsAdd2) {
		this.sAdrsAdd2 = sAdrsAdd2;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr1() {
		return sDoroAddr1;
	}

	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr1(String sDoroAddr1) {
		this.sDoroAddr1 = sDoroAddr1;
	}

	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}

	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}

	/**
	 * @return the sStdAddrFlag
	 */
	public String getsStdAddrFlag() {
		return sStdAddrFlag;
	}

	/**
	 * @param sStdAddrFlag the sStdAddrFlag to set
	 */
	public void setsStdAddrFlag(String sStdAddrFlag) {
		this.sStdAddrFlag = sStdAddrFlag;
	}
	
}
