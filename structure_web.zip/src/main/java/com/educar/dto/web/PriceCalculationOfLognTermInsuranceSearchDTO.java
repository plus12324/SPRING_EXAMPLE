/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfLognTermInsuranceSearchDTO")
public class PriceCalculationOfLognTermInsuranceSearchDTO {

	/** ���� ��� ���� DTO **/
	private InsuranceContractDesignDTO LTIDA00;
	/** �Ǻ����� ���� DTO **/
	private InsuredDesignedDTO LTIDA01;
	/** ȭ�纸�� ���� DTO **/
	private InsuredHouseFireDTO LTIDA60;
	/** ���� Ư�� DTO **/
	@XmlElementWrapper(name = "vLTIDA02List")
	private List<JoinTheRiderDesignDTO> vLTIDA02;

	/**
	 * @return the lTIDA00
	 */
	public InsuranceContractDesignDTO getLTIDA00() {
		return LTIDA00;
	}

	/**
	 * @param lTIDA00 the lTIDA00 to set
	 */
	public void setLTIDA00(final InsuranceContractDesignDTO lTIDA00) {
		LTIDA00 = lTIDA00;
	}

	/**
	 * @return the lTIDA01
	 */
	public InsuredDesignedDTO getLTIDA01() {
		return LTIDA01;
	}

	/**
	 * @param lTIDA01 the lTIDA01 to set
	 */
	public void setLTIDA01(final InsuredDesignedDTO lTIDA01) {
		LTIDA01 = lTIDA01;
	}

	/**
	 * @return the lTIDA06
	 */
	public InsuredHouseFireDTO getLTIDA60() {
		return LTIDA60;
	}

	/**
	 * @param lTIDA06 the lTIDA06 to set
	 */
	public void setLTIDA06(InsuredHouseFireDTO lTIDA60) {
		LTIDA60 = lTIDA60;
	}

	/**
	 * @return the vLTIDA02
	 */
	public List<JoinTheRiderDesignDTO> getvLTIDA02() {
		return vLTIDA02;
	}

	/**
	 * @param vLTIDA02 the vLTIDA02 to set
	 */
	public void setvLTIDA02(final List<JoinTheRiderDesignDTO> vLTIDA02) {
		this.vLTIDA02 = vLTIDA02;
	}

}
