/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ �� ã�� ��� DTO
 * @author �ּ�ȯ(David SW Choi) 
 * @since 0.0.10
 */
@XmlRootElement(name = "claimCenterSearchDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClaimCenterSearchDTO {
	/** ��/�� (��ȸ�� ���) **/
	private String sArea;
	/** ����/���� (��ȸ�� ���) **/
	private String sName;
	/** ������ �ε��� (��ȸ�� ���) **/
	private String pageIndex;

	/**
	 * @return the sArea
	 */
	public String getsArea() {
		return sArea;
	}

	/**
	 * @param sArea the sArea to set
	 */
	public void setsArea(final String sArea) {
		this.sArea = sArea;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the pageIndex
	 */
	public String getPageIndex() {
		return pageIndex;
	}

	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(final String pageIndex) {
		this.pageIndex = pageIndex;
	}

}
