package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * ���������� ���� ���� ����� Input DTO
 * @author �Ž¿�
 * @since 0.0.10
 */
@XmlRootElement(name = "customerSatisfactionInputDTO")
public class CustomerSatisfactionInputDTO {

	/**	����	**/	
	private String	nSeqNo;
	/**	������	**/	
	private String	sName;
	/**	�����̿� ���ε���1	**/	
	private String	sAgmYn1;
	/**	�����̿� ���ε���2	 **/	
	private String	sAgmYn2;
	/**	�޴�����ȣ1	**/	
	private String	sCellPhone1;
	/**	�޴�����ȣ2	**/	
	private String	sCellPhone2;
	/**	�޴�����ȣ3	**/	
	private String	sCellPhone3;
	/**	���ÿ�����ȣ1	**/	
	private String	sHomeZip1;
	/**	���ÿ�����ȣ2	**/	
	private String	sHomeZip2;
	/**	�����ּ�1	**/	
	private String	sHomeAdrs1;
	/**	�����ּ�2	**/	
	private String	sHomeAdrs2;
	/**	�����ּ�3	**/	
	private String	sHomeAdrs3;
	/**	���ù���	**/	
	private String	sHomeAdrsAdd;
	/**	�Է�����	**/	
	private String	sInputDate;
	/**	�Է½ð�	**/	
	private String	sInputTime;
	/**	�Է���	**/	
	private String	sUserID;
	/**	��������	**/	
	private String	sUpdateDate;
	/**	�����ð�	**/	
	private String	sUpdateTime;
	/**	�������	**/	
	private String	sBirthDate;
	/**	�̺�Ʈ����	**/	
	private String	sEventSeq;
	/**	�� ���θ� �����ּ�	**/	
	private String	sDoroAddr;
	/**	�� ���θ� �ּҰ�����ȣ	**/	
	private String	sAddrMgtNo;
	/**	ǥ���ּ� ��ȯ ����	**/	
	private String	sStdAddrFlag;
	
	
	public String getsEventSeq() {
		return sEventSeq;
	}
	public void setsEventSeq(String sEventSeq) {
		this.sEventSeq = sEventSeq;
	}
	public String getnSeqNo() {
		return nSeqNo;
	}
	public void setnSeqNo(String nSeqNo) {
		this.nSeqNo = nSeqNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsAgmYn1() {
		return sAgmYn1;
	}
	public void setsAgmYn1(String sAgmYn1) {
		this.sAgmYn1 = sAgmYn1;
	}
	public String getsAgmYn2() {
		return sAgmYn2;
	}
	public void setsAgmYn2(String sAgmYn2) {
		this.sAgmYn2 = sAgmYn2;
	}
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	public String getsHomeZip1() {
		return sHomeZip1;
	}
	public void setsHomeZip1(String sHomeZip1) {
		this.sHomeZip1 = sHomeZip1;
	}
	public String getsHomeZip2() {
		return sHomeZip2;
	}
	public void setsHomeZip2(String sHomeZip2) {
		this.sHomeZip2 = sHomeZip2;
	}
	public String getsHomeAdrs1() {
		return sHomeAdrs1;
	}
	public void setsHomeAdrs1(String sHomeAdrs1) {
		this.sHomeAdrs1 = sHomeAdrs1;
	}
	public String getsHomeAdrs2() {
		return sHomeAdrs2;
	}
	public void setsHomeAdrs2(String sHomeAdrs2) {
		this.sHomeAdrs2 = sHomeAdrs2;
	}
	public String getsHomeAdrs3() {
		return sHomeAdrs3;
	}
	public void setsHomeAdrs3(String sHomeAdrs3) {
		this.sHomeAdrs3 = sHomeAdrs3;
	}
	public String getsHomeAdrsAdd() {
		return sHomeAdrsAdd;
	}
	public void setsHomeAdrsAdd(String sHomeAdrsAdd) {
		this.sHomeAdrsAdd = sHomeAdrsAdd;
	}
	public String getsInputDate() {
		return sInputDate;
	}
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	public String getsInputTime() {
		return sInputTime;
	}
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	public String getsUserID() {
		return sUserID;
	}
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	public String getsUpdateDate() {
		return sUpdateDate;
	}
	public void setsUpdateDate(String sUpdateDate) {
		this.sUpdateDate = sUpdateDate;
	}
	public String getsUpdateTime() {
		return sUpdateTime;
	}
	public void setsUpdateTime(String sUpdateTime) {
		this.sUpdateTime = sUpdateTime;
	}
	public String getsBirthDate() {
		return sBirthDate;
	}
	public void setsBirthDate(String sBirthDate) {
		this.sBirthDate = sBirthDate;
	}
	/**
	 * @return the sDoroAddr
	 */
	public String getsDoroAddr() {
		return sDoroAddr;
	}
	/**
	 * @param sDoroAddr the sDoroAddr to set
	 */
	public void setsDoroAddr(String sDoroAddr) {
		this.sDoroAddr = sDoroAddr;
	}
	/**
	 * @return the sAddrMgtNo
	 */
	public String getsAddrMgtNo() {
		return sAddrMgtNo;
	}
	/**
	 * @param sAddrMgtNo the sAddrMgtNo to set
	 */
	public void setsAddrMgtNo(String sAddrMgtNo) {
		this.sAddrMgtNo = sAddrMgtNo;
	}
	/**
	 * @return the sStdAddrFlag
	 */
	public String getsStdAddrFlag() {
		return sStdAddrFlag;
	}
	/**
	 * @param sStdAddrFlag the sStdAddrFlag to set
	 */
	public void setsStdAddrFlag(String sStdAddrFlag) {
		this.sStdAddrFlag = sStdAddrFlag;
	}

	
}
