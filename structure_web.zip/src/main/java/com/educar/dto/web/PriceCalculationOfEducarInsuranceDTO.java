/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "priceCalculationOfEducarInsuranceDTO")
public class PriceCalculationOfEducarInsuranceDTO {
	/** �Ѻ���� **/
	private String nBasePrm;
	/** �г������ **/
	private String bun_nab_prm;
	/** �㺸���Աݾ� (���� ȭ�鿡�� �������� ��)**/
	private String sHanAmt;
	/** �㺸���Աݾ� (������) �Ⱓ�� ��ȯ�� **/
	private String sHanAmtA;
	/** �㺸���Աݾ� (�⺻��) �Ⱓ�� ��ȯ�� **/
	private String sHanAmtB;
	/** �㺸���Աݾ� (������)  �Ⱓ�� ��ȯ��**/
	private String sHanAmtC;
	/** �㺸�� **/
	private String sCovNam;
	/** �㺸�ڵ� **/
	private String sCovCod;
	/** �㺸����� **/
	private String nApplyPrm;

	/**
	 * @return the nBasePrm
	 */
	public String getnBasePrm() {
		return nBasePrm;
	}

	/**
	 * @param nBasePrm the nBasePrm to set
	 */
	public void setnBasePrm(final String nBasePrm) {
		this.nBasePrm = nBasePrm;
	}

	/**
	 * @return the bun_nab_prm
	 */
	public String getBun_nab_prm() {
		return bun_nab_prm;
	}

	/**
	 * @param bun_nab_prm the bun_nab_prm to set
	 */
	public void setBun_nab_prm(final String bun_nab_prm) {
		this.bun_nab_prm = bun_nab_prm;
	}

	/**
	 * @return the sHanAmt
	 */
	public String getsHanAmt() {
		return sHanAmt;
	}

	/**
	 * @param sHanAmt the sHanAmt to set
	 */
	public void setsHanAmt(final String sHanAmt) {
		this.sHanAmt = sHanAmt;
	}

	/**
	 * @return the sHanAmtA
	 */
	public String getsHanAmtA() {
		return sHanAmtA;
	}

	/**
	 * @param sHanAmtA the sHanAmtA to set
	 */
	public void setsHanAmtA(final String sHanAmtA) {
		this.sHanAmtA = sHanAmtA;
	}

	/**
	 * @return the sHanAmtB
	 */
	public String getsHanAmtB() {
		return sHanAmtB;
	}

	/**
	 * @param sHanAmtB the sHanAmtB to set
	 */
	public void setsHanAmtB(final String sHanAmtB) {
		this.sHanAmtB = sHanAmtB;
	}

	/**
	 * @return the sHanAmtC
	 */
	public String getsHanAmtC() {
		return sHanAmtC;
	}

	/**
	 * @param sHanAmtC the sHanAmtC to set
	 */
	public void setsHanAmtC(final String sHanAmtC) {
		this.sHanAmtC = sHanAmtC;
	}

	/**
	 * @return the sCovNam
	 */
	public String getsCovNam() {
		return sCovNam;
	}

	/**
	 * @param sCovNam the sCovNam to set
	 */
	public void setsCovNam(final String sCovNam) {
		this.sCovNam = sCovNam;
	}

	/**
	 * @return the sCovCod
	 */
	public String getsCovCod() {
		return sCovCod;
	}

	/**
	 * @param sCovCod the sCovCod to set
	 */
	public void setsCovCod(final String sCovCod) {
		this.sCovCod = sCovCod;
	}

	/**
	 * @return the nApplyPrm
	 */
	public String getnApplyPrm() {
		return nApplyPrm;
	}

	/**
	 * @param nApplyPrm the nApplyPrm to set
	 */
	public void setnApplyPrm(final String nApplyPrm) {
		this.nApplyPrm = nApplyPrm;
	}

}
