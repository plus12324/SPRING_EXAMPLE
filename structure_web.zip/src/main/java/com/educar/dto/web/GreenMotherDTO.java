/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import com.educar.common.dto.PageDTO;

/**
 * <pre>
 * �����Ӵ� �Խ��� ���� DTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "greenMotherDTO")
public class GreenMotherDTO extends PageDTO{

	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	/** 	�Ϸù�ȣ	**/ 
	private Integer 	nSeq;
	/** 	����	**/ 
	private String 	sTitle;
	/** 	����	**/ 
	private String 	sContent;
	/** 	�ۼ���	**/ 
	private String 	sName;
	/** 	�ۼ���й�ȣ	**/ 
	private String 	sPassword;
	/** 	�ۼ����޴�����ȣ	**/ 
	private String 	sCellPhone;
	/** 	�б��ڵ�	**/ 
	private String 	sSchoolCode	;
	/** 	�б��ڵ�	**/ 
	private String 	sSchoolName;
	/** 	�б��ּ�	**/ 
	private String 	sSchoolAdrs;
	/** 	��������	**/
	private String 	sViewYn;
	/** 	��ȸ��	**/ 
	private int 	nVisitCnt;
	/** 	��ܰ�������	**/ 
	private String 	sTopYn;
	/** 	�������1	**/ 
	private String 	sFileTypeURI1;
	/** 	������1	**/ 
	private String 	sFileName1;
	/** 	�������2	**/ 
	private String 	sFileTypeURI2;
	/** 	������2	**/ 
	private String 	sFileName2;
	/** 	������	**/ 
	private String 	sRegId;
	/** 	������¥	**/ 
	private String 	sRegDate	;
	/** 	�����ð�	**/ 
	private String 	sRegTime;
	/** 	������	**/ 
	private String 	sUpId;
	/** 	������¥	**/ 
	private String 	sUpDate;
	/** 	�����ð�	**/ 
	private String 	sUpTime;
	/**		���Ͽ��� **/
	private String	sFileYn;
	/** 	���۰��� **/
	private String  sCmtCnt;
	/** 	�Խ��� **/
	private String  sOpenDate;
	/** �˻��� ī�װ��� (��ü: all, ����: title, ����: contents)*/
	private String searchType;
	/** �˻��� */
	private String searchTxt;
	
	/** �˻����� "": ��ü, 1: ����, 2: ���� (�����ڿ��� ���) **/
	@XmlTransient
	private String kind;
	/** �˻��� **/
	@XmlTransient
	private String searchValue;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String startOpenDate;
	/** �Խ��� ������ (�����ڿ��� ���) **/
	@XmlTransient
	private String endOpenDate;
	
	/** 	����ID	**/ 
	private String 	sFileID1;
	/** 	����ID	**/ 
	private String 	sFileID2;
	
	/** 	����Url Path(���ο��� ���)	**/ 
	private String 	sImgUrl1;
	/** 	����Url Path(���ο��� ���)	**/ 
	private String 	sImgUrl2; 

	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(Integer nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}
	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	/**
	 * @return the sContent
	 */
	public String getsContent() {
		return sContent;
	}
	/**
	 * @param sContent the sContent to set
	 */
	public void setsContent(String sContent) {
		this.sContent = sContent;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	/**
	 * @return the sCellPhone
	 */
	public String getsCellPhone() {
		return sCellPhone;
	}
	/**
	 * @param sCellPhone the sCellPhone to set
	 */
	public void setsCellPhone(String sCellPhone) {
		this.sCellPhone = sCellPhone;
	}
	/**
	 * @return the sSchoolCode
	 */
	public String getsSchoolCode() {
		return sSchoolCode;
	}
	/**
	 * @param sSchoolCode the sSchoolCode to set
	 */
	public void setsSchoolCode(String sSchoolCode) {
		this.sSchoolCode = sSchoolCode;
	}
	/**
	 * @return the sViewYn
	 */
	public String getsViewYn() {
		return sViewYn;
	}
	/**
	 * @param sViewYn the sViewYn to set
	 */
	public void setsViewYn(String sViewYn) {
		this.sViewYn = sViewYn;
	}
	/**
	 * @return the nVisitCnt
	 */
	public int getnVisitCnt() {
		return nVisitCnt;
	}
	/**
	 * @param nVisitCnt the nVisitCnt to set
	 */
	public void setnVisitCnt(int nVisitCnt) {
		this.nVisitCnt = nVisitCnt;
	}
	/**
	 * @return the sTopYn
	 */
	public String getsTopYn() {
		return sTopYn;
	}
	/**
	 * @param sTopYn the sTopYn to set
	 */
	public void setsTopYn(String sTopYn) {
		this.sTopYn = sTopYn;
	}
	/**
	 * @return the sFileTypeURI1
	 */
	public String getsFileTypeURI1() {
		return sFileTypeURI1;
	}
	/**
	 * @param sFileTypeURI1 the sFileTypeURI1 to set
	 */
	public void setsFileTypeURI1(String sFileTypeURI1) {
		this.sFileTypeURI1 = sFileTypeURI1;
	}
	/**
	 * @return the sFileName1
	 */
	public String getsFileName1() {
		return sFileName1;
	}
	/**
	 * @param sFileName1 the sFileName1 to set
	 */
	public void setsFileName1(String sFileName1) {
		this.sFileName1 = sFileName1;
	}
	/**
	 * @return the sFileTypeURI2
	 */
	public String getsFileTypeURI2() {
		return sFileTypeURI2;
	}
	/**
	 * @param sFileTypeURI2 the sFileTypeURI2 to set
	 */
	public void setsFileTypeURI2(String sFileTypeURI2) {
		this.sFileTypeURI2 = sFileTypeURI2;
	}
	/**
	 * @return the sFileName2
	 */
	public String getsFileName2() {
		return sFileName2;
	}
	/**
	 * @param sFileName2 the sFileName2 to set
	 */
	public void setsFileName2(String sFileName2) {
		this.sFileName2 = sFileName2;
	}
	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}
	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(String sRegId) {
		this.sRegId = sRegId;
	}
	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}
	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(String sRegDate) {
		this.sRegDate = sRegDate;
	}
	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}
	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(String sRegTime) {
		this.sRegTime = sRegTime;
	}
	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}
	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(String sUpId) {
		this.sUpId = sUpId;
	}
	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}
	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(String sUpDate) {
		this.sUpDate = sUpDate;
	}
	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}
	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(String sUpTime) {
		this.sUpTime = sUpTime;
	}
	/**
	 * @return the sFileYn
	 */
	public String getsFileYn() {
		return sFileYn;
	}
	/**
	 * @param sFileYn the sFileYn to set
	 */
	public void setsFileYn(String sFileYn) {
		this.sFileYn = sFileYn;
	}
	/**
	 * @return the sCmtCnt
	 */
	public String getsCmtCnt() {
		return sCmtCnt;
	}
	/**
	 * @param sCmtCnt the sCmtCnt to set
	 */
	public void setsCmtCnt(String sCmtCnt) {
		this.sCmtCnt = sCmtCnt;
	}
	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}
	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}
	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}
	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}
	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}
	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	/**
	 * @return the startOpenDate
	 */
	public String getStartOpenDate() {
		return startOpenDate;
	}
	/**
	 * @param startOpenDate the startOpenDate to set
	 */
	public void setStartOpenDate(String startOpenDate) {
		this.startOpenDate = startOpenDate;
	}
	/**
	 * @return the endOpenDate
	 */
	public String getEndOpenDate() {
		return endOpenDate;
	}
	/**
	 * @param endOpenDate the endOpenDate to set
	 */
	public void setEndOpenDate(String endOpenDate) {
		this.endOpenDate = endOpenDate;
	}
	/**
	 * @return the searchType
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType the searchType to set
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return the searchTxt
	 */
	public String getSearchTxt() {
		return searchTxt;
	}
	/**
	 * @param searchTxt the searchTxt to set
	 */
	public void setSearchTxt(String searchTxt) {
		this.searchTxt = searchTxt;
	}
	/**
	 * @return the sSchoolName
	 */
	public String getsSchoolName() {
		return sSchoolName;
	}
	/**
	 * @param sSchoolName the sSchoolName to set
	 */
	public void setsSchoolName(String sSchoolName) {
		this.sSchoolName = sSchoolName;
	}
	/**
	 * @return the sFileID1
	 */
	public String getsFileID1() {
		return sFileID1;
	}
	/**
	 * @param sFileID1 the sFileID1 to set
	 */
	public void setsFileID1(String sFileID1) {
		this.sFileID1 = sFileID1;
	}
	/**
	 * @return the sFileID2
	 */
	public String getsFileID2() {
		return sFileID2;
	}
	/**
	 * @param sFileID2 the sFileID2 to set
	 */
	public void setsFileID2(String sFileID2) {
		this.sFileID2 = sFileID2;
	}
	/**
	 * @return the sSchoolAdrs
	 */
	public String getsSchoolAdrs() {
		return sSchoolAdrs;
	}
	/**
	 * @param sSchoolAdrs the sSchoolAdrs to set
	 */
	public void setsSchoolAdrs(String sSchoolAdrs) {
		this.sSchoolAdrs = sSchoolAdrs;
	}
	/**
	 * @return the sImgUrl1
	 */
	public String getsImgUrl1() {
		return sImgUrl1;
	}
	/**
	 * @param sImgUrl1 the sImgUrl1 to set
	 */
	public void setsImgUrl1(String sImgUrl1) {
		this.sImgUrl1 = sImgUrl1;
	}
	/**
	 * @return the sImgUrl2
	 */
	public String getsImgUrl2() {
		return sImgUrl2;
	}
	/**
	 * @param sImgUrl2 the sImgUrl2 to set
	 */
	public void setsImgUrl2(String sImgUrl2) {
		this.sImgUrl2 = sImgUrl2;
	}


}
