/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������Ȯ�� ��⺸�� ���峻�� ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectTrtyResultDTO")
public class SelectTrtyResultDTO {
	/** ����ȣ **/
	private String sCrNo;
	/** �ι���ü�����ڵ� **/
	private String sPsnPrprtGroupFlgcd;
	/** �ι���ü�Ϸù�ȣ **/
	private String nPsnPrprtGroupSeqno;
	/** Ư���ڵ� **/
	private String sTrtyCd;
	/** ��ຯ���ȣ **/
	private String nCrChngNo;
	/** �⺻���ñ����ڵ� **/
	private String sBascSlctFlagCd;
	/** �ڵ����Ű��ɿ��� **/
	private String sAutoRenwlAvaYn;
	/** �ڵ������ֱ��ڵ� **/
	private String sAutoRenwlCyclCd;
	/** ���谡�Աݾ� **/
	private String nTrtyInsAmt;
	/** ���谡�Աݾ׸� **/
	private String nTrtyInsAmtName;
	/** �ڱ�δ�� **/
	private String nSelfChamt;
	/** Ư�ຸ��� **/
	private String nTrtyPrem;
	/** ���庸��� **/
	private String nGrntPrem;
	/** ��ǰ�ڵ� **/
	private String sGdCd;
	/** �����ڵ� **/
	private String sGnrzCd;
	/** ����Ƚ�� **/
	private String nRenwlSeq;
	/** �������� **/
	private String sRenwlYn;
	/** ���ԱⰣ�ڵ� **/
	private String sPaymTermCd;
	/** �ǳ��ԱⰣ **/
	private String nRealPaymTerm;
	/** ����Ⱓ�ڵ� **/
	private String sInsurTermCd;
	/** �Ǻ���Ⱓ **/
	private String nRealInsurTerm;
	/** ���Կ��� **/
	private String nPaymAge;
	/** ���⿬�� **/
	private String nEndAge;
	/** Ư������ڵ� **/
	private String sTrtyStatCd;
	/** ������ñ� **/
	private String sInsurStrtdate;
	/** ���������� **/
	private String sInsurEndDate;
	/** �����Ҹ길������ **/
	private String sCnclExtnEndDate;
	/** ���ԱⰣ�������� **/
	private String sPaymTermStrtDate;
	/** ���ԱⰣ�������� **/
	private String sPaymTermEndDate;
	/** �����ֱ��ڵ� **/
	private String sPaymCyclCd;
	/** �Է�ó���� **/
	private String sInptDler;
	/** �Է�ó����IP **/
	private String sInptDlerIP;
	/** �Է����� **/
	private String sInptDate;
	/** �Է½ð� **/
	private String sInptHms;
	/** ����ó���� **/
	private String sMdfcDler;
	/** ����ó����IP **/
	private String sMdfcDlerIP;
	/** �������� **/
	private String sMdfcDate;
	/** �����ð� **/
	private String sMdfcHms;
	/** �⺻���ñ��и� **/
	private String sBascSlctFlagNm;
	/** �ڵ������ֱ�� **/
	private String sAutoRenwlCyclNm;
	/** ���ԱⰣ�� **/
	private String sPaymTermNm;
	/** ����Ⱓ�� **/
	private String sInsurTermNm;
	/** Ư����¸� **/
	private String sTrtyStatNm;
	/** Ư��� **/
	private String sTrtyNm;
	/** �����念������� **/
	private String nExptGrntBussPrem;

	/**
	 * @return the sCrNo
	 */
	public String getsCrNo() {
		return sCrNo;
	}

	/**
	 * @param sCrNo the sCrNo to set
	 */
	public void setsCrNo(final String sCrNo) {
		this.sCrNo = sCrNo;
	}

	/**
	 * @return the sPsnPrprtGroupFlgcd
	 */
	public String getsPsnPrprtGroupFlgcd() {
		return sPsnPrprtGroupFlgcd;
	}

	/**
	 * @param sPsnPrprtGroupFlgcd the sPsnPrprtGroupFlgcd to set
	 */
	public void setsPsnPrprtGroupFlgcd(final String sPsnPrprtGroupFlgcd) {
		this.sPsnPrprtGroupFlgcd = sPsnPrprtGroupFlgcd;
	}

	/**
	 * @return the nPsnPrprtGroupSeqno
	 */
	public String getnPsnPrprtGroupSeqno() {
		return nPsnPrprtGroupSeqno;
	}

	/**
	 * @param nPsnPrprtGroupSeqno the nPsnPrprtGroupSeqno to set
	 */
	public void setnPsnPrprtGroupSeqno(final String nPsnPrprtGroupSeqno) {
		this.nPsnPrprtGroupSeqno = nPsnPrprtGroupSeqno;
	}

	/**
	 * @return the sTrtyCd
	 */
	public String getsTrtyCd() {
		return sTrtyCd;
	}

	/**
	 * @param sTrtyCd the sTrtyCd to set
	 */
	public void setsTrtyCd(final String sTrtyCd) {
		this.sTrtyCd = sTrtyCd;
	}

	/**
	 * @return the nCrChngNo
	 */
	public String getnCrChngNo() {
		return nCrChngNo;
	}

	/**
	 * @param nCrChngNo the nCrChngNo to set
	 */
	public void setnCrChngNo(final String nCrChngNo) {
		this.nCrChngNo = nCrChngNo;
	}

	/**
	 * @return the sBascSlctFlagCd
	 */
	public String getsBascSlctFlagCd() {
		return sBascSlctFlagCd;
	}

	/**
	 * @param sBascSlctFlagCd the sBascSlctFlagCd to set
	 */
	public void setsBascSlctFlagCd(final String sBascSlctFlagCd) {
		this.sBascSlctFlagCd = sBascSlctFlagCd;
	}

	/**
	 * @return the sAutoRenwlAvaYn
	 */
	public String getsAutoRenwlAvaYn() {
		return sAutoRenwlAvaYn;
	}

	/**
	 * @param sAutoRenwlAvaYn the sAutoRenwlAvaYn to set
	 */
	public void setsAutoRenwlAvaYn(final String sAutoRenwlAvaYn) {
		this.sAutoRenwlAvaYn = sAutoRenwlAvaYn;
	}

	/**
	 * @return the sAutoRenwlCyclCd
	 */
	public String getsAutoRenwlCyclCd() {
		return sAutoRenwlCyclCd;
	}

	/**
	 * @param sAutoRenwlCyclCd the sAutoRenwlCyclCd to set
	 */
	public void setsAutoRenwlCyclCd(final String sAutoRenwlCyclCd) {
		this.sAutoRenwlCyclCd = sAutoRenwlCyclCd;
	}

	/**
	 * @return the nTrtyInsAmt
	 */
	public String getnTrtyInsAmt() {
		return nTrtyInsAmt;
	}

	/**
	 * @param nTrtyInsAmt the nTrtyInsAmt to set
	 */
	public void setnTrtyInsAmt(final String nTrtyInsAmt) {
		this.nTrtyInsAmt = nTrtyInsAmt;
	}

	/**
	 * @return the nTrtyInsAmtName
	 */
	public String getnTrtyInsAmtName() {
		return nTrtyInsAmtName;
	}

	/**
	 * @param nTrtyInsAmtName the nTrtyInsAmtName to set
	 */
	public void setnTrtyInsAmtName(final String nTrtyInsAmtName) {
		this.nTrtyInsAmtName = nTrtyInsAmtName;
	}

	/**
	 * @return the nSelfChamt
	 */
	public String getnSelfChamt() {
		return nSelfChamt;
	}

	/**
	 * @param nSelfChamt the nSelfChamt to set
	 */
	public void setnSelfChamt(final String nSelfChamt) {
		this.nSelfChamt = nSelfChamt;
	}

	/**
	 * @return the nTrtyPrem
	 */
	public String getnTrtyPrem() {
		return nTrtyPrem;
	}

	/**
	 * @param nTrtyPrem the nTrtyPrem to set
	 */
	public void setnTrtyPrem(final String nTrtyPrem) {
		this.nTrtyPrem = nTrtyPrem;
	}

	/**
	 * @return the nGrntPrem
	 */
	public String getnGrntPrem() {
		return nGrntPrem;
	}

	/**
	 * @param nGrntPrem the nGrntPrem to set
	 */
	public void setnGrntPrem(final String nGrntPrem) {
		this.nGrntPrem = nGrntPrem;
	}

	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}

	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(final String sGdCd) {
		this.sGdCd = sGdCd;
	}

	/**
	 * @return the sGnrzCd
	 */
	public String getsGnrzCd() {
		return sGnrzCd;
	}

	/**
	 * @param sGnrzCd the sGnrzCd to set
	 */
	public void setsGnrzCd(final String sGnrzCd) {
		this.sGnrzCd = sGnrzCd;
	}

	/**
	 * @return the nRenwlSeq
	 */
	public String getnRenwlSeq() {
		return nRenwlSeq;
	}

	/**
	 * @param nRenwlSeq the nRenwlSeq to set
	 */
	public void setnRenwlSeq(final String nRenwlSeq) {
		this.nRenwlSeq = nRenwlSeq;
	}

	/**
	 * @return the sRenwlYn
	 */
	public String getsRenwlYn() {
		return sRenwlYn;
	}

	/**
	 * @param sRenwlYn the sRenwlYn to set
	 */
	public void setsRenwlYn(final String sRenwlYn) {
		this.sRenwlYn = sRenwlYn;
	}

	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}

	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(final String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}

	/**
	 * @return the nRealPaymTerm
	 */
	public String getnRealPaymTerm() {
		return nRealPaymTerm;
	}

	/**
	 * @param nRealPaymTerm the nRealPaymTerm to set
	 */
	public void setnRealPaymTerm(final String nRealPaymTerm) {
		this.nRealPaymTerm = nRealPaymTerm;
	}

	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}

	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(final String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}

	/**
	 * @return the nRealInsurTerm
	 */
	public String getnRealInsurTerm() {
		return nRealInsurTerm;
	}

	/**
	 * @param nRealInsurTerm the nRealInsurTerm to set
	 */
	public void setnRealInsurTerm(final String nRealInsurTerm) {
		this.nRealInsurTerm = nRealInsurTerm;
	}

	/**
	 * @return the nPaymAge
	 */
	public String getnPaymAge() {
		return nPaymAge;
	}

	/**
	 * @param nPaymAge the nPaymAge to set
	 */
	public void setnPaymAge(final String nPaymAge) {
		this.nPaymAge = nPaymAge;
	}

	/**
	 * @return the nEndAge
	 */
	public String getnEndAge() {
		return nEndAge;
	}

	/**
	 * @param nEndAge the nEndAge to set
	 */
	public void setnEndAge(final String nEndAge) {
		this.nEndAge = nEndAge;
	}

	/**
	 * @return the sTrtyStatCd
	 */
	public String getsTrtyStatCd() {
		return sTrtyStatCd;
	}

	/**
	 * @param sTrtyStatCd the sTrtyStatCd to set
	 */
	public void setsTrtyStatCd(final String sTrtyStatCd) {
		this.sTrtyStatCd = sTrtyStatCd;
	}

	/**
	 * @return the sInsurStrtdate
	 */
	public String getsInsurStrtdate() {
		return sInsurStrtdate;
	}

	/**
	 * @param sInsurStrtdate the sInsurStrtdate to set
	 */
	public void setsInsurStrtdate(final String sInsurStrtdate) {
		this.sInsurStrtdate = sInsurStrtdate;
	}

	/**
	 * @return the sInsurEndDate
	 */
	public String getsInsurEndDate() {
		return sInsurEndDate;
	}

	/**
	 * @param sInsurEndDate the sInsurEndDate to set
	 */
	public void setsInsurEndDate(final String sInsurEndDate) {
		this.sInsurEndDate = sInsurEndDate;
	}

	/**
	 * @return the sCnclExtnEndDate
	 */
	public String getsCnclExtnEndDate() {
		return sCnclExtnEndDate;
	}

	/**
	 * @param sCnclExtnEndDate the sCnclExtnEndDate to set
	 */
	public void setsCnclExtnEndDate(final String sCnclExtnEndDate) {
		this.sCnclExtnEndDate = sCnclExtnEndDate;
	}

	/**
	 * @return the sPaymTermStrtDate
	 */
	public String getsPaymTermStrtDate() {
		return sPaymTermStrtDate;
	}

	/**
	 * @param sPaymTermStrtDate the sPaymTermStrtDate to set
	 */
	public void setsPaymTermStrtDate(final String sPaymTermStrtDate) {
		this.sPaymTermStrtDate = sPaymTermStrtDate;
	}

	/**
	 * @return the sPaymTermEndDate
	 */
	public String getsPaymTermEndDate() {
		return sPaymTermEndDate;
	}

	/**
	 * @param sPaymTermEndDate the sPaymTermEndDate to set
	 */
	public void setsPaymTermEndDate(final String sPaymTermEndDate) {
		this.sPaymTermEndDate = sPaymTermEndDate;
	}

	/**
	 * @return the sPaymCyclCd
	 */
	public String getsPaymCyclCd() {
		return sPaymCyclCd;
	}

	/**
	 * @param sPaymCyclCd the sPaymCyclCd to set
	 */
	public void setsPaymCyclCd(final String sPaymCyclCd) {
		this.sPaymCyclCd = sPaymCyclCd;
	}

	/**
	 * @return the sInptDler
	 */
	public String getsInptDler() {
		return sInptDler;
	}

	/**
	 * @param sInptDler the sInptDler to set
	 */
	public void setsInptDler(final String sInptDler) {
		this.sInptDler = sInptDler;
	}

	/**
	 * @return the sInptDlerIP
	 */
	public String getsInptDlerIP() {
		return sInptDlerIP;
	}

	/**
	 * @param sInptDlerIP the sInptDlerIP to set
	 */
	public void setsInptDlerIP(final String sInptDlerIP) {
		this.sInptDlerIP = sInptDlerIP;
	}

	/**
	 * @return the sInptDate
	 */
	public String getsInptDate() {
		return sInptDate;
	}

	/**
	 * @param sInptDate the sInptDate to set
	 */
	public void setsInptDate(final String sInptDate) {
		this.sInptDate = sInptDate;
	}

	/**
	 * @return the sInptHms
	 */
	public String getsInptHms() {
		return sInptHms;
	}

	/**
	 * @param sInptHms the sInptHms to set
	 */
	public void setsInptHms(final String sInptHms) {
		this.sInptHms = sInptHms;
	}

	/**
	 * @return the sMdfcDler
	 */
	public String getsMdfcDler() {
		return sMdfcDler;
	}

	/**
	 * @param sMdfcDler the sMdfcDler to set
	 */
	public void setsMdfcDler(final String sMdfcDler) {
		this.sMdfcDler = sMdfcDler;
	}

	/**
	 * @return the sMdfcDlerIP
	 */
	public String getsMdfcDlerIP() {
		return sMdfcDlerIP;
	}

	/**
	 * @param sMdfcDlerIP the sMdfcDlerIP to set
	 */
	public void setsMdfcDlerIP(final String sMdfcDlerIP) {
		this.sMdfcDlerIP = sMdfcDlerIP;
	}

	/**
	 * @return the sMdfcDate
	 */
	public String getsMdfcDate() {
		return sMdfcDate;
	}

	/**
	 * @param sMdfcDate the sMdfcDate to set
	 */
	public void setsMdfcDate(final String sMdfcDate) {
		this.sMdfcDate = sMdfcDate;
	}

	/**
	 * @return the sMdfcHms
	 */
	public String getsMdfcHms() {
		return sMdfcHms;
	}

	/**
	 * @param sMdfcHms the sMdfcHms to set
	 */
	public void setsMdfcHms(final String sMdfcHms) {
		this.sMdfcHms = sMdfcHms;
	}

	/**
	 * @return the sBascSlctFlagNm
	 */
	public String getsBascSlctFlagNm() {
		return sBascSlctFlagNm;
	}

	/**
	 * @param sBascSlctFlagNm the sBascSlctFlagNm to set
	 */
	public void setsBascSlctFlagNm(final String sBascSlctFlagNm) {
		this.sBascSlctFlagNm = sBascSlctFlagNm;
	}

	/**
	 * @return the sAutoRenwlCyclNm
	 */
	public String getsAutoRenwlCyclNm() {
		return sAutoRenwlCyclNm;
	}

	/**
	 * @param sAutoRenwlCyclNm the sAutoRenwlCyclNm to set
	 */
	public void setsAutoRenwlCyclNm(final String sAutoRenwlCyclNm) {
		this.sAutoRenwlCyclNm = sAutoRenwlCyclNm;
	}

	/**
	 * @return the sPaymTermNm
	 */
	public String getsPaymTermNm() {
		return sPaymTermNm;
	}

	/**
	 * @param sPaymTermNm the sPaymTermNm to set
	 */
	public void setsPaymTermNm(final String sPaymTermNm) {
		this.sPaymTermNm = sPaymTermNm;
	}

	/**
	 * @return the sInsurTermNm
	 */
	public String getsInsurTermNm() {
		return sInsurTermNm;
	}

	/**
	 * @param sInsurTermNm the sInsurTermNm to set
	 */
	public void setsInsurTermNm(final String sInsurTermNm) {
		this.sInsurTermNm = sInsurTermNm;
	}

	/**
	 * @return the sTrtyStatNm
	 */
	public String getsTrtyStatNm() {
		return sTrtyStatNm;
	}

	/**
	 * @param sTrtyStatNm the sTrtyStatNm to set
	 */
	public void setsTrtyStatNm(final String sTrtyStatNm) {
		this.sTrtyStatNm = sTrtyStatNm;
	}

	/**
	 * @return the sTrtyNm
	 */
	public String getsTrtyNm() {
		return sTrtyNm;
	}

	/**
	 * @param sTrtyNm the sTrtyNm to set
	 */
	public void setsTrtyNm(final String sTrtyNm) {
		this.sTrtyNm = sTrtyNm;
	}

	/**
	 * @return the nExptGrntBussPrem
	 */
	public String getnExptGrntBussPrem() {
		return nExptGrntBussPrem;
	}

	/**
	 * @param nExptGrntBussPrem the nExptGrntBussPrem to set
	 */
	public void setnExptGrntBussPrem(final String nExptGrntBussPrem) {
		this.nExptGrntBussPrem = nExptGrntBussPrem;
	}

}
