/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ��⺸�� �÷���ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "longTermInsurancePlanSearchDTO")
public class LongTermInsurancePlanSearchDTO {
	/** ��ǰ�ڵ� **/
	private String sGdCd;
	/** �����ڵ� **/
	private String sGnrzCd;
	/** �÷��ڵ� **/
	private String sPlanCd;
	/**
	 * <pre> 
	 * �Ǻ������ֹι�ȣ 
	 * (ȭ�鿡�� ���� ������� �ڿ��� �߰��Ͽ� 13�ڸ� �������1984�� 9�� 16�� ���� ���(8409161000000))
	 * </pre> 
	 **/
	private String sResno;
	/** ���������ڵ� (�����ڵ带 ���� �����޼��� ������ �´�)**/
	private String sDrivFlagCd;

	/** ����Ⱓ(7�� : 107, 10�� : 110, 20�� : 120) **/
	private String sInsurTermCd;
	/** ���ԱⰣ(7�� : 107, 10�� : 110, 20�� : 120, �����ֱⰡ �Ͻó��� ��� : 000) **/
	private String sPaymTermCd;
	/** �����ֱ�(����:12, 2����:06, 3����:04, 6����:02, �ⳳ:01, �Ͻó�:99) **/
	private String sPaymCyclCd;
	
	//���ݺ��� �߰�
	/** û����		**/
	private String sStndDate;
	/** �����з��ڵ�		**/
	private String sBunsMetdDocuClsfCd;
	/** ���ݰ��ó���		**/
	private String sAnntOpnAgeCd;
	/** �������ޱⰣ		**/
	private String sAnntPymTermCd;


	/**
	 * @return the sGdCd
	 */
	public String getsGdCd() {
		return sGdCd;
	}

	/**
	 * @param sGdCd the sGdCd to set
	 */
	public void setsGdCd(final String sGdCd) {
		this.sGdCd = sGdCd;
	}

	/**
	 * @return the sPlanCd
	 */
	public String getsPlanCd() {
		return sPlanCd;
	}

	/**
	 * @param sPlanCd the sPlanCd to set
	 */
	public void setsPlanCd(final String sPlanCd) {
		this.sPlanCd = sPlanCd;
	}

	/**
	 * @return the sResno
	 */
	public String getsResno() {
		return sResno;
	}

	/**
	 * @param sResno the sResno to set
	 */
	public void setsResno(final String sResno) {
		this.sResno = sResno;
	}

	/**
	 * @return the sDrivFlagCd
	 */
	public String getsDrivFlagCd() {
		return sDrivFlagCd;
	}

	/**
	 * @param sDrivFlagCd the sDrivFlagCd to set
	 */
	public void setsDrivFlagCd(final String sDrivFlagCd) {
		this.sDrivFlagCd = sDrivFlagCd;
	}

	/**
	 * @return the sInsurTermCd
	 */
	public String getsInsurTermCd() {
		return sInsurTermCd;
	}

	/**
	 * @param sInsurTermCd the sInsurTermCd to set
	 */
	public void setsInsurTermCd(final String sInsurTermCd) {
		this.sInsurTermCd = sInsurTermCd;
	}

	/**
	 * @return the sPaymTermCd
	 */
	public String getsPaymTermCd() {
		return sPaymTermCd;
	}

	/**
	 * @param sPaymTermCd the sPaymTermCd to set
	 */
	public void setsPaymTermCd(final String sPaymTermCd) {
		this.sPaymTermCd = sPaymTermCd;
	}

	/**
	 * @return the sPaymCyclCd
	 */
	public String getsPaymCyclCd() {
		return sPaymCyclCd;
	}

	/**
	 * @param sPaymCyclCd the sPaymCyclCd to set
	 */
	public void setsPaymCyclCd(final String sPaymCyclCd) {
		this.sPaymCyclCd = sPaymCyclCd;
	}

	/**
	 * @return the sGnrzCd
	 */
	public String getsGnrzCd() {
		return sGnrzCd;
	}

	/**
	 * @param sGnrzCd the sGnrzCd to set
	 */
	public void setsGnrzCd(String sGnrzCd) {
		this.sGnrzCd = sGnrzCd;
	}

	/**
	 * @return the sStndDate
	 */
	public String getsStndDate() {
		return sStndDate;
	}

	/**
	 * @param sStndDate the sStndDate to set
	 */
	public void setsStndDate(String sStndDate) {
		this.sStndDate = sStndDate;
	}

	/**
	 * @return the sBunsMetdDocuClsfCd
	 */
	public String getsBunsMetdDocuClsfCd() {
		return sBunsMetdDocuClsfCd;
	}

	/**
	 * @param sBunsMetdDocuClsfCd the sBunsMetdDocuClsfCd to set
	 */
	public void setsBunsMetdDocuClsfCd(String sBunsMetdDocuClsfCd) {
		this.sBunsMetdDocuClsfCd = sBunsMetdDocuClsfCd;
	}

	/**
	 * @return the sAnntOpnAgeCd
	 */
	public String getsAnntOpnAgeCd() {
		return sAnntOpnAgeCd;
	}

	/**
	 * @param sAnntOpnAgeCd the sAnntOpnAgeCd to set
	 */
	public void setsAnntOpnAgeCd(String sAnntOpnAgeCd) {
		this.sAnntOpnAgeCd = sAnntOpnAgeCd;
	}

	/**
	 * @return the sAnntPymTermCd
	 */
	public String getsAnntPymTermCd() {
		return sAnntPymTermCd;
	}

	/**
	 * @param sAnntPymTermCd the sAnntPymTermCd to set
	 */
	public void setsAnntPymTermCd(String sAnntPymTermCd) {
		this.sAnntPymTermCd = sAnntPymTermCd;
	}
	
}
