/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * �����Ӵ� �Խ��� - ���� DTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "greenMotherCommentDTO")
public class GreenMotherCommentDTO  {

	/** 	�Ϸù�ȣ	**/ 
	private Integer 	nSeq;
	/** 	���� �Ϸù�ȣ	**/ 
	private String 	nSubSeq;
	/** 	���۳���	**/ 
	private String 	sComment;
	/** 	�ۼ���	**/ 
	private String 	sName;
	/** 	���� ��й�ȣ	**/ 
	private String 	sPassword;
	/** 	������	**/ 
	private String 	sRegId;
	/** 	������¥	**/ 
	private String 	sRegDate	;
	/** 	�����ð�	**/ 
	private String 	sRegTime;
	/** 	������	**/ 
	private String 	sUpId;
	/** 	������¥	**/ 
	private String 	sUpDate;
	/** 	�����ð�	**/ 
	private String 	sUpTime;
	
	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(Integer nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the nSubSeq
	 */
	public String getnSubSeq() {
		return nSubSeq;
	}
	/**
	 * @param nSubSeq the nSubSeq to set
	 */
	public void setnSubSeq(String nSubSeq) {
		this.nSubSeq = nSubSeq;
	}
	/**
	 * @return the sComment
	 */
	public String getsComment() {
		return sComment;
	}
	/**
	 * @param sComment the sComment to set
	 */
	public void setsComment(String sComment) {
		this.sComment = sComment;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	/**
	 * @return the sRegId
	 */
	public String getsRegId() {
		return sRegId;
	}
	/**
	 * @param sRegId the sRegId to set
	 */
	public void setsRegId(String sRegId) {
		this.sRegId = sRegId;
	}
	/**
	 * @return the sRegDate
	 */
	public String getsRegDate() {
		return sRegDate;
	}
	/**
	 * @param sRegDate the sRegDate to set
	 */
	public void setsRegDate(String sRegDate) {
		this.sRegDate = sRegDate;
	}
	/**
	 * @return the sRegTime
	 */
	public String getsRegTime() {
		return sRegTime;
	}
	/**
	 * @param sRegTime the sRegTime to set
	 */
	public void setsRegTime(String sRegTime) {
		this.sRegTime = sRegTime;
	}
	/**
	 * @return the sUpId
	 */
	public String getsUpId() {
		return sUpId;
	}
	/**
	 * @param sUpId the sUpId to set
	 */
	public void setsUpId(String sUpId) {
		this.sUpId = sUpId;
	}
	/**
	 * @return the sUpDate
	 */
	public String getsUpDate() {
		return sUpDate;
	}
	/**
	 * @param sUpDate the sUpDate to set
	 */
	public void setsUpDate(String sUpDate) {
		this.sUpDate = sUpDate;
	}
	/**
	 * @return the sUpTime
	 */
	public String getsUpTime() {
		return sUpTime;
	}
	/**
	 * @param sUpTime the sUpTime to set
	 */
	public void setsUpTime(String sUpTime) {
		this.sUpTime = sUpTime;
	}
}
