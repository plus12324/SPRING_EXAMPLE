/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * ���޵��ǰ�������
 * @author ���ѳ�
 * @since 0.0.10
 */
public class CUSMD03InfoDTO {
	/** ���޵��ǰ������� �Է� ����	**/
	private String kidiInfoVerify;
	/** �ֹ�/����ڹ�ȣ	**/
	private String sCustNo;
	/** �̺�Ʈ����	**/
	private String sEventDiv;
	/** ����ó�ڵ�	**/
	private String sAffiliatedConcern;
	/** ����� ID	**/
	private String sUserID;
	/**
	 * @return the kidiInfoVerify
	 */
	public String getKidiInfoVerify() {
		return kidiInfoVerify;
	}
	/**
	 * @param kidiInfoVerify the kidiInfoVerify to set
	 */
	public void setKidiInfoVerify(String kidiInfoVerify) {
		this.kidiInfoVerify = kidiInfoVerify;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}
	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}
	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	
	
}
