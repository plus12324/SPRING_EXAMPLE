/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ���� �⺻���� �Է� DTO
 * @author ������
 * @since 1.1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dealerContSaveSalesSearchResultDTO")
public class DealerContSaveSalesSearchResultDTO {
	/** dealerInfo **/
	private DealerContSaveSalesOfDealerInfoDTO dealerInfo;
	/** coverVt **/
	private List<DealerContSaveSalesOfCoverVtDTO> coverVt;

	/**
	 * @return the dealerInfo
	 */
	public DealerContSaveSalesOfDealerInfoDTO getDealerInfo() {
		return dealerInfo;
	}

	/**
	 * @param dealerInfo the dealerInfo to set
	 */
	public void setDealerInfo(final DealerContSaveSalesOfDealerInfoDTO dealerInfo) {
		this.dealerInfo = dealerInfo;
	}

	/**
	 * @return the coverVt
	 */
	public List<DealerContSaveSalesOfCoverVtDTO> getCoverVt() {
		return coverVt;
	}

	/**
	 * @param coverVt the coverVt to set
	 */
	public void setCoverVt(final List<DealerContSaveSalesOfCoverVtDTO> coverVt) {
		this.coverVt = coverVt;
	}

}
