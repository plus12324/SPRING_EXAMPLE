/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ؿܻ����� ��ȸ ��� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "selectNationalResultDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class SelectNationalResultDTO {
	/** �ڵ�ID **/
	private String sCodeId;
	/** �ڵ�� **/
	private String sCodeName;
	/** �ڵ念���� **/
	private String sCodeNameEng;

	/**
	 * @return the sCodeId
	 */
	public String getsCodeId() {
		return sCodeId;
	}

	/**
	 * @param sCodeId the sCodeId to set
	 */
	public void setsCodeId(final String sCodeId) {
		this.sCodeId = sCodeId;
	}

	/**
	 * @return the sCodeName
	 */
	public String getsCodeName() {
		return sCodeName;
	}

	/**
	 * @param sCodeName the sCodeName to set
	 */
	public void setsCodeName(final String sCodeName) {
		this.sCodeName = sCodeName;
	}

	/**
	 * @return the sCodeNameEng
	 */
	public String getsCodeNameEng() {
		return sCodeNameEng;
	}

	/**
	 * @param sCodeNameEng the sCodeNameEng to set
	 */
	public void setsCodeNameEng(final String sCodeNameEng) {
		this.sCodeNameEng = sCodeNameEng;
	}

}
