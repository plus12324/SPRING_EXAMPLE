/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �Ϲݰ�� - ī����� ����
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insDrvPayRectList03DTO")
public class InsDrvPayRectList03DTO {
	/** 	ī���ȣ	 **/ 
	private String 	sCardNo;
	/** 	��������	 **/ 
	private String 	sReqDate;
	/** 	���ο�ûȸ��	 **/
	private String 	nReqCnt;
	/**
	 * @return the sCardNo
	 */
	public String getsCardNo() {
		return sCardNo;
	}
	/**
	 * @param sCardNo the sCardNo to set
	 */
	public void setsCardNo(String sCardNo) {
		this.sCardNo = sCardNo;
	}
	/**
	 * @return the sReqDate
	 */
	public String getsReqDate() {
		return sReqDate;
	}
	/**
	 * @param sReqDate the sReqDate to set
	 */
	public void setsReqDate(String sReqDate) {
		this.sReqDate = sReqDate;
	}
	/**
	 * @return the nReqCnt
	 */
	public String getnReqCnt() {
		return nReqCnt;
	}
	/**
	 * @param nReqCnt the nReqCnt to set
	 */
	public void setnReqCnt(String nReqCnt) {
		this.nReqCnt = nReqCnt;
	}
	
	
}
