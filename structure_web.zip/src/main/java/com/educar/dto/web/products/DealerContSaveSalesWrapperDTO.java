/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.products;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.AgreeDTO;

/**
 * <pre>
 * <pre>
 * @author �ڼ���(SeongJin Park)
 *
 */
@XmlRootElement(name = "dealerContSaveSalesWrapperDTO")
public class DealerContSaveSalesWrapperDTO implements Serializable {

	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/** ���� �Է� ���� **/
	private DealerContSaveSalesSearchDTO dealerInfo;
	/** ��� ���� ���� **/
	private AgreeDTO agreeDTO;

	/**
	 * @return the dealerInfo
	 */
	public DealerContSaveSalesSearchDTO getDealerInfo() {
		return dealerInfo;
	}

	/**
	 * @param dealerInfo the dealerInfo to set
	 */
	public void setDealerInfo(final DealerContSaveSalesSearchDTO dealerInfo) {
		this.dealerInfo = dealerInfo;
	}

	/**
	 * @return the agreeDTO
	 */
	public AgreeDTO getAgreeDTO() {
		return agreeDTO;
	}

	/**
	 * @param agreeDTO the agreeDTO to set
	 */
	public void setAgreeDTO(final AgreeDTO agreeDTO) {
		this.agreeDTO = agreeDTO;
	}
}
