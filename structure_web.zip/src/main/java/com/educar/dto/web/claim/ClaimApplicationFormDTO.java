/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

/**
 * <pre>
 * <pre>
 * @author ������ (Hyunsu Kim)
 *
 */
public class ClaimApplicationFormDTO {
	/** sBodyHTML **/
	private String sBodyHTML;
	/** �̸��� ���� **/
	private String sSubject;
	/** �̸��� ������ ���� **/
	private String sTitle;
	/** ������ **/
	private String sName;
	/** ����1 **/
	private String sText1;
	/** ������� **/
	private String sDmCode;
	/** ���Ÿ��� **/
	private String sRecMail;
	/** ���ȸ��� ���� **/
	private String sSecureFlag;
	/** ��¹� key�� **/
	private String key;
	/** ��¹� value�� **/
	private String value;
	/** ����ϱ��� **/
	private String sDiv;

	/**
	 * @return the sBodyHTML
	 */
	public String getsBodyHTML() {
		return sBodyHTML;
	}

	/**
	 * @param sBodyHTML the sBodyHTML to set
	 */
	public void setsBodyHTML(final String sBodyHTML) {
		this.sBodyHTML = sBodyHTML;
	}

	/**
	 * @return the sSubject
	 */
	public String getsSubject() {
		return sSubject;
	}

	/**
	 * @param sSubject the sSubject to set
	 */
	public void setsSubject(final String sSubject) {
		this.sSubject = sSubject;
	}

	/**
	 * @return the sTitle
	 */
	public String getsTitle() {
		return sTitle;
	}

	/**
	 * @param sTitle the sTitle to set
	 */
	public void setsTitle(final String sTitle) {
		this.sTitle = sTitle;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(final String sName) {
		this.sName = sName;
	}

	/**
	 * @return the sText1
	 */
	public String getsText1() {
		return sText1;
	}

	/**
	 * @param sText1 the sText1 to set
	 */
	public void setsText1(final String sText1) {
		this.sText1 = sText1;
	}

	/**
	 * @return the sDmCode
	 */
	public String getsDmCode() {
		return sDmCode;
	}

	/**
	 * @param sDmCode the sDmCode to set
	 */
	public void setsDmCode(final String sDmCode) {
		this.sDmCode = sDmCode;
	}

	/**
	 * @return the sRecMail
	 */
	public String getsRecMail() {
		return sRecMail;
	}

	/**
	 * @param sRecMail the sRecMail to set
	 */
	public void setsRecMail(final String sRecMail) {
		this.sRecMail = sRecMail;
	}

	/**
	 * @return the sSecureFlag
	 */
	public String getsSecureFlag() {
		return sSecureFlag;
	}

	/**
	 * @param sSecureFlag the sSecureFlag to set
	 */
	public void setsSecureFlag(final String sSecureFlag) {
		this.sSecureFlag = sSecureFlag;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(final String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(final String value) {
		this.value = value;
	}

	/**
	 * @return the sDiv
	 */
	public String getsDiv() {
		return sDiv;
	}

	/**
	 * @param sDiv the sDiv to set
	 */
	public void setsDiv(final String sDiv) {
		this.sDiv = sDiv;
	}
}
