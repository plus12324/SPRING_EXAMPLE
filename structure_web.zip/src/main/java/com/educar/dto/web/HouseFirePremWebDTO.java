/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ������ ������ ���� ����� ���� DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "houseFirePremWebDTO")
public class HouseFirePremWebDTO {
	/** 	����ñ�	**/ 
	private String 	sFmdt	;
	/** 	��������	**/ 
	private String 	sTodt;
	/** 	�ǹ����Աݾ�	**/ 
	private String 	nOptAmt1;
	/** 	���絵�����Աݾ�	**/ 
	private String 	nOptAmt2;
	/** 	�ǹ��з��ڵ�	**/ 
	private String 	sOpnCode;
	/** 	�ǹ������޼�	**/ 
	private String 	sClass;
	/** 	�����	**/
	private String 	nPrem;
	/**		������**/
	private String  nFloorNum;
	/**
	 * @return the sFmdt
	 */
	public String getsFmdt() {
		return sFmdt;
	}
	/**
	 * @param sFmdt the sFmdt to set
	 */
	public void setsFmdt(String sFmdt) {
		this.sFmdt = sFmdt;
	}
	/**
	 * @return the sTodt
	 */
	public String getsTodt() {
		return sTodt;
	}
	/**
	 * @param sTodt the sTodt to set
	 */
	public void setsTodt(String sTodt) {
		this.sTodt = sTodt;
	}
	/**
	 * @return the nOptAmt1
	 */
	public String getnOptAmt1() {
		return nOptAmt1;
	}
	/**
	 * @param nOptAmt1 the nOptAmt1 to set
	 */
	public void setnOptAmt1(String nOptAmt1) {
		this.nOptAmt1 = nOptAmt1;
	}
	/**
	 * @return the nOptAmt2
	 */
	public String getnOptAmt2() {
		return nOptAmt2;
	}
	/**
	 * @param nOptAmt2 the nOptAmt2 to set
	 */
	public void setnOptAmt2(String nOptAmt2) {
		this.nOptAmt2 = nOptAmt2;
	}
	/**
	 * @return the sOpnCode
	 */
	public String getsOpnCode() {
		return sOpnCode;
	}
	/**
	 * @param sOpnCode the sOpnCode to set
	 */
	public void setsOpnCode(String sOpnCode) {
		this.sOpnCode = sOpnCode;
	}
	/**
	 * @return the sClass
	 */
	public String getsClass() {
		return sClass;
	}
	/**
	 * @param sClass the sClass to set
	 */
	public void setsClass(String sClass) {
		this.sClass = sClass;
	}
	/**
	 * @return the nPrem
	 */
	public String getnPrem() {
		return nPrem;
	}
	/**
	 * @param nPrem the nPrem to set
	 */
	public void setnPrem(String nPrem) {
		this.nPrem = nPrem;
	}
	/**
	 * @return the nFloorNum
	 */
	public String getnFloorNum() {
		return nFloorNum;
	}
	/**
	 * @param nFloorNum the nFloorNum to set
	 */
	public void setnFloorNum(String nFloorNum) {
		this.nFloorNum = nFloorNum;
	}
	
	
	
}
