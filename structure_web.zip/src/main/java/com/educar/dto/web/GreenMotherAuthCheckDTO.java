/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <pre>
 * �����Ӵ� �Խ���, ���� ������ ��й�ȣ üũ DTO
 * <pre>
 * @author ���ѳ�
 *
 */
@XmlRootElement(name = "greenMotherAuthCheckDTO")
public class GreenMotherAuthCheckDTO{

	/** 	�Խñ� ��ȣ	**/ 
	private Integer 	nSeq;
	/**    ���� ��ȣ **/
	private Integer nSubSeq;
	/**    üũ ���� ( N : �Խñ�, C : ����) **/
	private String sChkDiv;
	/**		��й�ȣ **/
	private String sPassword;
	/**
	 * @return the nSeq
	 */
	public Integer getnSeq() {
		return nSeq;
	}
	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(Integer nSeq) {
		this.nSeq = nSeq;
	}
	/**
	 * @return the nSubSeq
	 */
	public Integer getnSubSeq() {
		return nSubSeq;
	}
	/**
	 * @param nSubSeq the nSubSeq to set
	 */
	public void setnSubSeq(Integer nSubSeq) {
		this.nSubSeq = nSubSeq;
	}
	/**
	 * @return the sChkDiv
	 */
	public String getsChkDiv() {
		return sChkDiv;
	}
	/**
	 * @param sChkDiv the sChkDiv to set
	 */
	public void setsChkDiv(String sChkDiv) {
		this.sChkDiv = sChkDiv;
	}
	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	
}
