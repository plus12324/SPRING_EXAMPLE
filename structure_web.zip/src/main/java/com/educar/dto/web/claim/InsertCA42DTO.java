/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.claim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �ڵ��� ���� ���������� DTO
 * @author ������
 * @since 1.0.0
 */
@XmlRootElement(name = "insertCA42DTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertCA42DTO {
	/** �����ȣ **/
	private String sAccidentNo;
	/** ���ȸ�� **/
	private String sRegiNo;
	/** ���ϸ� **/
	private String sFileName;
	/** ��θ� **/
	private String sFilePath;
	/** �������� **/
	private String sPictGb;

	/**
	 * @return the sPictGb
	 */
	public String getsPictGb() {
		return sPictGb;
	}

	/**
	 * @param sPictGb the sPictGb to set
	 */
	public void setsPictGb(String sPictGb) {
		this.sPictGb = sPictGb;
	}

	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}

	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(final String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}

	/**
	 * @return the sRegiNo
	 */
	public String getsRegiNo() {
		return sRegiNo;
	}

	/**
	 * @param sRegiNo the sRegiNo to set
	 */
	public void setsRegiNo(final String sRegiNo) {
		this.sRegiNo = sRegiNo;
	}

	/**
	 * @return the sFileName
	 */
	public String getsFileName() {
		return sFileName;
	}

	/**
	 * @param sFileName the sFileName to set
	 */
	public void setsFileName(final String sFileName) {
		this.sFileName = sFileName;
	}

	/**
	 * @return the sFilePath
	 */
	public String getsFilePath() {
		return sFilePath;
	}

	/**
	 * @param sFilePath the sFilePath to set
	 */
	public void setsFilePath(final String sFilePath) {
		this.sFilePath = sFilePath;
	}

}
