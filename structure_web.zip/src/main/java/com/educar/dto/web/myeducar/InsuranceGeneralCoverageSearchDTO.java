/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ϲݺ��� �㺸���� ��ȸ DTO
 * @author ������
 * @since 0.0.10
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insuranceGeneralCoverageSearchDTO")
public class InsuranceGeneralCoverageSearchDTO {
	/** ����ȣ TYPE **/
	private String sBizTyp;
	/** �����ڵ� **/
	private String sInsItmCod;
	/** ����ȣ SEQ  **/
	private String sSeq;
	/** �輭��ȣ **/
	private String nEndorseNo;
	/** ����ñ� **/
	private String sInsCtrTpd;

	/**
	 * @return the sBizTyp ����ȣ TYPE
	 */
	public String getsBizTyp() {
		return sBizTyp;
	}

	/**
	 * @param sBizTyp the sBizTyp to set ����ȣ TYPE
	 */
	public void setsBizTyp(final String sBizTyp) {
		this.sBizTyp = sBizTyp;
	}

	/**
	 * @return the sInsItmCod �����ڵ�
	 */
	public String getsInsItmCod() {
		return sInsItmCod;
	}

	/**
	 * @param sInsItmCod the sInsItmCod to set �����ڵ�
	 */
	public void setsInsItmCod(final String sInsItmCod) {
		this.sInsItmCod = sInsItmCod;
	}

	/**
	 * @return the sSeq ����ȣ SEQ
	 */
	public String getsSeq() {
		return sSeq;
	}

	/**
	 * @param sSeq the sSeq to set ����ȣ SEQ
	 */
	public void setsSeq(final String sSeq) {
		this.sSeq = sSeq;
	}

	/**
	 * @return the nEndorseNo �輭��ȣ
	 */
	public String getnEndorseNo() {
		return nEndorseNo;
	}

	/**
	 * @param nEndorseNo the nEndorseNo to set �輭��ȣ
	 */
	public void setnEndorseNo(final String nEndorseNo) {
		this.nEndorseNo = nEndorseNo;
	}

	/**
	 * @return the sInsCtrTpd ����ñ�
	 */
	public String getsInsCtrTpd() {
		return sInsCtrTpd;
	}

	/**
	 * @param sInsCtrTpd the sInsCtrTpd to set ����ñ�
	 */
	public void setsInsCtrTpd(final String sInsCtrTpd) {
		this.sInsCtrTpd = sInsCtrTpd;
	}

}
