/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.annotation.BeanUtil;

/**
 * �������� ��ȸ DTO
 * @author ������
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "carPhotoSearchDTO")
public class CarPhotoSearchDTO {
	/** �������� 1:���� 2: ����� **/
	private String sCustType;
	/** �ֹε�Ϲ�ȣ �Ǵ� ����� ��ȣ **/
	private String sCustNo;
	/** ������ȣ **/
	private String sPlateNo;
	/** ��ȸ�������� YYYYMMDD **/
	private String sStartDate;
	/** ��ȸ �������� YYYYMMDD **/
	private String sEndDate;

	/** ������ ������ ��ȣ **/
	@BeanUtil(name = "page")
	private String pageIndex;

	/**
	 * @return the sCustType
	 */
	public String getsCustType() {
		return sCustType;
	}

	/**
	 * @param sCustType the sCustType to set
	 */
	public void setsCustType(final String sCustType) {
		this.sCustType = sCustType;
	}

	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}

	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(final String sCustNo) {
		this.sCustNo = sCustNo;
	}

	/**
	 * @return the sPlateNo
	 */
	public String getsPlateNo() {
		return sPlateNo;
	}

	/**
	 * @param sPlateNo the sPlateNo to set
	 */
	public void setsPlateNo(final String sPlateNo) {
		this.sPlateNo = sPlateNo;
	}

	/**
	 * @return the sStartDate
	 */
	public String getsStartDate() {
		return sStartDate;
	}

	/**
	 * @param sStartDate the sStartDate to set
	 */
	public void setsStartDate(final String sStartDate) {
		this.sStartDate = sStartDate;
	}

	/**
	 * @return the sEndDate
	 */
	public String getsEndDate() {
		return sEndDate;
	}

	/**
	 * @param sEndDate the sEndDate to set
	 */
	public void setsEndDate(final String sEndDate) {
		this.sEndDate = sEndDate;
	}

	/**
	 * @return the pageIndex
	 */
	public String getPageIndex() {
		return pageIndex;
	}

	/**
	 * @param pageIndex the pageIndex to set
	 */
	public void setPageIndex(final String pageIndex) {
		this.pageIndex = pageIndex;
	}

}
