/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web.myeducar;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ����ᳳ�� - ���⺻ ��ȸ �ڵ��� Wrapper DTO
 * @author ���ѳ�
 * @since 0.0.10
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "insCarContInfoWrapperDTO")
public class InsCarContInfoWrapperDTO {
	/** ��� ���� **/
	private InsCarPoliInfoDTO polcb01Info;
	/** ���� ���� **/
	private List<InsCarPayListDTO> polca07Vt;
	/**
	 * @return the polcb01Info
	 */
	public InsCarPoliInfoDTO getPolcb01Info() {
		return polcb01Info;
	}
	/**
	 * @param polcb01Info the polcb01Info to set
	 */
	public void setPolcb01Info(InsCarPoliInfoDTO polcb01Info) {
		this.polcb01Info = polcb01Info;
	}
	/**
	 * @return the polca07Vt
	 */
	public List<InsCarPayListDTO> getPolca07Vt() {
		return polca07Vt;
	}
	/**
	 * @param polca07Vt the polca07Vt to set
	 */
	public void setPolca07Vt(List<InsCarPayListDTO> polca07Vt) {
		this.polca07Vt = polca07Vt;
	}
	
	
}
