/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * �ڵ��� �㺸 ���� ����� DTO
 * @author ������
 *
 */
public class CalculationOfCarInsuranceApplyDTO {
	/** �㺸 �ڵ� **/
	private String sCover;
	/** ���� ����� **/
	private String nRealPrem;

	/**
	 * @return the sCover
	 */
	public String getsCover() {
		return sCover;
	}

	/**
	 * @param sCover the sCover to set
	 */
	public void setsCover(final String sCover) {
		this.sCover = sCover;
	}

	/**
	 * @return the nRealPrem
	 */
	public String getnRealPrem() {
		return nRealPrem;
	}

	/**
	 * @param nRealPrem the nRealPrem to set
	 */
	public void setnRealPrem(final String nRealPrem) {
		this.nRealPrem = nRealPrem;
	}

}
