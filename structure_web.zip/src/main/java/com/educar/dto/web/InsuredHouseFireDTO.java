/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.web;

/**
 * ȭ�纸�� ���� DTO(LTIDA60)
 * @author ���ѳ�
 *
 */
public class InsuredHouseFireDTO {
	/** 	��ȸ����	 **/ 
	private String 	sel;
	/** 	�ǹ��޼�	 **/ 
	private String 	sBuldgStrtGradCd;
	/** 	�����÷��ڵ�	 **/ 
	private String 	sApplPlanCd;
	/** 	���Ը���	 **/ 
	private String 	nInsArea;
	/** 	��������	 **/ 
	private String 	sRatoBntpCd;
	/** 	���Ծ���	 **/ 
	private String 	sInsBntpCd;
	/** 	���Ǳ���	 **/ 
	private String 	sRatoBntpObjtFlagCd;
	/** 	Ư���ǹ�����	 **/ 
	private String 	sSpclBuldgFlagCd;
	/** 	����	 **/ 
	private String 	nInsrdObjctSeqno;

	/**
	 * @return the sel
	 */
	public String getSel() {
		return sel;
	}
	/**
	 * @param sel the sel to set
	 */
	public void setSel(String sel) {
		this.sel = sel;
	}
	/**
	 * @return the sBuldgStrtGradCd
	 */
	public String getsBuldgStrtGradCd() {
		return sBuldgStrtGradCd;
	}
	/**
	 * @param sBuldgStrtGradCd the sBuldgStrtGradCd to set
	 */
	public void setsBuldgStrtGradCd(String sBuldgStrtGradCd) {
		this.sBuldgStrtGradCd = sBuldgStrtGradCd;
	}
	/**
	 * @return the sApplPlanCd
	 */
	public String getsApplPlanCd() {
		return sApplPlanCd;
	}
	/**
	 * @param sApplPlanCd the sApplPlanCd to set
	 */
	public void setsApplPlanCd(String sApplPlanCd) {
		this.sApplPlanCd = sApplPlanCd;
	}
	/**
	 * @return the nInsArea
	 */
	public String getnInsArea() {
		return nInsArea;
	}
	/**
	 * @param nInsArea the nInsArea to set
	 */
	public void setnInsArea(String nInsArea) {
		this.nInsArea = nInsArea;
	}
	/**
	 * @return the sRatoBntpCd
	 */
	public String getsRatoBntpCd() {
		return sRatoBntpCd;
	}
	/**
	 * @param sRatoBntpCd the sRatoBntpCd to set
	 */
	public void setsRatoBntpCd(String sRatoBntpCd) {
		this.sRatoBntpCd = sRatoBntpCd;
	}
	/**
	 * @return the sInsBntpCd
	 */
	public String getsInsBntpCd() {
		return sInsBntpCd;
	}
	/**
	 * @param sInsBntpCd the sInsBntpCd to set
	 */
	public void setsInsBntpCd(String sInsBntpCd) {
		this.sInsBntpCd = sInsBntpCd;
	}
	/**
	 * @return the sRatoBntpObjtFlagCd
	 */
	public String getsRatoBntpObjtFlagCd() {
		return sRatoBntpObjtFlagCd;
	}
	/**
	 * @param sRatoBntpObjtFlagCd the sRatoBntpObjtFlagCd to set
	 */
	public void setsRatoBntpObjtFlagCd(String sRatoBntpObjtFlagCd) {
		this.sRatoBntpObjtFlagCd = sRatoBntpObjtFlagCd;
	}
	/**
	 * @return the sSpclBuldgFlagCd
	 */
	public String getsSpclBuldgFlagCd() {
		return sSpclBuldgFlagCd;
	}
	/**
	 * @param sSpclBuldgFlagCd the sSpclBuldgFlagCd to set
	 */
	public void setsSpclBuldgFlagCd(String sSpclBuldgFlagCd) {
		this.sSpclBuldgFlagCd = sSpclBuldgFlagCd;
	}
	/**
	 * @return the nInsrdObjctSeqno
	 */
	public String getnInsrdObjctSeqno() {
		return nInsrdObjctSeqno;
	}
	/**
	 * @param nInsrdObjctSeqno the nInsrdObjctSeqno to set
	 */
	public void setnInsrdObjctSeqno(String nInsrdObjctSeqno) {
		this.nInsrdObjctSeqno = nInsrdObjctSeqno;
	}
	
	
}
