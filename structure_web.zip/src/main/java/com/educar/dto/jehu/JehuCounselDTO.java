/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.jehu;

/**
 * ���������û
 * @author ���ѳ�
 * @since 1.0.0
 */
public class JehuCounselDTO {
	/** 	�̸�		**/ 
	private String 	sName;
	/** 	�ֹι�ȣ		**/ 
	private String 	sCustNo;
	/** 	�ڵ���1		**/ 
	private String 	sCellPhone1;
	/** 	�ڵ���2		**/ 
	private String 	sCellPhone2;
	/** 	�ڵ���3		**/ 
	private String 	sCellPhone3;
	/** 	���Լ��赿�ǿ���	Y:����, N:�ź�	**/ 
	private String 	sAgmYn1	;
	/** 	��ǰ�Ұ����ǿ���	Y:����, N:�ź�	**/ 
	private String 	sAgmYn2	;
	/** 	�Է���	�����	**/ 
	private String 	sUserID;
	/** 	�������˰��	 **/ 
	private String 	sContactPath;
	/** 	�̺�Ʈ�ڵ� **/ 
	private String 	sEventDiv;
	/** 	���޻��ڵ� **/ 
	private String 	sAffiliatedConcern;
	/** 	���޻� Ű **/ 
	private String 	sAffiliatedConcernKey;
	/** ���ǹ��	**/
	private String sAgmMethod;
	/** ���ǰ�������	**/
	private String sAgmCheckType;
	/** 	�����ڵ� **/ 
	private String 	sAgmCheckInfo;
	/** ������� ��**/
	private String sAgmRecvName;
	/** �ڳ��ֹι�ȣ **/
	private String sChildrenCustNo;
	/** �ڳ༺��	**/
	private String sChildrenName;
	/** ��õURL **/
	private String sRecommendUrl;
	/** ��õ�� **/
	private String sRecommendName;
	
	/** ��������Ͻ�	**/
	private String sTravelFmDttm;
	/** ���������Ͻ�	**/
	private String sTravelToDttm;
	/** �������	**/
	private String sBirthDay;
	/** ��������	**/
	private String sSex;
	/** ���ܱ��α���	**/
	private String sForeigner;
	/** ��ǰ���� **/
	private String sProductType;
	
	/** ������ȣ **/
	private String sCouponNo;
	
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sAgmYn1
	 */
	public String getsAgmYn1() {
		return sAgmYn1;
	}
	/**
	 * @param sAgmYn1 the sAgmYn1 to set
	 */
	public void setsAgmYn1(String sAgmYn1) {
		this.sAgmYn1 = sAgmYn1;
	}
	/**
	 * @return the sAgmYn2
	 */
	public String getsAgmYn2() {
		return sAgmYn2;
	}
	/**
	 * @param sAgmYn2 the sAgmYn2 to set
	 */
	public void setsAgmYn2(String sAgmYn2) {
		this.sAgmYn2 = sAgmYn2;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sContactPath
	 */
	public String getsContactPath() {
		return sContactPath;
	}
	/**
	 * @param sContactPath the sContactPath to set
	 */
	public void setsContactPath(String sContactPath) {
		this.sContactPath = sContactPath;
	}
	/**
	 * @return the sEventDiv
	 */
	public String getsEventDiv() {
		return sEventDiv;
	}
	/**
	 * @param sEventDiv the sEventDiv to set
	 */
	public void setsEventDiv(String sEventDiv) {
		this.sEventDiv = sEventDiv;
	}
	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}
	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}
	
	/**
	 * @return the sAffiliatedConcernKey
	 */
	public String getsAffiliatedConcernKey() {
		return sAffiliatedConcernKey;
	}
	/**
	 * @param sAffiliatedConcernKey the sAffiliatedConcernKey to set
	 */
	public void setsAffiliatedConcernKey(String sAffiliatedConcernKey) {
		this.sAffiliatedConcernKey = sAffiliatedConcernKey;
	}
	/**
	 * @return the sAgmMethod
	 */
	public String getsAgmMethod() {
		return sAgmMethod;
	}
	/**
	 * @param sAgmMethod the sAgmMethod to set
	 */
	public void setsAgmMethod(String sAgmMethod) {
		this.sAgmMethod = sAgmMethod;
	}
	/**
	 * @return the sAgmCheckType
	 */
	public String getsAgmCheckType() {
		return sAgmCheckType;
	}
	/**
	 * @param sAgmCheckType the sAgmCheckType to set
	 */
	public void setsAgmCheckType(String sAgmCheckType) {
		this.sAgmCheckType = sAgmCheckType;
	}
	/**
	 * @return the sAgmCheckInfo
	 */
	public String getsAgmCheckInfo() {
		return sAgmCheckInfo;
	}
	/**
	 * @param sAgmCheckInfo the sAgmCheckInfo to set
	 */
	public void setsAgmCheckInfo(String sAgmCheckInfo) {
		this.sAgmCheckInfo = sAgmCheckInfo;
	}
	/**
	 * @return the sAgmRecvName
	 */
	public String getsAgmRecvName() {
		return sAgmRecvName;
	}
	/**
	 * @param sAgmRecvName the sAgmRecvName to set
	 */
	public void setsAgmRecvName(String sAgmRecvName) {
		this.sAgmRecvName = sAgmRecvName;
	}
	/**
	 * @return the sChildrenCustNo
	 */
	public String getsChildrenCustNo() {
		return sChildrenCustNo;
	}
	/**
	 * @param sChildrenCustNo the sChildrenCustNo to set
	 */
	public void setsChildrenCustNo(String sChildrenCustNo) {
		this.sChildrenCustNo = sChildrenCustNo;
	}
	/**
	 * @return the sChildrenName
	 */
	public String getsChildrenName() {
		return sChildrenName;
	}
	/**
	 * @param sChildrenName the sChildrenName to set
	 */
	public void setsChildrenName(String sChildrenName) {
		this.sChildrenName = sChildrenName;
	}
	/**
	 * @return the sRecommendUrl
	 */
	public String getsRecommendUrl() {
		return sRecommendUrl;
	}
	/**
	 * @param sRecommendUrl the sRecommendUrl to set
	 */
	public void setsRecommendUrl(String sRecommendUrl) {
		this.sRecommendUrl = sRecommendUrl;
	}
	/**
	 * @return the sRecommendName
	 */
	public String getsRecommendName() {
		return sRecommendName;
	}
	/**
	 * @param sRecommendName the sRecommendName to set
	 */
	public void setsRecommendName(String sRecommendName) {
		this.sRecommendName = sRecommendName;
	}
	/**
	 * @return the sTravelFmDttm
	 */
	public String getsTravelFmDttm() {
		return sTravelFmDttm;
	}
	/**
	 * @param sTravelFmDttm the sTravelFmDttm to set
	 */
	public void setsTravelFmDttm(String sTravelFmDttm) {
		this.sTravelFmDttm = sTravelFmDttm;
	}
	/**
	 * @return the sTravelToDttm
	 */
	public String getsTravelToDttm() {
		return sTravelToDttm;
	}
	/**
	 * @param sTravelToDttm the sTravelToDttm to set
	 */
	public void setsTravelToDttm(String sTravelToDttm) {
		this.sTravelToDttm = sTravelToDttm;
	}
	/**
	 * @return the sBirthDay
	 */
	public String getsBirthDay() {
		return sBirthDay;
	}
	/**
	 * @param sBirthDay the sBirthDay to set
	 */
	public void setsBirthDay(String sBirthDay) {
		this.sBirthDay = sBirthDay;
	}
	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}
	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(String sSex) {
		this.sSex = sSex;
	}
	/**
	 * @return the sForeigner
	 */
	public String getsForeigner() {
		return sForeigner;
	}
	/**
	 * @param sForeigner the sForeigner to set
	 */
	public void setsForeigner(String sForeigner) {
		this.sForeigner = sForeigner;
	}
	/**
	 * @return the sProductType
	 */
	public String getsProductType() {
		return sProductType;
	}
	/**
	 * @param sProductType the sProductType to set
	 */
	public void setsProductType(String sProductType) {
		this.sProductType = sProductType;
	}
	/**
	 * @return the sCouponNo
	 */
	public String getsCouponNo() {
		return sCouponNo;
	}
	/**
	 * @param sCouponNo the sCouponNo to set
	 */
	public void setsCouponNo(String sCouponNo) {
		this.sCouponNo = sCouponNo;
	}
	
}
