/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.jehu;

/**
 * ���ް���(WEBAD01)
 * @author ������
 * @since 1.0.0
 */
public class JehuDTO {
	/** �Ϸù�ȣ **/ 
	private long nSeq;
	/** ����ó�ڵ� **/
	private String sAffiliatedConcern;
	/** ����ó�̸� **/
	private String sAffiliatedConcernName;
	/** ����ó Ű ��(educar, moneta....) **/
	private String sAffiliatedConcernKey;
	/** ����� **/
	private String sStaffName;
	/** �Խ��� ������¥ (YYYYMMDD) **/
	private String sOpenDate;
	/** ������ (1: �Ϲ�, 2: ����, 3: ����, 4: ����) **/
	private String sJobKind;
	/** ���λ����� **/
	private String sWidth;
	/** �ڵ�������-ǥ�ø� **/
	private String sCarText;
	/** �ڵ�������-������갡�� (1: ����, 0 :����) **/
	private String sCarCalc;
	/** �ڵ�������-����û (1: ����, 0 :����) **/
	private String sCarCounsel;
	/** �Ϲݺ���-ǥ�ø� **/
	private String sGeneralText;
	/** �Ϲݺ���-������갡�� (1: ����, 0 :����) **/
	private String sGeneralCalc;
	/** �Ϲݺ���-����û (1: ����, 0 :����) **/
	private String sGeneralCounsel;
	/** ��⺸��-����û (1: ����, 0 :����) **/
	private String sLongCounsel;
	/** ��⺸�� ��ǰ�ڵ� **/
	private String sLongProductCode;
	/** ��⺸�� ��ǰ�� **/
	private String sLongProductCodeName;
	/** ȸ��ΰ�-�̹��� �̸� **/
	private String sLogoImageName;
	/** ȸ��ΰ�-�̹���URL **/
	private String sLogoImageURL;
	/** ����ʼ���-�̹����̸� **/
	private String sMembershipImageName;
	/** ����ʼ���-�̹���URL **/
	private String sMembershipImageURL;
	/** ����ʼ���-Forward URL **/
	private String sMembershipForwardURL;
	/** ���������-�̹����̸� **/
	private String sSavingImageName;
	/** ���������-�̹���URL **/
	private String sSavingImageURL;
	/** ���������-Forward URL **/
	private String sSavingForwardURL;
	/** ��õ��ǰ-�̹����̸� **/
	private String sBestImageName;
	/** ��õ��ǰ-�̹���URL **/
	private String sBestImageURL;
	/** ��õ��ǰ-Forward URL **/
	private String sBestForwardURL;
	/** ����ϼ���-�̹����̸� **/
	private String sMobileImageName;
	/** ����ϼ���-�̹���URL **/
	private String sMobileImageURL;
	/** ����ϼ���-Forward URL **/
	private String sMobileForwardURL;
	/** �������� **/
	private String sCreDate;
	/** �����Ͻ� **/
	private String sCreTime;
	/** ������ **/
	private String sModiDate;
	/** �����ð� **/
	private String sModiTime;
	/** JSP���� ��Ÿ�ϸ��� ���� �ʿ��� ����, width�� 590px ~ 730px ���� **/
	private String isRange;
	/** �������ȣ **/  
	private String sCounselNo;
	/** ����ʼ���2-�̹����̸� **/
	private String sMembership2ImageName;
	/** ����ʼ���2-�̹���URL **/
	private String sMembership2ImageURL;
	/** ����ʼ���2-Forward URL **/
	private String sMembership2ForwardURL;
	/** ����-�̹����̸� **/
	private String sMainImageName;
	/** ����-�̹���URL **/
	private String sMainImageURL;
	/** ����-Forward URL **/
	private String sMainForwardURL;
	
	/**
	 * @return the nSeq
	 */
	public long getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(final long nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sAffiliatedConcern
	 */
	public String getsAffiliatedConcern() {
		return sAffiliatedConcern;
	}

	/**
	 * @param sAffiliatedConcern the sAffiliatedConcern to set
	 */
	public void setsAffiliatedConcern(final String sAffiliatedConcern) {
		this.sAffiliatedConcern = sAffiliatedConcern;
	}

	/**
	 * @return the sAffiliatedConcernName
	 */
	public String getsAffiliatedConcernName() {
		return sAffiliatedConcernName;
	}

	/**
	 * @param sAffiliatedConcernName the sAffiliatedConcernName to set
	 */
	public void setsAffiliatedConcernName(final String sAffiliatedConcernName) {
		this.sAffiliatedConcernName = sAffiliatedConcernName;
	}

	/**
	 * @return the sAffiliatedConcernKey
	 */
	public String getsAffiliatedConcernKey() {
		return sAffiliatedConcernKey;
	}

	/**
	 * @param sAffiliatedConcernKey the sAffiliatedConcernKey to set
	 */
	public void setsAffiliatedConcernKey(final String sAffiliatedConcernKey) {
		this.sAffiliatedConcernKey = sAffiliatedConcernKey;
	}

	/**
	 * @return the sStaffName
	 */
	public String getsStaffName() {
		return sStaffName;
	}

	/**
	 * @param sStaffName the sStaffName to set
	 */
	public void setsStaffName(final String sStaffName) {
		this.sStaffName = sStaffName;
	}

	/**
	 * @return the sOpenDate
	 */
	public String getsOpenDate() {
		return sOpenDate;
	}

	/**
	 * @param sOpenDate the sOpenDate to set
	 */
	public void setsOpenDate(final String sOpenDate) {
		this.sOpenDate = sOpenDate;
	}

	/**
	 * @return the sJobKind
	 */
	public String getsJobKind() {
		return sJobKind;
	}

	/**
	 * @param sJobKind the sJobKind to set
	 */
	public void setsJobKind(final String sJobKind) {
		this.sJobKind = sJobKind;
	}

	/**
	 * @return the sWidth
	 */
	public String getsWidth() {
		return sWidth;
	}

	/**
	 * @param sWidth the sWidth to set
	 */
	public void setsWidth(final String sWidth) {
		this.sWidth = sWidth;
	}

	/**
	 * @return the sCarText
	 */
	public String getsCarText() {
		return sCarText;
	}

	/**
	 * @param sCarText the sCarText to set
	 */
	public void setsCarText(final String sCarText) {
		this.sCarText = sCarText;
	}

	/**
	 * @return the sCarCalc
	 */
	public String getsCarCalc() {
		return sCarCalc;
	}

	/**
	 * @param sCarCalc the sCarCalc to set
	 */
	public void setsCarCalc(final String sCarCalc) {
		this.sCarCalc = sCarCalc;
	}

	/**
	 * @return the sCarCounsel
	 */
	public String getsCarCounsel() {
		return sCarCounsel;
	}

	/**
	 * @param sCarCounsel the sCarCounsel to set
	 */
	public void setsCarCounsel(final String sCarCounsel) {
		this.sCarCounsel = sCarCounsel;
	}

	/**
	 * @return the sGeneralText
	 */
	public String getsGeneralText() {
		return sGeneralText;
	}

	/**
	 * @param sGeneralText the sGeneralText to set
	 */
	public void setsGeneralText(final String sGeneralText) {
		this.sGeneralText = sGeneralText;
	}

	/**
	 * @return the sGeneralCalc
	 */
	public String getsGeneralCalc() {
		return sGeneralCalc;
	}

	/**
	 * @param sGeneralCalc the sGeneralCalc to set
	 */
	public void setsGeneralCalc(final String sGeneralCalc) {
		this.sGeneralCalc = sGeneralCalc;
	}

	/**
	 * @return the sGeneralCounsel
	 */
	public String getsGeneralCounsel() {
		return sGeneralCounsel;
	}

	/**
	 * @param sGeneralCounsel the sGeneralCounsel to set
	 */
	public void setsGeneralCounsel(final String sGeneralCounsel) {
		this.sGeneralCounsel = sGeneralCounsel;
	}

	/**
	 * @return the sLongCounsel
	 */
	public String getsLongCounsel() {
		return sLongCounsel;
	}

	/**
	 * @param sLongCounsel the sLongCounsel to set
	 */
	public void setsLongCounsel(final String sLongCounsel) {
		this.sLongCounsel = sLongCounsel;
	}

	/**
	 * @return the sLongProductCode
	 */
	public String getsLongProductCode() {
		return sLongProductCode;
	}

	/**
	 * @param sLongProductCode the sLongProductCode to set
	 */
	public void setsLongProductCode(final String sLongProductCode) {
		this.sLongProductCode = sLongProductCode;
	}

	/**
	 * @return the sLogoImageName
	 */
	public String getsLogoImageName() {
		return sLogoImageName;
	}

	/**
	 * @param sLogoImageName the sLogoImageName to set
	 */
	public void setsLogoImageName(final String sLogoImageName) {
		this.sLogoImageName = sLogoImageName;
	}

	/**
	 * @return the sLongProductCodeName
	 */
	public String getsLongProductCodeName() {
		return sLongProductCodeName;
	}

	/**
	 * @param sLongProductCodeName the sLongProductCodeName to set
	 */
	public void setsLongProductCodeName(final String sLongProductCodeName) {
		this.sLongProductCodeName = sLongProductCodeName;
	}

	/**
	 * @return the sLogoImageURL
	 */
	public String getsLogoImageURL() {
		return sLogoImageURL;
	}

	/**
	 * @param sLogoImageURL the sLogoImageURL to set
	 */
	public void setsLogoImageURL(final String sLogoImageURL) {
		this.sLogoImageURL = sLogoImageURL;
	}

	/**
	 * @return the sMembershipImageName
	 */
	public String getsMembershipImageName() {
		return sMembershipImageName;
	}

	/**
	 * @param sMembershipImageName the sMembershipImageName to set
	 */
	public void setsMembershipImageName(final String sMembershipImageName) {
		this.sMembershipImageName = sMembershipImageName;
	}

	/**
	 * @return the sMembershipImageURL
	 */
	public String getsMembershipImageURL() {
		return sMembershipImageURL;
	}

	/**
	 * @param sMembershipImageURL the sMembershipImageURL to set
	 */
	public void setsMembershipImageURL(final String sMembershipImageURL) {
		this.sMembershipImageURL = sMembershipImageURL;
	}

	/**
	 * @return the sMembershipForwardURL
	 */
	public String getsMembershipForwardURL() {
		return sMembershipForwardURL;
	}

	/**
	 * @param sMembershipForwardURL the sMembershipForwardURL to set
	 */
	public void setsMembershipForwardURL(final String sMembershipForwardURL) {
		this.sMembershipForwardURL = sMembershipForwardURL;
	}

	/**
	 * @return the sSavingImageName
	 */
	public String getsSavingImageName() {
		return sSavingImageName;
	}

	/**
	 * @param sSavingImageName the sSavingImageName to set
	 */
	public void setsSavingImageName(final String sSavingImageName) {
		this.sSavingImageName = sSavingImageName;
	}

	/**
	 * @return the sSavingImageURL
	 */
	public String getsSavingImageURL() {
		return sSavingImageURL;
	}

	/**
	 * @param sSavingImageURL the sSavingImageURL to set
	 */
	public void setsSavingImageURL(final String sSavingImageURL) {
		this.sSavingImageURL = sSavingImageURL;
	}

	/**
	 * @return the sSavingForwardURL
	 */
	public String getsSavingForwardURL() {
		return sSavingForwardURL;
	}

	/**
	 * @param sSavingForwardURL the sSavingForwardURL to set
	 */
	public void setsSavingForwardURL(final String sSavingForwardURL) {
		this.sSavingForwardURL = sSavingForwardURL;
	}

	/**
	 * @return the sBestImageName
	 */
	public String getsBestImageName() {
		return sBestImageName;
	}

	/**
	 * @param sBestImageName the sBestImageName to set
	 */
	public void setsBestImageName(final String sBestImageName) {
		this.sBestImageName = sBestImageName;
	}

	/**
	 * @return the sBestImageURL
	 */
	public String getsBestImageURL() {
		return sBestImageURL;
	}

	/**
	 * @param sBestImageURL the sBestImageURL to set
	 */
	public void setsBestImageURL(final String sBestImageURL) {
		this.sBestImageURL = sBestImageURL;
	}

	/**
	 * @return the sBestForwardURL
	 */
	public String getsBestForwardURL() {
		return sBestForwardURL;
	}

	/**
	 * @param sBestForwardURL the sBestForwardURL to set
	 */
	public void setsBestForwardURL(final String sBestForwardURL) {
		this.sBestForwardURL = sBestForwardURL;
	}

	/**
	 * @return the sMobileImageName
	 */
	public String getsMobileImageName() {
		return sMobileImageName;
	}

	/**
	 * @param sMobileImageName the sMobileImageName to set
	 */
	public void setsMobileImageName(final String sMobileImageName) {
		this.sMobileImageName = sMobileImageName;
	}

	/**
	 * @return the sMobileImageURL
	 */
	public String getsMobileImageURL() {
		return sMobileImageURL;
	}

	/**
	 * @param sMobileImageURL the sMobileImageURL to set
	 */
	public void setsMobileImageURL(final String sMobileImageURL) {
		this.sMobileImageURL = sMobileImageURL;
	}

	/**
	 * @return the sMobileForwardURL
	 */
	public String getsMobileForwardURL() {
		return sMobileForwardURL;
	}

	/**
	 * @param sMobileForwardURL the sMobileForwardURL to set
	 */
	public void setsMobileForwardURL(final String sMobileForwardURL) {
		this.sMobileForwardURL = sMobileForwardURL;
	}

	/**
	 * @return the sCreDate
	 */
	public String getsCreDate() {
		return sCreDate;
	}

	/**
	 * @param sCreDate the sCreDate to set
	 */
	public void setsCreDate(final String sCreDate) {
		this.sCreDate = sCreDate;
	}

	/**
	 * @return the sCreTime
	 */
	public String getsCreTime() {
		return sCreTime;
	}

	/**
	 * @param sCreTime the sCreTime to set
	 */
	public void setsCreTime(final String sCreTime) {
		this.sCreTime = sCreTime;
	}

	/**
	 * @return the sModiDate
	 */
	public String getsModiDate() {
		return sModiDate;
	}

	/**
	 * @param sModiDate the sModiDate to set
	 */
	public void setsModiDate(final String sModiDate) {
		this.sModiDate = sModiDate;
	}

	/**
	 * @return the sModiTime
	 */
	public String getsModiTime() {
		return sModiTime;
	}

	/**
	 * @param sModiTime the sModiTime to set
	 */
	public void setsModiTime(final String sModiTime) {
		this.sModiTime = sModiTime;
	}

	/**
	 * @return the isRange
	 */
	public String getIsRange() {
		final int width = Integer.parseInt(this.sWidth);
		if (width > 590 && width < 730) {
			this.isRange = "true";
		} else {
			this.isRange = "false";
		}
		return isRange;
	}


	/**
	 * @return the sCounselNo
	 */
	public String getsCounselNo() {
		return sCounselNo;
	}

	/**
	 * @param sCounselNo the sCounselNo to set
	 */
	public void setsCounselNo(String sCounselNo) {
		this.sCounselNo = sCounselNo;
	}

	/**
	 * @return the sMembership2ImageName
	 */
	public String getsMembership2ImageName() {
		return sMembership2ImageName;
	}

	/**
	 * @param sMembership2ImageName the sMembership2ImageName to set
	 */
	public void setsMembership2ImageName(String sMembership2ImageName) {
		this.sMembership2ImageName = sMembership2ImageName;
	}

	/**
	 * @return the sMembership2ImageURL
	 */
	public String getsMembership2ImageURL() {
		return sMembership2ImageURL;
	}

	/**
	 * @param sMembership2ImageURL the sMembership2ImageURL to set
	 */
	public void setsMembership2ImageURL(String sMembership2ImageURL) {
		this.sMembership2ImageURL = sMembership2ImageURL;
	}

	/**
	 * @return the sMembership2ForwardURL
	 */
	public String getsMembership2ForwardURL() {
		return sMembership2ForwardURL;
	}

	/**
	 * @param sMembership2ForwardURL the sMembership2ForwardURL to set
	 */
	public void setsMembership2ForwardURL(String sMembership2ForwardURL) {
		this.sMembership2ForwardURL = sMembership2ForwardURL;
	}

	/**
	 * @return the sMainImageName
	 */
	public String getsMainImageName() {
		return sMainImageName;
	}

	/**
	 * @param sMainImageName the sMainImageName to set
	 */
	public void setsMainImageName(String sMainImageName) {
		this.sMainImageName = sMainImageName;
	}

	/**
	 * @return the sMainImageURL
	 */
	public String getsMainImageURL() {
		return sMainImageURL;
	}

	/**
	 * @param sMainImageURL the sMainImageURL to set
	 */
	public void setsMainImageURL(String sMainImageURL) {
		this.sMainImageURL = sMainImageURL;
	}

	/**
	 * @return the sMainForwardURL
	 */
	public String getsMainForwardURL() {
		return sMainForwardURL;
	}

	/**
	 * @param sMainForwardURL the sMainForwardURL to set
	 */
	public void setsMainForwardURL(String sMainForwardURL) {
		this.sMainForwardURL = sMainForwardURL;
	}
}
