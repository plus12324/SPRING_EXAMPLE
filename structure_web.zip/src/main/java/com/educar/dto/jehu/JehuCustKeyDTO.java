/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.jehu;

/**
 * ������ȣä��
 * @author ���ѳ�
 * @since 1.0.0
 */
public class JehuCustKeyDTO {
	/** 	�̸�		**/ 
	private String 	sName;
	/** 	�ֹι�ȣ		**/ 
	private String 	sCustNo;
	/** 	�ڵ���1		**/ 
	private String 	sCellPhone1;
	/** 	�ڵ���2		**/ 
	private String 	sCellPhone2;
	/** 	�ڵ���3		**/ 
	private String 	sCellPhone3;
	/** 	�Է���		**/ 
	private String 	sUserID;
	/** �������	**/
	private String sBirthDay;
	/** ��������	**/
	private String sSex;
	/** ���ܱ��α���	**/
	private String sForeigner;
	/** ��ǰ���� **/
	private String sProductType;
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCustNo
	 */
	public String getsCustNo() {
		return sCustNo;
	}
	/**
	 * @param sCustNo the sCustNo to set
	 */
	public void setsCustNo(String sCustNo) {
		this.sCustNo = sCustNo;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sBirthDay
	 */
	public String getsBirthDay() {
		return sBirthDay;
	}
	/**
	 * @param sBirthDay the sBirthDay to set
	 */
	public void setsBirthDay(String sBirthDay) {
		this.sBirthDay = sBirthDay;
	}
	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}
	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(String sSex) {
		this.sSex = sSex;
	}
	/**
	 * @return the sForeigner
	 */
	public String getsForeigner() {
		return sForeigner;
	}
	/**
	 * @param sForeigner the sForeigner to set
	 */
	public void setsForeigner(String sForeigner) {
		this.sForeigner = sForeigner;
	}
	/**
	 * @return the sProductType
	 */
	public String getsProductType() {
		return sProductType;
	}
	/**
	 * @param sProductType the sProductType to set
	 */
	public void setsProductType(String sProductType) {
		this.sProductType = sProductType;
	}
	
	
}
