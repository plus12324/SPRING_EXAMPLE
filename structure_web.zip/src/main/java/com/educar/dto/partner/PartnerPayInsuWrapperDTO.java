/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

import java.util.List;

/**
 * ���޺���ݳ���
 * @author ���ѳ�
 *
 */
public class PartnerPayInsuWrapperDTO {
	
	/** 	����ڹ�ȣ	 **/ 
	private String 	sBizRegiNo;
	/** 	��ȸ���۱Ⱓ	 **/ 
	private String 	searchFrm;
	/** 	��ȸ����Ⱓ	 **/ 
	private String 	searchTo;
	/**     ����ڸ� **/
	private String sCompanyName;
	
	private PartnerCLMCE01DTO clmce01;
	
	private List<PartnerCLMC001ListDTO> clmc001;

	/**
	 * @return the sBizRegiNo
	 */
	public String getsBizRegiNo() {
		return sBizRegiNo;
	}

	/**
	 * @param sBizRegiNo the sBizRegiNo to set
	 */
	public void setsBizRegiNo(String sBizRegiNo) {
		this.sBizRegiNo = sBizRegiNo;
	}

	/**
	 * @return the searchFrm
	 */
	public String getSearchFrm() {
		return searchFrm;
	}

	/**
	 * @param searchFrm the searchFrm to set
	 */
	public void setSearchFrm(String searchFrm) {
		this.searchFrm = searchFrm;
	}

	/**
	 * @return the searchTo
	 */
	public String getSearchTo() {
		return searchTo;
	}

	/**
	 * @param searchTo the searchTo to set
	 */
	public void setSearchTo(String searchTo) {
		this.searchTo = searchTo;
	}
	
	
	
	/**
	 * @return the sCompanyName
	 */
	public String getsCompanyName() {
		return sCompanyName;
	}

	/**
	 * @param sCompanyName the sCompanyName to set
	 */
	public void setsCompanyName(String sCompanyName) {
		this.sCompanyName = sCompanyName;
	}

	/**
	 * @return the clmce01
	 */
	public PartnerCLMCE01DTO getClmce01() {
		return clmce01;
	}

	/**
	 * @param clmce01 the clmce01 to set
	 */
	public void setClmce01(PartnerCLMCE01DTO clmce01) {
		this.clmce01 = clmce01;
	}

	/**
	 * @return the clmc001
	 */
	public List<PartnerCLMC001ListDTO> getClmc001() {
		return clmc001;
	}

	/**
	 * @param clmc001 the clmc001 to set
	 */
	public void setClmc001(List<PartnerCLMC001ListDTO> clmc001) {
		this.clmc001 = clmc001;
	}
	
	
	
}
