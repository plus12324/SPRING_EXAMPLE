/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;


/**
 * ���¾�ü - ȸ������
 * @author ���ѳ�
 *
 */
public class PartnerInsuJoinDTO {
	/** 	����ڵ�Ϲ�ȣ	 **/ 
	private String	sBizRegiNo;
	/** 	����ڱ���	 **/ 
	private String	sJobDiv;
	/** 	��й�ȣ	 **/ 
	private String	sPassword;
	/** 	��й�ȣ�����÷���	 **/ 
	private String	sPassFlag;
	/** 	����ڱ���	 **/ 
	private String	sCompanyType;
	/** 	���¾�ü�ڵ�	 **/ 
	private String	sCorrespondent;
	/** 	����	 **/ 
	private String	sName;
	/** 	�������	 **/ 
	private String	sBirthYear;
	/** 	����	 **/ 
	private String	sJobTitle;
	/** 	�޴���1	 **/ 
	private String	sCellPhone1;
	/** 	�޴���2	 **/ 
	private String	sCellPhone2;
	/** 	�޴���3	 **/ 
	private String	sCellPhone3;
	/** 	�̸���	 **/ 
	private String	sEmail;
	/** 	��������	 **/ 
	private String	sClass;
	/** 	������	 **/ 
	private String	sJoinDate;
	/** 	���Խð�	 **/ 
	private String	sJoinTime;
	/** 	������	 **/ 
	private String sInputDate;
	/** 	�����ð�	 **/ 
	private String sInputTime;
	/** 	Ż����	 **/ 
	private String sSecedeDate;
	/** 	Ż��ð�	 **/ 
	private String sSecedeTime;
	/**
	 * @return the sBizRegiNo
	 */
	public String getsBizRegiNo() {
		return sBizRegiNo;
	}
	/**
	 * @param sBizRegiNo the sBizRegiNo to set
	 */
	public void setsBizRegiNo(String sBizRegiNo) {
		this.sBizRegiNo = sBizRegiNo;
	}
	/**
	 * @return the sJobDiv
	 */
	public String getsJobDiv() {
		return sJobDiv;
	}
	/**
	 * @param sJobDiv the sJobDiv to set
	 */
	public void setsJobDiv(String sJobDiv) {
		this.sJobDiv = sJobDiv;
	}
	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	/**
	 * @return the sPassFlag
	 */
	public String getsPassFlag() {
		return sPassFlag;
	}
	/**
	 * @param sPassFlag the sPassFlag to set
	 */
	public void setsPassFlag(String sPassFlag) {
		this.sPassFlag = sPassFlag;
	}
	/**
	 * @return the sCompanyType
	 */
	public String getsCompanyType() {
		return sCompanyType;
	}
	/**
	 * @param sCompanyType the sCompanyType to set
	 */
	public void setsCompanyType(String sCompanyType) {
		this.sCompanyType = sCompanyType;
	}
	/**
	 * @return the sCorrespondent
	 */
	public String getsCorrespondent() {
		return sCorrespondent;
	}
	/**
	 * @param sCorrespondent the sCorrespondent to set
	 */
	public void setsCorrespondent(String sCorrespondent) {
		this.sCorrespondent = sCorrespondent;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sBirthYear
	 */
	public String getsBirthYear() {
		return sBirthYear;
	}
	/**
	 * @param sBirthYear the sBirthYear to set
	 */
	public void setsBirthYear(String sBirthYear) {
		this.sBirthYear = sBirthYear;
	}
	/**
	 * @return the sJobTitle
	 */
	public String getsJobTitle() {
		return sJobTitle;
	}
	/**
	 * @param sJobTitle the sJobTitle to set
	 */
	public void setsJobTitle(String sJobTitle) {
		this.sJobTitle = sJobTitle;
	}
	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}
	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}
	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}
	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}
	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}
	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}
	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}
	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	/**
	 * @return the sClass
	 */
	public String getsClass() {
		return sClass;
	}
	/**
	 * @param sClass the sClass to set
	 */
	public void setsClass(String sClass) {
		this.sClass = sClass;
	}
	/**
	 * @return the sJoinDate
	 */
	public String getsJoinDate() {
		return sJoinDate;
	}
	/**
	 * @param sJoinDate the sJoinDate to set
	 */
	public void setsJoinDate(String sJoinDate) {
		this.sJoinDate = sJoinDate;
	}
	/**
	 * @return the sJoinTime
	 */
	public String getsJoinTime() {
		return sJoinTime;
	}
	/**
	 * @param sJoinTime the sJoinTime to set
	 */
	public void setsJoinTime(String sJoinTime) {
		this.sJoinTime = sJoinTime;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sSecedeDate
	 */
	public String getsSecedeDate() {
		return sSecedeDate;
	}
	/**
	 * @param sSecedeDate the sSecedeDate to set
	 */
	public void setsSecedeDate(String sSecedeDate) {
		this.sSecedeDate = sSecedeDate;
	}
	/**
	 * @return the sSecedeTime
	 */
	public String getsSecedeTime() {
		return sSecedeTime;
	}
	/**
	 * @param sSecedeTime the sSecedeTime to set
	 */
	public void setsSecedeTime(String sSecedeTime) {
		this.sSecedeTime = sSecedeTime;
	}
	
	
}
