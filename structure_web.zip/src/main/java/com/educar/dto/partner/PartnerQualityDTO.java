/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;


/**
 * ���¾�ü - ȸ������
 * @author ���ѳ�
 *
 */
public class PartnerQualityDTO {
	
	/** 	������ȣ	**/ 
	private String 	sCarNo;
	/** 	������	**/ 
	private String 	sCarKorName;
	/** 	������	**/ 
	private String 	sCustName;
	/** 	������ȣ	**/ 
	private String 	sAccidentNo;
	/** 	��ü��	**/ 
	private String 	sFactoryName;
	/** 	�ּ�	**/ 
	private String 	sAddress;
	/** 	��ǥ��	**/ 
	private String 	sBossName;
	/** 	����ó	**/ 
	private String 	sTel1;
	/** 	����ó	**/ 
	private String 	sTel2;
	/** 	����ó	**/ 
	private String 	sTel3;
	
	/** 	�㺸	**/ 
	private String 	sHndCover;
	/** 	����	**/ 
	private String 	sDmgeNo;
	/** 	�����Ͻ�������	**/ 
	private String 	sAcctRegiDateFrom;
	/** 	��������������	**/ 
	private String 	sAcctRegiDateTo;
	/** ���� **/
	private String sProgStat;
	/** ����� **/
	private String sCorrespondent;	
	/** 	����ڹ�ȣ	**/ 
	private String 	sBizRegiNo;
	/** 	��	**/ 
	private String 	sMonth;
	/** 	����	**/ 
	private String 	sCenter;
	/** 	��	**/ 
	private String 	sTeam;
	/** 	�����	**/ 
	private String 	sStaff;
	/**		�������� **/
	private String  sCurrDate;
	/** 	������� **/
	private String sReleaseDate;
	/**
	 * @return the sCarNo
	 */
	public String getsCarNo() {
		return sCarNo;
	}
	/**
	 * @param sCarNo the sCarNo to set
	 */
	public void setsCarNo(String sCarNo) {
		this.sCarNo = sCarNo;
	}
	/**
	 * @return the sCarKorName
	 */
	public String getsCarKorName() {
		return sCarKorName;
	}
	/**
	 * @param sCarKorName the sCarKorName to set
	 */
	public void setsCarKorName(String sCarKorName) {
		this.sCarKorName = sCarKorName;
	}
	/**
	 * @return the sCustName
	 */
	public String getsCustName() {
		return sCustName;
	}
	/**
	 * @param sCustName the sCustName to set
	 */
	public void setsCustName(String sCustName) {
		this.sCustName = sCustName;
	}
	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}
	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}
	/**
	 * @return the sFactoryName
	 */
	public String getsFactoryName() {
		return sFactoryName;
	}
	/**
	 * @param sFactoryName the sFactoryName to set
	 */
	public void setsFactoryName(String sFactoryName) {
		this.sFactoryName = sFactoryName;
	}
	/**
	 * @return the sAddress
	 */
	public String getsAddress() {
		return sAddress;
	}
	/**
	 * @param sAddress the sAddress to set
	 */
	public void setsAddress(String sAddress) {
		this.sAddress = sAddress;
	}
	/**
	 * @return the sBossName
	 */
	public String getsBossName() {
		return sBossName;
	}
	/**
	 * @param sBossName the sBossName to set
	 */
	public void setsBossName(String sBossName) {
		this.sBossName = sBossName;
	}
	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}
	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(String sTel1) {
		this.sTel1 = sTel1;
	}
	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}
	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(String sTel2) {
		this.sTel2 = sTel2;
	}
	/**
	 * @return the sTel3
	 */
	public String getsTel3() {
		return sTel3;
	}
	/**
	 * @param sTel3 the sTel3 to set
	 */
	public void setsTel3(String sTel3) {
		this.sTel3 = sTel3;
	}
	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}
	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(String sHndCover) {
		this.sHndCover = sHndCover;
	}
	/**
	 * @return the sDmgeNo
	 */
	public String getsDmgeNo() {
		return sDmgeNo;
	}
	/**
	 * @param sDmgeNo the sDmgeNo to set
	 */
	public void setsDmgeNo(String sDmgeNo) {
		this.sDmgeNo = sDmgeNo;
	}
	/**
	 * @return the sAcctRegiDateFrom
	 */
	public String getsAcctRegiDateFrom() {
		return sAcctRegiDateFrom;
	}
	/**
	 * @param sAcctRegiDateFrom the sAcctRegiDateFrom to set
	 */
	public void setsAcctRegiDateFrom(String sAcctRegiDateFrom) {
		this.sAcctRegiDateFrom = sAcctRegiDateFrom;
	}
	/**
	 * @return the sAcctRegiDateTo
	 */
	public String getsAcctRegiDateTo() {
		return sAcctRegiDateTo;
	}
	/**
	 * @param sAcctRegiDateTo the sAcctRegiDateTo to set
	 */
	public void setsAcctRegiDateTo(String sAcctRegiDateTo) {
		this.sAcctRegiDateTo = sAcctRegiDateTo;
	}
	/**
	 * @return the sProgStat
	 */
	public String getsProgStat() {
		return sProgStat;
	}
	/**
	 * @param sProgStat the sProgStat to set
	 */
	public void setsProgStat(String sProgStat) {
		this.sProgStat = sProgStat;
	}
	/**
	 * @return the sCorrespondent
	 */
	public String getsCorrespondent() {
		return sCorrespondent;
	}
	/**
	 * @param sCorrespondent the sCorrespondent to set
	 */
	public void setsCorrespondent(String sCorrespondent) {
		this.sCorrespondent = sCorrespondent;
	}
	/**
	 * @return the sBizRegiNo
	 */
	public String getsBizRegiNo() {
		return sBizRegiNo;
	}
	/**
	 * @param sBizRegiNo the sBizRegiNo to set
	 */
	public void setsBizRegiNo(String sBizRegiNo) {
		this.sBizRegiNo = sBizRegiNo;
	}
	/**
	 * @return the sMonth
	 */
	public String getsMonth() {
		return sMonth;
	}
	/**
	 * @param sMonth the sMonth to set
	 */
	public void setsMonth(String sMonth) {
		this.sMonth = sMonth;
	}
	/**
	 * @return the sCenter
	 */
	public String getsCenter() {
		return sCenter;
	}
	/**
	 * @param sCenter the sCenter to set
	 */
	public void setsCenter(String sCenter) {
		this.sCenter = sCenter;
	}
	/**
	 * @return the sTeam
	 */
	public String getsTeam() {
		return sTeam;
	}
	/**
	 * @param sTeam the sTeam to set
	 */
	public void setsTeam(String sTeam) {
		this.sTeam = sTeam;
	}
	/**
	 * @return the sStaff
	 */
	public String getsStaff() {
		return sStaff;
	}
	/**
	 * @param sStaff the sStaff to set
	 */
	public void setsStaff(String sStaff) {
		this.sStaff = sStaff;
	}
	/**
	 * @return the sCurrDate
	 */
	public String getsCurrDate() {
		return sCurrDate;
	}
	/**
	 * @param sCurrDate the sCurrDate to set
	 */
	public void setsCurrDate(String sCurrDate) {
		this.sCurrDate = sCurrDate;
	}
	/**
	 * @return the sReleaseDate
	 */
	public String getsReleaseDate() {
		return sReleaseDate;
	}
	/**
	 * @param sReleaseDate the sReleaseDate to set
	 */
	public void setsReleaseDate(String sReleaseDate) {
		this.sReleaseDate = sReleaseDate;
	}
		
}
