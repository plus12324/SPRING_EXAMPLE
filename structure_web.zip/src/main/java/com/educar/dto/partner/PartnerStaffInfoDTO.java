/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;


/**
 * ���������
 * @author ���ѳ�
 *
 */
public class PartnerStaffInfoDTO {
	/** 	����	**/ 
	private String 	sName;
	/** 	�Ҽ�	**/ 
	private String 	sCenterName;
	private String 	sTeamName;
	/** 	�繫��	**/ 
	private String 	sOffTel1;
	private String 	sOffTel2;
	private String 	sOffTel3;
	/** 	�޴���	**/ 
	private String 	sCellTel1;
	private String 	sCellTel2;
	private String 	sCellTel3;
	/** 	�����ѽ�	**/ 
	private String 	sFaxTel1;
	private String 	sFaxTel2;
	private String 	sFaxTel3;
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sCenterName
	 */
	public String getsCenterName() {
		return sCenterName;
	}
	/**
	 * @param sCenterName the sCenterName to set
	 */
	public void setsCenterName(String sCenterName) {
		this.sCenterName = sCenterName;
	}
	/**
	 * @return the sTeamName
	 */
	public String getsTeamName() {
		return sTeamName;
	}
	/**
	 * @param sTeamName the sTeamName to set
	 */
	public void setsTeamName(String sTeamName) {
		this.sTeamName = sTeamName;
	}
	/**
	 * @return the sOffTel1
	 */
	public String getsOffTel1() {
		return sOffTel1;
	}
	/**
	 * @param sOffTel1 the sOffTel1 to set
	 */
	public void setsOffTel1(String sOffTel1) {
		this.sOffTel1 = sOffTel1;
	}
	/**
	 * @return the sOffTel2
	 */
	public String getsOffTel2() {
		return sOffTel2;
	}
	/**
	 * @param sOffTel2 the sOffTel2 to set
	 */
	public void setsOffTel2(String sOffTel2) {
		this.sOffTel2 = sOffTel2;
	}
	/**
	 * @return the sOffTel3
	 */
	public String getsOffTel3() {
		return sOffTel3;
	}
	/**
	 * @param sOffTel3 the sOffTel3 to set
	 */
	public void setsOffTel3(String sOffTel3) {
		this.sOffTel3 = sOffTel3;
	}
	/**
	 * @return the sCellTel1
	 */
	public String getsCellTel1() {
		return sCellTel1;
	}
	/**
	 * @param sCellTel1 the sCellTel1 to set
	 */
	public void setsCellTel1(String sCellTel1) {
		this.sCellTel1 = sCellTel1;
	}
	/**
	 * @return the sCellTel2
	 */
	public String getsCellTel2() {
		return sCellTel2;
	}
	/**
	 * @param sCellTel2 the sCellTel2 to set
	 */
	public void setsCellTel2(String sCellTel2) {
		this.sCellTel2 = sCellTel2;
	}
	/**
	 * @return the sCellTel3
	 */
	public String getsCellTel3() {
		return sCellTel3;
	}
	/**
	 * @param sCellTel3 the sCellTel3 to set
	 */
	public void setsCellTel3(String sCellTel3) {
		this.sCellTel3 = sCellTel3;
	}
	/**
	 * @return the sFaxTel1
	 */
	public String getsFaxTel1() {
		return sFaxTel1;
	}
	/**
	 * @param sFaxTel1 the sFaxTel1 to set
	 */
	public void setsFaxTel1(String sFaxTel1) {
		this.sFaxTel1 = sFaxTel1;
	}
	/**
	 * @return the sFaxTel2
	 */
	public String getsFaxTel2() {
		return sFaxTel2;
	}
	/**
	 * @param sFaxTel2 the sFaxTel2 to set
	 */
	public void setsFaxTel2(String sFaxTel2) {
		this.sFaxTel2 = sFaxTel2;
	}
	/**
	 * @return the sFaxTel3
	 */
	public String getsFaxTel3() {
		return sFaxTel3;
	}
	/**
	 * @param sFaxTel3 the sFaxTel3 to set
	 */
	public void setsFaxTel3(String sFaxTel3) {
		this.sFaxTel3 = sFaxTel3;
	}
	
	

}
