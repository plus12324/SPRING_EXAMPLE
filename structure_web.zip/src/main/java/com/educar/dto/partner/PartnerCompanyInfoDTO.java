/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * ���¾�ü����
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class PartnerCompanyInfoDTO {
	/** 	���¾�ü�ѱ۸�	 **/ 
	private String 	sCompanyKorName;
	/** 	���¾�ü������	 **/ 
	private String 	sCompanyEngName;
	/** 	������ȣ1	 **/ 
	private String 	sZip1;
	/** 	������ȣ2	 **/ 
	private String 	sZip2;
	/** 	������ּ�1	 **/ 
	private String 	sAddress1;
	/** 	������ּ�2	 **/ 
	private String 	sAddress2;
	/** 	��ȭ��ȣ1	 **/ 
	private String 	sTel1;
	/** 	��ȭ��ȣ2	 **/ 
	private String 	sTel2;
	/** 	��ȭ��ȣ3	 **/ 
	private String 	sTel3;
	/** 	�ѽ���ȣ1	 **/
	private String 	sFaxTel1;
	/** 	�ѽ���ȣ2	 **/ 
	private String 	sFaxTel2;
	/** 	�ѽ���ȣ3	 **/ 
	private String 	sFaxTel3;
	
	private String sCorrespondent;
	
	private String sBossSocNo;
	/**
	 * @return the sCompanyKorName
	 */
	public String getsCompanyKorName() {
		return sCompanyKorName;
	}
	/**
	 * @param sCompanyKorName the sCompanyKorName to set
	 */
	public void setsCompanyKorName(String sCompanyKorName) {
		this.sCompanyKorName = sCompanyKorName;
	}
	/**
	 * @return the sCompanyEngName
	 */
	public String getsCompanyEngName() {
		return sCompanyEngName;
	}
	/**
	 * @param sCompanyEngName the sCompanyEngName to set
	 */
	public void setsCompanyEngName(String sCompanyEngName) {
		this.sCompanyEngName = sCompanyEngName;
	}
	/**
	 * @return the sZip1
	 */
	public String getsZip1() {
		return sZip1;
	}
	/**
	 * @param sZip1 the sZip1 to set
	 */
	public void setsZip1(String sZip1) {
		this.sZip1 = sZip1;
	}
	/**
	 * @return the sZip2
	 */
	public String getsZip2() {
		return sZip2;
	}
	/**
	 * @param sZip2 the sZip2 to set
	 */
	public void setsZip2(String sZip2) {
		this.sZip2 = sZip2;
	}
	/**
	 * @return the sAddress1
	 */
	public String getsAddress1() {
		return sAddress1;
	}
	/**
	 * @param sAddress1 the sAddress1 to set
	 */
	public void setsAddress1(String sAddress1) {
		this.sAddress1 = sAddress1;
	}
	/**
	 * @return the sAddress2
	 */
	public String getsAddress2() {
		return sAddress2;
	}
	/**
	 * @param sAddress2 the sAddress2 to set
	 */
	public void setsAddress2(String sAddress2) {
		this.sAddress2 = sAddress2;
	}
	/**
	 * @return the sTel1
	 */
	public String getsTel1() {
		return sTel1;
	}
	/**
	 * @param sTel1 the sTel1 to set
	 */
	public void setsTel1(String sTel1) {
		this.sTel1 = sTel1;
	}
	/**
	 * @return the sTel2
	 */
	public String getsTel2() {
		return sTel2;
	}
	/**
	 * @param sTel2 the sTel2 to set
	 */
	public void setsTel2(String sTel2) {
		this.sTel2 = sTel2;
	}
	/**
	 * @return the sTel3
	 */
	public String getsTel3() {
		return sTel3;
	}
	/**
	 * @param sTel3 the sTel3 to set
	 */
	public void setsTel3(String sTel3) {
		this.sTel3 = sTel3;
	}
	/**
	 * @return the sFaxTel1
	 */
	public String getsFaxTel1() {
		return sFaxTel1;
	}
	/**
	 * @param sFaxTel1 the sFaxTel1 to set
	 */
	public void setsFaxTel1(String sFaxTel1) {
		this.sFaxTel1 = sFaxTel1;
	}
	/**
	 * @return the sFaxTel2
	 */
	public String getsFaxTel2() {
		return sFaxTel2;
	}
	/**
	 * @param sFaxTel2 the sFaxTel2 to set
	 */
	public void setsFaxTel2(String sFaxTel2) {
		this.sFaxTel2 = sFaxTel2;
	}
	/**
	 * @return the sFaxTel3
	 */
	public String getsFaxTel3() {
		return sFaxTel3;
	}
	/**
	 * @param sFaxTel3 the sFaxTel3 to set
	 */
	public void setsFaxTel3(String sFaxTel3) {
		this.sFaxTel3 = sFaxTel3;
	}
	/**
	 * @return the sCorrespondent
	 */
	public String getsCorrespondent() {
		return sCorrespondent;
	}
	/**
	 * @param sCorrespondent the sCorrespondent to set
	 */
	public void setsCorrespondent(String sCorrespondent) {
		this.sCorrespondent = sCorrespondent;
	}
	/**
	 * @return the sBossSocNo
	 */
	public String getsBossSocNo() {
		return sBossSocNo;
	}
	/**
	 * @param sBossSocNo the sBossSocNo to set
	 */
	public void setsBossSocNo(String sBossSocNo) {
		this.sBossSocNo = sBossSocNo;
	}
	
	
}
