/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

/**
 * ���¾�ü����
 * @author ���ѳ�
 *
 */
public class PartnerCompanyInfoWrapperDTO {
	private String totalRows;
	private String result;
	private PartnerCompanyInfoDTO CLMMA09;
	/**
	 * @return the totalRows
	 */
	public String getTotalRows() {
		return totalRows;
	}
	/**
	 * @param totalRows the totalRows to set
	 */
	public void setTotalRows(String totalRows) {
		this.totalRows = totalRows;
	}
	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}
	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}
	/**
	 * @return the cLMMA09
	 */
	public PartnerCompanyInfoDTO getCLMMA09() {
		return CLMMA09;
	}
	/**
	 * @param cLMMA09 the cLMMA09 to set
	 */
	public void setCLMMA09(PartnerCompanyInfoDTO cLMMA09) {
		CLMMA09 = cLMMA09;
	}
	
	
	
}
