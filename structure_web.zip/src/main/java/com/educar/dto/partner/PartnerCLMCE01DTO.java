/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

/**
 * ����ó ����
 * @author ���ѳ�
 *
 */
public class PartnerCLMCE01DTO {
	/** 	�����ޱݾ�	 **/ 
	private String 	nVictimPaymentAmt;
	/** 	�Ѽҵ漼	 **/ 
	private String 	nIncomeTax;
	/** 	���ֹμ�	 **/ 
	private String 	nInhabitantsTax;
	/** 	�ѰǼ�	 **/ 
	private String 	totalRows;
	/**
	 * @return the nVictimPaymentAmt
	 */
	public String getnVictimPaymentAmt() {
		return nVictimPaymentAmt;
	}
	/**
	 * @param nVictimPaymentAmt the nVictimPaymentAmt to set
	 */
	public void setnVictimPaymentAmt(String nVictimPaymentAmt) {
		this.nVictimPaymentAmt = nVictimPaymentAmt;
	}
	/**
	 * @return the nIncomeTax
	 */
	public String getnIncomeTax() {
		return nIncomeTax;
	}
	/**
	 * @param nIncomeTax the nIncomeTax to set
	 */
	public void setnIncomeTax(String nIncomeTax) {
		this.nIncomeTax = nIncomeTax;
	}
	/**
	 * @return the nInhabitantsTax
	 */
	public String getnInhabitantsTax() {
		return nInhabitantsTax;
	}
	/**
	 * @param nInhabitantsTax the nInhabitantsTax to set
	 */
	public void setnInhabitantsTax(String nInhabitantsTax) {
		this.nInhabitantsTax = nInhabitantsTax;
	}
	/**
	 * @return the totalRows
	 */
	public String getTotalRows() {
		return totalRows;
	}
	/**
	 * @param totalRows the totalRows to set
	 */
	public void setTotalRows(String totalRows) {
		this.totalRows = totalRows;
	}
	
	

}
