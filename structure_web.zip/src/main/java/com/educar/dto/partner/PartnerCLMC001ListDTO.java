/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

/**
 * ���޻���
 * @author ���ѳ�
 *
 */
public class PartnerCLMC001ListDTO {
	/** 	������ȣ	 **/ 
	private String 	sAccidentNo;
	/** 	�㺸	 **/ 
	private String 	sHndCover;
	/** 	������(��)	 **/ 
	private String 	sVictim;
	/** 	���������	 **/ 
	private String 	nDcAmt;
	/** 	�ҵ漼	 **/ 
	private String 	nIncomeTax;
	/** 	�ֹμ�	 **/ 
	private String 	nInhabitantsTax;
	/** 	���޺����	 **/ 
	private String 	nPaymentAmt;
	/** 	��������	 **/ 
	private String 	sPaymentDate;
	/** 	�����	 **/
	private String 	sName;
	/** 	�㺸�� **/ 
	private String 	sHndCoverName;
	/** 	���޺����2	 **/ 
	private String 	nPaymentAmt2;
	/**
	 * @return the sAccidentNo
	 */
	public String getsAccidentNo() {
		return sAccidentNo;
	}
	/**
	 * @param sAccidentNo the sAccidentNo to set
	 */
	public void setsAccidentNo(String sAccidentNo) {
		this.sAccidentNo = sAccidentNo;
	}
	/**
	 * @return the sHndCover
	 */
	public String getsHndCover() {
		return sHndCover;
	}
	/**
	 * @param sHndCover the sHndCover to set
	 */
	public void setsHndCover(String sHndCover) {
		this.sHndCover = sHndCover;
	}
	/**
	 * @return the sVictim
	 */
	public String getsVictim() {
		return sVictim;
	}
	/**
	 * @param sVictim the sVictim to set
	 */
	public void setsVictim(String sVictim) {
		this.sVictim = sVictim;
	}
	/**
	 * @return the nDcAmt
	 */
	public String getnDcAmt() {
		return nDcAmt;
	}
	/**
	 * @param nDcAmt the nDcAmt to set
	 */
	public void setnDcAmt(String nDcAmt) {
		this.nDcAmt = nDcAmt;
	}
	/**
	 * @return the nIncomeTax
	 */
	public String getnIncomeTax() {
		return nIncomeTax;
	}
	/**
	 * @param nIncomeTax the nIncomeTax to set
	 */
	public void setnIncomeTax(String nIncomeTax) {
		this.nIncomeTax = nIncomeTax;
	}
	/**
	 * @return the nInhabitantsTax
	 */
	public String getnInhabitantsTax() {
		return nInhabitantsTax;
	}
	/**
	 * @param nInhabitantsTax the nInhabitantsTax to set
	 */
	public void setnInhabitantsTax(String nInhabitantsTax) {
		this.nInhabitantsTax = nInhabitantsTax;
	}
	/**
	 * @return the nPaymentAmt
	 */
	public String getnPaymentAmt() {
		return nPaymentAmt;
	}
	/**
	 * @param nPaymentAmt the nPaymentAmt to set
	 */
	public void setnPaymentAmt(String nPaymentAmt) {
		this.nPaymentAmt = nPaymentAmt;
	}
	/**
	 * @return the sPaymentDate
	 */
	public String getsPaymentDate() {
		return sPaymentDate;
	}
	/**
	 * @param sPaymentDate the sPaymentDate to set
	 */
	public void setsPaymentDate(String sPaymentDate) {
		this.sPaymentDate = sPaymentDate;
	}
	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}
	/**
	 * @return the sHndCoverName
	 */
	public String getsHndCoverName() {
		return sHndCoverName;
	}
	/**
	 * @param sHndCoverName the sHndCoverName to set
	 */
	public void setsHndCoverName(String sHndCoverName) {
		this.sHndCoverName = sHndCoverName;
	}
	/**
	 * @return the nPaymentAmt2
	 */
	public String getnPaymentAmt2() {
		return nPaymentAmt2;
	}
	/**
	 * @param nPaymentAmt2 the nPaymentAmt2 to set
	 */
	public void setnPaymentAmt2(String nPaymentAmt2) {
		this.nPaymentAmt2 = nPaymentAmt2;
	}
	
	
}
