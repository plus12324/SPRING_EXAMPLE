/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.partner;

/**
 * ���¾�ü - �ӽú�й�ȣ �߼�
 * @author ���ѳ�
 *
 */
public class PartnerTempPwdSendDTO {
	/** 	���¾�ü�ѱ۸�	**/ 
	private String	sCompanyKorName;
	/** 	�޴�����ȣ	**/ 
	private String	sCellPhone;
	/** 	����ڹ�ȣ	**/ 
	private String	sBizRegiNo;
	/** 	����ڱ���	**/ 
	private String	sJobDiv;
	/** 	�޽���	**/
	private String	sMessage;
	/** 	����÷���	**/ 
	private String	result;
	/**
	 * @return the sCompanyKorName
	 */
	public String getsCompanyKorName() {
		return sCompanyKorName;
	}
	/**
	 * @param sCompanyKorName the sCompanyKorName to set
	 */
	public void setsCompanyKorName(String sCompanyKorName) {
		this.sCompanyKorName = sCompanyKorName;
	}
	/**
	 * @return the sCellPhone
	 */
	public String getsCellPhone() {
		return sCellPhone;
	}
	/**
	 * @param sCellPhone the sCellPhone to set
	 */
	public void setsCellPhone(String sCellPhone) {
		this.sCellPhone = sCellPhone;
	}
	/**
	 * @return the sBizRegiNo
	 */
	public String getsBizRegiNo() {
		return sBizRegiNo;
	}
	/**
	 * @param sBizRegiNo the sBizRegiNo to set
	 */
	public void setsBizRegiNo(String sBizRegiNo) {
		this.sBizRegiNo = sBizRegiNo;
	}
	/**
	 * @return the sJobDiv
	 */
	public String getsJobDiv() {
		return sJobDiv;
	}
	/**
	 * @param sJobDiv the sJobDiv to set
	 */
	public void setsJobDiv(String sJobDiv) {
		this.sJobDiv = sJobDiv;
	}
	/**
	 * @return the sMessage
	 */
	public String getsMessage() {
		return sMessage;
	}
	/**
	 * @param sMessage the sMessage to set
	 */
	public void setsMessage(String sMessage) {
		this.sMessage = sMessage;
	}
	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}
	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}
	
	

}
