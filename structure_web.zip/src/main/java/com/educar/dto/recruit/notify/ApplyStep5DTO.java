/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep5DTO")
public class ApplyStep5DTO {
	
	/**	�̷¼�����Ϸ�**/	
	private String	sResumeConfirmYN;
	
	/**	�̷¼�����Ϸ�����**/	
	private String	sResumeConfirmDate;
	
	/**	ä���ȣ**/	
	private String	sHireNo;
	
	/**	������ȣ  **/	
	private String	nApplyNo;

	/**
	 * @return the sResumeConfirmYN
	 */
	public String getsResumeConfirmYN() {
		return sResumeConfirmYN;
	}

	/**
	 * @param sResumeConfirmYN the sResumeConfirmYN to set
	 */
	public void setsResumeConfirmYN(String sResumeConfirmYN) {
		this.sResumeConfirmYN = sResumeConfirmYN;
	}

	/**
	 * @return the sResumeConfirmDate
	 */
	public String getsResumeConfirmDate() {
		return sResumeConfirmDate;
	}

	/**
	 * @param sResumeConfirmDate the sResumeConfirmDate to set
	 */
	public void setsResumeConfirmDate(String sResumeConfirmDate) {
		this.sResumeConfirmDate = sResumeConfirmDate;
	}

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	
}

