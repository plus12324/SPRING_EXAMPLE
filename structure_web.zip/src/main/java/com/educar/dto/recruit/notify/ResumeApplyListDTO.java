/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "resumeApplyListDTO")
public class ResumeApplyListDTO {
	/** ä��� **/
	private String sHireName;
	/** ä���ȣ **/
	private String sHireNo;
	/** ������� **/
	private String sStatus;
	/** ä�������� **/
	private String sRecruitTodt;
	
	/**
	 * @return the sRecruitTodt
	 */
	public String getsRecruitTodt() {
		return sRecruitTodt;
	}
	/**
	 * @param sRecruitTodt the sRecruitTodt to set
	 */
	public void setsRecruitTodt(String sRecruitTodt) {
		this.sRecruitTodt = sRecruitTodt;
	}
	/**
	 * @return the sHireName
	 */
	public String getsHireName() {
		return sHireName;
	}
	/**
	 * @param sHireName the sHireName to set
	 */
	public void setsHireName(String sHireName) {
		this.sHireName = sHireName;
	}
	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}
	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}
	/**
	 * @return the sStatus
	 */
	public String getsStatus() {
		return sStatus;
	}
	/**
	 * @param sStatus the sStatus to set
	 */
	public void setsStatus(String sStatus) {
		this.sStatus = sStatus;
	}	
	
}
