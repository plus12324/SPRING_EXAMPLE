/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ի���������3(updateApplystep3)�ڰݸ������
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3OfHRMAA07DTO")
public class ApplyStep3OfHRMAA07DTO {
	
	/**	ä���ȣ**/	
	private String	sHireNo;
	
	/**	������ȣ**/	
	private String	nApplyNo;
	
	/**	�ڰݸ������**/	
	private String	nLicenseSeq;
	
	/**	�ڰݸ���� **/
	private String	sLicenseNm;
	
	/**	�ڰ�����ȣ **/	
	private String	sLicenseNo;
	
	/**	�ڰ�������� **/	
	private String	sLicenseGetDt;
	
	/**	����ó��	**/	
	private String	sLicenseEnroll;
	
	/**	���  **/	
	private String	sNote;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the nLicenseSeq
	 */
	public String getnLicenseSeq() {
		return nLicenseSeq;
	}

	/**
	 * @param nLicenseSeq the nLicenseSeq to set
	 */
	public void setnLicenseSeq(String nLicenseSeq) {
		this.nLicenseSeq = nLicenseSeq;
	}

	/**
	 * @return the sLicenseNm
	 */
	public String getsLicenseNm() {
		return sLicenseNm;
	}

	/**
	 * @param sLicenseNm the sLicenseNm to set
	 */
	public void setsLicenseNm(String sLicenseNm) {
		this.sLicenseNm = sLicenseNm;
	}

	/**
	 * @return the sLicenseNo
	 */
	public String getsLicenseNo() {
		return sLicenseNo;
	}

	/**
	 * @param sLicenseNo the sLicenseNo to set
	 */
	public void setsLicenseNo(String sLicenseNo) {
		this.sLicenseNo = sLicenseNo;
	}

	/**
	 * @return the sLicenseGetDt
	 */
	public String getsLicenseGetDt() {
		return sLicenseGetDt;
	}

	/**
	 * @param sLicenseGetDt the sLicenseGetDt to set
	 */
	public void setsLicenseGetDt(String sLicenseGetDt) {
		this.sLicenseGetDt = sLicenseGetDt;
	}

	/**
	 * @return the sLicenseEnroll
	 */
	public String getsLicenseEnroll() {
		return sLicenseEnroll;
	}

	/**
	 * @param sLicenseEnroll the sLicenseEnroll to set
	 */
	public void setsLicenseEnroll(String sLicenseEnroll) {
		this.sLicenseEnroll = sLicenseEnroll;
	}

	/**
	 * @return the sNote
	 */
	public String getsNote() {
		return sNote;
	}

	/**
	 * @param sNote the sNote to set
	 */
	public void setsNote(String sNote) {
		this.sNote = sNote;
	}
	
	

}
