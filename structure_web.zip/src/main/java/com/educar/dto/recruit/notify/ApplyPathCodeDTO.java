/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * applyStep1���� ���Ǵ� ��������ڵ�DTO
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyPathCodeDTO")
public class ApplyPathCodeDTO {
	
	private String	sClassCode;
	
	private String	sDetailCode;
	
	private String	sDetailNm;
	
	private String	sOption1;
	
	private String	sOption2;
	
	private String	sOption3;
	
	private String	nOption1;
	
	private String	nOption2;
	
	private String	nOption3;

	/**
	 * @return the sClassCode
	 */
	public String getsClassCode() {
		return sClassCode;
	}

	/**
	 * @param sClassCode the sClassCode to set
	 */
	public void setsClassCode(String sClassCode) {
		this.sClassCode = sClassCode;
	}

	/**
	 * @return the sDetailCode
	 */
	public String getsDetailCode() {
		return sDetailCode;
	}

	/**
	 * @param sDetailCode the sDetailCode to set
	 */
	public void setsDetailCode(String sDetailCode) {
		this.sDetailCode = sDetailCode;
	}

	/**
	 * @return the sDetailNm
	 */
	public String getsDetailNm() {
		return sDetailNm;
	}

	/**
	 * @param sDetailNm the sDetailNm to set
	 */
	public void setsDetailNm(String sDetailNm) {
		this.sDetailNm = sDetailNm;
	}

	/**
	 * @return the sOption1
	 */
	public String getsOption1() {
		return sOption1;
	}

	/**
	 * @param sOption1 the sOption1 to set
	 */
	public void setsOption1(String sOption1) {
		this.sOption1 = sOption1;
	}

	/**
	 * @return the sOption2
	 */
	public String getsOption2() {
		return sOption2;
	}

	/**
	 * @param sOption2 the sOption2 to set
	 */
	public void setsOption2(String sOption2) {
		this.sOption2 = sOption2;
	}

	/**
	 * @return the sOption3
	 */
	public String getsOption3() {
		return sOption3;
	}

	/**
	 * @param sOption3 the sOption3 to set
	 */
	public void setsOption3(String sOption3) {
		this.sOption3 = sOption3;
	}

	/**
	 * @return the nOption1
	 */
	public String getnOption1() {
		return nOption1;
	}

	/**
	 * @param nOption1 the nOption1 to set
	 */
	public void setnOption1(String nOption1) {
		this.nOption1 = nOption1;
	}

	/**
	 * @return the nOption2
	 */
	public String getnOption2() {
		return nOption2;
	}

	/**
	 * @param nOption2 the nOption2 to set
	 */
	public void setnOption2(String nOption2) {
		this.nOption2 = nOption2;
	}

	/**
	 * @return the nOption3
	 */
	public String getnOption3() {
		return nOption3;
	}

	/**
	 * @param nOption3 the nOption3 to set
	 */
	public void setnOption3(String nOption3) {
		this.nOption3 = nOption3;
	}


}
