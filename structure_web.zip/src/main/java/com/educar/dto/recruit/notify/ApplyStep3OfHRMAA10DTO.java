/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ի���������3(updateApplystep3) ������������
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3OfHRMAA10DTO")
public class ApplyStep3OfHRMAA10DTO {
	
	/**	ä���ȣ             	**/	
	private String	sHireNo;
	
	/**	������ȣ             	**/	
	private String	nApplyNo;
	
	/**	ȸ��	**/	
	private String	nSeq;
	
	/**	����������           	**/	
	private String	sEduName;
	
	/**	����������           	**/	
	private String	sEduFmdt;
	
	/**	����������           	**/	
	private String	sEduTodt;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the nSeq
	 */
	public String getnSeq() {
		return nSeq;
	}

	/**
	 * @param nSeq the nSeq to set
	 */
	public void setnSeq(String nSeq) {
		this.nSeq = nSeq;
	}

	/**
	 * @return the sEduName
	 */
	public String getsEduName() {
		return sEduName;
	}

	/**
	 * @param sEduName the sEduName to set
	 */
	public void setsEduName(String sEduName) {
		this.sEduName = sEduName;
	}

	/**
	 * @return the sEduFmdt
	 */
	public String getsEduFmdt() {
		return sEduFmdt;
	}

	/**
	 * @param sEduFmdt the sEduFmdt to set
	 */
	public void setsEduFmdt(String sEduFmdt) {
		this.sEduFmdt = sEduFmdt;
	}

	/**
	 * @return the sEduTodt
	 */
	public String getsEduTodt() {
		return sEduTodt;
	}

	/**
	 * @param sEduTodt the sEduTodt to set
	 */
	public void setsEduTodt(String sEduTodt) {
		this.sEduTodt = sEduTodt;
	}
	
	

}
