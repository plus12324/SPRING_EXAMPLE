/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.vo.RecruitInfoVO;
import com.educar.dto.recruit.notify.ApplyStep3OfHRMAA05DTO;
import com.educar.dto.recruit.notify.ApplyStep3OfHRMAA07DTO;
import com.educar.dto.recruit.notify.ApplyStep3OfHRMAA09DTO;
import com.educar.dto.recruit.notify.ApplyStep3OfHRMAA10DTO;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3DTO")
public class ApplyStep3DTO {
	
	/**BaseDoc �⺻����**/ 
	private RecruitInfoVO BaseDoc;
	


	/**HRMAA05 ��»��� **/ 
	@XmlElementWrapper(name = "HRMAA05List")
	private List<ApplyStep3OfHRMAA05DTO> HRMAA05; 
	
	/**HRMAA07 ������� **/ 
	@XmlElementWrapper(name = "HRMAA07List")
	private List<ApplyStep3OfHRMAA07DTO> HRMAA07; 
	
	/**HRMAA09 �ܱ������ **/ 
	@XmlElementWrapper(name = "HRMAA09List")
	private List<ApplyStep3OfHRMAA09DTO> HRMAA09; 
	
	/**HRMAA10 ������������ **/ 
	@XmlElementWrapper(name = "HRMAA10List")
	private List<ApplyStep3OfHRMAA10DTO> HRMAA10;
	
	/**
	 * @return the baseDoc
	 */
	public RecruitInfoVO getBaseDoc() {
		return BaseDoc;
	}

	/**
	 * @param baseDoc the baseDoc to set
	 */
	public void setBaseDoc(RecruitInfoVO baseDoc) {
		BaseDoc = baseDoc;
	}
	
	
	/**
	 * @return the hRMAA05
	 */
	public List<ApplyStep3OfHRMAA05DTO> getHRMAA05() {
		return HRMAA05;
	}

	/**
	 * @param hRMAA05 the hRMAA05 to set
	 */
	public void setHRMAA05(List<ApplyStep3OfHRMAA05DTO> hRMAA05) {
		HRMAA05 = hRMAA05;
	}

	/**
	 * @return the hRMAA07
	 */
	public List<ApplyStep3OfHRMAA07DTO> getHRMAA07() {
		return HRMAA07;
	}

	/**
	 * @param hRMAA07 the hRMAA07 to set
	 */
	public void setHRMAA07(List<ApplyStep3OfHRMAA07DTO> hRMAA07) {
		HRMAA07 = hRMAA07;
	}

	/**
	 * @return the hRMAA09
	 */
	public List<ApplyStep3OfHRMAA09DTO> getHRMAA09() {
		return HRMAA09;
	}

	/**
	 * @param hRMAA09 the hRMAA09 to set
	 */
	public void setHRMAA09(List<ApplyStep3OfHRMAA09DTO> hRMAA09) {
		HRMAA09 = hRMAA09;
	}

	/**
	 * @return the hRMAA10
	 */
	public List<ApplyStep3OfHRMAA10DTO> getHRMAA10() {
		return HRMAA10;
	}

	/**
	 * @param hRMAA10 the hRMAA10 to set
	 */
	public void setHRMAA10(List<ApplyStep3OfHRMAA10DTO> hRMAA10) {
		HRMAA10 = hRMAA10;
	} 
	
	

}
