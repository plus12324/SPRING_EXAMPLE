/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3OutputDTO")
public class ApplyStep3OutputDTO {

	/**HRMAA05 ��»��� **/ 
	@XmlElementWrapper(name = "hrmaa05Vec")
	private List<ApplyStep3OfHRMAA05DTO> hrmaa05Vec; 
	
	/**HRMAA07 ������� **/ 
	@XmlElementWrapper(name = "hrmaa07Vec")
	private List<ApplyStep3OfHRMAA07DTO> hrmaa07Vec; 
	
	/**HRMAA09 �ܱ������ **/ 
	@XmlElementWrapper(name = "hrmaa09Vec")
	private List<ApplyStep3OfHRMAA09DTO> hrmaa09Vec; 
	
	/**HRMAA10 ������������ **/ 
	@XmlElementWrapper(name = "hrmaa10Vec")
	private List<ApplyStep3OfHRMAA10DTO> hrmaa10Vec;

	/**
	 * @return the hrmaa05Vec
	 */
	public List<ApplyStep3OfHRMAA05DTO> getHrmaa05Vec() {
		return hrmaa05Vec;
	}

	/**
	 * @param hrmaa05Vec the hrmaa05Vec to set
	 */
	public void setHrmaa05Vec(List<ApplyStep3OfHRMAA05DTO> hrmaa05Vec) {
		this.hrmaa05Vec = hrmaa05Vec;
	}

	/**
	 * @return the hrmaa07Vec
	 */
	public List<ApplyStep3OfHRMAA07DTO> getHrmaa07Vec() {
		return hrmaa07Vec;
	}

	/**
	 * @param hrmaa07Vec the hrmaa07Vec to set
	 */
	public void setHrmaa07Vec(List<ApplyStep3OfHRMAA07DTO> hrmaa07Vec) {
		this.hrmaa07Vec = hrmaa07Vec;
	}

	/**
	 * @return the hrmaa09Vec
	 */
	public List<ApplyStep3OfHRMAA09DTO> getHrmaa09Vec() {
		return hrmaa09Vec;
	}

	/**
	 * @param hrmaa09Vec the hrmaa09Vec to set
	 */
	public void setHrmaa09Vec(List<ApplyStep3OfHRMAA09DTO> hrmaa09Vec) {
		this.hrmaa09Vec = hrmaa09Vec;
	}

	/**
	 * @return the hrmaa10Vec
	 */
	public List<ApplyStep3OfHRMAA10DTO> getHrmaa10Vec() {
		return hrmaa10Vec;
	}

	/**
	 * @param hrmaa10Vec the hrmaa10Vec to set
	 */
	public void setHrmaa10Vec(List<ApplyStep3OfHRMAA10DTO> hrmaa10Vec) {
		this.hrmaa10Vec = hrmaa10Vec;
	}
	
	
	
	
	
}
