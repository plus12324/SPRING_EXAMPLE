/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *  �Ի���������3(updateApplystep3) ��»���
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3OfHRMAA05DTO")
public class ApplyStep3OfHRMAA05DTO {
	
	/**		ä���ȣ             	**/	
	private String	sHireNo;
	
	/**		������ȣ             	**/	
	private String	nApplyNo;
	
	/**		ȸ�����             	**/	
	private String	nCompSeq;
	
	/**		�Ի���               	**/	
	private String	sJoinDt;
	
	/**		�����               	**/	
	private String	sRetireDt;
	
	/**		ȸ���               	**/	
	private String	sCompNm;
	
	/**		�μ���               	**/	
	private String	sDepartNm;
	
	/**	"01 ����
	02 ����
	03 ����
	04 ��
	05 �̻�
	06 ����
	07 ����
	08 ����
	09 �븮
	10 ���
	99 ��Ÿ"	����                 	**/	
	private String	sPosition;
	
	/**	�ֿ���� **/	
	private String	sMajorWork;
	
	/**		������               	**/	
	private String	sWorkSite;
	
	/**		��¿���             	**/	
	private String	nCareerTerm;
	
	/**		��������             	**/	
	private String	nApproveTerm;
	
	/**		��������             	**/	
	private String	sApproveReason;
	
	/**		��������	**/	
	private String	sRetireReason;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the nCompSeq
	 */
	public String getnCompSeq() {
		return nCompSeq;
	}

	/**
	 * @param nCompSeq the nCompSeq to set
	 */
	public void setnCompSeq(String nCompSeq) {
		this.nCompSeq = nCompSeq;
	}

	/**
	 * @return the sJoinDt
	 */
	public String getsJoinDt() {
		return sJoinDt;
	}

	/**
	 * @param sJoinDt the sJoinDt to set
	 */
	public void setsJoinDt(String sJoinDt) {
		this.sJoinDt = sJoinDt;
	}

	/**
	 * @return the sRetireDt
	 */
	public String getsRetireDt() {
		return sRetireDt;
	}

	/**
	 * @param sRetireDt the sRetireDt to set
	 */
	public void setsRetireDt(String sRetireDt) {
		this.sRetireDt = sRetireDt;
	}

	/**
	 * @return the sCompNm
	 */
	public String getsCompNm() {
		return sCompNm;
	}

	/**
	 * @param sCompNm the sCompNm to set
	 */
	public void setsCompNm(String sCompNm) {
		this.sCompNm = sCompNm;
	}

	/**
	 * @return the sDepartNm
	 */
	public String getsDepartNm() {
		return sDepartNm;
	}

	/**
	 * @param sDepartNm the sDepartNm to set
	 */
	public void setsDepartNm(String sDepartNm) {
		this.sDepartNm = sDepartNm;
	}

	/**
	 * @return the sPosition
	 */
	public String getsPosition() {
		return sPosition;
	}

	/**
	 * @param sPosition the sPosition to set
	 */
	public void setsPosition(String sPosition) {
		this.sPosition = sPosition;
	}

	/**
	 * @return the sMajorWork
	 */
	public String getsMajorWork() {
		return sMajorWork;
	}

	/**
	 * @param sMajorWork the sMajorWork to set
	 */
	public void setsMajorWork(String sMajorWork) {
		this.sMajorWork = sMajorWork;
	}

	/**
	 * @return the sWorkSite
	 */
	public String getsWorkSite() {
		return sWorkSite;
	}

	/**
	 * @param sWorkSite the sWorkSite to set
	 */
	public void setsWorkSite(String sWorkSite) {
		this.sWorkSite = sWorkSite;
	}

	/**
	 * @return the nCareerTerm
	 */
	public String getnCareerTerm() {
		return nCareerTerm;
	}

	/**
	 * @param nCareerTerm the nCareerTerm to set
	 */
	public void setnCareerTerm(String nCareerTerm) {
		this.nCareerTerm = nCareerTerm;
	}

	/**
	 * @return the nApproveTerm
	 */
	public String getnApproveTerm() {
		return nApproveTerm;
	}

	/**
	 * @param nApproveTerm the nApproveTerm to set
	 */
	public void setnApproveTerm(String nApproveTerm) {
		this.nApproveTerm = nApproveTerm;
	}

	/**
	 * @return the sApproveReason
	 */
	public String getsApproveReason() {
		return sApproveReason;
	}

	/**
	 * @param sApproveReason the sApproveReason to set
	 */
	public void setsApproveReason(String sApproveReason) {
		this.sApproveReason = sApproveReason;
	}

	/**
	 * @return the sRetireReason
	 */
	public String getsRetireReason() {
		return sRetireReason;
	}

	/**
	 * @param sRetireReason the sRetireReason to set
	 */
	public void setsRetireReason(String sRetireReason) {
		this.sRetireReason = sRetireReason;
	}
	
	

}
