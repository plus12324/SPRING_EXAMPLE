/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep1Ofhrmaa08DocDTO")
public class ApplyStep1Ofhrmaa08DocDTO {
	
	/** 	��������             	**/	
	private String	nFamilySeq;
	
	/** 	�����ڵ�             	**/	
	private String	sRelCode;
	
	/** 	����                 	**/	
	private String	sName;
	
	/** 	����                 	**/	
	private String	nAge;
	
	/** 	�з��ڵ�             	**/
	private String	sEduCode;
	
	/** 	�ٹ�ó��             	**/
	private String	sJobName;
	
	/** 	������              	**/	
	private String	sPosition;
	
	/** 	���ſ���             	**/	
	private String	sLiveYN;

	/** 	������ȣ          	**/	
	private String	nApplyNo;
	
	/** 	ä���ȣ    	**/	
	
	private String	sHireNo;
	
	
	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nFamilySeq
	 */
	public String getnFamilySeq() {
		return nFamilySeq;
	}

	/**
	 * @param nFamilySeq the nFamilySeq to set
	 */
	public void setnFamilySeq(String nFamilySeq) {
		this.nFamilySeq = nFamilySeq;
	}

	/**
	 * @return the sRelCode
	 */
	public String getsRelCode() {
		return sRelCode;
	}

	/**
	 * @param sRelCode the sRelCode to set
	 */
	public void setsRelCode(String sRelCode) {
		this.sRelCode = sRelCode;
	}

	/**
	 * @return the sName
	 */
	public String getsName() {
		return sName;
	}

	/**
	 * @param sName the sName to set
	 */
	public void setsName(String sName) {
		this.sName = sName;
	}

	/**
	 * @return the nAge
	 */
	public String getnAge() {
		return nAge;
	}

	/**
	 * @param nAge the nAge to set
	 */
	public void setnAge(String nAge) {
		this.nAge = nAge;
	}

	/**
	 * @return the sEduCode
	 */
	public String getsEduCode() {
		return sEduCode;
	}

	/**
	 * @param sEduCode the sEduCode to set
	 */
	public void setsEduCode(String sEduCode) {
		this.sEduCode = sEduCode;
	}

	/**
	 * @return the sJobName
	 */
	public String getsJobName() {
		return sJobName;
	}

	/**
	 * @param sJobName the sJobName to set
	 */
	public void setsJobName(String sJobName) {
		this.sJobName = sJobName;
	}

	/**
	 * @return the sPosition
	 */
	public String getsPosition() {
		return sPosition;
	}

	/**
	 * @param sPosition the sPosition to set
	 */
	public void setsPosition(String sPosition) {
		this.sPosition = sPosition;
	}

	/**
	 * @return the sLiveYN
	 */
	public String getsLiveYN() {
		return sLiveYN;
	}

	/**
	 * @param sLiveYN the sLiveYN to set
	 */
	public void setsLiveYN(String sLiveYN) {
		this.sLiveYN = sLiveYN;
	}

}
