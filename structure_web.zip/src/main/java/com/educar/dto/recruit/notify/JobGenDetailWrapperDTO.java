/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ���ѳ�
 *
 */
@XmlRootElement(name="jobGenDetailWrapperDTO")
public class JobGenDetailWrapperDTO {
	/** �Ϲ� ���� �� **/
	private JobMasterDTO masterResult;
	/** �Ϲ� ���� �㺸���� **/
	private List<JobDetailDTO> detailList;
	/**
	 * @return the masterResult
	 */
	public JobMasterDTO getMasterResult() {
		return masterResult;
	}
	/**
	 * @param masterResult the masterResult to set
	 */
	public void setMasterResult(JobMasterDTO masterResult) {
		this.masterResult = masterResult;
	}
	/**
	 * @return the detailList
	 */
	public List<JobDetailDTO> getDetailList() {
		return detailList;
	}
	/**
	 * @param detailList the detailList to set
	 */
	public void setDetailList(List<JobDetailDTO> detailList) {
		this.detailList = detailList;
	}
	
	
	
}
