/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * �Ի���������3(updateApplystep3) �ܱ������
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep3OfHRMAA09DTO")
public class ApplyStep3OfHRMAA09DTO {
	
	/**	ä���ȣ**/	
	private String	sHireNo;
	
	/**	������ȣ**/	
	private String	nApplyNo;
	
	/** 1 ����
    	2 �Ϻ���
    	3 �߱���
    	4 ���Ͼ�
    	5 �Ҿ�
    	6 ���ݾƾ�
    	7 �ƶ���
    	9 ��Ÿ	
	�ܱ����  **/	
	private String	sLangType;
	
	/**	�ܱ������**/	
	private String	sApplyDt;
	
	/**	������**/	
	private String	sDegree;
	
	/**	���(�����)**/	
	private String	nPoint;
	
	/**	����**/	
	private String	sNote;
	
	/**	��� **/	
	private String	nLangSeq;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sLangType
	 */
	public String getsLangType() {
		return sLangType;
	}

	/**
	 * @param sLangType the sLangType to set
	 */
	public void setsLangType(String sLangType) {
		this.sLangType = sLangType;
	}

	/**
	 * @return the sApplyDt
	 */
	public String getsApplyDt() {
		return sApplyDt;
	}

	/**
	 * @param sApplyDt the sApplyDt to set
	 */
	public void setsApplyDt(String sApplyDt) {
		this.sApplyDt = sApplyDt;
	}

	/**
	 * @return the sDegree
	 */
	public String getsDegree() {
		return sDegree;
	}

	/**
	 * @param sDegree the sDegree to set
	 */
	public void setsDegree(String sDegree) {
		this.sDegree = sDegree;
	}

	/**
	 * @return the nPoint
	 */
	public String getnPoint() {
		return nPoint;
	}

	/**
	 * @param nPoint the nPoint to set
	 */
	public void setnPoint(String nPoint) {
		this.nPoint = nPoint;
	}

	/**
	 * @return the sNote
	 */
	public String getsNote() {
		return sNote;
	}

	/**
	 * @param sNote the sNote to set
	 */
	public void setsNote(String sNote) {
		this.sNote = sNote;
	}

	/**
	 * @return the nLangSeq
	 */
	public String getnLangSeq() {
		return nLangSeq;
	}

	/**
	 * @param nLangSeq the nLangSeq to set
	 */
	public void setnLangSeq(String nLangSeq) {
		this.nLangSeq = nLangSeq;
	}
	
	

}
