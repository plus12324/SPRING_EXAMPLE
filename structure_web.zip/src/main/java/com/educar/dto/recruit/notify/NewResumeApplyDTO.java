/**
 * Copyright (c) 2012, All rights reserved. TSIS PROPRIETARY/CONFIDENTIAL. Use
 * is subject to project license terms. All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * 
 * @author ���ѳ�
 * 
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "newResumeApplyDTO")
public class NewResumeApplyDTO implements Serializable{
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/** ä���ȣ **/
	private String sHireNo;
	/** �̸�  **/
	private String sKorName;
	/** �̸��� 1 **/
	private String sEmail;
	/** ��й�ȣ **/
	private String sPassword;
	/** ��й�ȣ Ȯ�� **/
	private String sPasswd2;
	/**
	 * @return the sName
	 */
	public String getsKorName() {
		return sKorName;
	}
	/**
	 * @param sName the sName to set
	 */
	public void setsKorName(String sKorName) {
		this.sKorName = sKorName;
	}
	/**
	 * @return the sEmial1
	 */
	public String getsEmail() {
		return sEmail;
	}
	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}
	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}
	/**
	 * @param sEmial1 the sEmial1 to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	/**
	 * @return the sPasswd1
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPasswd1 the sPasswd1 to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	/**
	 * @return the sPasswd2
	 */
	public String getsPasswd2() {
		return sPasswd2;
	}
	/**
	 * @param sPasswd2 the sPasswd2 to set
	 */
	public void setsPasswd2(String sPasswd2) {
		this.sPasswd2 = sPasswd2;
	}
	

	

}
