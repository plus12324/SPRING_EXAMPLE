/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep4DTO")
public class ApplyStep4DTO {

	/**	ä���ȣ             		**/	
	private String sHireNo;
	
	/**	������ȣ             		**/	
	private String nApplyNo;
	
	/**	�������             	**/	
	private String	sIntroText1;
	
	/**	���ݼҰ�             	**/	
	private String	sIntroText2;
	
	/**	��Ȱ����             	**/	
	private String	sIntroText3;
	
	/**	��������             	**/	
	private String	sIntroText4;
	
	/**	�ڱ��������         	**/	
	private String	sIntroText5;
	
	/**	��»���             	**/	
	private String	sIntroText6;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sIntroText1
	 */
	public String getsIntroText1() {
		return sIntroText1;
	}

	/**
	 * @param sIntroText1 the sIntroText1 to set
	 */
	public void setsIntroText1(String sIntroText1) {
		this.sIntroText1 = sIntroText1;
	}

	/**
	 * @return the sIntroText2
	 */
	public String getsIntroText2() {
		return sIntroText2;
	}

	/**
	 * @param sIntroText2 the sIntroText2 to set
	 */
	public void setsIntroText2(String sIntroText2) {
		this.sIntroText2 = sIntroText2;
	}

	/**
	 * @return the sIntroText3
	 */
	public String getsIntroText3() {
		return sIntroText3;
	}

	/**
	 * @param sIntroText3 the sIntroText3 to set
	 */
	public void setsIntroText3(String sIntroText3) {
		this.sIntroText3 = sIntroText3;
	}

	/**
	 * @return the sIntroText4
	 */
	public String getsIntroText4() {
		return sIntroText4;
	}

	/**
	 * @param sIntroText4 the sIntroText4 to set
	 */
	public void setsIntroText4(String sIntroText4) {
		this.sIntroText4 = sIntroText4;
	}

	/**
	 * @return the sIntroText5
	 */
	public String getsIntroText5() {
		return sIntroText5;
	}

	/**
	 * @param sIntroText5 the sIntroText5 to set
	 */
	public void setsIntroText5(String sIntroText5) {
		this.sIntroText5 = sIntroText5;
	}

	/**
	 * @return the sIntroText6
	 */
	public String getsIntroText6() {
		return sIntroText6;
	}

	/**
	 * @param sIntroText6 the sIntroText6 to set
	 */
	public void setsIntroText6(String sIntroText6) {
		this.sIntroText6 = sIntroText6;
	}

	
}
