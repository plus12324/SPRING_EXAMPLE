/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * �Ի�����1�ܰ� �ƿ�ǲ DTO( setApplyStep1 output��)
 * 
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep1OutputDTO")
public class ApplyStep1OutputDTO {

	
	/**hrmaa03Doc **/ 		
	private ApplyStep1Ofhrmaa03DocDTO hrmaa03Doc;
	
	/** hrmaa08Vec **/
	@XmlElementWrapper(name = "hrmaa08Vec")
	private List<ApplyStep1Ofhrmaa08DocDTO> hrmaa08Vec;

	/**
	 * @return the hrmaa03Doc
	 */
	public ApplyStep1Ofhrmaa03DocDTO getHrmaa03Doc() {
		return hrmaa03Doc;
	}

	/**
	 * @param hrmaa03Doc the hrmaa03Doc to set
	 */
	public void setHrmaa03Doc(ApplyStep1Ofhrmaa03DocDTO hrmaa03Doc) {
		this.hrmaa03Doc = hrmaa03Doc;
	}

	/**
	 * @return the hrmaa08Vec
	 */
	public List<ApplyStep1Ofhrmaa08DocDTO> getHrmaa08Vec() {
		return hrmaa08Vec;
	}

	/**
	 * @param hrmaa08Vec the hrmaa08Vec to set
	 */
	public void setHrmaa08Vec(List<ApplyStep1Ofhrmaa08DocDTO> hrmaa08Vec) {
		this.hrmaa08Vec = hrmaa08Vec;
	}	
	
}
