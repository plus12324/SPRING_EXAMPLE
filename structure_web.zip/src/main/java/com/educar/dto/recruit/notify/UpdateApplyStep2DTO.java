/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.vo.RecruitInfoVO;
import com.educar.dto.recruit.notify.ApplyStep2DTO;

/**
 * updateApplyStep2 ��
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "updateApplyStep2DTO")
public class UpdateApplyStep2DTO {
	
	/**BaseDoc �⺻����**/ 
	private RecruitInfoVO BaseDoc;
	
	/** HRMAA04 **/
	@XmlElementWrapper(name = "HRMAA04List")
	private List<ApplyStep2DTO> HRMAA04; 

	/**
	 * @return the baseDoc
	 */
	public RecruitInfoVO getBaseDoc() {
		return BaseDoc;
	}

	/**
	 * @param baseDoc the baseDoc to set
	 */
	public void setBaseDoc(RecruitInfoVO baseDoc) {
		BaseDoc = baseDoc;
	}

	/**
	 * @return the hRMAA04
	 */
	public List<ApplyStep2DTO> getHRMAA04() {
		return HRMAA04;
	}

	/**
	 * @param hRMAA04 the hRMAA04 to set
	 */
	public void setHRMAA04(List<ApplyStep2DTO> hRMAA04) {
		HRMAA04 = hRMAA04;
	}

	
}
