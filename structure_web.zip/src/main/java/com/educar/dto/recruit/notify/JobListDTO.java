/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.educar.common.dto.PageDTO;

/**
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "jobListDTO")
public class JobListDTO extends PageDTO{
	/** ���� **/
	private String sGubun;
	/** ä���ȣ       **/	
	private String	sHireNo;
	/** ä���     **/	
	private String	sHireName;
	/**  �������� **/
	private String sStatus;
	/**  ������¸�  **/
	private String sStatusNm;
	/** �����Ⱓ **/
	private String sRecruitdt;
	/** �������� **/
	private String sHireGroup;
	/** �� ���� ���� **/
	public String sWebResultYN;
	
	private String sRecruitFmdt;
	
	private String sRecruitTodt;
	/**
	 * @return the sGubun
	 */
	public String getsGubun() {
		return sGubun;
	}
	/**
	 * @param sGubun the sGubun to set
	 */
	public void setsGubun(String sGubun) {
		this.sGubun = sGubun;
	}
	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}
	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}
	/**
	 * @return the sHireName
	 */
	public String getsHireName() {
		return sHireName;
	}
	/**
	 * @param sHireName the sHireName to set
	 */
	public void setsHireName(String sHireName) {
		this.sHireName = sHireName;
	}
	/**
	 * @return the sStatus
	 */
	public String getsStatus() {
		return sStatus;
	}
	/**
	 * @param sStatus the sStatus to set
	 */
	public void setsStatus(String sStatus) {
		this.sStatus = sStatus;
	}
	/**
	 * @return the sStatusNm
	 */
	public String getsStatusNm() {
		return sStatusNm;
	}
	/**
	 * @param sStatusNm the sStatusNm to set
	 */
	public void setsStatusNm(String sStatusNm) {
		this.sStatusNm = sStatusNm;
	}
	/**
	 * @return the sRecruitDt
	 */
	public String getsRecruitdt() {
		return sRecruitdt;
	}
	/**
	 * @param sRecruitDt the sRecruitDt to set
	 */
	public void setsRecruitdt(String sRecruitdt) {
		this.sRecruitdt = sRecruitdt;
	}
	/**
	 * @return the sHireGroup
	 */
	public String getsHireGroup() {
		return sHireGroup;
	}
	/**
	 * @param sHireGroup the sHireGroup to set
	 */
	public void setsHireGroup(String sHireGroup) {
		this.sHireGroup = sHireGroup;
	}
	
	/**
	 * @return the sWebNoticeYN
	 */
	public String getsWebResultYN() {
		return sWebResultYN;
	}
	/**
	 * @param sWebNoticeYN the sWebNoticeYN to set
	 */
	public void setsWebResultYN(String sWebResultYN) {
		this.sWebResultYN = sWebResultYN;
	}
	/**
	 * @return the sRecruitFmdt
	 */
	public String getsRecruitFmdt() {
		return sRecruitFmdt;
	}
	/**
	 * @param sRecruitFmdt the sRecruitFmdt to set
	 */
	public void setsRecruitFmdt(String sRecruitFmdt) {
		this.sRecruitFmdt = sRecruitFmdt;
	}
	/**
	 * @return the sRecruitTodt
	 */
	public String getsRecruitTodt() {
		return sRecruitTodt;
	}
	/**
	 * @param sRecruitTodt the sRecruitTodt to set
	 */
	public void setsRecruitTodt(String sRecruitTodt) {
		this.sRecruitTodt = sRecruitTodt;
	}
	

}
