/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep1Ofhrmaa03DocDTO")
public class ApplyStep1Ofhrmaa03DocDTO {

	/** ä���ȣ **/
	private String sHireNo;	

	/** ������ȣ **/
	private String nApplyNo;	

	/** �������� **/
	private String nOrgSeq;		
	
	/** ä������      **/
	private String sHireType;	
	
	/**  ��±���    **/
	private String sCareerType;	

	/** �����ι�     **/
	private String sRecruitGroup;	
	
	/** �ѱ۸�     **/
	private String sKorName;	

	/** ������     **/
	private String sEngName;	
	
	/** �ѹ���     **/
	private String sChiName;	

	/** �ֹε�Ϲ�ȣ     **/
	private String sCitizenNo;	
	
	/** ����     **/
	private String sBirthDt;	

	/** ���ϱ���     **/
	private String sBirthdayType;	
	
	/** ����     **/
	private String sSex;	

	/** Email     **/
	private String sEmail;	
	
	/** ȣ��     **/
	private String sFamilyMaster;	

	/** ȣ�ֿ��ǰ����ڵ�     **/
	private String sFamilyMasterRel;	
	
	/** ����ȭ1     **/
	private String sHomeTel1;	

	/** ����ȭ2     **/
	private String sHomeTel2;	
	
	/** ����ȭ3      **/
	private String sHomeTel3;	

	/** �ڵ���1     **/
	private String sCellPhone1;	
	
	/** �ڵ���2     **/
	private String sCellPhone2;	

	/** �ڵ���3     **/
	private String sCellPhone3;	
	
	/** ��޿���ó1      **/
	private String sUrgentTel1;	

	/** ��޿���ó2       **/
	private String sUrgentTel2;	
	
	/** ��޿���ó3     **/
	private String sUrgentTel3;	

	/** ���ּҿ�����ȣ     **/
	private String sCurrZip;	
	
	/** ���ּ�     **/
	private String sCurrAdrs;	

	/** ���ּұ�Ÿ     **/
	private String sCurrAdrsAdd;	
	
	/** ����������ȣ     **/
	private String sBirthZip;	

	/** �����ּ�       **/
	private String sBirthAdrs;	
	
	/** ������Ÿ      **/
	private String sBirthAdrsAdd;	

	/** ����ι�     **/
	private String sHopeGroup;	
	
	/** ����ٹ���1     **/
	private String sHopeWorkSite1;	

	/** ����ٹ���2     **/
	private String sHopeWorkSite2;	
	
	/** ������������     **/
	private String sRealPromoteDt;	

	/** ���翬��     **/
	private String nCurrSalary;	
	
	/** �������     **/
	private String nHopeSalary;	

	/** �������     **/
	private String sHopeClass;	
	
	/** ����     **/
	private String nHeight;	

	/** ü��     **/
	private String nWeight;	
	
	/** �÷���     **/
	private String nLeftEyesight;	

	/** �÷¿�     **/
	private String nRightEyesight;	
	
	/** ���Ϳ���     **/
	private String sColorBlindYN;	

	/** ���1     **/
	private String sHobby1;	
	
	/** ���2      **/
	private String sHobby2;	

	/** Ư��     **/
	private String sSpecialty;	
	
	/** �����ڵ� (01 ���� 02 �ұ�  03 �⵶�� 04 õ�ֱ� 05 ���� 06 ���ұ� 07 �̽����� 08 õ���� 99 ��Ÿ  **/
	private String sReligionCode;	

	/** ��������     1 �ǿ���
2 ����
3 ����**/
	private String sMilitaryStat;	
	
	/** ����   1 ����
2 �ر�
3 ����
4 �غ�
5 ����
6 �ǰ�
7 �ǹ��ҹ��
8 ī���  **/
	private String sMilitaryType;	

	/** ����     **/
	private String sMilitaryNo;	
	
	/** ����    01 ����
02 ����
03 �Ⱙ
04 ����
05 ���
06 ����
07 ����
08 ����
09 ȭ��
10 ����(�ΰ�)
11 �庴
12 �渮
13 ����
14 ����(�ǹ�)
15 ġ��
16 ����
17 ����
18 ����
19 ����
20 ��ȣ
21 ����
22 ���
23 ���
24 �Ϲ�
25 �ü�
26 ����
27 ����
28 ����
29 ���
30 ���̴�
31 ��ȣ
32 ����
33 ����
34 ��񱳵�
35 ����
36 ����
37 ���
38 ����
39 �⹫
99 ��Ÿ **/
	private String sMilitaryGroup;	
	
	/** ���     01 ����
02 ����
03 ����
04 ����
05 ���
06 �߷�
07 �ҷ�
08 ����
09 ����
10 ����
11 ����
12 ���
13 �߻�
14 �ϻ�
15 ����
16 ��
17 �Ϻ�
18 �̺�**/
	private String sMilitaryClass;	
	

	/** �����ⰣFROM      **/
	private String sMilitaryFmdt;	
	
	

	/** �����ⰣTO       **/
	private String sMilitaryTodt;	
	
	/** �����ڵ� **/
	private String sRemissionCode;	
	
	/** ���ƴ�󿩺� ���('Y') **/
	private String sExploitYN;	
	
	/** �������� **/
	private String sExploitType;	
	
	/** ��õ���� **/
	private String sRecmdCode;	
	
	/** ��õ�� **/
	private String sRecmdNm;	
	
	/** ��� **/
	private String sNote;	
	
	/** �����ڵ� **/
	private String sSelCode;	
	
	/** �հݿ���**/
	private String sPassYN;	
	
	/** �̷¼�����Ϸ�**/
	private String sResumeConfirmYN;	
	
	/** �۾���IP**/
	private String sUserIP;	
	
	/** �۾��ڻ�� **/
	private String sUserID;	
	
	/** �۾��� **/
	private String sInputDate;	
	
	/** �۾��ð� **/
	private String sInputTime;	
	
	/**��������й�ȣ **/
	private String sPassword;	
	
	/**������������ȣ **/
	private String sCertifyNo;	
	
	/** 	�������	**/	
	private String	sApplyPath1	;
	
	/** 	�������ΰ��	**/	
	private String	sApplyPath2;
	
	//�����θ��ּ� ��ȯ�� ���� �ʿ��׸�
	/** ���ּ� - �����θ� �����ּ�   **/
	private String sCurrDoroAddr;
	/** ���ּ� - �����θ� �ּҰ�����ȣ   **/
	private String sCurrAddrMgtNo;	
	/** ���ּ� - �����θ� ǥ���ּ� ��ȯ ����   **/
	private String sCurrStdAddrFlag;	
	
	/** ������ - �����θ� �����ּ�   **/
	private String sBirthDoroAddr;
	/** ������ - �����θ� �ּҰ�����ȣ   **/
	private String sBirthAddrMgtNo;	
	/** ������ - �����θ� ǥ���ּ� ��ȯ ����   **/
	private String sBirthStdAddrFlag;	
	
	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the nOrgSeq
	 */
	public String getnOrgSeq() {
		return nOrgSeq;
	}

	/**
	 * @param nOrgSeq the nOrgSeq to set
	 */
	public void setnOrgSeq(String nOrgSeq) {
		this.nOrgSeq = nOrgSeq;
	}

	/**
	 * @return the sHireType
	 */
	public String getsHireType() {
		return sHireType;
	}

	/**
	 * @param sHireType the sHireType to set
	 */
	public void setsHireType(String sHireType) {
		this.sHireType = sHireType;
	}

	/**
	 * @return the sCareerType
	 */
	public String getsCareerType() {
		return sCareerType;
	}

	/**
	 * @param sCareerType the sCareerType to set
	 */
	public void setsCareerType(String sCareerType) {
		this.sCareerType = sCareerType;
	}

	/**
	 * @return the sRecruitGroup
	 */
	public String getsRecruitGroup() {
		return sRecruitGroup;
	}

	/**
	 * @param sRecruitGroup the sRecruitGroup to set
	 */
	public void setsRecruitGroup(String sRecruitGroup) {
		this.sRecruitGroup = sRecruitGroup;
	}

	/**
	 * @return the sKorName
	 */
	public String getsKorName() {
		return sKorName;
	}

	/**
	 * @param sKorName the sKorName to set
	 */
	public void setsKorName(String sKorName) {
		this.sKorName = sKorName;
	}

	/**
	 * @return the sEngName
	 */
	public String getsEngName() {
		return sEngName;
	}

	/**
	 * @param sEngName the sEngName to set
	 */
	public void setsEngName(String sEngName) {
		this.sEngName = sEngName;
	}

	/**
	 * @return the sChiName
	 */
	public String getsChiName() {
		return sChiName;
	}

	/**
	 * @param sChiName the sChiName to set
	 */
	public void setsChiName(String sChiName) {
		this.sChiName = sChiName;
	}

	/**
	 * @return the sCitizenNo
	 */
	public String getsCitizenNo() {
		return sCitizenNo;
	}

	/**
	 * @param sCitizenNo the sCitizenNo to set
	 */
	public void setsCitizenNo(String sCitizenNo) {
		this.sCitizenNo = sCitizenNo;
	}

	/**
	 * @return the sBirthDt
	 */
	public String getsBirthDt() {
		return sBirthDt;
	}

	/**
	 * @param sBirthDt the sBirthDt to set
	 */
	public void setsBirthDt(String sBirthDt) {
		this.sBirthDt = sBirthDt;
	}

	/**
	 * @return the sBirthdayType
	 */
	public String getsBirthdayType() {
		return sBirthdayType;
	}

	/**
	 * @param sBirthdayType the sBirthdayType to set
	 */
	public void setsBirthdayType(String sBirthdayType) {
		this.sBirthdayType = sBirthdayType;
	}

	/**
	 * @return the sSex
	 */
	public String getsSex() {
		return sSex;
	}

	/**
	 * @param sSex the sSex to set
	 */
	public void setsSex(String sSex) {
		this.sSex = sSex;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sFamilyMaster
	 */
	public String getsFamilyMaster() {
		return sFamilyMaster;
	}

	/**
	 * @param sFamilyMaster the sFamilyMaster to set
	 */
	public void setsFamilyMaster(String sFamilyMaster) {
		this.sFamilyMaster = sFamilyMaster;
	}

	/**
	 * @return the sFamilyMasterRel
	 */
	public String getsFamilyMasterRel() {
		return sFamilyMasterRel;
	}

	/**
	 * @param sFamilyMasterRel the sFamilyMasterRel to set
	 */
	public void setsFamilyMasterRel(String sFamilyMasterRel) {
		this.sFamilyMasterRel = sFamilyMasterRel;
	}

	/**
	 * @return the sHomeTel1
	 */
	public String getsHomeTel1() {
		return sHomeTel1;
	}

	/**
	 * @param sHomeTel1 the sHomeTel1 to set
	 */
	public void setsHomeTel1(String sHomeTel1) {
		this.sHomeTel1 = sHomeTel1;
	}

	/**
	 * @return the sHomeTel2
	 */
	public String getsHomeTel2() {
		return sHomeTel2;
	}

	/**
	 * @param sHomeTel2 the sHomeTel2 to set
	 */
	public void setsHomeTel2(String sHomeTel2) {
		this.sHomeTel2 = sHomeTel2;
	}

	/**
	 * @return the sHomeTel3
	 */
	public String getsHomeTel3() {
		return sHomeTel3;
	}

	/**
	 * @param sHomeTel3 the sHomeTel3 to set
	 */
	public void setsHomeTel3(String sHomeTel3) {
		this.sHomeTel3 = sHomeTel3;
	}

	/**
	 * @return the sCellPhone1
	 */
	public String getsCellPhone1() {
		return sCellPhone1;
	}

	/**
	 * @param sCellPhone1 the sCellPhone1 to set
	 */
	public void setsCellPhone1(String sCellPhone1) {
		this.sCellPhone1 = sCellPhone1;
	}

	/**
	 * @return the sCellPhone2
	 */
	public String getsCellPhone2() {
		return sCellPhone2;
	}

	/**
	 * @param sCellPhone2 the sCellPhone2 to set
	 */
	public void setsCellPhone2(String sCellPhone2) {
		this.sCellPhone2 = sCellPhone2;
	}

	/**
	 * @return the sCellPhone3
	 */
	public String getsCellPhone3() {
		return sCellPhone3;
	}

	/**
	 * @param sCellPhone3 the sCellPhone3 to set
	 */
	public void setsCellPhone3(String sCellPhone3) {
		this.sCellPhone3 = sCellPhone3;
	}

	/**
	 * @return the sUrgentTel1
	 */
	public String getsUrgentTel1() {
		return sUrgentTel1;
	}

	/**
	 * @param sUrgentTel1 the sUrgentTel1 to set
	 */
	public void setsUrgentTel1(String sUrgentTel1) {
		this.sUrgentTel1 = sUrgentTel1;
	}

	/**
	 * @return the sUrgentTel2
	 */
	public String getsUrgentTel2() {
		return sUrgentTel2;
	}

	/**
	 * @param sUrgentTel2 the sUrgentTel2 to set
	 */
	public void setsUrgentTel2(String sUrgentTel2) {
		this.sUrgentTel2 = sUrgentTel2;
	}

	/**
	 * @return the sUrgentTel3
	 */
	public String getsUrgentTel3() {
		return sUrgentTel3;
	}

	/**
	 * @param sUrgentTel3 the sUrgentTel3 to set
	 */
	public void setsUrgentTel3(String sUrgentTel3) {
		this.sUrgentTel3 = sUrgentTel3;
	}

	/**
	 * @return the sCurrZip
	 */
	public String getsCurrZip() {
		return sCurrZip;
	}

	/**
	 * @param sCurrZip the sCurrZip to set
	 */
	public void setsCurrZip(String sCurrZip) {
		this.sCurrZip = sCurrZip;
	}

	/**
	 * @return the sCurrAdrs
	 */
	public String getsCurrAdrs() {
		return sCurrAdrs;
	}

	/**
	 * @param sCurrAdrs the sCurrAdrs to set
	 */
	public void setsCurrAdrs(String sCurrAdrs) {
		this.sCurrAdrs = sCurrAdrs;
	}

	/**
	 * @return the sCurrAdrsAdd
	 */
	public String getsCurrAdrsAdd() {
		return sCurrAdrsAdd;
	}

	/**
	 * @param sCurrAdrsAdd the sCurrAdrsAdd to set
	 */
	public void setsCurrAdrsAdd(String sCurrAdrsAdd) {
		this.sCurrAdrsAdd = sCurrAdrsAdd;
	}

	/**
	 * @return the sBirthZip
	 */
	public String getsBirthZip() {
		return sBirthZip;
	}

	/**
	 * @param sBirthZip the sBirthZip to set
	 */
	public void setsBirthZip(String sBirthZip) {
		this.sBirthZip = sBirthZip;
	}

	/**
	 * @return the sBirthAdrs
	 */
	public String getsBirthAdrs() {
		return sBirthAdrs;
	}

	/**
	 * @param sBirthAdrs the sBirthAdrs to set
	 */
	public void setsBirthAdrs(String sBirthAdrs) {
		this.sBirthAdrs = sBirthAdrs;
	}

	/**
	 * @return the sBirthAdrsAdd
	 */
	public String getsBirthAdrsAdd() {
		return sBirthAdrsAdd;
	}

	/**
	 * @param sBirthAdrsAdd the sBirthAdrsAdd to set
	 */
	public void setsBirthAdrsAdd(String sBirthAdrsAdd) {
		this.sBirthAdrsAdd = sBirthAdrsAdd;
	}

	/**
	 * @return the sHopeGroup
	 */
	public String getsHopeGroup() {
		return sHopeGroup;
	}

	/**
	 * @param sHopeGroup the sHopeGroup to set
	 */
	public void setsHopeGroup(String sHopeGroup) {
		this.sHopeGroup = sHopeGroup;
	}

	/**
	 * @return the sHopeWorkSite1
	 */
	public String getsHopeWorkSite1() {
		return sHopeWorkSite1;
	}

	/**
	 * @param sHopeWorkSite1 the sHopeWorkSite1 to set
	 */
	public void setsHopeWorkSite1(String sHopeWorkSite1) {
		this.sHopeWorkSite1 = sHopeWorkSite1;
	}

	/**
	 * @return the sHopeWorkSite2
	 */
	public String getsHopeWorkSite2() {
		return sHopeWorkSite2;
	}

	/**
	 * @param sHopeWorkSite2 the sHopeWorkSite2 to set
	 */
	public void setsHopeWorkSite2(String sHopeWorkSite2) {
		this.sHopeWorkSite2 = sHopeWorkSite2;
	}

	/**
	 * @return the sRealPromoteDt
	 */
	public String getsRealPromoteDt() {
		return sRealPromoteDt;
	}

	/**
	 * @param sRealPromoteDt the sRealPromoteDt to set
	 */
	public void setsRealPromoteDt(String sRealPromoteDt) {
		this.sRealPromoteDt = sRealPromoteDt;
	}

	/**
	 * @return the nCurrSalary
	 */
	public String getnCurrSalary() {
		return nCurrSalary;
	}

	/**
	 * @param nCurrSalary the nCurrSalary to set
	 */
	public void setnCurrSalary(String nCurrSalary) {
		this.nCurrSalary = nCurrSalary;
	}

	/**
	 * @return the nHopeSalary
	 */
	public String getnHopeSalary() {
		return nHopeSalary;
	}

	/**
	 * @param nHopeSalary the nHopeSalary to set
	 */
	public void setnHopeSalary(String nHopeSalary) {
		this.nHopeSalary = nHopeSalary;
	}

	/**
	 * @return the sHopeClass
	 */
	public String getsHopeClass() {
		return sHopeClass;
	}

	/**
	 * @param sHopeClass the sHopeClass to set
	 */
	public void setsHopeClass(String sHopeClass) {
		this.sHopeClass = sHopeClass;
	}

	/**
	 * @return the nHeight
	 */
	public String getnHeight() {
		return nHeight;
	}

	/**
	 * @param nHeight the nHeight to set
	 */
	public void setnHeight(String nHeight) {
		this.nHeight = nHeight;
	}

	/**
	 * @return the nWeight
	 */
	public String getnWeight() {
		return nWeight;
	}

	/**
	 * @param nWeight the nWeight to set
	 */
	public void setnWeight(String nWeight) {
		this.nWeight = nWeight;
	}

	/**
	 * @return the nLeftEyesight
	 */
	public String getnLeftEyesight() {
		return nLeftEyesight;
	}

	/**
	 * @param nLeftEyesight the nLeftEyesight to set
	 */
	public void setnLeftEyesight(String nLeftEyesight) {
		this.nLeftEyesight = nLeftEyesight;
	}

	/**
	 * @return the nRightEyesight
	 */
	public String getnRightEyesight() {
		return nRightEyesight;
	}

	/**
	 * @param nRightEyesight the nRightEyesight to set
	 */
	public void setnRightEyesight(String nRightEyesight) {
		this.nRightEyesight = nRightEyesight;
	}

	/**
	 * @return the sColorBlindYN
	 */
	public String getsColorBlindYN() {
		return sColorBlindYN;
	}

	/**
	 * @param sColorBlindYN the sColorBlindYN to set
	 */
	public void setsColorBlindYN(String sColorBlindYN) {
		this.sColorBlindYN = sColorBlindYN;
	}

	/**
	 * @return the sHobby1
	 */
	public String getsHobby1() {
		return sHobby1;
	}

	/**
	 * @param sHobby1 the sHobby1 to set
	 */
	public void setsHobby1(String sHobby1) {
		this.sHobby1 = sHobby1;
	}

	/**
	 * @return the sHobby2
	 */
	public String getsHobby2() {
		return sHobby2;
	}

	/**
	 * @param sHobby2 the sHobby2 to set
	 */
	public void setsHobby2(String sHobby2) {
		this.sHobby2 = sHobby2;
	}

	/**
	 * @return the sSpecialty
	 */
	public String getsSpecialty() {
		return sSpecialty;
	}

	/**
	 * @param sSpecialty the sSpecialty to set
	 */
	public void setsSpecialty(String sSpecialty) {
		this.sSpecialty = sSpecialty;
	}

	/**
	 * @return the sReligionCode
	 */
	public String getsReligionCode() {
		return sReligionCode;
	}

	/**
	 * @param sReligionCode the sReligionCode to set
	 */
	public void setsReligionCode(String sReligionCode) {
		this.sReligionCode = sReligionCode;
	}

	/**
	 * @return the sMilitaryStat
	 */
	public String getsMilitaryStat() {
		return sMilitaryStat;
	}

	/**
	 * @param sMilitaryStat the sMilitaryStat to set
	 */
	public void setsMilitaryStat(String sMilitaryStat) {
		this.sMilitaryStat = sMilitaryStat;
	}

	/**
	 * @return the sMilitaryType
	 */
	public String getsMilitaryType() {
		return sMilitaryType;
	}

	/**
	 * @param sMilitaryType the sMilitaryType to set
	 */
	public void setsMilitaryType(String sMilitaryType) {
		this.sMilitaryType = sMilitaryType;
	}

	/**
	 * @return the sMilitaryNo
	 */
	public String getsMilitaryNo() {
		return sMilitaryNo;
	}

	/**
	 * @param sMilitaryNo the sMilitaryNo to set
	 */
	public void setsMilitaryNo(String sMilitaryNo) {
		this.sMilitaryNo = sMilitaryNo;
	}

	/**
	 * @return the sMilitaryGroup
	 */
	public String getsMilitaryGroup() {
		return sMilitaryGroup;
	}

	/**
	 * @param sMilitaryGroup the sMilitaryGroup to set
	 */
	public void setsMilitaryGroup(String sMilitaryGroup) {
		this.sMilitaryGroup = sMilitaryGroup;
	}

	/**
	 * @return the sMilitaryClass
	 */
	public String getsMilitaryClass() {
		return sMilitaryClass;
	}

	/**
	 * @param sMilitaryClass the sMilitaryClass to set
	 */
	public void setsMilitaryClass(String sMilitaryClass) {
		this.sMilitaryClass = sMilitaryClass;
	}

	/**
	 * @return the sMilitaryFmdt
	 */
	public String getsMilitaryFmdt() {
		return sMilitaryFmdt;
	}

	/**
	 * @param sMilitaryFmdt the sMilitaryFmdt to set
	 */
	public void setsMilitaryFmdt(String sMilitaryFmdt) {
		this.sMilitaryFmdt = sMilitaryFmdt;
	}

	/**
	 * @return the sMilitaryTodt
	 */
	public String getsMilitaryTodt() {
		return sMilitaryTodt;
	}

	/**
	 * @param sMilitaryTodt the sMilitaryTodt to set
	 */
	public void setsMilitaryTodt(String sMilitaryTodt) {
		this.sMilitaryTodt = sMilitaryTodt;
	}

	/**
	 * @return the sRemissionCode
	 */
	public String getsRemissionCode() {
		return sRemissionCode;
	}

	/**
	 * @param sRemissionCode the sRemissionCode to set
	 */
	public void setsRemissionCode(String sRemissionCode) {
		this.sRemissionCode = sRemissionCode;
	}

	/**
	 * @return the sExploitYN
	 */
	public String getsExploitYN() {
		return sExploitYN;
	}

	/**
	 * @param sExploitYN the sExploitYN to set
	 */
	public void setsExploitYN(String sExploitYN) {
		this.sExploitYN = sExploitYN;
	}

	/**
	 * @return the sExploitType
	 */
	public String getsExploitType() {
		return sExploitType;
	}

	/**
	 * @param sExploitType the sExploitType to set
	 */
	public void setsExploitType(String sExploitType) {
		this.sExploitType = sExploitType;
	}

	/**
	 * @return the sRecmdCode
	 */
	public String getsRecmdCode() {
		return sRecmdCode;
	}

	/**
	 * @param sRecmdCode the sRecmdCode to set
	 */
	public void setsRecmdCode(String sRecmdCode) {
		this.sRecmdCode = sRecmdCode;
	}

	/**
	 * @return the sRecmdNm
	 */
	public String getsRecmdNm() {
		return sRecmdNm;
	}

	/**
	 * @param sRecmdNm the sRecmdNm to set
	 */
	public void setsRecmdNm(String sRecmdNm) {
		this.sRecmdNm = sRecmdNm;
	}

	/**
	 * @return the sNote
	 */
	public String getsNote() {
		return sNote;
	}

	/**
	 * @param sNote the sNote to set
	 */
	public void setsNote(String sNote) {
		this.sNote = sNote;
	}

	/**
	 * @return the sSelCode
	 */
	public String getsSelCode() {
		return sSelCode;
	}

	/**
	 * @param sSelCode the sSelCode to set
	 */
	public void setsSelCode(String sSelCode) {
		this.sSelCode = sSelCode;
	}

	/**
	 * @return the sPassYN
	 */
	public String getsPassYN() {
		return sPassYN;
	}

	/**
	 * @param sPassYN the sPassYN to set
	 */
	public void setsPassYN(String sPassYN) {
		this.sPassYN = sPassYN;
	}

	/**
	 * @return the sResumeConfirmYN
	 */
	public String getsResumeConfirmYN() {
		return sResumeConfirmYN;
	}

	/**
	 * @param sResumeConfirmYN the sResumeConfirmYN to set
	 */
	public void setsResumeConfirmYN(String sResumeConfirmYN) {
		this.sResumeConfirmYN = sResumeConfirmYN;
	}

	/**
	 * @return the sUserIP
	 */
	public String getsUserIP() {
		return sUserIP;
	}

	/**
	 * @param sUserIP the sUserIP to set
	 */
	public void setsUserIP(String sUserIP) {
		this.sUserIP = sUserIP;
	}

	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}

	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}

	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}

	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}

	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}

	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}

	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}

	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}

	/**
	 * @return the sCertifyNo
	 */
	public String getsCertifyNo() {
		return sCertifyNo;
	}

	/**
	 * @param sCertifyNo the sCertifyNo to set
	 */
	public void setsCertifyNo(String sCertifyNo) {
		this.sCertifyNo = sCertifyNo;
	}

	/**
	 * @return the sApplyPath1
	 */
	public String getsApplyPath1() {
		return sApplyPath1;
	}

	/**
	 * @param sApplyPath1 the sApplyPath1 to set
	 */
	public void setsApplyPath1(String sApplyPath1) {
		this.sApplyPath1 = sApplyPath1;
	}

	/**
	 * @return the sApplyPath2
	 */
	public String getsApplyPath2() {
		return sApplyPath2;
	}

	/**
	 * @param sApplyPath2 the sApplyPath2 to set
	 */
	public void setsApplyPath2(String sApplyPath2) {
		this.sApplyPath2 = sApplyPath2;
	}

	/**
	 * @return the sCurrDoroAddr
	 */
	public String getsCurrDoroAddr() {
		return sCurrDoroAddr;
	}

	/**
	 * @param sCurrDoroAddr the sCurrDoroAddr to set
	 */
	public void setsCurrDoroAddr(String sCurrDoroAddr) {
		this.sCurrDoroAddr = sCurrDoroAddr;
	}

	/**
	 * @return the sCurrAddrMgtNo
	 */
	public String getsCurrAddrMgtNo() {
		return sCurrAddrMgtNo;
	}

	/**
	 * @param sCurrAddrMgtNo the sCurrAddrMgtNo to set
	 */
	public void setsCurrAddrMgtNo(String sCurrAddrMgtNo) {
		this.sCurrAddrMgtNo = sCurrAddrMgtNo;
	}

	/**
	 * @return the sCurrStdAddrFlag
	 */
	public String getsCurrStdAddrFlag() {
		return sCurrStdAddrFlag;
	}

	/**
	 * @param sCurrStdAddrFlag the sCurrStdAddrFlag to set
	 */
	public void setsCurrStdAddrFlag(String sCurrStdAddrFlag) {
		this.sCurrStdAddrFlag = sCurrStdAddrFlag;
	}

	/**
	 * @return the sBirthDoroAddr1
	 */
	public String getsBirthDoroAddr() {
		return sBirthDoroAddr;
	}

	/**
	 * @param sBirthDoroAddr1 the sBirthDoroAddr1 to set
	 */
	public void setsBirthDoroAddr(String sBirthDoroAddr) {
		this.sBirthDoroAddr = sBirthDoroAddr;
	}

	/**
	 * @return the sBirthAddrMgtNo
	 */
	public String getsBirthAddrMgtNo() {
		return sBirthAddrMgtNo;
	}

	/**
	 * @param sBirthAddrMgtNo the sBirthAddrMgtNo to set
	 */
	public void setsBirthAddrMgtNo(String sBirthAddrMgtNo) {
		this.sBirthAddrMgtNo = sBirthAddrMgtNo;
	}

	/**
	 * @return the sBirthStdAddrFlag
	 */
	public String getsBirthStdAddrFlag() {
		return sBirthStdAddrFlag;
	}

	/**
	 * @param sBirthStdAddrFlag the sBirthStdAddrFlag to set
	 */
	public void setsBirthStdAddrFlag(String sBirthStdAddrFlag) {
		this.sBirthStdAddrFlag = sBirthStdAddrFlag;
	}
	
	
}
