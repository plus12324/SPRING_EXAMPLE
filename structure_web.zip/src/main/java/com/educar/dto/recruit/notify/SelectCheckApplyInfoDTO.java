/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "selectCheckApplyInfoDTO")
public class SelectCheckApplyInfoDTO {
	/**	ä���ȣ             	**/	
	private String	sHireNo;
	
	/**	�ѱ۸�	**/	
	private String	sKorName;
	
	/**	Email	**/	
	private String	sEmail;
	
	/**	��������й�ȣ	**/	
	private String	sPassword;

	/**	������ȣ            **/	
	public String	nApplyNo;
	
	/**	�̷¼�����Ϸ�           **/	
	public String	sResumeConfirmYN;
	
	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sResumeConfirmYN
	 */
	public String getsResumeConfirmYN() {
		return sResumeConfirmYN;
	}

	/**
	 * @param sResumeConfirmYN the sResumeConfirmYN to set
	 */
	public void setsResumeConfirmYN(String sResumeConfirmYN) {
		this.sResumeConfirmYN = sResumeConfirmYN;
	}

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/** 
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the sKorName
	 */
	public String getsKorName() {
		return sKorName;
	}

	/**
	 * @param sKorName the sKorName to set
	 */
	public void setsKorName(String sKorName) {
		this.sKorName = sKorName;
	}

	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}

	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}

	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}

	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	
	

}
