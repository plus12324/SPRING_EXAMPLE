/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import com.educar.dto.recruit.notify.ApplyStep1Ofhrmaa08DocDTO;
import com.educar.dto.recruit.notify.ApplyStep1Ofhrmaa03DocDTO;
import com.educar.common.vo.RecruitInfoVO;
 

/**
 * �Ի����� �� ���� step1 DTO(setApplyStep1, updateApplySpte1 �� DTO)
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep1DTO")
public class ApplyStep1DTO {

	/**BaseDoc �⺻����**/ 
	private RecruitInfoVO BaseDoc;
	
	/**hrmaa03Doc **/ 		
	private ApplyStep1Ofhrmaa03DocDTO HRMAA03;
	
	/** temp�� ����� file ID **/
	private String fileId;
	
	/** hrmaa08Doc **/
	@XmlElementWrapper(name = "hrmaa08DocList")
	private List<ApplyStep1Ofhrmaa08DocDTO> HRMAA08;

	/**
	 * @return the hRMAA03
	 */
	public ApplyStep1Ofhrmaa03DocDTO getHRMAA03() {
		return HRMAA03;
	}

	/**
	 * @param hRMAA03 the hRMAA03 to set
	 */
	public void setHRMAA03(ApplyStep1Ofhrmaa03DocDTO hRMAA03) {
		HRMAA03 = hRMAA03;
	}

	/**
	 * @return the hRMAA08
	 */
	public List<ApplyStep1Ofhrmaa08DocDTO> getHRMAA08() {
		return HRMAA08;
	}

	/**
	 * @param hRMAA08 the hRMAA08 to set
	 */
	public void setHRMAA08(List<ApplyStep1Ofhrmaa08DocDTO> hRMAA08) {
		HRMAA08 = hRMAA08;
	}

	/**
	 * @return the baseDoc
	 */
	public RecruitInfoVO getBaseDoc() {
		return BaseDoc;
	}

	/**
	 * @param baseDoc the baseDoc to set
	 */
	public void setBaseDoc(RecruitInfoVO baseDoc) {
		BaseDoc = baseDoc;
	}

	/**
	 * @return the fileId
	 */
	public String getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}







	
	

}
