/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author �Ž¿�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "applyStep2DTO")
public class ApplyStep2DTO {
	
	/**	ä���ȣ             		**/	
	private String sHireNo;
	
	/**	������ȣ             		**/	
	private String nApplyNo;
	
    /**	�з��ڵ�             	
    01 �ʵ��б�
    02 ���б�
    03 �����б�
    04 ��������
    05 ���б�
    06 ���п�(����)
    07 ���п�(����)
    08 ���п�(�ڻ�)	**/	
	private String sEduCode;
	
	/**	�б�����   **/	
	private String nSchoolSeq;
	
	/**	�б���  **/	
	private String sSchoolName;
	
	/**	������   **/	
	private String sSchoolFmdt;
	
	/**	������  **/	
	private String sSchoolTodt;
	
	/**	������  **/	
	private String sMajorName;
	
	/**	�������ڵ�  ������**/	
	private String sMajorCode;
	
	/**	�������ڵ�   ������**/	
	private String sSubMajorCode;
	
    /**	�־߱���             	
    1 �����ְ�
    2 �����߰�
    3 �б��ְ�
    4 �б��߰�
    5 �ְ�
    6 �߰�(2��)
    7 �ؿܴ���	**/	
	private String sStudyType;
	
    /**	��������             	
    1 ����(����)
    2 ����
    3 ����
    4 ����
    5 ��������
    9 ��Ÿ	**/	
	private String sGraduateType;
	
	/**	���Կ���   **/	
	private String sSpecialAdmissYN;
	
	/**	��������  **/	
	private String nBasePoint;
	
	/**	�������  **/	
	private String nAvgPoint;
	
	/**	��ŸȰ��  **/	
	private String sEtcAtivity;
	
	/**	�����з¿���	Y **/	
	private String sLastSchool;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}

	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}

	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}

	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}

	/**
	 * @return the sEduCode
	 */
	public String getsEduCode() {
		return sEduCode;
	}

	/**
	 * @param sEduCode the sEduCode to set
	 */
	public void setsEduCode(String sEduCode) {
		this.sEduCode = sEduCode;
	}

	/**
	 * @return the nSchoolSeq
	 */
	public String getnSchoolSeq() {
		return nSchoolSeq;
	}

	/**
	 * @param nSchoolSeq the nSchoolSeq to set
	 */
	public void setnSchoolSeq(String nSchoolSeq) {
		this.nSchoolSeq = nSchoolSeq;
	}

	/**
	 * @return the sSchoolName
	 */
	public String getsSchoolName() {
		return sSchoolName;
	}

	/**
	 * @param sSchoolName the sSchoolName to set
	 */
	public void setsSchoolName(String sSchoolName) {
		this.sSchoolName = sSchoolName;
	}

	/**
	 * @return the sSchoolFmdt
	 */
	public String getsSchoolFmdt() {
		return sSchoolFmdt;
	}

	/**
	 * @param sSchoolFmdt the sSchoolFmdt to set
	 */
	public void setsSchoolFmdt(String sSchoolFmdt) {
		this.sSchoolFmdt = sSchoolFmdt;
	}

	/**
	 * @return the sSchoolTodt
	 */
	public String getsSchoolTodt() {
		return sSchoolTodt;
	}

	/**
	 * @param sSchoolTodt the sSchoolTodt to set
	 */
	public void setsSchoolTodt(String sSchoolTodt) {
		this.sSchoolTodt = sSchoolTodt;
	}

	/**
	 * @return the sMajorName
	 */
	public String getsMajorName() {
		return sMajorName;
	}

	/**
	 * @param sMajorName the sMajorName to set
	 */
	public void setsMajorName(String sMajorName) {
		this.sMajorName = sMajorName;
	}

	/**
	 * @return the sMajorCode
	 */
	public String getsMajorCode() {
		return sMajorCode;
	}

	/**
	 * @param sMajorCode the sMajorCode to set
	 */
	public void setsMajorCode(String sMajorCode) {
		this.sMajorCode = sMajorCode;
	}

	/**
	 * @return the sSubMajorCode
	 */
	public String getsSubMajorCode() {
		return sSubMajorCode;
	}

	/**
	 * @param sSubMajorCode the sSubMajorCode to set
	 */
	public void setsSubMajorCode(String sSubMajorCode) {
		this.sSubMajorCode = sSubMajorCode;
	}

	/**
	 * @return the sStudyType
	 */
	public String getsStudyType() {
		return sStudyType;
	}

	/**
	 * @param sStudyType the sStudyType to set
	 */
	public void setsStudyType(String sStudyType) {
		this.sStudyType = sStudyType;
	}

	/**
	 * @return the sGraduateType
	 */
	public String getsGraduateType() {
		return sGraduateType;
	}

	/**
	 * @param sGraduateType the sGraduateType to set
	 */
	public void setsGraduateType(String sGraduateType) {
		this.sGraduateType = sGraduateType;
	}

	/**
	 * @return the sSpecialAdmissYN
	 */
	public String getsSpecialAdmissYN() {
		return sSpecialAdmissYN;
	}

	/**
	 * @param sSpecialAdmissYN the sSpecialAdmissYN to set
	 */
	public void setsSpecialAdmissYN(String sSpecialAdmissYN) {
		this.sSpecialAdmissYN = sSpecialAdmissYN;
	}

	/**
	 * @return the nBasePoint
	 */
	public String getnBasePoint() {
		return nBasePoint;
	}

	/**
	 * @param nBasePoint the nBasePoint to set
	 */
	public void setnBasePoint(String nBasePoint) {
		this.nBasePoint = nBasePoint;
	}

	/**
	 * @return the nAvgPoint
	 */
	public String getnAvgPoint() {
		return nAvgPoint;
	}

	/**
	 * @param nAvgPoint the nAvgPoint to set
	 */
	public void setnAvgPoint(String nAvgPoint) {
		this.nAvgPoint = nAvgPoint;
	}

	/**
	 * @return the sEtcAtivity
	 */
	public String getsEtcAtivity() {
		return sEtcAtivity;
	}

	/**
	 * @param sEtcAtivity the sEtcAtivity to set
	 */
	public void setsEtcAtivity(String sEtcAtivity) {
		this.sEtcAtivity = sEtcAtivity;
	}

	/**
	 * @return the sLastSchool
	 */
	public String getsLastSchool() {
		return sLastSchool;
	}

	/**
	 * @param sLastSchool the sLastSchool to set
	 */
	public void setsLastSchool(String sLastSchool) {
		this.sLastSchool = sLastSchool;
	}


	
	

}
