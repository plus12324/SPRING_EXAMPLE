/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "jobMasterDTO")
public class JobMasterDTO {
	/** 	ä���ȣ             	 **/	
	private String	sHireNo;
	/** 	ä���   	 **/	
	private String	sHireName;
	/** 	������ȣ             	 **/	
	private String	sDocNo;
	/** 	����������           	 **/	
	private String	sRecruitFmdt;
	/** 	����������           	 **/	
	private String	sRecruitTodt;	
	/** 	��������ڵ�	 **/	
	private String	sSelWay;
	/** 	��������ڵ��	 **/	
	private String	sSelWayNm;
	/** 	����������         	 **/	
	private String	sSelWayNote;
	/** 	���⼭���ڵ�1     **/	
	private String	sSubmitDoc1;
	/** 	���⼭���ڵ�2    **/	
	private String	sSubmitDoc2;
	/** 	���⼭���ڵ�3   **/	
	private String	sSubmitDoc3;
	/** 	���⼭���ڵ�4    **/	
	private String	sSubmitDoc4;
	/** 	���⼭���ڵ�5    **/	
	private String	sSubmitDoc5;
	/** 	���⼭���ڵ�6	 **/	
	private String	sSubmitDoc6;
	/** 	���⼭���ڵ��1   **/	
	private String	sSubmitDoc1Nm;
	/** 	���⼭���ڵ��2	 **/	
	private String	sSubmitDoc2Nm;
	/** 	���⼭���ڵ��3	 **/	
	private String	sSubmitDoc3Nm;
	/** 	���⼭���ڵ��4	 **/	
	private String	sSubmitDoc4Nm;
	/** 	���⼭���ڵ��5	 **/	
	private String	sSubmitDoc5Nm;
	/** 	���⼭���ڵ��6	 **/	
	private String	sSubmitDoc6Nm;
	/** 	���⼭�����         	 **/	
	private String	sSubmitDocNote;
	/** 	��������ڵ�            	 **/	
	private String	sApplyWay;
	/** 	��������ڵ��	 **/	
	private String	sApplyWayNm;
	/** 	����ó               	 **/	
	private String	sApplySite;
	/** 	��Ÿ����             	 **/	
	private String	sEtcAsk;
	/** 	��Ÿ����2             	 **/	
	private String	sEtcAsk2;
	/** 	��Ÿ����3            	 **/	
	private String	sEtcAsk3;
	/** 	�������             	 **/	
	private String	sCommonItem;
	/** 	����������             	 **/	
	private String	sWebNoticeYN;
	/** 	�����ȣ             	 **/	
	private String	sApproveNo;
	/** 	�۾��ڻ��           	 **/	
	private String	sUserID;
	/** 	�۾���               	 **/	
	private String	sInputDate;
	/** 	�۾��ð�             	 **/	
	private String	sInputTime;
	/** 	ä�뱸���ڵ�	 **/	
	private String	sHireGroup;
	/** 	ä�뱸���ڵ��	 **/	
	private String	sHireGroupNm;
	/** 	�ڰݰ��뱸���ڵ�	 **/	
	private String	sQualCommType;
	/** 	�ڰݰ��뱸���ڵ��	 **/	
	private String	sQualCommTypeNm;
	/** 	��������        	 **/	
	private String	sSelSchedule;
	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}
	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}
	/**
	 * @return the sHireName
	 */
	public String getsHireName() {
		return sHireName;
	}
	/**
	 * @param sHireName the sHireName to set
	 */
	public void setsHireName(String sHireName) {
		this.sHireName = sHireName;
	}
	/**
	 * @return the sDocNo
	 */
	public String getsDocNo() {
		return sDocNo;
	}
	/**
	 * @param sDocNo the sDocNo to set
	 */
	public void setsDocNo(String sDocNo) {
		this.sDocNo = sDocNo;
	}
	/**
	 * @return the sRecruitFmdt
	 */
	public String getsRecruitFmdt() {
		return sRecruitFmdt;
	}
	/**
	 * @param sRecruitFmdt the sRecruitFmdt to set
	 */
	public void setsRecruitFmdt(String sRecruitFmdt) {
		this.sRecruitFmdt = sRecruitFmdt;
	}
	/**
	 * @return the sRecruitTodt
	 */
	public String getsRecruitTodt() {
		return sRecruitTodt;
	}
	/**
	 * @param sRecruitTodt the sRecruitTodt to set
	 */
	public void setsRecruitTodt(String sRecruitTodt) {
		this.sRecruitTodt = sRecruitTodt;
	}
	/**
	 * @return the sSelWay
	 */
	public String getsSelWay() {
		return sSelWay;
	}
	/**
	 * @param sSelWay the sSelWay to set
	 */
	public void setsSelWay(String sSelWay) {
		this.sSelWay = sSelWay;
	}
	/**
	 * @return the sSelWayNm
	 */
	public String getsSelWayNm() {
		return sSelWayNm;
	}
	/**
	 * @param sSelWayNm the sSelWayNm to set
	 */
	public void setsSelWayNm(String sSelWayNm) {
		this.sSelWayNm = sSelWayNm;
	}
	/**
	 * @return the sSelWayNote
	 */
	public String getsSelWayNote() {
		return sSelWayNote;
	}
	/**
	 * @param sSelWayNote the sSelWayNote to set
	 */
	public void setsSelWayNote(String sSelWayNote) {
		this.sSelWayNote = sSelWayNote;
	}
	/**
	 * @return the sSubmitDoc1
	 */
	public String getsSubmitDoc1() {
		return sSubmitDoc1;
	}
	/**
	 * @param sSubmitDoc1 the sSubmitDoc1 to set
	 */
	public void setsSubmitDoc1(String sSubmitDoc1) {
		this.sSubmitDoc1 = sSubmitDoc1;
	}
	/**
	 * @return the sSubmitDoc2
	 */
	public String getsSubmitDoc2() {
		return sSubmitDoc2;
	}
	/**
	 * @param sSubmitDoc2 the sSubmitDoc2 to set
	 */
	public void setsSubmitDoc2(String sSubmitDoc2) {
		this.sSubmitDoc2 = sSubmitDoc2;
	}
	/**
	 * @return the sSubmitDoc3
	 */
	public String getsSubmitDoc3() {
		return sSubmitDoc3;
	}
	/**
	 * @param sSubmitDoc3 the sSubmitDoc3 to set
	 */
	public void setsSubmitDoc3(String sSubmitDoc3) {
		this.sSubmitDoc3 = sSubmitDoc3;
	}
	/**
	 * @return the sSubmitDoc4
	 */
	public String getsSubmitDoc4() {
		return sSubmitDoc4;
	}
	/**
	 * @param sSubmitDoc4 the sSubmitDoc4 to set
	 */
	public void setsSubmitDoc4(String sSubmitDoc4) {
		this.sSubmitDoc4 = sSubmitDoc4;
	}
	/**
	 * @return the sSubmitDoc5
	 */
	public String getsSubmitDoc5() {
		return sSubmitDoc5;
	}
	/**
	 * @param sSubmitDoc5 the sSubmitDoc5 to set
	 */
	public void setsSubmitDoc5(String sSubmitDoc5) {
		this.sSubmitDoc5 = sSubmitDoc5;
	}
	/**
	 * @return the sSubmitDoc6
	 */
	public String getsSubmitDoc6() {
		return sSubmitDoc6;
	}
	/**
	 * @param sSubmitDoc6 the sSubmitDoc6 to set
	 */
	public void setsSubmitDoc6(String sSubmitDoc6) {
		this.sSubmitDoc6 = sSubmitDoc6;
	}
	/**
	 * @return the sSubmitDoc1Nm
	 */
	public String getsSubmitDoc1Nm() {
		return sSubmitDoc1Nm;
	}
	/**
	 * @param sSubmitDoc1Nm the sSubmitDoc1Nm to set
	 */
	public void setsSubmitDoc1Nm(String sSubmitDoc1Nm) {
		this.sSubmitDoc1Nm = sSubmitDoc1Nm;
	}
	/**
	 * @return the sSubmitDoc2Nm
	 */
	public String getsSubmitDoc2Nm() {
		return sSubmitDoc2Nm;
	}
	/**
	 * @param sSubmitDoc2Nm the sSubmitDoc2Nm to set
	 */
	public void setsSubmitDoc2Nm(String sSubmitDoc2Nm) {
		this.sSubmitDoc2Nm = sSubmitDoc2Nm;
	}
	/**
	 * @return the sSubmitDoc3Nm
	 */
	public String getsSubmitDoc3Nm() {
		return sSubmitDoc3Nm;
	}
	/**
	 * @param sSubmitDoc3Nm the sSubmitDoc3Nm to set
	 */
	public void setsSubmitDoc3Nm(String sSubmitDoc3Nm) {
		this.sSubmitDoc3Nm = sSubmitDoc3Nm;
	}
	/**
	 * @return the sSubmitDoc4Nm
	 */
	public String getsSubmitDoc4Nm() {
		return sSubmitDoc4Nm;
	}
	/**
	 * @param sSubmitDoc4Nm the sSubmitDoc4Nm to set
	 */
	public void setsSubmitDoc4Nm(String sSubmitDoc4Nm) {
		this.sSubmitDoc4Nm = sSubmitDoc4Nm;
	}
	/**
	 * @return the sSubmitDoc5Nm
	 */
	public String getsSubmitDoc5Nm() {
		return sSubmitDoc5Nm;
	}
	/**
	 * @param sSubmitDoc5Nm the sSubmitDoc5Nm to set
	 */
	public void setsSubmitDoc5Nm(String sSubmitDoc5Nm) {
		this.sSubmitDoc5Nm = sSubmitDoc5Nm;
	}
	/**
	 * @return the sSubmitDoc6Nm
	 */
	public String getsSubmitDoc6Nm() {
		return sSubmitDoc6Nm;
	}
	/**
	 * @param sSubmitDoc6Nm the sSubmitDoc6Nm to set
	 */
	public void setsSubmitDoc6Nm(String sSubmitDoc6Nm) {
		this.sSubmitDoc6Nm = sSubmitDoc6Nm;
	}
	/**
	 * @return the sSubmitDocNote
	 */
	public String getsSubmitDocNote() {
		return sSubmitDocNote;
	}
	/**
	 * @param sSubmitDocNote the sSubmitDocNote to set
	 */
	public void setsSubmitDocNote(String sSubmitDocNote) {
		this.sSubmitDocNote = sSubmitDocNote;
	}
	/**
	 * @return the sApplyWay
	 */
	public String getsApplyWay() {
		return sApplyWay;
	}
	/**
	 * @param sApplyWay the sApplyWay to set
	 */
	public void setsApplyWay(String sApplyWay) {
		this.sApplyWay = sApplyWay;
	}
	/**
	 * @return the sApplyWayNm
	 */
	public String getsApplyWayNm() {
		return sApplyWayNm;
	}
	/**
	 * @param sApplyWayNm the sApplyWayNm to set
	 */
	public void setsApplyWayNm(String sApplyWayNm) {
		this.sApplyWayNm = sApplyWayNm;
	}
	/**
	 * @return the sApplySite
	 */
	public String getsApplySite() {
		return sApplySite;
	}
	/**
	 * @param sApplySite the sApplySite to set
	 */
	public void setsApplySite(String sApplySite) {
		this.sApplySite = sApplySite;
	}
	/**
	 * @return the sEtcAsk
	 */
	public String getsEtcAsk() {
		return sEtcAsk;
	}
	/**
	 * @param sEtcAsk the sEtcAsk to set
	 */
	public void setsEtcAsk(String sEtcAsk) {
		this.sEtcAsk = sEtcAsk;
	}
	/**
	 * @return the sEtcAsk2
	 */
	public String getsEtcAsk2() {
		return sEtcAsk2;
	}
	/**
	 * @param sEtcAsk2 the sEtcAsk2 to set
	 */
	public void setsEtcAsk2(String sEtcAsk2) {
		this.sEtcAsk2 = sEtcAsk2;
	}
	/**
	 * @return the sEtcAsk3
	 */
	public String getsEtcAsk3() {
		return sEtcAsk3;
	}
	/**
	 * @param sEtcAsk3 the sEtcAsk3 to set
	 */
	public void setsEtcAsk3(String sEtcAsk3) {
		this.sEtcAsk3 = sEtcAsk3;
	}
	/**
	 * @return the sCommonItem
	 */
	public String getsCommonItem() {
		return sCommonItem;
	}
	/**
	 * @param sCommonItem the sCommonItem to set
	 */
	public void setsCommonItem(String sCommonItem) {
		this.sCommonItem = sCommonItem;
	}
	/**
	 * @return the sWebNoticeYN
	 */
	public String getsWebNoticeYN() {
		return sWebNoticeYN;
	}
	/**
	 * @param sWebNoticeYN the sWebNoticeYN to set
	 */
	public void setsWebNoticeYN(String sWebNoticeYN) {
		this.sWebNoticeYN = sWebNoticeYN;
	}
	/**
	 * @return the sApproveNo
	 */
	public String getsApproveNo() {
		return sApproveNo;
	}
	/**
	 * @param sApproveNo the sApproveNo to set
	 */
	public void setsApproveNo(String sApproveNo) {
		this.sApproveNo = sApproveNo;
	}
	/**
	 * @return the sUserID
	 */
	public String getsUserID() {
		return sUserID;
	}
	/**
	 * @param sUserID the sUserID to set
	 */
	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}
	/**
	 * @return the sInputDate
	 */
	public String getsInputDate() {
		return sInputDate;
	}
	/**
	 * @param sInputDate the sInputDate to set
	 */
	public void setsInputDate(String sInputDate) {
		this.sInputDate = sInputDate;
	}
	/**
	 * @return the sInputTime
	 */
	public String getsInputTime() {
		return sInputTime;
	}
	/**
	 * @param sInputTime the sInputTime to set
	 */
	public void setsInputTime(String sInputTime) {
		this.sInputTime = sInputTime;
	}
	/**
	 * @return the sHireGroup
	 */
	public String getsHireGroup() {
		return sHireGroup;
	}
	/**
	 * @param sHireGroup the sHireGroup to set
	 */
	public void setsHireGroup(String sHireGroup) {
		this.sHireGroup = sHireGroup;
	}
	/**
	 * @return the sHireGroupNm
	 */
	public String getsHireGroupNm() {
		return sHireGroupNm;
	}
	/**
	 * @param sHireGroupNm the sHireGroupNm to set
	 */
	public void setsHireGroupNm(String sHireGroupNm) {
		this.sHireGroupNm = sHireGroupNm;
	}
	/**
	 * @return the sQualCommType
	 */
	public String getsQualCommType() {
		return sQualCommType;
	}
	/**
	 * @param sQualCommType the sQualCommType to set
	 */
	public void setsQualCommType(String sQualCommType) {
		this.sQualCommType = sQualCommType;
	}
	/**
	 * @return the sQualCommTypeNm
	 */
	public String getsQualCommTypeNm() {
		return sQualCommTypeNm;
	}
	/**
	 * @param sQualCommTypeNm the sQualCommTypeNm to set
	 */
	public void setsQualCommTypeNm(String sQualCommTypeNm) {
		this.sQualCommTypeNm = sQualCommTypeNm;
	}
	/**
	 * @return the sSelSchedule
	 */
	public String getsSelSchedule() {
		return sSelSchedule;
	}
	/**
	 * @param sSelSchedule the sSelSchedule to set
	 */
	public void setsSelSchedule(String sSelSchedule) {
		this.sSelSchedule = sSelSchedule;
	}
	
	
	
}
