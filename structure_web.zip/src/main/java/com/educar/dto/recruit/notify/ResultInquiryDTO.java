/**
 * Copyright (c) 2012, All rights reserved.
 * TSIS PROPRIETARY/CONFIDENTIAL.  Use is subject to project license terms.
 * All codes are licensed to The-K
 */
package com.educar.dto.recruit.notify;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ���ѳ�
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "resultInquiryDTO")
public class ResultInquiryDTO implements Serializable{
	/**
	 * default
	 * ���ǿ� ����Ǵ� ��ü�� Serializable�� �����ؾ��Ѵ�.
	 */
	private static final long serialVersionUID = 1L;
	/**  	ä���ȣ   **/  
	private String 	sHireNo;
	/**  	�ѱ۸�	  **/  
	private String 	sKorName;
	/**  	Email	 **/  
	private String 	sEmail;
	/**  	��й�ȣ	  **/  
	private String 	sPassword;
	/**  	�����ڵ�     **/  
	private String 	sSelCode;
	/**  	�����ڵ��	  **/  
	private String sSelName	;
	/**  	�հݿ���           	  **/  
	private String 	sPassYN;
	/**  	�̷¼�����Ϸ���	  **/  
	private String 	sResumeConfirmDate;
	/** ������ȣ **/
	private String nApplyNo;
	/** ä�뱸�и� **/
	private String sHireName;

	/**
	 * @return the sHireNo
	 */
	public String getsHireNo() {
		return sHireNo;
	}
	/**
	 * @param sHireNo the sHireNo to set
	 */
	public void setsHireNo(String sHireNo) {
		this.sHireNo = sHireNo;
	}
	/**
	 * @return the sKorName
	 */
	public String getsKorName() {
		return sKorName;
	}
	/**
	 * @param sKorName the sKorName to set
	 */
	public void setsKorName(String sKorName) {
		this.sKorName = sKorName;
	}
	/**
	 * @return the sEmail
	 */
	public String getsEmail() {
		return sEmail;
	}
	/**
	 * @param sEmail the sEmail to set
	 */
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	/**
	 * @return the sPassword
	 */
	public String getsPassword() {
		return sPassword;
	}
	/**
	 * @param sPassword the sPassword to set
	 */
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	/**
	 * @return the sSelCode
	 */
	public String getsSelCode() {
		return sSelCode;
	}
	/**
	 * @param sSelCode the sSelCode to set
	 */
	public void setsSelCode(String sSelCode) {
		this.sSelCode = sSelCode;
	}
	/**
	 * @return the sSelName
	 */
	public String getsSelName() {
		return sSelName;
	}
	/**
	 * @param sSelName the sSelName to set
	 */
	public void setsSelName(String sSelName) {
		this.sSelName = sSelName;
	}
	/**
	 * @return the sPassYN
	 */
	public String getsPassYN() {
		return sPassYN;
	}
	/**
	 * @param sPassYN the sPassYN to set
	 */
	public void setsPassYN(String sPassYN) {
		this.sPassYN = sPassYN;
	}
	/**
	 * @return the sResumeConfirmDate
	 */
	public String getsResumeConfirmDate() {
		return sResumeConfirmDate;
	}
	/**
	 * @param sResumeConfirmDate the sResumeConfirmDate to set
	 */
	public void setsResumeConfirmDate(String sResumeConfirmDate) {
		this.sResumeConfirmDate = sResumeConfirmDate;
	}
	/**
	 * @return the nApplyNo
	 */
	public String getnApplyNo() {
		return nApplyNo;
	}
	/**
	 * @param nApplyNo the nApplyNo to set
	 */
	public void setnApplyNo(String nApplyNo) {
		this.nApplyNo = nApplyNo;
	}
	/**
	 * @return the sHireName
	 */
	public String getsHireName() {
		return sHireName;
	}
	/**
	 * @param sHireName the sHireName to set
	 */
	public void setsHireName(String sHireName) {
		this.sHireName = sHireName;
	}


}
