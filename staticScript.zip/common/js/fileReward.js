/**
 * \ud30c\uc77c \uc5c5\ub85c\ub4dc \ubcc0\uc218 JS
 */
var FileUploadParam = {
	// \uc720\ud615
	type : {
		image    : 'image',
		document : 'document'
	},
	// \ubbf8\ub9ac\ubcf4\uae30 \uac1d\uccb4 \uae30\ubcf8 \uac12
	defaultValue : {
		image    : '/static/web/images/content/bg_mgphnoimg.gif',
		document : '/static/web/images/content/bg_mgphnoimg.gif'
	},
	// \ud5c8\uc6a9\ub418\ub294 \ud655\uc7a5\uc790 \uc815\uaddc\uc2dd
	allowedExtensionRegex : {
		// \uc784\uc2dc jpg\ub9cc \uac00\ub2a5 \ud558\uac8c \uc124\uc815
		// image    : /^(jpg|gif|png|bmp)$/
		image	: /^(jpg|pdf|tif|jpeg|tiff)$/,
		document : /^(jpg|pdf|tif|jpeg|tiff)$/
	},
	// \ud5c8\uc6a9\ub418\uc9c0 \uc54a\ub294 \ud655\uc7a5\uc790 \uc815\uaddc\uc2dd
	disallowedExtentionRegex : {
		document : /^(exe|sh)$/
	},
	// \uc815\uaddc\uc2dd\uc5d0\uc11c \ud1b5\uacfc\ub418\uc9c0 \ubabb\ud588\uc744 \uacbd\uc6b0 \ubcf4\uc5ec\uc904 \ubb38\uad6c
	disallowedMessage : {
		// \uc784\uc2dc jpg\ub9cc \uac00\ub2a5 \ud558\uac8c \uc124\uc815
		//image    : '\uc774\ubbf8\uc9c0 \ud30c\uc77c\ub9cc \uc5c5\ub85c\ub4dc \uac00\ub2a5\ud569\ub2c8\ub2e4.',
		image    : 'jpg,pdf,tif,jpeg,tiff \ud30c\uc77c\ub9cc \uc5c5\ub85c\ub4dc \uac00\ub2a5\ud569\ub2c8\ub2e4.',
		document : 'jpg,pdf,tif,jpeg,tiff \ud30c\uc77c\ub9cc \uc5c5\ub85c\ub4dc \uac00\ub2a5\ud569\ub2c8\ub2e4.'
	}
};

/**
 * \ud30c\uc77c \uc5c5\ub85c\ub4dc \ud568\uc218 JS
 */
var FileUploadFunc = {
	/**
	 * \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \ucc3e\uc544\ubcf4\uae30 \uc2e4\ud589\ud558\uc600\uc744 \ub54c \ud30c\uc77c \ud655\uc7a5\uc790 \uac80\uc99d\uc744 \uc218\ud589\ud55c\ub2e4.
	 * @param uploadObj \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4
	 * @param fileType \ud30c\uc77c \uc720\ud615
	 */
	onInputValueChange : function(uploadObj, fileType) {
	
		// uploadObj \uac1d\uccb4 \uc720\ud6a8\uc131 \uac80\uc0ac
		if (uploadObj === null || typeof uploadObj != 'object' || !(typeof uploadObj.getPluginName == 'function' || typeof uploadObj.getPluginName == 'object')) {
			return false;
		}

		// fileType \uae30\ubcf8 \uac12 \uc124\uc815
		fileType = fileType || FileUploadParam.type.image;

		// \ud30c\uc77c \ud655\uc7a5\uc790 \uc720\ud6a8\uc131 \uac80\uc0ac
		FileUploadParam.fileName = uploadObj.getValue();
		FileUploadParam.fileNameSuffix = FileUploadParam.fileName.substring(FileUploadParam.fileName.lastIndexOf('.') + 1);
		if ((FileUploadParam.allowedExtensionRegex[fileType] && !FileUploadParam.allowedExtensionRegex[fileType].test(FileUploadParam.fileNameSuffix.toLowerCase()))
				|| (FileUploadParam.disallowedExtentionRegex[fileType] && FileUploadParam.disallowedExtentionRegex[fileType].test(FileUploadParam.fileNameSuffix.toLowerCase()))) {
			alert(FileUploadParam.disallowedMessage[fileType]);
			this.reset(uploadObj, fileType); // \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4 \uac12\uc744 \ucd08\uae30\ud654\uc2dc\ucf1c\uc900\ub2e4.
			return false;
		}

		// \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8\uc5d0 \uc11c\ubc84\ub85c \ub118\uaca8\uc904 \ucd94\uac00\uc815\ubcf4\ub97c \uc124\uc815\ud55c\ub2e4.
		if (uploadObj.getUserData('componentId') !== true) {
			uploadObj.setUserData('componentId', true);
			uploadObj.addParam('componentId', uploadObj.getID());
		}
		uploadObj.setUserData('fileType', fileType);
		uploadObj.addParam('fileType', fileType);
		uploadObj.submit();
		return false;
	},

	/**
	 * \ud30c\uc77c\uc744 \uc784\uc2dc \ub4f1\ub85d\ud55c \ud6c4 \ucd5c\uc885 \uc800\uc7a5\ud560 \ub54c \uc11c\ubc84\ub85c \ub118\uaca8\uc904 fileId \uc815\ubcf4\ub97c \uc124\uc815\ud55c\ub2e4.
	 * @param uploadObj : \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4
	 * @param retXml : \ud30c\uc77c \uc5c5\ub85c\ub4dc \ud6c4 \uc6f9\uc2a4\ud018\uc5b4\uc5d0\uc11c \ubc18\ud658\ub418\ub294 \uacb0\uacfc XML
	 */
	ondone : function(uploadObj, retXml) {
		// \uc624\ub958\ub0b4\uc6a9 \uc720\ubb34 \uac80\uc99d
		var fileErrorMessage = WebSquare.xml.getValue(retXml, 'ret/fileErrorMessage');
		if (fileErrorMessage !== '') {
			alert(fileErrorMessage);
			this.reset(uploadObj, uploadObj.getUserData('fileType')); // \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4 \uac12\uc744 \ucd08\uae30\ud654\uc2dc\ucf1c\uc900\ub2e4.
			return false;
		}
		// \uc774\ubbf8\uc9c0 \ud30c\uc77c \uc5ec\ubd80 \uac80\uc99d
		if (uploadObj.getUserData('fileType') == FileUploadParam.type.image
				&& WebSquare.xml.getValue(retXml, 'ret/fileType') != FileUploadParam.type.image) {
			alert(FileUploadParam.disallowedMessage.image);
			this.reset(uploadObj); // \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4 \uac12\uc744 \ucd08\uae30\ud654\uc2dc\ucf1c\uc900\ub2e4.
			return false;
		}

		// \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8\uc5d0 \uc11c\ubc84\ub85c \ub118\uaca8\uc904 fileId \uc124\uc815
		FileUploadParam.fileId = WebSquare.xml.getValue(retXml, '/ret/fileId');
		uploadObj.setUserData('fileId', FileUploadParam.fileId);

		// \uc774\ubbf8\uc9c0 \ud30c\uc77c\uc744 \ub4f1\ub85d\ud55c \ud6c4 \ubbf8\ub9ac\ubcf4\uae30 \uae30\ub2a5\uc744 \uc218\ud589\ud55c\ub2e4.
		if (typeof PageParam == 'object' && typeof PageParam.preview == 'object') {
			FileUploadParam.previewObj = PageParam.preview[uploadObj.getID()];
			if (FileUploadParam.previewObj && typeof FileUploadParam.previewObj == 'object' && typeof FileUploadParam.previewObj.setSrc == 'function') {
				FileUploadParam.previewObj.setSrc('/upload/preview.do?fileId=' + FileUploadParam.fileId);
			}
		}
		return true;
	},

	/**
	 * \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8\ub97c \ucd08\uae30\ud654\ud55c\ub2e4.
	 * @param uploadObj \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \uac1d\uccb4
	 * @param fileType \ud30c\uc77c \uc720\ud615
	 */
	reset : function(uploadObj, fileType) {
		// \ud30c\uc77c \ucef4\ud3ec\ub10c\ud2b8 \ucd08\uae30\ud654
		uploadObj.reset();
		// \ubbf8\ub9ac\ubcf4\uae30 \uac1d\uccb4\uac00 \uc788\uc744 \uacbd\uc6b0 \uac1d\uccb4 \uac12\uc744 \ucd08\uae30\ud654\uc2dc\ucf1c\uc900\ub2e4.
		if (typeof PageParam != 'object' || typeof PageParam.preview != 'object') {
			return false;
		}
		FileUploadParam.previewObj = PageParam.preview[uploadObj.getID()];
		if (FileUploadParam.previewObj && typeof FileUploadParam.previewObj == 'object') {
			switch (fileType) {
				case FileUploadParam.type.image :
					if (typeof FileUploadParam.previewObj.setSrc == 'function') {
						FileUploadParam.previewObj.setSrc(FileUploadParam.defaultValue.image);
					}
					break;
				case FileUploadParam.type.document :
					if (typeof FileUploadParam.previewObj.setValue == 'function') {
						FileUploadParam.previewObj.setValue(FileUploadParam.defaultValue.document);
					}
					break;
			}
		}
		return false;
	}
};
