/**
 * \ud558\uc704 \ud504\ub808\uc784 \ubc14\ub85c \uc811\uadfc \uc2dc \uc0c1\uc704 \uaecd\ub370\uae30 \ud654\uba74 \ud3ec\ud568\ud558\ub3c4\ub85d URL \ubc14\ub85c\ubcc0\uacbd
 */
// check parent window
if (window.parent && window.parent == window.self) {
	var replaceUrl = location.protocol + '//' + location.host + '/web/index.educar';
	replaceUrl+= '?openLayerUrl=' + encodeURIComponent(window.location.href);
	window.top.location.replace(replaceUrl);
}
