/**
 *  \ub9ac\uc544\uc6a9 \uacf5\ud1b5 \ubcc0\uc218 \ubaa8\uc74c
 */
var riaCommParam = {
	/** \ubcf4\uc885 \ucf54\ub4dc **/
	sInsType : {
		car : { code : '0130', name : '\uc5d0\ub4c0\uce74 \uac1c\uc778\uc6a9' },		// \uc2b9\uc6a9\ucc28
		van : { code : '0212', name : '\uc5c5\ubb34\uc6a9' },		// \uc2b9\ud569\ucc28(\uc5c5\ubb34\uc6a9)
		truck : { code : '0230', name : '\uc5d0\ub4c0\uce74 \uc5c5\ubb34\uc6a9' }		// \ud654\ubb3c\ucc28
	},
	/** \uc678\uc81c\ucc28 \ube0c\ub79c\ub4dc \ucf54\ub4dc **/
	foreignCar : {
		'AUDI'			: '15',
		'FORD'			: '8',
		'LAND ROVER'	: '12',
		'PORSCHE'		: '19',
		'\uc528\ud2b8\ub85c\uc5e5'		: '14',
		'BENZ'			: '17',
		'GM'			: '9',
		'MAZDA'			: '25',
		'SAAB'			: '20',
		'FERRARI'		: '28',
		'BMW'			: '16',
		'HONDA'			: '23',
		'MITSUBISHI'	: '26',
		'TOYOTA'		: '27',
		'MASERATI'		: '29',
		'CHRYSLER'		: '7',
		'ISUZU'			: '24',
		'PEUGEOT'		: '13',
		'VOLKSWAGEN'	: '18',
		'NISSAN'		: '30',
		'FIAT'			: '22',
		'JAGUAR'		: '11',
		'PONTIAC'		: '10',
		'VOLVO'			: '21',
		'\uc2dc\ud2f0\uc564\ud2f0'		: '31',
		'\uc5d0\uc774\ub514\ubaa8\ud130\uc2a4'	: '32',
		'SUBARU'		: '33',
		'RENAULT'		: '34'
	},
	/** \uc0ac\uc6a9\uc6a9\ub3c4 \uae30\uac04\uacc4 \ucf54\ub4dc \ub9f5\ud551 **/
	usageCode : {
		'0130' : {
			'\ucd9c\ud1f4\uadfc \ubc0f \uac00\uc815\uc6a9' : '1',	// \ucd9c\ud1f4\uadfc \ubc0f \uac00\uc815\uc6a9
			'\uac1c\uc778\uc0ac\uc5c5 \ubc0f \uae30\ud0c0' : '2'	// \uac1c\uc778\uc0ac\uc5c5 \ubc0f \uae30\ud0c0
		},
		'0212' : {
			'\ucd9c\ud1f4\uadfc \ubc0f \uac00\uc815\uc6a9'		: '68',	// \ucd9c\ud1f4\uadfc \ubc0f \uac00\uc815\uc6a9
			'\uc77c\ubc18\uc5c5\ubb34\uc6a9'			: '81',	// \uc77c\ubc18\uc5c5\ubb34\uc6a9
			'\ud559\uad50\uc5c5\ubb34\uc6a9'			: '53',	// \ud559\uad50\uc5c5\ubb34\uc6a9
			'\ud654\ubb3c\ucc28\ub300\uc6a9'			: '61',	// \ud654\ubb3c\ucc28\ub300\uc6a9
			'\uc885\uad50\ub2e8\uccb4, \uc2e0\uc790 \uc218\uc1a1\uc6a9' : '64'	// \uc885\uad50\ub2e8\uccb4, \uc2e0\uc790 \uc218\uc1a1\uc6a9
		},
		'0230' : {
			'\ub18d/\ucd95/\uc218\uc0b0\ubb3c'		: '71',	// \ub18d/\ucd95/\uc218\uc0b0\ubb3c
			'\uac00\uc815\uc6a9\uc5f0\ub8cc\ubc30\ub2ec'	: '76',	// \uac00\uc815\uc6a9\uc5f0\ub8cc\ubc30\ub2ec
			'\uae30\ud0c0\uc18c\ube44\uc790\ubc30\ub2ec'	: '78',	// \uae30\ud0c0\uc18c\ube44\uc790\ubc30\ub2ec
			'\ud0dd\ubc30/\uc774\uc0bf\uc9d0\uc13c\ud130'	: '80',	// \ud0dd\ubc30/\uc774\uc0bf\uc9d0\uc13c\ud130
			'\uae30\ud0c0\uc6a9\ub3c4'			: '89'	// \uae30\ud0c0\uc6a9\ub3c4
		}
	},
	/** \ubb3c\uc801\uc0ac\uace0\ud560\uc99d\uae30\uc900\uae08\uc561 **/
	addPrice : {
		'50\ub9cc\uc6d0'	: '0301',	// 50\ub9cc\uc6d0
		'100\ub9cc\uc6d0'	: '0302',	// 100\ub9cc\uc6d0
		'150\ub9cc\uc6d0'	: '0303',	// 150\ub9cc\uc6d0
		'200\ub9cc\uc6d0'	: '0304'	// 200\ub9cc\uc6d0
	}
};

/**
 *  \ub9ac\uc544\uc6a9 \uacf5\ud1b5\ud568\uc218 \ubaa8\uc74c
 */
 var riaCommFunc = {
	/** \uc5f0\uc2dd \uad6c\ubd84 \uc870\ud68c **/
	getsYearType : function (sApplyFmdt, sYear, sCarRegDate) {
		//\uc5f0\uc2dd\uad6c\ubd84 \uccb4\ud06c (01: A,B \uac12\ud544\uc694, 02: \ud544\uc694x)
		var sYearType = '';
		var yearResult = this.validYearType(sApplyFmdt, sYear, sYearType);
		//yearResult 01\uc77c\uacbd\uc6b0 : \ucc28\ub7c9\ub144\uc2dd\uad6c\ubd84\uc5d0 'A' \ub610\ub294 'B' \ud544\uc218
		if (yearResult === '01'){
			sYearType = this.setDecideYearType(sApplyFmdt , sCarRegDate || '');
		//yearResult 02\uc77c\uacbd\uc6b0 : \ucc28\ub7c9\ub144\uc2dd\uc5d0 'A' \ub610\ub294 'B' \ub97c \uc785\ub825\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4
		} else if (yearResult == '02'){
			sYearType = '';
		}
		return sYearType;
	},
	/**
	 * sYearType \uc720\ud6a8\uc131\uccb4\ud06c
	 * @param applyFmdt \ubcf4\ud5d8\uc2dc\uae30
	 * @param sYear \ub144\uc2dd
	 * @param sYearType : \ub144\uc2dd\uad6c\ubd84
	 * @return result 01 : sYearType\ud544\uc218 (A or B \ud0c0\uc785), 02 : sYearType \uc5c6\uc74c (A, B \uc5c6\uc74c)
	 */
	validYearType : function(applyFmdt, sYear, sYearType){
		var result = '00';
		var yyyy   = applyFmdt.substring(0,4);
		var mmdd   = applyFmdt.substring(4);
		//\ubcf4\ud5d8\uc2dc\uae30\uc640 \ub144\uc2dd\uc758 \ub144\ub3c4\uac00 \uac19\uc740 \uacbd\uc6b0
		//\ubcf4\ud5d8\uc2dc\uae30\uac00 7\uc6d4\uc774\ud6c4\uba74 A or B
		//\uc544\ub2c8\uba74 \ub2f9\uc5f0\ud788 6\uac1c\uc6d4\uc774\uc804\uc774\ubbc0\ub85c
		if ( yyyy  == sYear ){

			if ( Number(mmdd) >= 701 ){
				if ( sYearType != 'A' && sYearType != 'B' ){
					return '01';
				}
			} else {
				if ( sYearType != ''){
					return '02';
				}
			}
		//\ub144\uc2dd\uc774 \ubcf4\ud5d8\uc2dc\uae30\uc758 1\ub144 \uc804\uc778 \uacbd\uc6b0
		//\ubcf4\ud5d8\uc2dc\uae30\uac00 7\uc6d4\uc774\uc804\uc774\uba74 A or B
		//\uc544\ub2c8\uba74 \ub2f9\uc5f0\ud788 6\uac1c\uc6d4\uc774\ud6c4\uc774\ubbc0\ub85c
		} else if ( Number(yyyy) ==  ( Number(sYear) + 1 ) ){
			if ( Number(mmdd) < 701 ){
				if ( sYearType != 'A' && sYearType != 'B' ){
					return '01';
				}
			} else {
				if ( sYearType != ''){
					return '02';
				}
			}
		//\uadf8 \uc678\ub294 6\uac1c\uc6d4\uc774\ud6c4\uc774\ubbc0\ub85c
		} else {
			if ( sYearType != ""  ){
				return '02';
			}
		}
		return result;
	},
	/**
	 * sYearType \uad6c\ud558\uae30
	 * @param applyFmdt \ubcf4\ud5d8\uc2dc\uae30
	 * @param firstdate \ucd5c\ucd08\ub4f1\ub85d\uc77c
	 * @return sYearType
	 */
	setDecideYearType : function(applyFmdt, firstdate){
		var sYearType  = 'A';
		var sYear = firstdate.substring(0,4);
		var yyyy = applyFmdt.substring(0,4);
		var nMMDDD = applyFmdt.substring(4,8);
		//\ucd5c\ucd08\ub4f1\ub85d\uc77c\ub85c\ubd80\ud130 6\uac1c\uc6d4\uc774\ud6c4 \uc77c\uc790\ub97c \uad6c\ud55c\ub2e4.
		var afterDate = DateFunc.addMonth(6, '', firstdate);
		//\ubcf4\ud5d8\uc2dc\uae30\uac00 \ucd5c\ucd08\ub4f1\ub85d\uc77c\ub85c\ubd80\ud130 6\uac1c\uc6d4\uc774\ud6c4\uc77c\uc790 \ubcf4\ub2e4 \ud070 \uacbd\uc6b0\ub294 B
		if (afterDate < applyFmdt){
			sYearType = 'B';
		}
		return sYearType;
	},
	/** \uac31\uc2e0\uac00\ub2a5\uc5ec\ubd80 \ud655\uc778
	* 1. sTodtStatus == 1 || sTodtStatus == 2 || sTodtStatus == 3 || sPlateNo.length (\ucc28\ub7c9\ubc88\ud638\uac00 \uc5c6\ub294\uacbd\uc6b0) <= 0
	* 2. (sRenewCode.length <= 0 && sNewCode.length <= 0)(\uac31\uc2e0\uc728 \uc5c6\ub294\uc790)
	* 3. sRectFlag == "1" (\uc774\ubbf8\uacc4\uc57d\uc790)
	* 4. sSpcAcceptType == "1" (\uc0ac\uace0\uc810\uc218 \ub192\uc740\uc790)
	* 5. sRenewCode === "000" (IBNR \uc0ac\uae30\uac74)
	* @param sTodtStatus
	* @param sPlateNo
	* @param sRenewCode
	* @param sNewCode
	* @param sSpcAcceptType
	* @param sRectFlag
	**/
	isPossibleRenewal : function(sTodtStatus, sPlateNo ,sRenewCode, sNewCode, sSpcAcceptType, sRectFlag) {
		if (sTodtStatus == 1 || sTodtStatus == 2 || sTodtStatus == 3 || sPlateNo == null || sPlateNo.length <= 0) {
			return true;
		}
		/* \ud604\uc5c5\uc694\uccad(\uae40\ud0dc\ud6c8 \uacfc\uc7a5)\uc5d0 \uc758\ud574 \uc8fc\uc11d\ucc98\ub9ac (2013.02.04)
		if ((sRenewCode === null || sRenewCode.length <= 0) && (sNewCode === null || sNewCode.length <= 0)) {
			return true;
		}
		*/
		if (sRectFlag == '1') {
			return true;
		}
		if (sSpcAcceptType == '1') {
			return false;	// disable\ucc98\ub9ac\ub294 \ud558\uc9c0\uc54a\uace0 \ucf5c\uc13c\ud130\uc804\ud654\ubc88\ud638 alert
		}
		if (sRenewCode == '000') {
			return false;   // disable\ucc98\ub9ac\ub294 \ud558\uc9c0\uc54a\uace0 \ucf5c\uc13c\ud130\uc804\ud654\ubc88\ud638 alert
		}
		return false;
	},
	/**
	* \uacc4\uc0b0 \ubd88\uac00 \uace0\uac1d \ud1b5\ud569 \uba54\uc138\uc9c0
	* @param sName \uace0\uac1d\uba85
	**/
	getCalculationImPossibleMessage : function(sName) {
		return '\uc8c4\uc1a1\ud569\ub2c8\ub2e4. ' + sName + ' \uace0\uac1d\ub2d8\n' + '\uace0\uac1d\ub2d8\uaed8\uc11c\ub294 \ud604\uc7ac \uc778\ud130\ub137\uc73c\ub85c \ubcf4\ud5d8\ub8cc \uc0b0\ucd9c\uc774 \uc5b4\ub835\uc2b5\ub2c8\ub2e4.\n\ucf5c\uc13c\ud0c0 (1566-3000, ARS 3\ubc88) \ub610\ub294 \uc0c1\ub2f4\uc2e0\uccad\uc744 \uc774\uc6a9\ud558\uc2dc\uba74 \uce5c\uc808\ud558\uac8c \uc548\ub0b4\ud574 \ub4dc\ub9ac\uaca0\uc2b5\ub2c8\ub2e4.';
	},
	/**
	* \uacc4\uc0b0 \ubd88\uac00 \uace0\uac1d \ud1b5\ud569 \uba54\uc138\uc9c0(\ubaa8\ubc14\uc77c\uc6a9)
	* @param sName \uace0\uac1d\uba85
	**/
	getCalculationImPossibleMessageForMobile : function(sName) {
		return '\uc8c4\uc1a1\ud569\ub2c8\ub2e4. ' + sName + ' \uace0\uac1d\ub2d8\n' + '\uace0\uac1d\ub2d8\uaed8\uc11c\ub294 \ud604\uc7ac \uc778\ud130\ub137\uc73c\ub85c \ubcf4\ud5d8\ub8cc \uc0b0\ucd9c\uc774 \uc5b4\ub835\uc2b5\ub2c8\ub2e4.\n\ucf5c\uc13c\ud0c0 (1644-3633, ARS 3\ubc88) \ub610\ub294 \uc0c1\ub2f4\uc2e0\uccad\uc744 \uc774\uc6a9\ud558\uc2dc\uba74 \uce5c\uc808\ud558\uac8c \uc548\ub0b4\ud574 \ub4dc\ub9ac\uaca0\uc2b5\ub2c8\ub2e4.';
	}
 };