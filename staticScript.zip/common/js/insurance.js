/**
 * \ubcf4\ud5d8\ub8cc \ubcc0\uc218
 */
var InsuranceParam = {
	/** \uc7a5\uae30\ubcf4\ud5d8 */
	LongTermParam : {
		calculationNodePath : 'calculationBackBone/request/requestBody',
		isInsuranceListSearch : false, // \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \uc870\ud68c \uc5ec\ubd80
		isInsuranceCalculation : false, // \ubcf4\ud5d8\ub8cc \uc0b0\ucd9c \uacc4\uc0b0 \uc5ec\ubd80
		isInsuranceRecalculation : false, // \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \uacc4\uc0b0 \uc5ec\ubd80
		calculationMinPrem : 0 // \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c\uc6a9 \uc601\uc5c5\ubcf4\ud5d8\ub8cc \ucd5c\uc18c \uac12
	},
	InsuranceVaildDate : ''
};

/**
 * \ubcf4\ud5d8\ub8cc \ud568\uc218
 */
var InsuranceFunc= {
	/**
	 * Job common function
	 */
	JobFunc : {
		// \uc9c1\uc5c5 \uc911\ubd84\ub958 \ubaa9\ub85d \uc870\ud68c\ud558\uae30
		selectDivisionList : function() {
			// \uc911\ubd84\ub958/\uc18c\ubd84\ub958 \ucd08\uae30\ud654
			cboJobDivision.removeAll(true);
			cboJobDivision.setDisabled(true);
			cboJobSub.removeAll(true);
			cboJobSub.setDisabled(true);
			if (cboJobMain.getValue() === '') {
				return false;
			}
			WebSquare.ModelUtil.setInstanceValue('jobList/request/requestBody/data/key', cboJobMain.getValue());
			WebSquare.ModelUtil.executeSubmission('submissionGetJobDivisionList');
		},
		// \uc9c1\uc5c5 \uc18c\ubd84\ub958 \ubaa9\ub85d \uc870\ud68c\ud558\uae30
		selectSubList : function() {
			// \uc18c\ubd84\ub958 \ucd08\uae30\ud654
			cboJobSub.removeAll(true);
			cboJobSub.setDisabled(true);
			if (cboJobDivision.getValue() === '') {
				return false;
			}
			WebSquare.ModelUtil.setInstanceValue('jobList/request/requestBody/data/key', cboJobDivision.getValue());
			WebSquare.ModelUtil.executeSubmission('submissionGetJobSubList');
		}
	},
	/**
	 * \uc7a5\uae30\ubcf4\ud5d8
	 */
	LongTermFunc : {
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ud65c\uc131\ud654\ub97c \uc704\ud55c \ucd08\uae30\ud654 */
		resetInsuranceRecalculation : function() {
			nGrntPrem.setLabel(0);	// \ubcf4\uc7a5\ubcf4\ud5d8\ub8cc
			nAccuPrem.setLabel(0);  // \uc801\ub9bd\ubcf4\ud5d8\ub8cc
			nBussPrem.setValue(''); // \uc601\uc5c5\ubcf4\ud5d8\ub8cc
			nExptEndRetrnAmt.setLabel(0); // \uc608\uc0c1\ub9cc\uae30\ud658\uae09\uae08
			// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \uc228\uae40 \ucc98\ub9ac
			nBussPrem.setDisabled(true);
			grpReCalculaion.hide();
			// \uc608\uc0c1\ub9cc\uae30\ud658\uae09\uae08 \ud658\uae09\ub960 show/hide \ucc98\ub9ac
			grpExptEndRtnrt.hide();
			if ($('#grpExptEndRtnrt').hasClass('dpi')) { // for \ubcf4\ud5d8\uc0c1\ud488
				$('#grpExptEndRtnrt').removeClass('dpi').addClass('dpn');
			}
			// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ud65c\uc131\ud654 \ucc98\ub9ac
			InsuranceParam.LongTermParam.isInsuranceRecalculation = false;
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \uc870\ud68c */
		selectInsuranceList : function() {
		
			// \uc870\ud68c\uc870\uac74\uc774 \ubcc0\uacbd\ub418\uc9c0 \uc54a\uc558\uace0 \uac00\uc785 \ud2b9\uc57d\uc744 \uc870\ud68c\ud558\uc600\uc744 \uacbd\uc6b0\uc5d0\ub294 \uc7ac\uc870\ud68c\ud558\uc9c0 \uc54a\ub294\ub2e4.
			if (InsuranceParam.LongTermParam.isInsuranceListSearch) {
				return false;
			}

			// \uc0dd\uc77c
			var birth_value = '';
			if (document.getElementById('txtBirth')) {
				birth_value = txtBirth.getValue();
			} else {
				birth_value = txtBirth1.getValue() + txtBirth2.getValue() + txtBirth3.getValue();
			}

			// validation check
			var valid = ValidFunc.init({
				rules : {
					txtBirth1	: { required : true, number : true, equalLength : 4 },
					txtBirth2	: { required : true, number : true, equalLength : 2 },
					txtBirth3	: { required : true, number : true, equalLength : 2 },
					txtBirth	: { required : true, number : true, equalLength : 8, date : true },
					/* 
					fullAge		: {
						fullAge : [19, 63]
					},
					*/
					cboSex		: 'required',
					cboJobMain	: 'required',
					cboJobDivision : 'required',
					cboJobSub	: 'required'
				},
				names : {
					txtBirth1	: '\uc0dd\ub144\uc6d4\uc77c',
					txtBirth2	: '\uc0dd\ub144\uc6d4\uc77c',
					txtBirth3	: '\uc0dd\ub144\uc6d4\uc77c',
					txtBirth	: '\uc0dd\ub144\uc6d4\uc77c',
					cboSex		: '\uc131\ubcc4',
					cboJobMain	: '\ud53c\ubcf4\ud5d8\uc790(\ubcf8\uc778) \uc9c1\uc5c5(\ub300\ubd84\ub958)',
					cboJobDivision : '\ud53c\ubcf4\ud5d8\uc790(\ubcf8\uc778) \uc9c1\uc5c5(\uc911\ubd84\ub958)',
					cboJobSub	: '\ud53c\ubcf4\ud5d8\uc790(\ubcf8\uc778) \uc9c1\uc5c5(\uc18c\ubd84\ub958)'
				},
				values : {
					txtBirth	: birth_value,
					/* fullAge		: CommonFunc.getFullAge(birth_value) */
				}
			});
			/* 
			
			valid.addMethod('fullAge', function(value, element, param) {
				return this.optional(element) || (value > param[0] && value < param[1]);
			}, ValidMessage.format('\ub9cc {0} ~ {1}\uc138 \uace0\uac1d\uc5d0 \ud55c\ud574 \ubcf4\ud5d8\ub8cc \ud655\uc778\uc774 \uac00\ub2a5\ud569\ub2c8\ub2e4.'));
			
			*/
			if (!valid.validate()) {
				return false;
			}
			// \ub178\ub4dc\uc5d0\uc11c \uae30\uac04\uacc4\ub85c \ub118\uaca8\uc904 sDriveClass \uac12 \uac00\uc838\uc624\uae30
			var doc = WebSquare.ModelUtil.findInstanceNode('jobCbo/cboJobSub/responseBody/data[key="' + cboJobSub.getValue() + '"]');
			// \uc0dd\ub144\uc6d4\uc77c \uc124\uc815
			InsuranceParam.LongTermParam.sResno = CommonFunc.birthSSNConvert(birth_value, cboSex.getValue()); // \uc0dd\ub144\uc6d4\uc77c \ub4a4\uc5d0 \ucd94\uac00\ud558\uc5ec 13\uc790\ub9ac \ub9cc\ub4e4\uc5b4\uc900\ub2e4 1980\ub144 10\uc6d4 30\uc77c \ub0a8\uc790 \uacbd\uc6b0(8010301000000)
			WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sResno', InsuranceParam.LongTermParam.sResno);
			WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sInsurTermCd', insurancePeriod.getValue()); // \ubcf4\ud5d8\uae30\uac04
			WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sPaymCyclCd',  cboPaymentCycle.getValue()); // \ub0a9\uc785\uc8fc\uae30
			// sDriveClass \uac12 \uc124\uc815
			WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sDrivFlagCd', WebSquare.xml.getValue(doc, 'sDriveClass'));
			
			if(InsuranceParam.pGnrzCd){
				WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sGnrzCd',  InsuranceParam.pGnrzCd); // \uac00\uc785\uc720\ud615
			}else{
				WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sGnrzCd',  '00');
			}
				
			if(InsuranceParam.paymentPeriod){
				WebSquare.ModelUtil.setInstanceValue('selectBackBone/request/requestBody/data/sPaymTermCd', paymentPeriod.getValue()); // \ub0a9\uc785\uae30\uac04
			}
			
			// \uc9c1\uc5c5\uc815\ubcf4\uc5d0 \ub530\ub978 \ubcf4\uc7a5\uc815\ubcf4 \uae30\uac04\uacc4 \uc870\ud68c
			WebSquare.ModelUtil.executeSubmission('submissionSelectBackBone');
		},
		/**
		 * \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \uadf8\ub9ac\uae30 \uc704\ud55c \uc124\uc815
		 *  - \ubcf4\ud5d8\uae30\uac04, \ub0a9\uc785\uae30\uac04 \uadf8\ub9ac\uae30
		 *  - \ubcf4\uc7a5\uae08\uc561(\ucf64\ubcf4\ubc15\uc2a4) \uadf8\ub9ac\uae30 - \ubcf4\uc7a5\uae08\uc561\uc774 \ub9c8\uc9c0\ub9c9\uc73c\ub85c \uadf8\ub824\uc8fc\ubbc0\ub85c row_index \uac12\uc744 + 1 \ub354\ud574\uc900\ub2e4.
		 */
		insuranceListSetting : function() {
			
			//var trty_col_index = Number(grdInsurance.getCellInfo('sTrtyCd').options.colIndex);
			//IE11 \ub300\uc751 \uc5c5\ub370\uc774\ud2b8\ubd80\ud130 options.colIndex \uc744 \uc9c0\uc6d0\uc548\ud574\uc11c \uc544\ub798\ucc98\ub7fc \ubcc0\uacbd
			var trty_col_index = Number(grdInsurance.getColumnIndex('sTrtyCd'));
			var row_index = 0;
			function insuranceListSettingForTrtyCd(value) {
				// HTML \uc0dd\uc131
				row_index = row_index % grdInsurance.getRowCount();
				var optionNodes = WebSquare.xml.findNodes(WebSquare.ModelUtil.findInstanceNode('insurance/data'), 'selectList/map[@value="' + grdInsurance.getCellData(row_index, trty_col_index) + '"]/vector');
				// HACK: \ucf64\ubcf4\ubc15\uc2a4 \uc635\uc158 \ud56d\ubaa9\uc774 \ub3d9\uc801\uc774\ub77c diplayFormatter \ucc98\ub9ac
				var html = '<div class="w2selectbox_native fixedWidth w2grid_embedded_select"><div class="w2selectbox_native_innerDiv"><select class="w2selectbox_native_select" onchange="InsuranceFunc.LongTermFunc.insuranceCboChageEvent(this, ' + row_index++ + ')">';
				$.each(optionNodes, function(index, optionNode) {
					html+= '<option value="' + WebSquare.xml.getValue(optionNode, 'sCd') + '">' + WebSquare.xml.getValue(optionNode, 'sHnglCdName') + '</option>';
				});
				html += '</select></div></div>';
				return html;
			}
			// \ubcf4\ud5d8\uae30\uac04
			grdInsurance.setDisplayFormatter('sInsurTermCdFormatter', function(value) {
				row_index = row_index % grdInsurance.getRowCount();
				return WebSquare.ModelUtil.getInstanceValue('insurance/data/InsurTerm[sTrtyCd="' + grdInsurance.getCellData(row_index, trty_col_index) + '"]/sInsurTermName');
			});
			// \ub0a9\uc785\uae30\uac04
			grdInsurance.setDisplayFormatter('sPaymTermCdFormatter', function(value) {
				row_index = row_index % grdInsurance.getRowCount();
				return WebSquare.ModelUtil.getInstanceValue('insurance/data/InsurTerm[sTrtyCd="' + grdInsurance.getCellData(row_index, trty_col_index) + '"]/sPaymTermName');
			});
			// \ubcf4\uc7a5\uae08\uc561
			grdInsurance.setDisplayFormatter('sTrtyCdFormatter', insuranceListSettingForTrtyCd);
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \ubcf4\uc7a5\uae08\uc561(\ucf64\ubcf4\ubc15\uc2a4)\uc774\ubca4\ud2b8 \ubd80\uc5ec */
		insuranceCboChageEvent : function(obj, idx) {
			this.validInsuranceChange($(obj), idx, WebSquare.ModelUtil.findInstanceNodes('insurance/data/multi')); // \uc7a5\uae30\ubcf4\ud5d8\ub8cc \ubcf4\uc7a5\ub0b4\uc6a9 \ubcc0\uacbd \uac80\uc99d
			InsuranceParam.LongTermParam.isInsuranceCalculation = false; // \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \ubc84\ud2bc \ud65c\uc131\ud654 \ucc98\ub9ac
			this.resetInsuranceRecalculation(); // \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ud65c\uc131\ud654\ub97c \uc704\ud55c \ucd08\uae30\ud654
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \ubcf4\ud5d8\uae30\uac04 */
		insuranceDisplayFormatterForInsurTerm : function(value) {
			return WebSquare.ModelUtil.getInstanceValue('insurance/data/InsurTerm[sTrtyCd="' + value + '"]/sInsurTermName');
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \ub0a9\uc785\uae30\uac04 */
		insuranceDisplayFormatterForPaymTerm : function(value) {
			return WebSquare.ModelUtil.getInstanceValue('insurance/data/InsurTerm[sTrtyCd="' + value + '"]/sInsurTermName');
			
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \uadf8\ub9ac\uae30 */
		insuranceListDraw : function() {

			var doc = WebSquare.xml.parse(WebSquare.ModelUtil.getInstanceValue('response/responseBody/data'));
			var insuranceDoc = WebSquare.xml.findNode(doc, 'root/data');
			var insuranceDocList = WebSquare.xml.findNodes(insuranceDoc , 'multi');
			WebSquare.ModelUtil.setInstanceNode(insuranceDoc, 'insurance');

			// create request node
			WebSquare.ModelUtil.removeChildNodes(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List'); // \ub178\ub4dc \ucd08\uae30\ud654

			if (insuranceDocList.length === 1) {
				WebSquare.ModelUtil.copyChildrenNodes('insurance/data/multi', InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02', 'replaceAll');
			} else {
				WebSquare.ModelUtil.copyChildrenNodes('insurance/data/multi[1]', InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02', 'replaceAll');
				
				for (var i = 2; i <= insuranceDocList.length; i++) {
					WebSquare.ModelUtil.setInstanceNode(WebSquare.ModelUtil.findInstanceNode(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02'), InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List', null, 'append');
					WebSquare.ModelUtil.copyChildrenNodes('insurance/data/multi[' + i + ']', InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[' + i + ']', 'replaceAll');//'overwrite');
				}
			}
			// \ubaa9\ub85d \uadf8\ub9ac\uae30
			WebSquare.ModelUtil.removeInstanceNodes(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sScrnIndcYn != "Y"]');
			WebSquare.ModelUtil.removeInstanceNodes('insurance/data/multi[sScrnIndcYn != "Y"]');
			insuranceDoc = WebSquare.ModelUtil.findInstanceNode('insurance/data');
			insuranceDocList = WebSquare.xml.findNodes(insuranceDoc , 'multi');
			grdInsurance.setXML(insuranceDoc);
			
			if(grdInsurance.getRowCount() < 1){
				alert('\uc785\ub825\ud558\uc2e0 \uac00\uc785\uc870\uac74\uc73c\ub85c \ubcf4\ud5d8\ub8cc\ub97c \ud655\uc778 \ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.');
				return false;
			}
			// \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d (\ubcf4\uc7a5\ub0b4\uc5ed) \uc870\ud68c \ubc84\ud2bc \ube44\ud65c\uc131\ud654 \ucc98\ub9ac
			InsuranceParam.LongTermParam.isInsuranceListSearch = true;
			// \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \ubc84\ud2bc \ud65c\uc131\ud654 \ucc98\ub9ac
			InsuranceParam.LongTermParam.isInsuranceCalculation = false;
			
			
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \uac80\uc99d */
		validInsuranceCalculation : function() {
			var isSuccess = true;
			var options = {};
			options.nodeList = WebSquare.ModelUtil.findInstanceNodes('insurance/data/multi');
			options.$target  = $('#grdInsurance tbody:first tr');
			options.$target.each(function(tr_idx) {
				var Trty = {
					userDefnName	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'TrtyUserDefnName'),	// \ub2f4\ubcf4\uba85
					cd				: WebSquare.xml.getValue(options.nodeList[tr_idx], 'TrtyCd'),			// \ub2f4\ubcf4\ucf54\ub4dc
					pkgCd			: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sPkgCd'),			// \ud328\ud0a4\uc9c0\ucf54\ub4dc
					excluGroupCd1	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sExcluGroupCd1'),	// \ubca0\ud0c0\uadf8\ub8f9\ucf54\ub4dc
					excluGroupCd2	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sExcluGroupCd2'),
					excluGroupCd3	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sExcluGroupCd3'),
					excluGroupCd4	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sExcluGroupCd4'),
					excluGroupCd5	: WebSquare.xml.getValue(options.nodeList[tr_idx], 'sExcluGroupCd5'),
					amt				: $(this).find(':input').val()
				};

				// \uae30\ubcf8\ub2f4\ubcf4\uc5ec\ubd80
				if (WebSquare.xml.getValue(options.nodeList[tr_idx], 'BascSlctFlagCd') === '1' && Trty.amt === '') {
					var message  = WebSquare.xml.getValue(options.nodeList[tr_idx], 'BascSlctFlagCd_H') + ' \ud2b9\uc57d ';
						message += Trty.userDefnName + ' \ubcf4\uc7a5\uae08\uc561\uc744 \uc120\ud0dd\ud574 \uc8fc\uc2ed\uc2dc\uc624.';
					alert(message);
					isSuccess = false;
					return isSuccess;
				}
				// \ub3d9\uc77c\ud328\ud0a4\uc9c0 \ub3d9\uc2dc \uac00\uc785
				if (Trty.amt && Trty.pkgCd) {
					options.$target.each(function(check_idx) {
						if (tr_idx == check_idx) {
							// \uac80\uc0ac\ub300\uc0c1\uacfc \uac19\uc740 \ud589\uc77c \uacbd\uc6b0 \ub2e4\uc74c \ud589\uc744 \uac80\uc0ac
							return true;
						}
						Trty.checkAmt = $(this).find(':input').val();
						if (Trty.checkAmt === '' && Trty.pkgCd == WebSquare.xml.getValue(options.nodeList[check_idx], 'sPkgCd')) { // \ud328\ud0a4\uc9c0\ucf54\ub4dc
							var message = '\'' + Trty.userDefnName + '\' \ud2b9\uc57d\uacfc ';
							message += '\'' + WebSquare.xml.getValue(options.nodeList[check_idx], 'TrtyUserDefnName') + '\'';
							message += ' \ud2b9\uc57d\uc740 \ub3d9\uc2dc\uc5d0 \uac00\uc785\ud574\uc57c\ud569\ub2c8\ub2e4.';
							alert(message);
							$(this).find(':input:first').focus();
							isSuccess = false;
							return isSuccess;
						}
					});
				}
				// \ubca0\ud0c0\uadf8\ub8f9 \uac00\uc785 \uc5ec\ubd80
				if (Trty.amt && (Trty.excluGroupCd1 || Trty.excluGroupCd2 || Trty.excluGroupCd3 || Trty.excluGroupCd4 || Trty.excluGroupCd5)) {
					options.$target.filter(':gt(' + tr_idx + ')').each(function(check_idx) {
						Trty.checkAmt = $(this).find(':input').val();
						if (Trty.checkAmt !== '') {
							Trty.checkIdx = tr_idx + check_idx + 1;
							Trty.checkGroupCd = WebSquare.xml.getValue(options.nodeList[Trty.checkIdx], 'sGroupCd'); // \uadf8\ub8f9\ucf54\ub4dc
							if (Trty.checkGroupCd !== ''
									&& (Trty.checkGroupCd == Trty.excluGroupCd1
									|| Trty.checkGroupCd == Trty.excluGroupCd2
									|| Trty.checkGroupCd == Trty.excluGroupCd3
									|| Trty.checkGroupCd == Trty.excluGroupCd4
									|| Trty.checkGroupCd == Trty.excluGroupCd5)) {
								var message = '\'' + Trty.userDefnName + '\' \ud2b9\uc57d\uacfc ';
								message += '\'' + WebSquare.xml.getValue(options.nodeList[Trty.checkIdx], 'TrtyUserDefnName') + '\'';
								message += ' \ud2b9\uc57d\uc740 \ub3d9\uc2dc \uac00\uc785\uc774 \ubd88\uac00\ud569\ub2c8\ub2e4.';
								alert(message);
								$(this).find(':input:first').focus();
								isSuccess = false;
								return isSuccess;
							}
						}
					});
				}
			});
			return isSuccess;
		},
		/** \uc7a5\uae30\ubcf4\ud5d8\ub8cc \ubcf4\uc7a5\ub0b4\uc6a9 \ubcc0\uacbd \uac80\uc99d */
		validInsuranceChange : function($obj, tr_idx, xmlDoc) {
			if ($obj.val() === '') {
				return true;
			}
			var Trty = {
				$target			: $obj.closest('tbody').find('tr'),
				userDefnName	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'TrtyUserDefnName'),	// \ub2f4\ubcf4\uba85
				excluGroupCd1	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'sExcluGroupCd1'),		// \ubca0\ud0c0\uadf8\ub8f9\ucf54\ub4dc
				excluGroupCd2	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'sExcluGroupCd2'),
				excluGroupCd3	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'sExcluGroupCd3'),
				excluGroupCd4	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'sExcluGroupCd4'),
				excluGroupCd5	: WebSquare.xml.getValue(xmlDoc[tr_idx], 'sExcluGroupCd5')
			};
			if (Trty.excluGroupCd1 || Trty.excluGroupCd2 || Trty.excluGroupCd3 || Trty.excluGroupCd4 || Trty.excluGroupCd5) {
				Trty.$target.each(function(check_idx) {
					if (tr_idx === check_idx) {
						return true;
					}
					Trty.checkAmt = $(this).find(':input').val();
					if (Trty.checkAmt !== '') {
						Trty.checkGroupCd = WebSquare.xml.getValue(xmlDoc[check_idx], 'sGroupCd'); // \uadf8\ub8f9\ucf54\ub4dc
						if (Trty.checkGroupCd !== ''
								&& (Trty.checkGroupCd == Trty.excluGroupCd1
								|| Trty.checkGroupCd == Trty.excluGroupCd2
								|| Trty.checkGroupCd == Trty.excluGroupCd3
								|| Trty.checkGroupCd == Trty.excluGroupCd4
								|| Trty.checkGroupCd == Trty.excluGroupCd5)) {
							var message = '';
							if (check_idx < tr_idx) {
								message += '\'' + WebSquare.xml.getValue(xmlDoc[check_idx], 'TrtyUserDefnName') + '\' \ud2b9\uc57d\uacfc ';
								message += '\'' + Trty.userDefnName + '\'';
							} else {
								message += '\'' + Trty.userDefnName + '\' \ud2b9\uc57d\uacfc ';
								message += '\'' + WebSquare.xml.getValue(xmlDoc[check_idx], 'TrtyUserDefnName') + '\'';
							}
							message += ' \ud2b9\uc57d\uc740 \ub3d9\uc2dc \uac00\uc785\uc774 \ubd88\uac00\ud569\ub2c8\ub2e4.';
							alert(message);
							$obj.val('').focus();
						}
					}
				});
			}
		},
		/** \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 */
		insuranceCalculation : function(wqObject) {

			// \uac00\uc785 \ud2b9\uc57d\uc774 \uc870\ud68c\ub418\uc9c0 \uc54a\uc558\uac70\ub098, \uacc4\uc0b0 \uc870\ud68c\uc870\uac74\uc774 \ubcc0\uacbd\ub418\uc9c0 \uc54a\uc558\uc744 \uacbd\uc6b0\uc5d0\ub294 \uc7ac\uacc4\uc0b0\ud558\uc9c0 \uc54a\ub294\ub2e4.
			if (!InsuranceParam.LongTermParam.isInsuranceListSearch) {
				alert('\uac00\uc785\ud2b9\uc57d \ub0b4\uc5ed\uc744 \uc870\ud68c\ud558\uc9c0 \uc54a\uc73c\uc168\uac70\ub098, \uac00\uc785\uc870\uac74\uc774 \ubcc0\uacbd\ub418\uc5c8\uc2b5\ub2c8\ub2e4. \uac00\uc785\ud2b9\uc57d \ub0b4\uc5ed\uc744 \uc870\ud68c\ud574 \uc8fc\uc2ed\uc2dc\uc624.');
				return false;
			} else {
				if (wqObject.hasClass('re_calculation') === true) {
					// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c
					if (!InsuranceParam.LongTermParam.isInsuranceCalculation) {
						alert('\ubcf4\ud5d8\ub8cc\ub97c \uacc4\uc0b0\ud558\uc9c0 \uc54a\uc73c\uc168\uac70\ub098, \ud2b9\uc57d\uc870\uac74\uc774 \ubcc0\uacbd\ub418\uc5c8\uc2b5\ub2c8\ub2e4. \ubcf4\ud5d8\ub8cc\ub97c \uacc4\uc0b0\ud574 \uc8fc\uc2ed\uc2dc\uc624.');
						return false;
					} else if (nBussPrem.getValue() === '' || Number(nBussPrem.getValue()) === 0) {
						alert('\uc601\uc5c5\ubcf4\ud5d8\ub8cc \ud56d\ubaa9\uc740 \ubc18\ub4dc\uc2dc \uc785\ub825\ud574\uc57c \ud569\ub2c8\ub2e4.');
						return false;
					} else if (Number(nBussPrem.getValue()) < InsuranceParam.LongTermParam.calculationMinPrem) {
						alert('\uc601\uc5c5\ubcf4\ud5d8\ub8cc \ud56d\ubaa9\uc740 ' + InsuranceParam.LongTermParam.calculationMinPrem.addComma() + '\uc6d0 \uc774\uc0c1\uc73c\ub85c \uc785\ub825\ud574\uc57c \ud569\ub2c8\ub2e4.');
						return false;
					} else if (InsuranceParam.LongTermParam.isInsuranceRecalculation) {
						// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubcc0\uacbd\ub41c \uc870\ud68c\uc870\uac74\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.
						return false;
					}
				} else if (InsuranceParam.LongTermParam.isInsuranceCalculation) {
					// \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \ubcc0\uacbd\ub41c \uc870\ud68c\uc870\uac74\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.
					return false;
				}
			}
			if (!this.validInsuranceCalculation()) {
				return false;
			}

			// \uc0dd\uc77c
			var birth_value = '';
			if (document.getElementById('txtBirth')) {
				birth_value = txtBirth.getValue();
			} else {
				birth_value = txtBirth1.getValue() + txtBirth2.getValue() + txtBirth3.getValue();
			}

			// \ubcf4\ud5d8 \uacc4\uc57d \uc124\uacc4
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/nGrntPrem', String(nGrntPrem.getLabel()).replace(/,/, '')); // \ubcf4\uc7a5\ubcf4\ud5d8\ub8cc (\uc7ac\uc0b0\ucd9c \uc2dc \uc0ac\uc6a9)
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/sInsurTermCd', insurancePeriod.getValue()); // \ubcf4\ud5d8\uae30\uac04
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/sPaymCyclCd',  cboPaymentCycle.getValue()); // \ub0a9\uc785\uc8fc\uae30
				
			if(InsuranceParam.paymentPeriod){
				WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/sPaymTermCd', paymentPeriod.getValue()); // \ub0a9\uc785\uae30\uac04
			}
			
			// \ud53c\ubcf4\ud5d8\uc790 \uc124\uacc4
			var vsInsParam = CommonFunc.birthSSNConvert(birth_value, cboSex.getValue());
			var vsInsAge = CommonFunc.getInsAge(vsInsParam);
			
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA01/nInrpsAge', vsInsAge); // \ub9cc \ub098\uc774
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA01/sInrpsCd',  CommonFunc.birthSSNConvert(birth_value, cboSex.getValue())); // \ud53c\ubcf4\ud5d8\uc790 \uc8fc\ubbfc\ubc88\ud638
			// \ub178\ub4dc\uc5d0\uc11c \uae30\uac04\uacc4\ub85c \ub118\uaca8\uc904 \uc9c1\uc5c5 Document \uac12 \uac00\uc838\uc624\uae30
			var jobDoc = WebSquare.ModelUtil.findInstanceNode('jobCbo/cboJobSub/responseBody/data[key="' + cboJobSub.getValue() + '"]');
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA01/sJobCd',      WebSquare.xml.getValue(jobDoc, 'key'));         // \uc9c1\uc5c5\ucf54\ub4dc (cboJobSub.getValue())
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA01/sJobGradCd',  WebSquare.xml.getValue(jobDoc, 'sJobClass'));   // \uc9c1\uc5c5\uae09\uc218
			WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA01/sDrveFlagCd', WebSquare.xml.getValue(jobDoc, 'sDriveClass')); // \uc6b4\uc804\uad6c\ubd84\ucf54\ub4dc
			// \uac00\uc785 \ud2b9\uc57d (\ubcf4\uc7a5\ub0b4\uc6a9\ubcc4 \ubcf4\uc7a5\uae08\uc561)
			$('#grdInsurance tbody:first tr').each(function(tr_idx) {
				var trtyCode = $(this).find('td[col_id=sTrtyCd]').text(); // \ud2b9\uc57d\ucf54\ub4dc
				var trtyAmt  = $(this).find(':input').val(); // \ubcf4\ud5d8\ub8cc
				if (trtyAmt !== '') {
					WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/chk', '1');
					WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/nTrtyInsAmt', trtyAmt);
					if(InsuranceParam.pGnrzCd){
						WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/sGnrzCd', InsuranceParam.pGnrzCd);// \uac00\uc785\uc720\ud615
					}
				} else {
					WebSquare.ModelUtil.removeInstanceNode(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/chk');
					WebSquare.ModelUtil.removeInstanceNode(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/nTrtyInsAmt');
					WebSquare.ModelUtil.removeInstanceNode(InsuranceParam.LongTermParam.calculationNodePath + '/data/vLTIDA02List/vLTIDA02[sTrtyCd="' + trtyCode + '"]/sGnrzCd');
				}
			});
			// \ubcf4\ud5d8\ub8cc \uacc4\uc0b0/\uc7ac\uc0b0\ucd9c \uad6c\ubd84\uc5d0 \ub530\ub978 \uc601\uc5c5\ubcf4\ud5d8\ub8cc \ubd84\uae30
			if (wqObject.hasClass('re_calculation') === true) {
				// \uc7ac\uc0b0\ucd9c
				WebSquare.ModelUtil.setInstanceValue(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/nBussPrem', Number(nBussPrem.getValue()));
			} else {
				// \uacc4\uc0b0
				WebSquare.ModelUtil.removeInstanceNode(InsuranceParam.LongTermParam.calculationNodePath + '/data/LTIDA00/nBussPrem');
			}
			// \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \uae30\uac04\uacc4 \uc870\ud68c
			
			WebSquare.ModelUtil.executeSubmission('submissionCalculationBackBone');
		},
		// \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \ud6c4\ucc98\ub9ac
		insuranceCalculationPost : function() {
		
			// \uc801\ub9bd\ubcf4\ud5d8\ub8cc \uc720/\ubb34(\uc7ac\uc0b0\ucd9c/\uacc4\uc0b0)\uc5d0 \ub530\ub77c \ubd84\uae30
			if (!WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nAccuPrem')) {
				// \ubcf4\ud5d8\ub8cc \uacc4\uc0b0 \ubc84\ud2bc \ube44\ud65c\uc131\ud654 \ucc98\ub9ac
				InsuranceParam.LongTermParam.isInsuranceCalculation = true;
				// \uac00\uc785 \ud2b9\uc57d \ubaa9\ub85d \uac1d\uccb4
				InsuranceParam.LongTermParam.insuranceGrid$Obj = $('#grdInsurance tbody:first');

				// \uac00\uc785 \ud2b9\uc57d \ubcf4\uc7a5\ubcf4\ud5d8\ub8cc column index \ud655\uc778
				var colIndex = grdInsurance.getColumnIndex('nTrtyPrem');
				// \uac00\uc785 \ud2b9\uc57d \ubcf4\uc7a5\ubcf4\ud5d8\ub8cc \ucd08\uae30\ud654
				InsuranceParam.LongTermParam.insuranceGrid$Obj.find('tr').each(function(row_idx) {
					grdInsurance.setCellData(row_idx, colIndex, 0);
				});
				// \uae30\uac04\uacc4\uc5d0\uc11c \uacc4\uc0b0\ub41c \ubcf4\uc7a5\ubcf4\ud5d8\ub8cc \uc870\ud68c
				$.each(WebSquare.ModelUtil.findInstanceNodes('response/responseBody/data/vLTIDA02List/vLTIDA02'), function(i, v) {
					InsuranceParam.LongTermParam.insuranceGrid$Obj.find('tr td[col_id=sTrtyCd]').each(function(row_index) {
						if ($(this).text() == WebSquare.xml.getValue(v, 'sTrtyCd')) {
							grdInsurance.setCellData(row_index, colIndex, WebSquare.xml.getValue(v, 'nTrtyPrem'));
							return false;
						}
					});
				});
				// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ud65c\uc131\ud654\ub97c \uc704\ud55c \ucd08\uae30\ud654
				this.resetInsuranceRecalculation();
				// \ucd1d\ubcf4\uc7a5\ubcf4\ud5d8\ub8cc
				nGrntPrem.setLabel(WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nGrntPrem').addComma());
				// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ubcf4\uc5ec\uc8fc\uae30 \ucc98\ub9ac
				nBussPrem.setDisabled(false);
				grpReCalculaion.show();
				// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c\uc6a9 \uc601\uc5c5\ubcf4\ud5d8\ub8cc \ucd5c\uc18c \uac12
				InsuranceParam.LongTermParam.calculationMinPrem = WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nMinPrem');
			} else {
				// \ubcf4\ud5d8\ub8cc \uc7ac\uc0b0\ucd9c \ubc84\ud2bc \ube44\ud65c\uc131\ud654 \ucc98\ub9ac
				InsuranceParam.LongTermParam.isInsuranceRecalculation = true;
				// \uc801\ub9bd\ubcf4\ud5d8\ub8cc
				nAccuPrem.setLabel(WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nAccuPrem').addComma());
				// \uc608\uc0c1\ub9cc\uae30\ud658\uae09\uae08 \ud658\uae09\ub960 show/hide \ucc98\ub9ac
				grpExptEndRtnrt.show();
				if ($('#grpExptEndRtnrt').hasClass('dpn')) { // for \ubcf4\ud5d8\uc0c1\ud488 
					$('#grpExptEndRtnrt').removeClass('dpn').addClass('dpi');
				}
				nExptEndRetrnAmt.setLabel(WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nExptEndRetrnAmt').addComma());
				nExptEndRtnrt.setLabel(WebSquare.ModelUtil.getInstanceValue('response/responseBody/data/nExptEndRtnrt'));
			}
		}
	}
};
