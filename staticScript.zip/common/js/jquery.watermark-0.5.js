/**
 * Input Watermark jQuery Plugin
 * @version: 0.5
 * @author: Gonzalo Villar
 * @editor: slander
 */
;(function($) {
    function CreateDummyInput(jElement, options) {
        var watermarkText = options.watermarkText;
        var dummyStyle = {
            width : jElement.width() + 'px',
            height: jElement.height() + 'px',
            color : '#aaa'
        };
        var jElementStyle = {};
        $.each(jElement.attr('style').split(';'), function(idx, style) {
            style = style.split(':');
            if (style.length !== 2) {
                return true;
            }
            jElementStyle[$.trim(style[0])] = $.trim(style[1]);
        });
        $.each(dummyStyle, function(key, value) {
            jElementStyle[key] = dummyStyle[key];
        });
        var dummyInput = $('<input type="text">').attr('id', jElement.attr('id') + '_watermark')
                            .addClass(options.watermarkCssClass)
                            .addClass(jElement.attr('class'))
                            .css(jElementStyle)
                            .val(watermarkText)
                            .hide();
        jElement.after(dummyInput);
    }
    function MakeWatermark(element, options) {
        element.each(function() {
            var thisEl = jQuery(this);
            options.watermarkText = options.watermarkText ? options.watermarkText : thisEl.attr('title');
            if ('placeholder' in document.createElement('input')) {
                thisEl.attr('placeholder', options.watermarkText);
                return true;
            }
            CreateDummyInput(thisEl, options);
            var dummyInput = $('#' + thisEl.attr('id') + '_watermark');
            dummyInput.click(function(e) {
                $(this).hide();
                thisEl.show().focus();
            });
            dummyInput.focus(function(e) {
                $(this).hide();
                thisEl.show().focus();
            });
            thisEl.blur(function(e) {
                if (this.value == '') {
                    $(this).hide();
                    dummyInput.show();
                }
            });
            if (thisEl.val() == '') {
                thisEl.hide();
                dummyInput.show();
            }
        });
        return element;
    }

    $.fn.watermark = function(text, options) {
        if (arguments.length === 1 && typeof text == 'string') {
            options = {
                watermarkText : text
            };
        } else if (arguments.length > 1) {
            options.watermarkText = text;
        }
        return MakeWatermark(this, options);
    };
})(jQuery);
