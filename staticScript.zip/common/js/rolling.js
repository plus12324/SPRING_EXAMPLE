var RollingFunc = function() {
	return {
		// define object with some default configuration settings
		defaults : {
			container	: '',
			containerDot: '',
			childElement: 'li',
			containerDotClass : 'on',
			height		: 0,		// height of images
			width		: 0,		// width of images
			borderSize	: 0,		// size of border around images
			borderStyle	: 'none',	// style of border around images
			borderColor	: 'F00',	// color of border around images
			padding		: 0,		// amount of padding (in pixels) around images
			margin		: 0,		// amount of margin (in pixels) around images
			delay		: 5000,		// delay to next element
			speed		: 400,		// transition speed
			after		: null,		// transition after function
			before		: null		// transition before function
		},
		init : function(options) {
			// extend properties supplied by user
			var config = this.defaults;
			for (var option in options) {
				config[option] = options[option];
			}
			config.container = '#' + config.container;
			function log() {
				if (window.console && console.log) {
					console.log('[rolling] ' + Array.prototype.join.call(arguments, ' '));
				}
			}
			function start(config) {
				$(config.container).css({
					position	: 'relative',
					height		: config.height + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2 + 'px',
					width		: config.width + parseInt(config.borderSize) * 2 + 'px',
					overflow	: 'hidden'
				});
				var rollingSize = $(config.container + ' ' + config.childElement).size();
				if (rollingSize < 2) {
					log('terminating; too fee size:', rollingSize);
					return false;
				}
				$(config.container + ' ' + config.childElement).each(function(i) {
					$(this).css({
						position: 'absolute',
						top		: 0,
						left	: i * (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2) + 'px'
					}).attr('rollingIndex', i + 1);
				});
				$(config.container + ' ' + config.childElement + ':first').addClass('selected');
				$(config.container + ' ' + config.childElement + ' img').css({
					border	: config.borderSize + 'px ' + config.borderStyle + ' #' + config.borderColor,
					height	: config.height,
					width	: config.width
				});
				$(config.container + ' ' + (config.childElement === 'a' ? 'a' : config.childElement + ' a')).bind('focus mouseenter', function() {
					clearTimeout(config.rollingTimeout);
				}).bind('blur mouseleave', function() {
					config.rollingTimeout = setTimeout( function() { next(config); }, config.delay);
				});
				config.rollingTimeout = setTimeout( function() { next(config); }, config.delay);
			}
			function next(config) {
				var i = parseInt($(config.container + ' ' + config.childElement + '.selected').attr('rollingIndex'));
				if (typeof config.before == 'function') {
					config.before.call(this, config, i, NextElement(config, i));
				}
				if (LastElement(config, i)) {
					$(config.container + ' ' + config.childElement + '[rollingIndex="' + NextElement(config, i) + '"]').css('left', (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2) + 'px');
				}
				$(config.container + ' ' + config.childElement + '[rollingIndex="' + i + '"]').removeClass('selected');
				$(config.container + ' ' + config.childElement + '[rollingIndex="' + (NextElement(config, i)) + '"]').addClass('selected');
				var isValidLeft = false; // hack : for unknown error
				$(config.container + ' ' + config.childElement).each(function() {
					var newLeft = parseInt($(this).css('left').replace(/px/i, '')) - (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2);
					isValidLeft = isValidLeft || newLeft === 0;
				});
				if (!isValidLeft) {
					$(document.getElementById(config.containerDot)).find('a.' + config.containerDotClass).mouseenter().mouseleave();
					return false;
				}
				$(config.container + ' ' + config.childElement).each(function() {
					var newLeft = parseInt($(this).css('left').replace(/px/i, '')) - (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2);
					$(this).animate({'left' : newLeft + 'px'}, config.speed);
				});
				if (typeof config.after == 'function') {
					config.after.call(this, config, i, NextElement(config, i));
				}
				config.rollingTimeout = setTimeout( function() { next(config); }, config.delay);
			}
			function pause(config, i) {
				clearTimeout(config.rollingTimeout);
				$(config.container + ' ' + config.childElement).each(function(idx) {
					$(this).removeClass('selected');
				});
				$(config.container + ' ' + config.childElement).eq(i - 1).css('left', 0).addClass('selected');
	
				var rolling_left  = 0;
				var rolling_flag  = -1;
				var rolling_size  = $(config.container + ' ' + config.childElement).size();
				var rolling_width = (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2);
				var rolling_index = (i === 1 ? rolling_size : i - 1);
				while (rolling_index != i) {
					rolling_left = rolling_left + rolling_flag * rolling_width;
					$(config.container + ' ' + config.childElement).eq(rolling_index - 1).css('left', rolling_left + 'px');
					if (rolling_index === 1) {
						rolling_left  = 0;
						rolling_flag  = rolling_flag * rolling_flag;
						rolling_index = rolling_size;
					} else {
						rolling_index--;
					}
				}
			}
			function NextElement(config, index) {
				if (index < parseInt($(config.container + ' ' + config.childElement + ':last').attr('rollingIndex'))) {
					return index + 1;
				} else {
					return 1;
				}
			}
			function LastElement(config, index) {
				return (parseInt($(config.container + ' ' + config.childElement + '[rollingIndex="' + NextElement(config, index) + '"]').css('left').replace(/px/i, '')) == (1 - parseInt($(config.container + ' ' + config.childElement + ':last').attr('rollingIndex'))) * (config.width + config.padding * 2 + config.margin * 2 + parseInt(config.borderSize) * 2));
			}
	
			function swapDotClass(options, dot_idx) {
				$(document.getElementById(options.containerDot)).find('a').each(function(idx) {
					if (idx == dot_idx) {
						$(this).addClass(options.containerDotClass);
					} else {
						$(this).removeClass(options.containerDotClass);
					}
				});
			}
			if (config.containerDot != '') {
				config.after = function(options, currentIndex, nextIndex) {
					swapDotClass(options, nextIndex - 1);
				};
				$(document.getElementById(config.containerDot)).find('a:first').addClass(config.containerDotClass);
				$(document.getElementById(config.containerDot)).find('a').bind('focus mouseenter', function() {
					var rolling_obj = this;
					var rolling_idx = 0;
					$(document.getElementById(config.containerDot)).find('a').each(function(idx) {
						if (rolling_obj == this) {
							$(this).addClass(config.containerDotClass);
							rolling_idx = idx;
						} else {
							$(this).removeClass(config.containerDotClass);
						}
					});
					pause(config, rolling_idx + 1);
				}).bind('blur mouseleave', function() {
					config.rollingTimeout = setTimeout( function() { next(config); }, config.delay);
				});
			}
			start(config);
		}
	};
};
