// Global common Parameter
var GlobalParam = {
	siteURL			: location.protocol + '//' + location.host + '/partner',
	protocol : 'http:',
	indexClientWeb : '/index.html',
	sessionURL : function() {
		var URL = new Array();
		return URL;
	}(),
	nonSessionURL : function() {
		var URL = new Array();
		URL.push('/index.html');
		return URL;
	}()
};

// Global common Function
var GlobalFunc = {
	// AJAX \ud1b5\uc2e0 \uc624\ub958 \ubc1c\uc0dd\ud558\uc600\uc744 \ub54c \uba54\uc2dc\uc9c0 \ubcf4\uc5ec\uc8fc\uae30
	exceptionMsg : function(response) {
		if (response.error) {
			response.error.message = response.error.message.replace(/\\n/g, '\n');
			alert(response.error.message);
			if (response.error.forwardURL) {
				if (response.error.forwardURL === 'HISTORY_BACK') {
					$.back();
				} else if (response.error.forwardURL === '/index.html') {
					$.changePage('/index.html?returnUrl=' + location.href, { reloadPage : true, changeHash : false });
				} else {
					$.changePage(response.error.forwardURL, { reloadPage : true });
				}
			}
			return false;
		}
		return true;
	},
	// URL query string
	queryString : function() {
		var queryString = {};
		var searchString = window.location.search || function() {
			if (window.location.href.indexOf('?') >= 0) {
				return window.location.href.substring(window.location.href.indexOf('?'));
			}
			return '#';
		}();
		searchString.substring(1).replace(/([^=]+)=([^&]*)(&|$)/g, function() {
			queryString[arguments[1]] = arguments[2];
			return arguments[0];
		});
		return queryString;
	},
	protocol : function() {
		return location.protocol;
	}
};

// Common util function
var CommonFunc = {
	/**
	 * \uc8fc\ubbfc\ubc88\ud638\ub85c \uc0dd\ub144\uc6d4\uc77c \uc870\ud68c
	 * @param \uc8fc\ubbfc\ubc88\ud638
	 * @return {String} \uc0dd\ub144\uc6d4\uc77c
	 */
	ssnBirthConvert : function(ssn) {
		ssn = ssn.replace('-', '');
		// \uc8fc\ubbfc\ubc88\ud638 \uc55e\uc790\ub9ac
		var ssn1 = ssn.substring(0, 6);
		// 2000\ub144 \uc774\ud6c4 \ucd9c\uc0dd\uc790 \uad6c\ubd84
		var sex = ssn.substring(6, 7);
		if (sex === '1' || sex === '2' || sex === '5' || sex === '6') {
			return ('19' + ssn1);
		} else if (sex === '3' || sex === '4' || sex === '7' || sex === '8') {
			return ('20' + ssn1);
		}
		return '';
	},
	/**
	 * \uc8fc\ubbfc\ubc88\ud638 \uc131\ubcc4\uc22b\uc790\ub85c \uc131\ubcc4 \uc870\ud68c(\ub0a8/\uc5ec)
	 * @param \uc8fc\ubbfc\ub4f1\ub85d\ubc88\ud638 \ub4b7\uc790\ub9ac \uccab\ubc88\uc9f8 \uc22b\uc790
	 * @return {String} (\ub0a8/\uc5ec)
	 */
	ssnSexConvertKor : function(sexDigit) {
		if (sexDigit % 2 === 1) {
			return '\ub0a8';
		} else {
			return '\uc5ec';
		}
	},
	/**
	 * \ub9cc \ub098\uc774 \uacc4\uc0b0
	 * @param _birth_date \uc0dd\uc77c
	 * @return {Number} \ub9cc \ub098\uc774
	 */
	getFullAge : function(birth_date) {
		var full_age = Number(0);
		if (birth_date.length < 8) {
			return full_age;
		}
		var today	= new Date();
		switch (arguments.length) {
			case 1 :
				break;
			case 2 :
				var inputDate = arguments[1];
				if (typeof inputDate !== 'undefined' && inputDate.length === 8) {
					today = new Date(inputDate.substring(0, 4), Number(inputDate.substring(4, 6)) - 1, inputDate.substring(6));
				}
				break;
			default :
				alert('\uc798\ubabb\ub41c CommonFunc.getFullAge \ud638\ucd9c\uc785\ub2c8\ub2e4.');
				break;
		}
		var year	= today.getFullYear();
		var month	= today.getMonth() + 1;
		var day		= today.getDate();

		full_age = year - birth_date.substring(0, 4);
		if (month < birth_date.substring(4, 6)) {
			// \ud604\uc7ac \uc6d4\uc774 \ud0dc\uc5b4\ub09c \ub2ec\ubcf4\ub2e4 \ube60\ub97c \uacbd\uc6b0 \ub9cc\ub098\uc774 \ucc28\uac10
			full_age--;
		} else if (month == birth_date.substring(4, 6) && day < birth_date.substring(6, 8)) {
			// \ud604\uc7ac \uc6d4\uc740 \ud0dc\uc5b4\ub09c \ub2ec\uacfc \uac19\uc73c\ub098 \ud604\uc7ac \uc77c\uc790\uac00 \ud0dc\uc5b4\ub09c \uc77c\uc790\ubcf4\ub2e4 \ube60\ub97c \uacbd\uc6b0 \ub9cc\ub098\uc774 \ucc28\uac10
			full_age--;
		}
		return full_age;
	},
	
	/*
	* \uc804\ud654\ubc88\ud638 \uad6d\ubc88(0), \uc911\uac04\uc790\ub9ac(1), \ub05d\uc790\ub9ac(2)\ub85c \ubd84\ub9ac
	* @param \uc804\ud654\ubc88\ud638, \uc6d0\ud558\ub294 \uc790\ub9ac
	* @return tel (\uc804\ud654\ubc88\ud638 \ubc30\uc5f4)
	*/
	splitPhoneNo : function(telNo) {
		telNo = telNo.replace(/[^0-9]/g,''); // \uc22b\uc790 \uc678 \ubb38\uc790 \uc81c\uac70
		var tel = '';
		if (telNo.length < 9 || telNo.length > 12) {
			alert('\uc798\ubabb\ub41c \uc804\ud654\ubc88\ud638 \ud615\uc2dd\uc785\ub2c8\ub2e4');
			return false;
		}
		tel = telNo.replace(/(^01[016789]{1}|02|050[256]|0[3-9]{1}[0-9]{1})([0-9]+)([0-9]{4})$/, '$1-$2-$3').split('-');
		if (tel.length !== 3) {
			alert('\uc798\ubabb\ub41c \uc804\ud654\ubc88\ud638 \ud615\uc2dd\uc785\ub2c8\ub2e4');
			return false;
		}
		return tel;
	}
};

/**
 * \ub0a0\uc9dc \uad00\ub828 \ud568\uc218 \ubaa8\uc74c
 */
var DateFunc = {
	/**
	 * \uae30\uc900\uc77c\uc790\uc5d0 \uc6d4\uc744 \ub354\ud55c\ub2e4. \uae30\uc900\uc77c\uc790\uac00 \uc5c6\uc744 \uacbd\uc6b0 \ud604\uc7ac\uc77c\uc790\ub97c \uae30\uc900\uc73c\ub85c \ub354\ud574\uc900\ub2e4.
	 * @param add_month \ub354\ud574\uc904 \uac1c\uc6d4 \uc218
	 * @param delim \uad6c\ubd84\uc790
	 * @param standard_date \uae30\uc900\uc77c\uc790
	 * @returns \uae30\uc900\uc77c\uc790\uc5d0\uc11c \uac1c\uc6d4 \uc218\uac00 \ub354\ud574\uc900 \uc77c\uc790
	 */
	addMonth : function(add_month, delim, paramDate) {
		if (!paramDate) {
			var current_date = new Date();
			paramDate = current_date.getFullYear() + (current_date.getMonth() + 1).lpad(2, '0') + current_date.getDate().lpad(2, '0');
		}
		paramDate = paramDate.replace(/[^0-9]/g, '');
		var date_info = [ paramDate.substring(0, 4), paramDate.substring(4, 6), paramDate.substring(6, 8) ];
		var date_object = new Date(date_info[0], date_info[1] - 1, date_info[2]);
		date_object.setMonth(date_object.getMonth() + add_month);
		var return_date = date_object.getFullYear() + '-' + (date_object.getMonth() + 1 + 100).toString().substring(1) + '-' + (date_object.getDate() + 100).toString().substring(1);
		if (!delim) {
			delim = '';
		}
		return return_date.split('-').join(delim);
	},
	// \ub0a0\uc9dc\uc640 \uad6c\ubd84\uc790\ub97c \uc785\ub825\ubc1b\uc544 \uad6c\ubd84\uc790\ub97c \uc0bd\uc785\ud55c \ub0a0\uc9dc\ud615\uc2dd\uc73c\ub85c \ubc18\ud658\ud55c\ub2e4.
	addDelim : function(paramDate, delim, formatter) {
		if (formatter) {
			var returnDate = '';
			var cutPoint = 0;
			$.each(formatter.split(delim), function(idx, format) {
				returnDate += delim + paramDate.substr(cutPoint, format.length);
				cutPoint += format.length;
			});
			return returnDate.substring(delim.length);
		}
		switch (paramDate.length) {
			case 4 :
				delim = delim || ':';
				return paramDate.substring(0, 2) + delim + paramDate.substring(2);
			case 6 :
				delim = delim || '-';
				return paramDate.substring(0, 4) + delim + paramDate.substring(4);
			case 8 :
				delim = delim || '-';
				return paramDate.substring(0, 4) + delim + paramDate.substring(4, 6) + delim + paramDate.substring(6);
		}
		return paramDate;
	},
	// 'yyyyMMdd' \ud615\uc2dd\uc758 \ub0a0\uc9dc\ub97c \ubc1b\uc544 'yyyy\ub144 MM\uc6d4 dd\uc77c' \ud615\uc2dd\uc73c\ub85c \ubcc0\uacbd\ud55c\ub2e4.
	formatKorean : function(paramDate) {
		paramDate = paramDate.replace(/[^0-9]/gi, '');
		if (paramDate.length != 8) {
			alert('\uc798\ubabb\ub41c DateFunc.formatKorean \ud638\ucd9c\uc785\ub2c8\ub2e4.');
			return false;
		}
		return paramDate.substring(0, 4) + '\ub144 ' + paramDate.substring(4, 6) + '\uc6d4 ' + paramDate.substring(6, 8) + '\uc77c';
	},
	/** toDate - fromDate \uc77c\uc218 \uacc4\uc0b0 **/
	dateDiff : function(fromDate, toDate, interval) {
		var second = 1000, minute = second * 60, hour = minute * 60, day = hour * 24, week = day * 7;
		fromDate.replace(/[^0-9]/gi, '');
		toDate.replace(/[^0-9]/gi, '');
		fromDate = new Date(fromDate.substring(0, 4), fromDate.substring(4, 6), fromDate.substring(6, 8));
		toDate = new Date(toDate.substring(0, 4), toDate.substring(4, 6), toDate.substring(6, 8));
		var timediff = toDate - fromDate;
		if (isNaN(timediff)) return NaN;
		switch (interval) {
			case "years": return toDate.getFullYear() - fromDate.getFullYear();
			case "months": return (
							(toDate.getFullYear() * 12 + toDate.getMonth())
							-
							(fromDate.getFullYear() * 12 + fromDate.getMonth())
						);
			case "weeks": return Math.floor(timediff / week);
			case "days": return Math.floor(timediff / day);
			case "hours": return Math.floor(timediff / hour);
			case "minutes": return Math.floor(timediff / minute);
			case "seconds": return Math.floor(timediff / second);
			default: return undefined;
		}
	}
};

function SetNum(obj)
{
	
	val=obj.value;
	re=/[^0-9]/gi;
	obj.value=val.replace(re,"");
}
function nextFocus(obj1, num, obj2) {
	if(obj1.value.length >= num) obj2.focus();
}

String.prototype.addComma = function() {
	//return Number(this).toLocaleString().split('.')[0];
	var _amount = this.split('.');
	var _integer = _amount[0];
	var _decimal = _amount.length > 1 ? '.' + _amount[1] : '';
	var _regex = /(^[+-]?\d+)(\d{3})/;
  	while (_regex.test(_integer)) {
  		_integer = _integer.replace(_regex, '$1' + ',' + '$2');
  	}
  	return _integer + _decimal;
};
Number.prototype.addComma = function() {
	var _amount = this.toString().split('.');
	var _integer = _amount[0];
	var _decimal = _amount.length > 1 ? '.' + _amount[1] : '';
	var _regex = /(^[+-]?\d+)(\d{3})/;
  	while (_regex.test(_integer)) {
  		_integer = _integer.replace(_regex, '$1' + ',' + '$2');
  	}
  	return _integer + _decimal;
};

