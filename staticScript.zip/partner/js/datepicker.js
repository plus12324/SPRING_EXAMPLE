$(function() {
	$('.datepicker').datepicker({
	    showOn: "button",
	    buttonImage: "/static/partner/images/btn_cal.gif",
	    buttonImageOnly: true,
	    dateFormat: "yy/mm/dd",
	    minDate: '-0y',
	    changeYear: true,
	    changeMonth: true,
	    showButtonPanel: true,
	    nextText: '\ub2e4\uc74c \ub2ec',
	    prevText: '\uc774\uc804 \ub2ec',
	    currentText: '\uc624\ub298 \ub0a0\uc9dc',
	    closeText: '\ub2eb\uae30',
	    dayNamesMin: ['\uc6d4','\ud654','\uc218','\ubaa9','\uae08','\ud1a0','\uc77c'],
	    monthNamesShort: ['1\uc6d4', '2\uc6d4', '3\uc6d4','4\uc6d4', '5\uc6d4', '6\uc6d4','7\uc6d4', '8\uc6d4', '9\uc6d4', '10\uc6d4', '11\uc6d4', '12\uc6d4']
	});
	$('.datepickerAll').datepicker({
	    showOn: "button",
	    buttonImage: "/static/partner/images/btn_cal.gif",
	    buttonImageOnly: true,
	    dateFormat: "yy/mm/dd",
	    changeYear: true,
	    changeMonth: true,
	    showButtonPanel: true,
	    nextText: '\ub2e4\uc74c \ub2ec',
	    prevText: '\uc774\uc804 \ub2ec',
	    currentText: '\uc624\ub298 \ub0a0\uc9dc',
	    closeText: '\ub2eb\uae30',
	    dayNamesMin: ['\uc6d4','\ud654','\uc218','\ubaa9','\uae08','\ud1a0','\uc77c'],
	    monthNamesShort: ['1\uc6d4', '2\uc6d4', '3\uc6d4','4\uc6d4', '5\uc6d4', '6\uc6d4','7\uc6d4', '8\uc6d4', '9\uc6d4', '10\uc6d4', '11\uc6d4', '12\uc6d4']
	});
});