var tableFunc =  {
		dnd : function(tableObject, reorderIndex) {
			$(tableObject).tableDnD({
				onDragClass : 'myDragStyle',
			    onDrop: function(table, row) {
			    	// reorder id text
			    	var i = 0;
			    	tableObject.find('tbody tr').each(function(i){
			    		$(this).find('td:eq(' + reorderIndex + ')').text(i + 1);
			    	});
			    },
				onDragStart: function(table, row) {
				}
			});
		},
		
		hideColumn : function(tableObject, index) {
			// hide the column at index, thead ���� üũ
			if ($('.boardlist').find('thead') === null) {
				 $('td:nth-child(' + index + ')').hide();
			} else {
				$('td:nth-child(' + index + '),th:nth-child(' + index +')').hide();
			}
		},
		
		showColumn : function(tableObject, index) {
			if ($('.boardlist').find('thead') === null) {
				 $('td:nth-child(' + index + ')').show();
			} else {
				$('td:nth-child(' + index + '),th:nth-child(' + index +')').show();

			}
		}
}
