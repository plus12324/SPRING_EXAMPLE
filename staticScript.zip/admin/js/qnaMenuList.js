$(function() {
	$('.hiddenTarget').each(function() {
		$(this).append($('#hiddenOrg').clone());
	});
	$('.btnGroupClone').each(function() {
		$(this).append($('#btnGroup').clone());
	});

	$('.tb1d').find('li').click(function() {
		$('.tb1d').find('li').each(function() {
			$(this).removeClass('on');
		});
		$('.tb1dcont').each(function() {
			$(this).addClass('dpn');
		});
		$(this).addClass('on');
		$('#' + 'catMenu' + $(this).attr('id')).removeClass('dpn');
	});
	
	$('.confirm').click(function() {
		debugger;
		var tabID = getTabID();
		alert(tabID);
		if(tabID == null) {
			return false;
		}
		$('.' + tabID + 'ModifyOrder').each(function() {
			$(this).val($(this).closest('tr').find('.order').text());
		});

		var formID = getFormID(tabID);
		$(formID).attr('action', '/admin/qna/menuConfirm');
		progressbar.show();
		$(formID).submit();
	});
	
	$('.regist').click(function() {
		var tabID = getTabID();
		if(tabID == null) {
			return false;
		}
		var menuType = getMenuType(tabID);
		if(menuType == null) {
			return false;
		}
		$(this).closest('.tb1dcont').find('.sMenuType').val(menuType);
		
		var formID = getFormID(tabID);
		$(formID).attr('action', '/admin/mainScreen/menuRegisterInit');
		progressbar.show();
		$(formID).submit();
	});
	
	$('.modify').click(function() {
		var tabID = getTabID();
		var menuType = getMenuType(tabID);
		if(menuType == null) {
			return false;
		}
		$(this).closest('.tb1dcont').find('.sMenuType').val(menuType);
		$(this).closest('.tb1dcont').find('.nSeq').val($(this).closest('tr').find('.seq').val());

		var formID = getFormID(tabID);
		$(formID).attr('action', '/admin/mainScreen/menuModifyInit');
		progressbar.show();
		$(formID).submit();
	});
	
	$('.delete').click(function() {
		var tabID = getTabID();
		var menuType = getMenuType(tabID);
		if(tabID == null) {
			return false;
		}
		var formID = getFormID(tabID);
		$(formID).attr('action', '/admin/mainScreen/deleteMenu');
		progressbar.show();
		$(formID).submit();
	});
	
	function getFormID(tabID) {
		return '#' + tabID + 'Form';
	}
	function getMenuType(tabID) {
		var menuType = null;
		if(tabID === 'mainMenu') {
			menuType = 'A';
		}else if(tabID === 'firstVisit') {
			menuType = 'B';
		}else if(tabID === 'signUpCustomers') {
			menuType = 'C';
		}else if(tabID === 'issueZone') {
			menuType = 'E';
		}else if(tabID === 'bannerZone') {
			menuType = 'F';
		}
		return menuType;
	}
	function getTabID() {
		var id = null;
		$('.tb1d li').each(function() {
			if($(this).hasClass('on')) {
				alert($(this).attr('id'));
				id = "#mainMenuForm" + $(this).attr('id');
				return false;	// break;
			}
		});
		return id;
	}
});