popupOpen = {
    _document : null,
    callback : null,
    titleHeight : 30,
    layerLeft : 0,
    layerTop : 0,
    open : function(_document, title, url, layerWidth, layerHeight) {
        this._document = _document;

        // iframe�� �������� ������ ����
        if ($("#popupDiv").length <= 0) {
            $("body").append("<div id='popupDiv'><div id='title'><div id='titleText'></div><img id='closeIcon' src='/static/admin/images/inc/btn_pp_close.gif'/></div><iframe id='popupFrame' src='about:blank' frameborder='0'></iframe></div>");

            $("#closeIcon").on("click", function() {
            	popupOpen.close();
            });
        }

        this.resize(layerWidth, layerHeight);

        $("#titleText").html(title);
        $("#popupFrame").attr("src", url);

        // �⺻ ��Ÿ�� ����
        $.blockUI.defaults.css = {
            padding : 0,
            margin : 0,
            left : this.layerLeft,
            top : this.layerTop,
            cursor : 'wait'
        };

        $.blockUI.defaults.overlayCSS = {
            backgroundColor : '#000',
            opacity : 0.5,
            cursor : 'wait'
        };
        
        $.blockUI.defaults.baseZ = 1000;
        
        // ���� �˾�
        $.blockUI({
            message : document.getElementById("popupDiv"),
            fadeIn : 0,
            bindEvents : false,
            centerX : false,
            centerY : false
        });

        $("#popupDiv").show();
    },

    resize : function(layerWidth, layerHeight) {
        // �ִ� �˾� ũ�⿡ ���� ũ�� ����
        if ($(window).width() < layerWidth) {
            layerWidth = $(window).width();
        }

        if ($(window).height() < layerHeight + this.titleHeight) {
            layerHeight = $(window).height() - this.titleHeight;
        }

        // �ּ� �˾� ũ�⿡ ���� ũ�� ����
        if (layerWidth < 350) {
            layerWidth = 350;
        }

        if (layerHeight < 530) {
            layerHeight = 530;
        }

        this.layerLeft = Math.round(($(window).width() - layerWidth) / 2);
        this.layerTop = Math.round(($(window).height() - layerHeight - this.titleHeight) / 2);

        if (this.layerLeft < 0) {
            this.layerLeft = 0;
        }

        if (this.layerTop < 0) {
            this.layerTop = 0;
        }

        if ($("#popupDiv").parent()) {
            $("#popupDiv").parent().css("left", this.layerLeft);
            $("#popupDiv").parent().css("top", this.layerTop);
        }

        $("#popupDiv").width(layerWidth);
        $("#popupDiv").height(layerHeight);
    },

    close : function() {
        $("#popupFrame").attr("src", "");
        $("#popupDiv").hide();

        $.unblockUI({
            message : document.getElementById("popupDiv"),
            fadeOut : 0
        });
    }
};