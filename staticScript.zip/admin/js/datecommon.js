// ���ó�¥ �������� returnType : "-" or ":" or "/" or "" .. ��Ÿ��� ) 
function DCgetNowDate(returnType) {
	
	var today 	= new Date();
	var nowDate = today.getFullYear() + "-" + (today.getMonth()+1+100+"").substring(1,3) + "-" + (today.getDate()+100+"").substring(1,3);

	if ( returnType == null )
		returnType = "";

	var returnDate = nowDate.split("-").join(returnType);
	
	return returnDate;
}

// �� ���ϱ� or ������ ��¥���� �� ���ϱ�	( *addYear : ���ϰų� �� ���� , returnType : "-" or ":" or "/" or "" .. ��Ÿ��� , currentDate : ������¥ 1977-11-07 )
function DCaddYear(addYear, returnType, currentDate ) {

	if ( currentDate == null ) 
		currentDate = DCgetNowDate("-");

	var dateinfo	= currentDate.split("-");
	var srcDate	= new Date(dateinfo[0], dateinfo[1]-1, dateinfo[2]);	
	srcDate.setYear(srcDate.getFullYear() + addYear);
	var returnDate = srcDate.getFullYear() +"-" + (srcDate.getMonth()+1+100+"").substring(1,3) +"-" + (srcDate.getDate()+100+"").substring(1,3);

	if ( returnType == null )
		returnType = "";
	returnDate = returnDate.split("-").join(returnType);

	return returnDate;
}


// �� ���ϱ� or ������ ��¥���� �� ���ϱ�	( *addMonth : ���ϰų� �� ���� , returnType : "-" or ":" or "/" or "" .. ��Ÿ��� , currentDate : ������¥ 1977-11-07 )
function DCaddMonth(addMonth, returnType, currentDate ) {

	if ( currentDate == null ) 
		currentDate = DCgetNowDate("-");

	var dateinfo	= currentDate.split("-");
	var srcDate	= new Date(dateinfo[0], dateinfo[1]-1, dateinfo[2]);	
	srcDate.setMonth(srcDate.getMonth() + addMonth);
	var returnDate = srcDate.getFullYear() +"-" + (srcDate.getMonth()+1+100+"").substring(1,3) +"-" + (srcDate.getDate()+100+"").substring(1,3);

	if ( returnType == null )
		returnType = "";
	returnDate = returnDate.split("-").join(returnType);

	return returnDate;
}

// �� ���ϱ� or ������ ��¥���� �� ���ϱ�	( *addDate : ���ϰų� �� ���� , returnType : "-" or ":" or "/" or "" .. ��Ÿ��� , currentDate : ������¥ 1977-11-07 )
function DCaddDate(addDate, returnType, currentDate ) {

	if ( currentDate == null ) 
		currentDate = DCgetNowDate("-");

	var dateinfo	= currentDate.split("-");
	var srcDate	= new Date(dateinfo[0], dateinfo[1]-1, dateinfo[2]);	
	srcDate.setDate(srcDate.getDate() + addDate);
	var returnDate = srcDate.getFullYear() +"-" + (srcDate.getMonth()+1+100+"").substring(1,3) +"-" + (srcDate.getDate()+100+"").substring(1,3);

	if ( returnType == null )
		returnType = "";
	returnDate = returnDate.split("-").join(returnType);

	return returnDate;
}

/*
 * ��¥ ��    date1 - date2
 */
function compareDate(date1, date2, formatChar) {
	var aDate1 = {};
	var aDate2 = {};

	if (formatChar == '') {
		aDate1[0] = date1.substring(0, 4);
		aDate1[1] = date1.substring(4, 6);
		aDate1[2] = date1.substring(6, 8);
		aDate2[0] = date2.substring(0, 4);
		aDate2[1] = date2.substring(4, 6);
		aDate2[2] = date2.substring(6, 8);
	}
	else {
		aDate1 = date1.split(formatChar);
		aDate2 = date2.split(formatChar);
	}
	var date1 = new Date(aDate1[0], aDate1[1], aDate1[2]);
	var date2 = new Date(aDate2[0], aDate2[1], aDate2[2]);
	var days = Math.ceil((date1 - date2) / 24 / 60 / 60 / 1000);

	return days;
};