var progressbar = {
	show : function() {
		$('#layerPop').dialog({
			modal: false, width: 0, height: 0, minHeight: 0, minWidth: 0, resizable: false, autoOpen: true,
			closeOnEscape: false,
	        open: function(event, ui) {
	        	$('.ui-dialog').removeClass('ui-widget ui-widget-content ui-draggable');
	        	$('.ui-dialog-titlebar').removeClass('ui-widget-header ui-corner-all ui-helper-clearfix');
	        }
		});
	},
	hide : function() {
		$('#layerPop').dialog('close');
	}
}
