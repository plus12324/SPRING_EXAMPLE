$(function() {
	// ��ü����
	$('.checkboxAll').click(function() {
		var flag = $(this).attr('checked') == 'checked';
		$(this).closest('tr.checkboxAllTop').find(':checkbox').each(function() {
			this.checked = flag;
		});
	});
	// ��޴� üũ�ڽ�
	$('.checkbox').click(function() {
		var $obj = $(this).closest('div.treemenuTop').find('ul');
		var flag = $(this).attr('checked') == 'checked';
		$obj.find(':checkbox').each(function() {
			this.checked = flag;
		});
	});
	// �Ҹ޴� üũ�ڽ�
	$('.checkboxSub').click(function() {
		var flag = $(this).attr('checked') == 'checked';
		$(this).closest('li').find(':checkbox').each(function() {
			this.checked = flag;
		});
	});
	// �޴� ���
	$('.treemenu :not(input)').toggle(function(e) {
		$(this).closest('div.treemenuTop').find('ul').hide();
	}, function(e) {
		$(this).closest('div.treemenuTop').find('ul').show();
	});
	function checkOnOff(flag, $obj) {
		$obj.find('input[type=checkbox]').each(function() {
			if(flag == 'checked') {
				$(this).attr('checked', flag);
			}else {
				$(this).removeAttr('checked');
			}
		});
	}
});
var controlledaccount = {
	initCheckbox : function() {
		var sPermission = $('#sPermission').val();
		var sPermissionArray = sPermission.split("|");
		var isCheckboxAll = true;
		// ������ ������ �޴��� üũ
		$('.checkboxAllTop').find(':checkbox').each(function() {
			if($.inArray($(this).attr('id'), sPermissionArray) >= 0) {
				this.checked = true;
			}
		});
		// checkbox�� loop�� ���� ���� checkbox�� ���� check�̸� check
		$('.checkbox').each(function() {
			var $obj = $(this).closest('div.treemenuTop').find('ul').find('li');
			var isCheckboxCheck = true;
			
			$($obj).each(function() {

				$(this).find('.checkboxSub').each(function() {
					var $subList = $(this).closest('li').find('.subList');
					var isCheckboxSub = true;
					if($($subList).size() > 0) {
						$($subList).find(':checkbox').each(function() {
							if(this.checked == false) {
								isCheckboxSub = false;
								return false; //break;
							}
						});
						this.checked = isCheckboxSub;
					}
					
					if(this.checked != true) {
						isCheckboxCheck = false;
						return false;	//break;
					}
				});

			});
			this.checked = isCheckboxCheck;
			if(isCheckboxAll && !isCheckboxCheck) {
				isCheckboxAll = false;
			}			
		});
		document.getElementById('checkboxAll').checked = isCheckboxAll;
	},
	disabledCheckbox : function() {
		// ������ ������ �޴��� üũ
		$('.checkboxAllTop').find(':checkbox').each(function() {
			// ��� üũ�ڽ� disabled
			$(this).attr('disabled', true);
		});
	},
	getsPermission : function() {
		var sPermission = '';
		$('.checkboxAllTop').find(':checkbox:checked').not('.submitIgnore').each(function() {
			if(sPermission.length != 0) {
				sPermission += "|";
			}
			sPermission += $(this).attr('id');
			//console.log($(this).attr('id'));
		});
		return sPermission;
	}
}