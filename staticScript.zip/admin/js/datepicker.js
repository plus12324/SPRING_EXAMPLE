$(function() {
	$('.datepicker').datepicker({
	    showOn: "button",
	    buttonImage: "/static/admin/images/inc/ic_calendar.gif",
	    buttonImageOnly: true,
	    dateFormat: "yy-mm-dd",
	    minDate: '-0y',
	    changeYear: true,
	    changeMonth: true,
	    showButtonPanel: true
	});
	$('.datepickerAll').datepicker({
	    showOn: "button",
	    buttonImage: "/static/admin/images/inc/ic_calendar.gif",
	    buttonImageOnly: true,
	    dateFormat: "yy-mm-dd",
	    changeYear: true,
	    changeMonth: true,
	    showButtonPanel: true
	});
	$('.datepicker2').datepicker({
	    showOn: "button",
	    buttonImage: "/static/admin/images/inc/ic_calendar.gif",
	    buttonImageOnly: true,
	    dateFormat: "yy-mm-dd",
	    minDate: '-7d',
	    maxDate: '+7d',
	    changeYear: true,
	    changeMonth: true,
	    showButtonPanel: true
	});
	
	
});