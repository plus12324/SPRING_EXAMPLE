$(function() {
	$('.insurance').click(function() {
		var isCheck = this.checked;
		$(this).closest('.checkboxTop').find('.list :checkbox').each(function() {
			this.checked = isCheck;
		});
	});
	$('.checkboxSub').click(function() {
		var isCheck = true;
		$(this).closest('.list').find(':checkbox').each(function() {
			if(this.checked == false) {
				isCheck = false;
				return false; //break;
			}
		});
		$(this).closest('.checkboxTop').find('.insurance').attr('checked', isCheck);
	});
});
function longInsuranceCheck() { 
	var longCheck = true;
	$('.longInsuranceCheck').each(function() {
		if(this.checked == false) {
			longCheck = false;
			return false;	//break;
		}
	})
	if(longCheck) {
		var selectBox = $('select[name=sLongProductCode]');
		if($(selectBox).val() == '') {
			$(selectBox).focus();
			return false;
		}
	}
	return true;
}
function explanationTextCheck(id) {
	var checkValue = false;
	
	$('#' + id).closest('.checkboxTop').find('.checkboxSub').each(function() {
		if($(this).checked == true) {
			checkValue = true;
			return false;	// break;
		}
	});
	if(checkValue && $('#' + id).val() == '') {
		return false;
	}
	return true;
}